In this image we can see a poster with some text and images.

<!-- image -->

Based on the National Curriculum Framework: Grades 7,8 &amp; 9 (2017) - Nine-Year Continuous Basic Education

In this image we can see a poster with some text and images.

<!-- image -->

## Professor Vassen Naëck -

Head Curriculum Implementation, Textbook Development and Evaluation

## PHYSICAL EDUCATION PANEL

<!-- image -->

Bharutty Ramguttee

- Coordinator, Lecturer, MIE

Ravi Bhurtun

- Senior Lecturer, MIE

Yudhishthir Rao Rama

- Lecturer, MIE

Udylen Veerasamy

- Educator

Teerhan Seebah Beeharry

- Educator

Shravansingh Sowamber

- Educator

Honee Heerah

- Educator

Bernard Nuchadee

- Educator

Azarias Baptiste

- Educator

Design

Karnesh Ramful

- Graphic Designer

## © Mauritius Institute of Education (2021)

ISBN: 978-99949-53-91-2

## Acknowledgements

The Physical Education Panel wishes to acknowledge the contribution of:

Kamini Moteea , (Lecturer, MIE) for proof reading

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The  development  of  textbooks  has  been  a  very  challenging  exercise  for  the  writers  and  the  MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and Evaluation provided guidance with respect to the objectives of the NCF, while ascertaining that the  instruction  designs  are  appropriate  for  the  age  group  targeted.  I  also  acknowledge  the  efforts of  the  graphic  artists  who  put  in  much  hard  work  to  maintain  the  quality  of  the  MIE  publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## Preface

The grade 9 Physical Education book is in line with the philosophy of the National Curriculum 2017. It has two components, that is, the theory and practical components which aim at enhancing acquired motor  skills  from  grade  7  and  8  to  be  able  to  perform  a  variety  of  sports  and  physical  activities. The book aims to develop responsible learners with knowledge, skills, and dispositions to work together in groups, think critically and to pursue a lifelong healthy and active lifestyle. Students will be able to experience and assess their own designed fitness, exercise and nutrition programmes.

The practical component emphasises on the learning of fundamental and in-depth skill development through  individual  and  group  activities.  It  is  categorised  into  three  themes:  Alternative  Activities; Net/Ball Activities; Outdoor and Athletics Activities. A school should do at least one sport/activity from the three themes .

The theory component equips learners with knowledge of sports injuries, respiratory system, circulatory system, good body mechanics , health, diet and fitness which will be useful to enjoy a healthy lifestyle.

QR CODES: Scan QR codes on your smartphone to view videos which will enable you to learn and practise skills and fitness activities.

To  test  the  knowledge  and  skill  of  learners,  different  challenges  and  working  exercises  have  been included in the different practical units and theory topics.

In this image, we can see a diagram.

<!-- image -->

## INJURIES

## Learning Objectives

<!-- image -->

## In this chapter you will learn about the:

- causes and symptoms of minor injuries
- RICER treatment on sprains and strains

## Introduction

In this chapter, you will be exposed to basic knowledge of first aid. However in case of doubt about the type and severity of the injury, call a qualified person for assistance.

In your daily life, you are constantly exposed to various situations where you may get injured. Similarly, when you practise a physical activity, the risk of getting injured is also present but if you take appropriate preventive measures, you can easily avoid it.

## Some ways to prevent injuries are listed in figure 1:

Warm up and cool down properly

Check if the playing surface, facilities or equipment are safe to use

<!-- image -->

Ensure that a teacher/ coach/ responsible person is always present

<!-- image -->

<!-- image -->

Do not participate when over-tired, sick or injured

Use appropriate clothing, footwear and protective equipment

<!-- image -->

<!-- image -->

Choose a team or opponent which matches your level of skill and physique

<!-- image -->

Abide by the rules and regulations of the games

Figure 1

Adopt correct posture and handle equipment with care

## UNIT 1

## First Aid

Despite of the preventive measures mentioned, a simple carelessness can cause injury. You might get panicked and don't know what to do. Most of the time people adopt inappropriate actions that worsen the injuries instead of helping it to heal.

First aid is that initial assistance or treatment given to a person who is injured or suddenly falls ill.

In this image we can see a person wearing a green color shirt and holding a stick. In the background there is a person wearing a white color shirt and holding a stick.

<!-- image -->

Figure 2 represents some common injuries that may occur while participating in Physical Activities

## Did you know

## A first aider should:

- stay calm and safe all time
- assess a situation
- protect him/herself
- wash their hands before and after exposure to an injury
- prevent spreading of infection
- provide comfort and reassure
- give first treatment
- arrange for appropriate help
- pass on relevant information to emergency services that will take care of the casualty

<!-- image -->

## Treatment for minor injuries

RICER is the most commonly used procedure for treating minor injuries. It stands for:

<!-- image -->

<!-- image -->

<!-- image -->

Figure 3

<!-- image -->

Stop the activity immediately and sit or lie down in a safe area. Rest prevents from further injury and helps you to  evaluate  the  severity  of the injury.

<!-- image -->

Figure 6

<!-- image -->

## Elevation

Raise the injured part above heart level. This decreases swelling  and  reduces  blood flow to the injured area due to the force of gravity.

Figure 4

<!-- image -->

Ice

Wrap ice  in  a  piece  of  cloth or plastic and apply it around the  injured  area.  This  helps to slow the internal bleeding and  swelling  by  narrowing the blood vessels.

<!-- image -->

Figure 7

<!-- image -->

## Referral

Refer the injured person to a qualified professional such as a  doctor  or  physiotherapist for precise diagnosis and further treatment.

Figure 5

<!-- image -->

## Compression

Use a clean piece of cloth or bandage to wrap the injured area to control swelling.

## Types of injuries

## Injuries and assistance to be given

## Figure 8: STRAINS

This is a diagram, which consists of a person doing stretching exercises. There are three different parts of the image. The person is in the middle of stretching. There are two different parts of the image, which are labeled as "Stretching", "Large", and "Complete tear".

<!-- image -->

It occurs when there is a twist, pull or tear of the muscle or tendon at joint.

In this image, we can see a diagram of the human leg. We can also see the legs and the feet. We can see the text at the top of the image.

<!-- image -->

## Both of them have the same sign and symptoms and are treated alike.

Signs and Symptoms: Swelling, tenderness, pain, decolouring of the skin, bruises, difficulty in moving the injured part.

Assistance to be given (reduce swelling and pain):

1.  Sit or lie down and support the injured part.
2.  Apply cold compress to reduce pain, swelling and bruise.
3.  Secure it with a bandage that is next to the joint.
4.  Support and raise the injured part preferably above the heart level
5.  Call for medical help.

## Figure 10: CUTS

<!-- image -->

This is likely to happen after having an impact with a sharp or hard object.

Signs and Symptoms: Open wound, bleeding, redness or swelling around the wound, pain or irritation at the skin surface.

Assistance to be given (control bleeding and minimise the risk of infection):

1.  Clean the wound and cover it with a sterilze gauze.
2.  Raise and support the injured part above heart level.
3.  If the cut is deep or bleeding is not stopping, immediately call for medical help.

## Figure 11: BLISTERS

<!-- image -->

When the skin is repeatedly rubbed against another surface or when exposed to heat, cold or chemical exposure.

Signs and Symptoms: Liquid filled sac, pain, burning.

Assistance to be given (prevent further rubbing):

1.  Do not burst a blister as it increases the risk of infection (In case of burst, do not peel off the dead skin).
2.  Clean  the  blister  and  cover  with adhesive dressing.

## Figure 12: ABRASIONS

<!-- image -->

When the skin rubs against a rough surface and is superficial in nature.

Signs and Symptoms: Irritated itchy skin, bleeding, sensitive skin, redness, pain.

Assistance to be given (protect the skin):

1.  Clean the wound.
2.  Place a sterile dressing.

## Figure 13: BRUISE

<!-- image -->

A bleeding beneath the skin due to a blow or fall.

Signs and Symptoms: Bluish or purple coloured patches, swelling, pain.

Assistance to be given (reduce blood flow and swelling):

1.  Raise and support the injured part in a comfortable position.
2.  Apply cold compress around the wound.

<!-- image -->

## QUESTIONS

1. Write down five preventive measures that you can adopt to avoid injuries while practising your favourite game.
2. Bernard was playing hopscotch in the school yard with his friends when he suddenly twisted  his  ankle  while  jumping.  According  to  you,  what  assistance  should  be given to him?
3. Match the following injury with their related causes.

## INJURY

## CAUSES

1.  Strain
2.  Cut
3.  Blister
4.  Bruise
5.  Sprain

## 4. Research work on:

- a)  sunburn
- b)  dehydration and cramps
- A.  This is likely to happen after having an impact with a sharp or hard object
- B.  When the skin is repeatedly rubbed against another surface or when exposed to heat, cold or chemical exposure
- C.  Muscle or tendon is overstretched or torn
- D.  Ligament is overstretched or torn around a joint
- E.  A bleeding beneath the skin due to a blow or fall

## RESPIRATORY SYSTEM

<!-- image -->

## Learning Objectives

## In this chapter you will learn about the:

- different parts of the respiratory system
- functions of the lungs
- short and long term effects of exercise on the respiratory system

## Introduction

The respiratory system is responsible for the exchange of gases. Breathing is a physiological process of moving air into and out of your lungs. Although you can't see it, the air you breathe is made up of several gases like nitrogen, oxygen, Ilium, carbon dioxide, etc. Oxygen is the gas which is required by the body to live, grow and produce energy.

<!-- image -->

<!-- image -->

## Breathe  IN

Taking in air from the atmosphere to the lungs is called breathe in (inhale)

## Breathe  OUT

Taking out of air from the lungs to the atmosphere is called breathe out (exhale).

Figure 1

## UNIT 2

## Pathway of air (Figure 1)

In this image, we can see a diagram.

<!-- image -->

## UNIT 2   |   RESPIRATORY SYSTEM

## Structure of the respiratory system

The diagram below is a cross-section of the respiratory system. The nasal cavity, mouth, trachea, alveoli, bronchiole, bronchus, diaphragm and lungs are all shown.

Figure 3

In this image we can see a human body. In the background there is a white color background.

<!-- image -->

## Measuring Respiratory Rate

The respiratory rate is defined as the number of breaths a person takes in a one-minute period at  rest.  Children  have  faster  respiratory  rates  than  adults,  and  the  respiratory  rate  can  vary significantly by age.

The normal ranges of respiratory rates for different ages include:

- Children (6-12 years): 18-30 breaths per minute
- Adolescent (13-17 years): 12-16 breaths per minute

## Spirometer

A spirometer is a small instrument attached by a cable to  a  mouthpiece.  It  is  used  to  measure  the  volume of air inspired and expired by the lungs. It is usually measured in millilitres (ml).

Figure 4

In this image we can see a person sitting on the chair and holding a camera in his hand. In the background there is a monitor and a person sitting on the chair.

<!-- image -->

## The mechanism of breathing

The process of breathing takes place in two phases:

## Inspiration (inhale)

In this image, we can see a diagram.

<!-- image -->

Figure 5

<!-- image -->

## EXPERIMENTS

## ACTIVITY 1

Create a model of the lungs and explain it.

This link can help you in doing the activity.

<!-- image -->

## CHECK THIS LINK

https://www.teachengineering.org/activities/view/ cub\_human\_lesson09\_activity1

## Expiration (exhale)

Figure 6

In this image, we can see a person. We can also see the text.

<!-- image -->

<!-- image -->

Figure 7

<!-- image -->

Figure 8

## LET'S DO IT

## ACTIVITY 1

- i) Sit down, place your hand on your chest, count the number of breath you take in 1 minute and write it down.
2. ii)  Now jump for 1 minute, then, place your hands on your chest, count the number of breath you take in one minute and write it down.
3. iii) Why do you think there is a change in your breathing rate?

## Effects of exercise on the respiratory system

## Short term effects of exercise

## Long term effects of exercise

Figure 9

In this image, we can see a human body. In the image, we can see the text and the image of a human.

<!-- image -->

Change in lung capacity and volume

More alveoli become active allowing greater volume of air to pass through the lungs

Hypertrophy of alveoli causes an increase in the network of capillaries around them which will allow more gas exchange

Diaphragm and intercostal muscles become stronger

<!-- image -->

## Did you know

1. Once you start exercising your muscles work harder, thus your body needs more oxygen. In order to cope with this extra demand your breathing rate increases from about 15 times per minute (at rest) to about 40-60 times per minute.
2. Smoking reduces the amount of oxygen the blood can carry.
3. Exercise can improve the symptoms of asthma in the long run.

## UNIT 2   |   RESPIRATORY SYSTEM

<!-- image -->

## QUESTIONS

1.   Write down the functions of the respiratory system.
2.   Label the diagram below with the following words.

(Alveoli, Bronchi, Bronchioles, Diaphragm, Lung, Mouth, Nasal Passage, Trachea)

In this image we can see a person's body. We can also see the text and a few lines.

<!-- image -->

3.   Explain the mechanism of breathing.
4.   Why does the breath rate increases when you exercise?
5.   What are the effects of exercise on your respiratory system?

## CIRCULATORY SYSTEM

<!-- image -->

## Learning Objectives

## In this chapter you will learn about the:

- different parts of the circulatory system
- functions of the heart
- short and long-term effects of exercise on the circulatory system

## Circulatory system

The  circulatory  system  is  a  network  of  organs  and  blood vessels  (arteries,  capillaries  and  veins)  that  are  responsible for the flow of blood.

Figure 1

<!-- image -->

## The heart

<!-- image -->

Figure 2

<!-- image -->

Figure 3

The heart is the engine of the body. It is a hollow muscular organ located in the chest cavity between the lungs behind the sternum just above the diaphragm. It pumps blood continuously throughout the body by contracting and relaxing rhythmically.

## UNIT 3

## Components of blood

White blood cells (WBC) are cells that fight against viruses, bacteria and other foreign bodies. WBC protect you from illnesses and diseases.

## Plasma

## Platelets

is a light yellow liquid (when seperated from the rest of the blood) that carries water, salts, waste, nutrients and enzymes.

are sticky cells in nature which are responsible to form clots to stop bleeding.

Red blood cells (RBC) contain haemoglobin (a protein) that carry oxygen. They also remove carbon dioxide.

In this image we can see a picture of a red and white color object.

<!-- image -->

<!-- image -->

Blood Vessels are tubes through which blood circulates. There are three types of blood vessels.

Arteries (red): carries oxygenated blood away from the heart to body tissues.

Veins (blue): carries deoxygenated blood from the body back to the heart.

In this image we can see a diagram of a human body.

<!-- image -->

Capillaries: connect the arteries and veins. They allow oxygen, nutrients, carbon dioxide and waste products to pass to and from the tissue cells.

Figure 4

## Structure of The Heart

## Superior vena cava

is a major vein that carries deoxygenated blood from the head, neck, upper chest and arms to the heart.

## Pulmonary

veins carries rich oxygenated blood from the lungs to the heart.

## Right atrium

receives deoxygenated blood from the inferior and superior vena cava.

Aorta is the main artery that carries oxygen-rich blood away from the heart to the rest of the body.

The image is a diagram of a human heart. It is labeled with various anatomical features and labels. Here is a detailed description of the image:

### Heart Diagram

#### Left Ventricle
- **Left Ventricle**: The topmost part of the heart. It is a large, circular structure with a dome-shaped base.
- **Right Ventricle**: The bottommost part of the heart. It is a smaller, circular structure with a dome-shaped base.
- **Left Ventricle**: The bottommost part of the heart. It is a smaller, circular structure with a dome-shaped base.
- **Right Ventricle**: The bottommost part of the heart. It is a smaller, circular structure with a dome-shaped base.
- **Heart**: The central structure of the heart. It is a large, circular organ with a dome-shaped base.
- **Atria**: The two upper chambers of the heart

<!-- image -->

## Right ventricle

## Inferior vena cava

is a major vein that carries deoxygenated blood from the lower chest and legs to the heart.

receives deoxygenated blood from the right atrium and pumps it to the lungs.

Figure 5

Pulmonary artery carries deoxygenated blood from the heart to the lungs.

Left atrium receives rich oxygenated blood from the lungs to the left ventricle.

## Left ventricle

receives rich oxygenated blood from the left atrium and pumps it to the rest of the body.

## UNIT 3   |   CIRCULATORY SYSTEM

## Blood circulation

## There are three types of blood circulations namely:

In this image there is a diagram of a human body.

<!-- image -->

In this image we can see a red color heart rate monitor.

<!-- image -->

Figure 7

<!-- image -->

## Did you know

1. Your thumb has its own pulse (do not use your thumb to take your pulse).
2. RHR should not be taken after exercise or stressful event.
3. RHR should be checked in the morning before getting out of the bed.

## 1.  Pulmonary circulation (occurs between the heart and lungs)

Deoxygenated blood leaves the right ventricle through the pulmonary artery to the lungs to be  reoxygenated. The  rich  oxygenated  blood enters the left atrium from the lungs through the pulmonary veins.

## 2.  Systemic  circulation  (occurs  between  the heart and body)

Rich oxygenated blood leaves the left ventricle through the aorta to be supplied to the body. Deoxygenated  blood  enters  the  right  atrium though the inferior and superior vena cava.

3.  Coronary  circulation refers  to  the  supply  of blood in the heart.

## The heart rate

Your  heart  rate  is  the  number  of  times  your heart beats in one minute . The resting heart rate (RHR) is the average heart rate of a person at  rest.  Normally,  it  is  72  beats  per  minute (bpm).  The  RHR  determines  your  Physical Fitness level.  While practising an aerobic activity,  your  heart  becomes  stronger  and your RHR decreases.

## LET'S DO IT -  TAKE YOUR PULSE RATE

<!-- image -->

<!-- image -->

<!-- image -->

Figure 8

<!-- image -->

Figure 9

<!-- image -->

## Did you know

The  pulse  rate  is  the  number  of  times  your  heart  beats per minute. It is mostly taken at the wrist (radial) or neck (carotid). You should use your index or middle finger but not your thumb to feel the flutter (beating).

## ACTIVITY 1

- (i)  Record your RHR for 3 consecutive days. Jump for 1 minute, record your pulse and compare it with your RHR.
- (ii) Why do you think there is a change in your pulse?

<!-- image -->

## EXPERIMENTS

## ACTIVITY 1

Design a circulatory system model.

This link can help you in doing the activity.

<!-- image -->

CHECK THIS LINK

https://www.youtube.com/watch?v=VeEQr31A3NU

Figure 10

<!-- image -->

## UNIT 3   |   CIRCULATORY SYSTEM

## Radial pulse:

Press your fingers into the hollow space to  feel  the  radial  artery  as  shown  in figure 8.

## Carotid pulse:

Press  your  fingers  against  the  carotid artery  which  is  located  by  the  side  of windpipe as shown in figure 9.

Once you feel your pulse, start counting it for 60 seconds to measure your bpm. You  can  also  measure  it  for  a  shorter period of time (e.g. 15, 20 or 30 seconds) and multiply by the relevant factor (4, 3 or 2 respectively) to convert to bpm.

The diagram below lists further changes that occur when you exercise.

## Short and long term effects of exercise on the human circulatory system

## Short term effects of exercise

## Long term effects of exercise

Hypertrophy of the cardiac muscles

Improves aerobic fitness

Fast recovery

Resting heart rate decrease

Reduce the risk for stroke, heart attack, kidney failure, loss of vision and hardening of arteries.

Increase heart rate

Increase blood circulation

Increase blood temperature

Increase blood pressure

Figure 11

In this image, we can see a graph.

<!-- image -->

## Blood pressure

Figure 12

In this image we can see a red color object.

<!-- image -->

Blood pressure is a term that you might have  come  across.  It  is  the  amount  of pressure  that  the  blood  exerts  against the wall of the blood vessels.  The normal blood pressure for an adults is 120/80 mmHg.

The  device  used  to  measure  blood pressure is called a sphygmomanometer modernly  known  as  blood  pressure monitor, or blood pressure gauge.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

## UNIT 3   |   CIRCULATORY SYSTEM

Hypertension is  a  hypokinetic  disease (due to lack of physical activities). It is a term used when the blood pressure is  higher  than  normal.  This  means that  the  heart  is  working  harder  to circulate blood to the body. A person with  high  blood  pressure  (HBP)  is expose to higher risk of stroke, heart attack,  kidney  failure,  loss  of  vision and hardening of arteries.

Hypotension is  the term used when the blood pressure is lower than normal. This can be a life- threatening condition.

To maintain fluctuation in your normal blood pressure, you need to practise a physical activity and have a healthy diet daily.

Figure 13

| Blood Pressure Category                    | Systolic mmHg(upper #)   | Diastolic mmHg(lower #)   |
|--------------------------------------------|--------------------------|---------------------------|
| Normal                                     | less than 120            | and less than 80          |
| Prehypertension                            | 120 - 139                | or 80 - 89                |
| High Blood Pressure (Hypertension) Stage 1 | 140 - 159                | or 90 - 99                |
| High Blood Pressure (Hypertension) Stage 2 | 160 or higher            | or 100 or higher          |
| Hypertensive Crisis (Emergencycareneeded)  | Higher than 180          | or Higher than 110        |

## Did you know

<!-- image -->

1. The  heart  has  a  network of  vessels  of  97,000  km long  and  beats  100,  000 times per day.
2. Red and white blood cells are produced in the bone marrow. The RBC lives for about  120  days  whereas WBC, lives for 1-3 days.

<!-- image -->

## EXERCISES

1. Match the following:

## COMPONENTS OF BLOOD

1.  White blood cells
2.  Platelets
3.  Red blood cells
4.  Hypertension
5.  Resting Heart Rate (RHR)
6.  Heart

## FUNCTION

- A.  Carry oxygen and nutrients to different body parts
- B.  Protect your body from bacteria and infections
- C.  Help in blood clotting
- D.  Responsible to pump blood continuously throughout the body
- E.  Blood pressure is higher than normal
- F.  Average heart rate of a person at rest
2. Label the parts of the heart.

(Left ventricle, Right atrium, Pulmonary artery, Right ventricle, Left atrium, Aortra)

Figure 14

In this image, we can see a diagram of a heart.

<!-- image -->

3. Explain the pulmonary circulation.
4. If  you  exercise  daily,  what  are  the  changes  that  your  circulatory  system  will undergo?

## GOOD BODY MECHANICS

<!-- image -->

## Learning Objectives

## In this chapter you will learn about the:

- good body mechanics of walking and running
- effects of good body mechanics on sports performance

## Introduction

Body mechanics refer to the way we move while doing daily activities. Good body mechanics prevent injury, muscle fatigue and pain. This includes how we position our body while doing basic movements or sports activities. Body mechanics involve the way the muscles, skeleton, and  the  nervous  system  coordinate  to  ensure  that  the  right  balance,  posture,  and  body alignment are maintained.

Poor or improper posture can cause the spine to be subjected to stress with time which can result in wear and tear. For these reasons, it is essential that we learn about the principles and guidelines that govern proper body mechanics in daily life activities.

## Good body mechanism of walking

In this image, we can see a diagram.

<!-- image -->

## UNIT 4

Figure 2

In this image, we can see a group of people.

<!-- image -->

Figure 3

In this image, we can see a person standing and holding a stick.

<!-- image -->

## Good body mechanism of running

Keep the shoulders level, low and loose

Staying relaxed is key

Unclench your fists

Your arms should swing forward and back, not across your body

Keep elbows at a 90 o angle

The foot maintains a dorsiflexed position except when the foot makes contact with the ground

The drive leg (Plantar flexion) is fully extended while the recovery leg is shortened as it passes by the knee

Figure 4

In this image we can see a person running.

<!-- image -->

## The effects of good body mechanics :

- improves sport performance.
- help in understanding the limitation of the body movement.
- increase self confidence in sportsperson.
- prevent sports injuries.
- prevent postural deformities.
- help in research work to improve training techniques.

Figure 5

<!-- image -->

## UNIT 4   |   GOOD BODY MECHANICS

Look forward, not at your feet

Straighten your neck and back, and bring your body into alignment

Push off with maximum force

Land lightly

Your foot should touch down between your heel and midfoot, then quickly roll forward

<!-- image -->

## Did you know

Walking,  jogging  and  running follow the same principles of body mechanism. The difference between walking and running is that when you walk,  you  always  have  one  or both  feet  in  contact  with  the ground  during  the  gait  cycle, whereas  in  running  both  feet are off the ground in the flight phase and you never have both feet in contact with the ground at the same time.

<!-- image -->

## EXERCISES

1. Identify the difference in the foot movement while walking and running?
2. Explain the following terms in your own words:
- a)  flexion
- b)  extension
- c)  dorsiflexion

## 3. Observe the picture below:

- a) identify the person who has the appropriate running mechanism.
- b) explain why?

Figure 6

<!-- image -->

## 4. Write True or False.

- a) Good body mechanics fatigue your muscles.
- b) Improper posture stresses your spin.
- c) The heel strikes the ground first when you walk.
- d) Good body mechanics increase your sports performance.
- e) Clench your fists when you run.
5. How does good body mechanism affect your sports performance?

## HEALTH, DIET AND FITNESS

<!-- image -->

## Learning Objectives

## In this chapter you will learn how to:

- relate your food intake with your physical activity level
- calculate your caloric intake, body fat and training zone
- design a balanced diet and workout plan

## Introduction

Your health reflects the overall condition of your body. To stay in good health you should eat a balanced diet daily, exercise at least 45 minutes three times per week, cope with stress and be able to interact with others.

## Healthy eating helps you to:

- maintain an ideal  weight.
- avoid  certain  health  problems  (obesity,  heart  diseases, diabetes and hypertension).
- sharpen your mind (better concentration, retention ability and reaction time).

## Food intake and Physical activities

Whatever you eat or drink is converted into energy in your body (energy in). This energy is being used up when you are engaged in any activity (energy out) or excess is being stored in the body. To be healthy, you should have a balance between energy in and energy out.

<!-- image -->

## UNIT 5

## Did you know

The World Health Organisation (WHO) defines health as a 'state of complete physical, mental  and  social  well-being, and not merely the absence of disease or infirmity' .

Figure 1 shows three examples of how energy in and out can affect your health.

Example 1

Example 2

Example 3

<!-- image -->

When your energy in is greater than your energy out, it leads to weight gain (overweight and obesity) and other health problems.

<!-- image -->

<!-- image -->

When your energy in is equal to your energy out, it leads to ideal weight and good health.

<!-- image -->

<!-- image -->

When your energy in is less than your energy out, it leads to fatigue, weight loss, muscle atrophy (muscles loss), and other health problems.

Figure 1

<!-- image -->

It  is  advisable  to  follow  the  2 nd example  to  enjoy  a  good  health.  You  should  balance  the kilocalories consumed (through eating and drinking) and kilocalories burnt through physical activities.

## Balance Diet

## Did you know

<!-- image -->

A  balance  diet  consists  of  carbohydrates,  fats,  protein, vitamins,  minerals  and  water  at  a  proportional  amount. It helps to:

- strengthen the learning abilities and well-being.
- prevent/reduce  non-communicable  diseases  such as  cancer,  hypotension  or  hypertension,  obesity, diabetes, etc.
- promote a healthy lifestyle.
1. You  should  reduce/  cut  salt, sugar and saturated fat intake in your meals.
2. Healthy snack comprises of fruits, dairy products, fresh fruit juice, nuts, light sandwich and eatable raw vegetables (carrots,  cucumber,  tomatoes, beetroot, etc.)
3. You should avoid polished, processed and preserved food.

## UNIT 5   |   HEALTH, DIET AND FITNESS

## Components and Sources of a Balance Diet

To stay healthy, your diet should comprise each of the following components:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Components    | Functions                                                                    | Sources                                                                         | Amount of energy yield/g   | Estimated quantity%to be taken / day   |
|---------------|------------------------------------------------------------------------------|---------------------------------------------------------------------------------|----------------------------|----------------------------------------|
| Carbohydrates |                                                                              |                                                                                 |                            |                                        |
|               | It is a main source of immediate energy to the body and brain.               | Bread, pasta, noodles, rice, cassava, sweet potatoes, bread fruit, etc.         | 4 KCal                     | 45-65%                                 |
| Proteins      |                                                                              |                                                                                 |                            |                                        |
|               | It helps in growth, reparation and restoring of cells.                       | Fish, meat, egg white, dairy products, etc.                                     | 4 KCal                     | 10-35%                                 |
| Fats          |                                                                              |                                                                                 |                            |                                        |
|               | It is a source of energy and maintains body temperature.                     | Nuts, seeds, avocados, oil, butter, meat, and home- made sausages, burger, etc. | 9 KCal                     | 20-35%                                 |
| Vitamins      |                                                                              |                                                                                 |                            |                                        |
|               | It boosts the immune system and helps in the proper functioning of the body. | Carrots, green vegetables, fruits, nuts and seeds, etc.                         | -                          | * see note below                       |

<!-- image -->

<!-- image -->

<!-- image -->

| Minerals   | Essential for the body to grow, develop and stay healthy.                                                         | Banana, seafood, onion, garlics, peas, green leafy vegetables, yogurt, milk, grapes, liver, etc.     | -   | * see note below   |
|------------|-------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|-----|--------------------|
| Fibers     | Prevent constipation, reduce the risk of coronary heart diseasesandhelpin maintaining normal blood glucose level. | Whole grains, vegetables, fruits, etc.                                                               | -   | * see note below   |
| Water      | Helps to regulate the body temperature and to maintain other body functions.                                      | Chayote (Chouchou), mushroom, water, fresh juice, coconut water, watermelon, cucumber, lettuce, etc. | -   | At least 2 litres  |

NOTE : Your energy requirement differs according to your age, gender and physical activity level.

*The Recommended Daily Allowances (RDAs) is normally available in a balanced diet.

## Diet Plan

To  be  able  to  plan  your  diet  correctly,  you  need to adopt the right nutritional behaviour, that is, manage the proportion and size of  your  food  intake. It  is  recommended to have smaller portion of meal at regular intervals. You may take 5-6 meals per day.

<!-- image -->

## Did you know

Energy requirement is 'the amount of food energy needed to balance energy expenditure in order to maintain body size, body composition and a level of necessary and desirable physical activity, consistent with long-term good health' .

## UNIT 5   |   HEALTH, DIET AND FITNESS

## The following steps will be useful to you for planning a healthy balance diet.

Step 1: Calculate the amount of Kilocalories you need to consume per day.

<!-- image -->

## Step 2: Calculate the amount of calories you need per meal.

For example: if you have to consume 2200 kilocalories per day, it will make 440 kilocalories per meal.

<!-- image -->

## Step 3: Choose the appropriate time for your meals.

Select five slots and try to follow it as far as possible.

For example:

In this image there is a chart.

<!-- image -->

## Step 4: Calculate the % of kilocalories that you will take from each food component for a meal.

For example:

| Food Components                | Carbohydrates                           | Proteins                               | Fats                                    |
|--------------------------------|-----------------------------------------|----------------------------------------|-----------------------------------------|
| %recommended into Kilocalories | 60% * 440 =264Kcal (estimated quantity) | (estimated quantity) 15% * 440 =66Kcal | (estimated quantity) 25% * 440 =110Kcal |

## Step 5: Convert the amount of kilocalories into grams.

For example:

| Conversion Table        | Conversion Table                        | Conversion Table                       | Conversion Table                        |
|-------------------------|-----------------------------------------|----------------------------------------|-----------------------------------------|
| Food Components         | Carbohydrates                           | Proteins                               | Fats                                    |
| Kilocalories into grams | (amount of energy yield) 264 Kcal/4=66g | 66 Kcal/4=17g (amount of energy yield) | 110 Kcal/9=12g (amount of energy yield) |

## Step 6: Set your goal.

To lose, gain or maintain a healthy weight, your goal should be realistic and achievable.

| Goals to be healthy         | Action to be taken                              |
|-----------------------------|-------------------------------------------------|
| To lose &reduce weight      | Decrease your consumption by 500 KCal per week. |
| To build &gain weight       | Increase your consumption by 500 KCal per week. |
| To maintain &improve weight | Maintain a healthy diet.                        |

## Step 7: Plan your diet.

Choose quality diet over quantity diet. Below is an example of 1 day diet plan.

<!-- image -->

| Water   | Num of glasses   | Breakfast                                                    | Num of calories        | Snack                                        | Num of calories   | Lunch                                                  | Num of calories    | Dinner                                    | Num of calories   |
|---------|------------------|--------------------------------------------------------------|------------------------|----------------------------------------------|-------------------|--------------------------------------------------------|--------------------|-------------------------------------------|-------------------|
|         | 8 8              | Bread, 4 slices Butter Cheddar Cheese 1 cup of milk 1 banana | 280 51 106 150 105 692 | 1 Pear Tomato soup 1 slice of bread 1 Yogurt | 98 74 70 140 382  | 1/2 cup brown rice Lentils MixedVegetables Grapes (10) | 350 139 118 36 643 | Macaroni Tuna Salad (1 cup) 1 fruit juice | 335 136 471       |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

NOTE: You can have 2 healthy snack time per day.

## LET'S DO IT

Plan your diet for a week and for that you need to:

- (i) choose your diet goal.
- (ii) calculate your calorie intake per meal.
- (iii) select healthy food to incorporate in your diet.

Use the weekly diet journal (page 122 - 123) for your planning.

The food calorie chart given in the appendix (page 119 - 120) might be of help to you.

## Food Label

## Nutritional facts

Servings Size 1 cup (220g) Servings per container 2

Amount Per Serving

Calories 250    Calories from fat 110

## % Daily Value

Total Fat 12 g

Saturated Fat 3G

Trans Fat 3g

Cholesterol 30mg

Sodium 470mg

Total Carbohydrate 31g

18%

15%

10%

20%

10%

Dietary Fibre 0g Sugars 6g Protein 5g

0%

Vitamin A

4%

Vitamin C

2%

Calcium

20%

Iron

4%

*Percentage Daily Values are based on a 2000 calorie diet. Your Daily Value may be higher or lower according to your calorie needs.

|                    | Calories   | 2000   | 2500   |
|--------------------|------------|--------|--------|
| Total Fat          | Less than  | 65g    | 80g    |
| Sat Fat            | Less than  | 20g    | 25g    |
| Cholesterol        | Less than  | 300mg  | 300mg  |
| Sodium             | Less than  | 2400mg | 2400mg |
| Total Carbohydrate |            | 300g   | 375g   |
| Fibre              |            | 20g    | 30g    |

Indicates the serving

Limit these nutrients as they may increase your risk of certain chronic diseases like heart diseases, some cancers or high blood pressure

Indicates the amount of calories

Have greater amount of these nutrients

Information on the serving based on the calories

## Workout plan

Along with your diet, you should take care of your Physical Fitness to stay in good health.

The following steps will help you to know your physical fitness level so as to be able to design your work out plan according to your abilities and goals.

## STEP 1: Calculate your BMI and Hip waist ratio

<!-- image -->

a) Body Mass Index (BMI): weight (kg) ÷ height (m)2

In this image, we can see a graph. On the graph, we can see the numbers.

<!-- image -->

b) Waist hip ratio:  waist ÷  hip

<!-- image -->

## Waist-to-Hip Ratio (WHR) Norms

Figure 2

| Gender   | Excellent   | Good      | Average   | At Risk   |
|----------|-------------|-----------|-----------|-----------|
| Males    | <0.85       | 0.85-0.89 | 0.90-0.95 | ≥0.95     |
| Females  | <0.75       | 0.75-0.79 | 0.80-0.86 | ≥0.86     |

STEP 2: Record your resting heart rate for 1 minute (Refer to chapter circulatory system)

Figure 3

In this image, we can see a person is doing a exercise. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump. We can also see a person is doing a jump

<!-- image -->

<!-- image -->

## STEP 4:

## Calculate your heart training zone

| TARGET ZONE %MHR HARD 70% &above   | 2 - 10 MIN DURATION   |
|------------------------------------|-----------------------|
| MODERATE 60 - 70%                  | 10 - 40 MIN           |
| LIGHT 50 - 60%                     | 40 - 80 MIN           |
| VERY LIGHT 30 - 50%                | 20 - 40 MIN           |
| VERYVERY LIGHT 10 - 30%            | 10 - 30 MIN           |

<!-- image -->

## STEP 5:

Set your goal: Strength, aerobic. fitness, fat burn, weight management.

## FITNESS GOAL

| Increase maximum performance capacity- suitable for everyone during short exercises                         | Strength          |
|-------------------------------------------------------------------------------------------------------------|-------------------|
| Improves aerobic fitness during moderately long exercises                                                   | Aerobic fitness   |
| Basic endurance and fat burning - suitable for everyone during short to moderately long exercises           | Fat burn          |
| Simple exercise for weight management and recovery Simple exercise for weight management and rehabilitation | Weight management |

For  example,  if  you  are  13  years old  with  a  resting  heart  rate  of 72 Beats/Minute (bpm), and your goal  is  to  burn  fat.  You  have  to calculate your:

- a)  Maximum Heart Rate (220 - your age)

220 - 13 (Age) = 207 bpm.

- b) Maximum training zone {  (Max  HR  -  resting  HR) × (higher %  of training intensity)) + resting HR}

207 - 72 (RHR) = 135 135 x 70% (Max. Intensity) + 72 (RHR) = 167 bpm

- c)  Minimum training zone {  (Max  HR  -  resting  HR) × (lower % of training intensity)) + resting HR}

207 - 72 (RHR) = 135 135 x 60% (Min. Intensity) + 72 (RHR) = 153 bpm

Your training heart rate zone will therefore be 153  - 167 bpm

## F.I.T.T PRINCIPLE

Based on the data you have collected from the fitness assessments, you are now able to identify your strengths and weaknesses.

It  is  important  to  understand and apply the 'F.I.T.T.' principle to 'dose' your workout before designing your workout plan.

Figure 4

In this image, we can see a diagram with some text and images.

<!-- image -->

## Did you know

<!-- image -->

There are two more principles that you need to know:

1.  Principle of Overload: The load or amount of exercise you are performing should not put greater stress on the body.
2.  Principle  of  Progression:  Workload  should  be  gradual and continuous. Too quick progression can lead to injury or  unnecessary  fatigue  or  both  and  can  discourage  or prevent you from achieving your fitness goal.
1. You  can  also  use  these  fitness tests for your parents.
2. You  can  compare  your  fitness test  with  other  friends  of  the same age and gender.
3. These tests will motivate you to lead a more active lifestyle.
4. You need to perform these fitness tests at regular intervals to evaluate your progress.

## UNIT 5   |   HEALTH, DIET AND FITNESS

According  to  the  'F.I.T.T'  principle,  here  is  an  example  of  a  workout  for  an  adolescent  of 13 years old.

| FREQUENCY             | 4 times per week                                    | Sunday, Tuesday, Thursday, Saturday                                                                                                                                                 | You can also exercise on all seven days in a week.   |
|-----------------------|-----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------|
| 60 - 70% (vigorous)   | 153 - 167Bpm                                        | You have to take your pulse rate just after the exercise to be sure you are in your heart training zone.                                                                            | INTENSITY                                            |
| Aerobic and anaerobic | Swimming, running, squat, sit up, push up, etc.     | walking, Aerobic exercises (cardio/ endurance) need to be much more than anaerobic exercises (strength/speed).                                                                      | TYPE                                                 |
| 40-45 mins            | 20 mins x 2 times per day 15 mins x 3 times per day | You can plan your exercise time in one go continuously or you can break it down according time availability but at the end of the day you should have completed your 40 or 45 mins. | TIME                                                 |

<!-- image -->

## Did you know

1. Physical Activities help you to:
- improve your health by reducing the risk of hypokinetic diseases (coronary heart disease, hypertension, obesity)
- do better in school
- improve your fitness
- grow stronger
- have fun playing with friends
- feel happier
- maintain a healthy body weight
- improve your self-confidence
- learn new skills.
2. Static  streching  is  holding  a  stretch  for  5-10  seconds. It  is  generally done before any pulse raiser activity and is recommended for general fitness.
3. Dynamic stretching is a stretch which is performed while  moving,  done  in  repetition  and  is  more  successful among  athletes,  coaches,  trainers  and  physical  therapist (not ballistic stretching).

This is an example of a weekly workout plan.

| DAY/ DURATION                   | Mon   | Tues                                                                                            | Wed   | Thurs                                                       | Fri     | Sat                                                         | Sun                                                                    |
|---------------------------------|-------|-------------------------------------------------------------------------------------------------|-------|-------------------------------------------------------------|---------|-------------------------------------------------------------|------------------------------------------------------------------------|
| 5 mins Warmup 20 mins Endurance | E S T | Static stretching, walk, jog, run Dynamic stretching 10 mins Brisk walk 10 mins bicycle/ Zumba/ | S T   | Static stretching, walk, jog, run Dynamic stretching        | R E S T | Static stretching, walk, jog, run Dynamic stretching        | Static stretching, walk, jog, run Dynamic stretching                   |
| (Cardio)                        | E S T | dance/ games/ hiking                                                                            | S T   | 10 mins run 10 mins Zumba                                   | R E S T | 10 mins bicycle 10 football or other games                  | 35 mins Trail/ climbing/ mountain- eering/ beach games, swimming, etc. |
| 15 mins Strength                | R     | Circuit training (with without weight)                                                          | R     | Circuit training (with without weight)                      | R E S T | Circuit training (with without weight)                      | 35 mins Trail/ climbing/ mountain- eering/ beach games, swimming, etc. |
| 5 mins Cooldown                 | R     | Run, Jog, Walk, Stretching (Flexibility exercises and yoga)                                     | R     | Run, Jog, Walk, Stretching (Flexibility exercises and yoga) | R E S T | Run, Jog, Walk, Stretching (Flexibility exercises and yoga) | Run, Jog, Walk, Stretching (Flexibility exercises and yoga)            |

## LET'S DO IT

## 1.  Design you own workout plan:

- (i) choose your fitness goal.
- (ii) calculate your heart training zone.
- (iii)  select the exercises that you want to do.
- (iv)  record it in the weekly exercise log on page 122 - 123.
- (v) implement it for a period of 12 weeks.
- (vi)  write down the changes you have noticed.

## CIRCUIT TRAINING

<!-- image -->

## Learning Outcomes

## By the end of this lesson you will learn about:

- the concepts and benefits of circuit training
- using body weight and small equipment
- different types of circuit training

'Circuit training is one of the best methods of exercising as it provides excellent all round fitness, tone, strength, and a reduction of weight. In short, maximum results in minimum time.'

A circuit training workout includes around 8 exercise stations. After completing a station, you move to the next station in a rotational way.

## Principles to be followed while designing a circuit training:

- The  stations  in  a  circuit  training  may include  the  following  components  of fitness:  strength,  endurance,  stamina, flexibility, coordination, speed and muscle tone.
- Change  muscle  groups  between  each station to delay fatigue.
- Make  use  of  your  body  weight,  free weights,  elastic  bands,  benches,  jump boxes, etc.
- Perform  each  exercise  for a specific number  of  repetitions  or  a  set  time (30 seconds to 3 minutes) before moving on to the next exercise.
- Moving  from  one  station  to  the  next (recovery time) is often short and rapid.

Figure 1

In this image, we can see a group of people. We can also see some text.

<!-- image -->

## UNIT 6

- When one circuit is completed, it is referred to as a set. You can carry out 3-5 sets depending on your fitness level.
- You can increase the load by:
1.   Increasing the time spent on each exercise.
2.   Trying to do more repetitions in the time limit.
3.   Doing the circuit more time.
4.   Decreasing the recovery time between stations.

<!-- image -->

## Advantages of circuit training:

## Disadvantages of circuit training:

- The variety of exercises prevents boredom.
- Any kind of exercises can be included.
- It is easy to measure progress.
- Circuits  can  be  organised  for  indoor or outdoor use.
- Can  be  adjusted  to  suit  age,  fitness and health of the athlete.
- Increase bone density.
- Exercises are simple enough to make you  feel  a  sense  of  achievement  in completing them.
- A large number of choices of exercises which maintain enthusiasm.
- Appropriate form of training for most sports.

You can design your circuit training program targeting the major muscles of the body as shown in the figure 2.

The  Upper  body  muscles include all the muscles that cover the upper surface from head till hip.

The lower muscles include all  the  muscles  that  cover the lower surface from hips to toes.

In this image, we can see a human body. We can also see some text.

<!-- image -->

- Many  exercises require specialised equipment, e.g. gym equipment
- Ample space is required to set up the circuit exercises and equipment.
- Use of additional equipment requires appropriate health and safety monitoring.
- In  general,  it  can  only  be  conducted where appropriate facilities/equipment are available.

## SWISS BALL CIRCUIT TRAINING

1. Swiss ball back stretch

In this image, we can see a group of people. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a ball. We can also see a person holding a

<!-- image -->

Figure 3

Swiss ball exercises help to improve balance, flexibility and strengthen your body. It has many advantages compared to other fitness programme. However, you should be very careful so as not to injure yourself.

## Circuit training using chair/ benches/ wooden box

Figure 4

In this image, we can see a group of people. We can also see a person sitting on a chair. We can also see a person standing. We can also see a person standing on the ground. We can also see a person lying on the ground. We can also see a person standing on the ground. We can also see a person sitting on the ground. We can also see a person standing on the ground. We can also see a person lying on the ground. We can also see a person standing on the ground. We can also see a person sitting on the ground. We can also see a person standing on the ground. We can also see a person lying on the ground. We can also see a person standing on the ground. We can also see a person sitting on the ground. We can also see a person standing on the ground. We can also see a person lying on the ground. We can also see a person standing on the ground. We can also see

<!-- image -->

Chair, benches, wooden box exercises can be done anywhere. They are easy and yield the same benefits as any other exercises.

<!-- image -->

<!-- image -->

<!-- image -->

1

4

6

## Circuit training without equipment

## 1. Superman exercise

Figure 5

In this image, we can see a group of people. There are some pictures of them. We can see the text on the image.

<!-- image -->

In body weight exercises, the body is used as resistance.

These types of exercises are convenient and effective as they can be:

- modified according to your level of ability
- done regularly and anywhere

<!-- image -->

<!-- image -->

6

<!-- image -->

7

Figure 6

In this image, we can see a group of people. There are two women and a man. They are doing exercises. There is a board with text on it.

<!-- image -->

Flexibility exercises are important to lengthen and stretch the joints and muscles to prevent injuries. This type of circuit help to improve posture, balance, strength and mobility around joints. It also relaxes the state of mind and the body feels better.

## FOOTBALL

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about:

- shooting
- goalkeeping
- tackling
- team formations
- playing a football game

## Travelling with the ball

Running with the ball under control is known as dribbling. In its basic form, the skill involves you kicking the ball ahead of yourself, running to catch up with it, kicking it forward again and so on. It is, therefore, a fundamental technique used to keep possession of the ball. It enables you to run with the ball, past opponents and to travel with the ball at speed when moving in an open space.

In this image we can see a person wearing a yellow shirt and black shorts is holding a ball.

<!-- image -->

Using  either  your  right  or  left  foot, gently  kick  the  ball  betweeen  30-50 centimetres  ahead  of  you  while  you move forward.

In this image, we can see a person wearing a yellow color shirt and shorts is playing football.

<!-- image -->

In this image I can see a person wearing yellow t-shirt, shorts and socks. I can see a ball and a foot.

<!-- image -->

Keep your eyes on the ball while running  forward,  occasionally  looking up to assess the situation ahead of you.

Figure 1

When you reach the ball, continue with the  dribble  using  either  left  or  right foot.

## UNIT 7

## LET'S DO IT

## ACTIVITY 1

## One on one dribbling

Figure 2

In this image we can see two boys are playing soccer. The boy on the left is wearing blue t-shirt and blue shorts. The boy on the right is wearing blue t-shirt and black shorts. The grass is green in color.

<!-- image -->

Figure 3

In this image we can see two players are playing a game. The players are wearing the blue and red color shorts and the blue color socks. The ground is covered with the grass. In the background there are trees.

<!-- image -->

## Shooting

Shooting is one of the most exciting part of football where players strike the ball in between the goalpost to score a goal. However, the most proper technique is to strike the ball with the laces part of your shoes.

## The Volley

The volley (air borne strike), is a shooting technique whereby the player strikes the ball with his foot when it is still in the air. This technique, can also be used to make rapid crosses, clearances and passes.

## Preparation

- Flex your knees slightly.
- Lean your upper body slightly forward to maintain balance .
- Keep the ball close to your foot.
- Keep an eye on the opponent.

## Execution

- Dribble  towards  the  defender  at speed.
- Use body feints and deceptive foot movements to beat your opponent (refer to Grade 7) .

## Follow-through

- Maintain  close  control  of  the  ball and move away with speed.

## Volleying styles

There are 3 basic types of volley in football namely:

- i) Full volley
2. ii)  Half volley
3. iii) Side volley.

However, there is an advanced technique known as the bicycle or overhead kick.

## Full volley

You perform a full volley when the ball travels towards you without bouncing off the ground. A full volley requires good timing, concentration and composure (body position, momentum, coordination and aesthetic).

Figure 4

In this image, we can see a person wearing red shirt and blue shorts. We can also see a ball.

<!-- image -->

Figure 5

In this image we can see a person standing on the ground and holding a ball. We can also see a person's legs and a person's foot. We can also see a person's hand and a person's hand. We can also see a person's leg and a person's foot. We can also see a person's hand and a person's hand. We can also see a person's leg and a person's foot. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We can also see a person's hand and a person's hand. We

<!-- image -->

## Preparation

- Move quickly to the location of the incoming ball.
- Place your non kicking foot slightly forward.
- Shift  your  body  weight  on  it  and maintain balance.
- Draw  the  kicking  leg  back  with foot extended.

## Execution

- Position yourself in the direction of the incoming ball to make a good contact.
- Extend  the  kicking  leg  forward and  snap  (powerful  movement) the centre of the ball with the full instep.
- The body faces in the direction of the outgoing ball.
- Always keep your eyes on the ball.

## Follow-through

- Kicking foot follow through in direction of kick.

## Half volley

The half volley is also an air borne strike which is performed when the player strikes the ball just after it bounces off the ground.

Figure 6

In this image we can see a person standing on the ground. In the background there is a grass.

<!-- image -->

NOTE: Keep  your  kicking  foot  firm  and  pointing  down throughout the contact with the ball.

<!-- image -->

## Preparation

- Move  in  line  with  the  incoming ball.
- Flex  both  knees  slightly  with  the torso  in  an  upright  position  to maintain body balance.
- Watch the ball  closely  as  it  drops towards you.

## Execution

- Position yourself  and  pull  back your striking leg just before making contact with the ball.
- As the ball bounces off the ground, extend  the  kicking  leg  forward and  snap  (powerful  movement) the centre of the ball with the full instep.
- The body faces the direction of the outgoing ball.
- Always keep your eyes on the ball.

## Follow-through

- Kicking foot follow through in direction of kick.

<!-- image -->

## Side volley

The Side-volley can be performed for both an airborne ball, just before or after it bounces off the ground.

Figure 7

In this image we can see a person wearing a green shirt and blue shorts is playing with a ball.

<!-- image -->

Starting  with  your  knee,  bring  your  leg  toward  the  ball  and turn your hips

Strike the ball slightly above the centre to keep it down

Figure 8

In this image we can see a person is playing a game. In the background there is grass.

<!-- image -->

Follow through with your kicking leg parallel to the ground and rotate your hips through the impact

In this image we can see a person is standing on the ground. In the background there are trees.

<!-- image -->

## Preparation

- Move  in  line  with  the  incoming ball.
- Flex both knees slightly with the torso  in  an  upright  position  to maintain Body balance.
- Watch the ball closely as it drops toward you.

## Execution

- Position  yourself  in-line  with  the flight of the ball to make a good contact.
- Keep shoulders and hips perpendicular to the target.
- Snap the kicking leg straight and contact the center of the ball with full instep.
- Keep  your  eyes  on  the  ball  and your  kicking  foot  firm  pointing down throughout the contact.

## Follow-through

- Kicking foot follow through in the direction of the ball.

## LET'S DO IT

## ACTIVITY 1 (In pairs)

## Full volley

- Stand approximately 5 metres from your friend as shown in diagram 10.
- With  his/her  hands  your  friend  feeds  you (red  player)  with  the  ball.  You  can  use  any of  your  foot  to  volley  the  ball  back  to  your friend's hands.
- Swap after 10 repetitions each.

## ACTIVITY 2

## Half volley

- Repeat  the  drill  above  but  this  time  you  need  to  strike  the  ball  just  as  it  bounces  off the ground.

## ACTIVITY 3

## Side volley

Repeat the drill above but this time you need to  stand  square  to  your  friend  (not  facing him) and strike the ball:

- just as it bounces off the ground.
- directly in the air.

## Goalkeeping

## Grounding

When you catch a ball but have no chance of staying on your feet, you need to ground the ball as soon as possible to bring it under control and keep from spilling it into the path of incoming attackers.

<!-- image -->

Dive  with  your  hands  in  the 'W'  position Figure 11

<!-- image -->

<!-- image -->

watching the ball closely as it approaches.

Figure 12

As  you  hit  the  ground,  land  on  one  knee with the other leg outstretched. Catch the ball slightly above its centre.

Figure 13

Bring the ball firmly down to the ground, holding it tightly, with the hands still in the 'W' position.

## Aim: To have a good control and touch

Figure 10

In this image, we can see a person standing on the ground. We can also see a person wearing a yellow and blue color dress. We can see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a person wearing a yellow and blue color dress and a person wearing a yellow and blue color dress. We can also see a

<!-- image -->

## Challenge

Increase  the  distance  between  you and your friend to approximately 10  metres  and  try  to  volley  back  the ball to him.

## LET'S DO IT

## Practice 'grounding' with your friend

Figure 14

In this image we can see a football ground with a goal post. There are few people standing on the ground.

<!-- image -->

## Tackling

## Slide tackle

This technique is used only when there are no alternatives. This is because the player doing the tackle always end up on the ground and invariably out of the game.

In this image we can see a person standing on the ground and holding a ball. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a blue t-shirt and a cap. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing a cap and a blue t-shirt. We can also see a person wearing

<!-- image -->

Figure 15

In this image we can see a person standing on the ground. In the background there is a grass.

<!-- image -->

## The'hook'tackle

This is a variation of the slide tackle in which  you  'hook'  your  foot  around the ball. This technique is typically used to dispossess an opponent when approaching from behind.

Figure 16

Angle your approach from one side and as you get nearer to your opponent, slide on your side past him or her

Contact the ball with the instep of the upper foot and hook the ball from your opponent without contacting him or her

After executing the tackle, get back quickly on your feet and initiate a counter attack

Snap your blocking foot (upper) foot on a slightly downward plane with ankle locked

Figure 17

- Position yourself in between the goalposts.
- Your  friend  will  be  placed  around  5-6  metres  away from you with 5-6 balls as shown in figure 14.
- He  alternatively  throws  the  ball  to  your  left  and right side.
- You need to catch the ball as it comes in the air and ground it as quickly as possible.

## LET'S DO IT

## Mark an area 10 x 10 metres and with your friend practice:

- (i)  slide tackle.
- (ii) hook tackle.

Switch roles after 5 minutes.

Figure 18

In this image, we can see two persons are standing on the ground. We can also see the ground and the sky. We can also see the text.

<!-- image -->

## Players and their positions

Each football team has 11 players and among these players, 1 is a goalkeeper. In both the offensive or defensive team, the player's responsibility is to score a goal for the team and stop the opposing team from scoring a goal. Figure 19 shows various positions of the players on a football field. A list of player positions and their responsibilities is also provided.

- Center Forward :  The  most  tactful,  dangerous  and strong  positions  of  the  game.  They  are  also  called strikers and basically the leading goal scorers in the game.
- Midfielders : They are the link between the defenders  and  attackers.  Position  which  requires maximum  of  endurance.  Their  responsibility  is  to enter  the  opposing  team's  area  and  defend  their team when the opposing team retains the ball.
- Defenders : The defenders are positioned in front of the goalkeeper and their aim is to stop the opposing team from entering into their goal area.
- Outside  fullback :  They  play  on  the  left  and  right flanks. They rarely move from their positions.
- Central  Defenders :  They  are  positioned  in  the center  of  the  field  and  are  supposed  to  cover  the leading goal scorer of the opponent's team.
- Goalkeeper :  The  main  aim  of  a  goalkeeper  is  to stop  the  opposing  team  from  scoring  a  goal.  The goalkeeper  is  restricted  to  the  rectangular  penalty area which is 18 yards away from the goal and he is the only player in the game who is allowed to use his hands to stop the ball.

Figure 19

In this image we can see a football ground. There are two players. One is on the left side and the other is on the right side.

<!-- image -->

<!-- image -->

## 1.  Identify  the  different  formations  that  your  favourite  team  adopt  and  in  which situation?

## Formations

The  formation  of  a  team  is  determined  by  the  positions  allocated  to  players  and  their relationship with each other.

Coaches select formations with two main goals to:

- neutralize the opposition.
- exploit its weaknesses.

Formations are  listed  in  numbers,  with  the  defenders  listed  first  and  the  strikers  listed  last (goalkeepers are never listed).

## 4-4-2

## 3-5-2/5-3-2

The  basic  modern  formation, the 4-4-2, places a burden on midfielders: one of the central pair  must go up and support attacks, while the other drops back. Wide players help out in defense  and  attack,  creating a  temporary  4-2-4.  The  two strikers work in tandem and  need  to have a  good understanding of each other.

Hardworking wingbacks give this formation width

Wide players provide cover in defense and extra options in attack

In this image we can see a football ground. There are some red color circles on the football ground.

<!-- image -->

## 4-5-1

This is essentially a defensive formation, with a packed midfield  and  a  lone  striker left  to  fend  for  himself,  or hold the ball up, until support arrives, usually from the wide  players. English  team Chelsea  used  this  system  to great  effect  during  its  backto-back Premier Leagure title successes in 2005 and 2006.

A back of four defenders provides the necessary cover in defense

A single striker receives and holds up the ball

<!-- image -->

Wide men join the striker in attack

The difference between 3-5-2 and 5-3-2 is one of emphasis, with the former being more attack-oriented than the  latter  since  it  has  more midfielders. In either variant, the  key  men  are  the  wide players,  usually  described  as wingers, who are expected to help out with both attack and defense.

Three midfielders on defense Three central defenders, one of whom drops back

## 4-3-3

Essentially  a  more  defensive version of the 4-2-4, the 4-3-3  was  first  pioneered  by Brazil at the 1962 World Cup. The  three  midfielders  could be staggered in various ways and  tended  to  move  across the field as a unit. Few teams now  start  with  this  system, but  many  adopt  it  late  on ina  match  if  they're  chasing a game.

In attack, two midfielders push forward with one dropping back to help the defense

<!-- image -->

## Wingers can join the attack or drop into midfield to defend

<!-- image -->

## LET'S DO IT

## ACTIVITY 1

## Football game

The class is divided into two teams of equal number of players. They will play a game abiding by the rules of the game. In case of less number of players, a modified game can be played on a smaller size ground.

The team formation depends on the number of players (the diagram below shows a modified football team formation).

Figure 21

In this image we can see a person standing on the ground. We can also see a person holding a stick. We can also see a person standing on the ground. We can also see a person holding a flag. We can also see a person standing on the ground. We can also see a person holding a stick. We can also see a person standing on the ground. We can also see a person holding a flag. We can also see a person standing on the ground. We can also see a person holding a stick. We can also see a person standing on the ground. We can also see a person holding a flag. We can also see a person standing on the ground. We can also see a person holding a flag. We can also see a person standing on the ground. We can also see a person holding a flag. We can also see a person standing on the ground. We can also see a person holding a flag. We can also see a person standing on the

<!-- image -->

## Some Major Fouls in Football

These are some major offenses, or fouls, which result in either a direct free kick or a penalty kick, depending on the location of the offense.

1.  Kicking or attempting to kick an opponent.
2.  Jumping at an opponent in a way that endangers the player.
3.  Charging an opponent in a violent or dangerous manner.
4.  Charging an opponent from behind unless the latter is obstructing.
5.  Striking, attempting to strike or spitting at an opponent.
6.  Holding an opponent.
7.  Pushing an opponent.
8.  Directing or stopping the ball by using the hands or arms. This rule does not apply to the goalkeeper within the penalty area.

## VOLLEYBALL

## Learning Outcomes

<!-- image -->

## In this chapter you will learn about:

- fast front set and back set
- spike
- block

## Backset

Backset  is  an  essential  technique  used  in volleyball to set the ball for a spiker in your team who is behind you. It is used to deceive the opponent's block and to score.

<!-- image -->

Figure 1(a)

<!-- image -->

<!-- image -->

Figure 1(b)

Figure 1(c)

## Preparation - Figure 1(a)

- Move behind the incoming ball. Stand  with  feet  shoulder  with apart (left foot slightly in front of the right).
- Raise your arms with hands making the shape of the incoming ball. Simultaneously, flex your legs and elbows.

## Execution - Figure 1(b)

- Contact  the  ball  just  above  the forehead,  extend  your  legs  and elbows simultaneously, and tilt a little backward.
- While  contacting  the  ball,  push your  hips  out  and  make  an  arch with your back.
- Look towards your target (spiker).

## Follow-through - Figure (c)

- Follow  through  by  going  to  the inital  position  and  be  ready  for the next action.

## UNIT 8

## Fast front set

Fast front set is performed as any other front set but in this one you need to use quick wrist action with less or no body extension.

It is an advance kind of set which is faster and straighter to the hitter with less back arch. It is so quick that the blockers struggle to react and get to the net to block as shown in figure 2.

<!-- image -->

Figure 2

<!-- image -->

<!-- image -->

NOTE: There are different setting zones as shown in figure 3.

Figure 3

In this image we can see a net, a person is standing on the net, there are some objects, there is a board, there is a net, there is a person, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a net, there is a

<!-- image -->

In this image we can see a person is playing a volleyball. In the background there is a wall.

<!-- image -->

Figure 4

The image depicts a volleyball court with two people playing a game. The court is divided into two halves, with the net at the center. The net is white and has a grid pattern. The people are playing a game of volleyball, which is a sport played on a court with a net. The court is surrounded by a red boundary, which is a common feature in volleyball fields.

In the foreground, there are two people, one on each side of the court. They are both wearing casual clothes, including shorts and t-shirts. The person on the left is wearing a purple shirt and a black shorts, while the person on the right is wearing a white shirt and a blue t-shirt. Both people are holding a volleyball in their hands, which are positioned on the court.

The background of the image is a simple, outdoor scene with a clear sky and a few trees. The sky is not visible, but the trees are visible in the background. The ground is

<!-- image -->

Figure 5

Number  3  is  quick,  low  and  halfway between the outside and middle hitter.

Figure 6

<!-- image -->

Number  5  is  high  and  long  for  the outside hitter to either sideline.

<!-- image -->

Figure 8

<!-- image -->

## UNIT 8   |   VOLLEYBALL

Figure 7

In this image we can see a person playing a game of volleyball. In the background there is a net.

<!-- image -->

Figure 9

In this image we can see a volleyball court. There are two persons playing volleyball. One person is jumping and the other person is standing.

<!-- image -->

## Did you know

To make it easier for the setter to deliver a 'hittable set' , the net is divided into 9 zones of 1 meter each. The numbers from 1-5 indicate the heights of the set.

## LET'S DO IT

## ACTIVITY 1 (In pairs)

Draw circles in different zones on the volleyball court. Toss the ball, let it bounce once and set it in the circle.

Figure 10

In this image we can see a group of objects. There are some text on the image.

<!-- image -->

## ACTIVITY 2

From the back row, your partner handfeed the ball to you and you try to set it in:

- zone 4.
- zone 3.
- zone 2 using backset.

The image depicts a rectangular shape with a diagonal line running from the top left corner to the bottom right corner. This line is labeled as "P" and is positioned at the top center of the shape. The shape is a rectangle with a slight variation in color, with a darker shade on the left side and a lighter shade on the right side. The color of the shape is a shade of pink.

The shape is made up of two distinct parts: the rectangle and the diagonal line. The rectangle is positioned at the top center of the shape, while the diagonal line is positioned at the top right side. The shape is symmetrical, with the shape being a rectangle with a slight variation in color.

The image does not contain any text, numbers, or other objects that would typically be found in a geometric figure. The image is a simple representation of a rectangle and a diagonal line, with no additional elements or objects.

<!-- image -->

## ACTIVITY 3

Player 1 handfeeds the ball towards you (S). You set it to player 2 (he catches the ball and returns it to player 1) when he is in:

- zone 4.
- zone 3.
- zone 2 using backset.

Rotate after a few repetitions.

In this image we can see a group of people. There are poles, rods, and a few other objects.

<!-- image -->

## ACTIVITY 4

Player 1 serves from the opposite court. Player 2 receives the serve and direct it to you (S). You set the ball for player 3 (he catches the ball and returns it to player 1) when he is in:

- zone 4.
- zone 3.
- zone 2 using backset.

Rotate after a few repetitions.

## UNIT 8   |   VOLLEYBALL

## Spike / attack / hit / smash

Spike is the most exciting, important and powerful move in volleyball. It  aims at hitting the ball quickly and powerfully over the net into the opponent's court to win a point.

## 3-Steps Approach and Jump

<!-- image -->

In this image, we can see a diagram. In the diagram, we can see a person doing a yoga pose. We can also see a person's legs and feet. We can also see a person's hands and fingers. We can also see a person's head and neck. We can also see a person's arms and hands. We can also see a person's legs and feet. We can also see a person's legs and feet. We can also see a person's hands and fingers. We can also see a person's head and neck. We can also see a person's hands and fingers. We can also see a person's legs and feet. We can also see a person's hands and fingers. We can also see a person's head and neck. We can also see a person's hands and fingers. We can also see a person's legs and feet. We can also see a person's hands and fingers. We can also see a person's head and neck.

<!-- image -->

The 3-step approach allows you to gain momentum and power to hit the ball. Start with your strong foot, accelerate on the last step and take off on both foot. Slightly swing the arms backward and then forward above your hand.

## Figure 14

## Action in the air and Landing

In this image we can see a diagram, in the diagram we can see a person, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the person we can see a person holding a camera, in the

<!-- image -->

## In the air,

1.   bring your right hand close to your ear and flex your elbow.
2.   extend the right arm quickly, open your hands and snap your wrist to hit the ball (highest point) hard downwards (bring the left hand down).
3. follow through with your arms, flex your knees to land and be prepared for the next action.

## LET'S DO IT

## ACTIVITY 1

Start by throwing a tennis ball off the floor against the wall. This helps you to get a good arm swing mechanism.

## ACTIVITY 2

Toss  the  ball  above the head, arc the back slightly and use the spike action to hit the ball on the floor in front of you powerfully.

Toss the ball and tap it off the floor against the wall.

In this image we can see a group of people. The people are wearing red and black color dresses.

<!-- image -->

## ACTIVITY 3

## Individual Wall Practice Spiking Against The Wall

Figure 17

In this image we can see a group of people. They are wearing red and black color dresses. The background is white in color.

<!-- image -->

## ACTIVITY 4

## 3-Step Approach

Figure 18

<!-- image -->

<!-- image -->

<!-- image -->

Figure 16

<!-- image -->

Toss the ball forward, take the 3-step approach, jump, catch the ball above the net and flex your knees to land.

Toss the ball forward, take the 3-step approach, jump, hit the ball over the net and flex your knees to land.

## ACTIVITY 5

You toss the ball to the setter (s), who in turn, sets  it  for  you.  Take the  3-step  approach and hit it over the net.

P2

Figure 19

In this image we can see a person standing on the floor. There are some objects on the floor.

<!-- image -->

## ACTIVITY 6

P3

In this image we can see a person standing on the floor. In the background there are some objects and we can see a wall and some objects.

<!-- image -->

Player  1  serves  from the opposite court. Player  2  receives  the ball  and  passes  it  to the setter (S). He/s sets the ball for you to hit. Rotate after a few repetitions.

<!-- image -->

## Did you know

- A  back-row  player  may  hit  a ball behind the front zone and may land in the front zone after the hit.

Attackers should let their setters know what type of sets they prefer.

## Block

Block is the main defense action against an opponent spikes. It helps to slow down the speed of the hit which makes it easier for the back row player to pass the ball to the setter.

## LET'S DO IT

## ACTIVITY 1

One player holds the ball just above the net and you try to block it.

Figure 21

<!-- image -->

## The positioning Skill

1. Stand close to the net and keep your hands at shoulder level with palm facing the net.
2. Keep your eyes on the ball and move along.
3. Take a pike jump immediately after the attacker's jump.
4. Extend and stretch your hands over the net once in the air.
5. Contact the ball so that it rebounds off your hands and fall into the opponents court (but it should not go out the court or come into your court).
6. Flex your knees to land (make sure not to touch the net or the midline) and be ready for the next action.

<!-- image -->

Figure 22

<!-- image -->

<!-- image -->

<!-- image -->

Figure 23

In this image we can see a person holding a ball. In the background there are some objects.

<!-- image -->

## ACTIVITY 2

One player from the opposite court throws the ball over the net and you need to block it.

Figure 24

In this image we can see a person standing on the ground. In the background there are some objects and a fence.

<!-- image -->

## ACTIVITY 3

In this image we can see a group of people playing volleyball. There is a net. In the background there is a wall.

<!-- image -->

S

Player 1 serves the ball from the opposite court. Player 2 receives the ball and pass it to the setter (S) who sets it for the hitter (P3). When the spiker hits the ball, you (P4) need to block it.

## Double Block

Figure 26

In this image we can see a group of people playing with a ball.

<!-- image -->

In this image we can see three persons are standing on the floor. In the background there are some objects and a wall.

<!-- image -->

In this image we can see three people playing with a ball. In the background we can see a wall, rods, a few objects and lights.

<!-- image -->

It is performed when two players, the middle blocker (usually the setter) and the either two side blocker, come together to block an attacked ball at the net. This, most of the time prevents successful attacking.

NOTE: It is against the rules to block an opponent serve. If the blocker attempts to interfere with the opponent's play, block or touches the ball before the hitter, it is a fault.

## LET'S DO IT

## Did you know

<!-- image -->

## ACTIVITY 1

Figure 27

<!-- image -->

## ACTIVITY 2

Player 1 serves the ball from the opposite court,  Player  2  receives  it  and  passes  the ball to the setter who sets it for the hitter. When the spiker hits the ball, you and your friend block it.

1. Setters can use underhand to set a ball.
2. The  setter  can  surprise the  opposing  team  by spiking the ball instead of setting.

One player  from  the  opposite  court throws the ball over the net. You and your friend block it.

3. A  team  can  have  two setters  on  the  court  at the same time.

In this image we can see a person playing tennis. In the background there is a wall.

<!-- image -->

## BASKETBALL

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about:

- basics of defensive and offensive strategies in basketball
- screen/pick and roll
- positioning in basketball

## Defense in Basketball

Defense in basketball aims at making it difficult for the offensive players to score. This can be achieved by:

- positioning yourself in between the opponent and your rim.
- closing any open space for (e.g when opponent is shooting).
- preventing the opponents from approaching your rim easily.

## A strong defensive stance allows you to:

- be ready to move in any direction.
- prevent shots.
- have active hands, ready to steal the ball from your opponent.
- increase the difficulty level of your opponent's offensive work.

## Preparation

Keep your eyes up on the offensive player

Stand with your feet slightly wider than shoulder width apart and pointing forward

Flex your knees to adopt a half squat position to keep your body low with chest up

Shift your body weight on the balls of your feet (but not on your toes)

<!-- image -->

Figure 1

<!-- image -->

## UNIT 9

## Positioning

Figure 2

<!-- image -->

## LET'S DO IT

## ACTIVITY 1

- Set up cones in a zig-zag shape.
- Start at the top cone (1) in the proper defensive stance.
- Slide to the next cone. Change direction at each cone.
- Start slow, stay low, keep balance  and  maintain  posture to work on the proper mechanics and then speed up.

## ACTIVITY 2

Perform the same drill as above in a one to one situation.

- Keep your body square to the offensive player.
- Move with your opponent while staying low to the ground using chasing step (side to side).
- Change direction, as the offensive player changes direction.
- Keep your hands up and active.

In this image we can see a diagram of a basketball court.

<!-- image -->

In this image we can see a person is playing basketball. There are two persons standing on the ground. There are two nets. There are trees.

<!-- image -->

Figure 3

<!-- image -->

Figure 4

<!-- image -->

## On ball defense tips

Aim to stay in between the offensive player and the rim:

- observe your opponent.
- force him/her to use his/her weaker hand to dribble (for e.g, if he/she dribbles more fluently with the right hand, place your left foot slightly in front of his/her right side or vice versa).
- be patient and do not lunge at the basketball, unless you are sure of winning the ball.

<!-- image -->

Figure 5

- stay an arm distance from your opponent.
- keep hands active and put constant pressure on the opponent in possession of the ball.

## Off ball defense tips

Whenever  you  are  on  an  offball  defense  (you  are  not  defending  the player  having  possession  of  the  ball),  you  should  adopt  a 'defensive triangle' .  It  refers  to  positioning  yourself  between  the  basketball  and your opponent so that you can see both with your peripheral vision.

Figure 6

<!-- image -->

There are several defensive systems but we are going to focus on the 2 most popular ones:

## 1.  Zone defense

Zone  defense  is  a  specific  area  of  the  floor assigned to a defensive player who has to guard whenever  an  offensive  player  enters  this  area. Figure 8 shows different types of zone defense.

For example, in a 2-3 zone two defenders cover areas in the top of the zone while three defenders cover areas near the baseline.

Figure 7

In this image we can see a cartoon image of a person standing on the ground. In the background there are fire and there are some objects.

<!-- image -->

Figure 8

In this image we can see a board with some text and numbers.

<!-- image -->

## Man to man defense

Man-to-man defense is another type of defense where each player is assigned to defend and follow the movements of a single offensive player. A player guards his  counterpart  (e.g.  center  guarding center),  but  he/s  may  be  assigned  to guard  a  different  position.  However, the strategy is not rigid, a player might switch  assignment  if  needed,  or  leave his  own  assignment  for  a  moment  to double team offensive player.

Figure 9

In this image we can see a basketball court. There are a few people standing on the court.

<!-- image -->

It is advised to use man-to-man defense for young students.

## LET'S DO IT

## ACTIVITY 1

## Formation: One line on the left side of the court

NOTE: 1 player (Player C) stands in the free throw area before the activity starts.

- Player 1 (C) feeds the ball to player 2 (A).
- Player A becomes an attacker and Player C becomes a defender and they play 1 vs 1.
- After  one  shot,  the  defender  joins  the  line  and  the attacker acts as defender now.
- After few repetitions, do the same from the right side.

## ACTIVITY 2

## Formation:  Single  line  from  one  side  of  the  back court

- Player 1 (attacker) dribbles the ball around cone A to shoot.
- Player 2 (defender) runs around cone B to defend on player 1 (1 vs 1).
- Player  3  receives  the  ball  from  player  1  and performs the same role as player 2.
- Player 2 joins the line.

Figure 11

In this image we can see a diagram. In the diagram we can see a ball and a cone.

<!-- image -->

<!-- image -->

Figure 10

<!-- image -->

## ACTIVITY 3

Figure 12

In this image, we can see a group of people. We can also see a basketball. We can see a basketball hoop. We can see a person holding a basketball. We can also see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can also see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can also see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can also see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a basketball. We can also see a person holding a basketball. We can see a person holding a basketball. We can see a person holding a

<!-- image -->

## Offensive Strategy

## Screening (pick)

A screen , also known as a pick , is when an offensive player blocks a defender, by standing beside or slightly behind a defender, thus allowing his team-mate to free himself for a pass, shoot, or dribble (drive in) to score. Screens can be on-ball (when set for the ballhandler),  or  off-ball  (when  set  for  a  teammate  moving  without the ball to get free for a pass). The two offensive players involved in setting the screen are known as the screener (who blocks the defender) and the cutter (who gets free from the defender).

## UNIT 9   |   BASKETBALL

4  cones  are  placed  in  a  square  formation.  3  players stand behind the 3 cones (one of them have a ball), and 1 player remains inside the square.

The players outside the square pass the ball to each other. Once the pass is made, the player who passed the ball moves towards the free cone, without passing in the middle of the square.

The player who is inside the square has to follow  the  ball  and  tries  to  intercept  it.  After  20 seconds,  the  player  who  is  inside  the  square  goes outside, and  another  player  gets to defend  for another  20  seconds.  The  drill  continues  until  all the players have gone through the defensive situation.

Figure 13

<!-- image -->

## Position for the player setting the screen

Figure 14

In this image we can see a group of people playing basketball.

<!-- image -->

- Stand with feet slightly more than shoulder-width apart.
- Keep your hands crossed across your chest (girls) or on your groin area (boys).
- Stand still as the screen is set (if you move, you will be called for an offensive foul).
- Keep  your  body  straight  and  tall  (should  not  be leaning forward or backwards).
- The middle of your chest should be in line with the defender's shoulder and hips.

## How to take advantage of the screen

- Wait until the screener is completely set.
- Fake a move in the opposite direction even if it's only a slight head fake (this will get the defender leaning  in  the  wrong  direction  and  when  he moves in the  other  direction  to  catch  up  with you, he will run into the screen).
- When you run off the screen, you will need to run shoulder to shoulder, that is brush against your teammates screen as you run (this will not give the defender any room to get around the screen).
- Run off the screen in an explosive manner (this will leave the defender in the difficulty and give you much more time to set up for a shot).

Figure 15

In this image we can see a group of people standing on the ground. In the front of the image we can see a person holding a basketball. In the background of the image we can see the trees.

<!-- image -->

## Pick and roll

The  pick and  roll is  an offensive  play  in  which  a player sets a screen (pick) for  a  teammate  handling the  ball  and  then  moves toward the basket (rolls) to receive a pass.

Figure 16

In this image we can see a group of people playing tennis on the tennis court. There are trees and a fence in the background.

<!-- image -->

This situation involves three players:

1.  the play begins with a defender (in red) guarding a ball handler.
2.  the ball handler moves towards a teammate (pick player).
3.  teammate  (yellow)  sets  a  screen (pick)  by  standing  in  the  way  of the  defender  and  then  performs a roll, by a foot pivot (180 degrees towards  the  basket)  and  is  open for a pass.

Figure 17

In this image we can see a person wearing a yellow shirt and a blue shirt is standing. There is a ball on the ground. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding a stick. There is a person holding

<!-- image -->

## LET'S DO IT

## ACTIVITY 1

## Pick and roll

1.  Player  A  has  the  ball and  Player  B  sets  pick for Player A.
2.  Player  B  'rolls'  to  the basket.

<!-- image -->

Figure 18

<!-- image -->

## ACTIVITY 2

Use all the skills you have learnt in this chapter in a match situation.

## UNIT 9   |   BASKETBALL

3.  Player A passes to Player B for an easy shot.

<!-- image -->

<!-- image -->

## Positioning in basketball

In the modern game of basketball, players have differet roles and responsibilities while being in defensive or attacking positions. The five basic positions in basketball are:

1.  point guard.
2.  shooting guard.
3.  small forward.
4.  power forward.
5.  centre.

Figure 19

In this image we can see a board with some text and images.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|   Post | Position       | Physical Attributes required                                                                 | Skills required                                                                                                                              | Roles and responsibilities                                                                                                                   | Examples   |
|--------|----------------|----------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|------------|
|      1 | Point guard    | He / she can be the shortest player of the team                                              | • Agility • Good ability to handle the ball • Good vision • Good passing skills • Ability to shoot from long distance                        | • Drives the ball • Directs play • Initiates offensive play (tactics) • Creates shooting opportunities for teammates                         |            |
|      2 | Shooting guard | He / she can be the shortest player of the team                                              | • Ability to shoot from long distance • Good court vision                                                                                    | • Shoots • Drives the ball • Helps setting up offensive play                                                                                 |            |
|      3 | Small forward  | He/ she is usually the shorter of the two forwards, but should be tall enough to play inside | • Ball Handling • Shooting • Passing • Creating Space • Post up • Defense • Pick &Roll defense • Dribble moves • Finishing • Setting screens | • Ability to play inside and play outside (versatile) • Shoots                                                                               |            |
|      4 | Power forward  | He/she can be the second tallest player of the team                                          | • Shooting skills                                                                                                                            | • Scores near the basket • Guards offensive players near the basket                                                                          |            |
|      5 | Centre         | He/she should be the tallest and strongest player of the team                                | • Good footwork • Strength                                                                                                                   | • Positions yourself under basket • Scores from offensive rebound • Sets screens • Block shots when defending • Fight for defensive rebounds |            |

## BADMINTON

## Learning Outcomes

<!-- image -->

## In this chapter you will learn about the:

- smash
- overhead clear
- forehand and backhand lift
- slow and fast drop shot

## Advance offensive and defensive strokes

## Introduction

The advance offensive and defensive strokes in badminton are skills used to get an advantage over your opponent. These include the following techniques:

## 1. Smash

The smash is an offensive shot used to hit the shuttlecock with power and speed into the opponent's court. The angle and steepness of the shuttlecock's trajectory makes it difficult for your opponent to retrieve (defend) thus, giving you an extra opportunity to score.

A jumping smash is a more advanced shot that gives more power and speed to the shuttlecock, leaving the opponent with less or no time to react and move to play the shot.

However, you need to master the forehand smash before going for the jumping smash.

## Stance for the smash technique

## Execution

Raise both arms to balance your body weight

Shift your weight to the back foot

Flex your elbow

Lock your wrist and prepare to swing forward

Stand sideways with your non-racket side facing the net using the forehand grip

<!-- image -->

Figure 2

Figure 3

<!-- image -->

Figure 1: Jumping smash

<!-- image -->

With a full forward arm swing

Extend your elbow to hit the shuttle at the highest point possible with a full forward arm swing

## UNIT 10

## Follow Through

<!-- image -->

## LET'S DO IT

## ACTIVITY 1 (In pairs)

One  partner  acts  as  the  feeder and lifts the shuttlecock high in the middle of your court. Be in a ready position and move towards the incoming shuttlecock.

Smash it at its highest point into the partner's court.

Complete your swing down till your racket reaches down the opposite side of your body

Maintain body balances

Recover and be prepared for the next shot

Figure 4

Figure 5: Flight trajectory of the Smash

In this image, we can see a person is standing and holding a stick. We can also see a diagram.

<!-- image -->

## 2. Overhead clear

The overhead clear is a defensive stroke much higher from your baseline to your opponent's one, for you to gain time to come back to your base position. This will allow you to prepare for your next shot.

Figure 6

In this image we can see a group of people playing a game.

<!-- image -->

## Stance

Stand sideways with your non-racket side facing the net

Use the forehand grip

## Execution

<!-- image -->

## Follow through

Shuffle Racket Foot forward

<!-- image -->

Shift your body weight on your racket foot while swinging the racket forward

Point both feet forward

Stretch out your non-racket arm

Figure 8

<!-- image -->

## UNIT 10   |   BADMINTON

Raise your racket arm and non-racket arm

Shift your body weight on back foot

Figure 7

Bring your racket arm as far back as possible while bringing your non racket arm down

Flex your knees slightly

Swing your racket forward

Use your racket foot to push your body weight forward

## shuttle direction

<!-- image -->

Place yourself below the shuttlecock and hit it at its highest point

The swing naturally directs the shuttlecock upward

Extend your knees while doing the action

Figure 9

## LET'S DO IT

## ACTIVITY 1 (In pairs)

Practice the overhead clear continuously from baseline to baseline with a partner.

## Forehand and Backhand Badminton lift

Forehand and backhand lifts are defensive strokes in badminton. These strokes are used to defend an opponent's smash.

<!-- image -->

Figure 11: The flight trajectory of a lift

## Execution

Take the shuttlecock when it is in front of you

## SWING

<!-- image -->

Move the racket down towards the incoming shuttlecock and at the point of contact

Flick your wrist so that the shuttlecock travels over the net

Figure 13

## Follow through

Follow through with your swing until the racket reaches above your head

Bend your body &amp; Contract your abs

Bend your knees as you hit the shuttle

Figure 14

<!-- image -->

## Forehand lift Stance

Place your racket in front of your body

Lunge forward with your Racket Leg

<!-- image -->

Use a forehand grip and don't hold the racket too tightly for a better wrist action

Figure 12

## LET'S DO IT

## ACTIVITY 1 (In pairs)

One partner acts as a feeder. He/s throws the shuttlecock to your forecourt and you return it using the forehand lift.

## Backhand lift

## Stance

<!-- image -->

From ready position, lunge forward

Adopt the backhand grip stance as shown above

Avoid holding your racket too tightly

Figure 15

## Execution

<!-- image -->

At the point of contact, flick your wrist so that the shuttlecock travels over the net

Figure 16

## LET'S DO IT

## ACTIVITY 1 (In pairs)

One partner acts as a feeder. He/s throws the shuttlecock in front of your non racket side. Return it using the backhand lift

## Badminton Drop Shot

The badminton drop shot is used to move your opponent to the front court. This creates space in the midcourt and backcourt of the opponent's court for you to exploit. You can play a Slow or a Fast Drop Shot. It can be played on the forehand or backhand sides.

## Slow Drop Shot

## Fast Drop Shot

<!-- image -->

Slow Drop: the shuttlecock takes some time before it lands on your opponent's side. However, it falls nearer to the net. The point of contact with the shuttlecock is above the racket shoulder to move your opponent to the front court, forcing him/her for a weak return to your midcourt for you to attack.

<!-- image -->

Fast Drop: the shuttlecock travels down faster to your opponent's  side,  but  lands  nearer  to  the  mid  court. For that, you need to hit the shuttle slightly further in front of your body to produce a shallower trajectory at a faster speed.

## Follow Through

Follow through with your swing until the racket reaches above your head

Figure 17

<!-- image -->

## Stance for slow and fast drop shot

<!-- image -->

Take shuttle at the Highest Point

In this image we can see a person standing on the ground and holding a tennis racket.

<!-- image -->

Body Face Sideways

Figure 19

Raise your Non-Racket Arm

In this image, we can see a person holding a tennis racket. We can also see a person standing and holding a tennis racket. We can see a red color line. We can see a white color line. We can see a red color line. We can see a blue color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see a red color line. We can see a white color line. We can see

<!-- image -->

Figure 20: Flight Trajectory of the Slow Drop and Fast Drop Shot

## Ideal Landing Point for the Slow Drop Shot

In this image we can see a graph.

<!-- image -->

Figure 21

In this image we can see a graph.

<!-- image -->

For the Slow Drop Shot , the shuttle should land somewhere on the RED area. An ideal Slow Drop should lands before the service line.

For the Fast Drop Shot , the shuttle should land somewhere on the YELLOW area. The Ideal Fast Drop lands on or after the service line.

## LET'S DO IT

## ACTIVITY 1 (In pairs)

One partner acts as the feeder and lift the shuttle cock high in the middle of your court. Be in a ready position, move towards the incoming shuttle cock and return it using the slow and fast drop shot alternately.

## SWIMMING

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about:

- breaststroke technique
- forward start from the starting block
- flip turn technique
- water safety tips

## Breaststroke

## Introduction

This is the oldest of the four modern competitive strokes which is used by swimmers of all abilities.  However,  it  is  considered  as  the  slowest  stroke  as  recovery  of  both  arms  and  legs beneath  the  water  creates  considerable  resistance  when  swimming  at  speed.  Finally,  the relatively high position of the head, especially when inhaling, causes the body to be inclined from the horizontal, producing additional resistance.

Figure 1

In this image we can see a person wearing a cap and a white color dress is swimming in the pool.

<!-- image -->

## UNIT 11

## Breaststroke

## Body position:

- As horizontal as possible.
- Slope down towards the seat.
- Shoulders horizontal.

## Arm Action:

- From glide position, hands turn outwards.
- Pull downwards and outwards in line with the shoulders.
- Arms meet in the centre of the body and drive out to glide position.

Figure 2

In this image, we can see a person wearing a purple color dress and holding a stick.

<!-- image -->

## LET'S DO IT

## ACTIVITY 1 (Standing individual leg kick see figure 3)

Standing with both feet close together and arms at your sides.

Execute the different phases of the kick with your right leg:

- recovery - flex your right knee and bring your heel towards your right gluteal. At the same time, flex your ankle with your toes pointing towards your shin (dorsiflexion).
- catch - When your foot is close to the gluteal, abduct your right leg  sideways  while  keeping  your  knee  flexed  and  your  ankle remains in dorsiflexion.
- outsweep - extend your leg and point your foot/toes (plantar flexion). But keep your leg lifted sideways.
- insweep - Bring your right leg back to the starting position at the end of the leg extension.

Perform the activity several times until the movement becomes fluid (smooth). Then, repeat the same with your left leg.

## Leg Action:

- Starts in the glide position.
- Heels drawn towards the seat.
- Knees as wide as the hips.
- Feet turn out just before you kick.
- Kick backwards with a circular movement.
- Legs return to glide position.

## Breathing:

- Breath taken every arm pull.
- Chin is pushed forwards

## Timing:

- Pull - breathe - kick - glide

Figure 3

<!-- image -->

## ACTIVITY 2 (Breaststroke kick on a chair see figure 4)

In  the  next  dry  land  exercise,  you  simultaneously  rehearse  the kick movements with both legs. You need a chair for this exercise:

- Sit with knees fully extended and hold the seat of the chair with both hands as shown in figure 2.
- Lift your legs slightly above the ground.
- Perform breastroke kick for 1 minute.

## ACTIVITY 3 (Breaststroke kick on the floor see figure 5)

- Lie down on the floor in prone position.
- Place your arms in front of you in a comfortable position as shown in figure 3.
- Extend  your  legs  with  ankles  in  dorsiflexed position.
- Now practice the breaststroke kick.

Figure  5

<!-- image -->

## ACTIVITY 4 (Breaststroke kick while holding on the wall of the pool see figure 6)

- Enter  the  pool  and stand on both feet.
- Stretch  your  arms  in front and  hold the edge of the wall with both hands.
- Take  a  deep  breath, put your face into the water and stretch your legs to float.
- Blow bubbles and start breastroke leg movements.
- When  you  have  run out  of  breath  regain standing position.

Figure 6

The image is a diagram titled "Breast Stroke Kick." It shows a diagram of a person's body in a swimming position, specifically with the legs straight and the body oriented towards the left side of the image. The diagram includes a label "Legs straight" and a red arrow pointing to the right side of the image.

The diagram includes a blue line that runs from the bottom left to the top right of the image. This line represents the "leg straight" position. The diagram also includes a red arrow pointing to the left side of the image.

The diagram includes a label "Breast Stroke Kick" at the top of the image. This label indicates that the person is performing a breast stroke kick, which is a type of swimming stroke where the body is bent forward with the arms extended backward.

The diagram also includes a red arrow pointing to the left side of the image. This arrow indicates that the person is performing a "leftward" or "leftward"

<!-- image -->

In this image we can see a person swimming in the water.

<!-- image -->

## UNIT 11   |   SWIMMING

Figure 4

<!-- image -->

## ACTIVITY 5 (Breaststroke kick with kickboard see figure 7)

- Hold the kick board and stand against the wall.
- Bend forward and stretch your arms fully in front.
- Push against the wall and glide to start kicking.
- Kick for 5 metres and regain standing position.

<!-- image -->

## Breaststroke:  arm action

In this image, we can see a diagram.

<!-- image -->

## 3. Insweep

The  insweep  is  the  propulsive  phase  of  the arm stroke.

Move your  forearms  backward  and  inwards while  trying  to  keep  them  facing  backward for as long as possible.

Your  elbows  automatically  move  inwards towards the rib cage and your hands move towards each other.

The insweep ends when your hands are close together below your chest.

## Breathing Technique

- Inhale during the insweep and exhale continuously for the rest of the stroke cycle.
- Your head and shoulders rise above the water surface during the insweep, which allows you to breathe in.
- During the arm recovery forward your head and shoulders drop back into the water, and you start to exhale and continue to do so until the next insweep.

## 1. Outsweep

Your  hands  separate  and  your  arms  move outwards until they are outside the shoulders. Your  palms  should  be  facing  downwards  or slightly outwards.

## 2. Catch

Bend your arms at the elbows and move your forearms downwards and backward.

Your  hands  stay  in  line  with  your  forearms and  your  shoulders  stay  close  to  the  water surface.

The catch phase ends when your forearms and palms are facing backward, perpendicular to the water surface.

## 4. Recovery

Move your arms quickly forward in a straight line until they are completely extended, with your hands close together.

Your  forearms  and  palms  rotate  outwards during  the  recovery  until  they  are  again facing downwards at the end of the recovery.

## 1. Breaststroke arm action while standing

While swimming breaststroke, there's a short glide phase that is observed at the end of each stroke cycle. In that glide phase, your arms (and your legs) are fully extended, and your body is horizontal and streamlined.

- Stand upright, with your arms straight and extended overhead.
- Keep your hands close together and your palms facing downwards.
- Perform arm action for 1 minute.

## 2. Breaststroke arm action with pull buoy (Figure 9)

- Stand against the wall.
- Put the pull buoy in between your thigh.
- Bend forward and stretch your arms fully in front.
- Take a deep breath, lower your head until your face is in the water and exhale slowly.
- Push against the wall and glide to start arm action.
- Swim for 5 metres and regain standing position.

## Breaststroke: full stroke

## 1. Swimming breaststroke using a water noodle, without breathing

- Grab a water noodle.
- Stand against the wall.
- Place  the  water  noodle  across  your  chest  and under your armpits.
- Push  against  the  wall  and  assume  a  horizontal position with your body.
- Extend  your  arms  forward,  and  your  hands  are close together.
- Extend  your  legs,  close  together,  and  your  toes are pointed.
- Put  your  face  is  in  the  water,  and  your  head  is aligned with your trunk.

<!-- image -->

Figure 10

- Keep your head in the water for the whole stroke cycle (as explained in learning the arm movements on dry land, start the arm stroke with the outsweep, followed by the catch and insweep).
- Start the recovery of the legs towards the buttocks at the end of the arms' insweep, then catch and sweep out with your legs at the end of the arms' recovery forward.
- Continue to sweep your legs out and then in while your arms are extended forward.
- Observe a short glide phase in the streamline position where both your arms and your legs are extended and kept together at the end of the kick.
- Start the stroke cycle again after the glide phase by sweeping your arms out.
- Do three stroke cycles in a row, then pause for breathing, before starting again.

Figure 9

<!-- image -->

## 2. Swimming breaststroke using a water noodle, with breathing

- Follow the same instructions as the previous drill.
- Start to sweep in with your arms, let your hips drop and your shoulders and head rise above the water surface.
- Start to inhale as soon as your mouth clears the water.
- Keep your head in line with your trunk, look downwards and slightly forward.
- Drop your shoulders and head back into the water when your arms recover forward.
- Start to exhale as soon as your head is in the water again.
- Finish this stroke cycle, then immediately start a new one, and so on.

## 3. Swimming breaststroke

- Remove the water noodle once you feel confident enough in the propulsion and support provided by your arms' and legs' movements.

## FORWARD START

## Introduction

The front crawl, breaststroke and butterfly races all normally start with a dive. When the referee is satisfied that all competitors and officials are ready, a single long blast on his whistle is the signal for the competitors to take up position on the back of the starting block or a short pace back from the starting line. By raising his hand, the referee then signals to the starter that he may proceed to start the race.

## Using the grab standing position

## 1.  Step carefully onto the block.

- Keep both feet facing forward, with your entire body facing the pool.
- Make  sure  that  you  feel  completely  stabilized  before moving into the next position.

## 2.  Stand on the block and curl your toes over the edge of the block.

- Stand with your feet approximately 6 inches apart and your body weight evenly distributed between your two legs to ensure stability.
- Keep your knees slightly bent.

Figure 11

<!-- image -->

Figure 12

<!-- image -->

## UNIT 11   |   SWIMMING

3.  Stretch your arms forward and grab the front edge of the block
- Place  your  hands  inside  or  outside  of  your  feet,  whichever  is most comfortable for you.
- Lean slightly forward.

## 4.  Keep your head positioned between your knees

- Tuck your head close to your knees with your chin resting on your chest.

## Finalizing your position

## 1.  Lift your hips

- Lift your hips as high as you can.
2.  Position your head so that it is down and looking slightly backward
- Help you keep your goggles on after you hit the water.

## 3.  Get into position and be as still as possible

- The race will not be started until all of the competitors are ready, completely still and in starting position.

<!-- image -->

Figure 13

<!-- image -->

Figure 14

<!-- image -->

Figure 15

Figure 16

<!-- image -->

Figure 17

<!-- image -->

## Pushing off

## 1.  Push off with your hands and legs simultaneously

- Pushing off with your hands will tilt your body in the ideal position to thrust with your legs.
- Leave  the  block,  use  your  curled  toes  to  give yourself a final push to propel you forward and downward into the water.

Figure 18

<!-- image -->

## 2.  Throw your arms forward into the streamline position as you push off

- Push off with your hands to throw your arms forward into the streamline position
- Look up slightly as you push off. This will force your body to follow the direction of your head.

## 3.  Tuck your head down and push your hips up

- Keep  your  head  between  your  arms,  looking slightly backward.

## Making impact

1.  Maintain the streamlined position after push off
- Maintain this position before entering the water by locking all of your major joints - ankles, knees, hips, wrists, elbows, shoulders and neck.
- Hook your thumbs together to keep your arms in the streamlined position once you hit the water.

## 2.  Remain in the streamlined position when you hit the water

- Keep  your  feet  close  together,  toes  pointed, buttocks  tight,  chin  resting  on  your  chest,  eyes looking downward and your arms locked straight behind your ears.

In this image we can see a person is doing a swimming exercise.

<!-- image -->

Figure 19

Figure 20

In this image, we can see a person swimming.

<!-- image -->

Figure 21

<!-- image -->

## 3.  Lift your hands and head slightly after you hit the water

- Keep the streamlined position until you are just about to resurface and begin swimming.

## LET'S DO IT

## ACTIVITY 1 (The seated dive)

- Sit  on  the  edge of the pool, butt on the edge and feet dangling in the water.
- Roll the body forward in streamline (hand over hand, elbows squeezing ears and look down).
- Get long over the water if possible and push with the feet.
- Use the legs to drive the body forward through the water.

## ACTIVITY 2 (Kneeling dive)

- Kneel down on the edge of the pool with one leg forward with toes curled over.
- Knee should be near face.
- Arms in streamline position over your head.
- Keep your back parallel to the deck or water surface.
- Get along with the body when you PUSH with legs.

## ACTIVITY 3 (Standing position)

- Stand on the edge of the pool and perform the dive.

## ACTIVITY 4 (Dive from the starting block)

- Perform the dive from the starting block.

<!-- image -->

Figure 22

<!-- image -->

Figure 23

Figure 24

<!-- image -->

Figure 25

<!-- image -->

## THE FLIP TURN

## Introduction

A  tumble  turn  or  flip  turn  is  one  of  the  turns  in swimming used to reverse the direction in which the  person  is  swimming.  It  is  done  when  the swimmer reaches the end of the swimming pool but  still  has  one  or  more  lengths  to  swim.  Flip turns  are  only  permitted  during  freestyle  and backstroke  races.  In  butterfly  and  breaststroke races, regulations require swimmers to touch the end of the pool with both hands simultaneously before turning back for another length.

Figure 26

In this image we can see a person swimming in the water.

<!-- image -->

## Start your turn when you see the black T on the pool floor

There is a black line at the bottom of your pool lane. The perpendicular line lets you know that the wall is two feet away. You can use the black T to let yourself know it IS time to start executing your turn. This can be  hard  to  judge  because  it  all  depends  on  the  length  of  your  legs. Depending  on  how  long  your  legs  are,  you  would  normally  do  two strokes after the T, then do your turn. If you Are very tall or on the short side, adjust accordingly.

Figure 27

<!-- image -->

Figure 28

In this image we can see a group of people swimming.

<!-- image -->

To  perform  this  turn  the  swimmer  approaches  the  wall  at  speed. When about half a body length away, the head leads the body into a piked position, as one arm is about to enter the water in front of the head. The other arm stops at the beginning of the push phase.

The leading arm assists the roll until it is in line with the other arm which is then bent and used in a sculling action to aid rotation.

The  legs  are  lifted  and  thrown  over  the  water  to  the  side  of  the forward arm. At the same time the shoulders are turned to place the body on its side, assisted by the sculling movements of the hands.

The body continues to move forward during rotation so that the feet are placed on the wall a short distance apart, with the knees bent.

The arms are now extended and - without pause - a strong thrust is made with the legs to drive the body into the glide.

NOTE: Blow bubbles through your nose.

## LET'S DO IT

## ACTIVITY 1(Somersault to streamline stand)

- Practise a somersault and finish by standing with your arms in the streamline position.
- Repeat until mastered.

## ACTIVITY 2 (Somersault to streamline feet on the wall)

- Start from a position where your hand is almost touching the wall or end of the pool.
- Make a somersault and aim for your feet to touch the wall.
- Push off the wall on your back.
- Focus on using your feet and legs to push off from the wall with power.
- Repeat until mastered.

## ACTIVITY 3 (Add a twist, push and streamline kick)

- Hit the wall with your feet consistently.
- Push off from the wall with power in a streamline position.
- Make a twist so that you push off on your side and rotate on the push off to face the bottom of the pool.
- Repeat until mastered.

## ACTIVITY 4 (Swim freestyle, tumble turn with a twist, streamline kicks out to flags)

- Stand in the water 5 metres away from the end of the pool.
- Swim freestyle and perform a tumble turn to swim back to your initial position.

## WATER SAFETY TIPS

## 1.  At home

Did you know that people can drown in as little as 2 centimetres of water?

- Always use self-closing gates, fences and locks to prevent children from gaining access to pools of water.
- Securely cover all water storage tanks and drains.
- Empty paddling pools and buckets as soon as they have been used.
- Always turn paddling pools upside down once emptied.
- Always supervise bath time.

## 2.  Inland water sites

More people drown in inland waters than coastal or at sea (e.g. in rivers, canals, lakes, reservoirs and ponds).

-  When around water, stay back from the edge. About 22 % of people who drown fall into the water by accident (e.g. whilst out fishing, running or walking).
- Remember that lakes and rivers remain cold all year round.
- Always wear a buoyancy aid or lifejacket for any water activities.
-  Never enter the water after consuming alcohol.

## 3.  At the beach

Drowning is the second leading cause of accidental deaths in the world.

-  Swim at lifeguarded beaches only.
-  Swim within the swim zone (yellow buoys).
- Read safety signs at the entrance to the beach.
- Learn the meanings of the lifeguard flags.
- Check when the tide will be low and high.
- Keep young children under constant supervision.

## 4.  At the swimming pool

- Swim at lifeguarded pools only.
- Keep young children under constant supervision.
- Follow the pool's rules (don't dive into the shallow end).
- Take time to check the depth, water flow and layout of the pool, especially at leisure pools and holiday resorts.

## Know the SAFE code

Whether you are at the pool, the beach, a lake, or by a river, use the SAFE code to ensure yourself.

| SPOT      | • Spot the dangers - learn about the hazards at swimming pools and open water sites.                  |
|-----------|-------------------------------------------------------------------------------------------------------|
| ADVICE    | • Take safety advice - read the signs and listen to lifeguards.                                       |
| FRIEND    | • Alwaysgowithafriend-ifonepersongetsintodifficulty, the other can go and get help. Never swim alone. |
| EMERGENCY | • Learn what to do in an Emergency - learn personal survival skills and learn hoe to help others.     |

<!-- image -->

## TABLE TENNIS

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about:

- basic footwork (combining forehand and backhand)
- playing down the line/ straight
- backhand serve
- spin

## Basic Footwork

The basis of good footwork is an important base  stance  for  all  possible  strokes  to  be reached  easily.  Good  footwork  enables  a player  to  move  quickly  to  get  to  the  ball, save energy and be in the best position to perform a particular skill.

Put your weight on the front part of the foot to provide balance and readiness for movement.

## UNIT 12

Place your feet shoulder width apart or slightly wider.

<!-- image -->

Ready Position

Footwork involves movement techniques which vary from playing, close to the table to far from the table and there are different types of footwork to accommodate different styles of play. They can be described as follows:

## 1. In and out footwork

The footwork is performed by moving your body forward (IN) to reach the ball to play the stroke and afterwards move back (OUT) to the ready position.

When moving inwards towards the ball, step your right foot forward under the table. After playing the shot, return to the base position.

## LET'S DO IT

## ACTIVITY 1 (Shadow Practice)

- Stand on a line and be in the ready position (see figure 1).
- Keep the non-racket leg on the line.
- Extend your racket leg forward to make as if you are hitting a ball (see figure 2).
- Get back to the initial position.
- Perform this activity 10 times.

Figure 1

<!-- image -->

## ACTIVITY 2 (In pairs)

- Your partner feeds the ball near the net.
- Use the 'in and out' footwork to play the ball.

<!-- image -->

Figure 2

<!-- image -->

## 2. Chasing Steps / Side to side or 'chasse' footwork

Figure 3

The chasing steps is the most used footwork being fast and economical, enabling the player to be in the best possible position for every stroke.

If the movement is on the right side, the left foot moves first and has to get close to the right one, which will move on the right side. If the movement is on the left side, the right foot moves first and has to get close to the left one, which will move on the left side.

## LET'S DO IT

## ACTIVITY 1

- Place two chairs, A and B about 5 metres apart (see figure 4).
- Put 5 balls in a basket on chair A.
- Put another basket which is empty on chair B.
- Be in ready position between the two chairs.
- Perform the chase steps, to move to chair A and pick one ball. Perform the chase steps again to move to chair B and put the ball in the other basket.
- Continue the activity until the 5 balls have been transferred to the basket on chair B.

Figure 4

In this image we can see a group of people playing a game.

<!-- image -->

## UNIT 12   |   TABLE TENNIS

## ACTIVITY 2

Perform the same activity by placing 2 baskets at the two ends of the table (see figure 5 &amp; 6).

<!-- image -->

Figure 5

<!-- image -->

Figure 6

NOTE: For a better balance, it is essential to keep the knee flexed to lower the center of gravity.

## LET'S DO IT

## Playing straight / down the line (In pairs)

## ACTIVITY 1

Player  A  performs  the  forehand  drive and  player  B  performs  the  backhand drive down the line (see figure 7).

Player A Forehand Drive

## ACTIVITY 2

Player B performs the forehand drive and player A performs the backhand drive down the line (see figure 8).

Player A Backhand Drive

NOTE : The body position changes for the forehand  drive.  The  left  foot  and  the  left shoulder are placed slightly forward.

In this image there is a blue color chart.

<!-- image -->

- -Count the maximum number of rallies with your partner by performing the forehand drive and the backhand drive down the line.
- -Use the forehand push and the backhand push to perform the same drill.

In this image, we can see a diagram.

<!-- image -->

## Combining forehand and backhand

## ACTIVITY 1

Player 2 uses his forehand to send the  ball  at  2  different  points  of the table (one at the  middle and the other on the right hand side)  and  player  1  performs  the chasing  steps  to  play  the  ball at  the  2  different  points  using forehand (see figure 9).

The image presents a graph titled "Player 2." The graph is a line graph with a blue background. The x-axis is labeled "Player 1" and the y-axis is labeled "Player 2." The graph shows the values of the player's scores for each player.

The line on the graph is a straight line, indicating that the player's scores are equal for each player. The line is drawn from the bottom left to the top right of the graph. The graph shows that the player's scores for Player 1 are 0, Player 2 is 0, and Player 3 is 0. The player's scores for Player 2 are 0, Player 3 is 0, and Player 4 is 0.

The graph also shows that the player's scores for Player 3 are 0, Player 4 is 0, and Player 5 is 0. The player's scores for Player 4 are

<!-- image -->

## ACTIVITY 2

Player 2 uses his forehand to play the  ball  at  2  different  points  of the  table  (one  on  the  backhand side  and  the  other  on  the  right hand side of the table) and player 1  performs  the  chasing  steps  to play the ball by using backhand and forehand alternately (see figure 10).

The image depicts a horizontal line graph with two axes labeled "Player 1" and "Backhand." The x-axis is labeled "Player 1" and the y-axis is labeled "Backhand." The graph has a blue background with a white grid.

### Graph Description:
- **Title**: The title of the graph is "Backhand."
- **X-Axis**: The x-axis is labeled "Player 1" and has a label "Player 1."
- **Y-Axis**: The y-axis is labeled "Backhand" and has a label "Backhand."
- **Lines**: There are two lines on the graph:
  - **Line 1**: This line starts at the bottom left and extends upwards to the top right.
  - **Line 2**: This line starts at the bottom left and extends downwards to the top right.

### Analysis:
- **Player 1**: The line on the

<!-- image -->

## Backhand serve

## Ready Position

<!-- image -->

- Keep your feet shoulder width apart and square on to the table
- Bend your knees
- Place the racket in front of you and the ball on the palm of your non-racket hand

Figure 11

## Backswing

Player 2

Forehand

## Foreward Movement

<!-- image -->

- Toss the ball up vertically
- Move your racket back and behind the ball

Figure 12

<!-- image -->

- Close the racket angle
- Move your racket forward to hit the ball

Figure 13

## Follow Through

<!-- image -->

- Complete your movement with the racket in the direction of the ball

Figure 14

## LET'S DO IT

## ACTIVITY 1

- (i)  Serve  the  ball  10  times  diagonally  and  count  the  number  of success.
- (ii)  Serve the ball 10 times down the line (straight) and count the number of success.
- (iii) Target Serving Game (see figure 15).

Place two hoops or 2 A4 sheets of paper on the opponent's side of the table. Count how many times you hit the A4 sheets of paper or make the ball bounce in the hoops. One point is scored for every success.

## UNIT 12   |   TABLE TENNIS

<!-- image -->

## Introduction to Spin

Nowadays, the use of spin is the most dominant stroke in table tennis. Spin is  imparted onto the ball by using a tangential brushing action with your racket (see figure 16). The brushing action is crucial to be able to impart more spin in the ball. The faster your racket brushes against the ball, the more spin you will impart onto it.

<!-- image -->

A table tennis ball can rotate in different direction. The type of spin imparted onto the ball depends on the direction of the brushing action of the racket onto the ball. It can be upward, downward or sideways.

The basic types of spin:

1. Top spin : If you want to impart top spin onto a ball, start your stroke below the ball and brush your racket against the ball in an upward and forward motion (see figure 17).

Figure 17

<!-- image -->

## LET'S DO IT

## ACTIVITY 1

- Drop/release the ball at a reasonable height on the table.
- Use your forehand to brush it upward and forward to the other side of the table when it reaches the peak of the bounce.

Figure 18

<!-- image -->

## ACTIVITY 2

- (i)  Draw a circle or place a target diagonally on the other side of the table (see figure 19).
- (ii) Using  forehand  perform  activity  (1),  10 times and count the number of successful shots into the target.

<!-- image -->

## Back spin

To impart back spin onto the ball, start your stroke above the ball and brush your racket against it in a downward and forward motion (see figure 20).

<!-- image -->

## LET'S DO IT

Figure 20

## ACTIVITY 3

Perform Activity 1 and 2 by imparting back spin onto the ball.

<!-- image -->

## Did you know

## Effects of spin

When you impart top spin onto a ball, after  it  bounces  on  the  table,  it  will stay low and will accelerate forward. When the ball touches the opponent's racket (placed vertically) it will move upward (see figure 21).

When  you  impart  back  spin  onto  a ball,  after  it  bounces  on  the  table, it  will  rise  slightly  up  but  will  not go  as  far  forward.  When  the  ball touches the opponent's racket (placed vertically)  it  will  move  downward (see figure 22).

Figure 21

In this image, we can see a diagram.

<!-- image -->

Figure 22

In this image, we can see a diagram.

<!-- image -->

## ATHLETICS DISCUS THROW

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about the:

- grip
- familiarization activity
- standing throw

## Introduction

## History

The discus throw can be traced as early as in the ancient Greek Olympic Games in the 708 B.C which was part of the  Greek's  pentathlon  event.  Myron  sculpted  a  very famous statue 'Discobolus' to represent this event back in the 5 th   century B.C as shown in figure 1. Discus has been  an  event  in  the  first  Modern  Summer  Olympic Games  in  1896.  Today  the  discus  throw  is  included in  all  track-and-field  meets  at  all  levels,  and  in  the Olympic Games.

Figure 1

<!-- image -->

## LET'S DO IT

## ACTIVITY 1 (The grip)

1.  Place the discus in your throwing hand.
2.  Spread fingers out with index finger in line with the wrist as shown in figure 3.
3.  Place  the  thumb  over  the  discus  as shown in figure 4.

Figure 3

<!-- image -->

## UNIT 13

Figure 2: Replica of the discus used in the Ancient Olympic Games

<!-- image -->

Figure 4

<!-- image -->

## ACTIVITY 1 (Familiarisation)

1.  Stand with the feet shoulder width apart.
2.  Place the discus in your throwing hand as shown in figure 5.
3.  Swing the discus forth and back up to your shoulder level.
4.  Swing the discus and from right to left.
5.  Hold the discus and make the figure of eight.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Figure 5: Swing the discus forth and back upto your shoulder level.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Figure 6: Swing the discus and from right to left.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Figure 7: Hold the discus and make the figure of eight.

<!-- image -->

## Did you know

## Safety measures

1. Warm-up  and  cool-down before and after the event respectively.
2. Students not throwing must be behind the thrower  in  a  marked  off area of minimum 5 metres away.
3. Thrower must never release discus  if  there  is  someone in the throwing area.
4. Carry back  the  discus in your hands instead of rolling it.
5. Use  a  towel  to  dry  a  wet discus to avoid unnecessary early release of the discus.
6. The  weight  of  the  discus should be chosen according to your category:
-  Under  14  years,  600g  for girls and 800g for boys.
-  Under  15years,  1kg  for both gender.

<!-- image -->

<!-- image -->

<!-- image -->

## UNIT 13   |   ATHLETICS

In this image we can see a group of people standing on the ground. In the background there are buildings and the sky.

<!-- image -->

Figure 8

<!-- image -->

## ACTIVITY 2 (Discus bowling)

Figure 9

In this image we can see a group of people standing on the ground. We can also see some objects and the sky.

<!-- image -->

- Place discus in the throwing hand with proper grip.
- Bowl the discus forward on the ground in a clockwise direction leaving the index finger as shown in figure 8.
- Do the same activity but this time throw the discus forward in the air as shown in figure 9.

<!-- image -->

## STANDING THROW

Figure 10 : Standing throw is for beginners

In this image we can see a group of people. We can also see some trees and a wall.

<!-- image -->

## Stance

1.  Stand  perpendicular to the throwing direction
2.  Place your feet shoulder width apart.
3. Align the toe of your throwing leg with the heel of your nonthrowing leg (heeltoe alignment)
4.  Hold  the  discus  with your  throwing  hand with a proper grip by the side of your nonthrowing at shoulder level (figure 10)

## Execution

1.  Swing the discus sideward and back ward while flexing your non-throwing knees and twisting the hip
2.  Swing the discus forward in a wide arc while  extending  the non-throwing knees and twist the hip forward
3.  Release the discus in front  of  you  above the shoulder (around eye level) in the sector

<!-- image -->

## Follow through

1.  Continue to swing the arm  in  the  direction of the throw
2.  Bring  your  rear  foot forward
3.  Shift your body weight on it so as not to step out of the rim

## LET'S DO IT

## ACTIVITY 1 (Hula hoop throw)

- Hold the hula hoop in your hand, with your arm extended.
- Step into your throw with the opposite foot, driving your legs, hips, and chest while swinging your arm around the body.
- Keep the arm slightly below your shoulder, and release the hoop in front of your body around eye level.

## UNIT 13   |   ATHLETICS

Figure 11

<!-- image -->

## ACTIVITY 2 (Skip throw)

- Stand with legs shoulders wide apart.
- Position yourself in the throwing direction.
- Place the discus in your throwing hand.
- Hold the discus properly and swing it forward and throw it in the throwing sector.

Figure 12

<!-- image -->

## Some important rules regarding discus throw -

1.  The discus is thrown within the circle.  It is considered as a foul if:
- An athlete leaves the circle before the landing of the discus.
- After the throw, athletes get out of the circle through the front half of the circle.
- During the course of the throw, athletes touch the top of the rim or any part outside. However, they can touch the inner part of the rim.
- The discus does not land within the landing area or on the lines.
2.  Athletes are not allowed to wear gloves.

## ATHLETICS

## RELAY RACE

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about the:

- 4 x100 metres relay race
- exchange of the relay baton

## Introduction

A relay race consists of a team of four sprinters. It is a track and field event in which athletes run a pre-set distance while carrying a relay baton before passing it onto the next runner in the team.

## Running the 4 x 100 metres relay race

In the 4 × 100 metres relay race:

- each team consists of four sprinters running one at a time in a single lane  assigned  to  the  team  (see figure 1). Each sprinter covers 100 metres.
- the exchange of the relay baton is done in the' takeover zone ' which is of 30 metres.
- the  one  carrying  the  relay  baton is known as the incoming runner and the one receiving it, is known as the outgoing runner .
- the  outgoing runner at the starts of his/her race should adopt the 3 points start (is a position similar to a crouch start 'set' position - but with only one hand in contact with the ground) see figure 2.
- there  are  two  methods  of  relay baton exchange namely; visual (4  ×  400  metres)  and  non-visual (blind - 4 × 100 metres).

Figure 1

In this image, we can see a diagram with a circle.

<!-- image -->

Figure 2: showing how to hold the relay baton at the start of the race.

<!-- image -->

<!-- image -->

## UNIT 13   |   ATHLETICS

Table 1: shows the technical characteristics of the 4 x100 metres relay race .

| Sprinter                                      | Starting line   | Hand holding the baton   | Approach                                                                      | Type of exchange                                                  |
|-----------------------------------------------|-----------------|--------------------------|-------------------------------------------------------------------------------|-------------------------------------------------------------------|
| First (lead-off) Second Third Fourth (anchor) | 400 320 220 120 | Right left Right Left    | Inside of the lane Outside of the lane Inside of the lane Outside of the lane | Inside exchange Outside exchange Inside exchange Outside exchange |

Table 1

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 2: represents the technical characteristics of relay baton exchange.

| Technique   | Position and placement of hand of outgoing runner                                                                                                  | Action of incoming runner                                                              | Illustrations                |
|-------------|----------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|------------------------------|
| Upsweep     | • Hand backward at hip level with the palm facing down (see figure 3) • Wide angle between the thumb and the rest of the fingers (see figure 4)    | Pass the relay baton in an upward movement into the receiving hand (see figure 5)      | Figure 3 Figure 4            |
| Downsweep   | • Hand extended backward in a horizontal position. • Palm facing up with a wide angle between the thumb and the rest of the fingers (see figure 6) | Passes the relay baton in a downward movement into the receiving hand (see figure 8) 1 | Figure 6 Figure 7 3 Figure 8 |

## LET'S DO IT

## ACTIVITY 1(Good morning game)

## a) with ball (with 3 or 4 partners)

- Your friends and you jog around freely in an open space.
- You hold a ball while jogging.
- When you come across your friend, give the ball to him/her and say good morning.
- He/s will repeat the same with another friend.

## b) with relay baton

- Practise the game as above, but this time with a relay baton.

## ACTIVITY 2 (Shuttle relay game with 6 partners)

- Have 2 groups of 3 persons namely group A and B.
- Each group stands 20 metres apart in a single line while facing each other.
- The person standing in front of group A, holds a relay baton and runs to pass the relay baton to the front person of group B (see figure 9).
- After handling the relay baton, the person moves to the back of group B.
- The first runner of group B, runs to pass the relay baton to the new person standing in front of group A.
- Repeat the action till all of your friends have completed the game and go back to the initial position in your group.

<!-- image -->

<!-- image -->

In this image we can see a group of people running on the ground. In the background there are trees, buildings, poles and the sky.

<!-- image -->

<!-- image -->

<!-- image -->

Figure 9

<!-- image -->

## ACTIVITY 3 (Exchange of the relay baton)

## a) from stationary position (with 4 partners):

- you and your friends stand in a line with two arms distance.
- the 4 th person stands to the left of the 3 rd one, the latter stands to the right of the 2 nd one which in turn stands to the left of the 1 st one (see figure 9).
- the  4 th partner  of  the  team  gives  a  command  (for  instance, main). On hearing the command, without looking backward, the  3 rd person extends his/  her  arm. The  4 th partner  uses  the downsweep technique to pass the relay baton (see figure 10).
- after  receiving  the  relay  baton,  the  3 rd partner  of  the  team gives a command. On hearing the command, without looking backward, the 2 nd partner extends his/ her arm. The 3 rd partner uses the downsweep technique to pass the relay baton.
- after  receiving  the  relay  baton,  the  2 nd partner  of  the  team gives a command. On hearing the command, without looking backward, the 1 st partner extends his/ her arm. The 2 nd partner uses the downsweep technique to pass the relay baton.
- repeat the same exercise using upsweep technique.

Figure 9

<!-- image -->

## b) Repeat the same activity using the:

- i)  downsweep technique while walking.
2. ii)   upsweep technique while walking.
3. iii) downsweep technique while running.
4. iv) upsweep technique while running .

<!-- image -->

## c) Blind/ non- visual exchange of the relay baton (in pairs)

Figure 10

## Variation 1

- The outgoing runner (O) stands around 5 metres to the right side of the incoming runner (I) and a cone is placed in between the two runners (see figure 11).
- 'I'  holding a relay baton in his/her right hand, start walking towards 'O' .

Figure 11

In this image we can see a group of people. We can also see the ground, poles, grass, fence, and some objects.

<!-- image -->

## UNIT 13   |   ATHLETICS

- 'O'   rotates  his/her  head  to  the  left  to  look  at the  moment  when  'I'  reaches  the  cone  (see figure 12).
- 'I'  gives a command when he/she is at two arms distance from 'O' (see figure 13.1).
- On  hearing  the  command, 'O'extends  his/her  arm  back  without  slowing  or  stopping (without looking backward) (see figure 13.2). 'I' hands over the relay baton (see figure 13.3):

Figure 12

<!-- image -->

Figure 13.1

<!-- image -->

<!-- image -->

<!-- image -->

Figure 13.2

- i)  using the downsweep technique.
2. ii) using the upsweep technique.

## Variation 2

Repeat the same exercise but this time exchange of the relay baton is done from left hand ('I') to right hand ('O').

## Variation 3

Repeat the variation 1 and 2 but this time switch roles ('O' becomes 'I' and vice versa).

## Variation 4

Repeat all of the above variations but this time while:

- i) jogging (increase the distance among the runners to 10 metres, and the cone is placed at about 4 metres behind 'O') (see figure 14).
2. ii)  running (increase the distance among the runners to 20 metres, and the cone is placed at about 7 metres behind 'O') (see figure 15).

Figure 14

<!-- image -->

<!-- image -->

<!-- image -->

Figure 15

In this image we can see a track and a track track. There is a person in the track. There is a track boundary. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is a track boundary with a track. There is

<!-- image -->

Figure 13.3

## HURDLES ATHLETICS

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about:

- sprinting over low hurdles
- 100 metres hurdle race

## Introduction

It  is  a  track  event  where  one  needs  to run in his/ her assigned lane from start to finish over a given numbers of obstacles called hurdles (see figure 1). Although it is  allowed  to  knock  hurdles  down  while running  over  them,  it  is  not  allowed  to trail  a  foot  or  leg  alongside  a  hurdle  or knock it  down  with  a  hand.  In  standard competitions, men have the 110 and 400 metres  hurdle  race  while  women  have the 100 and 400 metres hurdle race.

<!-- image -->

In this image, we can see a diagram. There is a text on the image.

<!-- image -->

Did you know

Figure 1

For the Under 16 category, hurdles are set as in the table 1 below.

| Gender   | Distance of Race (Hurdles)   |   Number of Hurdles | Height of Hurdles   | Distance from starting line to 1 st Hurdler   | Distance in between hurdles   | Distancefrom last hurdle to finishing line   |
|----------|------------------------------|---------------------|---------------------|-----------------------------------------------|-------------------------------|----------------------------------------------|
| Female   | 100m                         |                  10 | 0.76 metres         | 12m 00                                        | 8m00                          | 16m 00                                       |
| Male     | 100m                         |                  10 | 0.84 metres         | 13m 00                                        | 8m50                          | 10m 50                                       |
| Female   | 300m                         |                   8 | 0.76 metres         | 50m 00                                        | 35m 00                        | 40m 00                                       |
| Male     | 300m                         |                   8 | 0.84 metres         | 50m 00                                        | 35m 00                        | 40m 00                                       |

## Skill: 100 metres hurdle race

## Start of the race

- Take a crouch start with the lead leg (the leg  that  attacks  the  hurdle  first-  usually your dominant foot) in the back position in the starting blocks.
- Use eight strides to run to the first hurdle and clear it with the lead leg (see figure 2). Remember to run 'into' the hurdle, do not jump.

## Take off phase

- To have a good take off,the hip, knee and ankle joints of the support/trail leg should be fully extended (as 1 in figure 3) and the thigh of the lead leg swings rapidly to the horizontal position (as 2 in figure 3), with the opposite arm in front.

## Clearance Phase

- After the take off phase, there is the clearance  phase,  where  the  lead  leg  is actively lowered as quickly as possible after the hurdle (as 1 in figure 4).

## Landing Phase

- The landing leg (lead leg) is rigid and is on the ball of the foot so as to maintain the speed (as 1 in figure 5).
- The trail leg stays tucked (folded) until touchdown of the lead leg, then it extends quickly and actively forward (as 2 in figure 5).

## 3 strides rhythms in between the hurdles

- Usually,  three  strides  are  being  used  in between  hurdles  to  have  same  lead  leg as  shown  in  figure  6  (short-long-short) but  if  you  find  the  distance  in  between the hurdles too long, then, either you use a  four  strides  rhythms  (you  will  have  to change your lead leg after each hurdle) or five strides rhythms (you will have smaller strides  which  will  make  you  lose  some precious time).
- After  having  cleared  all  the  10  hurdles, sprint to finish the race.

<!-- image -->

Figure 2

<!-- image -->

Figure 3

<!-- image -->

Figure 4

Figure 5

In this image we can see a person wearing yellow color dress and standing on the ground.

<!-- image -->

Figure 6

<!-- image -->

## LET'S DO IT

## ACTIVITY 1 (Stepping over cones)

- Step  overscattered  short  cones  placed  on  the ground (see figure 7).
- Step  over  scattered  medium  cones  placed  on the ground.
- Step over scattered high cones placed on the ground.

## UNIT 13   |   ATHLETICS

<!-- image -->

## ACTIVITY 2

- From a starting position, place a stick on the ground (starting line).
- Count 16 walking strides and place another stick on the ground.
- Then place two sticks at 9 walking strides interval.
- A last stick at 18 walking strides is placed (see figure 2).
- i. From a standing start, walk from the start and step over the sticks placed on the ground.
- ii.  From a standing start, run with 8 strides from start to first stick and 3 strides between the following sticks.
- iii. Same as ii, but this time the sticks are placed on reversed cones (see figure 9):
- run fast with a smooth action.
- do not slow down before or after the obstacles.
- while clearing the obstacles, running action should not be interrupted.
-  do not jump over the obstacles.
- run fast until past the finish line.
- iv. Same as ii but this time, the sticks are placed on top of lower cones (see figure 10).
- v.  Same as ii, but this time, the sticks are placed on top of higher cones.
- vi. Same as ii, but this time, reversed hurdle are placed (see figure 11).

Figure 8

<!-- image -->

<!-- image -->

<!-- image -->

Figure 9

Figure 10

<!-- image -->

Figure 11

<!-- image -->

## ACTIVITY 3

- Hurdles are placed at the lowest height, one and a half metres apart, you now walk by the side of the hurdles:
- i. using  the  left  leg  as  lead  leg  to  clear  the hurdles (to the right if the hurdle as shown in figure 12).
- ii.  using  the  right  leg  as  lead  leg  to  clear  the hurdles (to the left of the hurdle).

## NOTE:

- Drive the lead knee high towards the hurdle (as 2 in figure 12).
- Extend the heel across the hurdle (as 3 in figure 12).
- Pull the foot actively back to the floor on the far side of the barrier (as 3 in figure 12).
- Action performed in line with the running direction.

<!-- image -->

Figure 12

<!-- image -->

iii. using the left leg as trail leg to clear the hurdles (to the right of the hurdle as shown in figure 13).

In this image we can see a collage of images. In the images we can see a person standing on the ground and holding a racket.

<!-- image -->

<!-- image -->

## NOTE:

Figure 13

- lead leg on the ground to the side and ahead of the hurdle (as 1 in figure 13).
- lean forward (as 2 in figure 13) and pull the trailing leg up and over the side of the hurdle (as 2 in figure 13).
- pull the trail leg knee towards the armpit (as 2 in figure 13).
- turn the small toe up towards the sky as the foot passes over the hurdle (as 2 in figure 13).
- as the knee passes the hurdle, it continues to be pulled through until it is back in the line of running (as 4 in figure 13).

iv. using the left leg as trail leg to clear the hurdles (to the right side of the hurdle).

## ACTIVITY 3

- Hurdles at the lowest height are placed one and a half metres apart and you move over the hurdle while walking first leading with the right foot (see figure 14), then the other foot. After some trials you will know which foot you will use to lead.

Figure 14

<!-- image -->

<!-- image -->

## ACTIVITY 4

- Same exercise as 4 but this time, the hurdles are placed 4-5 metres apart and try move over the hurdles while jogging.

## ATHLETICS

## TRIPLE JUMP

<!-- image -->

## Learning Outcomes

## In this chapter you will learn about the:

- different phases of triple jump

It is a field event where participants have to run along a runway, take off from a wooden board (take off board) with a hop followed by a step then jump (horizontally) and land with both feet together. It was introduced at the inaugural Modern Olympic Games in 1896. At that time, the event comprised of two hops and a jump before being standardized in 1908 as the hop, step and jump.

## The phases of Triple jump

There are four phases involved in triple jump: the Approach, Hop, Step and Jump (see figure 1).

In this image, we can see a chart.

<!-- image -->

1. The  approach run  consists  of  generally  10-20  strides,  (depending  on  your  level). The  frequency  of  which  must  be  increased  at  the  end  of  the  approach.  However,  the run-up must be smooth with a maximum controllable speed.
2.  The hop starts  as  soon  as  your  take off foot (usually your dominant  leg) strikes  the  take-off  board.  Immediately after,  your  free  leg  (airborne  leg/non dominant) is driven forward horizontally then drawn backward. After that, the take off leg is drawn forward and upward,then extended for the touchdown (preparation for the step).

Figure 2

<!-- image -->

NOTE: Keep your trunk upright.

3. The step must be performed with an active and quick foot plant of your  dominant  foot  which  is  almost completely extended. Swing both arms forward, bring the thigh of the free leg higher than horizontal (as 1 in figure 3). Keep  your  trunk  upright.  Extend  your free  leg  (preparation  for  jump)  as  2  in figure 3.
4.  The jump is  a  powerful  take  off  at  an optimum  angle  (as  1  in  figure  4).  Your non-dominant foot plant should be active,  quick  and  straight  during  take off.  Swing  both  arms  forward,  use  the hang  or  sail  technique  and  landing  on both feet.

Figure 3

<!-- image -->

Figure 4

<!-- image -->

## LET'S DO IT

## ACTIVITY 1(Double legs hops over laths/ sticks)

- Place laths, four to five foot length apart on the ground and hop with both feet over them rhythmically (see figure 5).

<!-- image -->

<!-- image -->

3

Figure 5

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ACTIVITY 2 (Single leg hop over laths)

- Repeat activity 1, but this time using single leg hop your: i.  right foot (see figure 6). ii. left foot.

Figure 6

In this image we can see a group of people running on the ground. We can also see some grass, trees, buildings and some other objects.

<!-- image -->

## ACTIVITY 3 (Hop-step-hop over low obstacles)

- Place low obstacles six foot length distance apart.
- Start the exercise by: hopping on one leg (as 1-3 in figure 7),then step on the other leg (as 3-6 in figure 7), before hopping on the same leg again (as 6-8 in figure 7), in rhythm.

Figure 7

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ACTIVITY 4 (Short approach step and run)

- Using a short approach run (as 1-3 in figure 8), perform a step (taking off using your right foot and land on the opposite one) (as 4-6 in figure 8). Just after landing continue to run (as 7- 9 in figure 8).
- Same as above, but for now for the step, take off is done by using the left foot and land on the opposite one.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

6

Figure 8

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ACTIVITY 5 (Short approach hop and run)

- Using a short approach run (as 1-2 in figure 9), perform a hop (taking off using your left foot and land on the same foot) (as 3-5 in figure 9). Just after landing continue to run (as 6-7 in figure 8).
- Same as above, but now for the hop, take off is done by using the right foot and land on the same foot).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Figure 9

<!-- image -->

## ACTIVITY 6 (Short approach hop, step and run)

- Using a short approach run (as 1-3 in figure 10), perform a hop(taking off using your left foot and land on the same foot) (as 4-6 in figure 10). After that perform a step(as 7-8 in figure 10). Just after landing, continue to run (as 9 in figure 10).
- Same as above, but now for the hop, take off is done by using the left foot and land on the opposite one.

Figure 10

In this image we can see a collage of images. In the center of the image we can see a person running. In the background we can see a fence, stairs and a wall.

<!-- image -->

## ACTIVITY 7 (Short approach hop, step and jump)

- Using a  short  approach  run  (as  1  in  figure  1),  hop  with  your  dominant  foot  (as  2-4  in figure 11), step (as 5 in figure 11) and jump (as 6 and 7 in figure 11).
- Same as above but now increase the approach run and try to run faster (as you increase the  approach  run  and  its  speed,  you  need  to  increase  the  length  of  the  zone  for  the take off also).

In this image we can see a group of people. We can also see the ground, poles, ropes, and some objects.

<!-- image -->

Figure 11

<!-- image -->

## ATHLETICS

## CROSS COUNTRY RUNNING

## Learning Outcomes

## In this chapter you will learn about the:

- benefits of long distance
- technique of cross country running without fatigue

Cross country is a race where individuals or teams have to compete against each other to complete a relatively long  distance  course  in  the  minimum  time.  Athletes often regulate their pace according to the distance of the course to give their best performance.

<!-- image -->

In  Mauritius,  most  of  the  tracks  used  before  crosscountry were in sugarcane fields or in the nature. But now, the tracks are as per the recommendations of the International Amateur Athletics Federation (IAAF) and are usually run over a distance of 3-12 km depending on the category of the participant.

The course as per the IAAF recommendations normally includes:

- running  surfaces  of  grass,  soil  or  gravel  or  a combination of the three.
- frequent and smooth turns.
- ascending elevation when running on hills.
- one or more loops.
- a  straight  line  start  and  another  leading  to  the finish line.

Anyone who can run, only needs an appropriate pair of shoes and motivation to indulge in this activity. Cross country running can take place almost anywhere and is cost effective. However, training is important for the athlete to be able to sustain effort for a long period of time.

According to the Mauritius Athletics Association (MAA), the recommended distance for different categories are as shown in table 1 (on next page):

Figure 1

<!-- image -->

## Did you know

Cross country doesn't hold a national or world record because  the  distance  and  the difficulty level of the tracks.

Cross  country  is  a  method  of training to build  up  aerobic capacity  (endurance)  in  many sports event.

## UNIT 13   |   ATHLETICS

<!-- image -->

| MenCategory         | WomenCategory       | Recommended distance (this mayvary)   |
|---------------------|---------------------|---------------------------------------|
| U12 U14 U16 U18 U20 | U12 U14 U16 U18 U20 | 1.4km 2.3km 3km 4.2km 6km 6.5km       |

Table 1

## Scoring as a team in cross country

Cross Country as a team is usually made up of six runners. The top four runners are the 'scoring' members and the remaining two have the important job of displacing the scorers on opposing teams. Points are awarded to the individual runners of eligible teams, equal to the position in which they cross the finish line (first place gets 1 point, second place gets 2 points, etc.). The points for these runners are summed and the team with the lowest score wins.

## Equipment

It is advisable to be as light as possible to run a cross country.

## Training shoes

These should be well cushioned to avoid blisters and also acts as shock absorbers to prevent joints/shin injury.

Figure 2

<!-- image -->

<!-- image -->

## Cross country running technique

- Run in a tall upright posture to allow: 1. maximize length of your strides 2. efficient breathing.
- Relaxed and run with arms movement lower than your shoulder and higher than your hips.
- Strike your mid-foot on the ground (not the heel).

Figure 3

<!-- image -->

## UNIT 13   |   ATHLETICS

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| PHASES                                | CUES                                                                                                                               | PICTURES   |
|---------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|------------|
| Running up hill COM V ø F F 0 0 λ COM | • Lean slightly forward • Rise on your toes • Keep your arms active • Attack the hill to gain ground • Manage your energetic level |            |
| Running down hill                     | • Lengthen your strides • Let things go but keep control of your movements                                                         |            |
| Turns                                 | • Change pace and direction quickly to gain ground on opponent                                                                     |            |
| Arm swing and racing stride           | • Swing your hands down to the hip and back at shoulder height • Keep short arms movements to create efficient strides             |            |
| Foot strike                           | • Strike your mid-foot or ball of the foot so as not to slow down                                                                  | x ✓ ✓      |
| Running on uneven smooth surface      | • Shorten your stride length • Increase the frequency of your strides • Make constant adjustments to maintain balance              |            |

## Tips to run a Cross Country

- Prepare for a minimum of 3 weeks.
- Hydrate well, eat healthy and sleep for at least 8 hours daily, days before the race.
- Prepare yourself mentally and try to make a mental imagery of your race.
- Eat 3-4 hours prior to your race (but never run with an empty stomach).
- Double tie the laces of your running shoes.
- Arrive early at the site of competition to familiarise with the track (by walking or jogging) to devise your running strategy.
- Warm up well before competition.

## NOTE:

Cross country training requires other qualities like muscles strength, cardio and not only endurance. Strength, power and speed are also important to be able to perform well in Cross Country.

## Here are some training exercises to help you improve in this activity:

Continuous training: also known as continuous exercise, is any type of physical training that involves activity without rest intervals. Continuous training can be performed at low to moderate intensity, and is often contrasted with interval training.

Interval training: a type of training that involves a series of low to high-intensity workouts broken by rest periods. The high-intensity periods are typically at or close to anaerobic exercise, while the recovery periods involve activity of lower intensity.

Fartlek: a Swedish term that means 'speed play,' is a form of interval or speed training that can be effective in  improving your running speed and endurance. Fartlek running involves varying  your  pace  throughout  your  run,  alternating  between  fast  segments  and  slow  jogs. Fartlek, combine both continuous and interval approaches.

## Circuit training (refer to page 37 - 42)

Your circuit training needs to include workout lasting from 1 - 3 minutes. Your goal will be to increase endurance level. For that, your circuit session should be of 30 minutes at least.

## LET'S DO IT

## ACTIVITY 1 (Continuous training)

Aim: to run for a minimum of 20-30 minutes per day. How to achieve your aim?

Start with 5 minutes slow running. As your body gets used to it, add 3 minutes to your exercise. If your body adapts  well,  you  can  reach  20-30  minutes  jogging within 3-4 weeks. You may even increase your running intensity and duration gradually.

Figure 4

In this image, we can see a diagram. In the diagram, we can see a person holding a book. We can also see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person holding a book. We can see a person

<!-- image -->

## ACTIVITY 2  (Interval training)

Run for 1 minute at tempo pace (high intensity) followed by 3 minutes recovery between each repetition. The  exercise  can  be  repeated  5-10 times according to your fitness level.

## ACTIVITY 3  (Fartlek)

Run  for  30  seconds  continuously  with  high intensity  followed  by  30  seconds  of  jogging, then  again  run  for  30  seconds  continuously with high intensity.

Repeat this activity for at least 5-10 times.

## ACTIVITY 4  (Circuit training)

Insert 5-6 stations and spend maximum of time on each station.

Figure 5

<!-- image -->

FARTLEK TRAINING

ADVANTAGES &amp; DISADVANTAGES

Figure 6

In this image, we can see a person running on the road. We can also see some text on the image.

<!-- image -->

## Physiological benefits of Cross Country

1.  Cardiac muscle hypertrophy

The more you run, the harder your heart works and the stronger it gets.

Figure 7

<!-- image -->

2.  Tendons and ligaments become stronger Running boosts your cartilage and strengthens the ligaments around your joints.

<!-- image -->

Figure 8

<!-- image -->

3.  Maintain a steady weight

Runners are more likely to maintain a normal body weight.

Figure 9

4.  Diminish risk of non communicable diseases. Cross Country significantly decreases the risk of diabetes, osteoarthritis, high blood pressure and stroke. (associated with hypokinetic diseases).

Figure 10

<!-- image -->

## Mental benefits of Cross Country

1.  Running  boosts  confidence  level,  relieves  stress  and  fights depression. The brain releases endorphins that naturally improve mood, leaving runners energized and happier.
2.  Cross country running is also very demanding in terms of effort and motivation. A dedicated runner will need commitment and discipline to practise his daily jogging and training session.
3.  It builds one's character and enhances mental strength. Very often the athlete sets personal targets to overcome their own limits.

Figure 11

<!-- image -->

## LET'S DO IT

## ACTIVITY 2

Design your personal cross country training program for 2 weeks.

## FOOD CALORIE CHART

## BREAD, RICE, POTATOES AND GRAINS

| Product and Portion         |   Kcal | Product and Portion       |   Kcal | Product and Portion            |   Kcal |
|-----------------------------|--------|---------------------------|--------|--------------------------------|--------|
| Bread, Garlic 1 slice       |    110 | Pitta bread, plain 1      |    135 | Doughnut, Cake-type, plain 1   |    165 |
| Bread, Oatmeal 1 slice      |     75 | Doughnut, sugared 1       |    185 | Doughnut, Jelly filled 1       |    225 |
| Bread, Raisin 1 slice       |     70 | French Bread 1 slice      |     70 | Croissants, Plain 1            |    310 |
| Bread,Wheatgerm, 1 slice    |     70 | Muffin, English 1         |    135 | Potato 1 small                 |    120 |
| Bread, White plain, 1 slice |     70 | Doughnut, sugared 1       |    185 | Lentils,Green/Brown,boiled113g |    105 |
| Crackers, CrackedWheat 4    |    110 | Croissants, Chocolate 1   |    440 | Kidney Beans, dried 113g       |    268 |
| White rice basmati, 1/2cup  |    330 | Brown rice, 1/2 cup       |    350 | Wheatflakes 28g                |    100 |
| Macaroni pasta 1 cup        |    200 | Sweet potato 1 small      |    146 | Soya Beans, dried 113g         |    375 |
| Peas, split, dried 113g     |    300 | Lentils, Red, boiled 113g |    100 | Peas, canned 113g              |     85 |

NOTE: Food containing high calories are not recommended.

## FRUITS

| Product and Portion         |   Kcal | Product and Portion         |   Kcal | Product and Portion             |   Kcal |
|-----------------------------|--------|-----------------------------|--------|---------------------------------|--------|
| Apple (with the peel)       |     81 | Fig (medium)                |     37 | Orange                          |     65 |
| Apricot                     |     17 | Grapes (10 medium seedless) |     36 | Papaya (1/2 cup cubed)          |     27 |
| Avocado                     |    306 | Grapefruit (1 medium half)  |     46 | Passion Fruit (medium)          |     18 |
| Banana, average size        |    105 | Guava (1/2 cup)             |     42 | Peach                           |     37 |
| Cherries (1/2 cup)          |     52 | Kiwi (medium)               |     46 | Pear (medium)                   |     98 |
| Dates dried/sugar (1/2 cup) |    280 | Lychees 1 oz.               |     19 | Pineapple fresh (1/2 cup cubed) |     39 |
| Date 1 fresh/unsweetened    |      7 | Mango fresh                 |    135 | Plum                            |     36 |
| Melon Cantaloupe (1 half)   |     94 | Nectarine (medium)          |     67 | Prune (1 dried &pitted)         |     20 |
| Melon Honeydew              |     46 | Raisins (dried 1/2 cup)     |    110 | Strawberries (1/2 cup)          |     23 |

## APPENDIX

## VEGETABLES

| Product and Portion           |   Kcal | Product and Portion             |   Kcal | Product and Portion           |   Kcal |
|-------------------------------|--------|---------------------------------|--------|-------------------------------|--------|
| Aubergine (eggplant),raw,100g |     15 | CapsicumPepper,green,raw,100g   |     15 | Cucumber, unpeeled,raw,100g   |     10 |
| Bamboo shoots, canned, 100g   |     11 | CapsicumPepper,red,raw,100g     |     32 | Endive (Escarole), 100g       |     11 |
| Beetroot, boiled, 100g        |     46 | Carrots, young, raw, 100g       |     30 | Garlic, fresh, raw, 100g      |     98 |
| Beetroot, raw, 100g           |     36 | Cassava, streamed, 100g         |    142 | Mushrooms,common,raw,100g     |     13 |
| Broccoli, green, raw, 100g    |     33 | Cauliflower, boiled, 100g       |     28 | Potatoes, new, boiled, 100 g  |     75 |
| Watercress, raw, 100g         |     22 | Corn Kernels, canned, 100g      |    123 | Onions, raw, 100g             |     64 |
| Cabbage white, 100g           |     21 | Courgette (Zuuchini), raw, 100g |     18 | Peas, fresh, raw, 100g        |     83 |
| Radish, red, raw, 100g        |     12 | Pumpkin, raw, 100g              |     13 | Spinach, raw, 100g            |     25 |
| Cabbage red, raw, 100g        |     21 | Tomatoes,canned,&liquid,100g    |     16 | Tomatoes, ordinary, raw, 100g |     17 |

## DAIRY PRODUCT AND EGG

| Product and Portion        |   Kcal | Product and Portion           |   Kcal | Product and Portion            |   Kcal |
|----------------------------|--------|-------------------------------|--------|--------------------------------|--------|
| Fresh whole milk 1 cup     |    150 | Freshmilkfat-free/skimmed1cup |     85 | Carnation, condensed (1/3 cup) |    318 |
| ChocolateMilklow-fat1%1cup |    158 | Soya Milk 1 cup               |     90 | Cream, single (1tbsp.)         |     30 |
| Yogurt, full-fat           |    140 | Yogurt, fat-free              |    100 | Parmesan, grated, 28g          |    110 |
| Mozzarella, 28g            |     80 | English Cheddar, 28g          |    114 | American Cheddar 28g           |    106 |
| Egg white, large           |     16 | EggYolk, large                |     59 | Egg, whole, extra-large 58g    |     86 |

## MEAT, SEAFOOD AND POULTRY

| Product and Portion                        |   Kcal | Product and Portion                       |   Kcal | Product and Portion                         |   Kcal |
|--------------------------------------------|--------|-------------------------------------------|--------|---------------------------------------------|--------|
| White Fish, steamed, 1g                    |     70 | Shrimp, cooked, no shells, 1g             |     90 | Pilchards, canned tomato                    |     95 |
| Venison, lean meat, roasted 3g             |    110 | Sardines, canned, oil, 14g                |    220 | sauce, 4g                                   |     65 |
| Tuna, canned, oil, 9g                      |    190 | Salmon, smoked, 8g                        |    160 | Octopus, raw, 9.5 g                         |     80 |
| Hake, steamed, 1g                          |     90 | Crab, boiled, no shell, 2g                |     78 | Lobster, Boiled, no shell, 1g               |    140 |
| LambShoulder, lean &fat, roasted, 24g      |    290 | Chicken breast, meat &skin, roasted, 6.5g |    165 | Chicken breast, meat &skin, roasted, 3g     |    235 |
| Chicken drumsticks, meat only, roasted, 4g |    150 | Chicken leg, meat& skin, roasted, 11g     |    210 | Chicken drumstick, meat& skin, fried, 13.2g |    190 |

## PHYSICAL EDUCATION: MY FITNESS CARD

Name:

...................................................................................................

Gender:

.....................

Age:

............................

Waist / Hip Ratio:

......................................

Resting Heart Rate:

.................................................

Min HR:

.......................

Max HR:

.......................

Height:

..................................

Weight:

.................................

BMI:

........................................

Any health issues:

.........................................................

.........................................................

.........................................................

Your fitness goal:

...........................................................................................................................................

..................................................................................................................................................................................

..................................................................................................................................................................................

Your nutritional goal:

..................................................................................................................................

..................................................................................................................................................................................

..................................................................................................................................................................................

1. Sit up  (1 min)

2. Push up  (1 min)

3. Speed  (30 m dash)

4. Endurance

(12 m run, walk, jog)

5. Sit and reach

38 - 40

26 - 29

4.3 - 4.4 sec

2.2 - 2.4 km

10.9 - 7.0 cm

29 - 31

17 - 20

4.7 - 4.8 sec

1.6 - 1.9 km

11.9 - 7.0 cm

Fitness Test

Boys

Girls

Average Performance

Results

Remarks

(Age 14 -15)

## MY WEEKLY DIET AND EXERCISE JOURNAL

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| DAYS            | Monday   | Tuesday   | Wednesday   | Thursday   |
|-----------------|----------|-----------|-------------|------------|
| Water           |          |           |             |            |
| Num of glasses  |          |           |             |            |
| Breakfast       |          |           |             |            |
| Num of calories |          |           |             |            |
| Snacks          |          |           |             |            |
| Num of calories |          |           |             |            |
| Lunch           |          |           |             |            |
| Num of calories |          |           |             |            |
| Dinner          |          |           |             |            |
| Num of calories |          |           |             |            |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                    | Exercise         | N o of rep/ set   | Exercise   | N o of rep/ set   | Exercise   | N o of rep/ set   | Exercise   | N o of rep/ set   |
|--------------------|------------------|-------------------|------------|-------------------|------------|-------------------|------------|-------------------|
| Warm up 5 mins     |                  |                   |            |                   |            |                   |            |                   |
| Cool down 3 mins   | Cool down 3 mins |                   |            |                   |            |                   |            |                   |
| Cardio 30 mins     |                  |                   |            |                   |            |                   |            |                   |
| Strength 15 mins   |                  |                   |            |                   |            |                   |            |                   |
| Flexibility 7 mins |                  |                   |            |                   |            |                   |            |                   |
| General Remarks    |                  |                   |            |                   |            |                   |            |                   |

| Friday   | Saturday   | Sunday   | Approximate Amount of Total food intake   | Checklist                                                    | Tick or Cross   |
|----------|------------|----------|-------------------------------------------|--------------------------------------------------------------|-----------------|
|          |            |          |                                           | Do you have sufficient water?                                |                 |
|          |            |          |                                           | Do you skip breakfast?                                       |                 |
|          |            |          |                                           | Are you trying to eat more vegetables?                       |                 |
|          |            |          |                                           | Are you trying to eat more fibers?                           |                 |
|          |            |          |                                           | Do you eat less sugar?                                       |                 |
|          |            |          |                                           | Do you eat less salt?                                        |                 |
|          |            |          |                                           | Do you eat more home-made food?                              |                 |
|          |            |          |                                           | Are you trying to cook at home?                              |                 |
|          |            |          |                                           | Do you read the nutritional facts before buying a food item? |                 |

## TOTAL number of calories intake per week

N o of

N o of

N o of

Exercise rep/

Tick

Remarks on my set

rep/

set rep/

set performance

or Cross

Exercise

Exercise

Checklist

Do you practise a physical activity

at least 3 times per week?

Do you need some support to be active?

Have you been able to meet the goals

you set?

Are you motivated to do physical activity

or sports?