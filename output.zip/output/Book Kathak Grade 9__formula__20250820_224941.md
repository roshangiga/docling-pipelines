In this image we can see a woman dancing.

<!-- image -->

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the

Ministry of Education; Tertiary Education, Science and Technology:

<!-- image -->

In this image I can see the text on the white color background.

<!-- image -->

Based on the National Curriculum Framework (2016)

In this image I can see the watermark on the top left corner. In the middle of the image I can see the text. In the bottom right corner I can see the watermark. In the middle of the image I can see the text.

<!-- image -->

## © Mahatma Gandhi Institute (2019)

All  rights  reserved.No  part  of  this  publication  may  be  reproduced,  stored  in  a retrieval system, or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise, without the prior permission of the Copyright owner.

## Printed by

Veerus Ltd, DBM Industrial Estate, Plaine Lauzun, Mauritius. Tel: (230) 260 93 00

First published 2020 Reprinted 2021

While every effort has been made to trace the copyright holders for reproductions, we might have not succeeded in some cases. We offer our sincere apologies and hope that they will take our liberty in good faith. We would appreciate any information that would enable us to acknowledge the copyright holders in our future editions.All materials should be used strictly for educational purposes.

ISBN: 978-99949-54-32-2

## Performing Arts

## (Indian Music and Dance) Panel

Mr. K. Mantadin

## Project Co-ordinator

(organisation and development), Senior Lecturer (Tabla), Head, Department of Curriculum Development,

Mahatma Gandhi Institute.

- Mr. K. Mantadin

## Panel Co-ordinator

Senior Lecturer (Tabla), Mahatma Gandhi Institute

## Writing Team

## (Kathak)

- Mrs S. Gangoo. Jootun

## Team Leader

Educator (Kathak) - (M.O.E, T.E, Sc.&amp; Tech.)

- Mrs R. Khadoo

Educator (Kathak) - (M.O.E, T.E, Sc.&amp; Tech.)

## Contributors

- Ms. S. Dabee

Senior Lecturer (Bharata Natyam)

Head Department of Decentralisation of Music &amp; Dance, Distance Education &amp; E-Learning, MGI

- Mrs. P.D. Luchman

Educator (Bharata Natyam) - MGI

- Mrs. A.D Bania

Educator (Bharata Natyam),(M.O.E, T.E, Sc.&amp; Tech.)

- Mrs. K.Mahadoo

Educator (Bharata Natyam),(M.O.E, T.E, Sc.&amp; Tech.)

- Dr D. Pentiah - Appadoo

Music Organiser (Oriental), (M.O.E, T.E, Sc.&amp; Tech.)

## Vetter

- Mrs P. Bhiwajee Rama

Educator (Kathak) - MGSS

Proof Reading

- Mrs D.Balaghee

Deputy Rector - MGISS

Graphic Designers (cover, illustration, layout and photography)

- Mr.Vishal Napaul

- Miss.Vaneeta Jatooa

- Ms.Presika Juckhory

## Cartoonist

- Mr.T.K.Mantadin

School of Fine Arts  Student - MGI

## Photography

- Mr.K.G. Moonesawmy ( Pro Foto Plus )

Word Processing Operator

- Mrs. N. Mugon

## Acknowledgements

Mrs S. N Gayan, GOSK, Director General, Mahatma Gandhi Institute and Rabindranath Tagore Institute for her continued advocacy for music education especially Indian Music and Dance.

Dr (Mrs) V Koonjal, Director, Mahatma Gandhi Institute for her unwavering support to this project.

The Performing Arts (Indian Music and Dance) panel is also grateful to the following persons:

Dr.Mrs. S.D.Ramful -

Director Schooling - MGI

Mrs.U. Kowlesser -

Registrar - MGI

Dr.D.Ramkalawon -

Senior Lecturer (Sitar),

-

Head, School of Performing Arts, MGI

Dr. D. Pentiah Appadoo -

Music Organiser (Oriental), M.O.E, T.E, Sc.&amp; Tech.

Dr Pritee.A.Damle -

Lecturer, MS University, Baroda, India

Mr K Nayeck -

Senior Lecturer (Sanskrit), MGI

## Quality Vetting Team

Dr. S.K.Pudaruth

-

Assoc. Professor, Ag.Head, Centre for Quality Assurance - MGI

Ms. T.Toory

-

Educator (Kathak) - MGSS

Mrs B. D Pandoo -

Educator (Kathak) - M.O.E, T.E, Sc.&amp; Tech.

Mrs. L. Ramduth -

Lecturer, Department of Design &amp; Communication

MGI

Mrs.D. R. Maloo -

Educator (English) - MGSS

Administrative Staff

Mrs.H. Chudoory

Administrative Officer - MGI

Mrs. S. Appadoo

Clerical / Higher Clerical Officer - MGI

Mrs. G. Checkooree

Clerical / Higher Clerical Officer - MGI

Mrs. P. Purmessur

Word Processing Operator - MGI

Cover Photo

Ms. T.Toory -

Educator (Kathak) - MGSS

Photo Courtesy

Ms. I. Mohit -

Gaetan Reynal SSS

Ms. P. Hurreba

-

Forest Side SSS

- The parents and their wards for giving us the permission to reproduce their photographs and images in the textbook.

## Foreword

'Where the mind is allowed to stumble upon cascades of emotion and where the surprise of creative exchange comes out of tireless striving towards perfection' Rabindranath Tagore

Should music, dance, arts, drama be taught in schools? Do such subjects matter ?

As in the case of all debate, there are those who are for and those who are against. The  decision,  in  the  context  of  the  reforms  leading  to  the  Nine  Year  Continuous Basic Education, to include teaching of the performing arts in the secondary school curriculum shows that 'the ayes have it.' At least for the time being.

Traditionally, music teaching takes place in a one-to-one mode. The piano teacher teaches one student at a time, so does the sitar guru. Dance is more of a group experience. But for each of these disciplines, the context of institutional level teaching introduces opportunities of reaching a broader cross-section of population, thereby giving rise to fresh challenges. Students come from a variety of social and cultural environments which expose them to different types, genres and registers in the arts. Students also come with different levels of aptitude. These are but two of challenges encountered.

From  another  perspective,  it  has  been  repeatedly  pointed  out  that  the  'digital natives', while definitely coming to learning with resources hitherto not available, may,  in  the  process,  be  losing  their  ability  to  grasp,  decipher  and  understand emotional language. In short they may be losing empathy.

The ultimate aim of arts education in the curriculum is to provide a pedagogical space where the young will be able to explore their own affective responses to forms  of  artistic  expression,  to  develop  sensibility,  while  acquiring  a  whole  set of  skills,  including  not  only  spatial  awareness,  pattern  recognition  or  movement coordination, but also the benefits of group and team work, of joint effort, higher level creative thinking and expression, as well as an overall sense of shared pleasure and of achievement. This is what emotional intelligence is all about.

The specialists who prepared the syllabus and the present textbooks for Indian music and  dance  had  all  the  above  in  mind  while  undertaking  the  task.  The  teacher training for these disciplines needs to be a continuous process of exchange between curriculum developers, teaching practitioners, textbook-writers and learners.

The MGI is particularly happy to be part of this major development, at a time when the country is looking at new avenues for continued economic development, and more importantly at new avenues to enhance equity, social justice and inclusion. It is our small contribution to the 'grande aventure' of holistic education.

Mrs Sooryakanti Nirsimloo-Gayan, GOSK Director-General (MGI &amp; RTI)

## Preface

This textbook is the first instructional material in the field of Performing Arts (Indian Music and Dance) written by a team of experienced Mauritian teachers and experts in Vocal Music, Instrumental Music and Dance.

It has been designed on the Aims, Objectives and the Teaching and Learning Syllabus  of  the  Performing  Arts  from  the  National  Curriculum  Framework (2016), under the Nine Year Continuous Basic Education Programme.

The Performing Arts Curriculum is articulated around four strands: Performing, Creating,  Responding  and  Performing Arts  and  Society. Thus,  the  textbook takes into account the development of key skills and understandings under the four strands.

This set of textbooks for grade 7, 8 and grade 9 lays the foundation in each discipline and provides learners with the essential knowledge, skills and attitudes needed to progress towards higher grades. It also takes into consideration the multicultural nature of our society and its traditions.

This textbook is a support material that gives direction to the educators in the teaching and learning process by linking the curricular components, curricular expectations, pedagogical principles and assessments.

A textbook is not an end in itself like  any  other  instructional  material.It  is  a means to facilitate learning to take place in a continuous and continual manner.

Learning  objectives  in  each  chapter  of  the  textbook  reflect  the  curricular outcomes.  It will help the teacher to design his/her lesson plans which will further ease the teaching and learning transaction towards achievement.  Teachers will have to plan their work so that learning takes place in an effective and efficient way.    They  will  have  to  provide  appropriate  and  enriched  experiences  and modify the teaching and learning strategies according to the needs of learners.

The practical aspects of the discipline have been integrated under 'practical' with step-by-step technique laying emphasis on the mastery of skills from one level to another.

We are aware that children construct knowledge in their own way and have different  learning  styles.The  textbook  has  been  designed  to  cater  for  such needs.

Special  features  and  a  generous  number  of  illustrations,  pictures,  concept maps and activities have been included to promote collaborative learning and other additional skills like team spirit, cooperation and understanding diverse

nature  of  learners.These  would  help  teachers  to  organise  their  interactions at  classroom  level. Teachers  may  give  more  activities,  depending  upon  the availability of resources and time.

Assessments in the form of activities, projects and questions are also included at the end of each chapter.  These are check points to assess the learners.  It will help teachers gather evidences about the expected level of learning taking place in the learners.

I would also request all the Educators to go through the National Curriculum Framework  (2016),  the  Teaching  and  Learning  Syllabus  of  the  Performing Arts (Indian Music and Dance) documents and especially the 'Important Note to  Educators'  which  has  been  provided  in  the  textbook  to  have  a  thorough understanding of the Philosophy and Perspective behind those documents and their implications in the implementation of the Reform process in the education system.

I  hope that this new journey of learning Indian Music and Dance will be an enriching one.

## Mr. K. Mantadin,

Project Co-ordinator - Performing Arts (Indian Music and Dance),

Senior Lecturer (Tabla),

Head, Department of Curriculum Development,

Mahatma Gandhi Institute.

## NOTE TO EDUCATORS

This teaching and learning syllabus of Indian Music and Dance has been designed on the spiral curriculum model in which core components and essential topics are revisited  within  the  three  years.    It  caters  for  both  the  theoretical  and  practical aspects of each discipline.

It also comprises different blocks of knowledge and skills and each block is supported by  specific  learning  outcomes  which  cover  all  the  three  domains  of  learning; cognitive, psychomotor and affective.

The Listening and Viewing component has been integrated in the syllabus as it is a key factor in the development of music and dance abilities. Teachers should provide a wide variety of listening and viewing experiences for learners to stimulate active listening and viewing through questioning, prompting and suggestion.

In  order  to  achieve  the  objectives  of  the  syllabus  and  to  keep  a  good  balance between  theory  and  practical  sessions,  the  teacher  will  have  to  plan  his  /  her work and teaching and learning activities according to the topics to be taught as specified in the scheme of studies.  However, educators may modify the sequence of the topics in which they wish to teach for the smooth running of the course.

## Educators should:

- Ensure that learners use the knowledge, skills and understanding developed from grades 1 -6 and build upon that prior knowledge to construct new knowledge. 1.
- Provide  learning  experiences  that  include  opportunities  for  hands-on  and interactive learning, self-expression and reflection. 2.
- Find a variety of ways to align their instruction with the Aims, Learning Outcomes and Specific  Learning  Outcomes by focusing on active learning and critical thinking. 3.
- Provide learning activities that are appropriate in complexity and pacing. 4.
- Provide opportunities for individual and multiple groupings. 5.
- Actively engage and motivate students in the process of Learning Music and Dance. 6.
- Develop the ability in the learners to use and understand the language of Music and Dance through listening  and  viewing  as  well  as  responding  to  live  and recorded repertoires. 7.

8. Enrich  the  musical  experience  of  the  students  by  gaining  an  understanding of  the  cultural  and  historical  context of music and dance exploring personal connections with them.
9. Carry out active listening and viewing sessions through the use of Information Learning  Technologies(ILT's).    This  will  facilitate  developing  their  investigative and methodological abilities.
10. Model and demonstrate accurate and artistic musical and dance techniques.
11. Differentiate  Music  and  Dance  instruction  to  meet  a  wide  range  of  students needs.
12. Educators should also ensure that learners'
-  Show proper care and maintenance of classroom instruments.
-  Demonstrate respectful behavior as performers and listeners.
- Participate in classroom protocole and traditions for music making and dance.
9. Reinforce effort and provide recognition. 13.
10. Discuss student performances by using peer assessment as a tool. 14.
11. Give opportunities to students to assume various roles in music performances, presentations and collaborations. 15.
12. Motivate students to maintain a musical collection and portfolio of their own work over a period of time.  It can be an individual or group initiative that the learner will undertake under the supervision of the educator. 16.

## Table of Contents

| Chapter 1 - Invocation                          |   1 |
|-------------------------------------------------|-----|
| Chapter 2 - Indian Classical Dance in Mauritius |   9 |
| Chapter 3 - Tatkaar and Chakkar                 |  17 |
| Chapter 4 - Composition Teentaal                |  25 |
| Chapter 5 - Components of Classical Dance       |  35 |
| Chapter 6 - Indian Classical Dance              |  47 |
| Chapter 7 - Costume Make up for Kathak Dance    |  57 |
| Chapter 8 - Expressive Dance Composition        |  71 |
| Chapter 9 - Tala                                |  77 |
| Chapter 10 - Padhant and Notation               |  85 |
| Chapter 11 - Historical Development of Kathak   | 101 |
| Chapter 12 - Creative Exercises                 | 113 |
| Listening and Viewing                           | 121 |
| Glossary                                        | 124 |

In this image we can see a statue, there are some flowers, there are some candles, there are some lights, there is a text on the image.

<!-- image -->

## CHAPTER 1

<!-- image -->

<!-- image -->

In this image we can see a collage of different objects.

<!-- image -->

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Memorise the Guru Vandana
- Write the prescribed Guru Vandana and its meaning
- Explain the prescribed Guru Vandana
- List all the hand gestures while performing the Guru Vandana
- Demonstrate the Guru Vandana with oral explanation and name the hand gestures
- Perform the Guru Vandana with correct anga , symbolic postures, mudras (hand gestures) and suggestive expressions
- Perform the Vandana with complete involvement and sense of reverence
- Recognise the spirituality behind kathak as an art form
- Develop respect for the teacher and discipline towards the class.

## 1.0 Invocation

An invocation is a form of a prayer invoking God's presence, especially offered at the beginning of a religious ceremony.

In Kathak dance, invocation is one of the three main parts of a performance. The other two, as mentioned in the Natya Shastra, are Nritta (pure dance) and Nritya (expressional dance). In the invocation section, the dancer offers respect and gratefulness through reverential dance compositions to the Guru and Hindu deities using hand gestures, facial expressions and dance movements.

Invocations are usually chanted in free rhythm and this dance demonstration brings an atmosphere of peace and serenity on the stage and in the audience.

## 1.1  Vandana

The Sanskrit word Vandana means prayer or worship. Kathak originated in temples and in ancient times, it was important for the dancers to dedicate a dance in the form of a prayer at the beginning of a performance. This tradition has been maintained till today and Vandana-s are devoted to the Guru , Gods and Goddesses with awe and reverence.

## 1.1.1   Guru Vandana

In the field of yoga, meditation and Indian music and dance, a Guru has a very special importance. He is treated with high respect and symbolises the fountain of knowledge under the Guru-shishya parampara , that is, the teacher-disciple lineage. The Guru imparts that knowledge which cannot be otherwise gained through merely reading books. He provides the initial guidance and a deep understanding of the subject. Thus, there is a firm trust of the student and a determination to follow the Guru's words since the latter takes the responsibility for shaping/molding the disciple into what he or she should be. The student that follows the Guru's word with faith, is supposed to be assured of reaching the goals, irrespective of the personal merit of the teacher.

Similarly, the knowledge of music and dance cannot be obtained by merely reading books. In Kathak dance the student often dedicates the Guru Vandana to the teacher from whom the knowledge of the art is being assimilated. Thus, the student praises the Guru and seeks blessings through performing the Guru Vandana as a reverential dance at the beginning of a performance.

In this image we can see a person sitting on the tree trunk. There are some plants and trees in the background.

<!-- image -->

In this image we can see a person standing and holding a stick.

<!-- image -->

## 1.1.2 Dyaan Mulam - Guru Vandana in Kathak

Dhyan Mulam Guru Murati

Pooja Mulam Guru Padam Mantra Mulam Guru Vaakyam Mukti Mulam Guru Kripa Tadaami Guruve Namo Namaha

## Translation:

The root of meditation is the form of the Guru The root of worship is the feet of the Guru The source of mantra is the words of the Guru The source of Liberation is the Guru's grace I bow to such Guru

## Meaning of the shloka:

The root where ' dhyan' (meditation) comes from is the Guru's form. His feet are seen to be as beautiful as lotus flowers and any form of worship a student sadhna (practices) comes from the lotus feet of the Guru . His words are the mantra-s on which the student reflects and meditates. Guru's grace is the root of moksha or liberation which lies only in the Guru's blessings. The disciple bows down to the Guru in total surrender.

## Note to Teacher

Teacher may demonstrate as many hand gestures appropriate in this Vandana . They should also give a list of all the hand gestures used to students.

<!-- image -->

•

An invocation is a form of prayer or worship.

•

A Vandana is an invocation performed at the beginning of a performance in praise of a deity.

- Guru Vandana is an invocation for the Guru .
- ' Dhyaan Mulam… '  is a Vandana dedicated to the Guru .

<!-- image -->

Prayer, nritta, nritya , expressional, reverential, Guru-shishya  parampara ,  high-  respect,  imparts, knowledge, meditation, mantra , worship, liberation, disciple, unwavering, surrender, dedicated.

With  the  help  of  your  teacher,  form  a  group  or pairs. One by one, demonstrate the followings:

- Recite or sing the Guru Vandana .
- Show the hand gestures. Explain each use and meaning as used in the Vandana .
- Interpret with facial expressions the meaning of the words.
- Demonstrate the Vandana using appropriate facial expressions, hand gestures and body movements.

<!-- image -->

After  this  activity,  each  group  should  write  down  or  discuss  the  values learnt in the Guru Vandana . They should reflect upon the kathak dance as an art form portraying gracefully the meaning of words through the various facial expressions, hand gestures and dance movements.

## Assessment

## Exercise 1

## State whether the statements are TRUE or FALSE.

- a) An invocation is a form of prayer or worship. ………….

- b) A Guru Vandana is dedicated to the disciple. ………………

- c) A Guru Vandana is performed as a reverential dance. …………..

- d) An invocation is performed using hastas , bhavas and dance movements. ……………..

- e) Guru Vandana is performed at the end of a performance. …………

## Exercise 2

Fill in the blanks with the correct word.

Dyaan…………….. Guru ………………..

……………….. Mulam Guru ……………..

……………….. Mulam Guru ……………..

……………….. Mulam Guru ……………..

Tudaami ……………. Namo ……………..

## Exercise 3

Explain the meaning of the Guru Vandana ' Dhyaan Mulam …'.

…………………………………………………………………………………

…………………………………………………………………………………

…………………………………………………………………………………

…………………………………………………………………………………..

.................................................................................................................

## Exercise 4

Match  the  statements  in  column  A  with  the  correct  meaning  in column B:

| A                         | B                                              |
|---------------------------|------------------------------------------------|
| Dhyan Mulam Guru Murati   | The source of mantra is the words of the Guru  |
| Pooja Mulam Guru Padam    | The source of Liberation is the Guru's grace.  |
| Mantra Mulam Guru Vaakyam | The root of meditation is the form of the Guru |
| Moukti Mulam Guru Kripa   | I bow to such Guru                             |
| Tadaami Guruve Namo Namah | The root of worship is the feet of the Guru .  |

## Exercise 5

List the hand gestures you used in Guru Vandana .

## 1. Asamyuta hastas

…………………………………………………………………………………

…………………………………………………………………………………..

2. Samyuta hastas

…………………………………………………………………………………

……………………………………………………………………………….....

## Exercise 6

| I.                                                                  | Explain why Guru Vandana is a reverential dance.                |
|---------------------------------------------------------------------|-----------------------------------------------------------------|
| …………………………………………………………………………………                                     | …………………………………………………………………………………                                 |
| ………………………………………………………………………………… ………………………………………………………………………………… II. | Elaborate on the Guru Vandana you learnt.                       |
| ………………………………………………………………………………… …………………………………………………………………………………     | ………………………………………………………………………………… ………………………………………………………………………………… |

In this image we can see a collage of different images.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Identify the Indian classical dances practised in Mauritius
- Describe how the Indian classical dances were introduced in Mauritius
- Name the pioneers of Indian classical Music and Dance in Mauritius
- Elaborate on the evolution of Indian classical dances in Mauritius.

## 2.0   INDIAN CLASSICAL DANCE FORMS IN MAURITIUS

In Mauritius, only three Indian classical dance forms are practised. The three classical dance forms are Bharata Natyam, Kathak and Kuchipudi.

Bharata Natyam

In this image, we can see a woman wearing a yellow color dress and she is dancing. We can also see a woman wearing a blue color dress and she is also dancing. We can also see a woman wearing a green color dress and she is also dancing. We can also see a woman wearing a red color dress and she is also dancing. We can also see a woman wearing a yellow color dress and she is also dancing. We can also see a woman wearing a blue color dress and she is also dancing. We can also see a woman wearing a green color dress and she is also dancing. We can also see a woman wearing a red color dress and she is also dancing. We can also see a woman wearing a yellow color dress and she is also dancing. We can also see a woman wearing a blue color dress and she is also dancing. We can also see a woman wearing a green color dress and she is also dancing. We can also see a woman wearing a red color dress

<!-- image -->

Kathak

Kuchipudi

The majority of people who came from India had their roots from the South, South-East, South-West  and  the  Northern regions of India.  As Bharata Natyam  originated  from  Tamil Nadu,  Kuchipudi  from  Andhra Pradesh  and  Kathak  from  the North  regions,  these  classical dance  forms  got  established  in the island and had an influence on the people of Mauritius.

In this image I can see a map of India.

<!-- image -->

## 2.1    HOW THE INDIAN CLASSICAL DANCES WERE INTRODUCED IN MAURITIUS?

India became independent in 1947, and diplomatic relations were established between India  and  Mauritius.  The  Indian  Embassy  was  set  up  in  Mauritius in 1948. Since then, various Indian classical music and dance experts have visited Mauritius for performances, concerts and awareness programmes.

In  1962, Pandit Ram Gopal and his troupe left a remarkable impact on the people of Mauritius. They presented dance performances in Bharata Natyam, Kathakali  and  Kathak  which  led  to  an  increase  in  interest  for  learning  the classical dance forms in the country.

As there was a significant growth in the interest of Mauritians in Indian music and dance, Sir Veerasamy Ringadoo, the then Minister of Education set up the School of Indian Music and Dance at Beau-Bassin in 1964. The school was established with the collaboration of the Indian High Commission and the British government as Mauritius was still a British colony.

Did you Know?

Before the setting up of the Indian Embassy in Mauritius, Indian indentured labourers were only adept in folk music and dance.

The Indian Government sent Mr. and Mrs. Nandkishore to Mauritius, to teach Indian music and dance. They were  experts  in  Indian  classical  music  and  dance and taught the following disciplines: Vocal Hindustani music,  Sitar,  Harmonium,  Tabla,  Bharata  Natyam, Kathak, Kathakali, Manipuri and folk dances.

In this image we can see a person standing and wearing a red and black color dress. In the background there are red color curtains.

<!-- image -->

There  was  such  a  growing demand amongst the Mauritian people to learn Indian  classical  music  and dance, that a larger complex was required to accomodate the students. Thus, the School of Indian Music and  Dance  integrated the Mahatma Gandhi Institute with the mission to promote education and Indian culture

In this image we can see a poster with some text and images.

<!-- image -->

including Indian music and dance. As a matter of fact, the foundation stone of the Mahatma Gandhi Institute at Moka was laid on the 3rd June 1970 and the Mahatma Gandhi Institute was inaugurated in 1975 by late Shrimati Indira Gandhi, the then Prime Minister of India.

## 2.2    PIONEERS OF INDIAN CLASSICAL MUSIC AND DANCE IN MAURITIUS

The  High  Commission  of  India  annually  granted  scholarships  to  Mauritian students to study Indian classical music and dance in India. In 1950, the first Mauritian,  Mr  Ishwarduth  Nundlall  was  offered  a  scholarship  by  the  Indian Government to study Indian classical music in India. Dr Ishwarduth Nundlall came back to Mauritius in 1958 with degrees in Vocal Hindustani, Sitar and Violin from the National Academy of Music, Lucknow.

Dr. I. Nundlall started performing all over the island, arousing interest in many Mauritians to learn the art of music. He is considered to be the first Mauritian to teach, train and propagate Indian classical music in Mauritius.

In this image we can see a person wearing a cap. In the background there is a wall.

<!-- image -->

Furthermore, Mauritians and Indians who got training in eminent Institutions from India contributed in the  propagation  of  Indian  classical dances in Mauritius. Some of them are:  Mrs.  Padma  Naidu-Ghurbhurun, Mrs.  Sandhya  Mungur  and  Mrs. Rekha Deerpaul in Bharata Natyam;

Source : defimedia.info

Mr Ramesh Nundoo and Mrs Nirmala Gobin  in  Kathak;  Mrs  Damayantee Algoo in Manipuri; Mrs Premila Balakrishna Uppamah in Kuchipudi. Many Mauritians, who were initiated in  the  classical  art  forms,  went  to India to pursue further studies in the

In this image we can see a picture of a mobile phone. On the mobile phone we can see a text.

<!-- image -->

field of Tabla, Kathak, Violin, Vocal Hindustani, Vocal Carnatic, Sitar, Bharata Natyam, Mridangam, Kuchipudi, Mohini Attam and Veena.

Kathak dance performance

In this image we can see a group of women dancing on the stage.

<!-- image -->

Since 1964 onwards, there has been a continuous effort of the Mahatma Gandhi Institute staff to propagate Indian classical music and dance. Regional Centres were set up in 1982 throughout the island by the Mahatma Gandhi Institute so that these art forms could reach out the population at large.

Bharata Natyam dance performance

In this image we can see a woman and a man are dancing.

<!-- image -->

Kuchipudi dance performance

In this image we can see a collage of three images. In the first image there is a woman standing and smiling. In the second image there is a woman standing and smiling. In the third image there is a woman standing and smiling.

<!-- image -->

The Ministry of Education, Ministry of Arts and Culture, Indira Gandhi Centre for Indian Culture, Indian socio-cultural associations, and private dance schools have all played important roles in preserving, promoting and propagating Indian classical dance and music in Mauritius.

Indian classical dance has been part of the secondary schools curriculum for more than 40 years. Today, Indian classical music and dance have attained such a standard that they are being taught up to tertiary level at the Mahatma Gandhi Institute in collaboration with the University of Mauritius.

<!-- image -->

-    Only Bharata Natyam , Kathak and Kuchipudi are practised in Mauritius.
-   Due to the fact that Bharata Natyam , Kuchipudi and Kathak originate from T amil Nadu,  Andra Pradesh as well as Lucknow and Jaipur respectively, regions from where our ancestors came, these dance forms have established themselves in Mauritius.
-     It  is  only after the setting up of the Indian Embassy in Mauritius in 1948 that Indian classical dances were introduced in Mauritius.
-   The school of music and dance was set up in 1964.
-   Dr Ishwarduth Nundlall is known as the first pioneer of Indian classical music in Mauritius.
-   The three Indian classical dance forms; Bharata Natyam , Kathak and Kuchipudi are part of the cultural panorama of Mauritius.

<!-- image -->

Originate, practised, classical, pioneers, embassy, culture.

## Assessment

## Exercise 1

State whether the following statements are true or false.

|    | Statements                                                                                                        | TRUE / FALSE   |
|----|-------------------------------------------------------------------------------------------------------------------|----------------|
|  1 | Bharata Natyam , Kathakali and Odissi are the three Indian classical dance forms commonly practised in Mauritius. |                |
|  2 | Dr Ishwarduth Nundlall is known as the first pioneer of Indian classical music in Mauritius.                      |                |
|  3 | Indian classical dances were introduced in Mauritius before the Independence of India.                            |                |
|  4 | The School of music and dance was set up in 1964.                                                                 |                |
|  5 | Bharata Natyam , Kathak and Kuchipudi are part of all major socio-cultural occasions in Mauritius.                |                |

## Exercise 2

Name the three Indian classical dance forms commonly practised in Mauritius.

.................................................................................................................

.................................................................................................................

Exercise 3

Explain  why  only  Kathak,  Bharata  Natyam  and  Kuchipudi  are commonly practised in Mauritus.

.................................................................................................................

.................................................................................................................

.................................................................................................................

In this image we can see a woman standing and wearing a costume. In the background there is a wall.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Memorise each variety of Chakkar
- Explain the terms Bant and Chakkar
- Define composite Chakkar
- Differentiate between Chakkar and composite Chakkar
- Distinguish between the different Chakkar compositions and their varieties
- Perform one Bant of few Palta-s
- Execute two complex Tihai-s
- Perform one variation of each of the prescribed Chakkar-s
- Perform two variations of composite Chakkar-s
- Perform any two variations of Chakkar-s which include 1-step Chakkar .

## 3.0  TATKAAR AND CHAKKAR

The  two  major aspects of Kathak comprise Nritya ,  that  is,  acting  or  interpretative dance and Nritta , meaning abstract or pure dance.

Tatkaar and chakkar-s are special features of kathak dance style. They are the two main techniques through which the nritta aspect of kathak classical dance are demonstrated. The dancer exhibits the intricate rhythmic compositions in which the sounds of the ghungroo-s resonate the dance bols and accompanies the syllables played on the tabla .

## 3.1  TATKAAR

Tatkaar is the basic footwork in kathak dance. It also represents an execution of a set of footsteps in several variations or patterns. These complex forms or  types  of tatkaar are  termed  as bant and ladi .  Normally,  a tatkaar of  this type marks the end of a particular laya or the end of a recital as it is always concluded with a long and complex tihayi too.

The  execution  of  these  types  of tatkaar in  appropriate  rhythmic  patterns  is important for a dancer because it demonstrates his or her mastery in rhythm and technical skills. The performer keeps the hands folded in a  straight posture and starts the tatkaar with simple bol-s of the taal . The accompanying melody is mostly provided by the tabla and lehra .

Nevertheless,  the  stampings  of  the  foot  in  the vibhag-s provide  the  clear changes in the variations. Progressively, more and more complicated variations are brought in  and executed in a clear precision and rhythmic patterns. The matra-s can  be  sounded  separately  and  clearly  on  the  tinkling  bells  of  the ghunghroo-s .  Each variation of the foot step should match with bol-s of  the tabla and finally the tatkaar ends with a tihai marking the sam and as well as the end of the tatkaar .

## 3.1.1 BANT

The term bant is  derived from the Hindi word 'bantna '.  It  means to share or to divide in sections. A bant is  executed in fast tempo. It involves tatkaar in different patterns and in many variations. These patterns and variations are executed in many avartan-s . Therefore, when the bol-s of tatkaar are divided into different sections and in several vibhag-s , the composition is called a bant in kathak dance.

## 3.2 CHAKKAR

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Kathak is the only Indian classical dance form in which there is the dynamic use of spins. Chakkar can  be  identified  as  the bhramari-s mentioned in the Natyashastra . The techniques of spins are properly and beautifully executed after a long dedicated practice. Usually concentrated at the end of a composition, chakkar-s provide it  with  a  remarkable final climax to reach the sam into a picturesque pose.

Did you Know?

- A kathak dancer can take 3, 9, 27, 81, 108 or even more chakkar at a time.

A    composite chakkar is  when  more than one type of chakkar are included in the composition. For example, 8-step chakkar with 3-step chakkar or a 5-step chakkar with 3-step chakkar .

## Note to Students

The regular practice of the many variations should be done in order  to  be  able  to  execute  the composite chakkar-s as required. All  the  examples  and  notation forms are listed in the chapter 10Padhant and Notation.

## 3.2.1 Examples of performing 3-step chakkar

In this image we can see a woman standing.

<!-- image -->

In this image we can see a woman standing.

<!-- image -->

<!-- image -->

Example 2

<!-- image -->

In this image we can see a woman standing and wearing a blouse.

<!-- image -->

In this image we can see a woman standing.

<!-- image -->

## 3.3  COMPLEX TIHAI

A tihai is a rhythmic composition which comprises an identical rhythmic piece repeated exactly three times  with equal intervals. A tihai may start on any matra of  the taal but should always end on sam . Furthermore, it can be composed in one or more avartan-s .  It  is  also  executed  as  a  concluding piece  creating  a  transition  to  another  section  of the performance. Tihai-s are based on arithmetic calculation and consist of fixed structures.

A  complex tihai is  when  the  rhythmic  pattern  is complex, long and consists of various avartan-s but executed smoothly to reach the sam . A  complex tihai in kathak ,  enhances    the  beauty  of  the performance. It also illustrates the musical maturity of the performer and the musicians.

There are many types of tihai that are performed in kathak. Some examples are:

- Damdar tihai -  If  there  is  an  interval  of  more than or equal to half matra between the three parts of tihai.

## Note to teacher

Refer  to  chapter  10  ' Padhant  and Notation ' for  the notation of  the compositions.

In this image, there is a table with some text on it.

<!-- image -->

.

tihai when there is no interval in the three parts of the

-

Bedam tihai

•

## An example of a bedam tihai .

16

15

14

13

12

11

10

9

8

7

6

5

4

3

2

1

ThaiTa

ThaiTat

AaThai

ThaiTat

TaThai

TaThai

ThaiThai  TatThai

ThaiThai  TatAa

ThaiTa

ThaiTa

ThaiTat

Athai

ThaiTat

Tathai

3

0

2

X

Ta

X

when the whole tihai is repeated thrice to

-

Chakkradaar Tihai

•

.

sam reach the

|   16 | ThaiTat   |    | ThaiTat   |    | ThaiTat   |      |
|------|-----------|----|-----------|----|-----------|------|
|   15 | Athai     |    | Athai     |    | Athai     |      |
|   14 | ThaiTat   |    | ThaiTat   |    | ThaiTat   |      |
|   13 | Tathai    | 3  | Tathai    | 3  | Tathai    | 3    |
|   12 | SS        |    | SS        |    | SS        |      |
|   11 | Thai      |    | Thai      |    | Thai      |      |
|   10 | ThaiTat   |    | ThaiTat   |    | ThaiTat   |      |
|    9 | Athai     | 0  | Athai     | 0  | Athai     | 0    |
|    8 | ThaiTat   |    | ThaiTat   |    | ThaiTat   |      |
|    7 | Tathai    |    | Tathai    |    | Tathai    |      |
|    6 | SS        |    | SS        |    | SS        |      |
|    5 | Thai      | 2  | Thai      | 2  | Thai      | 2    |
|    4 | ThaiTat   |    | ThaiTat   |    | ThaiTat   |      |
|    3 | Athai     |    | Athai     |    | Athai     |      |
|    2 | ThaiTat   |    | ThaiTat   |    | ThaiTat   |      |
|    1 | Tathai    | X  | Tathai    | X  | Tathai    | X Ta |

<!-- image -->

- Tatkaar and chakkar-s are the main techniques through which the nritta aspect of kathak classical dance is demonstrated.
- Tatkaar constitutes of a set of footsteps in several variations or patterns.
- The term bant is derived from the Hindi word ' bantna ', meaning to share or to divide in sections.
- In a bant , the tatkaar-s are set in different patterns and in many variations but in fast tempo.
- A tihai is a rhythmic composition comprising an identical rhythmic piece repeated three times with equal intervals.
- A complex tihai is when the rhythmic pattern is complex, long and consists of various avartans .
- Examples of complex tihai-s are damdar, bedam and chakkradaar .
- A composite chakkar is when more than one type of chakkar are included in the composition.

<!-- image -->

Compostion, techniques, rhythmic,  patterns,  complex, composite.

Did you Know?

- Tihai is a distinguished feature of all music forms, that is vocal, instrumental and dance.
- Any concert of music and dance is concluded with a tihai .

| Assessment                                 | Assessment                                                |
|--------------------------------------------|-----------------------------------------------------------|
| Exercise 1                                 | Exercise 1                                                |
| State the bol-s of each of the followings: | State the bol-s of each of the followings:                |
| I.                                         | 3-step chakkar ………………………………..                             |
| II.                                        | 5- step chakkar ………………………………..                            |
| III.                                       | 8-step chakkar ………………………………                               |
| Exercise 2                                 | Exercise 2                                                |
| I.                                         | What is tatkaar ?                                         |
| II.                                        | Describe the meaning of a bant .                          |
| Exercise 3                                 | Exercise 3                                                |
| I.                                         | What is a tihai ?                                         |
| II.                                        | Describe a complex tihai .                                |
| Exercise 4                                 | Exercise 4                                                |
| I.                                         | What is a composite chakkar ?                             |
| II.                                        | Differentiate between a chakkar and a composite chakkar . |

In this image we can see a poster with some text and images.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Define the term Thaat
- Describe the terms Paran and Kavit/kavita Toda
- Explain the story line behind the Kavit/kavita Toda
- List the hand gestures used in the Kavit/kavita Toda
- Explain the term Gat Bhava
- Differentiate between Gat Nikas and Gat Bhaav
- Explain the prescribed Gat Bhava
- State the hand gestures used in the Kavit/Kavita Toda
- Explain orally and through demonstration the kavit/kavita Toda
- Count and recite the prescribed compositions in their specific laya (clapping and wave of hands with correct pronunciation.
- Perform the following compositions in teentaal vilambit laya : thaat , one toda , one paran and a tihai
- Perform the following compositions in teentaal Madhya laya one tukda , one toda and the prescribed kavit/kavita Toda and a paran
- Perform in teentaal drut laya two tukda-s , one Gat Bhava and one Gat Nikas either Parvati, Ruksar or chapka.

## 4.0 TEENTAAL COMPOSITIONS

A kathak performance of nritta (pure dance) always progresses from a very slow  speed  to  a  fast  one  at  the  end  of  a  demonstration.  Thus,  the  dancer demonstrates  the  various  compositions  in vilambit,  madhya and drut  laya. Some examples of slow compositions performed in vilambit  laya are amad, thaat, salaami or namaskar tukra , toda, paran and tatkaar. The medium ones performed in madhaya laya are the tatkaar, tukde, tihai and many more . Some examples performed in drut laya are paran-s , complex tukras, gat and tode.

## 4.1 THAAT

Thaat is  derived  from  the  word  ' thathana ' implying  stillness.  It  is  the  first nritta composition performed either after an amad or  a Vandana .  In  a thaat ,  the dancer performs short-lived but elegant and quick acts like mukhra, tukra, tihai and chalan . These are technically executed  to  the  accompaniment  of tabla and lehra, played in vilambit laya of the taal .

Thaat is generally performed in a decorative or graceful attitude. In stillness and  calmness, the dancer glides  the  neck,  shoulder,  and  torso slightly from side to side. The trembling

In this image we can see two women are dancing.

<!-- image -->

fingers, wrist and eyebrows heighten the beauty of the thaat and the statuesque poses denote the sam of the taal .

In Lucknow Gharana , the dancer usually uses less space to perform a thaat. But, it demonstrates delicate and swaying movements of the upper half of the body wherein subtle movements of the upanga-s and pratyanga-s are more discernible.

In Jaipur Gharana ,  the dancer glides gracefully first to one side and then to the other side. The tukra, chakkar or tihai are vivid and the sam is beautifully marked by a sharp turn of the head.

## 4.1.1 PARAN

The origin of the word paran may have some relation with the word 'par' meaning  wing,  thus implying 'something that 'flies' in quick time. Paran-s are  actually  compositions that  were  created  for  the tabla or for dance, but which  uses  the  language and beauty of the bol-s of pakhawaj  such  as dhuma kita, dhet dhet, kradha tita, gadi  gena,  dhagetita and so on.

In this image we can see two women are dancing.

<!-- image -->

In kathak dance, paran-s use pakhawaj bol-s exclusively. Kathak Gurus often describe  these  compositions  such  as  vigorous,  masculine,  non-expressive and pure dance items. Likewise, while performing Paran in the nritta part, the dancer makes use of footwork which usually echoes the rhythmic accents of the music. The movements are long and wide with free sweeping gestures in space to show the volume and breadth as recognised to the pakhawaj bol-s .

Paran-s are classified under tandava aspect of dancing as their demonstrations require forceful, energetic and lively movements. There are different types of paran ,  the chakkradaar paran and Paran Amad . There are stuti paran-s that are named after a specific deity, such as Ganesh paran and Shiva paran .

## 4.1.2 KAVITT/ KAVITT TODA

In this image we can see a woman standing and dancing. She is wearing a pink and yellow color dress.

<!-- image -->

The term kavitt comes from the word Kavita meaning a poem and pure dance bol-s are called 'tode' . Hence, a composition involving a  poem  and  dance bol-s is  called  a kavitt toda .  The  rhythmic  compositions  comprise natwari bol-s with tihai at the end.

They usually narrate mythological stories in which the dancer expresses the words of the Kavitt in  rhymes  with  appropriate  hand gestures or symbols, dance movements and facial expressions. Kavitt tode are classified under nritta aspect of dance.

Nevertheless, a kavitt tode combine both 'nritta' and ' nritya' and are performed to the recitation of the poem in a taal . The composition is often performed at great speed, thus, the nritya aspect is not as obvious because nritta is dominant. Also, the ghungroo-s resonate to the nritta bols accompanying the specific taal.

## Note to Teacher

Choreography of the kavitt tode should not be restricted to specific hand gestures and dance movements. Teacher should provide students with a list of all the hand gestures demonstrated in this composition.

## Below is an example of a simple kavitt :

## Meaning of the kavitt:

Tat Tat Tada Kata Theri Rita dhara kata Dima Dima Dima Dima Damini Damaka Chima Chima Chima Chima Nava Rasa Bara Sata Nira Taka Rata Krish Nas Krish Nas Krish Nas

Tat Tat Tada Kata Theri Rita Dhara Kata the sounds of thunder

Dima Dima Dima Dima in a slow pace Damini Damakata lightning

Chima Chima Chima Chimathe sound of    rain the rain

Nava Rasa Bara Sat gradually pouring down

Nira Taka Rata Krish Na Krish Na Krish Na and looking to all, Krishna is dancing

The frightening lightning and thunders causing the gradual downpours. Lord Krishna is watching all and dancing his blissful dance on the sound produced by the heavy rains.

## 4.1.3 Gat Nikas and Gat Bhava

Gat-s normally  introduce nritya in  a kathak dance  recital,  that  is,  dancing with gestures to portray a meaning. The dancer performs on the various themes one after another in an increased tempo, that  is,  in teentaal  drut  laya .  Still  the dance movements are fairly executed in slow speed. There is no recitation other

In this image we can see a woman standing and she is wearing a purple color dress.

<!-- image -->

than ' dha ka dhin na dhin na kat' and ' tat ta thai tat a thai ',  on which the dancer acts to represent the character.

Gat nikas is usually performed before gat bhava . The dancer takes the palta-s and moves forward and stops on one position. Steadily, along with the chaal-s or gaits, there are subtle movements of the fingers and wrists accompanying the speed the taal .  These  can  be  in  a  simple  posture  or sadharan posture. But more often in a gat nikas the dancer gives a brief description of the story to be represented afterwards, for example, the state of  a nayak or nayika meaning hero or heroine respectively.  Each  character  can  be  discerned through the beautiful gaits and postures.

In the Gat Nikas of both the Gharana-s there are some differences in the use of the stances. Jaipur, being  closely  connected  to  the  Hindu  culture and tradition, usually demonstrates simple ones such as the Parvati Gat , murli or bansuri gat and ghughat gat with a sadharan or saadi pose.

In this image we can see a woman standing and holding a red color object.

<!-- image -->

Lucknow, influenced by Muslim style, shows those stances which are from the Muslim background, like the Chapke Ki Gat , the Ruksar , the Husnaki Gat and so on.

In this image we can see a woman standing and wearing a red and green color dress.

<!-- image -->

In this image we can see a woman wearing a dress.

<!-- image -->

In gat bhava , a story is depicted in an allusive manner. It is completely devoid of any literary word or poem but the dancer shows a whole story,  only  a  subject  or  a  topic  that  has  a special piece or feature. The dancer makes use  of  the  techniques  of  mime  and  poses while enacting the various  characters in their daily  activities  accordingly,  for  example  in a panghat  gat , Draupadi  chirharan,  bansuri and many more.

In this image we can see two women are standing. The woman on the left is wearing a green color dress and the woman on the right is wearing a red color dress.

<!-- image -->

Each gat starts and ends with tihai-s . However, palta-s in gat nikas are used to show the sections and in gat bhavas these are used to switch in characters. Gat bhava depicts a complete story and, so, it is lengthier than a gat nikas . Gat ends with a tihayi which very often starts on any matra of the taal .

In this image we can see a woman standing and holding a stick in her hand. She is wearing a pink and gold color dress.

<!-- image -->

In this image we can see a woman standing and smiling.

<!-- image -->

In this image we can see a woman standing and holding a stick in her hand.

<!-- image -->

Did you Know?

Though performed in fast tempo while attempting abhinaya, kavitta tode are classified under nritta aspect of dance.

<!-- image -->

- Thaat is generally performed in a decorative or graceful attitude.
- Paran-s comprise bols such as dhuma kita , dhet dhet , kradha tita , gadi gena and dhagetita among others.
- Kavitt tode is a poem comprised of pure dance bol-s set on a taal .
- A kavitt tode is set in a rhythmic cycle narrating mythological stories.
- The dancer expresses the words of the Kavitt with appropriate hand gestures, dance movements and facial expressions.
- Simple and short Parvati, chapka, bansuri, ghunghat, ruksar and mayur gat-s are examples of gat nikas .
- Gat nikas is usually performed before gat bhava .
- In a gat nikas there  are subtle movements of the fingers and wrists accompanying the speed the taal .
- In a gat bhava , a story is depicted in an expressive manner.
- The dancer makes use of the technique of mime, enacting the characters and their daily activities accordingly.
- Palta-s in gat nikas are used to show the sections.
- Palta-s in gat bhavas are used to switch in characters.
- Gat bhava depicts a complete story and so it is lengthier than a gat nikas.

<!-- image -->

Elegant, Alluring,  Graceful,  Decorative,  Statuesque, nritta , Vigorous, Non-expressive, Pakhawaj, Accents, poem, devoid, Natwari, nritya, bhava , gait, palta .

## Assessment

## Exercise 1

## Match the following terms, with the correct meaning.

1. Thaat

decoration Natwari bol-s ruksar pakhawaj bol-s

2. Paran

3. Kavitt tode

4. Gat bhava

## Exercise 2

Answer the following questions in short paragraphs.

- I. Define the term thaat .

…………………………………………………………………………………

….………………………………………………………………………………

…..………………………………………………………………………………

- II. Explain the term Gat Bhava .

…………………………………………………………………………………

…………………………………………………………………………………

…………………………………………………………………………………..

- III. Describe the term Paran .

…………………………………………………………………………………

…………………………………………………………………………………

………………………………………………………………………………….

## Exercise 3

- a) Explain what is a kavitt tode .

……………………………………………………………………………….....

.................................................................................................................

| b)                                                                | Write down the meaning of kavitta tode 'Tat Tat Tada Kata' .      |
|-------------------------------------------------------------------|-------------------------------------------------------------------|
| ………………………………………………………………………………… ………………………………………………………………………………….. | ………………………………………………………………………………… ………………………………………………………………………………….. |
| c)                                                                | List the hand gestures used in the Kavitt tode .                  |
| Exercise 4                                                        | Exercise 4                                                        |
| a)                                                                | Differentiate between gat bhava and gat nikas .                   |
| …………………………………………………………………………………                                   | …………………………………………………………………………………                                   |

…………………………………………………………………………………..

In this image we can see a collage of different costumes of women.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Explain the following aspects of dance Nritta, Nritya, Natya, Tandava, Lasya and Abhinaya
- Classify different items which fall under Nritta and Nritya
- Differentiate between Nritta and Nritya
- Differentiate between Tandava and Lasya .

## 5.0  TERMINOLOGIES OF INDIAN CLASSICAL DANCES

According to the Natya Shastra and Abhinaya Darpana, traditional Indian dances are categorised into different distinct components. These distinct components  are Nritta, Nritya, Natya, Tandava, Lasya and Abhinaya .

## 5.1  NRITTA

In this image we can see a person's legs and a person's foot.

<!-- image -->

Nritta is  often referred to as 'pure' or 'abstract' dance.  The movements and hand  gestures  are  beautiful,  decorative,  graceful  and  artistic  with  rhythmic patterns of footwork.

In this image we can see a woman standing and dancing. She is wearing red and white color dress.

<!-- image -->

The musical accompaniment for Nritta does  not  have  any  poetic  or  lyrical content to be interpreted by the dancer. Nritta dance compositions do not convey any story or idea. Emphasis is rather laid on beautiful and structured body  movements  and  complexities  of rhythm.

For  example,  in  a Nritta dance  piece such as basic movements, the synchronisation between taal and laya is of utmost importance.

Therefore, Nritta is  solely  intended  to  display  the  techniques,  beauty  of  the body in motion and statuesque poses of dance in space and in appropriate taal and laya. Examples of nritta are basic movements, tatkaar, chakkar-s and compositions such as Tukra, bant, tihayi, thaat, toda, paran, gat and kavitt .

## 5.2  NRITYA

In this image we can see a woman standing and wearing a dress.

<!-- image -->

Nritya is known as expressional or emotive dance.  The  meaning  of  a  poem,  story  or song is conveyed using body movements, hand gestures, and facial expressions.

It is the  narrative  form  of  dance.  The emphasis of Nritya dance compositions is laid upon sentiments.

The themes of Nritya dance composition are mostly based upon divine love and devotion towards God. Reverential dance compositions such as Vandana-s, bhajans, kirtans and thumris are nritya dance.

## 5.3  NATYA

<!-- image -->

The word Natya is derived from ' Nat ' which means moving  or  acting. Natya is  considered  to  be  a combination  of  acting  with  dialogue  or  speech, music and dancing. A Natya performance is a dance drama, that is, a drama involving music and dance.

Thus, Natya is the dramatic element of Indian classical dance. Kathak choreographies of dance-ballets usually  include  aspects  of natya. Some  examples are raas  leela ,  themes  on  the  Ramayana  or  the Mahabharata and so on.

In this image we can see a woman standing and holding a candle in her hand.

<!-- image -->

## 5.4  TANDAVA

Tandava is considered as the masculine  aspect  of  dance.  These forms  of  dances  consist  of  forceful and vigorous movements with intricate steps. The music is usually very rhythmic and fast in tempo.

Tandava dance is mostly appropriate for  the  masculine  body  but  women too can perform the Tandava dance. According  to  Hindu  mythology,  it  is believed that the dance of Lord Shiva are known as tandava dance.

In this image we can see two persons dancing.

<!-- image -->

In kathak , examples of Tandava dance are paran, complicated chakaar and movements.

## 5.5  LASYA

In this image we can see a woman dancing.

<!-- image -->

Lasya is  considered  as  the  opposite of Tandava .  Hence,  it  is  the  feminine aspect of dance. Lasya is the graceful, soft  and  gentle  body  movement  with light  steps  in  dance.    It  is  executed in a reduced speed compared to the Tandava. According to Hindu mythology,  this  dance  was  performed by Goddess Parvati.

The gentle,  delicate  and  soft  movements in kathak dance compositions demonstrate  the laya aspects  of  this style of dance.

## 5.6  ABHINAYA

In this image we can see a group of people dancing.

<!-- image -->

Abhinaya is  the  art  of  expression  in  Indian  classical  dances. Abhinaya is  a Sanskrit word which is made of the prefix 'abhi ' meaning 'towards' and the root ' ni ' meaning 'to carry'. It means leading an audience towards the experience of a sentiment.

Abhinaya in Indian classical dances is the expressional aspect of dance where the dancer interprets the lyrics of a song. The dancer, at times, when depicting a  particular  character  has  to  visualise  the  conditions,  that  is,  both  mental and physical state of the character to be depicted and conveys them through imitation, mime, expressions or dance movements.

Abhinaya or  expression  is  divided  into  four  types  namely; Angika,  Vachika, Aharya and Sattvika.

## 5.6.1 Angika  Abhinaya

Anga means  limbs  and  the  part  of  the  body. Therefore angika  abhinaya is  the  performance that  contains  physical  expression  of  dance.  The dancer  makes  use  of  the anga,  pratyangas and Upangas . The nritta compositions in kathak dance are classified under angika abhinaya compositions. These involve compositions such as tatkaar, thaat, paran, tukra, tihayi, gat nikas and so on.

## 5.6.2 Vachika Abhinaya

In this image we can see a woman standing and dancing.

<!-- image -->

Vacha means  speech.  Therefore Vachika Abhinaya is  verbal  expression  in dance. It is the expression made through the use of dialogue, poetry, song and recitation. In kathak performances, the dancer usually does the padhant of each compositions.

In this image we can see a group of people. There are mics and a person standing in front of the mics. There is a person sitting on the chair. There is a person standing in front of the mics. There is a person sitting on the chair. There is a person standing in front of the mics. There is a person sitting on the chair. There is a person standing in front of the mics. There is a person sitting on the chair. There is a person standing in front of the mics.

<!-- image -->

In this image we can see a person standing on the stage.

<!-- image -->

## 5.6.3 Aharya  Abhinaya

In this image we can see a group of people standing on the floor. In the background there is a wall.

<!-- image -->

It is the expression of a character through the use of costumes, make-up and jewelleries, as well as stage décors. Aharya abhinaya is usually seen in dance drama or ballet choreographies.

Thus the performers have the choice to wear the appropiate costumes and make-up to depict the character. For example, in Ramayana, the artists may portray Rama and Sita as King and Queen  and also as mendicants, wearing costumes such as sages and living in forests.

## 5.6.4 Sattvika Abhinaya

It is the expression of the feelings which have been  produced  through  the  manifestations of different mental and emotional states. The various  states  can  be  represented  though facial expressions, gestures and dance movements. Some examples are laughing, weeping, shivering and so on.

In this image we can see a woman dancing.

<!-- image -->

The table below indicates the Aspects and Components of dance

The image is a diagram of a dance. The diagram is divided into two main sections: the left section and the right section.

### Left Section
- **Title**: Dance
- **Description**: The left section is labeled as "Nritta" and "Natriya" and is represented by two different colored shapes.
- **Color**: The left section is colored in a light pink color and the right section is colored in a dark blue color.
- **Color**: The left section is colored in a light pink color and the right section is colored in a dark blue color.
- **Color**: The left section is colored in a light pink color and the right section is colored in a dark blue color.
- **Color**: The left section is colored in a light pink color and the right section is colored in a dark blue color.
- **Color**: The left section is colored in a light pink color and the right section is colored in a dark

<!-- image -->

<!-- image -->

- Nritta is pure dance movements.
- Nritya is an expressional dance.
- Natya is the dramatic element in Indian classical dance.
- Tandava is the masculine aspect of dance and consists of forceful and vigorous movements.
- Lasya is the feminine aspect of dance and consists of soft and graceful movements.
- Abhinaya means to represent a play towards the audience.
- Abhinaya is divided into four categories namely: Angika, Vachika, Aharya and Sattvika.
- Angika Abhinaya is expression through the use of Anga, Pratyangas and Upangas.
- Vachika Abhinaya is expression made through speech, dialogue and lyrics.
- Aharya Abhinaya is expression made through the use of costumes, make-up and  jewellery as well as stage décors.
- Sattvika Abhinaya is the physical expression of the mental and emotional states.

<!-- image -->

Pure  dance,  Abstract  dance,  Expressional  dance, Dramatic elements, Masculine, Forceful, Graceful

## Assessment

## Exercise 1

## State whether the following statements are either TRUE or FALSE.

- a) Nritta is pure dance movements.

- b) Nritya is an expressional dance.

- c) Natya is a form of dance and drama.

- d) Tandava is a forceful dance.

- e) Lasya is a graceful and soft dance.

## Exercise 2

## Match the following terms with the correct phrase related to dance.

| Column A          | Column B                                                           |
|-------------------|--------------------------------------------------------------------|
| Angika Abhinaya   | Expression made through the use of costumes, make-up and jewellery |
| Vachika Abhinaya  | The physical expression of the mental and emotional states         |
| Aharya Abhinaya   | Expression made through the use of verbal expression               |
| Sattvika Abhinaya | Expression made through the use of Anga, Pratyangas and Upangas    |

## Exercise 3

## Describe the following terms.

- a) Tandava

.................................................................................................................

.................................................................................................................

- b) Lasya

.................................................................................................................

.................................................................................................................

- c) Nritta

.................................................................................................................

.................................................................................................................

- d) Nritya

.................................................................................................................

.................................................................................................................

## Exercise 4

## Differentiate	between

- (a) Nritta and Nritya and give two examples of each.

.................................................................................................................

.................................................................................................................

.................................................................................................................

.................................................................................................................

- (b) Tandava and lasya .

.................................................................................................................

.................................................................................................................

.................................................................................................................

.................................................................................................................

## Exercise 5

- (a)    Describe the term Abhinaya .

.................................................................................................................

.................................................................................................................

.................................................................................................................

.................................................................................................................

- (b)    Explain the four types of Abhinaya .

.................................................................................................................

.................................................................................................................

.................................................................................................................

.................................................................................................................

## NOTES

In this image we can see a collage of different images.

<!-- image -->

Qasical\_

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

-   Summarise the following Indian Classical dances:
- -Manipuri

-

- Kathakali
- -Kuchipudi

-

- Odissi

-

- Mohini Attam

## 6.0 INDIAN CLASSICAL DANCES

India has, since thousands of years, a tradition of classical and folk dances. Some  of  the  world-famous  dance  forms  which  originated  and  evolved  in India are Bharatnatyam, Kathak, Kathakali, Kuchipudi, Manipuri, Mohiniattam and  Odissi. All  these  dance  forms  use  basically  the  same mudras is  as  a common language of expression and were originally performed to entertain various Gods and Goddesses. They were also effective in carrying forward the various mythological stories from generation to generation while entertaining the audiences. Among the seven main classical dances, Kathak and Bharata Natyam have already been dealt in details in Grade 7 and Grade 8 textbooks. This  Chapter  deals  with  other  main  classical  dances  Manipuri,  Kuchipudi, Mohini-Attam, Kathakali and Odissi.

## 6.1 Manipuri

Manipuri  dance  originated  in  the North-Eastern  state  of  Manipur. It derived its name from its native state, Manipur.

The Manipur tradition of honouring the Gods through music and dance  was  an  elemental  part  of the Meiti people. The themes are devotional  and  are  performed  on religious occasions and in temples throughout the area.

In this image we can see three women are dancing on the stage. The woman in the middle is wearing a crown. The woman on the left is wearing a saree. The woman on the right is wearing a saree.

<!-- image -->

<!-- image -->

The ethnic  groups  of  people  in  Manipur  are  known  as meities .

The greatest cultural evolution and the revival of Manipur dance took place in the 18 th century during the reign of King Bhagyachandra who was a devotee of Lord Vishnu.

The  traditional  Manipuri  dance  style  represents  delicate, lyrical and graceful movements.  Manipuri  consists of rounded movements and it avoid any jerks or straight lines to create an 8-shaped pattern. It is performed through an excellent display of expressions, hand gestures and body language. Acrobatic  and  vigorous  dance  movements  are also displayed by Manipuri male dancers.

<!-- image -->

## 6.1.1 Kuchipudi

Kuchipudi  is  a  dance  drama  from Andhra Pradesh, India.  Similar  to  the  Indian  classical dance  forms,  Kuchipudi  too  evolved  as a religious art rooting back to the age-old Hindu  Sanskrit  text  ' Natya  Shastra' and traditionally connects with temples, spiritual faiths and travelling bards.

In this image we can see a woman standing and smiling.

<!-- image -->

In  fact,  it  was  performed  by  Bhagtas  in devotion to Krishna, who used poetry, song, music and drama for the propagation of their faiths and beliefs.

In this image we can see a woman is sitting and she is wearing a blue color dress and gold color jewelry.

<!-- image -->

Sidhyendra  Yogi,  a  pious  Telugu  Brahmin can  be  called  the  founder  of  this  dancedrama. He first staged his dance form in the Kuchelapuram  village  which  later  became known as Kuchipudi.

In this image we can see a person standing and holding a flower. In the background we can see a person and a person holding a flower.

<!-- image -->

## 6.1.2 Mohini	Attam

Mohini Attam is the classical dance form from Kerala. The name 'Mohini Attam' comes from the two words 'mohini', meaning a woman who charms or enchants everyone, and 'attam' meaning dance.

In this image we can see a woman standing. She is wearing a white color saree.

<!-- image -->

So,  Mohini  Attam  literally  means  dance  of the  enchantress.  Mohini   Attam  is  associated with  the lasya style  of  dancing.  The  temple sculptures of the state are evidences of Mohini Attam or other dance forms similar to it.

The  tradition  of  Mohini  Attam  can  be  traced back to the 18th-19th century. It was during the reign  of  the  great  poet,  King  Maharaja  Swati Tirunal that Mohini Attam was popularised. He promoted the Mohini Attam dance style.

He made the musical aspect of Mohini Attam rich and attractive.

The  movements  and  footwork  are  gentle,  soft  and never abrupt. The body executes graceful and gliding movements.

The technique is of a circular use of torso and revolving in the half bent position with the toes and heel used in a flowing rhythmical structure.

## 6.1.3 Kathakali

In this image we can see a woman is dancing.

<!-- image -->

Kathakali is the most famous dance-drama from Malabar, the south western Indian  state  of  Kerala.  The  word  kathakali  literally  means  'story-play'.  It  is famously known for its large, elaborate make-up and heavy colourful costumes.

In this image we can see a group of people are standing on the road. In the background we can see trees and the sky.

<!-- image -->

It was originated around in the 12 th Century. It is said that in his dream, Lord Krishna ordered King Zamorin of Kalicut  to  prepare  a  dancedrama on krishna- Leela' theme and presented  him  a  peacock-feather in the form of blessings.

Hence Zamorin started 'Krishna-Attam' or Krishna - Leela as a folk dance. But when he was invited by the king of Kottayam to perform in his palace, Zamorin refused. Then the king suggested to the Nambudri Brahmins, who were learned dancers, to compose 'Rama-Attam'.

Rama attam became popular and episodes of the Ramayan were dramatised. Also, plays were written with themes from the Mahabharata, Shiva Purana and the Bhagvad Gita. The name Rama Attam then became unsuitable because of  various thematic range and thus the name Kathakali was substituted in its place.

Mahakavi Vallathol Narayan Menon, gave kathakali its  present  form  and  he was considered as the founder of the 'Kerala Kala Mandalam'.

Kathakali was  usually  performed  only  by  men.    Female  characters  were portrayed by men dressed in women's costume.  However, in recent years, women  too  have  started  to  become  part  of  Kathakali  dance-dramas.  The dancer  expresses  himself  through  codified mudras and  facial  expressions, closely following the verses that are sung.

Heavy costumes and elaborate make up are the most distinctive characteristic features of Kathakali.

In this image we can see a collage of images.

<!-- image -->

In this image we can see a person dancing.

<!-- image -->

Orissi  originated  in  the  Hindu  temples  of  the Eastern coastal state of Odisha or Orissa in India.

Orissa  has  been  called  the  land  of  temples,  of which many are at Bhubaneshwar and Puri. These temples were the centres of art and culture as well as of religion. Odissi dance pays great importance to Lord Jagannath.

Female  dancers  known  as Maharis along  with their  male  colleagues  known  as Gotipuas were dedicated for service in the temples.

The Maharis who used  to undergo  rigorous training in the dance form, performed in temples and enacted spiritual poems and religious plays. This way, they have preserved this art.

The gotipuas were  dressed  like  the Maharis .  They  also  danced  in  the temples  however,  at  the  age  of  18, they  had  to  leave  the  temple.  They eventually became dance teachers.

In this image we can see a group of people standing and posing for a photo.

<!-- image -->

The Nata Mandir was especially built for the performance of devotional songs by the Maharis .

Odissi has greatly been  inspired by compositions of the 8th century Shankaracharya or the 12 th  century Sanskrit poet Jayadeva's epic poem 'Gita Govind'.

Odissi depicts mainly lasya aspect of dance. It focuses on a concept known as Tribhangi , which literally means three parts. The dance comprises of three major movements styles exhibited through the head, chest and pelvis area. The dancer depicts excellent body movements, expressions, impressive gestures and sign language.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- World-famous, honouring, culturing, 8-shaped, propagation,  founder,  speed,  form,  interpretative,  enchantress, gliding,  circular,  story-play, maharis, gotipua, tribhangi.

<!-- image -->

- Manipuri dance originated from Manipur. It was performed  by  the  Meiti  people.  King Bhagyachandra contributed greatly for Manipuri dance.
-       Kuchipudi is a dance-drama from Andhra Pradesh. Sidhyendra Yogi was the founder of this dance form.
-       Mohini Attam comes from Kerala. It is known as the dance of the enchantress and has the lasya style of dancing.King Maharaja Swati Tirunal popularised Mohini Attam .
- Kathakali is a dance-drama from Kerala and literally means story-play. It is famous for its heavy and colourful costumes. It was initially known as Rama Attam. Vallathol Narayan Menon gave Kuchipudi its present form.
-       Odissi originated from Odissa. It reveres Lord Jagannath. Maharis are the dancing girls while the dancing boys are known  as Gotipuas. Odissi has themes taken from Jayadeva's poems.

<!-- image -->

Students will have to work in group to submit a project work.

Each  group  has  to  choose  only  one  topic from the list below:

- Manipuri
- Kathakali
- Kuchipudi
- Odissi
- Mohini Attam

## Assessment

## Exercise 1

## Answer the following questions:

- (i)    Anciently performed by ' Maharis ' or female temple servants, this dance form has a close association with temples and temple sculptures. It originated in Odisha. Which dance is it?
- (ii)   The meaning of the name of this dance is story play. This form of dance is known for its heavy, intense make up and costume. This dance originated in kerala.

Which dance is it?

- (iii)  The meaning of the name of this dance is beautiful dancing woman. Thus this form of dance represents a beautiful feminine grace. This dance is based on love and emotion themes. This dance originated in kerala.

Which dance is it?

## Exercise 2

## State whether the following statements are TRUE or FALSE.

- (i) Devadasi-s were allowed to dance for entertainment.
- (ii) Initially, Kuchipudi was known as Rama attam.
- (iii) Odissi depicts mainly lasya aspect of dance.
- (iv) Manipuri consists of movements of 2- shaped pattern.
- (v) Mohini Attam literally means dance of enchantress.

In this image we can see a poster with some text and images.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Describe the costume used by a male and female dancers of the Hindu and Moghul period.
- List the make-up and ornaments used by male and female dancers of the Hindu and Moghul period.
- State the main differences between the Hindu and Moghul costumes, make-up and ornaments.

## 7.0 Costume and makeup for Kathak Dance

The costumes, make-up and ornaments are the Aharya Abhinaya, as  mentioned in  the Natya Shastra .  These are used to enhance both the nritta and nritya aspects  of  the  dance.  Today,  kathak  dancers  have  considerable  amount  of choices in costumes, either that of the Hindu period, or the Muslim period. The temple-inspired style can be defined as the Hindu costumes and the Musliminspired ones as the Muslim-type costumes.

<!-- image -->

In this image we can see a person standing and smiling.

<!-- image -->

In this image we can see a woman standing and smiling. There are some people sitting on the floor. There is a man sitting on the floor. There is a table. There is a wall. There is a door.

<!-- image -->

Since  ancient  times,  kathak  has  related  stories  from  Hindu  epics  and  mythologies. It flourished in the precincts of the temples till the 16th century.Thereafter, the history of Kathak developed steadily during the course of many eras, imbibing several influences.

With the rise of the Muslim Empire in the 15th century and after its acquaintance with music and dance of the Persians, some major changes took place in the dance style, mostly in the costumes. The Muslim costumes became so popular and closely associated with kathak that many people believed that this dance was brought by the Moghuls.

The  most  remarkable  kathak  dance  item  is  the Raas-Leela .  In  this  dance the girls wear traditional costumes. The main dancer often wears a peacock feather on the head and holds a flute or dancing sticks to portray Lord Krishna. Otherwise the dancer does not change the costumes, as a single performer may start and end a kathak performance in one costume only.

In this image we can see a person wearing a costume and smiling. In the background there is a person standing and there is a curtain.

<!-- image -->

In this image we can see a group of people standing on the stage. In the background there is a wall.

<!-- image -->

## 7.1  HINDU PERIOD

## 7.1.1 Costume of male dancers

The  traditional  costume  for  men  is  the  brocade bordered  silk dhoti. He  is  usually  bare-chested except for the janev (sacred thread). The dhoti is tied around the waist with many pleats between the legs  to  give  a  loose-trouser  effect. A  silk  scarf  is tied round the waist. Nowadays, very few maintain this traditional ones. Most of them prefer kurta with dhoti or pyjama and tying the waist is optional.

In this image we can see a person standing on the floor. The person is wearing a costume.

<!-- image -->

In this image we can see a person standing and holding a stick.

<!-- image -->

Did you Know?

A  kurta  is  a  loose  collarless shirt.  The  front  and  back  of  a traditional  kurta  are  made  of rectangular pieces, and its side-seams are left open at the bottom, up to varying lengths, to enable ease of movement.

In this image we can see a woman standing and dancing.

<!-- image -->

## 7.1.2 Costumes of female dancers

The oldest costume in the Hindu period is a set of lehenga/ghaagra, choli and orhni . The ghaagra is a long, fully pleated and gathered skirt. There are narrow silver or gold bands that radiate all the way from the waist to the edge of the skirt, that highlight the dance motion.

The choli or blouse that covers the upper body has embroidered sleeve-bands. The ghaagra is usually contrasted with a choli of different colour which can be either a loose or tight fitting blouse.

In this image we can see a woman standing and smiling. She is wearing a blue color dress. In the background there is a black color background.

<!-- image -->

A light orhni or scarf as a veil is draped over the head and left shoulder. It can be transparent or a normal one which is interwoven with gold patterns.

Another costume which is popular is the sari. The silk sari has a wide gold border and 'pallav' which is taken round the waist and allowed to hang down from it on the left side to show its full beauty.

## 7.2 Moghul Period

## 7.2.1 Costumes of male dancers

Costumes for a male dancer is the kurtachuridar .  The kurta can  be  a  simple one  and  that  is  adapted  for  dance  to incorporate wider flare. It is usually at knee-length.  The churidar is  a  figure hugging  trousers  folded  up  giving  the look  of  cloth  bangles  at  the  ankles. Men may also wear an angarkha ,  the Sanskrit term anga-rakshaka meaning 'limb-keeper'.

In this image we can see a person standing.

<!-- image -->

It is a set consisting of churidar, kameez or kurta (long Shirt). The angarka is a particularly older variety of costumes which also include the small peaked cap.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 7.2.2 Costumes of female dancers

The  female  costumes  consist  of  an angarkha .  The  design  is  similar  to a churidar and kameez .  The  upper part is tighter or more fitting and the skirt  portion  is  cut  on  the  round  at the waist to enhance the flare of the lower half while doing the chakkar-s . Sometimes the dancer wears a long coat  covering the arms and the upper body.

In this image we can see a person standing on the floor.

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

A bandi is  a  small  waistcoat  which  is an optional accessory worn to enhance the  bust-line.  Underneath  the  top,  the legs are covered by the churidar. The head is covered with either an orhni or a small peaked cap. Dancers also wear a belt made of zari or precious stones round the waist.

## 7.3 Make-up and Ornaments of a kathak dancer

Vivid  face  make-up  helps to highlight the facial expressions of the dancer. The graceful movements of different parts of the body such as the eyes, head, hands and feet are synchonised with the music and usually narrates a story.

The costumes are well complemented with the traditional ornaments which are usually of a golden colour. These  ornaments are used to adorn the hair, nose, ears, neck, waist, hands, arms, fingers and ankles.

However,  jewelleries  of  the  male  dancer are quite simple compared to that of female dancers and are usually made of stones. It  is  easy for the spectators to notice and appreciate  the  movement  of  the  eyes, head and hands. This is so because they are  more  visible  and  enhanced  by  the make-up and jewelleries. But it might not be  so  easy  to  distinguish  and  follow  the foot movements.

In this image we can see a woman standing and dancing.

<!-- image -->

In this image we can see a woman wearing a red and brown color dress. She is wearing a necklace and earrings.

<!-- image -->

Moreover,  Kathak  dance  uses  complex  foot movements through which the dancing skills of the dancer is emphasised.

Therefore, the purpose of the sound produced by the ghungroo-s is a vital aid. Ghungroo-s are worn by both male and female dancers and also, it is a musical accessory used in music as well.

## 7.3.1 Make-up and Ornaments of a male dancer

A long tilak is predominant among all the make-up for the male dancers. The tilak or tika on the forehead is of white or red colour and thus distinguishes the style as the Hindu period. Male dancers usually wear bajuband or an arm-band especially while performing bare-chested and with earrings also at times.

In this image we can see a person standing and doing a pose.

<!-- image -->

In this image we can see a person standing.

<!-- image -->

The make-up for the eyes is the black eyeliner or kajal ,  the  contour  of  the eyes are highlighted. Nowadays dancers use eye shadows and dark blush. Foundation cream and talcum powder are used for fair complexion and a light lipstick  is  permissible.  During  the  Muslim  period,  dancers  used  to  eat  betel leaves to render their lips red.

## Note to Teacher

The images provided in this chapter may not reflect the specific contents. Teacher is suggested show more appropriate pictures where necessary.

## 7.3.2 Make-up and Ornaments of female dancer

The make-up of a female dancer is more elaborate. Foundation cream, face powder, eye shadow, collyrium, dark blush, lipstick  and  bindi  or  a  coloured dot  are  the  basic  ones. Also  the alta or mahawar, a  red  coloured  liquid,  is used to make designs on the hands and feet. Female dancers usually wear heavy make-ups, especially the contour of the eye which is highlighted and is elongated at the end.

Among the jewelleries there are multiple gold necklaces, mang-tikka , bangles, earrings,  rings,  nose  rings, bajuband (arm  band), kamarband (waist-band), paranda (decorated lace) and flowers to adorn the hair. Ghungroo-s and other anklets are also part of the traditional costumes and jewelleries.

A jhumar or chapka is an ornament for the head and depicts the jewellery of a Muslim lady. It is a fan-shaped piece which rests flat on one side of the head. Dancers of the Mughal period used to wear chapka ,  a  lavish  jewellery  with stones thus the chapka gat became part of the repertoire.

In this image we can see a woman wearing a red and gold color dress. She is holding a red color object in her hand.

<!-- image -->

## Male costumes  and jewelleries

Hindu

- dhoti , scarf.

Necklace, tilak , earrings, arm bands, ghungroo-s .

- Moghul

- kurta- churidar or angarkha , cap.

Necklace, earrings, ghungroo-s .

## Female costumes and jewelleries

Hindu

- ghaagra or lehenga choli, orhni , saree and choli . Necklaces, bangles, nose-rings, earrings, rings, bindi , mang-tika, parranda , flowers, anklets, ghungroo-s .

- Moghul

- Churidar-kamee z or angarkha , cap. Necklaces, bangles, chapka , earrings, nose-rings,

parranda, flowers, pins.

<!-- image -->

- The history of Kathak developed steadily during the course of many eras, thus imbibing several influences.
- Today kathak dancers have a considerable amount of choices of costumes, either that of the Hindu period or the Muslim  period.
- The costumes, make-up and jewelleries are the Aharya Abhinaya.
- Face make-up helps to highlight the facial expressions of the dancer.
- Ghungroo-s are worn by both male and female dancers.

Did you Know?

Kathak  dancers  usually  wear  traditional  costumes  for kathak  dance  recitals.  However,  many  dancers  make use of contemporary costumes in kathak dance ballets.

<!-- image -->

Professional, elements, mnemonics, precincts, ornaments, aharya, raas-leela, adorn, traditional, dhoti, churidar, kameez, angarkha, orhni, choli, accessories, elaborated, highlight.

<!-- image -->

With  the  help  of  your  teacher,  form  a  group  or pairs.

- Each group or pair should search online the appropriate images of :
- a) Costumes and Ornaments of -
- (i) Male Hindu dancer
- (ii) Male Muslim dancer
- (iii) Female Hindu dancer
- (iv) Female Muslim dancer
- b) Each group or pair to find the similarities and comparison between the two style of costumes and ornaments.

## Assessment

Exercise 1

List the costumes of male and female kathak dancer of the Hindu period.

………

…………………………………………………………………………

…………………………………………………………………………………

…………………………………………………………………………………

…………………………………………………………………………………

Exercise 2

Tick  the box to identify the appropriate costumes and ornaments used by a female kathak dancer of the Moghul period.

Dhoti and ghungroo-s

Lehenga choli and bangles

Churidar kameez, chapka and ghungroo-s

Ghaagra, choli and necklaces

Angharkha , churidar, cap and ghungroo-s

Exercise 3

Observe the pictures below and state the style of costumes the dancer is wearing.

a.

<!-- image -->

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

b.

<!-- image -->

c.

<!-- image -->

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

……………………………………………………

Exercise 4

Compare the costumes, make-up and ornaments worn by male dancers of  Hindu and Moghul periods?

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………….............................

## NOTES

In this image we can see a collage of different images of women.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Define the term prelude.
- Explain the prelude ' ek samaya grihasso ...'.
- Define the terms thumri and sthayi .
- Explain the sthayi ' kahe rokata dagar ....'.
- List a few hand gestures in the performance of the prelude of the thumri .
- Perform the prelude ' ek samaya grihasso ...' and sthayi of the thumri with proper facial expressions and hand gestures.
- Give an oral explanation of the episode behind the prelude and sthayi of the thumri .
- Demonstrate the prelude and sthayi of the thumri by stating the hand gestures used.

## 8.0 Meaning of term the THUMRI

The term ' thumri '  refers  to  the  Hindi word ' thumakana '  meaning to execute dancing movements or steps so as to tinkle the ghungroo-s or ankle bells.

Thumri is  a  light  or  semi-classical form of  singing  always  sung  in  a  striking note of tenderness. The origin of this

In this image we can see a woman wearing a dress is sitting and holding a flower in her hand.

<!-- image -->

style of singing is traced into the Mughal court of Oudh. The wordings or lyrics are in the form of poems and are normally in Uttar Pradesh dialects of Hindi called Awadh and Brij language.

In this image we can see a woman standing and holding a flower.

<!-- image -->

Thumri is  romantic or devotional in nature and  the  poetic  songs  in  this  style  are recognised as shringar rasa meaning joy and love.

The theme of the poem is often related to  the  emotion  of  love  at  a  stage  of separation or union and the most common ones are Lord Krishna's courtship with the gopis and Radha.

## 8.1 Thumri composed by Bindadin Maharaj

The thumri depicts a theme involving Radha and Krishna, both at a very young age.

Ek Samay Grihaso Nikassi Ayi Pahen Cheer Kusum Ki Saree Khelata Kudata Jayi Rahi Nandalall Ki Bari

Kaanch Kali Ek Tod Layi

Jinha Kaaran Baah Marorat Maari Aag Lagi Brij Ki Bagiyan Mein Ek Phool Ke Kaaran Laakh De Gaari

Kahe Rokata Dagar Pyare Nandlall More Nit hi Karata Jhagara mose Panghat Nahi Jane Det Dekhat Sab Nari Mohe Bagiya kyun gahe Re Binati Karoun mein Nahin wo Manata Sunata Nahin More Chin leen le Gale ko haar Mangoun Nahin Det Barbas Mohe Laaj Let Binda Dekho Dhit Langar Doungi Doohayi Ab hi Jaye Nandji Ke Dere

## 8.1.1 Prelude

A prelude is an introductory piece of music. It can be an opening to an act or a performance or an event preparing for the main or important part of the action to be presented. In kathak, it is a piece of music or a song which has a meaning accompanied with movements and that, basically, introduces the theme of the principal subject.

The prelude of the above thumri can be translated as follows:

'Once Radha sets off from her house. She is wearing a saree as beautiful as a flower. She playfully heads towards Nandlall's  garden. She plucks a tender flower bud, for which Krishna twists her wrist.

Radha exclaims,

'May your garden get destroyed, because of one flower you said so many harsh words to me.'

## 8.1.2 THUMRI

Translation: Radha is saying,

'Why are you stopping my path beloved Son of Nandlall? You always quarrel with me. You are not letting me to go to the bank of the river. All the ladies are watching me. Why you holding my hand, I plead to you to let me go. He is neither agreeing nor listening to me. He has snatched my necklace. He is not giving it back despite asking him. Bindaji, see the stubborn lad, I am so embarassed.

I will go to house of Nand, to complain to him'.

## Meaning of the thumri:

Radha says,

'For one flower, you are saying thousands of harsh words to me. May your garden get destroyed'.

Radha asks the reason why he is on her way and he is always quarrelling with her. Krishna is not letting her go to the well to fill her pot of water. Every lady is looking at her since Krishna is holding her hand to prevent her from going away. He even snatches her chain. So, Radha requests Bindadin Maharaj Ji to witness the stubbornness of Krishna. The latter tries to humiliate her. So, Radha decides to go to Nandji's house to complain about Krishna.

## Note to Teachers

Choreography of the thumri should not be restricted to specific  hand gestures and dance movements. The teacher is free to use movements deemed appropriate.

In this image we can see a woman standing and holding a stick in her hand.

<!-- image -->

<!-- image -->

- A prelude is an introductory piece of music or song to introduce a theme in kathak.
- The term ' thumri ' refers to the Hindi word 'thumakana' meaning to execute dancing movements.
- The wordings or lyrics are in form of poems and are normally in Uttar Pradesh dialects of Hindi called Awadh and Brij language.
- 'Thumri' is romantic or devotional in nature and is usually a light or semi-classical form of singing.
- The theme of the poem is often related to the emotion of love at a stage of separation or union.

<!-- image -->

Prelude, introductory, thumri , thumaka , romantic, devotional,  semi-classical,  poetic,  love,  separation, union, shringar rasa .

## Assessment

## Exercise 1

## Match the statement of column A with its appropriate meaning in column B:

| Column A                                                | Column B                                                             |
|---------------------------------------------------------|----------------------------------------------------------------------|
| Ek Samay Grihaso Nikassi                                | She was playfully heading towards the garden of Nandlall.            |
| Ayi Pahen Cheer Kusum Ki Saree                          | May your garden gets destroyed.                                      |
| Khelata Kudata Jayi Rahi Nandalall Ki Bari              | Why are you preventing me?                                           |
| Kaanch Kali Ek Tod Layi Jinha Kaaran Baah Matorat Maari | Once Radha sets off from her house                                   |
| Aag Lagi Brij Ki Bagiyan Mein                           | She plucks a tender flower bud, for which Krishna twisted her wrist. |
| Kahe Rokata Dagar Pyare Nandlall More                   | She was wearing a saree as beautiful as a flower.                    |

## Exercise 2

List some hand gestures used in the thumri you learnt.

................................................................................................................

................................................................................................................

Exercise 3

Describe the followings:

- (a) Prelude

................................................................................................................

................................................................................................................

(b) Thumri

................................................................................................................

................................................................................................................

In this image we can see a poster with some images and text.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Elaborate on the term taal
- Describe Roopak taal , Jhaptaal and Ektaal
- Memorise the theka-s of Roopak taal , Jhaptaal and Ektaal
- Examine the structures of Roopak taal , Jhaptaal and Ektaal
- Identify the tali , khali of each of the prescribed taal-s
- Differentiate between Roopak taal , Jhaptaal and Ektaal
- Count and recite the theka of the prescribed taal at a given regular rhythm  (clapping and wave of hands with correct pronunciation).

## 9.0  TAAL

The term taal is an important component which forms the rhythmic framework in music and dance. A taal is a rhythmic cycle consisting of different components. It is used as a yardstick to measure time.

The Sanskrit phrase Kar tal dwani refers to the 'clapping of palms of hands'. In Indian Music and dance it also refers to a ' taali ' (clap) which is used to count the beats of rhythmic pattern, specially of the musical instruments such as tabla. It normally comprises avartan , that is, a fix-length cycle which is divided into basic time units called matra. The basic specific beats or matra-s are grouped into sections called vibhaag-s and each is indicated through the hand gestures such as taali or khali .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The starting point of a taal is called sam . It is the strongest accented beat of a taal. Khali is the unaccented beat. Hence the patterns of both tali and khali in avartans decide the accents of the taal. There are many taal-s , each having its own distinct characteristics and theka-s . Some examples of taal-s are dadra, kaherwa, jhaptaal, teentaal, dhamar and so on. Kathak compositions are based on many of these taal-s but teentaal is the most frequently used.

<!-- image -->

## 9.1 Importance of Taal in Music

There are two main systems of music that have evolved from ancient Hindu traditions.   These  are  the  Hindustani  and  Carnatic  Music.  Hindustani  music is the system of music commonly associated with the northern part of Indian classical Music while Carnatic music is associated with the southern part.

Kathak dance follows the Hindustani music system. The whole performance is set to a particular taal and laya which should be followed by the dancer with utmost precision. The taal provides support and coordination to the performance of both the dancer and the accompanying artists. Also it measures time and thus provides a framework as well as a guide.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Taal brings  life  to  music.  It  makes  music  meaningful and creates an impact on the audience. A taal performed in specific laya enhances the mood or the sentiment  one  wishes  to  express.  The kathak dancer  strikes  the  different statuesque poses at the end of the compositions, thus denoting the sam of the the taal.

## 9.2 Roopak Taal

Roopak  Taal is  a  popular taal in  Hindustani  music.  It  is  a  short range rhythmic cycle. One avartan of a roopak taal comprises seven matra-s which  are  divided into three vibhag-s and  are not of equal length. The first vibhag has three matra-s and  the  remaining two have two matra-s in each.

Roopak Taal is unique among the taal-s .  The  first  beat,  that  is,  the sam , is represented by a wave of the  hand.  The  specificity  of  this

In this image, we can see a diagram. In the diagram, we can see a few shapes.

<!-- image -->

taal is that both the sam and khali are taken on the first matra . Sam is on the first matra of the first vibhag and is shown by a wave, that is, a khali .

| Taal   | :   | Roopak                      |
|--------|-----|-----------------------------|
| Theka  | :   | Tin Tin Na Dhin na Dhin Na  |
| Matra  | :   | 7                           |
| Vibhag | :   | 3 (3 - 2 - 2 )              |
| Khali  | :   | 1 ( on 1 st matra )         |
| Taali  | :   | 2 ( on 4 th and 6 th matra) |

## Taal Roopak in Notation Form

| Matra-s Theka   | : 1 :   | 2   | 3   | 4    | 5   | 6    | 7   |
|-----------------|---------|-----|-----|------|-----|------|-----|
|                 | Tin     | Tin | Na  | Dhin | Na  | Dhin | Na  |
| Taal Sign       | : X     |     |     | 2    |     | 3    |     |
|                 | : Tin   |     |     |      |     |      |     |
|                 | : X     |     |     |      |     |      |     |

## 9.3 Jhaptaal

Jhaptaal is  one  of  the most  famous taal-s of Hindustani music after teentaal . It comprises ten matra-s which are divided into four vibhag-s .

The structure of the vibhaag-s are 2-3-2-3. There are three Taali on the 1st , 3rd and 8th beat. Khali is on 6th beat.

In this image we can see a diagram of a circle. In the diagram we can see the numbers and the text.

<!-- image -->

| Taal   | :   | Jhaptaal                                 |
|--------|-----|------------------------------------------|
| Theka  | :   | Dhin na Dhin Dhin Na Tin Na Dhin Dhin Na |
| Matra  | :   | 10                                       |
| Vibhag | :   | 4 ( 2 - 3 - 2 - 3 )                      |
| Khali  | :   | 1 ( on 6 th matra )                      |
| Taali  | :   | 2 ( on 4 th and 8 th matra)              |

## Jhaptaal in Notation Form

Did you

Know?

Roopak taal may be found in any musical style such as film songs, Khayals , Ghazals and instrumentals.

## Note to Teachers

Students should be guided to recite the prescribed taal-s in ekgun beat only.

## Note to Students

Students should properly examine the sam , taali , khali and theka of each taal .

## 9.4 Ektaal

Ektaal is one among the popular taal-s in  north Indian classical music. It consists of twelve matra-s divided into  six  equal vibhag-s .  The peculiarity of Ektaal is  that  The taali-s are on the 1st, 5th, 9th and 11th matra-s . The khali is on the 3rd and 7th matra-s .

Ektaal is played in a range of laya-s mostly  the ati  vilambit or ati drut laya .

The image is a circular diagram with a large yellow circle in the center. The circle has various colors and shapes, including a blue, green, orange, and purple section. The colors and shapes are arranged in a circular pattern, with the yellow section at the top and the purple section at the bottom.

At the top of the diagram, there is a title that reads "Ektaal". Below the title, there are several smaller circles with different colors and shapes. These circles are arranged in a circular pattern, with the yellow section at the top and the purple section at the bottom.

The diagram includes various percentages and percentages of different values. The percentages are as follows:
- The yellow section at the top has a value of 10.
- The green section at the top has a value of 12.
- The orange section at the top has a value of 12.
- The purple section at the top has a value of

<!-- image -->

<!-- image -->

Taal

: Ektaal

Theka

: Dhin Dhin DhaGe Tirket Tu Na kat  Ta Dhage Tirket Dhin Na : 12

Matra

Vibhag

: 6 ( 2 - 2 - 2 - 2 - 2 - 2 )

Khali

: 2 ( on 3 rd and 7 th  matra )

Taali

: 4 ( on 1 st , 5 th , 9 th and 11 th  matra)

## Ektaal in Notation Form

| Matra-s     | :   | 1 2       | 3 4          | 5   | 6   | 7   | 8   | 9 10         | 11   | 12   |
|-------------|-----|-----------|--------------|-----|-----|-----|-----|--------------|------|------|
| Theka       | :   | Dhin Dhin | Dhage Tirket | Tu  | Na  | Kat | Ta  | Dhage Tirket | Dhin | Na   |
| Taal Sign : |     | X         | 0            | 2   |     | 0   |     | 3            | 4    |      |
|             | :   | 1         |              |     |     |     |     |              |      |      |
|             | :   | Dhin      |              |     |     |     |     |              |      |      |
|             | :   | X         |              |     |     |     |     |              |      |      |

<!-- image -->

Sam , khali , taali , Asymmetric, Khayal , Ghazals .

<!-- image -->

- Taal is used as a rhythmical framework in which musical compositions are set.
- There are two main systems of music that have evolved from  ancient Hindu traditions Hindustani and Carnatic Music System.
- Kathak dance follows the Hindustani music system.
- Roopak Taal is comprised of seven beats.
- Jhaptaal is comprised of ten beats.
- Ektaal comprises of twelve beats.

## Assessment

## Exercise 1

## Describe the following taal-s .

- I. Ektaal .
- II. Jhaptaal .
- III. Roopak taal .

## Exercise 2

## Write down the characteristics of the following taal -s.

- I. Jhaptaal .
- II. Ektaal .
- III. Roopak taal .

## Exercise 3

- I. Define	the	term taal .
- II. Elaborate the concepts 'taal ' and its importance.

## Exercise 4

## Write the following taal-s into notation form:

- I. Roopak taal .
- II. Jhaptaal .

## Exercise 5

## Differentiate	between	the	following	two taal-s

- I. Ektaal and Roopak taal .
- II. Roopak Taal and Jhaptaal .
- III. Jhaptaal and Ektaal

In this image we can see a poster with some text and images.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Memorise the compositions.
- Identify the different actions of the hand.
- Interpret signs and symbols used in the notation.
- Notate all the compositions learnt in vilambit and madhya laya .
- Notate the tukda-s learnt in drut laya .
- Notate the roopak taal, Jhaptaal and Ektaal.
- Interpret the correlation between Taal and Laya.
- Count and recite all the compositions learnt at a given regular rhythm (with right clapping and waving of the hands and correct pronunciation).
- Count and recite the Roopak Taal, Jhaptaal and Ektaal at a given regular rhythm (with right clapping and wave of the hands and correct pronunciation).

<!-- image -->

## Introduction

Literally, padhant means recitation. It is the actions of executing taal and at the same time reciting the bol-s . Kathak dancers usually recite the compositions in the designated taal and laya before each and every dance demonstrations. While  doing padhant ,  it  is  important  that  the  pronunciation,  articulation  and intonation are done appropriately in the specific taal and laya . For example, the bol-s Thun and Digdig should not be heard as Tun and tigtig respectively.

Kathak  uses  the  Bhatkhande  Notation  System  to  notate  the  various  dance compositions set to specific taal-s and laya-s . The  notations help  to memorise the  compositions  and  perfect  oneself  in padhant-s .  Notation  form  is  very important as it facilitates the accompanists and the kathak dancer altogether in  reciting,  understanding  and  executing  the  rhythmic  compositions  in  the appropriate taal-s and laya-s .

## INTERPRETATION OF SIGNS AND SYMBOLS ARE GIVEN IN THE TABLE BELOW:

| Signs and symbols   | Representation        |
|---------------------|-----------------------|
| 'X'                 | Sam                   |
| 2 , 3 , .....       | Tali                  |
| '0'                 | Khali                 |
| (Vertical line)     | Vibhag                |
| S                   | Pause (Gap)           |
|                     | Grouping of Syllables |

## KATHAK DANCE COMPOSITION

| Vilambit Laya   | Madhya Laya   | Drut Laya   |
|-----------------|---------------|-------------|
| Thaat           | Tukda         | Tukda       |
| Toda            | Toda          | Gat         |
| Paran           | Paran         | Paran       |
| Tihai           | Kavit Toda    |             |

## NOTATION FORMS FOR CHAPTER 3 - Tatkaar and Chakkar

| 16 ThaiTat   | ThaiTat   | ThaiTat   | ThaiTat       | ThaiTat   | ThaiTat   |
|--------------|-----------|-----------|---------------|-----------|-----------|
| 15 AaThai    | AaThai    | AaThai    | AaThai AaThai | AaThai    |           |
| 14 ThaiTat   | Tat       | ThaiTat   | ThaiTat       | ThaiTat   | ThaiTat   |
| 13 TaThai    | 3 Tat 3   | TaThai    | TaThai 3      | TaThai 3  | TaThai 3  |
| 12 ThaiTat   | ThaiTat   | Tat       | Tat           | ThaiTat   | SS        |
| 11 AaThai    | TaThai    | Tat       | ThaiTat       | AaThai    | ThaiS     |
| 10 ThaiTat   | Tat       | Tat       | TaThai        | ThaiTat   | ThaiTat   |
| 9 TaThai     | 0 Tat 0   | Tat       | Tat 0         | TaThai 0  | AaThai 0  |
| 8 ThaiTat    | ThaiTat   | ThaiTat   | ThaiTat       | ThaiTat   | ThaiTat   |
| 7 AaThai     | AaThai    | AaThai    | AaThai        | AaThai    | TaThai    |
| 6 ThaiTat    | Tat       | ThaiTat   | ThaiTat       | ThaiTat   | SS        |
| 5 TaThai     | 2 Tat 2   | TaThai    | TaThai 2      | TaThai 2  | ThaiS 2   |
| 4 ThaiTat    | ThaiTat   | Tat       | Tat           | ThaiTat   | ThaiTat   |
| 3 AaThai     | TaThai    | Tat       | ThaiTat       | AaThai    | AaThai    |
| 2 ThaiTat    | Tat       | Tat       | TaThai        | ThaiTat   | ThaiTat   |
| 1 TaThai     | X Tat X   | Tat       | Tat X         | TaThai X  | TaThai X  |

## NOTATION FORMS FOR CHAPTER 3 - Tatkaar and Chakkar

|   16 | ThaiTat   | ThaiS    | ThaiTat   | TaS      |      | 16   | 2        | ThaiS    | ThaiTat   | 6            |
|------|-----------|----------|-----------|----------|------|------|----------|----------|-----------|--------------|
|   15 | TaThai    | TaS      | AaThai    | ThaiS    |      | 15 1 |          | TaS      | AaThai    | 5            |
|   14 | SS        | ThaiS    | ThaiTat   | ThaiTat  |      | 14   | SS       | ThaiS    | ThaiTat   | 4            |
|   13 | ThaiS 3   | ThaiS 3  | TaThai 3  | AaThai 3 |      | 13   | ThaiS 3  | ThaiS 3  | TaThai 3  | 3 3          |
|   12 | TaS       | TaS      | SS        | ThaiTat  |      | 12   | TaS      | TaS      | SS        | 2            |
|   11 | ThaiS     | ThaiS    | ThaiS     | TaThai   |      | 11   | ThaiS    | ThaiS    | 7         | 1            |
|   10 | ThaiS     | ThaiTat  | TaS       | SS       |      | 10   | ThaiS    | ThaiTat  | 6         | SS           |
|    9 | TaS 0     | AaThai 0 | ThaiS 0   | ThaiS 0  |      | 9    | TaS 0    | AaThai 0 | 5 0       | ThaiS 0      |
|    8 | ThaiS     | ThaiTat  | ThaiTat   | TaS      |      | 8    | ThaiS    | ThaiTat  | 4         | TaS          |
|    7 | ThaiS     | TaThai   | AaThai    | ThaiS    |      | 7    | ThaiS    | TaThai   | 3         | ThaiS        |
|    6 | TaS       | SS       | ThaiTat   | ThaiS    |      | 6    | TaS      | SS       | 2         | ThaiS        |
|    5 | ThaiS 2   | ThaiS 2  | TaThai 2  | TaS 2    |      | 5    | ThaiS 2  | 7 2      | 1 2       | TaS 2        |
|    4 | ThaiTat   | TaS      | SS        | ThaiS    |      | 4    | ThaiTat  | 6        | SS        | ThaiS        |
|    3 | AaThai    | ThaiS    | ThaiS     | ThaiS    |      | 3    | AaThai   | 5        | ThaiS     | ThaiS        |
|    2 | ThaiTat   | ThaiTat  | TaS       | TaS      |      | 2    | ThaiTat  | 4        | TaS       | TaS          |
|    1 | TaThai X  | AaThai X | ThaiS X   | ThaiS X  | Ta X | 1    | TaThai X | 3 X      | ThaiS X   | ThaiS X Ta X |

## NOTATION FORMS FOR CHAPTER 3 - Tatkaar and Chakkar

|   16 | Dig   | Dig   | DigDig        |
|------|-------|-------|---------------|
|   15 | Dig   | Dig   | TigDha        |
|   14 | Dha   | Dha   | DigDig        |
|   13 | Tig 3 | Tig 3 | TigDha 3      |
|   12 | Dig   | Dig   | DigDig        |
|   11 | Dig   | Dig   | TigDha        |
|   10 | Dha   | Dha   | DigDig        |
|    9 | Tig 0 | Tig 0 | TigDha 0      |
|    8 | Dig   | Dig   | DigDig        |
|    7 | Dig   | Dig   | TigDha        |
|    6 | Dha   | Dha   | DigDig        |
|    5 | Tig 2 | Tig 2 | TigDha 2      |
|    4 | Dig   | Dig   | DigDig        |
|    3 | Dig   | Dig   | TigDha        |
|    2 | Dha   | Dha   | DigDig        |
|    1 | Tig X | Tig X | TigDha X Ta X |

5 - Step Chakkar in Teentaal - Madhya Laya

|   16 | DigDig   | TaS             |
|------|----------|-----------------|
|   15 | TigDha   | ThaiS           |
|   14 | ThaiS    | DigDig          |
|   13 | DigDig 3 | TigDha 3        |
|   12 | TigDha   | ThaiS           |
|   11 | ThaiS    | DigDIg          |
|   10 | TaS      | TigDha          |
|    9 | ThaiS 0  | ThaiS 0         |
|    8 | DigDig   | DigDig          |
|    7 | TigDha   | TigDha          |
|    6 | ThaiS    | ThaiS           |
|    5 | DigDig 2 | TaS 2           |
|    4 | TigDha   | ThaiS           |
|    3 | ThaiS    | DigDig          |
|    2 | DigDig   | TigDha          |
|    1 | TigDha X | ThaiS X ThaiS X |

## NOTATION FORMS FOR CHAPTER 3 - Tatkaar and Chakkar

|   16 | TaS      | TaS      | TaS      |    | 16 DigDig   |      |   16 | DigDig      |
|------|----------|----------|----------|----|-------------|------|------|-------------|
|   15 | ThaiS    | ThaiS    | ThaiS    | 15 | TigDha      |      |   15 | TigDha      |
|   14 | ThaiS    | ThaiS    | ThaiS    | 14 | ThaiS       |      |   14 | ThaiS       |
|   13 | TatTat 3 | TatTat 3 | TatTat 3 | 13 | TigDha 3    |      |   13 | TigDha 3    |
|   12 | ThaiS    | ThaiS    | ThaiS    | 12 | TigDha      |      |   12 | TigDha      |
|   11 | TatTat   | TatTat   | TatTat   | 11 | ThaiS       |      |   11 | ThaiS       |
|   10 | ThaiS    | ThaiS    | ThaiS    | 10 | DigDig      |      |   10 | DigDig      |
|    9 | TatTat 0 | TatTat 0 | TatTat O |  9 | TigDha 0    |      |    9 | TigDha 0    |
|    8 | S        | S        | S        |  8 | SS (1-step) |      |    8 | SS (1-step) |
|    7 | Thai     | Thai     | Thai     |  7 | ThaiS       |      |    7 | ThaiS       |
|    6 | Tat      | Tat      | Tat      |  6 | Digdig      |      |    6 | Digdig      |
|    5 | Tat 2    | Tat 2    | Tat 2    |  5 | TigDha 2    |      |    5 | TigDha 2    |
|    4 | S        | S        | S        |  4 | S           |      |    4 | SS (1-step) |
|    3 | Thai     | Thai     | Thai     |  3 | Thai        |      |    3 | ThaiS       |
|    2 | Tat      | Tat      | Tat      |  2 | Tat         |      |    2 | DigDig      |
|    1 | Tat X    | Tat X    | Tat X    |  1 | Tat X       | Ta X |    1 | TigDha X    |

## NOTATION FORMS FOR CHAPTER 3 - Tatkaar and Chakkar

1 st  Composite Chakkar - 3 Step and 5 Step in Teentaal -  Madhya Laya

|   16 | SS       | DigDig   |
|------|----------|----------|
|   15 | ThaiS    | TigDha   |
|   14 | DigDig   | ThaiS    |
|   13 | TigDha 3 | DigDig 3 |
|   12 | S        | TigDha   |
|   11 | Thai     | ThaiS    |
|   10 | Tat      | DigDig   |
|    9 | Tat 0    | TigDha 0 |
|    8 | SS       | SS       |
|    7 | ThaiS    | ThaiS    |
|    6 | Digdig   | Digdig   |
|    5 | TigDha 2 | TigDha 2 |
|    4 | S        | S        |
|    3 | Thai     | Thai     |
|    2 | Tat      | Tat      |
|    1 | Tat X    | Tat X Ta |

In this image, we can see a table with some text and numbers.

<!-- image -->

|   16 | DigDig   |
|------|----------|
|   15 | TigDha   |
|   14 | ThaiS    |
|   13 | TigDha 3 |
|   12 | TigDha   |
|   11 | ThaiS    |
|   10 | DigDig   |
|    9 | TigDha 0 |
|    8 | SS       |
|    7 | ThaiS    |
|    6 | Digdig   |
|    5 | TigDha 2 |
|    4 | S        |
|    3 | Thai     |
|    2 | Tat      |
|    1 | Tat X    |

## NOTATION FORMS FOR CHAPTER 4 - COMPOSITION IN TEENTAAL

## Thaat in Teentaal - Vilambit Laya

In this image, we can see numbers.

<!-- image -->

|   16 | TatS    |
|------|---------|
|   15 | TatS    |
|   14 | SS      |
|   13 | ThaiS 3 |
|   12 | ThaiTa  |
|   11 | 11      |
|   10 | 10      |
|    9 | 9 0     |
|    8 | 8       |
|    7 | 7       |
|    6 | 6       |
|    5 | 5 2     |
|    4 | 4       |
|    3 | 3       |
|    2 | 2       |
|    1 | 1 X     |

## Toda in Teentaal - Vilambit Laya

|   16 | SS     |    | DigDig   |      |    |
|------|--------|----|----------|------|----|
|   15 | ThaiS  |    | TigDha   |      |    |
|   14 | TigTig |    | ThaiS    |      |    |
|   13 | TigDha | 3  | DigDig   | 3    |    |
|   12 | Thun   |    | TigDha   |      |    |
|   11 | Thun   |    | ThaiS    |      |    |
|   10 | Tat    |    | DigDig   |      |    |
|    9 | Tat    | O  | TigDha   | O    |    |
|    8 | SS     |    | SS       |      |    |
|    7 | ThaiS  |    | ThaiS    |      |    |
|    6 | TigTig |    | TigTig   |      |    |
|    5 | TigDha | 2  | TigDha   | 2    |    |
|    4 | Thun   |    | Thun     |      |    |
|    3 | Thun   |    | Thun     |      |    |
|    2 | Tat    |    | Tat      |      |    |
|    1 | Tat    | X  | Tat      | X Ta | X  |

## NOTATION FORMS FOR CHAPTER 4 - COMPOSITION IN TEENTAAL

## Paran in Teentaal - Vilambit Laya

In this image, we can see some text.

<!-- image -->

|   16 | S    |    | Gena   |    |    |
|------|------|----|--------|----|----|
|   15 | Ta   |    | Gadi   |    |    |
|   14 | Dhin |    | Kata   |    |    |
|   13 | Dha  | 3  | Tita   | 3  |    |
|   12 | S    |    | S      |    |    |
|   11 | Ta   |    | Ka     |    |    |
|   10 | Ge   |    | Tata   |    |    |
|    9 | Dhi  | O  | Taki   | O  |    |
|    8 | Ge   |    | Ga     |    |    |
|    7 | Dha  |    | Thun   |    |    |
|    6 | S    |    | Ka     |    |    |
|    5 | Ga   | 2  | Tak    | 2  |    |
|    4 | Thun |    | Dha    |    |    |
|    3 | Ka   |    | Kira   |    |    |
|    2 | Ta   |    | Ta     |    |    |
|    1 | Dha  | X  | Dhet   | X  | X  |

## Tihai in Teentaal - Vilambit Laya

In this image, we can see a chart.

<!-- image -->

## NOTATION FORMS FOR CHAPTER 4 - COMPOSITION IN TEENTAAL

## Tukda in Teentaal - Madhya Laya

In this image, we can see a chart.

<!-- image -->

|   16 | TigTig   |
|------|----------|
|   15 | TigDha   |
|   14 | ThaiS    |
|   13 | TigTig 3 |
|   12 | TigDha   |
|   11 | ThaiS    |
|   10 | TigTig   |
|    9 | TigDha 0 |
|    8 | SS       |
|    7 | ThaiS    |
|    6 | TigTig   |
|    5 | TigDha 2 |
|    4 | Thun     |
|    3 | Thun     |
|    2 | Tat      |
|    1 | Tat X    |

Toda in Teentaal - Madhya Laya

|   16 | SS     |    | DigDig   |      |    |
|------|--------|----|----------|------|----|
|   15 | ThaiS  |    | TigDha   |      |    |
|   14 | TigTig |    | ThaiS    |      |    |
|   13 | TigDha | 3  | DigDig   | 3    |    |
|   12 | Thun   |    | TigDha   |      |    |
|   11 | Thun   |    | ThaiS    |      |    |
|   10 | Tat    |    | DigDig   |      |    |
|    9 | Tat    | O  | TigDha   | O    |    |
|    8 | SS     |    | SS       |      |    |
|    7 | ThaiS  |    | ThaiS    |      |    |
|    6 | TigTig |    | TigTig   |      |    |
|    5 | TigDha | 2  | TigDha   | 2    |    |
|    4 | Thun   |    | Thun     |      |    |
|    3 | Thun   |    | Thun     |      |    |
|    2 | Tat    |    | Tat      |      |    |
|    1 | Tat    | X  | Tat      | X Ta | X  |

## NOTATION FORMS FOR CHAPTER 4 - COMPOSITION IN TEENTAAL

|   16 | Kata   |    | Krish   |        |
|------|--------|----|---------|--------|
|   15 | Dama   |    | Na      |        |
|   14 | Mini   |    | Krish   |        |
|   13 | Daa    | 3  | Na      | 3      |
|   12 | Dim    |    | Krish   |        |
|   11 | Dim    |    | Rata    |        |
|   10 | Dim    |    | Taka    |        |
|    9 | Dim    | O  | Nira    | O      |
|    8 | Kata   |    | Sata    |        |
|    7 | Dhara  |    | Bara    |        |
|    6 | Riri   |    | Rasa    |        |
|    5 | Theri  | 2  | Nava    | 2      |
|    4 | Kata   |    | Chim    |        |
|    3 | Tada   |    | Chim    |        |
|    2 | Tat    |    | Chim    |        |
|    1 | Tat    | X  | Chim    | X Na X |

Paran in Teentaal - Madhya Laya

|   16 | GheGhe   |    | Gena   |    |     |
|------|----------|----|--------|----|-----|
|   15 | Ta       |    | Gadi   |    |     |
|   14 | Dhet     |    | Kata   |    |     |
|   13 | Dhet     | 3  | Tita   | 3  |     |
|   12 | Traka    |    | GheGhe |    |     |
|   11 | Ta       |    | Dha    |    |     |
|   10 | Dhet     |    | Gena   |    |     |
|    9 | Dhet     | O  | Gadi   | O  |     |
|    8 | Ta       |    | Kata   |    |     |
|    7 | Dhet     |    | Tita   |    |     |
|    6 | SNa      |    | GheGhe |    |     |
|    5 | Taga     | 2  | Dha    | 2  |     |
|    4 | Dhet     |    | Gena   |    |     |
|    3 | Traka    |    | Gadi   |    |     |
|    2 | Dhet     |    | Kata   |    |     |
|    1 | Dhet     | X  | Tita   | X  | Dha |

## NOTATION FORMS FOR CHAPTER 4 - COMPOSITION IN TEENTAAL

## 1 st Tukda in Teentaal - Drut Laya

In this image, we can see a chart.

<!-- image -->

In this image, we can see a chart.

<!-- image -->

## NOTATION FORMS FOR CHAPTER 4 - COMPOSITION IN TEENTAAL

## Gat Bhava in Teentaal - Drut Laya

In this image, we can see some text.

<!-- image -->

| 3   | DhaKa DhinNa DhinNa Kat 3   | Aa Thai Thai Tat   | Aa Thai S Tat   | Thai Tat DigDig   |
|-----|-----------------------------|--------------------|-----------------|-------------------|
|     |                             |                    |                 | TigDha            |
|     |                             |                    |                 | Thai ThaiS        |
|     |                             | 3                  | 3               | Aa 3 DigDig 3     |
|     | Kat                         | Tat                | Tat             | Tat TigDha        |
|     | DhinNa                      | Thai               | S Thai          | ThaiS             |
|     | DhinNa                      | Thai               | Thai Thai       | DigDig            |
| O   | DhaKa 0                     | Ta 0               | Ta 0 Ta 0       | TigDha 0          |
|     | Kat                         | Tat                | Tat             | Tat DigDig        |
|     | DhinNa                      | Thai               | S Thai          | DigDig            |
|     | DhinNa                      | Thai               | Thai Thai       | DigDig            |
| 2   | DhaKa 2                     | Aa 2               | Aa 2 Aa         | 2 DigDig 2        |
|     | Kat                         | Tat                | Tat Tat         | DigDig            |
|     | DhinNa                      | Thai               | S Thai          | DigDig            |
|     | DhinNa                      | Thai               | Thai Thai       | DigDig            |
| X   | DhaKa X                     | Ta X               | Ta X Ta         | X DigDig X        |

<!-- image -->

- All compositions in the three prescribed laya -s must in notated in teentaal.
- Compositions that must be performed are chakkars, Thaat, Paran, Tihai, Tukda, Toda, Kavitt toda, Gat Bhava
- Padhant with correct pronunciation must be emphasised.

<!-- image -->

Compositions, Teentaal,  Vilambit laya, Madhya laya, Drut ,  Notation forms, padhant, Chakkar, Thaat, Paran, Tihai, Tukda, Toda, Kavitt toda, Gat Bhava.

## NOTES

In this image we can see a poster with some text and a picture of a woman.

<!-- image -->

## CHAPTER Il

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- . Describe the origin of kathak in temples
- . Recognise the role of kathakaar in the evolution of Kathak
- . Describe the influence of the different rulers across the different periods of  time in the history of Kathak
- . Describe the decline and revival periods of Kathak .
- . Pioneer - Madame Menaka

## 11.0 Origin of kathak in Temples

Kathak is  the  classical  dance  style  of  North  India.  It  has  a  distinctive  place among the major forms of the traditional classical dances of India. It originated in the temples, in the States of Rajasthan and Uttar Pradesh.

'Katha kahe so kathak …..',  the  one  who  tells  a  story  is  a  kathak.  The  term  kathak is derived from the Sanskrit word ' katha ' meaning story, and a ' kathakar' or 'gathakar ' is the one who tells a story. In ancient times, communities of dancers and musicians known as kathakar-s used to relate mythological stories from the Puranas , Ramayana and Mahabharata . These kathakar-s were appointed in  temples  to  communicate  stories  mainly  through  rhythmic  footwork,  hand gestures, facial expressions and dance movements.

## 11.1 Temple Period

The art of story-telling has existed since  ancient  times.  The  term Kathakar-s as  storytellers  appears in many ancient Hindu texts and epics.  The  most  famous  one  is the Sanskrit text ' Ramayana ' written by the great Sage Valmiki.

In this image we can see a group of people sitting on the ground.

<!-- image -->

He taught its musical narration to the sons of Lord Rama, Luva and Kush who were the first ones to tell this story in the court of King Rama. Thereafter, this tradition of relating stories continued throughout North India and years after many other mythological stories came into existence. The term kathak has thus been associated with the art of storytelling.

## 11.2.1 Medieval Period (8 th to 18 th century)

Vaishnavism implies  the  worship  of  Lord  Vishnu  as  the  Preserver  of  the Universe. Lord Vishnu incarnated numerous times in different forms to restore balance on Earth. His incarnation as Lord Krishna was adored during this period which was known as the Bhakti Period. This period was essentially connected to music and dance which was centred around Lord Krishna dancing with his beloved Radha and the gopis (milkmaids). Lord Krishna was the main subject of the many compositions of music and dancing in temples and other gathering places.

In this image we can see a group of people standing and dancing.

<!-- image -->

During the early Medieval years, Vaishnavism had an important influence upon the growth of kathak. The themes, episodes and legends about Krishna's life became a permanent part not only in the kathak repertoire but also in poetry and music. Many nritta bol-s were found in the poetry of famous poet-musicians like Jayadeva, Tulsidas, Mira and Surdas at the end of the medieval eras. This clearly indicates that dance was an essential aspect in their hymns.

By the end of the 8 th  Century, under the Mughal Empire, kathak dance as a divine art was strongly condemned and was seriously affected. The Muslim rulers refused the patronage of this dance connected to religion.

Subsequently, the Muslim Kings brought in musicians and dancers from Persia and Central Asia. These dancers had their own individual style of dancing.

In this image we can see a group of people standing and holding guns.

<!-- image -->

In this image we can see a group of people are standing on the ground. In the background there is a building.

<!-- image -->

The Mughal courts  accepted  kathak  dance  as  a  form  of  aristocratic  entertainment. Kathak dance was no longer a means of communication of spiritual or religious ideas. Consequently, some kathakar-s went in search of Hindu patrons such as the Rajput in central India while others dispersed into the countryside where they could safely continue to perform their traditional style of dance.

In this image we can see a group of people dancing.

<!-- image -->

With  the  passage  of  time, Sufism and Hinduism as new forms of religious movements paved their ways in India.  Hence, Hindu arts including kathak dance were encouraged and nurtured.

These new forms of movements gave birth to bhakti -inspired poetry (devotionalinspired  poetry)  which  formed  the nritya part  of  kathak  dance  in  the  Hindu Courts. Krishna as a dancing God was very popular in the Bhakti movement and reflects to our modern day Kathak in compositions such as Bhajan-s , Kirtan-s , thumris, kavitt-s and gat-s . The name Natwar ,  literally meaning Krishna as the perfect dancer. Many compositions included bol-s that  were originated from His dance known as Natwari bol-s. The dancers who found their ways in the Muslim courts adopted the styles of the Persian dancers especially to please their patrons and earn a living. Similarly, new musical instruments and major changes in costumes modelled as the Persian styles were preferred and also adopted by the kathakar-s .

During the Mughal period, Kathak entered its golden era when the King Akbar the Great married a Hindu princess.  Hindu  dancers and musicians started performing  in  the  Royal presence and soon came under the Emperor's patronage.

In this image we can see a group of people dancing. In the background there are buildings.

<!-- image -->

Kathak was therefore greatly appreciated and applauded.  The kathakar-s were given pensions and gifts. The themes of the dances in the Muslim Courts were mostly imperial, social and contemporary ones. The dancers also brought major variations of rhythms especially in foot works and pirouettes and thus kathak furthermore developed into a sophisticated and stylised form of entertainment with  the  emphasis  entirely  on  the  solo  performance.  There  was  the  rise  of British Rule and the decline of Mughal Empire in the end of the 18th Century. Kathak dance gradually became less popular in the Royal Courts. The colonial officials observed a mixture of the ancient Indian tradition and Central AsianPersian form of dance. This form of entertainment was not appreciated by the petty kings and nobles.

The social dishonour attached to the courtesans  and  dancing  girls  gave rise to a widespread partiality against dancing women. Dancing girls became less respected in the society and they became  known  as the 'natchwalis' or ' nautch ' girls. Officials

In this image we can see four women standing and wearing different color dresses.

<!-- image -->

and newspapers not only degraded the kathak dancers but also pressurized that their sources of patronage be stopped.

In 1892, Christian missionaries launched the 'anti-dance Movement' and furthermore, many film makers used kathak dance mostly as  the  performance  of 'tawaifs '(prostitutes).  This  resulted  in  the disgrace  of  the  dance  style.  Girls from  respectable  families  gave  up dancing  as  a  career.  In  order  to

In this image we can see a group of people. Among them, we can see a woman standing and holding a guitar.

<!-- image -->

preserve the dance tradition, kathak Gurus started training boys of their families. The aristocratic Hindu girls were instructed in the kathak art form since they had to be skilled in traditional arts.

## 11.4  Revival Period

The Movement for India to become independent was marked by an effort of the revolutionists to rescue the Indian culture. This Movement included the revival  of kathak art form.

Leila  Sokhey  was  the  first  dancer  who  broke  the restrictions. She was trained under the best Gurus and revived kathak as an art acceptable in the society.

<!-- image -->

With the downfall of the Mughals in the 18th century, many artists shifted  from Delhi to Lucknow. The Ruling King was Wajid Ali shah, the last Nawab (King) of Oudh, now Ayodhya. The arts such as, literature, music, dance and poetry flourished in an atmosphere of communal harmony.

In the 19th century kathak dance was developed and preserved in a distinct Gharana (School) which came to be known as the Lucknow Gharana. All the great artists were welcomed in Oudh. They were given pensions and grants. Thus a new Centre of art evolved in Lucknow.

Wajid Ali Shah was a poet, musician and a great dancer. Under the guidance of his Guru, Pandit Durga Prasad, he embellished the nritya aspect of kathak dance, that is, the exhibition of bhava-s or expressions. Durga Prasad's two sons Binda Din  and  Kalka  Prasad  succeeded  him.  The repertoire  of  kathak  dance  was  enhanced  by both technical precision and lyrical compositions such as Ghazals and Thumris . Wajid Ali Shah's palace always echoed with the sound of music and dancing.

The kathak dancers in the Rajput Courts developed their style of dance with  more complex

In this image we can see a person wearing a crown and a crown is smiling.

<!-- image -->

and intricate techniques thus giving more emphasis to the nritta aspect. Kathak developed in a new shape and flourished in Rajasthan with a strong religious fervour. The founders were Bhanuji and his brothers Hari Prasad and Hanuman Prasad.This unique style was preserved under the Gharana which came to be known as the Jaipur Gharana and later spread in Lahore also.

The last patron of kathak was Raja Chakkradar Singh of Raigarh. He was a dancer and a musician too. He welcomed kathak regardless of its Gharana . He encouraged and nurtured young talents in his courts. Jay Lal of Jaipur and Achhan Maharaj, the eldest son of Kalka Prasad of Lucknow Gharana , served him for many years.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The other kathak-s who maintained their traditional style came to be known as the Benaras Gharana . Kathak regained its popularity through the many Gurus who sustained and imparted the traditions of their Gharanas in the family. The present Guru of Lucknow Gharana is Birju Maharaj, son of Acchan Maharaj.

The Jaipur , Lucknow and Benaras Gharanas have been sustained and nurtured innovatively. Till now the Gurus' legacy been maintained by their family members and disciples in many Universities in India and countries around the world.

<!-- image -->

The three main Gharanas or  Schools of kathak dance are the Jaipur, Lucknow and Benares Gharanas . These schools are named according to the geographical area in  which  they  were  preserved  and  developed.  Each gharana is  slightly  different  in  interpretation  and  its repertoire through which each can be recognised.

## 11.4.1 Pioneer Madame Menaka

Leila Sokhey adopted the name 'Madame Meneka' at the start of her dance career. She first learnt kathak dance in Bombay from Pandit Sitaram Prasad for several years. Thereafter, she got more training from Lacchu Maharaj and Pandit Ramdutt Mishra.

Madame Meneka staged her first dance-drama 'Krishna- Leela'  in  1934  in Bombay and since then she produced many beautiful and innovative dancedramas.  She considered dance not only as a form of entertainment or means of  expressions  but  also  as  an  uplifting  spiritual  activity.She  also  produced dance-dramas on mythological themes and, at that time, these dance-dramas also helped to restructure the culture of India. She brought a new attraction in kathak dance techniques and costumes.

Her  dance  troupe  travelled  to  Europe  and South East Asia.

In  1941,  she  inaugurated  the  first  dance  school 'Nrityalayam' in Khandala, Mahastrashra State, in which many girls and married women started training in kathak. Thus as a pioneer, she revived kathak dance in India and around the world.

In this image we can see a woman wearing a saree and holding a book in her hand.

<!-- image -->

<!-- image -->

- Kathak comes from the word katha and originated in temples.
- Kathakar-s used to narrate stories from epics
- such as Ramayan, Mahabharata and the Purana-s.
- The themes, episodes and legends about Krishna's life became a permanent part in kathak, poetry and music.
- Musicians and dancers were brought from Persia and Central Asia at the end of 8th Century.
- Hindu arts were again encouraged and nurtured when new forms of  the movements such as Sufism and Hinduism took place.
- Some kathaks went to the Courts of Hindu emperors of Rajasthan while others to Muslim Courts.
- Kathak dancers  came under the Emperor's patronage.
- The themes of the kathak dances in the Muslim Courts included imperial, social and contemporary issues.
- The dancers brought major variations of rhythms especially in foot works and pirouettes.
- By the end of the 18th Century, with the rise of the British rule, kathak gradually became less popular in the Royal Courts.

<!-- image -->

- Meneka was trained under the best Gurus and she revived kathak as an entertainment acceptable in the society.
- In the 19 th century, during the reign of the last 'Nawab' of Oudh, Wajid Ali Shah, kathak dance was developed and   preserved   in a distinct Gharana known as the Lucknow Gharana.
- Kathak dancers in Rajput Courts developed their style of dance with  more complex and intricate techniques giving more emphasis on the nritta aspect preserved under the Jaipur Gharana .
- The other kathak-s who maintained their traditional style came to be known as the Benaras Gharana .

<!-- image -->

Key words

- Story-telling,  facial  expression,  hand  gestures, Musical  narration,  Medieval, Vaishnavism ,  Incarnation, Theme, Poet-musicians, Patronage, Mughal Empire, Condemned, Sufism , Hinduism, Bhakti movement

<!-- image -->

Project work With the help of your teacher, form groups or pairs.

For this project you will need materials such as  Bristol  papers,  marker,  print  outs  and photocopies.

Prepare  a  project  on  the  contributions  of Madame Menaka to kathak dance.

## Assessment

| Exercise 1                                                   | Exercise 1                                                                            |
|--------------------------------------------------------------|---------------------------------------------------------------------------------------|
| State whether the followings statements are TRUE or FALSE.   | State whether the followings statements are TRUE or FALSE.                            |
| a)                                                           | The word katha is a hindi word. ……………..                                               |
| b)                                                           | The one who tells a story is a kathaka .…………….                                        |
| c)                                                           | Kathakar-s used to communicate stories through music.……………                            |
| d)                                                           | Kathak originated in temples and Royal courts. …………….                                 |
| e)                                                           | Kathak istheclassicaldanceofRajasthanandUttarPradesh.………….                            |
| Exercise 2                                                   | Exercise 2                                                                            |
| Fill in the blanks with the words from the list given below. | Fill in the blanks with the words from the list given below.                          |
|                                                              | Repertoire Muslim Ramayan Theme                                                       |
| a)                                                           | The history of kathak is dated back to ………….. times.                                  |
| b)                                                           | Luva and Kusha related the musical narration of the ……………..                           |
| c)                                                           | Lord Krishna became the main ……….. of music and dancing in the early medieval period. |
| d)                                                           | Kathak was strongly condemned by the…………. rulers.                                     |
| e)                                                           | Kathak used poetry for the ……….. parts of dance.                                      |
| f)                                                           | Musicians and dancers from ……………were brought to India.                                |
| g)                                                           | Kathak became a form of …………………inthe Royal Courts.                                    |
| h)                                                           | The …………….. of kathak was limited to imperial, social and contemporary themes.        |

## Assessment

Exercise 3

Describe the history of kathak dance during the early Medieval period.

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

…………………………………………………………………………................

.....................................................................................................................

Exercise 4

Explain	how	the	Muslim	rulers	have	influenced	the kathak style  of dance.

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

…………………………………………………………………………................

.....................................................................................................................

Exercise 5

Write in a paragraph about how kathak dance has been preserved after the Mughals in India.

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

…………………………………………………………………………................

.....................................................................................................................

In this image we can see a poster with some text and images.

<!-- image -->

## AT THE END OF THIS CHAPTER, LEARNERS SHOULD BE ABLE TO:

- Demonstrate the basic skills of communication through the medium of Kathak movements
- Communicate through the medium of Kathak movements
- Enact an idea or a small story in sequences of movements, gestures and expressions in small groups
- Develop an appreciation for non - discursive communication
- Respond by reflecting on one's performance as well as that of peers.

## 12.0	Creative	Exercise

Indian classical dances integrate music, story, movements, costumes, makeup,  expressions,  symbolic  gestures  and  sometimes  stage  decors  to  create and represent a proper dramatic sequence of pure and expressional dance performance.

The Natya Shastra includes chapters that deal with the aesthetic and theoretical principles of Indian classical dances. It is an ancient Sanskrit text on performing arts, such as theatre, music and dance. There are specific dance chapters that define the movements of different parts of the body and numerous mudras or hand gestures with their meanings together with detailed clarifications of rasa or sentiments.

The language of gestures in kathak traces its origin in the Natya Shastra . Thus, kathak dance is an artistic and harmonious presentation of a unique non-verbal pattern.

In this image we can see a group of women dancing on the stage.

<!-- image -->

<!-- image -->

## The Natya Shastra mentions:

' Where the hands go, the eyes follow; where the eyes go, the mind follows '. Where the mind goes, there is created an aesthetic expression of bhava or emotion and where there is Bhava , the essence of the rasa or mood is evoked in both the performer and the audience.

Kathak  dance  involves  gestures,  movements,  expressions  and  poses  that transmit messages of a story. The hands convey symbols and together with emotions and dance movements, certain messages are therefore effectively and non-verbally transmitted. These are synchronized with taal and laya or melodic rhythm to create a highly expressive and intensive emotional performance.

## Note to Teachers

Recall  certain  chapters  dealing  with  the  communicative  aspects  of dance such as hand gestures, terminologies of dance, invocation and compositions like namaskar tukra, gat, kavitt, thumri and so on.

## 12.1	Basic	non-discursive	communication

All the Kathak compositions that you have practised, till now comprise various techniques of non-verbal communication. A kathak dancer uses the body and gestures as a medium to reproduce episodes, songs or poems of famous and sacred texts with great precision.

The communicative aspects in kathak are a combination of nritta, nritya and natya combined with abhinaya together with grace, gati or gait. Thus, the whole variety  of  non-verbal  techniques  used  by  the  dancer  create  the  interaction between the audience and performers.

Hands are the most expressive and communicative part of the body. These are always kept visible. The feet and their orientations as well as the intricate foot works are part of gestures and also communicate way space is used.

Kathak dance postures give us information about the status and character that the artist wants to portray. In addition, the choreographies of the characters with specific emotions communicate a manifestations of moods such as love, bravery, anger, fear, disgust, wonder, compassion and peace. These moods and emotions are described as the sattvika abhinaya in classical dance, more specifically referred to as the nine rasa-s . These are:

- -Love or happiness as Shringaar rasa
- -Laughter as Hasya rasa
- -Compassion as Karuna rasa
- -Wonder or amazememt as Adbhuta rasa
- -Disgust as Bibhatsa rasa
- -Bravery as Veera rasa
- -Anger as Raudra rasa
- -Fear as Bhayanak rasa
- -Peaceful as Shanta rasa .

The pictures below demonstrate the nine rasas as depicted in classical dances.

In this image we can see a collage of images.

<!-- image -->

<!-- image -->

<!-- image -->

## Imagination	and	creativity

With the help of your teacher, form groups or pairs. This activity is a demonstration of 3 to 4 minutes.

## Choose an animal/insect/bird.

- Use the appropriate hasta, either asamyuta or samyuta hasta to reproduce  its form.
- Imitate its behaviour or walk using body movements, dance steps, or poses.
- Use the space around you to produce a small story that involves the animal/ insect/bird. You should use the story combined with kathak dance  techniques, specific hand gestures, gaits and facial expressions, in taal and laya .

## Note to Students

## Keep the track of:

- representations coincide with the chosen animal and kathak dance
- ability to execute movements and interaction with the group
- emotions in dance.

## Idea

Students can use music with sounds of animals and nature to enhance their performance.

<!-- image -->

## Dancing	my	emotions

This  activity  in  an  individual  demonstration.  Reflect and practise how you would portray emotions such as happiness,  fear,  jealousy,  anger,  compassion,  peace, disgust, love and wonder.

Identify	any	two	emotions	and	use	them	to	create	a	small story that includes:

- kathak dance techniques (footworks, chakkars, basic movements)
- hastas (single and double)
- facial expressions
- costumes and make-up.

## Notes to students

## Keep the track of:

- Taal and laya
- Use of space
- Imitation and involvement
- choreography
- Creativity.

<!-- image -->

<!-- image -->

## Creativity	and	Choreography

This activity is a group performance. Students will need to work in groups to choreograph a performance not be more than 5 minutes.

The kathak dance performance should depict a story or song involving the techniques learnt so far. You should use tatkaar, chakkar , basic movements, hand gestures, facial expressions, costumes and make-up. Students may use classical and bollywood songs or music.

## Note to Students

Keep the track of: Team work Use of appropriate music Taal and laya Use of elements of dance Choreography Involvement of all students

## NOTES

In this image we can see two women standing and dancing.

<!-- image -->

## CHAPTER 13

<!-- image -->

<!-- image -->

In this image we can see a collage of different objects.

<!-- image -->

<!-- image -->

<!-- image -->

## Chapter 2 -Indian Classical dances in Mauritius:

- -https://www.youtube.com/watch?v=QESPcM1gjx4
- https://www.youtube.com/watch?v=qtKMh2dypQ0

## Chapter 3 -Tatkaar and Chakkar:

- -https://www.youtube.com/watch?v=BQDEuf15tjM
- https://www.youtube.com/watch?v=ai1HCYFBmww
- https://www.youtube.com/watch?v=NRxzoxLyzPQ

## Chapter 4 -Compositions Teentaal:

- Thaat -https://www.youtube.com/watch?v=dRuLSaFanpw Gat Bhava -https://www.youtube.com/watch?v=wL0tWMIU5no (Govardhan leela)
- -https://www.youtube.com/watch?v=XJ4Rh76Thsc (Makhan chor)
- -https://www.youtube.com/watch?v=akRLungVJU0 (Ruksar Gat)
- https://www.youtube.com/watch?v=Sj0cTZ\_MC0E
- https://www.youtube.com/watch?v=2ox1H7cuuMU
- https://www.youtube.com/channel/UCT0EeR8SMCItnnOg mLfEjoQ

## Chapter 6 -Indian Classical Dances:

- -https://www.youtube.com/watch?v=\_LVXqdd-SdM
- https://www.youtube.com/watch?v=w0gamtoWxnE

## Chapter 7 -Costume and Makeup of Kathak

- -https://www.youtube.com/watch?v=kOKbD8WWz-A
- https://www.youtube.com/watch?v=L\_uDzuBWzHk

<!-- image -->

## Ghungroo:

-https://www.youtube.com/watch?v=9hwKat-wnF8

Chapter 8 -Expressive dance composition Kahe Rokata:

- -https://www.youtube.com/watch?v=H7m-sG5w2RU

## Chapter 11 -Historical development of Kathak

- -https://www.youtube.com/watch?v=XZIyOAHwD00
- https://www.youtube.com/watch?v=dtrCIU5Sl3Q
- https://www.youtube.com/watch?v=QAEqiWgUl7c

## Glossary of terms

Abhinaya

Expression

Adbhuta

Wonder

Aharya

Accessories such as costumes, jewellery, stage set, etc

Amad

Introductory patterns based on dance mnemonics in

kathak

Anga

Body

Angarkha

Knee or calf length frock like tunic worn over tight pants

Avartan

A cycle of a taal

Bant

Chain of footwork

Bandi

A small waistcoat

Bansuri

Indian flute

Bedam

No pause

Bhajan

Devotional song used for dance portrayal

Bharata

Author of Natya Shastra

Bhava

Mood, state of emotion

Bhibatsa

Repugnant

Bhramari

Pirouette, spins

Bol

Syllable or phrase of rhythmic mnemonics

Chakkar

Pirouette, spin

Chakkradaar

Chalan

Gliding way of moving

Chapka

A fan-shaped piece of jewellery worn on the side of the head

Choli

A bodice

Churidar pyjama or

Tight fitting trousers with gathers at the ankles

Churidar

Damdaar

One pause

Dhyan

Meditation

Drut laya

Fast tempo

Gat bhava

Portrayal  of  a  story  in  kathak  using  the  full  gamut  of body  positions,hand gestures and expressions

Gat nikas

Gaits in kathak

Gati

Gait

Gharana

School

Ghazal

Form of Urdu poetry that is sung

Ghunghroo

Ankle bells

Guru

Teacher

Guru-shishya parampara

A succession of teachers and disciples in traditional Vedic culture and religions

Hasta

Hand gesture

Hasya

Humorous

Karuna

Compassion

Katha

Story

Kathak

Classical dance style of northern and central India

Kathakar

Story teller

Kavitt

Portrayal to recitation of poetic text

Khali

Empty beat of a taal

Kirtana

Devotional song

Ladi

Chain of footwork

Lasya

Graceful, delicate

Laya

Speed, tempo

Lehenga

Ankle length skirt with gathers

Madhaya laya

Medium tempo

Matra

Unit of beat

Mudra

Hand gesture that conveys a meaning

Mukhra

Chorus of a song repeated at the end

Namaskaar

Greeting

Natya

Drama

Natyashastra

Sanskrit text on dance and drama

Nritta

Pure dance, rhythmic movements

Nritta hasta

Ornamental hand gesture

Nritya

Dance with mime and expression

Orhni

Veil

Padhant

Recitation of rhythmic syllables of dance in Indian

music and dance

Pakhawaj

Long barrel shaped horizonal drum used in kathak Rhythmic pattern in kathak based on syllables of pakhawaj

Paran

Pratyanga

Upper part of the body

Rasa

Sentiments

Rasa leela

Dance of Lord Krishna with the milkmaids

Raudra

Anger, fury

Salaami

Greeting

Sam

First beat of a cycle

Shloka

Sanskrit verse

Stotram

Hymn of praise

Tabla

Pair of drums used in Hindustani music

Taal

Time measure

Tali

Clap

Tandava

Forceful, vigorous

Tatkaar

Footworks in kathak

Thaat

The initial rhythmic piece in kathak where elements of

body position are introduced

Tihai or tihayi

An activity that is repeated thrice

Toda

Rhythmic pattern in kathak based on tabla and dance mnemonics

Tukra

Rhythmic pattern in kathak  based on tabla and dance mnemonics

Upanga

Lower part of the body

Vandana

Prayer / workship

Vachika

Speech

Vaishnavism

Branch of Hinduism in which Vishnu or one of his incarnations (usually Krishna or Rama) is worshipped as the supreme God

Vilambit laya

Slow speed or slow tempo

Ni

Music &amp; Dance critic/ Journalist

Accompanist

Artistic Director

Cultural Officer

Musicologist

P

Composer/ Arranger

Music &amp; Dance Therapist

Lighting Designer

Performer/ Dancer

Music Librarian

Performing Artist

#

Music and dance scholar

Researcher

Stage Manager ga

Teacher/ Educator

Dha

Talent Manager

Business Agent

Pa"

Impressario

JGa

Marketing officer

Music Composer

Event Manager

Producer

Ma

Vi

Cultural Entrepreneur

Music Directors

Choreographers

ISBN 978-99949-54-32-2

Oha