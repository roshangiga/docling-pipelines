In this image we can see a poster with some text and images.

<!-- image -->

<!-- image -->

## Francaise LittÉRATURE

In this image we can see a book, a pen and a bookmark.

<!-- image -->

GRADE 9

<!-- image -->

## Professor Vassen Naëck

- -Head Curriculum Implementation,Textbook Development and Evaluation

## FRENCH LITERATURE PANEL

Dr Vèle Putchay

- Panel Coordinator, Associate Professor, MIE

Dr Wesley Marie

- Panel member, Lecturer, MIE

Mr Rajen Manick

- Panel member, Educator

Mrs Mila Devi Sewruttun-Dosieah

- Panel member, Educator

Ms Farzeenah B Emamally

- Panel member, Educator

Mr Jean Claude Coret

- Panel member, Resource Person

<!-- image -->

Design

Wendy Siew

- Graphic Designer

© Mauritius Institute of Education (2021)

ISBN : 978-99949-53-81-3

Acknowledgements

The French panel wishes to acknowledge the contribution of :

Mrs Marie-Claude Putchay for proof reading.

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies of learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The  development  of  textbooks  has  been  a  very  challenging  exercise  for  the  writers  and  the  MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and Evaluation provided guidance with respect to the objectives of the NCF, while ascertaining that the instructional designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic designers who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## Avant-propos

Ce manuel de Littérature française Grade 9 s'inscrit  dans  une  continuité  pédagogique  avec  ces  deux prédécesseurs. Tandis que celui de Grade 7 a permis à l'apprenant de renouer avec le plaisir d'une histoire racontée tout en découvrant une variété de textes littéraires ainsi que le goût de la lecture à travers une initiation à la littérature, celui de Grade 8 l'a amené, à travers une analyse élémentaire, à prendre connaissance des différentes spécificités de ces textes selon leur appartenance générique : romanesque, théâtre ou poésie.

Le manuel de Grade 9 propose une méthodologie pour une entrée dans le texte littéraire de manière plus approfondie à travers une analyse plus structurée. Deux principaux genres littéraires, à savoir le romanesque et le théâtre, sont traités dans ce manuel. Le premier, Le papa de Simon , une nouvelle de Maupassant, est un texte intégral partiellement et légèrement adapté. Le deuxième comprend un choix de scènes ou des extraits des scènes de l'acte premier de l'œuvre théâtrale de Marcel Pagnol, Topaze , le tout adapté aux besoins de l'apprenant de Grade 9.

Le choix de textes répond à une exigence bien pédagogique qui consiste à offrir à l'apprenant des outils appropriés pour lire, analyser et interpréter une œuvre littéraire et, par la même occasion, à le familiariser avec les auteurs et leurs œuvres qui reviennent souvent aux programmes de fin d'études du secondaire afin que cet univers littéraire ne lui soit pas complètement étranger. Comme signalé dans l'avant-propos de Grade 8, nous sommes ainsi contraints d'orienter notre choix de textes selon le corpus littéraire des programmes d'étude de « School Certificate » et de « Higher School Certificate ». Ce choix va donc dans l'intérêt de l'apprenant à long terme.

La même méthodologie de lecture que celle proposée en Grade 7 et Grade 8 est proposée ici. Chaque texte est présenté en différentes séquences selon un découpage mûrement réfléchi qui provoque chez le lecteur une curiosité pour la suite de l'histoire et qui suscite de ce fait un intérêt pour la lecture - ce qui indique la continuité du travail amorcé par l'initiation à la littérature en Grade 7. Chaque séquence est suivie d'une série de questions ciblées qui vérifient l'attention prêtée au texte durant la phase de lecture et qui réinvite à un retour au texte par une réorientation de lecture si besoin est.

Les questions sont catégorisées selon qu'elles proposent une étude sur l'action ou la trame de l'histoire, sur un thème ou sur un personnage - les trois rubriques qui forment l'objet d'étude pour l'apprenant de  Grade  9.  Elles  sont  organisées  de  telle  sorte  qu'elles  poussent  l'apprenant  à  progressivement déconstruire  le  texte  afin  de  l'analyser  plus  en  profondeur.  Cette  progression  vers  la  connaissance pratique des textes littéraires prend en compte le besoin des répétitions et des retours en arrière pour fixer les connaissances acquises et pour éviter que certaines d'entre elles ne sombrent dans la zone d'oubli. Quand l'apprenant aura parcouru l'intégralité du manuel sous la supervision de l'enseignant ou l' enseignante, l'ensemble des activités proposées après chaque séquence l'aura conduit vers la maîtrise de textes littéraires proposés comme objet d'étude. Les questions qui sont d'ordre général à la fin du manuel et  qui  réclament  une  connaissance  globale  de  l'œuvre  ainsi  que  des  principaux  thèmes  et personnages deviendront abordables à bien des égards.

Il  importe, de ce fait, que l'enseignement du texte littéraire ne se confonde pas avec une activité de lecture - compréhension, comme c'est souvent le cas en classes de littérature. Il ne s'agit pas de lire un extrait  pour  répondre à des questions arbitrairement posées, comme si les bonnes réponses de l'apprenant lui donneraient raison, mais de procéder à une lecture qui dégage à l'aide des questions

soigneusement orchestrées les spécificités du texte littéraire afin que l'apprenant, après avoir relevé les invariants du texte littéraire qui se répètent d'une œuvre à l'autre, parvienne à toucher du doigt ce petit rien (résidu lansonien) qui fait du texte un texte dit littéraire et de l'auteur un génie.

Notre objectif consiste à poser les fondements pour un enseignement des textes littéraires qui viserait à redynamiser cette matière scolaire qu'est la littérature française hélas trop longtemps considérée par certains acteurs clés de notre système éducatif comme une simple activité de lecture - compréhension, voire  comme  «  une  manière  banale  d'entretenir  les  apprenants  en  leur  racontant  des  histoires  », ou pire encore, comme la dernière option restante quand les autres matières d'apparence plus distinguée n'offrent plus de possibilité. Nous avons donc pensé tirer bénéfice à long terme d'une réforme qui se veut positive et prometteuse.

Nous espérons que le contenu ainsi que la méthodologie proposés dans ce manuel apporteront leur lot de satisfaction à l'ensemble des utilisateurs.

Dr Vèle Putchay

Coordinateur du panel de français, Professeur Associé, MIE.

In this image we can see a book, a pen, a sword, a paper, a paper clip, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a

<!-- image -->

## TABLE DES MATIÈRES

In this image we can see a book, a feather, a chain, a locket, a pen and a paper.

<!-- image -->

In this image there is a wooden plank on the right side of the image.

<!-- image -->

In this image we can see a girl standing and holding a pen. In the background there is a book.

<!-- image -->

In this image we can see a book with some text on it.

<!-- image -->

## Guy de Maupassant Le papa de Simon (1879)

Texte intégral adapté partiellement

<!-- image -->

## I. Comprendre la nouvelle

La  nouvelle  relève  du  genre  littéraire 'le  romanesque',  tout  comme  la  comédie  relève  du genre  littéraire  'le  théâtre' .  On  peut  dire  que  le  romanesque  est  un  genre  littéraire  et  la nouvelle un sous-genre.

La  nouvelle,  de  par  sa  forme,  est  plus  longue  qu'un  conte  mais  plus  courte  qu'un  roman. Elle se trouve donc entre le conte et le roman.

Par définition, la nouvelle est un récit bref qui présente une intrigue simple. Elle contient peu de personnages, commence par une situation de départ (situation initiale) et se termine par une situation finale. Le lecteur suit un seul personnage principal. L'histoire est généralement construite  autour  d'un  seul  thème  dominant  et  le  narrateur  raconte  l'essentiel  de  l'histoire. Une nouvelle peut être policière ou de science-fiction ; elle peut être réaliste comme « le papa de Simon » ou fantastique comme « le Horla » de Maupassant.

## II.  Présentation de Guy de Maupassant

The image consists of two parts. On the left side, there is a person's face. The face is in a profile view, and it is looking straight ahead. The person has a mustache and a beard. The background is blurred, and it looks like a wall or a wooden surface. On the right side, there is a part of a piece of wood. The wood has a light and dark color, and it has a rough texture. The image is in a collage format, with the two parts of the image overlapping each other.

<!-- image -->

Guy de Maupassant est un écrivain français né le 5 août 1850 à Fécamp. Sa mère l'a élevé seule après le départ de son mari. C'est une femme dépressive qui tente même de se suicider. Maupassant aura une enfance difficile.

Gustave  Flaubert,  ami  de  sa  mère,  soutient  Guy  dans  son  aspiration  à  devenir  écrivain. Maupassant connaît son premier succès littéraire avec sa nouvelle « Boule-de-suif », publiée en 1880. Il sera l'auteur de trois cents contes, cinq romans et une variété de nouvelles. Parmi ses romans les plus connus, on retient Une vie (1883) et Bel-Ami (1885), et parmi ses contes les plus lus figurent « Les contes de la bécasse » (1883), « La Parure » (1884) et « Le Horla » (1887). Il a écrit toutes ses œuvres en dix ans seulement.

Vers la fin de sa vie, sa santé se détériora tellement qu'il n'arrivera plus à écrire. Il sombrera dans la folie et la dépression. Il sera même atteint d'une paralysie générale qui le fera souffrir atrocement. Il subira des fréquentes crises et des convulsions avant de mourir dans la maison de santé de Passy le 6 juillet 1893 à Paris.

In this image we can see a wooden wall. On the right side of the image we can see a text.

<!-- image -->

## III.  Présentation de « Le papa de Simon »

Simon est un élève de 7 ou 8 ans et qui va à l'école pour la première fois. Ses camarades vont se moquer de lui et le violenter parce qu'ils ont appris qu'il n'a pas de papa. Sa mère, dite la Blanchotte, a été abandonnée par le père de Simon. Triste, l'enfant Simon veut se noyer dans une rivière. Mais Philippe, un forgeron qui passait par là, l'attrape par la main et le ramène chez sa mère. Simon demande à Philippe d'être son père pour que ses camarades ne se moquent plus de lui. Mais les camarades continuent à se moquer de lui et le torturer. À la fin, Philippe épouse la Blanchotte et devient le papa de Simon. Plus personne ne se moquera de Simon à l' école.

In this image we can see a cartoon image of a girl. She is wearing a pink and red color dress and a white color cap. She is holding a white color object in her hand. She is smiling.

<!-- image -->

## IV. Étude de 'Le Papa de Simon'

## Guy de Maupassant Le papa de Simon

## Séquence 1

## Extrait

Midi finissait de sonner. La porte de l'école s'ouvrit, et les gamins se précipitèrent en se bousculant pour sortir plus vite. Mais au lieu de se disperser rapidement et de rentrer déjeuner, comme ils le faisaient chaque jour, ils s'arrêtèrent à quelques pas, se réunirent par groupes et se mirent à chuchoter.

Ce matin-là, Simon, le fils de la Blanchotte, était venu dans la classe pour la première fois.

Tous avaient entendu parler de la Blanchotte dans leurs familles.

Quant à Simon, ils ne le connaissaient pas, car il ne sortait jamais et il ne galopinait point avec eux dans les rues du village ou sur les bords de la rivière. Ils n'aimaient guère Simon. Ils étaient étonnés d'apprendre, par un gars de quatorze ou quinze ans qui paraissait en savoir beaucoup sur Simon, que ce dernier n'avait pas de papa. C'était avec une certaine joie qu'ils s'étaient répété l'un à l'autre cette parole :

- « Vous savez… Simon… eh bien, il n'a pas de papa. »

<!-- image -->

## A.  Étude de l'histoire

Dans un conte, un roman ou une nouvelle, le fil conducteur de l'histoire concerne l'ordre dans lequel les évènements sont racontés. C'est la trame de l'histoire.

Etudie la trame de l'histoire en répondant aux questions suivantes :

1. À quel moment, précisément, commence l'histoire racontée ?
2. Dans quel lieu se déroule cette histoire ?

3. a.  Qui sont les personnages qui commencent l'histoire ?
- b.  Par quelle action commence cette histoire ?
- c.  Que font ces personnages par la suite ?
4. Pourquoi les gamins n'aiment pas Simon ?
5. Qu'est-ce que les gamins apprennent sur Simon ?
6. À ton avis, quelle sera la suite de cette histoire ? Écris-la en tes propres mots.

## B.  Étude des personnages

1. Qui est le personnage principal dans cette histoire ? Quel est l'élément de l'histoire qui te l'indique ?
2. Quel est le lien entre Simon et la Blanchotte ?
3. Relève  les  informations  dans  cette  séquence  de  l'histoire  qui  te  permettent  de  décrire le personnage Simon. (Pour décrire un personnage, utilise les adjectifs, les adverbes, les verbes  d'état,  les  verbes  au  participe  passé  qui  ont  un  rapport  avec  le  personnage  en question.)

## C.  Étude des thèmes

[Pour ces deux exercices, il ne s'agira pas de trouver la bonne réponse, mais d'apprendre à raisonner et anticiper même à tort.]

1. Après  avoir  lu  cette  première  séquence,  identifie  l'information  qui,  d'après  toi,  sera  au centre de l'histoire. Tu peux l'exprimer en tes propres mots.
2. En t'appuyant sur cette séquence, imagine les thèmes qui seront possiblement développés dans les autres séquences de l'histoire.

## Séquence 2

## Extrait

Le fils de la Blanchotte parut à son tour sur le seuil de l'école.

Il avait sept ou huit ans. Il était un peu pâlot, très propre, avec l'air timide, presque gauche.

Ses camarades chuchotaient toujours en le regardant. Ils avaient les yeux malins et cruels des enfants qui méditent un mauvais coup. Ils l'entourèrent peu à peu et finirent par l'enfermer dans un cercle. Simon restait là, planté au milieu d'eux. Surpris et embarrassé, il ne comprenait pas ce qu'on allait lui faire. Mais le gars qui avait apporté la nouvelle, enorgueilli du succès déjà obtenu, lui demanda :

- Comment t'appelles-tu, toi ?

Il répondit : « Simon. »

- Simon quoi ? reprit l'autre.

L'enfant répéta tout confus : « Simon. »

Le gars lui cria : « On s'appelle Simon quelque chose… c'est pas un nom ça… Simon. »

Et lui, prêt à pleurer, répondit pour la troisième fois :

- Je m'appelle Simon.

Les galopins se mirent à rire. Le gars triomphant éleva la voix :

- « Vous voyez bien qu'il n'a pas de papa. »

Un grand silence se fit. Les enfants étaient stupéfaits par cette chose extraordinaire, impossible, monstrueuse - un garçon qui n'a pas de papa ; ils le regardaient comme un phénomène, un être hors de la nature. Quant à Simon, il s'était appuyé contre un arbre pour ne pas tomber ; et il restait comme atterré par un désastre irréparable. Il cherchait à s'expliquer. Mais il ne pouvait rien trouver pour leur répondre, et démentir cette chose affreuse qu'il n'avait pas de papa. Enfin, livide, il leur cria à tout hasard : « Si, j'en ai un. »

- Où est-il ? demanda le gars.

Simon se tut ; il ne savait pas. Les enfants riaient, très excités.

<!-- image -->

## A.  Étude de l'histoire

1. Par quelle action commence cette séquence ?
2. Que font les gamins en voyant arriver Simon sur le seuil de l'école ?
3. Pourquoi le gars qui a apporté la nouvelle, pose des questions à Simon ?
4. Qu'est-ce que les camarades de Simon ont appris sur lui ?
5. Après avoir appris la nouvelle sur Simon, que pensent les camarades à propos de ce dernier ?
6. Qu'affirme Simon pour tenter de démentir la nouvelle ?
7. Ecris en tes propres mots un résumé de l'histoire depuis le début de la séquence 1 jusqu'à la fin de la séquence 2.

## B.  Étude des personnages

1. Relève dans cette séquence de l'histoire les informations qui te permettent de décrire le personnage Simon.
2. Fais le même exercice pour décrire les camarades de Simon.

## C.  Étude de thème

Etudie le thème de la cruauté en relevant les mots et expressions qui l'expriment dans cette séquence.

## Séquence 3

## Extrait

Simon avisa tout à coup un petit voisin, le fils d'une veuve, qu'il avait toujours vu, comme luimême, tout seul avec sa mère.

- Et toi non plus, dit-il, tu n'as pas de papa.
- Si, répondit l'autre, j'en ai un.
- Où est-il ? riposta Simon.
- Il est mort, déclara l'enfant avec une fierté superbe, il est au cimetière, mon papa.

Les gamins murmuraient pour l'approuver, comme si le fait d'avoir son père mort au cimetière permettait à leur camarade d'écraser cet autre qui n'en avait point du tout.

Et ces polissons, dont les pères étaient, pour la plupart, méchants, ivrognes, voleurs et durs avec leurs femmes, se bousculaient en se serrant de plus en plus, comme si eux, les légitimes, eussent voulu étouffer celui qui était hors la loi. L'un d'eux qui se trouvait contre Simon, lui tira la langue d'un air narquois et lui cria :

- Pas de papa ! pas de papa !

Simon le saisit à deux mains aux cheveux et se mit à lui cribler les jambes de coups de pieds, pendant qu'il lui mordait la joue cruellement. Il se fit une bousculade énorme. Les deux combattants furent séparés, et Simon se trouva frappé, déchiré, meurtri, roulé par terre, au milieu du cercle des galopins qui applaudissaient. Comme il se relevait, en nettoyant machinalement avec sa main sa petite blouse toute sale de poussière, quelqu'un lui cria :

- Va le dire à ton papa.

Alors il sentit dans son cœur un grand écroulement. Les camarades de Simon étaient plus forts que lui. Ils l'avaient battu. Simon ne pouvait point leur répondre, car il sentait bien que c'était vrai qu'il n'avait pas de papa. Plein d'orgueil, il essaya pendant quelques secondes de lutter contre les larmes qui l'étranglaient. Il eut une suffocation, puis, sans cris, il se mit à pleurer par grands sanglots qui le secouaient précipitamment.

Alors une joie féroce éclata chez ses ennemis, et naturellement, ainsi que les sauvages dans leurs gaietés terribles, ils se prirent par la main et se mirent à danser en rond autour de lui, en répétant comme un refrain :

- « Pas de papa ! pas de papa ! »

Mais Simon tout à coup cessa de sangloter. Une rage l'affola. Il y avait des pierres sous ses pieds ; il les ramassa et, de toutes ses forces, les lança contre ses bourreaux. Deux ou trois furent atteints et se sauvèrent en criant ; et il avait l'air tellement formidable qu'une panique eut lieu parmi les autres. Lâches, comme l'est toujours la foule devant un homme exaspéré, ils se débandèrent et s'enfuirent.

<!-- image -->

## A.  Étude de l'histoire

1. a.  Qui est le voisin de Simon ?
- b.  Qu'est-ce qu'il y a de commun entre Simon et son voisin ?
- c.  Quelle explication donne le voisin concernant son père ?
4. 2.
- a.  De quelle manière l'un des gamins se moque-t-il de Simon ? b.  Comment réagit Simon face à cette moquerie ?
3. a.  À quel moment Simon ressent-il « un grand écroulement » dans son cœur ? b.  Pourquoi le ressent-il ?
4. a.  À quel moment les ennemis de Simon ressentent-ils une joie féroce ?
- b.  Pourquoi, à ton avis ?
- c.  Que font-ils alors ?
- d.  Comment réagit Simon face à leur comportement ?
5. Que font les gamins à la fin de cette séquence ? Pourquoi ?
6. Fais un résumé de cette séquence entre 20 et 50 mots.

## B.  Étude des personnages

1. Quels sont les mots qui décrivent les pères des autres camarades de Simon ?
2. Relève,  dans  cette  séquence,  les  mots  et  expressions  qui  te  permettent  de  décrire  le personnage de Simon.

## C.  Étude de thème

Étudie le thème du courage dans cette séquence en montrant comment Simon essaye par tous les moyens de se défendre contre ses bourreaux et de les attaquer ensuite.

## Séquence 4

## Extrait

Resté seul, Simon, le petit enfant sans père, se mit à courir vers les champs, car un souvenir lui était venu qui avait amené dans son esprit une grande résolution. Il voulait se noyer dans la rivière. Il se rappelait en effet que, huit jours auparavant, un pauvre diable qui mendiait sa vie s'était jeté dans l'eau parce qu'il n'avait plus d'argent. Simon était là lorsqu'on le repêchait ; et le triste bonhomme, qui  lui  semblait  ordinairement  lamentable,  malpropre  et  laid,  l'avait  alors  frappé  par  son  air tranquille, avec ses joues pâles, sa longue barbe mouillée et ses yeux ouverts, très calmes. On avait dit alentour : « Il est mort. » Quelqu'un avait ajouté : « Il est bien heureux maintenant. » Et Simon voulait aussi se noyer parce qu'il n'avait pas de père, comme ce misérable qui n'avait pas d'argent.

Il arriva tout près de l'eau et la regarda couler. Quelques poissons folâtraient, rapides, dans le courant clair, et, par moments, faisaient un petit bond et happaient des mouches voltigeant à la surface. Il cessa de pleurer pour les voir, car leur manège l'intéressait beaucoup. Mais, parfois, comme dans les accalmies d'une tempête passent tout à coup de grandes rafales de vent qui font craquer les arbres et se perdent à l'horizon, cette pensée lui revenait avec une douleur aiguë : « Je vais me noyer parce que je n'ai point de papa. » Il faisait très chaud, très bon. Le doux soleil chauffait l'herbe. L'eau brillait comme un miroir. Et Simon avait des minutes de béatitude, de cet alanguissement qui suit les larmes, où il lui venait de grandes envies de s'endormir là, sur l'herbe, dans la chaleur.

Une petite  grenouille  verte  sauta  sous  ses  pieds.  Il  essaya  de  la  prendre.  Elle  lui  échappa.  Il  la poursuivit et la manqua trois fois de suite. Enfin il la saisit par l'extrémité de ses pattes de derrière et  il  se  mit  à  rire  en  voyant  les  efforts  que  faisait  la  bête  pour  s'échapper.  Elle  se  ramassait  sur ses  grandes jambes, puis, d'une détente brusque, les allongeait subitement, raides comme deux barres ; tandis que, l'œil tout rond avec son cercle d'or, elle battait l'air de ses pattes de devant qui s'agitaient comme des mains. Cela lui rappela un joujou fait avec des planchettes de bois et de petits soldats piqués dessus. Alors, il pensa à sa maison, puis à sa mère, et, pris d'une grande tristesse, il  recommença à pleurer. Il avait des frissons dans ses membres ; il se mit à genoux et récita sa prière comme avant de s'endormir. Mais il ne put l'achever, car des sanglots lui revinrent si pressés, si tumultueux, qu'ils l'envahirent tout entier. Il ne pensait plus ; il ne voyait plus rien autour de lui et il n'était occupé qu'à pleurer.

<!-- image -->

## A.  Étude de l'histoire

1. a.  Que fait Simon au début de cette séquence ?
- b.    En  quelques  mots,  résume  la  décision  prise  par  Simon  (De  quelle  décision  s'agit-il  ? D'où lui vient l'idée de cette décision ? Pourquoi cette décision ?)
2. Dans le deuxième paragraphe de cette séquence, explique pourquoi :
- a.  Simon cessa de pleurer.
- b.  Il a de la béatitude à un moment.
3. Dans le troisième paragraphe, explique pourquoi :
- a.  Simon se met à rire.
- b.  Il se met à pleurer.
4. Ecris en tes propres mots un résumé de l'histoire depuis le début de la séquence 1 jusqu'à la fin de la séquence 4.

## B.  Étude des personnages

1. Hormis Simon, qui sont les autres personnages dans cette séquence ?
2. Relève les mots et expressions qui te permettent de décrire le personnage de Simon tel qu'il apparaît dans cette séquence.

## C.  Étude de thème

Étudie le thème de la tristesse dans cette séquence.

<!-- image -->

## Séquence 5

## Extrait

Soudain, une lourde main s'appuya sur son épaule et une grosse voix lui demanda :

- « Qu'est-ce qui te fait donc tant de chagrin, mon bonhomme ? »

Simon se retourna. Un grand ouvrier qui avait une barbe et des cheveux noirs tout frisés le regardait d'un air bon. Il répondit avec des larmes plein les yeux et plein la gorge :

- Ils m'ont battu… parce que… je… je… n'ai pas… de papa… pas de papa…
- Comment, dit l'homme en souriant, mais tout le monde en a un.

L'enfant reprit péniblement au milieu des spasmes de son chagrin : « Moi… moi… je n'en ai pas. »

Alors l'ouvrier devint grave ; il avait reconnu le fils de la Blanchotte, et, quoique nouveau dans le pays, il savait vaguement son histoire.

- Allons, dit-il, console-toi, mon garçon, et viens-t'en avec moi chez ta maman. On t'en donnera… un papa.

Ils se mirent en route, le grand tenant le petit par la main, et l'homme souriait de nouveau, car il n'était pas fâché de voir cette Blanchotte, qui était, contait-on, une des plus belles filles du pays ; et il se disait peut-être, au fond de sa pensée, qu'une jeunesse qui avait failli pouvait bien faillir encore. Ils arrivèrent devant une petite maison blanche, très propre.

- C'est là, dit l'enfant, et il cria : « Maman ! »

Une femme se montra, et l'ouvrier cessa brusquement de sourire, car il comprit tout de suite qu'on ne badinait plus avec cette grande fille pâle qui restait sévère sur sa porte, comme pour défendre à un homme le seuil de cette maison où elle avait été déjà trahie par un autre. Intimidé et sa casquette à la main, il balbutia :

- Tenez, madame, je vous ramène votre petit garçon qui s'était perdu près de la rivière.

Mais Simon sauta au cou de sa mère et lui dit en se remettant à pleurer :

- Non, maman, j'ai voulu me noyer, parce que les autres m'ont battu… m'ont battu… parce que je n'ai pas de papa.

Une rougeur cuisante couvrit les joues de la jeune femme, et, meurtrie jusqu'au fond de sa chair, elle embrassa son enfant avec violence pendant que des larmes rapides lui coulaient sur la figure. L'homme ému restait là, ne sachant comment partir. Mais Simon soudain courut vers lui et lui dit :

- Voulez-vous être mon papa ?

<!-- image -->

## A.  Étude de la trame de l'histoire

1. Comment commence le début de cette séquence ?
2. Que fait l'homme lorsqu'il reconnaît Simon comme le fils de la Blanchotte ?
3. Qu'est-ce que Simon avoue à sa mère une fois rentré chez lui ?
4. Quelle est la demande faite par Simon à l'homme qui l'a ramené à sa mère ?
5. Fais un résumé de cette séquence entre 20 et 50 mots.

## B.  Étude des personnages

1. Combien de personnages apparaissent dans cette séquence ? Qui sont-ils ?
2. Relève les mots et expressions qui décrivent l'homme (Philippe) qui apparaît dans cette séquence.
3. Relève  les  mots  et  expressions  qui  te  permettent  de  décrire  la  Blanchotte  telle  qu'elle apparaît dans cette séquence.

## C.  Étude de thème

Décris  en  tes  propres  mots  le  thème  de  l'amour  maternel  tel  qu'il  est  présent  dans  cette séquence.

## Séquence 6

## Extrait

Un grand silence se fit. La Blanchotte, muette et torturée de honte, s'appuyait contre le mur, les deux mains sur son cœur. L'enfant, voyant qu'on ne lui répondait point, reprit :

- Si vous ne voulez pas, je retournerai me noyer.

L'ouvrier prit la chose en plaisanterie et répondit en riant :

- Mais oui, je veux bien.
-   Comment est-ce que tu t'appelles, demanda alors l'enfant, pour que je réponde aux autres quand ils voudront savoir ton nom ?
- Philippe, répondit l'homme.

Simon se tut une seconde pour bien faire entrer ce nom-là dans sa tête, puis il tendit les bras, tout consolé, en disant :

- Eh bien ! Philippe, tu es mon papa.

L'ouvrier, l'enlevant de terre, l'embrassa brusquement sur les deux joues, puis il s'enfuit très vite à grandes enjambées.

Quand l'enfant entra dans l'école, le lendemain, un rire méchant l'accueillit ; et à la sortie, lorsque le gars voulut recommencer, Simon lui jeta ces mots à la tête, comme il aurait fait d'une pierre : "Il s'appelle Philippe, mon papa."

Des hurlements de joie jaillirent de tous les côtés :

- Philippe qui ?... Philippe quoi ?... Qu'est-ce que c'est que ça, Philippe ?... Où l'as-tu pris ton Philippe ?

Simon ne répondit rien ; et, inébranlable dans sa foi, il les défiait de l'œil, prêt à se laisser martyriser plutôt que de fuir devant eux. Le maître d'école le délivra et il retourna chez sa mère.

Pendant trois mois, le grand ouvrier Philippe passa souvent auprès de la maison de la Blanchotte et, quelquefois, il s'enhardissait à lui parler lorsqu'il la voyait cousant auprès de sa fenêtre. Elle lui répondait poliment, toujours grave, sans jamais rire avec lui, et sans le laisser entrer chez elle.

Quant à Simon, il aimait beaucoup son nouveau papa et se promenait avec lui presque tous les soirs, la journée finie. Il allait assidûment à l'école et passait au milieu de ses camarades sans jamais leur répondre.

Un jour, pourtant, le gars qui l'avait attaqué le premier lui dit :

- Tu as menti, tu n'as pas un papa qui s'appelle Philippe. - Pourquoi ça ? demanda Simon très ému.

Le gars se frottait les mains. Il reprit :

- Parce que si tu en avais un, il serait le mari de ta maman.

Simon se troubla devant la justesse de ce raisonnement, néanmoins il répondit : "C'est mon papa tout de même."

- Ça se peut bien, dit le gars en ricanant, mais ce n'est pas ton papa tout à fait.

<!-- image -->

## A.  Étude de la trame de l'histoire

1. a.  Quel est le changement majeur qui s'est produit dans la vie de Simon ? b.  Comment cela a changé sa vie à l'école ?
2. a.  Pourquoi un beau jour le gars qui l'avait attaqué lui dit qu'il a menti ? b.  Qu'est-ce que cela fait à Simon ?
3. Ecris en tes propres mots un résumé de l'histoire depuis le début de la séquence 1 jusqu'à la fin de la séquence 6.

## B.  Étude des personnages

1. Relève  dans  cette  séquence  les  mots  et  expressions  qui  te  permettront  de  décrire  les personnages suivants :
- a.  Simon
- b.  La Blanchotte, la mère de Simon
- c.  Philippe, le papa de Simon.

## C.  Étude de thème

Décris en tes propres mots la fierté de Simon en tant qu'un fils qui a retrouvé un papa.

## Séquence 7

## Extrait

Simon courba la tête et s'en alla rêveur du côté de la forge, où travaillait Philippe.

Cette forge était comme ensevelie sous des arbres. Il y faisait très sombre ; seule, la lueur rouge d'un foyer formidable éclairait par grands reflets cinq forgerons aux bras nus qui frappaient sur leurs enclumes avec un terrible fracas. Ils se tenaient debout, enflammés comme des démons, les yeux fixés sur le fer ardent qu'ils torturaient ; et leur lourde pensée montait et retombait avec leurs marteaux.

Simon entra sans être vu et alla tout doucement tirer son ami par la manche. Celui-ci se retourna. Soudain le travail s'interrompit, et tous les hommes regardèrent, très attentifs. Alors, au milieu de ce silence inaccoutumé, monta la petite voix frêle de Simon.

- -Dis donc, Philippe, le gars à la Michaude m'a conté tout à l'heure que tu n'étais pas mon papa tout à fait.
- -Pourquoi ça ? demanda l'ouvrier.

L'enfant répondit avec toute sa naïveté :

- -Parce que tu n'es pas le mari de maman.

Personne ne rit. Philippe resta debout, appuyant son front sur le dos de ses grosses mains que supportait le manche de son marteau dressé sur l'enclume. Il rêvait. Ses quatre compagnons le regardaient et, tout petit entre ces géants, Simon, anxieux, attendait. Tout à coup, un des forgerons, répondant à la pensée de tous, dit à Philippe :

- -C'est tout de même une bonne et brave fille que la Blanchotte, et vaillante et rangée malgré son malheur, et qui serait une digne femme pour un honnête homme.
- -Ça, c'est vrai, dirent les trois autres.

L'ouvrier continua :

- -Est-ce sa faute, à cette fille, si elle a failli ? On lui avait promis mariage, et j'en connais plus d'une qu'on respecte bien aujourd'hui et qui en a fait tout autant.
- -Ça, c'est vrai, répondirent en chœur les trois hommes.

Il reprit : "Ce qu'elle a peiné, la pauvre, pour élever son gars toute seule, et ce qu'elle a pleuré depuis qu'elle ne sort plus que pour aller à l'église, il n'y a que le bon Dieu qui le sait."

- -C'est encore vrai, dirent les autres.

Alors on n'entendit plus que le soufflet qui activait le feu du foyer.

<!-- image -->

## A.  Étude de la trame de l'histoire

1. Pourquoi Simon est-il allé à la forge ?
2. Dans quel état se trouve Philippe après avoir écouté Simon ?
3. Qu'est-ce que les quatre compagnons de Philippe essayent de faire comprendre à Philippe ? Justifie ta réponse.
4. Fais un résumé de cette séquence entre 20 et 50 mots.

## B.  Étude des personnages

1. Relève les mots et expressions qui te permettent de décrire Simon tel qu'il apparaît dans cette séquence.
2. Fais le même exercice pour décrire la Blanchotte, la mère de Simon.

## C.  Étude de thème

Étudie le thème de l'innocence (pour les personnages Simon et sa mère, la Blanchotte) dans cette séquence.

## Séquence 8

## Extrait

Philippe, brusquement, se pencha vers Simon :

- -Va dire à ta maman que j'irai lui parler ce soir.

Puis il poussa l'enfant dehors par les épaules.

Il revint à son travail et, d'un seul coup, les cinq marteaux retombèrent ensemble sur les enclumes. Ils battirent ainsi le fer jusqu'à la nuit, forts, puissants, joyeux comme des marteaux satisfaits. Mais, de même que le bourdon d'une cathédrale résonne dans les jours de fête au-dessus du tintement des autres cloches, ainsi le marteau de Philippe, dominant le fracas des autres, s'abattait de seconde en seconde avec un vacarme assourdissant. Et lui, l'œil allumé, forgeait passionnément, debout dans les étincelles.

Le ciel était plein d'étoiles quand il vint frapper à la porte de la Blanchotte. Il avait sa blouse des dimanches, une chemise fraîche et la barbe faite. La jeune femme se montra sur le seuil et lui dit d'un air peiné : "C'est mal de venir ainsi la nuit tombée, monsieur Philippe."

Il voulut répondre, balbutia et resta confus devant elle.

Elle reprit : - "Vous comprenez bien pourtant qu'il ne faut plus que l'on parle de moi."

Alors, lui, tout à coup :

- -Qu'est-ce que ça fait, dit-il, si vous voulez être ma femme !

Aucune voix ne lui répondit, mais il crut entendre dans l'ombre de la chambre le bruit d'un corps qui s'affaissait. Il entra bien vite ; et Simon, qui était couché dans son lit, distingua le son d'un baiser et quelques mots que sa mère murmurait bien bas. Puis, tout à coup, il se sentit enlevé dans les mains de son ami, et celui-ci, le tenant au bout de ses bras d'Hercule, lui cria :

- -Tu leur diras, à tes camarades, que ton papa c'est Philippe Remy, le forgeron, et qu'il ira tirer les oreilles à tous ceux qui te feront du mal.

Le  lendemain,  comme  l'école  était  pleine  et  que  la  classe  allait  commencer,  le  petit  Simon  se leva, tout pâle et les lèvres tremblantes : "Mon papa, dit-il d'une voix claire, c'est Philippe Remy, le forgeron, et il a promis qu'il tirerait les oreilles à tous ceux qui me feraient du mal."

Cette fois, personne ne rit plus, car on le connaissait bien ce Philippe Remy, le forgeron, et c'était un papa, celui-là, dont tout le monde eût été fier.

<!-- image -->

## A.  Étude de la trame de l'histoire

1. Comment cette séquence commence-t-elle ?

2. a.  Qu'est-ce qui est réalisé dans la rencontre entre Philippe et la Blanchotte ?
- b.  Quel changement cela apporte-t-il dans la vie de Simon à l'école ?
3. Décris en tes propres mots la fin de cette histoire.

## B.  Étude des personnages

Relève les éléments d'information qui te permettent de décrire Philippe dans cette dernière séquence.

## C.  Étude de thème

Étudie le thème de la joie au sein de la famille dans cette séquence.

## Activités générales

## A.  Sur l'histoire

1. Entre 150 à 200 mots, fais un résumé de cette histoire.
2. Explique la morale de cette histoire en tes propres mots.

## B.  Sur les personnages

Utilise  les  informations  que  tu  as  recueillies  dans  les  activités  précédentes  pour  faire  la description des personnages suivants :

- a.  Simon
- b.  La Blanchotte, mère de Simon
- c.  Philippe, le papa de Simon.

## C.  Sur les thèmes

En te basant sur l'histoire « le papa de Simon », exprime-toi, en tes propres mots sur les thèmes suivants :

- a.  La méchanceté des camarades de classe envers un ami qui n'a pas de papa.
- b.  L'amour d'une mère pour son fils.
- c.  L'innocence d'une femme abandonnée.
- d.  La gentillesse d'un homme envers une mère abandonnée et son fils.

This image consists of two images. The first image is a wooden plank with a visible grain pattern. The second image is a book with a visible cover.

<!-- image -->

In this image, there is a person standing and holding a pen. The person is wearing a yellow dress and brown shoes. The person is holding a big blue color object. The person is smiling. In the background, there is a white color object.

<!-- image -->

In this image we can see a wooden wall. On the right side of the image there are some books.

<!-- image -->

## Marcel Pagnol Topaze (1931)

Extraits choisis et adaptés partiellement

## I. Comprendre le théâtre

Le  théâtre  est  un  genre  littéraire  qui  n'est  pas  nouveau  pour  toi.  L'année  dernière,  dans  le manuel de Littérature française Grade 8 , tu as travaillé sur un extrait de L'Avare de Molière. L'année d'avant, en Grade 7, dans le manuel d' Initiation à la Littérature française ,  tu  as  découvert un extrait de trois pièces de théâtre : Fiancés en herbe de Georges Feydeau , Le Malade imaginaire de Molière et L 'Invité ou huit jours à la campagne de Jules Renard . Donc, tu dois à présent avoir une connaissance du texte théâtral.

Le  théâtre  est  un genre  littéraire tout  comme  le  romanesque  et  la  poésie.  Une  pièce  de théâtre est faite pour être jouée, pour être mise en scène . C'est un mélange de littérature et de spectacle. Sur scène, chaque comédien joue son rôle en donnant la réplique à  d'autres comédiens qui jouent leur rôle.

Le spectateur regarde le jeu des comédiens au théâtre. Le lecteur lit les répliques des personnages dans le texte théâtral.

Le lecteur ne voit pas le jeu des comédiens. Pour bien comprendre le texte, il doit faire une lecture animée théâtralement, parfois à travers un jeu de rôle.

Le texte théâtral a ses propres spécificités. Par exemple, on ne trouvera pas dans la pièce un narrateur qui raconte une histoire tout comme dans un roman ou dans un conte. Mais, on retrouve des personnages qui donnent leurs répliques. Avant chaque réplique, apparaît le nom du personnage qui doit la dire.

Aussi, à la place de la narration, on a une didascalie qui explique au lecteur ce qu'il ne verrait pas en lisant la pièce mais que le spectateur peut voir lorsqu'il est au théâtre. Ainsi, la didascalie remplace la description : elle permet au lecteur de comprendre les gestes de chaque comédien sur scène, leur entrée et sortie et même d'imaginer les éléments du décor quand s'ouvre le rideau.

En ce sens, le texte théâtral est différent des autres textes.

À cause de l'absence de la narration et de la description telles qu'on les retrouve dans la prose (roman et conte), le texte théâtral relève donc du discours direct (voir « texte conversationnel » dans Français Grade 8 ). Il est composé de répliques des personnages qui forment un échange de dialogues. Quand le personnage est seul sur scène et qu'il parle à lui-même ou réfléchit à voix haute, il se livre à un monologue. Quand le monologue est long, cela s'appelle une tirade.

La forme du texte théâtral correspond à un découpage en actes . Et chaque acte est divisé en plusieurs scènes selon les entrées et les sorties des personnages.

Quand on étudie une pièce de théâtre, on étudie le hors-texte comme le titre et les didascalies aussi bien que le texte. Dans cette section, tu vas étudier Topaze qui est une comédie de Marcel Pagnol.

Mais avant d'aller plus loin, tu dois t'assurer d'avoir bien compris ce qu'est le théâtre. Pour cela, réponds aux questions suivantes :

1. Nomme trois pièces de théâtre dont tu as déjà entendu parler.
2. Combien de genres littéraires connais-tu ? Fais-en une liste.
3. Quelle différence y a t-il lorsqu'un
- a.  spectateur regarde jouer une pièce de théâtre ?
- b.  lecteur lit une pièce de théâtre ?

4. Dans une pièce de théâtre,
- a.  que signifie la didascalie ? Quelle est la fonction de la didascalie ?
- b.  qu'est-ce qu'une réplique ?
- c.  qu'est-ce qu'une tirade ?
5. Décris la forme d'une pièce de théâtre.

## II.  Qui est Marcel Pagnol ?

In this image we can see a person wearing a shirt and a tie. In the background there is a wooden wall.

<!-- image -->

Marcel  Pagnol  est  un  écrivain  français,  né  en  1895  et  mort  en  1974.  Il  est  connu  pour  son œuvre  romanesque Souvenirs  d'enfance qui  comprend  les  romans La  Gloire  de  mon  père et Le Château de ma mère.

Le père de Marcel était instituteur. Quand sa mère partait au marché, elle le laissait dans la classe de son père. C'est en écoutant son père faire la classe que le petit Marcel, âgé alors de trois  ans  seulement apprit à lire couramment. C'était un enfant précoce. A l'âge de dix ans, il est reçu second à l'examen des bourses. Il fera de brillantes études. Il commence à écrire des poèmes à l'âge de quinze ans. À dix-huit ans, il obtient son baccalauréat de philosophie et commence des études de lettres. À dix-neuf ans, il publie des poèmes et son premier roman, Le mariage de Peluque.

Après  avoir  commencé  une  carrière  d'enseignant,  il  décide  de  se  consacrer  à  la  littérature et plus tard au cinéma.

Il  meurt  en  1974  à  Paris,  à  l'âge  de  79  ans,  laissant  derrière  lui  toute  une  œuvre  littéraire et cinématographique, monumentale, et aujourd'hui incontournable.

## III.  Présentation de Topaze

Topaze est une pièce de théâtre en quatre Actes, écrite en 1931 et réalisée en film par Marcel Pagnol lui-même en 1951, avec l'acteur Fernandel dans le rôle de Topaze.

Topaze est un professeur de morale à la pension Muche et qui fait son métier d'enseignant avec beaucoup de passion. C'est un homme sincère, mais naïf également. Il est discrètement amoureux d'Ernestine, la fille du directeur de la pension. Cette dernière va exploiter la naïveté de Topaze  en  se  servant  de  lui  pour  accomplir  les  tâches  qu'elle  n'aime  pas  faire,  comme corriger les copies de ses élèves.

Authentique  dans  son  travail,  il  refuse  de  changer  les  notes  d'un  élève  qui  a  échoué  aux examens.  La  mère  de  l'élève,  une  riche  baronne,  essaye  en  vain,  avec  l'aide  du  directeur, de corrompre Topaze. Mais ce dernier refuse catégoriquement de changer les notes de l'élève. Elle l'accuse alors de truquer les compositions. Topaze sera expulsé de la pension, sous prétexte qu'il aime la fille du directeur.

Il  sera engagé par un politicien corrompu qui va se servir de lui pour détourner de l'argent. Topaze  finira  par  devenir  lui-même  un  excellent  homme  d'affaires,  mais  avec  des  mœurs corrompues.

En résumé, la pièce Topaze nous enseigne comment toute la société des bonnes gens peut être corrompue si l'éducation même à la base est corrompue.

Etudions à présent l'Acte premier de la pièce Topaze .

<!-- image -->

## IV. Étude de Topaze

## Topaze Pièce de théâtre de Marcel Pagnol

Extraits choisis et adaptés partiellement pour les besoins des apprenants de Grade 9

## Acte premier

## CONSEILS A L'ENSEIGNANT(E)

Une salle de classe à la pension Muche.

Dans la scène première M. Topaze faisait une dictée à un élève.

M. Topaze a trente ans. Il a une longue barbe noire ; il porte une  cravate  misérable,  une  redingote  usée  et  des  souliers  à boutons.

## SCÈNE II

## L'ÉLÈVE, TOPAZE, ERNESTINE

Ernestine Muche entre en scène. C'est une jeune fille de vingt-deux ans, petite bourgeoise vêtue avec une élégance bon marché. Elle porte une serviette sous le bras.

## ERNESTINE

Bonjour, monsieur Topaze.

## TOPAZE

Bonjour, mademoiselle Muche.

## ERNESTINE

Vous n'avez pas vu mon père ?

## TOPAZE

Non, M. le directeur ne s'est point montré ce matin.

## ERNESTINE

Quelle heure est-il donc ?

Après une lecture modèle à voix haute par l'enseignant / l'enseignante, il est conseillé de procéder à une distribution de rôles pour une lecture animée théâtralement par deux apprenant(e)s. Ce jeu de rôle peut être répété autant de fois que l'enseignant / l'enseignante de la classe le jugera nécessaire.

## TOPAZE

Il tire sa montre qui est énorme et presque sphérique.

Huit  heures  moins  dix,  mademoiselle.  Le  tambour  va  rouler  dans  trente-cinq  minutes exactement… Vous êtes bien en avance pour votre classe.

## ERNESTINE

Tant mieux, car j'ai du travail. Voulez-vous me prêter votre encre rouge ?

## TOPAZE

Avec le plus grand plaisir, mademoiselle… Je viens tout justement d'acheter ce flacon, et je vais le déboucher pour vous.

## ERNESTINE

Vous êtes fort aimable…

Topaze quitte son livre, et prend sur le bureau un petit flacon qu'il va déboucher avec la pointe d'un canif pendant les répliques suivantes.

## TOPAZE

Vous allez corriger vos devoirs ?

## ERNESTINE

Oui, et je n'aime pas beaucoup ce genre d'exercice…

## TOPAZE

Pour moi, c'est curieux, j'ai toujours eu un penchant naturel à corriger des devoirs… Au point que je me suis parfois surpris à rectifier l'orthographe des affiches dans les tramways ou sur les prospectus que des gens, cachés au coin des rues, vous mettent dans les mains à l'improviste... (il a réussi à ôter le bouchon.) Voici, mademoiselle. (Il flaire le flacon débouché avec un plaisir évident, et le tend à Ernestine.) Et je vous prie de garder ce flacon aussi longtemps qu'il vous sera nécessaire.

## ERNESTINE

Merci, monsieur Topaze.

## TOPAZE

Tout à votre service, mademoiselle…

ERNESTINE , elle allait sortir, elle s'arrête.

Tout à votre service ? C'est une phrase toute faite mais vous la dites bien !

## TOPAZE

Je la dis de mon mieux et très sincèrement.

## ERNESTINE

Il y a quinze jours, vous ne la disiez pas, mais vous étiez beaucoup plus aimable.

## TOPAZE , ému.

En quoi, mademoiselle ?

## ERNESTINE

Vous m'apportiez des boîtes de craies de couleur, ou des calendriers perpétuels, et vous veniez jusque dans ma classe corriger les devoirs de mes élèves… Aujourd'hui, vous ne m'offrez plus de m'aider.

## TOPAZE

Vous aider? Mais si j'avais sollicité cette faveur, me l'eussiez-vous accordée ?

## ERNESTINE

Je ne sais pas. Je dis seulement que vous ne l'avez pas sollicitée. (Elle montre le flacon et elle dit assez sèchement.) Merci tout de même…

Elle fait mine de se retirer.

TOPAZE , très ému.

Mademoiselle, permettez-moi…

## ERNESTINE

J'ai beaucoup de travail, monsieur Topaze…

Elle va sortir. Topaze, très ému, la rejoint.

## TOPAZE , pathétique.

Mademoiselle  Muche,  mon  cher  collègue,  je  vous  en  supplie  :  ne  me  quittez  pas  sur  un malentendu aussi complet.

ERNESTINE , elle s'arrête.

Quel  malentendu ?

## TOPAZE

Il est exact que depuis plus d'une semaine je ne vous ai pas offert mes services ; n'en cherchez point une autre cause que ma discrétion. Je craignais d'abuser de votre complaisance, et je redoutais un refus, qui m'eût été plus pénible que le plaisir que je m'en promettais était plus grand. Voilà toute la vérité.

## ERNESTINE

Ah ? Vous présentez fort bien les choses… Vous êtes beau parleur, monsieur Topaze…

## TOPAZE , il fait un pas en avant.

Faites-moi la grâce de me confier ces devoirs…

## ERNESTINE

Non, non, je ne veux pas vous imposer une corvée…

## TOPAZE , lyrique.

N'appelez point une corvée ce qui est une joie… Faut-il vous le dire : quand je suis seul, le soir, dans ma petite chambre, penché sur ces devoirs que vous avez dictés, ces problèmes que vous avez choisis, et ces pièges orthographiques si délicatement féminins, il me semble. (Il  hésite puis, hardiment) que je suis encore près de vous…

## ERNESTINE

Monsieur Topaze, soyez correct, je vous prie…

## TOPAZE , enflammé.

Mademoiselle, je vous demande pardon; mais considérez que ce débat s'est engagé de telle sorte  que  vous  ne  pouvez  plus  me  refuser  cette  faveur  sans  me  laisser  sous  le  coup  d'une impression pénible et m'infliger un chagrin que je n'ai pas mérité.

## ERNESTINE , après un petit temps.

Allons,  je  veux  bien  céder  encore  une  fois… (Elle  ouvre sa serviette et tire plusieurs liasses de devoirs, l'une après l'autre.)

TOPAZE les prend avec joie. A chaque liasse, il répète avec ferveur.

Merci, merci, merci, merci, merci.

## ERNESTINE

Il me les faut pour demain matin.

Elle rit.

## TOPAZE

Vous les aurez.

## ERNESTINE

Et surtout, ne mettez pas trop d'annotations dans les marges… Si l'un de ces devoirs tombait sous les yeux de mon père, il reconnaîtrait votre écriture au premier coup d'œil.

## TOPAZE

Et vous croyez que M. le directeur en serait fâché ?

## ERNESTINE

M. le directeur ferait de violents reproches à sa fille.

## TOPAZE

J'ai une petite émotion quand je pense que nous faisons ensemble quelque chose de défendu…

## ERNESTINE

Ah ! Taisez-vous…

## TOPAZE

Nous avons un secret… C'est délicieux d'avoir un secret. Une sorte de complicité…

## ERNESTINE

Si vous employez de pareils termes, je vais vous demander de me rendre mes devoirs.

## TOPAZE

N'en  faites  rien  mademoiselle,  je  serais  capable  de  vous  désobéir… Vous  les  aurez  demain matin…

## ERNESTINE

Soit. Demain matin, à huit heures et demie… Au revoir et pas un mot.

## TOPAZE , mystérieux.

Pas un mot.

Ernestine sort par là où elle est venue. Topaze resté seul rit de plaisir et lisse sa barbe. Il met les liasses de devoirs dans son tiroir. Enfin, il reprend son livre et revient vers l'élève.

<!-- image -->

## A.  Étude de l'action

1. Etudie le début de l'action dans la scène II en répondant aux questions suivantes :
- a.  Quelle est l'action qui ouvre cette scène ?
- b.  Quelle est la première raison qui explique la visite d'Ernestine ?
- c.  Quelle est la réaction spontanée de Topaze face à cette première raison ?
2. Quel service Topaze avait-il l'habitude d'offrir à Ernestine ? Le fera-t-il encore dans cette scène ? Justifie tes réponses.
3. Sur quel accord entre Topaze et Ernestine se termine la scène II ? Pourquoi cet accord entre les deux personnages ?
4. Penses-tu que la première raison de la visite d'Ernestine est un prétexte ? Si c'est le cas, à quoi a servi ce prétexte ? Explique et justifie ta réponse en te référant au texte.
5. Après avoir lu la scène II de l'acte premier, en moins de 50 mots, résume l'action telle qu'elle est jouée dans cette scène.
6. Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

<!-- image -->

## B.  Étude des personnages

1. Combien de personnages sont présents dans la scène II ? Qui sont-ils ?
2. En quelques mots, présente les informations qui te permettent de faire une description physique des personnages suivants :
- a.  Topaze
- b.  Ernestine
3. À ton avis qui sera le personnage principal de cette pièce de théâtre ? Justifie ta réponse.
4. a.  Quelle profession exerce Topaze ?
- b.    Quelles sont les autres informations qui t'indiquent sa profession depuis le début de la pièce ?
- c.  Est-ce qu'il aime cette profession ? Justifie ta réponse.
5. a.  Quel métier exerce Ernestine ?
- b.    Quelles sont les autres informations qui t'indiquent son métier depuis le début de la pièce ?
- c.  Est-ce qu'elle aime sa profession ? Justifie ta réponse.
6. Qui est le père d'Ernestine ? Quel métier exerce-t-il ? Justifie ta réponse.
7. Relève  les  mots,  expressions  et  répliques  qui  indiquent  les  sentiments  et  l'attitude  de Topaze  pour  Ernestine.  Exemple  :  la  réplique  d'Ernestine  «  vous  êtes  fort aimable … » indique la gentillesse de Topaze à l'égard d'Ernestine.
8. À  ton  avis,  est-ce  qu'Ernestine  est  sincère  et  franche  dans  sa  relation  avec  Topaze  ou joue-t-elle la comédie avec ce dernier ? Justifie ta réponse en employant les expressions et mots du texte de la scène II (répliques et didascalies) pour justifier tes idées.

## C.  Étude des thèmes

1. Fais une liste de mots que tu as rencontrés dans cette scène et qui pourraient être utilisés (même si ce n'est pas le cas) pour construire les principaux thèmes de la pièce.
2. Que signifie manipuler ? Étudie le thème de la manipulation chez le personnage Ernestine dans la scène II. Explique comment Ernestine abuse de son pouvoir de séduction pour amener Topaze à accepter de corriger ses devoirs. Pour cet exercice, tu dois montrer, par exemple :
- a.    Les différentes étapes de sa stratégie, de sa manœuvre depuis le début de la scène, par quoi elle commence et par quoi elle finit.
- b.  Comment les didascalies dévoilent le « faire semblant » dans ses gestes.
- c.    Comment certaines de ses répliques relèvent du chantage affectif et signifient parfois le contraire de ce qu'elle dit et sont donc des calculs pour tromper Topaze.
3. Que signifie être naïf ? Relève les détails (dans les répliques et les didascalies) qui indiquent la naïveté chez Topaze.

## SCÈNE VII

## TOPAZE, TAMISE

Entre Ernestine Muche

## ERNESTINE

Bonjour, messieurs…

TAMISE , il salue avec respect.

Mademoiselle…

## ERNESTINE

Monsieur Topaze, voulez-vous me prêter la mappemonde ?

## TOPAZE

Avec le plus grand plaisir, mademoiselle…

Il va ouvrir un petit meuble noir qui contient les cartes et en tire une mappemonde.

Il l' offre galamment à Ernestine.

TAMISE , mondain.

Vous avez ce matin une classe de géographie ?

## ERNESTINE

Oui, une leçon sur la répartition des continents et des mers.

## TOPAZE

Voici, mademoiselle…

## ERNESTINE

Je vous remercie, monsieur Topaze.

Elle sourit, elle sort, Topaze lui ouvre la porte.

## TAMISE

Mon cher, je te demande pardon… Si je n'avais pas été là, elle serait peut-être restée…

Il me semble que ça marche assez fort ?

## TOPAZE

Et tu ne sais pas tout ! (Confidentiel.) Tout à l'heure, elle m'a positivement relancé.

TAMISE , étonné et ravi.

Ah ! Bah ?

## TOPAZE

Elle m'a reproché ma froideur, tout simplement.

TAMISE , même jeu.

Ah ! Bah?

## TOPAZE

Elle n'a pas dit 'froideur' bien entendu… Mais elle me l'a fait comprendre, avec toute sa pudeur de jeune fille. Et j'ai obtenu qu'elle me confie encore une fois les devoirs de ses élèves.

## TAMISE

Elle a accepté ?

## TOPAZE

Les voici. (Il désigne les liasses de devoirs.) Les voici.

## TAMISE

Et alors, tu n'as pu faire autrement que lui avouer ta flamme ?

## TOPAZE

Non. Non. Je ne suis pas allé jusqu'à l'aveu.

## TAMISE

Non ?

## TOPAZE

Non… Considère qu'il s'agit de la main d'Ernestine Muche…

TAMISE , pensif.

C'est vrai. C'est un gros coup… Tu as visé haut, Topaze.

## TOPAZE

Et si je réussis, beaucoup de gens, peut-être, diront que j'ai visé trop haut.

## TAMISE

Evidemment… On pourra croire que tu as profité de ton physique pour mettre la main sur la pension Muche…

## TOPAZE

C'est vrai, ça.

TAMISE , un petit temps de réflexion, puis brusquement.

Et après tout, il faut être ambitieux… A la première occasion, le grand jeu.

## TOPAZE

Le grand jeu. Qu'entends-tu par le grand jeu ?

## TAMISE

Tu prépares le terrain par de regards significatifs. Tu sais, les yeux presque fermés… le regard filtrant…

Il rejette légèrement la tête en arrière et ferme les yeux à demi pour donner l'exemple du regard  « filtrant ».

## TOPAZE

Tu crois que c'est bon ?

## TAMISE

Si tu réussis, c'est épatant. Ensuite, tu t'approches d'elle, tu adoucis ta voix, et vas-y.

## TOPAZE

Vas-y… Mais comment y va-t-on ?

## TAMISE

Un peu d'émotion, un peu de poésie, et une demande en bonne et due forme. Si tu vois qu'elle hésite, sois hardi. (Il fait le geste de prendre une femme dans ses bras.) Un baiser.

## TOPAZE

Un baiser ! Mais que dira-t-elle ?

## TAMISE

Il se pourrait qu'elle se pâmât soudain, en murmurant « Topaze… Topaze. »

## TOPAZE

Ça, ce serait formidable, mais je n'ose pas l'espérer.

## TAMISE

On ne sait jamais. Ou alors il se pourrait que sa pudeur lui inspirât une petite réaction, par exemple elle te repoussera, elle te dira : « Que faites-vous là, monsieur ? » Mais ça n'a aucune importance. Tant qu'elle n'appelle pas : « Au secours », ça veut dire : « Oui. »

TOPAZE , après un temps.

Comment l'embrasser ? Sur le front ?

## TAMISE

Malheureux ! Un baiser sur la bouche !

## TOPAZE

Sur la bouche… Tu as fait ça, toi ?

TAMISE , gaillard.

Vingt fois.

## TOPAZE , décidé.

J'essaierai. Ce qui m'inquiète davantage, c'est le père.

## TAMISE

Ah !... Le père, ce n'est certainement pas la même manœuvre.

## TOPAZE

Je suis sûr qu'il m'estime et qu'il me sait parfaitement honnête… Mais un refus de sa part me ferait tellement de peine que… Je crois qu'il faudrait le sonder…

## TAMISE

Toi, je te vois venir : tu veux que je m'en charge !

## TOPAZE

Je n'osais pas te le demander.

## TAMISE

Entendu. A la première occasion.

## TOPAZE

Fais ça discrètement, qu'il ne se doute de rien.

## TAMISE

Oh ! Tu me connais. Je m'approcherai de la question à pas de loup.

<!-- image -->

## A.  Étude de l'action

1. Étudie le début de la scène VII en répondant aux questions suivantes :
- a.  Quelle action ouvre cette scène ?
- b.  Quelle est la première raison qui explique la visite d'Ernestine ?
- c.  Quelle est la réaction spontanée de Topaze à cette première raison ?
- d.    Compare  le  début  de  la  scène VII  avec  celui  de  la  scène  II.  Quels  sont  les  points  de similitude ?
2. Lorsque Ernestine quitte la scène, quelle confidence Topaze fait-il à Tamise ? Décris, en tes propres mots, cette confidence.
3. En quoi consiste ce « grand jeu » que Tamise conseille à Topaze ? Décris-le en tes propres mots.
4. Est-ce que Topaze accepte de jouer le grand jeu ? De qui a-t-il peur ?
5. Quelle mission Topaze confie-t-il à Tamise à la fin de la scène VII ?
6. Après  avoir  lu  la  scène VII  de  l'acte  premier, en moins de 50 mots, résume l'action telle qu'elle est jouée dans cette scène.
7. Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

## B.  Étude des personnages

1. Combien de personnages sont présents dans la scène VII ? Qui sont-ils ?
2. Présente les traits de caractère des personnages suivants en employant les expressions et mots du texte (répliques et didascalies) pour justifier tes idées :
- a.  Topaze
- b.  Tamise
3. Lequel des deux personnages est le plus influent et lequel est le plus naïf ? Justifie tes réponses.
4. Comment est présenté le père d'Ernestine dans cette scène ?
5. Décris le sentiment de Topaze pour Ernestine dans cette scène. Utilise les expressions et mots (dans les répliques et didascalies) pour justifier tes idées.
6. À ton avis, est-ce que Tamise est sincère et franc dans sa relation avec Topaze ? Justifie tes idées en employant les informations données dans la scène VII.

## C.  Étude des thèmes

1. Étudie l'influence de l'amitié dans cette scène. Montre comment Tamise initie Topaze à l'art de la séduction.
2. Relève les détails (dans les répliques et les didascalies) qui indiquent la naïveté chez Topaze.

## SCÈNE XI

## TOPAZE, ERNESTINE

Ernestine entre par la porte de gauche. Elle rapporte le flacon d'encre rouge. Elle a vu sortir de la classe de Topaze une jeune femme blonde de vingt-cinq ans, belle et élégamment vêtue.

## ERNESTINE

Eh bien, cher collègue, vous en recevez des belles dames !

## TOPAZE , rougissant

Cette personne est un parent d'élève. C'est-à-dire que son neveu…

## ERNESTINE

C'est-à-dire que je comprends pourquoi vous m'avez négligée depuis quelque temps !

TOPAZE , très ému.

Mademoiselle !

## ERNESTINE

Vous portiez vos calendriers perpétuels à d'autres ! Tenez, voilà votre encre. Je vous la rends, quoique cette dame ne me paraisse guère en avoir besoin.

## TOPAZE

Mademoiselle, je vous en supplie, ne vous fâchez pas !

## ERNESTINE

Monsieur Topaze, je ne me fâche pas ; je viens au contraire vous demander un grand service.

## TOPAZE

Je tiens à vous dire que je suis à votre entière disposition.

## ERNESTINE

Nous allons voir. (Elle se rapproche.) Figurez-vous que je prends des leçons de chant.

## TOPAZE

Ah ! je suis sûr que vous avez une très jolie voix !

## ERNESTINE

Oui, très jolie. Je vais chez mon professeur le jeudi matin, de dix heures à midi. Mon père ne sait pas que je prends ces leçons. C'est un petit secret entre ma mère et moi.

## TOPAZE , attendri

Je vous remercie de cette confidence…C'est un petit secret de plus entre nous.

## ERNESTINE

Exactement. Or, M. le directeur vient de décider que le service d'été commencera jeudi prochain.

Ça ne vous dit rien ?

## TOPAZE

Ça me dit beaucoup, naturellement. Beaucoup. Mais, dans le détail, je ne vois pas exactement quoi.

## ERNESTINE

Et bien, il va falloir que, le jeudi matin, j'emmène à la promenade tous les élèves de la classe enfantine. De dix à douze.

## TOPAZE

De dix à douze. (Frappé d'une idée.) Ah ! Mais alors, vous voilà forcée de renoncer à vos leçons de chant !

## ERNESTINE

Sans aucun doute.

## TOPAZE

Mais c'est navrant ! Il est évident que vous ne pouvez être à la même heure en deux endroits différents !

## ERNESTINE

Comprenez-vous quel service je veux vous demander ?

## TOPAZE

Parfaitement. Vous voulez que j'expose la situation à M. Muche, et qu'il change l'heure de la promenade ?

## ERNESTINE

Pas du tout. Je veux que vous conduisiez la promenade à ma place.

## TOPAZE

Mais oui ! (Joyeux.) Et moi qui n'ai justement rien à faire le jeudi matin !

## ERNESTINE

Parfait ! Je vais donc dire à mon père que vous demandez à conduire la promenade parce que, comme vous ne sortez jamais, ça vous donnera l'occasion de prendre l'air.

## TOPAZE

Excellent ! O ruse féminine ! (Il se rapproche d'elle. Avec émotion.) Mademoiselle Muche… C'est avec une joie profonde que je mènerai ces enfants à la promenade, parce que je … parce que je vous aime. (Il fait le regard filtrant.)

## ERNESTINE

Monsieur Topaze, je vous en prie…

## TOPAZE , il se rapproche.

Son regard est de plus en plus filtrant.

Je vous aime…Non pas d'une passion perverse et déshonorante…mais d'un amour honnête et profond, pour tout dire, conjugal. (Il s'est encore rapproché. Elle a peine à retenir son envie de rire. Il la prend brusquement dans ses bras.) Laissez-moi vous dire… (Il l'embrasse. Elle le repousse vigoureusement et le gifle.)

## ERNESTINE

Monsieur Topaze, à quoi pensez-vous ? Est-ce ainsi qu'on s'adresse à une jeune fille ? Tâchez de ne pas recommencer cette plaisanterie, je vous prie. Et n'oubliez pas que jeudi vous faites la promenade à ma place.

Elle sort.

## TOPAZE

Elle a eu la petite réaction prévue…Divine pudeur…Mais elle n'a pas appelé au secours, je crois que ça y est ! (Il se frotte la joue et répète.) Divine pudeur !

Un terrible roulement de tambour est répercuté par les quatre murs de la citerne. On voit à travers la porte-fenêtre des enfants qui se mettent en rang devant la classe. Topaze va leur ouvrir la porte. Mais ils n'entrent pas. Ils attendent son ordre. Il dit « Allez ! » Toute la classe, qui se compose d'une douzaine de gamins de dix à douze ans, entre. Ils sont deux par deux.

<!-- image -->

## A.  Étude de l'action

1. Étudie le début de la scène XI en répondant aux questions suivantes :
- a.  Quelle action ouvre cette scène ?
- b.  Quelle est la première raison de la visite d'Ernestine ?
- c.  Quel est le reproche fait par Ernestine à Topaze ?
- d.  Quelle est la réaction spontanée de Topaze suite à ce reproche ?
- e.    Compare le début de la scène XI avec celui de la scène VII. Quels sont les points de similitude ?
2. Quelle confidence Ernestine fait-elle à Topaze dans cette scène ?
3. Quel service Ernestine vient-elle demander à Topaze ?
4. Quelle déclaration Topaze fait-il à Ernestine ?
5. Suivant le conseil de Tamise,
- a.  quelle action Topaze tente-t-il d'accomplir avec Ernestine ?
- b.  quelle est la réaction spontanée de celle-ci face à cette action ?
- c.  quelle conclusion Topaze tire-t-il de la réaction d'Ernestine ?
6. Après  avoir  lu  la  scène  XI  de  l'acte  premier,  en  moins  de  50  mots,  résume  l'action  telle qu'elle est jouée dans cette scène.
7. Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

<!-- image -->

## B.  Étude des personnages

1. Combien de personnages sont présents dans la scène XI ? Qui sont-ils ?
2. Présente les traits de caractère des personnages suivants en employant les expressions et mots du texte (répliques et didascalies) pour justifier tes idées :
- a.  Topaze
- b.  Ernestine
3. Résume les sentiments de Topaze pour Ernestine. Utilise les expressions et mots du texte (répliques et didascalies) pour justifier tes idées.
4. À ton avis, est-ce que Ernestine est sincère et franche dans sa relation avec Topaze ? Justifie ta réponse en employant les informations données dans la scène XI.

## C.  Étude des thèmes

1. Étudie le thème de la manipulation chez le personnage Ernestine dans la scène XI. Explique comment Ernestine abuse de son pouvoir de séduction  pour  proposer  à Topaze  de  la remplacer afin d'emmener les élèves de la classe enfantine à la promenade. Montre les différentes étapes de sa stratégie depuis le début de la scène.
2. Relève les détails (dans les répliques et les didascalies) qui indiquent la naïveté chez Topaze.

## SCÈNE XIII

## TOPAZE, MUCHE, LA BARONNE

## MUCHE

Monsieur Topaze, Mme la baronne Pitart-Vergniolles désire vous parler.

## TOPAZE

Monsieur le directeur, je suis à votre entière disposition.

Les élèves sortent.

## LA BARONNE , à Topaze,

Je viens vous demander, monsieur Topaze, ce que vous pensez du travail de mon fils. Il vous aime beaucoup, monsieur. Il parle souvent de vous à son père en des termes qui marquent une grande estime.

## TOPAZE

J'en suis très heureux, madame… Je tiens à mériter l'estime de mes élèves…

## MUCHE

Vous l'avez, mon cher Topaze. Je dirai même que vous avez gagné leur affection.

Topaze se rengorge et sourit.

## LA BARONNE

L'enfant  vous  apprécie  à  tel  point  qu'il  a  exigé  que  je  vienne  vous  demander  des  leçons particulières…

## TOPAZE

J'en suis très flatté, madame…

## LA BARONNE

Je  viens  donc  vous  dire,  monsieur,  que  vous  lui  donnerez  chaque  semaine  autant  d'heures que vous voudrez, et au prix que vous fixerez. Vous viendrez chez moi demain soir et vous me mettrez au courant de ce que vous aurez décidé pour le nombre et le prix des leçons.

## TOPAZE

C'est entendu, madame.

## LA BARONNE

Permettez-moi maintenant de vous parler d'une affaire qui me tient à cœur…

## MUCHE

Oh ! Une bagatelle qui sera promptement rectifiée…

## TOPAZE

De quoi s'agit-il, madame ?

## LA BARONNE , elle tire de son sac une enveloppe.

Je viens de recevoir les notes trimestrielles de mon fils et je n'ai pas osé montrer ce bulletin à son père…

## MUCHE

J'ai déjà expliqué à Mme la baronne qu'il y a eu sans doute une erreur de la part du secrétaire qui recopie vos notes…

## TOPAZE

Je ne crois pas, monsieur le directeur…Car je n'ai pas de secrétaire, et ce bulletin a été rédigé de ma main…

Il  prend le bulletin et l'examine.

## MUCHE , il appuie sur certaines phrases.

Mme la baronne, qui vient de vous demander des leçons particulières , a trois enfants dans notre maison, et je lui ai moi-même de grandes obligations !...C'est pourquoi je ne serais pas étonné qu'il y eût une erreur.

## TOPAZE , regarde le bulletin.

Pourtant, ces notes sont bien celles que j'ai données à l'élève…

## LA BARONNE

Comment ? (Elle lit sur le bulletin.) Français : zéro. Calcul : zéro. Histoire : un quart. Morale : zéro.

## MUCHE

Allons ! Regardez  bien, monsieur Topaze…regardez de plus près, avec toute votre perspicacité…

## TOPAZE

Oh ! C'est vite vu…Il n'a eu que des zéros…Je vais vous montrer mes cahiers de notes…

(Il prend un cahier ouvert.)

## MUCHE , il lui prend le cahier et le ferme.

Ecoutez-moi, mon cher ami. Il n'y a pas grand mal à se tromper : l'erreur est humaine. (Il  le regarde fixement entre les deux yeux.) Voulez-vous être assez bon pour refaire le calcul de la moyenne de cet enfant ?

## TOPAZE

Bien volontiers…Ce ne sera pas long…

Il s'installe à sa chaire, ouvre plusieurs cahiers et commence ses calculs. Cependant, la Baronne et Muche, debout, échangent quelques phrases à haute voix, tout en regardant Topaz e.

## MUCHE

Aurez-vous bientôt, madame la baronne, l'occasion de rencontrer M. l'Inspecteur d'Académie ?

## LA BARONNE

Je  le  verrai  mercredi.  C'est  un  ancien  condisciple  du  baron,  il  a  pour  nous  une  très  grande amitié…

## MUCHE

Il  a  beaucoup  d'estime  pour  notre  ami  M. Topaze,  mais  il  n'a  pas  pu  lui  donner  les  palmes académiques cette année… Il ne les lui a décernées que moralement.

## LA BARONNE

Oh !... M. Topaze aura son ruban à la première occasion. Je vous le promets !

## MUCHE

Dites donc, mon cher ami, Madame la baronne promet que vous aurez réellement les palmes l'an prochain…

## TOPAZE , il relève la tête

Ce serait vraiment une grande joie, madame… Cette nouvelle est pour moi plus que vous ne pensez, madame…

## MUCHE

Vous avez retrouvé l'erreur ?

## TOPAZE

Mais non… Il n'y a pas d'erreur…

## MUCHE , impatienté

Voyons, voyons, soyez logique avec vous-même !... Vous croyez Mme la baronne quand elle vous dit que vous aurez les palmes et vous ne la croyez pas quand elle affirme qu'il y a une erreur !

## TOPAZE

Mais, madame, je vous jure qu'il n'y a pas d'erreur possible. Sa meilleure note est un 2… Il a eu encore un zéro, hier, en composition mathématique… Onzième et dernier : Pitart-Vergniolles.

LA BARONNE. Elle change de ton.

Et pourquoi mon fils est-il dernier ?

MUCHE , il se tourne vers Topaze.

Pourquoi dernier ?

## TOPAZE

Parce qu'il a eu zéro.

MUCHE , à la Baronne.

Parce qu'il a eu un zéro.

## LA BARONNE

Et pourquoi a-t-il eu zéro ?

MUCHE , il se tourne vers Topaze sévèrement.

Pourquoi a-t-il eu zéro ?

## TOPAZE

Parce qu'il n'a rien compris au problème.

MUCHE , à la baronne, en souriant.

Rien compris au problème.

## LA BARONNE

Et pourquoi n'a-t-il rien compris au problème ? Je vais vous le dire, monsieur Topaze, puisque vous me forcez à changer de ton. (Avec éclat.) Mon fils a été le dernier parce que la composition était truquée.

## MUCHE

Etait truquée!... ho! ho! Ceci est d'une gravité exceptionnelle…

Topaze est muet de stupeur et d'émotion.

## LA BARONNE

Le problème était une sorte de labyrinthe à propos de deux terrassiers qui creusent un bassin rectangulaire. Nierez-vous qu'il y ait dans votre classe un élève nommé Gigond ?

## MUCHE , à Topaze.

Un élève nommé Gigond ?

## TOPAZE

J'ai un élève nommé Gigond.

## MUCHE , à la Baronne.

Un élève nommé Gigond.

## LA BARONNE , brusquement.

Quelle est la profession de son père ?

## TOPAZE

Je n'en sais rien !

LA BARONNE , à Muche sur le ton de quelqu'un qui porte un coup décisif.

Le père du nommé Gigond a une entreprise de terrassement. Dans le jardin du nommé Gigond, il y a un bassin rectangulaire . Voilà. Je n'étonnerai personne en disant que le nommé Gigond a été premier.

## MUCHE , sévèrement.

Que le nommé Gigond a été premier. (A la baronne en souriant.) Mon Dieu, madame…

## TOPAZE , stupéfait.

Mais je ne vois nullement le rapport…

## LA BARONNE , avec autorité.

Le problème a été choisi pour favoriser le nommé Gigond. Il est impossible d'admettre que mon fils soit dernier.

## MUCHE , à Topaze.

Impossible d'admettre que son fils soit dernier.

## TOPAZE

Mais, madame, cet enfant est dernier, c'est un fait.

## LA BARONNE

Un fait inexplicable.

## MUCHE , à Topaze.

C'est peut-être un fait, mais il est inexplicable.

## TOPAZE

Mais non, madame, et je me charge de vous l'expliquer.

## LA BARONNE

Ah ! vous vous chargez de l'expliquer ! Eh bien, je vous écoute, monsieur.

## TOPAZE

Tantôt il bavarde, fait tinter des sous dans sa poche, ricane sans motif et jette des boules puantes. A des moments, il me regarde fixement, il paraît m'écouter avec grande attention. En réalité, les yeux grands ouverts, il dort.

## LA BARONNE , elle sursaute.

Il dort ?

## MUCHE

Ceci devient étrange. Vous dites qu'il dort ?

## LA BARONNE

Allons, monsieur, vous rêvez.

## TOPAZE

Non, madame, je veux vous parler dans son intérêt, et je sais que ma franchise lui sera utile. Ce qu'il lui faut, c'est une surveillance médicale.

## MUCHE

Allons, mon cher Topaze, je crois que vous feriez beaucoup mieux de trouver l'erreur.

## LA BARONNE

Monsieur Muche, si ce diffamateur professionnel doit demeurer dans cette maison, je vous retire mes trois fils séance tenante. Quant à ce bulletin hypocrite, voilà ce que j'en fais.

Elle  déchire  le  bulletin,  jette  les  morceaux  au  nez  de  Topaze  et  sort.  M.  Muche,  affolé,  la  suit, en bégayant : «Madame la baronne… Madame la baronne… »

<!-- image -->

## A.  Étude de l'action

1. Quelle est la première raison qui justifie l'arrivée de Madame la baronne ?
2. Quelle est la réaction de Topaze face à cette première raison de la visite de Madame la baronne ?
3. Quelle est la deuxième raison de sa visite ? Laquelle des deux raisons te semble être la principale ?
4. Quelle est la réaction de Topaze quand il apprend la deuxième raison de la visite de Madame la baronne ?
5. Quelle est la demande que fait M. Muche à Topaze ?
6. Quelle est la dernière décision de Topaze à la fin de la scène XIII ?
7. Quelle est la dernière décision de Madame la baronne à la fin de la scène XIII ?
8. Après avoir lu la scène XIII de l'acte premier, en moins de 50 mots, résume l'action telle qu'elle est jouée dans cette scène.
9. Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

## B.  Étude des personnages

1. Combien de personnages sont présents dans cette scène ? Qui sont-ils ?
2. Présente les traits de caractère des personnages suivants en employant les expressions et mots du texte (répliques et didascalies) pour justifier tes idées :
- a.  Topaze
- b.  Madame la baronne
- c.  M. Muche

## C.  Étude de thème

Étudie le thème de l'honnêteté chez le personnage de Topaze en tant qu'enseignant. Utilise les expressions et mots du texte (répliques et didascalies) pour justifier tes idées.

<!-- image -->

## SCÈNE XV

## MUCHE, TAMISE

## TAMISE

Bonjour, monsieur le directeur.

## MUCHE

Bonjour.

## TAMISE

Je désirerais, monsieur le directeur, vous demander un conseil.

## MUCHE

Venez me voir dans mon bureau à midi.

## TAMISE

Monsieur le directeur, je m'excuse d'insister, mais j'aimerais vous parler tout de suite, car je crois que c'est le moment.

MUCHE , qui regarde du côté de la fenêtre.

Je vous écoute.

## TAMISE , machiavélique.

Monsieur le directeur, vous n'êtes pas seulement le maître et le chef de cette maison, mais vous en êtes, à coup sûr, la plus haute autorité morale.

## MUCHE , distrait.

Si vous voulez.

## TAMISE

C'est pourquoi je voudrais avoir votre opinion sur une affaire qui n'a rien de scolaire… (un temps Muche le regarde d'un œil froid). J'ai un ami, qui est jeune, bien fait de sa personne et qui me paraît avoir un certain avenir.

## MUCHE

Eh bien ?

## TAMISE

Cet ami est amoureux d'une jeune fille qui, de son côté, n'est pas indifférente aux charmes de mon ami, puisqu'elle lui a donné des encouragements très nets.

## MUCHE

Eh bien ?

## TAMISE

Tout ceci, normalement, devrait se terminer par un mariage, mais il y a une certaine différence de fortune et de situation. Mon ami est lieutenant, le père de la jeune fille est général. Et voici la question que je veux vous poser. Si mon ami tente une démarche auprès du général, comment sera-t-il reçu ?

## MUCHE

Voilà qui mérite examen… Votre ami est-il un parfait honnête homme ?

## TAMISE

Pour ça, j'en réponds.

## MUCHE

Le général est-il un homme de cœur ?

## TAMISE

Oh ! oui, il a une âme de général.

## MUCHE

Que votre ami présente sa demande. Il sera reçu à bras ouverts, du moins, je le crois.

TAMISE , un large sourire.

Eh bien, le général, c'est vous !

MUCHE , stupéfait.

Moi, général ?

## TAMISE

Le lieutenant, c'est Topaze, et la jeune fille, c'est la toute gracieuse Mlle Muche.

## MUCHE

Comment, Topaze veut épouser ma fille ?

## TAMISE

Oui.

## MUCHE

Et vous dites qu'elle lui a donné des encouragements ?

## TAMISE

Nets, mais discrets et dignes d'une jeune fille de bonne famille…

## MUCHE

Par exemple ?

## TAMISE

Quand elle a des devoirs à corriger, elle les lui confie, ils se retrouvent ici même pendant les récréations… Bref, c'est une idylle…

## MUCHE

Je vais étudier la question…

## TAMISE

Que dois-je dire à Topaze ?

## MUCHE

Rien. Je lui parlerai moi-même.

## TAMISE

J'aurais aimé lui rapporter…

MUCHE , ex abrupto.

J'ai moi aussi une question à vous poser. Croyez-vous que l'électricité soit un fluide gratuit ?

TAMISE , déconcerté.

Dans quel sens ?

## MUCHE

Hier, en quittant votre classe, vous avez négligé d'éteindre quatre lampes qui l'éclairent. Elles brûlaient encore ce matin à huit heures. C'est pour cette raison que je vous retiendrai, à la fin du mois, quinze francs, plus dix francs d'amende.

## TAMISE

Mais il me semble pourtant…

## MUCHE

D'autre part, si vous exerciez sur vos élèves une surveillance plus attentive, je n'aurais pas eu le déplaisir de lire sur un pupitre de votre classe une inscription gravée au couteau qui dit en majuscules de cinq centimètres : Muche égale salaud.

## TAMISE

Sur quel pupitre ?

## MUCHE

Allez-y voir, monsieur Tamise. Tâchez de découvrir le coupable, sinon je vous prierai de remplacer le pupitre à vos frais. Et puisque vous me demandez conseil, je vais vous donner celui-ci : il vaudrait mieux vous occuper de votre métier que de faire l'entremetteur bénévole, et de jouer les valets de comédie. Au revoir…

Tamise, médusé, se dirige à reculons vers la sortie. Il veut parler encore une fois. Muche le coupe net.

## MUCHE

Je ne vous retiens pas.

Il sort, écrasé.

<!-- image -->

## A.  Étude de l'action

1. Pourquoi Tamise vient-il rendre visite à M. Muche ?
2. Qui  est  cet  «  ami  »  et  cette  «  jeune  fille  »  à  qui Tamise  fait  référence  au  début dans ses répliques ?
3. Pourquoi Tamise ne mentionne-t-il pas les noms de Topaze et d'Ernestine au début ?
4. Quel conseil M. Muche donne-t-il à Tamise pour son « ami » ?
5. Quelle est la vraie identité de cet « ami » et de cette « jeune fille » ?
6. Quelle est la première réaction de M. Muche lorsqu'il apprend leur vraie identité ?
7. Quel est ce service que Topaze a l'habitude d'offrir en secret à Ernestine et que Tamise finit par dévoiler à M. Muche ?
8. Que propose M. Muche lorsqu'il apprend toute la vérité sur sa fille ?
9. Quel est le premier reproche que M. Muche adresse à Tamise après avoir appris la raison de sa visite ?
10.  Quelle information concernant Tamise M. Muche révèle-t-il à ce dernier ?
11.  Au final, quel conseil M. Muche donne-t-il à Tamise ?
12.    Après avoir lu la scène XV de l'acte premier, en moins de 50 mots, résume l'action telle qu'elle est jouée dans cette scène.
13.  Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

## B.  Étude des personnages

1. Combien de personnages sont présents dans cette scène ? Qui sont-ils ?
2. Présente les traits de caractère des personnages suivants en employant les expressions et mots du texte (répliques et didascalies) pour justifier tes idées :
- a.  Tamise
- b.  M. Muche

## C.  Étude de thème

Étudie le thème de l'amitié chez le personnage de Tamise. Utilise les expressions et mots du texte (répliques et didascalies) pour justifier tes idées.

## SCÈNE XVI

## MUCHE, ERNESTINE

MUCHE , il ouvre la porte de la classe d'Ernestine.

Ernestine… viens ici… (Elle entre.) Est-il vrai que tu fasses corriger tous tes devoirs par Topaze ?

## ERNESTINE

Oui, c'est vrai.

## MUCHE

Pourquoi ?

## ERNESTINE

Parce que c'est un travail qui me dégoûte. Cette classe enfantine, j'en ai horreur. Pendant que d'autres se promènent avec des manteaux de fourrure, je reste au milieu de trente morveux… Tu crois que c'est une vie ?

## MUCHE

C'est la vie d'une institutrice.

## ERNESTINE

Puisque je la supporte, tu n'as rien à dire. Et si je trouve un imbécile qui corrige mes devoirs, je ne vois pas en quoi je suis coupable…

## MUCHE

Je ne te reproche pas de faire faire ton travail par un autre. Le principe même n'est pas condamnable. Mais pour quelle raison cet idiot fait-il ton travail ?

## ERNESTINE

Parce que je le fais marcher.

## MUCHE

Ouais… Tu ne lui as rien donné en échange ?

## ERNESTINE

Rien.

## MUCHE

Alors, pourquoi s'imagine-t-il que tu l'aimes ? Il a l'intention de me demander ta main.

## ERNESTINE

Il peut toujours la demander !

## MUCHE

Comment aurait-il cette audace si les choses n'étaient pas allées plus loin que tu ne le dis ? Allons, dis-moi la vérité. Qu'y a-t-il entre vous ?

## ERNESTINE

Rien. Il me fait les yeux doux.

## MUCHE

C'est tout ?

## ERNESTINE

Il a même essayé de m'embrasser.

## MUCHE

Où ?

## ERNESTINE

Ici.

MUCHE , il se prend la tête à deux mains.

Malheureuse !... Dans une classe !... Tous les enfants pouvaient donc le voir, le raconter à leur famille ! Tu veux donc chasser les derniers élèves qui nous restent ?

## ERNESTINE

Oh ! pour ça, la cuisinière s'en charge !

## MUCHE , violent.

Réponds à ce que je te dis, au lieu de diffamer la maison de ton père ! Il n'y a rien d'autre entre vous ?

## ERNESTINE

Mais non, voyons ! Pour qui me prends-tu ?

## MUCHE

Bien.

Il fait quelques pas, les mains derrière le dos, les dents serrées, le front barré de trois plis verticaux entre les sourcils. On voit enfin Topaze paraître sur la porte. Il a perdu son lorgnon. Il marche presque à tâtons, les yeux clignés, il se dirige vers la chaire.

<!-- image -->

## A.  Étude de l'action

1. Où se déroule la scène XVI ? Sur quelle action s'ouvre la pièce ?
2. Quelle est la raison de la visite de Muche dans la classe de sa fille ?
3. Est-ce que Ernestine aime sa vie d'institutrice ? Justifie tes réponses en employant les mots et les expressions du texte (répliques et didascalies).
4. A qui Ernestine fait-elle référence lorsqu'elle emploie l'expression « un imbécile qui corrige mes devoirs » ?
5. Sur quoi Muche interroge-t-il sa fille Ernestine ? Pourquoi l'interroge-t-il sur ce sujet ?
6. Qu'est-ce que Topaze a osé faire de choquant avec Ernestine ?
7. En  fin  de  compte  qu'est-ce  que  Muche  apprend  concernant  la  relation  de  sa  fille  avec Topaze ?
8. Après avoir lu la scène XVI de l'acte premier, en moins de 50 mots, résume l'action telle qu'elle est jouée dans cette scène.
9. Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

<!-- image -->

## B.  Étude des personnages

1. Combien de personnages sont présents dans la scène ? Qui sont-ils ?
2. Présente les traits de caractère des personnages suivants en employant les expressions et mots du texte (répliques et didascalies) pour justifier tes idées :
- a.  Ernestine
- b.  Muche
3. Décris le personnage de Topaze tel qu'il apparaît dans les répliques d'Ernestine adressées à son père Muche.
4. Décris le sentiment d'Ernestine pour Topaze. Utilise les expressions et mots du texte pour justifier tes idées.

## C.  Étude de thème

Étudie la vérité sur la relation entre Topaze et Ernestine dans cette scène. Utilise les expressions et les mots du texte (répliques et didascalies) pour justifier tes idées.

## SCÈNE XVII

## TOPAZE, MUCHE, ERNESTINE

## TOPAZE

Monsieur le directeur, cette dame refuse de m'entendre tant que je n'aurai pas retrouvé cette erreur ! (Avec violence) Et pourtant, il n'y en a pas ! Je ne peux pourtant pas inventer une erreur !

## MUCHE , glacial.

Taisez-vous, taisez-vous, monsieur ! On peut duper les gens pendant longtemps, mais il vient toujours un moment où le bandeau tombe, où les yeux s'ouvrent, où l'imposteur est démasqué. Monsieur, vous êtes la honte de cette maison !

## TOPAZE

Monsieur le directeur…

## MUCHE

Vous donnez en cachette des leçons gratuites pour déconsidérer l'enseignement…

## TOPAZE

Monsieur le directeur…

## MUCHE

Vous m'annoncez des élèves qu'on refuse ensuite de nous confier. Vous refusez de retrouver une erreur, quand c'est un parent d'élève qui l'exige ; vous truquez les compositions !

## TOPAZE

Mais, monsieur le directeur…

## MUCHE

Et pour comble, vous ajoutez à la sottise et à la mauvaise foi la lubricité la plus scandaleuse !

## TOPAZE

Moi ? Moi ? Mademoiselle Muche….

## MUCHE

Ici même, dans cette classe, et sous les yeux de nos enfants épouvantés, n'avez-vous pas essayé de déshonorer ma fille !

## TOPAZE

Moi ? Moi ?

## MUCHE

C'est  par  égard  pour  cette  maison  que  je  ne  ferai  pas  appeler  la  police.  Passez  à  la  caisse immédiatement. À partir d'aujourd'hui, dix heures, vous n'appartenez plus à l'établissement. Venez, Ernestine !

Il entraîne sa fille et disparaît.

## TOPAZE

Monsieur le directeur ! Monsieur Muche !... (Ils sont partis. Il a un geste de désespoir) . À la porte, moi… Mais c'est monstrueux !... C'est la journée des malentendus !

Tristement, il sort

RIDEAU

<!-- image -->

## A.  Étude de l'action

1. Où se déroule la scène ? Sur quelle action s'ouvre la pièce ?
2. Que vient faire Topaze dans cette scène ? Justifie ta réponse.
3. Quelles sont les accusations que Muche adresse à Topaze ? Liste ces accusations.
4. Quelle est la décision finale prise par Muche concernant Topaze ?
5. Après avoir lu la scène XVII de l'acte premier, en moins de 50 mots, résume l'action telle qu'elle est jouée dans cette scène.
6. Si tu dois donner un titre à cette scène, lequel choisiras-tu ?

## B.  Étude des personnages

1. Combien de personnages sont présents dans cette scène ? Qui sont-ils ?
2. Présente les traits de caractère des personnages suivants en employant les expressions et mots du texte (répliques et didascalies) pour justifier tes idées :
- a.  Topaze
- b.  Muche

## C.  Étude des thèmes

Étudie les thèmes de la vérité et du mensonge, dans cette scène. Utilise les expressions et les mots du texte (répliques et didascalies) pour justifier tes idées.

## Appréciation générale

1. Donne ton appréciation de ces extraits de Topaze en soulignant les aspects que tu aimes et ceux que tu n'aimes pas.
2. Quel est le personnage qui t'a le plus marqué dans cette pièce de théâtre Topaze ? Dis pourquoi.
3. À ton avis, quelle pourrait être la suite de cette histoire ? Imagine-la et raconte-la en 150 mots environ.

In the center of the image there is a stack of old books. On the right side there is a feather.

<!-- image -->