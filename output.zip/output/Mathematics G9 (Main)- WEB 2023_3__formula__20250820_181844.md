In this image, we can see a poster with some text and images.

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

Professor Vassen Naëck

- -Head Curriculum Implementation,Textbook Development and Evaluation

## MATHEMATICS PANEL

Sooryadev Purdasseea

- Coordinator, Lecturer, MIE

Dr Rajeev Nenduradu

- Associate Professor, MIE

Dr Khemduth Singh Angateeah

- Lecturer, MIE

Deobarruth Seetulparsad

- Retired senior educator

Naaz Parveen Edoo-Rujbaully

- Educator

Umesh Rajcoomar

- Educator

Vijayen Marden

- Educator

Rakesh Teeluckdarry

- Educator

Dharamveer Bansee

- Educator

Marie Christmède Meunier

- Educator (Rodrigues)

Design

Kunal Sumbhoo

- Graphic Designer, MIE

Karnesh Ramful

- Graphic Designer, MIE

- © Mauritius Institute of Education (2021)

ISBN: 978-99949-53-82-0

## Acknowledgements

The Mathematics textbook panel wishes to thank the following:

-  Mathematics Education Department (MIE) for proof reading and vetting.
-  Komal Reshma Gungapersand (Lecturer, MIE) for proof reading.

Consent from copyright owners has been sought. However, we extend our apologies to those we might have overlooked. All materials should be used strictly for educational purposes.

<!-- image -->

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources, Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies of learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The  development  of  textbooks  has  been  a  very  challenging  exercise  for  the  writers  and  the  MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the   NCF, while ascertaining that the instructional designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic designers who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## PREFACE

This book is the third of a series of three Mathematics textbooks for lower secondary level. It closely adheres to the philosophy of the National Curriculum Framework (Secondary), particularly, catering for the 21st century competencies. This book is designed to cater for the needs of students of all abilities. A pedagogically rich approach is used in the presentation of the contents. Furthermore, the focus is on the spiral nature of the curriculum.

The present textbook is one of the few textbooks written using a framework called Variation Theory (VT).  Variation Theory has been used in the designing of both the contents and exercises. This is done with the intention to help students discern important aspects of the various topics.

Mathematical concepts are introduced inductively to develop better conceptual understanding and reasoning skills in students rather than learning through rote memorisation. Students are given the opportunity  to  make  connections,  comparisons,  visualisations  and  effectively  communicate  their mathematical ideas with others. Hence, it is expected that students will be engaged behaviourally, emotionally and more importantly, cognitively with the topics. To ensure mastery of mathematical concepts,  exercises  are  included  after  explanation  of  each  concept  so  that  educators  can  assess learning  before  moving  to  the  next  concept.    Furthermore,  the  exercises  are  graded  using VT  in order to develop procedural fluency in students. In addition, revision exercises are incorporated to consolidate concepts/topics learnt earlier and to ensure spiral teaching.

Real  life  examples  are  given  at  the  start  of  each  topic  to  incite  students'  curiosity  and  interest  in mathematics. As such, learning of mathematical concepts will be less boring since students will be able to link their personal and real life experiences to Mathematics. Furthermore, various concepts learnt  during  Grades  7  and  8  are  recapitulated  before  consolidating  and  extending  interrelated concepts at Grade 9 level.

The  panel,  constituting  of  both  academics  from  the  MIE  and  experienced  secondary  educators, have addressed core skills and competencies that students are expected to develop in order to be successful in learning Mathematics. In the current Grade 9 textbook, the topics and mathematical concepts are arranged and presented such that connections can be made among them. In other words, educators can scaffold on previously acquired concepts in a progressive manner.

At the end of each chapter, continuous assessments are embedded to gauge students' understanding of the key mathematics concepts.

Mathematics Panel

## Table of Contents

| Chapter 1: Indices                         |   1 |
|--------------------------------------------|-----|
| Chapter 2: Binomial expressions            |  13 |
| Chapter 3: Quadratics                      |  27 |
| Chapter 4: Algebraic manipulation          |  41 |
| Revision exercise 1                        |  62 |
| Chapter 5: Coordinates                     |  63 |
| Chapter 6: Simultaneous equations          |  85 |
| Chapter 7: Inequalities                    | 101 |
| Chapter 8:Trigonometry                     | 117 |
| Revision exercise 2                        | 137 |
| Chapter 9: Matrices                        | 139 |
| Chapter 10:Volume and capacity             | 159 |
| Chapter 11: Surface area                   | 177 |
| Chapter 12: Personal and household finance | 191 |
| Revision exercise 3                        | 207 |
| Chapter 13: Patterns and sequence          | 209 |
| Chapter 14: Vectors and translation        | 227 |
| Chapter 15: Statistics                     | 255 |
| Chapter 16: Probability                    | 273 |
| Revision exercise 4                        | 286 |
| Revision exercise 5                        | 289 |

## Learning Objectives

## By the end of this chapter, you should be able to:

- recognise and apply multiplication and division laws of indices (including negative powers).
- identify and use power law of indices.
- understand and use the power zero index law ( a 0 = 1 ; a ≠ 0).
- apply the two rules: (ab) n = a n b n and n =     . a n b n a b
- solve simple equations involving indices.

## Indices in real life

In  ICT,  we  often  hear  about  megabytes,  gigabytes,  and terabytes.

"Mega" means 10 6  or one million, "giga" means 10 9 , and "tera" means 10 12 . The prefixes mega- and giga- are used in other fields as well; one example is megahertz, which means 10 6  or one million hertz

<!-- image -->

- Base
- Index
- Power
- Index form
- Laws of indices
- Zero index
- Negative index
- Fractional indices
- Equivalent indices
- Equations

<!-- image -->

In Grade 7 and 8, you learnt about the different laws and rules of indices.

In this chapter, you are going to revisit these laws before learning how to solve simple equations involving indices.

## Historical fact

<!-- image -->

Nicomachus of Gerasa lived  around  100AD.  He  discovered  an  interesting number pattern involving cubes and sum of odd numbers.

1 = 1 = 1

3

3 + 5 = 8 = 2 3

7 + 9 + 11 = 27 = 3 3

1 3 + 15 + 17 + 19 = 64 = 4 3 etc

2 × 2 × 2 × 2 × 2 = 2 5 2 5 is read as 2 to the power or index of 5 2 is the base.

<!-- image -->

<!-- image -->

## Laws of indices

## Multiplication law

a m × a n = a (m+n)

## Example

Simplify the following leaving your answer in index form.

(a) 2 4 × 2 2 (b) x 4 × y 2 × x 3 (c)   5 x 4 × 3 x 2

## Solution

(a) 2 4 × 2 2 = 2 4+2 (b) x 4 × y 2 × x 3 = x 4+3 y 2 (c)   5 x 4 × 3 x 2  = (5×3) x 4+2 = 2 6 = x 7 y 2 = 15 x 6

<!-- image -->

## EXERCISE 1.1

Simplify the following, leaving your answer in index form.

- (a) 5 4 × 5 3

(b) 3 5 × 3

2

- (c) x 3 × x 6

(d) 3 1 × 7 5 × 3 2 × 7 8

- (e) a 2 × b × a 5

(f) 3 a 3 × a 2

- (g) 5 ab 5 × a 3 b 2

(h) 3 m 4 n 2 × 4 m 5 n 5

- (i) 3 xy × x 3 y 2 z 3 4

(j) 8 p 6 × pq ×5

## Division law

$$a ^ { m } \div a ^ { n } = a ^ { ( m - n ) } \,, a \neq 0$$

## Example

Simplify the following leaving your answer in index form.

(a) 2 7 ÷ 2 3 (b) x 4 y 5 ÷ x 3 y 2 (c)   18 x 5 ÷ 3 x 2

## Solution

$$( \tt a ) \, 2 ^ { 7 } \div 2 ^ { 3 } & = 2 ^ { 7 - 3 } & ( \tt b ) \, x ^ { 4 } \, y ^ { 5 } \div x ^ { 3 } y ^ { 2 } & = x ^ { 4 - 3 } \, y ^ { 5 - 2 } & ( \tt c ) \, \ 1 8 x ^ { 5 } \div 3 x ^ { 2 } & = \frac { 1 8 x ^ { 5 } } { 3 x ^ { 2 } } \\ & = 2 ^ { 4 } & = x y ^ { 3 } & = 6 x ^ { 5 - 2 }$$

= 6 x 3

## Caution:

2 3 × 2 4 ≠ 4 3 + 4

(When using multiplication law, the base must remain same.)

2 3 × 2 4 = 2 3 + 4

= 2 7

## Caution:

a x + a y ≠ a x+y (powers are added only when we multiply two numbers with same base in index form)

3 2 + 3 3 ≠ 3 2 + 3

3 2 + 3 3 = 9 + 27

<!-- image -->

Simplify the following, leaving your answer in index form.

- (a) 5 4 ÷ 5 2

(b) 3 5 ÷ 3 2

- (c) b 8 ÷ b 6

(d) 5 x 3 ÷ x 2

- (e) 12 x 5  ÷ 3 x 2

(f) a 7  ÷ 5 a 2

(g)

(h)

- (i) 15 s 4 t 5

(j)

12

a

4

6 a 2

2 t 2

21 pq 4

35 pq 2

pq

5

p

2

q

2

## Power law

## (a m ) n = a mn

## Example

Express each of the following in simplest index form.

(a)  (3 2 ) 4

(b) ( m 3 ) 5

(c)   3( p 2 ) 4

## Solution

(a)  (3 2 ) 4 = 3 2×4

= 3 8

(b) ( m 3 ) 5 = m 3×5

= m 15

(c)   3( p 2 ) 4 = 3 p 2×4

= 3 p 8

<!-- image -->

## EXERCISE 1.3

Simplify the following, leaving your answer in index form.

- (a) (3 2 ) 5

(b) ( a 4 ) 3

- (c) 3( a 2 ) 5

(d) ( m 3 ) 5 × ( m 2 ) 3

- (e) 2( p 2 ) 3 × ( p 2 ) 3

(f) 3( m 3 ) 7 × 2 ( m 5 ) 3

(g)

(h) 5( x 2 ) 3

- (i) ( t 3 ) 7 × ( p 2 ) 5 × ( t 3 ) 4

- (j) ( t 3 ) 7 × ( t 4 ) 3

(

m

4

)

6

(

m

3

)

5

25( x 4 ) 2

( t 2 ) 4

## Zero index

## a 0 = 1 , a ≠ 0

## Example

(a) 3 0

=1       (b) 2 m 0 = 2(1)           (c) (2

m ) 0 = 1

= 2

<!-- image -->

RECALL

## Consider

(2 3 ) 2 = 2 3 × 2 3

3+3

= 2

= 2 6

which is same as 2 3×2

## So, in general

( a m ) n = a mn

<!-- image -->

<!-- image -->

## Evaluate the following.

- (a) (4) 0

(b) p 0

(c) 3( t ) 0

(d) (3 m ) 0 × m 0

(e) (0.5) 0

(f) 0 2 5

- (g) (2) 0

(h)

(i) 2(4 3 ) 0 × (4 0 ) 7 × (6 3 ) 0

(j) 5 0 + 5 1 + 5 2

(3 5 ) 0

25(

x

0

)

2

5( x 2 ) 0

Rule 1

( ab ) n = a n b n

Rule 2

= a b n a n b n

## Example

## Simplify the following

$$( \mathbf a ) = ( 2 p ) ^ { 3 } \, \quad \ \ \ ( \mathbf b ) \, \left ( \frac { 1 } { x } \right ) ^ { 2 }$$

## Solution

(a)  (2 p ) 3 =  2 3 p 3

= 8 p 3

$$( \mathbf b ) \left ( \frac { 1 } { x } \right ) ^ { 2 } & = \frac { 1 ^ { 2 } } { x ^ { 2 } } \\ & = \frac { 1 } { x ^ { 2 } }$$

<!-- image -->

(ab) 3 = (ab) × (ab) ×

$$a b ) ^ { 3 } & = ( a b ) \times ( a b ) \times ( a b ) \\ & = a \times b \times a \times b \times a \times b \\ & = a ^ { 3 } b ^ { 3 }$$

$$\Big | \ \left ( \frac { a } { b } \right ) ^ { 2 } = \left ( \frac { a } { b } \right ) \times \left ( \frac { a } { b } \right ) = \frac { a \times a } { b \times b } = \frac { a ^ { 2 } } { b ^ { 2 } }$$

(c)  ( x 3 y 2 )

$$( x ^ { 3 } y ^ { 2 } ) ^ { 5 } & & ( \text{d} ) \left ( \frac { x ^ { \ell } } { y ^ { 3 } } \right ) ^ { 4 }$$

$$\left ( \mathfrak { d } \right ) \left ( \frac { x ^ { 2 } } { \mathfrak { d } 3 } \right ) ^ { 4 }$$

(c)  ( x 3 y 2 ) 5 = ( x 3 ) 5 ( y 2 ) 5

= x 15 y 10

$$( \mathrm d ) \left ( \frac { x ^ { 2 } } { y ^ { 3 } } \right ) ^ { 4 } & = \frac { ( x ^ { 2 } ) ^ { 4 } } { ( y ^ { 3 } ) ^ { 4 } } \\ & = \frac { x ^ { 8 } } { y ^ { 1 2 } }$$

<!-- image -->

## EXERCISE 1.5

Simplify the following, leaving your answer in index form.

- (a) (2 b ) 4

(b) ( ab ) 3

- (c) ( a 2 b 3 ) 0

(d) (2 m 3 ) 5 × (3 m 2 ) 3

- (e) 2( p 2 q ) 3 ÷ ( p 2 q ) 3

(f) ( m 3 n ) 7 × ( m 5 ) 3 × mn 5

- (g) m n 3

$$( \mathbf h ) \quad \left ( \frac { a ^ { 4 } } { b ^ { 2 } } \right ) ^ { 3 }$$

$$( i ) \quad ( a b ^ { 3 } ) ^ { 7 } \times \left ( \frac { a } { b } \right ) ^ { 3 }$$

$$( j ) = \frac { \left ( \frac { m ^ { 3 } } { n ^ { 2 } } \right ) ^ { 4 } \times \left ( \frac { m } { n } \right ) ^ { 3 } } { ( m n ) ^ { 4 } }$$

## Negative indices

$$a ^ { - n } = \left ( \frac { 1 } { a } \right ) ^ { n } \ a \neq 0$$

<!-- image -->

## RECALL

$$\Big | \ \frac { 3 ^ { 3 } } { 3 ^ { 5 } } = \frac { 3 \times 3 \times 3 } { 3 \times 3 \times 3 \times 3 } = \ \frac { 1 } { 3 \times 3 } = \ \frac { 1 } { 3 ^ { 2 } }$$

Using division law

$$\Big | \ \frac { 3 ^ { 3 } } { 3 ^ { 5 } } = 3 ^ { 3 - 5 } = 3 ^ { - 2 }$$

$$\bigcup \, \text{So } 3 ^ { - 2 } = \frac { 1 } { 3 ^ { 2 } }$$

## Example

Express in positive index form.

$$\begin{smallmatrix} ( a ) & 3 ^ { - 2 } \end{smallmatrix}$$

$$\left ( \mathbf a \right ) \, 3 ^ { - 2 } \, & \left ( \mathbf b \right ) \, 4 y ^ { - 3 } \, & \left ( \mathbf c \right ) \, x ^ { - 3 } \times x ^ { - 2 } \, & \left ( \mathbf d \right ) \, 2 ^ { 2 } \div 2 ^ { 7 }$$

$$2 ^ { 7 }$$

## Solution

$$( a ) \ 3 ^ { - 2 } = \frac { 1 } { 3 ^ { 2 } } \int _ { \begin{array} { c } ( b ) \ 4 y ^ { - 3 } = 4 \left ( \frac { 1 } { y ^ { 3 } } \right ) \quad ( c ) \ x ^ { - 3 } \times x ^ { - 2 } = x ^ { - 3 + - 2 } \quad & ( d ) \ 2 ^ { 2 } \div 2 ^ { 7 } = 2 ^ { 2 - 7 } \\ = \frac { 4 } { y ^ { 3 } } \quad & = x ^ { - 5 } \quad & = 2 ^ { - 5 } \\ = \frac { 1 } { x ^ { 5 } } \quad & = \frac { 1 } { 2 ^ { 5 } } \end{array}$$

<!-- image -->

## EXERCISE 1.6

Simplify the following, leaving your answer in positive index form.

- (a) x -3

- (b) ( a -4 ) 3

- (c) ( a 2 ) -4 × a 3

- (d) 5( m 3 ) -5 × ( m -2 ) 3

- (e) ( p 2 ) 3 ÷ ( p 2 ) 8

- (f) ( m 3 ) -7 ÷ ( m 5 ) 3

- (g) ( m 2 ) -5 ( m 3 ) 2

$$( h ) \quad \frac { ( x ^ { 4 } ) ^ { 2 } \times x ^ { - 1 2 } } { ( x ^ { 2 } ) ^ { 3 } }$$

- (i) ( t -3 ) 7 × ( t 3 ) -7 × ( t 3 ) 2

$$( j ) \quad \frac { ( p ^ { 3 } ) ^ { 2 } \times ( p ^ { 4 } ) ^ { - 3 } } { ( p ^ { 2 } ) ^ { 4 } }$$

<!-- image -->

We can represent square roots using the symbol √ or fractional exponents √ a = a 1 2

Similarly, we can represent cube roots using the symbol √ or fractional exponents √ a = a 3 3 1 3

## Fractional indices

## Note:

$$\sqrt { a } = a ^ { \frac { 1 } { 2 } }$$

$$\stackrel { 3 } { \sqrt { a } } = a ^ { \frac { 1 } { 3 } }$$

$$\overset { n } { \sqrt { a } } = a ^ { \frac { 1 } { n } }$$

$$\stackrel { n } { \sqrt { a } ^ { m } } = a ^ { m \times \frac { 1 } { n } }$$

$$\overset { n } { \sqrt { a } } ^ { m } = \, a ^ { m \times \frac { 1 } { n } } \, \ n \neq 0$$

$$\stackrel { 3 } { \sqrt { a } ^ { m } } = a ^ { m \times \frac { 1 } { 3 } }$$

In general,

| Example                |                        |                           |                            |
|------------------------|------------------------|---------------------------|----------------------------|
| Evaluate the following | Evaluate the following |                           |                            |
| (a) √81                | (b) √64 3              | (c) (32) 1 5              | (d) (4 6 ) 1 3             |
| Solution               |                        |                           |                            |
| (a) √81 = (81) 1 2     | (b) √64 = (2 6 ) 3 1 3 | (c) (32) = (2 5 ) 1 5 1 5 | (d) (4 6 ) = 4 6 × 1 3 1 3 |
| = (3 4 ) 1 2           | = 2 2                  | = 2 1                     | = 4 2                      |
| = 3 2                  | = 4                    | = 2                       | = 16                       |
| = 9                    |                        |                           |                            |

<!-- image -->

## EXERCISE 1.7

Evaluate the following.

| (a)   | √256       | (b)   | √225         |
|-------|------------|-------|--------------|
| (c)   | √125 3     | (d)   | √216 3       |
| (e)   | √400       | (f)   | (3 4 ) 1 2   |
| (g)   | (5 6 ) 1 3 | (h)   | √0.25        |
| (i)   | 81 144     | (j)   | √256 × √27 3 |

## Equations involving indices

Consider the following equations. What do you observe?

(a)    5 x +1 = 5 3

(b)    5 2 x - 1 =125

(c) x 5 = 2 5

These equations involve indices where the unknowns are either the index or the base.

## Solving equations involving indices

How can we solve the equation 5 2 x -1 =125 ?

Well, to be able to solve such equations, we use the following rule

If a x = a y then x = y

## Example

Solve the following equations. (a) 5 x = 5 3 (b) 3 2 x +1 = 3 2 (c) m 4 = 3 4 (d) 3 2 x = 81 Solution (a) 5 x = 5 3 Since the bases are same, we conclude that x = 3. (b) 3 2 x +1 = 3 2 Here again the bases are same, so 2 x + 1 = 2 2 x = 2 - 1 2 x = 1 x = (c) m 4 = 3 4 Compairing indices and bases we get, m = 3 (d) 3 2 x = 81 Here, neither the base nor the index are same. So we need to either convert base or index in such a way that we can compare right and left hand sides. In this case we can write 81 as 3 4 . So, 3 2 x = 81 becomes 3 2 x = 3 4 . Hence 2 x = 4 x = x = 2 1 2 4 2

Note:

$$2 ^ { x } = \frac { 1 } { 2 ^ { 4 } }$$

<!-- image -->

x ≠ 4

In fact,

$$\begin{array} { c c } 2 ^ { x } = \frac { 1 } { 2 ^ { 4 } } = 2 ^ { - 4 } \end{array}$$

x = -4

A number can be written as a product of its prime factors either in expanded form or index form.

## Example

81= 3×3×3×3 (expanded form)

=3 4  (index form)

## Example

1. Solve the following equations. (a)   5 x = 25                (b) 3 2 x = 81       (c)  2 x +1  = 64 Solution (a)   5 x = 25 Here, the two bases are not same. So, we need to write 25 in index form. 5 x = 5 2 Now, these two numbers are equivalent. So x = 2 (b) 3 2 x = 81 Here, again we need to write both numbers with same base 3 2 x = 3 4 (81 = 3 × 3 × 3 × 3 = 3 4 ) Then, 2 x = 4 x = x = 2 (c)  2 x +1  = 64 64 in index form is 2 6 . Hence, 2 x +1 = 2 6 so x + 1 = 6 x = 6 -1 x = 5 4 2

## Example

2. Solve the following equations.

$$\underline { 3 ^ { x } }$$

(a)   5 x × 5 2 = 5                (b) 3 2 x × 3 3 = 81       (c)         = 27 3 2

Solution (a)   5 x × 5 2  = 5 Here,  we  have  numbers  with  the  same  base  but  on  the  left  hand  side  of  the  equation, we have two numbers which can be simplified. 5 x + 2 = 5 1 (multiplication law) Now these two numbers are equivalent. So, x + 2 = 1 x = 1 - 2 x = -1 (b) 3 2 x × 3 3  = 81 Here again we need to simplify the numbers on both sides. 3 2 x + 3 = 3 4 (using multiplication law on the left hand side and expressing 81 as 3 4 ) Then  2 x + 3 = 4 2 x = 4 - 3 2 x = 1 x = (c)         = 27 Here we have to simplify the numbers on the left hand side using division law and write 27 to base 3. 3 x -2 = 3 3 so x - 2 = 3 x = 3 + 2 x = 5 1 2 3 x 3 2

<!-- image -->

## EXERCISE 1.8

Solve the following equations.

(a) 4 x = 4 2 (b) 5 2 x = 5 6 (c) 2 x -3 = 2 4 (d) 2 x = 64 (e) 3 x = 1 (f) a x = 1 (g) 4 x = (h) 2 3 x = (i) 5 x = 5 3 × 5 2 (j) 7 x × 7  3  = 49 (k) = 2 7 (l) 2 x -3 ÷ 2 3 = 16 (m) 4 3 = x 3 (n) x 5 = 3 5 (o) x 3 = 5 3 (p) (2 x ) 5 = 6 5 1 4 2 1 2 9 (2) x (2 5 ) 2

## Summary

1. Multiplication law:
2. a m × a n = a (m+n)
2. Division law: a m ÷ a n = a (m-n)

3. Power law: (a m ) n = a mn

4. Zero index: a 0 = 1
5. Negative index: a -n = 1 a n
6. Rule 1:     ( ab ) n = a n b n
7. Rule 2:                = a b n a n b n
8. Fractional indices  -    Square roots:   √ a = a 1 2

Cube roots:      √ a = a 1 3 3

9. Equations involving indices :          If

a x

=

a y then

x

=

y

Or    If x m = y m then x = y

## Continuous Assessment

## 1 Write in index form.

- (a) 2 x 2 x 2 x 2
- (c) 4 x 4 x 4 x 7 x 7 x 7
- (d) 2 x 6 x 6 x 2 x 2 x 6

## 2 Simplify the following .

- (a) 15a2

- (f) 2x4 X x2

- (b) 3 X a5 X b2

- (g) 3a5 X a2

- (c) 6xy5 X x?y

- 6y5 x 5y2 8 x3 X x3 Xy4

- (d)

- (e) x3 X y4 X x3

- (k) 54 X 52

- 35 x 32 35 X 32 X 37 8 x3 X x6 x2 X x4 X x9

## 3. Simplify the following, leaving your answer in index form \_

- (a) 57 + 52

- (b) 35 + 33

- (c) b6 + b4

- (d) 413

- (e) pl1

- (f) 36 32

- (g) 7

- (h) 5b5 + b2

- (i) 12 x8 + 3x2

- (j)

- (k) 3x5 6x2

- (l) 4xy7

- (m) 303b3

- (n) 12 s4t8 + 3s2

- (o)

## 4. Simplify as far as possible.

- (a) 3a3 X 5a2

(b)

12m5

- (c) (m3)4 x (m3)5
- (d) 'x262
- (e) 2m) 3n
- (f) X a-2 a-5

## 5 Evaluate the following

- (b) 216;
- (a) (84)2
- (c)

## 6 Solve the following equations.

- (a) 3x = 37
- (c) = 57 52x-3
- (e) 2* = 1
- (g) 7x = 7
- (i) mx = m3 X m?
- 34

(h) (3m3)5 x (2m2)2

(i) 3(p54)3 4 9(p34)3

- (j) 12(ab3)7 x 3 (2)5

(k) 12(mn)' x 4mn5 4 (3m)4

$$( d ) \ 8 ^ { \frac { 2 } { 3 } } ;$$

$$( e ) \ \frac { ^ { 1 } _ { 8 ^ { 3 } \times 1 6 ^ { 2 } } } { \sqrt { 6 4 } }$$

- (b) p2x = p8
- (d) 4x = 64
- (f) 3x+1 = 1
- (h) 24x = 20
- (j) 5* X 53 = 125

## 7. Circle the correct answer .

- (i) 32 A 97 B. 37 C. D. (ii) (43)-2 = A 41 B. C. D 121 (iii) 4 53 = A 51 B.5-5 C.25-6 D. (iv) If 32x = 32 then x = A 2 B.3 C.1 D.9 X 35 310 910 12-2 4-6 5-2 1-5

## 8. Write true or false next to each statement .

- (a) 42 = 8 (b) 28 + 23 = 25 (c) 52 x 54 = 256 (d) 4xo = 1 (e) 30 + 31 + 32 = 13
9. Evaluate the following .
- (a) 3-2
- (b) (23)2
- (c) 25z
- (d) 64}
- (a) x4 x 42
- (b) 5b5 x 363
- (c)
- 3a3xa4
- a2
- (e) 8t-6 + 2 t-2
- (d) (x4)3 x (x2)4
- = 25 (b) 42x = 64 (c) (3*)5 = 34 (d) = 2Xx4 (e) 16 4-6
- = 23

## 10.

## 11.

## BINOMIAL EXPRESSIONS

## Learning Objectives

## By the end of this chapter, you should be able to:

- identify a binomial expression.
- use area tables and the distributive law to find product of binomial expressions.
- expand and use perfect squares and difference of two squares.
- factorise difference of two squares.

## Binomial Expressions in real life

In this image, we can see a poster with some text and an image of a bridge.

<!-- image -->

Expanding two Brackets  is  a  skill  needed  for  graphing  and analysing  "Parabola"  shapes,  such  as  the  Sydney  Harbour Bridge.

Example:  It  is  a  very  basic  and  very  important  skill  used  in doing other parts of Mathematics, for instance, dribbling is a fundamental skill of basketball.

## CHECK THAT YOU CAN:

- Use the rules of indices
- Expand algebraic expressions
- Use the distributive law

<!-- image -->

## KEY TERMS

- Terms
- Expressions
- Binomial Expressions
- Distributive Law
- Perfect Squares
- Difference of two squares
- Factorisation

<!-- image -->

DID YOU KNOW

A  polynomial  is  an  expression  with two or more unlike terms.

## Expressions

An  expression  can  have  one  or  more  terms.  A  term  consists  of  an  unknown  or  a  constant multiplied by an unknown.

Examples of expressions are 3 x ,  4,  4 y 2 ,  2 xy ,  4 x -y ,  2 x 2 +  4  or  2 x 2 -3 xy + 2. These terms are connected by a '+' or a '-' sign.

Expressions which contain a single term are called monomials , expressions which contain only two unlike terms are called binomials and expressions which contain only three unlike terms are called trinomials .

<!-- image -->

## Algebraic expressions

4 x , 2 x -y , 2 a + 3 b + 9, 3 x 2  - 2 x + 5,              are examples of algebraic expressions. An algebraic expression  is  an  expression  which  involves  only  multiplication,  addition  and  subtraction of  numbers  and  unknowns.  Note  that  in  this  chapter,  we  are  concerned  with  binomial expressions only. 3 x - 2 4

<!-- image -->

## Which of these expressions are binomial?

3 x ,   4 x - 5 y ,   2 xy ,   4 a -b + 2 c , a - 4 b ,   2 xy - 4,               ,   2 a 2  + 3 b + c 2 , x 2 y , 2 x + 3 x , x 2 -y 2  + 2 z 2 , 4 y - 2 y + 10 y . 3 x + 1 4

## Expansion of algebraic expressions using distributive law

<!-- image -->

## RECALL

Expand (i) 3( a + 2 b )

Solution

$$( i ) & \underset { 3 ( a + 2 b ) } { 3 ( a + 2 b ) } \\ & = 3 \times a + 3 \times 2 b \\ & = 3 a \ + \ 6 b$$

(ii) -5(2 x -  4)

$$( \text{ii} ) & - 5 ( 2 x - 4 ) \\ & = - 5 \times 2 x - 5 \times ( - 4 ) \\ & = - 1 0 x \, + \, 2 0$$

<!-- image -->

## Expand each of the following.

(a) 5(2 a -7)

(b) -3(2 x + 3)

(e) x (2 x -3)

(i) 5 + 2( x + 3)

(f) a (2 a + 3)

(j) 6 x + x ( x - 2)

(iii) y (3 y -  5)

$$( \text{iii} ) & \stackrel { \complement } { y ( 3 y - 5 ) } \\ & = y \times 3 y + y \times ( - 5 ) \\ & = 3 y ^ { 2 } - \ 5 y$$

(c) -5( x -2)

(g) t (2 t -3)

(k) x 2 -x ( x + 3)

(iv) x (2 x - 4)

$$( \text{iv} ) - & x ( 2 x - 4 ) \\ & = - x \times 2 x - x \times ( - 4 ) \\ & = - 2 x ^ { 2 } + \ 4 x$$

(d) -7(-2 x -3)

(h) -2 y (2 y + 5)

(l) 3 x -x (3 x - 2)

<!-- image -->

Expand and simplify

(a) 2( x - 3 ) + 3( x + 4 )

## Solution

(a) 2(

x

- 3) + 3(

= 2 ×

x

+ 4)

+ 2 × (-3) + 3 ×

x

= 2

x

- 6 + 3

= 5

x

+ 12

+ 6

x

<!-- image -->

## EXERCISE 2.2

Expand and simplify each of the following.

(a) 3( x + 2) + 2( x - 3)

(b) 4( x - 2) + 3( x + 5)

(c) 5( x + 3) - 2(2 x + 4)

(d) y (1 - y ) - 4(2 - y )

(e) x (2 x - 3) - 5( x - 3)

(f) m ( m - 2) - 4( m - 6)

## Products of Binomials

## Example 1

Evaluate ( x + 3)( x + 5)

## Method 1

We may use the idea of area of rectangles to illustrate the concept of the product of two algebraic expressions.

## Solution

|    | x    | +5   |
|----|------|------|
| x  | x 2  | +5 x |
| +3 | +3 x | +15  |

$$\begin{array} { c c } ( x + 3 ) ( x + 5 ) = x ^ { 2 } + 5 x + 3 x + 1 5 \\ = x ^ { 2 } + 8 x + 1 5 \end{array}$$

Note: Simplify the like terms. Here 3 x and 5 x are like terms.

## Method 2

Using distributive law to find product of binomials

$$( x + 3 ) ( x + 5 )$$

$$= \dot { x } ( \dot { x } + \dot { 5 } ) + \dot { 3 } ( \dot { x } + \dot { 5 } )$$

= x 2  + 5 x + 3 x + 15

= x 2  + 8 x + 15

## Method 3

<!-- image -->

= x 2  + 5 x + 3 x + 15

= x 2  + 8 x + 15

+ 3 × 4

x

$$( \mathfrak { b } ) \, a ( a - 2 b \, ) - 4 ( b - a \, )$$

$$& ( \mathbf b ) \, a ( a - 2 \mathbf b ) - 4 ( \mathbf b - a ) \\ & \quad = a \times a + a \times ( - 2 \mathbf b ) - 4 \times \mathbf b - 4 \times ( - a ) \\ & \quad = a ^ { 2 } - 2 a \mathbf b - 4 \mathbf b + 4 a$$

## Example 2

Evaluate (2 x + 4)(3 x + 7)

## Method 1

Using the idea of area of rectangles

## Solution

|     | 2 x   | +4    |
|-----|-------|-------|
| 3 x | 6 x 2 | +12 x |
| +7  | +14 x | +28   |

$$\left ( 2 x + 4 \right ) ( 3 x + 7 ) & = 6 x ^ { 2 } + 1 2 x + 1 4 x + 2 8 \\ & = 6 x ^ { 2 } + 2 6 x + 2 8$$

## Method 2

## Method 3

Using distributive law to find product of binomials

$$( 2 x + 4 ) ( 3 x + 7 )$$

$$= \overset {. } { 2 x } ( \overset {. } { 3 x } + \overset {. } { 7 } ) + \overset {. } { 4 } ( \overset {. } { 3 x } + \overset {. } { 7 } )$$

= 6 x 2  + 14 x + 12 x + 28

= 6 x 2  + 26 x + 28

<!-- image -->

## EXERCISE 2.3

1.   Find the product of the following.

- (a)   ( x + 3)( x + 2)

(b)   ( a + 7)( a + 9)

(c)  (2 x + 3)(5 x + 2)

- (d)   ( y + 3)( y + 3)

(e) ( x + y )( x + 3 y )

(f)  (3 x + 5)(3 x + 2)

- (g)   (6 a + 2)( a + 3)

(h)   ( p + 2 q )( q + p )

(i)   (7 + 2 x )(3 + x )

2.   Find the product of the following.

- (a)   ( x - 3)( x - 2)

(b)   ( a - 7)( a - 9)

(c)  (2 x - 3)(5 x - 2)

- (d)   ( y - 3)( y - 3)

(e) ( x - y )( x - 3 y )

(f)  (3 x - 5)(3 x - 2)

- (g)   (6 a - 2)( a - 3)

(h)   ( p - 2 q )( q - p )

(i)   (7 - 2 x )(3 - x )

$$( 2 x + 4 ) ( 3 x + 7 )$$

= 6 x 2  + 14 x + 12 x + 28

= 6 x 2  + 26 x + 28

3.   Find the product of the following.

(a)   (

x

- 3)(

x

+ 2)

(b)

- (d)   ( y + 3)( y - 3)

(

a

+ 7)(

a

- 9)

(e)

(

x

+

y

)(

x

- 3

y

)

(c)   (2 x + 3)(5 x - 2)

(f)   (3 x + 5)(3 x - 2)

- (g)   (6 a + 2)( a - 3)

(h)   ( p + 2 q )( q -p )

(i)

(7 + 2

x

)(3 -

x

)

4.   Formulate and simplify an expression for the area of the following.

In this image, we can see a diagram.

<!-- image -->

## Perfect Squares

A perfect square is an integer or quantity that is multiplied by itself. For example; 4 2 = 16, 11 2 = 121, x 2 = x × x and y 2 = y × y are perfect squares. Note that ( a + b ) 2 =  ( a + b )( a + b ) and ( a -b ) 2 = ( a -b )( a -b ) are also perfect squares.

$$\text{Expand } ( a + b ) ^ { 2 } \\ ( a + b ) ^ { 2 } & = ( a + b ) ( a + b ) \\ & = a ( a + b ) + b ( a + b ) \\ & = a ^ { 2 } + a b + a b + b ^ { 2 } \\ & = a ^ { 2 } + 2 a b + b ^ { 2 } \\ & = a ^ { 2 } + b ^ { 2 } + 2 a b$$

$$\text{Expand } ( a - b ) ^ { 2 } \\ ( a - b ) ^ { 2 } & = ( a - b ) ( a - b ) \\ & = a ( a - b ) - b ( a - b ) \\ & = a ^ { 2 } - a b - a b + b ^ { 2 } \\ & = a ^ { 2 } - 2 a b + b ^ { 2 } \\ & = a ^ { 2 } + b ^ { 2 } - 2 a b$$

<!-- image -->

Therefore,

(

a

+

b

)

2

=

a

(

a

-

b

2

)

=

a

2

2

+

+

b

b

2  + 2

2

ab

- 2

ab

## Common mistake:

(

a

+

b

)

2

≠

a

2

+

b

2

(

a

-

)

b

2

≠

a

2

-

b

2

## Example

Expand  (i) ( x + 3) 2

## Solution

Using the formula:

( a + b ) 2 = a 2 + b 2 + 2 ab replace "a" with ' x " and "b" with '3'

(i) ( x + 3) 2 = ( x ) 2 + (3) 2 + 2( x )(3)

= x 2  + 9 + 6 x

= x 2 + 6 x + 9

$$( \text{ii} ) \ ( 2 x - y ) ^ { 2 }$$

Using the formula:

( a -b ) 2 = a 2 + b 2 -2 ab replace "a" with '2 x " and "b" with ' y ' .

$$\begin{array} { c } ( \text{ii} ) \ ( 2 x - y ) ^ { 2 } = & ( 2 x ) ^ { 2 } + ( y ) ^ { 2 } - 2 ( 2 x ) ( y ) \\ = & 4 x ^ { 2 } + y ^ { 2 } - 4 x y \\ = & 4 x ^ { 2 } - 4 x y + y ^ { 2 } \end{array}$$

= 4 x 2  - 4 xy + y

<!-- image -->

## EXERCISE 2.4

1.  Use the formula to expand the following.

(a) ( x + 4) 2

(b) ( x - 9) 2

(c) ( x - 4) 2

(d) (2 x + 1) 2

(e) ( x + 2 y ) 2

(f ) (2 x - 4) 2

(g) (3 y - 9) 2

(h) ( x - 12) 2

(i) (2 m + n ) 2

2.   Circle the correct answer.

(a) The expansion of ( x + 4) 2 is

A. x 2  + 4 x + 16

B. x 2  + 8 x + 4

C. x 2  + 8 x + 16

D. x 2  + 2 x + 16

(b) The expansion of  (2 x - 5) 2 is

A.  2 x 2  - 20 x +25

B. 4 x 2  - 20 x + 25

C.  4 x 2  - 20 x - 25

D. 4 x 2  + 20 x + 25

## Example

Without direct multiplication, expand the number to find the value of each of the following. (a) 21 2

(b) 699 2

## Solution

(a) 21 2 = (20 + 1) 2

= (20) 2 + (1) 2 + 2(20)(1)

= 400 + 1 + 40

= 441

.

(b) 699 2 = (700 - 1) 2

= (700) 2 +(1) 2 - 2(700)(1)

= 49000 + 1 - 1400

= 488 601

<!-- image -->

Without direct multiplication, use binomial expansion to find the value of each of the following.

(a) (23) 2

(b) (59) 2

(c) (301) 2

(d) (298) 2

(e) (102) 2

(f ) (199) 2

(g) (302) 2

(h) (47) 2

## Example 3

If x 2 + y 2  = 18 and xy = 7, find the value of ( x + y ) 2 .

## Solution

( x + y ) 2 = x 2 + y 2  + 2 xy

= ( x 2 + y 2 ) + 2( xy )

= 18 + 2(7)

= 18 + 14

= 32

<!-- image -->

## EXERCISE 2.6

(a) If x 2 + y 2  = 40 and xy = 8, find the value of ( x + y ) 2 .

(b) If x 2 + y 2  =120 and xy =10, find the value of ( x -y ) 2 .

(c) If x 2 + y 2  = 97.92 and xy = 23.04 find the value of ( x + y ) 2 .

## Difference of two perfect squares

Consider the following expansions

$$\begin{matrix} ( a ) & ( x + 4 ) ( x - 4 ) & & ( b ) & ( 2 x - 3 ) ( 2 x + 3 ) \\ & = x ( x - 4 ) + 4 ( x - 4 ) & & & \\ & = x ^ { 2 } - 4 x + 4 x - 1 6 & & & \\ & = x ^ { 2 } - 1 6 & & & & \\ & = x ^ { 2 } - 1 6 & & & & \\ & = 4 x ^ { 2 } - 9 & & & \end{matrix}$$

## Example1

## Expand

$$( a ) \, ( x - 5 ) ( x + 5 )$$

## Note:

$$\text{row:} ( a - b ) ( a + b ) & = a ( a + b ) - b ( a + b ) \\ & = a ^ { 2 } + \alpha b - \alpha b - b ^ { 2 } \\ & = a ^ { 2 } - b ^ { 2 }$$

Thus ( a -b )( a + b )  = a 2 -b 2 , which is the difference of two perfect squares, a 2 and b 2 .

$$( b ) \, ( 4 b + 3 ) ( 4 b - 3 )$$

## Solution

$$( a ) \ ( x - 5 ) ( x + 5 ) & = x ^ { 2 } - 5 ^ { 2 } \\ & = x ^ { 2 } - 2 5$$

$$( b ) \ ( 4 b + 3 ) ( 4 b - 3 ) & = ( 4 b ) ^ { 2 } - 3 ^ { 2 } \\ & = 1 6 b ^ { 2 } - 9$$

## Example 2

- (i)  Given that a + b = 20 and a 2 -b 2 = 80, find the value of a -b .
- (ii) Given that a + b = 20 and a -b = 4, find the value of a 2 -b 2 .

## Solution

$$\text{Solution} \\ ( i ) \quad a ^ { 2 } - b ^ { 2 } \ & = \ ( a + b ) ( a - b ) \\ 8 0 \ & = \ 2 0 ( a - b ) \\ 2 0 ( a - b ) \ & = \ 8 0 \\ ( a - b ) \ & = \ \frac { 8 0 } { 2 0 } \\ a - b \ & = \ 4$$

$$( \text{ii} ) \ a ^ { 2 } - b ^ { 2 } \ & = \ ( a + b ) ( a - b ) \\ & = \ ( 2 0 ) ( 4 ) \\ & = \ 8 0$$

## Example 3

- (i)   Use the result of ( a + b )( a -b ) = a 2 -b 2  to evaluate 201 × 199.
- (ii) Use the result of ( a + b ) 2 = a 2 + 2 ab + b 2 to evaluate 29 2 + 58 + 1.

## Solution

```
201 × 199 = (200 + 1)(200 - 1) = (200) 2 - (1) 2 = 40 000 - 1 = 39 999 29 2 + 58 + 1 = (29) 2 + 2(29)(1) + (1) 2 = (29 + 1) 2 = 30 2 = 900
```

<!-- image -->

1.  Expand

(a)   ( x + 2)( x - 2)

(e)   ( y - 5)( y + 5)

(b)   ( b + 4)( b - 4)

(f )   (2 p - 3)(2 p + 3)

(c) ( y + 2)( y - 2)

(g) (4 b )(4 + b )

- (i) (4 m + 1)(4 m - 1)
2.  Using the expansion of ( a -b )( a + b ) = a 2 -b 2 , evaluate the following.

$$( \tt a ) \, 2 1 \times 1 9 \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \ \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \	 \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \
 \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \ } \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \quad \, \$$

3.   (i) Given that a + b = 40 and a 2 -b 2 = 120, find the value of a -b .
2. (ii)  Given that a + b = 20 and a -b = 6, find the value of a 2 -b 2 .
4.  Use the result of ( a + b ) 2 = a 2 + 2 ab + b 2 to evaluate the following.

$$( i ) \, 5 0 ^ { 2 } + 1 0 0 + 1 \quad \ \ ( i i ) \, 7 0 ^ { 2 } + 2 8 0 + 4$$

5.  Using the result ( a -b ) 2 = a 2  - 2 ab + b 2 to evaluate

$$( i ) \, 6 0 ^ { 2 } - 1 2 0 + 1, \quad \ ( i i ) \, 2 0 0 ^ { 2 } - 1 2 0 0 + 9.$$

## Factorisation of a difference of two squares

We have seen that ( a -b )( a + b ) = a 2 -b 2 . Now, the reverse process a 2 -b 2 = ( a -b )( a + b ) can be used to factorise expressions that are expressed as the difference of two squares.

## Example 1

Factorise

(i) x 2 - 4 2

## Solution

(i) x 2 - 4 = ( x + 2) ( x - 2)

$$( \text{ii} ) \ ( 2 m ) ^ { 2 } - 5 ^ { 2 }$$

$$( \text{ii} ) \ ( 2 m ) ^ { 2 } - 5 ^ { 2 } = ( 2 m + 5 ) ( 2 m - 5 )$$

(d)   ( c + 5)( c - 5)

(h)   (5 b + 3)(5 b - 3)

## Example 2

$$\text{Factorise} \, \begin{matrix} \text{Factorise} \\ \text{(i) } & a ^ { 2 } - 1 2 1, \end{matrix}$$

## Solution

$$\overbrace { ( i ) } \ \ a ^ { 2 } - 1 2 1 \\ = a ^ { 2 } - 1 1 ^ { 2 } \\ = ( a + 1 1 ) ( a - 1 1 )$$

## Example 3

Factorise and simplify

$$( i ) = ( x + 2 ) ^ { 2 } - 9,$$

## Solution

$$\begin{array} { l l } \text{uuid} \\ ( i ) & ( x + 2 ) ^ { 2 } - 9 \\ & = ( x + 2 ) ^ { 2 } - 3 ^ { 2 } \\ & = ( x + 2 + 3 ) ( x + 2 - 3 ) \\ & = ( x + 5 ) ( x - 1 ) \end{array}$$

## Example 4

Factorise completely.

$$( \mathbf i ) \ 2 x ^ { 2 } - 7 2$$

## Solution

$$\begin{array} { c c } \text{uuid} \\ ( i ) & 2 x ^ { 2 } - 7 2 \\ & = 2 ( x ^ { 2 } - 3 6 ) \\ & = 2 [ ( x ) ^ { 2 } - ( 6 ) ^ { 2 } ] \\ & = 2 ( x + 6 ) ( x - 6 ) \end{array}$$

$$( \text{ii} ) \, 4 x ^ { 2 } - 4 9.$$

$$\begin{matrix} ( \text{ii} ) & 4 x ^ { 2 } - 4 9 \\ & = ( 2 x ) ^ { 2 } - 7 ^ { 2 } \\ & = ( 2 x + 7 ) ( 2 x - 7 ) \end{matrix}$$

$$( \text{ii} ) \, x ^ { 2 } - \frac { 2 5 } { 9 } \.$$

$$( \text{ii} ) \, x ^ { 2 } - \frac { 2 5 } { \circ }$$

$$( \text{ii} ) & \, x ^ { 2 } - \frac { 2 5 } { 9 } \\ = & \, x ^ { 2 } - \left ( \frac { 5 } { 3 } \right ) ^ { 2 } \\ = & \, ( x + \frac { 5 } { 3 } ) \left ( x - \frac { 5 } { 3 } \right )$$

$$( \text{ii} ) \ 4 x ^ { 2 } - 3 6 y ^ { 2 }$$

$$( \text{ii} ) & \ 4 x ^ { 2 } - 3 6 y ^ { 2$$

## Note:

$$\begin{array} { l } 4 x ^ { 2 } - 3 6 y ^ { 2 }$$

Note that this is not complete factorisation.

## Example 5

Using the expansion ( a -b )( a + b )  = a 2 -b 2 , evaluate the following.

(i) 29 2 - 1 2 2

$$\begin{pmatrix} ( \text{ii} ) & \left ( \frac { 3$$

## Solution

$$( i ) \ 2 9 ^ { 2 } - 1 ^ { 2 } & = ( 2 9 +$$

$$\begin{array} {$$

=

<!-- image -->

## EXERCISE 2.8

1.  Factorise each of the following.
2.  Factorise completely each of the following.

| (i)                   | x 2 - 64 (ii) a 2 - 25   | (iii) 49 -        | y 2       | (iv) 100 - k 2   |
|-----------------------|--------------------------|-------------------|-----------|------------------|
| (v) 9 x 2 - 121       | (vi) 144 - 169 b         | (vii) 25 x 2 - 36 | (viii)    | 100 - 49 a 2     |
| (ix) 25 x 2 - y 2 1 4 | (x) x 2 - 1              | (xi) 16 x 2 - 1   | (xii) 5 4 | 81 x 2 - a 2 100 |

$$( i ) \ 2 x ^ { 2 } - 5 0 & & ( i i ) \ \ 3 b ^ { 2 } - 3 0 0 & & ( i i i ) \ \ 1 4 4 - 4 x ^ { 2 }$$

3.  Factorise completely each of the following.
2. (i) ( x + 4) 2 - 25

(ii)   (3 +

x

)

2

- 49

- (iii) x 2 -64 81

(v)  81- ( x + 2) 2

(vi)  64 - ( x + 2) 2

4.  Using the expansion ( a -b )( a + b ) = a 2 -b 2 , evaluate the following.

$$( i ) = 5 9 ^ { 2 } - 1 ^ { 2 } \sum _ { \substack { ( i i ) } } 5. 4 ^ { 2 } - 4. 6 ^ { 2 } \sum _ { \substack { ( i i i ) } } \left ( \frac { 5 } { 9 } \right ) ^ { 2 } - \left ( \frac { 4 } { 9 } \right ) ^ { 2 } \sum _ { \substack { ( i v ) } }$$

2

8

25

(iv) x 2 -100 121

(iv) 19.4 2 - 0.6 2

## Summary

- An expression can  have  one  or  more  terms.  A  term  consists  of  a  coefficient  and/or unknown(s).
- An algebraic expression is an expression which involves only multiplication, addition and subtraction of numbers and unknowns.
- A perfect square is a number that can be expressed as the product of two equal integers .
- ( a + b ) 2 = a 2 + b 2  + 2 ab ( a -b ) 2 = a 2 + b 2  - 2 ab
- Difference of two perfect squares .

( a -b )( a + b ) = a 2 -b 2

- Factorisation of a difference of two squares.
- a 2 -b 2 = ( a -b )( a + b )

## Continuous Assessment

1.  Expand and simplify each of the following.
2. (a)   4( y - 3) - 5( y - 4)
3. (b) x ( x - 2) + 3( x + 5)
4. (c) b ( b + 7) + a ( a - 3)
5. (d) t ( t + 2) - 4 t ( t + 5)
2.  Expand the following.
7. (a) ( b + 4)( b + 6)
8. (b) (7 b )( b + 4)
9. (c) (3 x - 5)(2 x - 4)
10. (d) (7 - 2 x )(2 - 4 x )
3.  Expand the following.

- (a) ( x + 3) 2

- (b)   ( x - 4) 2

- (c) (2 - m ) 2

- (d) (4 a - 5) 2

- (e) (3 a + 1) 2

- (f) (2 m - 3 n ) 2

4.  Without direct multiplication, expand to find the value of each of the following.
2. (a) (28) 2
3. (b) (101) 2
4. (c) (99) 2
5. (d) (303) 2
5.  Using the expansion of ( a -b )( a + b ) = a 2 -b 2 , evaluate 201 × 199.
6.  Factorise each of the following.
8. (a) m 2 - 81
9. (b)  4 x 2 - 25
10. (c)   4 x 2 - 100
11. (d)  2 x 2 - 50
12. (e) 1 x 2
13. (f) 49 a 2 b 2 -a 2
7.  Factorise completely 3 b 2 - 300.
8.  Factorise completely each of the following.
16. (a) ( x + 6) 2  - 49
17. (b) (5 + x ) 2  - 81
18. (c) x 2 -25 64
19. (d) 121- ( x + 7) 2
9.  Using the expansion ( a -b )( a + b ) = a 2 -b 2 , evaluate the following.
21. (a) 99 2  - 1 2
22. (b)   5.3 2 - 4.7 2
23. (c) -( ( 7 11 2 ( ( 4 11 2

## Notes

## QUADRATICS

## Learning Objectives

## By the end of this chapter, you should be able to:

- identify a quadratic expression and a quadratic equation.
- factorise the quadratic expression ax 2 + bx + c .
- solve quadratic equations by factorisation, where a = 1 , including algebraic fractions.
- formulate and solve problems involving quadratic equations.
- solve quadratic equations by factorisation, including algebraic fractions.
- formulate and solve problems involving quadratic equations.

## Quadratics in real life context

## Parabolic antenna are made using quadratics.

In this image we can see a group of people playing basketball. In the background there are trees, poles, a fence, a basketball hoop and a net.

<!-- image -->

In this image, we can see a person holding a ball. We can also see a graph.

<!-- image -->

## CHECK THAT YOU CAN:

- Find the HCF of algebraic terms.
- Factorise numbers.
- Factorise algebraic expressions.
- Solve simple linear equations.

<!-- image -->

## KEY TERMS

- Quadratics
- Expression
- Coefficient
- Constant term
- Factorisation
- Expansion
- Equation

<!-- image -->

## QUADRATIC EXPRESSIONS

## A quadratic expression is an expression of the form

## ax 2 + bx + c .

where a, b and c are real numbers and a ≠ 0 .

a is called the coefficient of x 2 , b is called the coefficient of x and c is the constant term.

In a quadratic expression in x, the highest power of x is 2.

Note: If a = 0, the expression becomes bx + c which is linear as the highest power of x is 1.

The following are examples of quadratics:

$$\text{(a)} \quad x ^ { 2 } + 2 \quad \text{(b)} \quad 3 - 2 x - 4 x ^ { 2 } \quad \text{(c)} \quad 5 x - x ^ { 2 } \quad \text{(d)} \quad ( x + 4 ) ^ { 2 }$$

<!-- image -->

1. Explain why the following expressions are not quadratics.

$$( \tt a ) \left ( \frac { 3 } { x ^ { 2 } } \right ) \right ) \left ( \tt b ) \right ) 5 \right ) \left ( \tt c ) \right ) 2 x + 1 \right ) \right ) \left ( \tt d \right ) \left ( 2 x ^ { 2 } + x ^ { 3 } \right )$$

2. Which of the following are quadratic expressions?

(a) 7 x 2

(b) 3 - 4 x -x 2

(c)

5 + 2

x

+

x

(e) 2 x + 3

(f ) 2 - 5 x 2

(g) -4 - 8 x

(d) 1 - 3 x

(h)

+

x

1

x

2

## Factorisation of quadratic expressions

Consider 10 counters. They can be re-arranged into 2 groups of 5.

The image is a bar chart with 12 bars. Each bar is colored blue and has a specific number of points on it. The number of points on each bar is represented by a red dot. The x-axis is labeled "2" and the y-axis is labeled "5". The bars are arranged in a horizontal line, with the first bar on the left and the last bar on the right. The bars are evenly spaced, and the number of points on each bar is the same.

### Description of the Bar Chart:
1. **Title**: The title of the chart is "20000000000" and is written in red font.
2. **X-axis**: The x-axis is labeled "2" and is marked with a red dot.
3. **Y-axis**: The y-axis is labeled "5" and is marked with a red dot.
4. **Bars**:

<!-- image -->

We now find the factors of an algebraic expression.

2

## Example

2 x + 2

<!-- image -->

In this case, 2 and x + 1 are factors of 2 x + 2 .

The process of writing an expression as the product of its factors is called factorisation.

<!-- image -->

## (1) Factorisation of ax 2 + bx , ( c = 0)

To factorise expressions of the form ax 2 + bx , remove the highest common factor outside.

Thus, ax 2 + bx = x(ax + b)

## Example

## Factorise

$$( a ) \ \ 2 x ^ { 2 } + 3 x$$

## Solution

$$( \mathbf a ) \ & = 2 x ^ { 2 } + 3 x \\ & = 2 \times x \times x + 3 \times x \\ \quad \ \. \quad \.$$

$$\begin{matrix} ( b ) & 3 x ^ { 2 } - 6 x & ( c ) & 1 4 x - 7 x ^ { 2 } \\ & = 3 \times x \times x - 3 \times 2 \times x & = 7 \times 2 \times x - 7 \times x \times x \end{matrix}$$

$$& = x ( 2 x + 3 ) & = 3 x ( x - 2 ) & = 7 x ( 2 - x )$$

<!-- image -->

$$( b ) \ \ 3 x ^ { 2 } - 6 x \ \ \ \ ( c ) \ \ 1 4 x - 7 x ^ { 2 }$$

$$\times x \quad \begin{matrix} ( c ) & 1 4 x - 7 x ^ { 2 } \\ & = 7 \times 2 \times x - 7 \times x \times x \\ & = 7 x ( 2 - x ) \end{matrix}$$

<!-- image -->

Factorise

(a) x 2 + 5 x

(b) x 2 - 6 x

(c) 5 x - 13 x 2

(d) 2 x 2 + 8 x

(e) 3 x 2 - 12 x

(f ) -6 x 2 + 3 x

(g) -4 - 10 x 2

(h) 27 x 2 - 18 x

## (2)  Factorisation of x 2 -k 2

In chapter 1, you learnt about the difference of two squares.

That is,

$$x ^ { 2 } - y ^ { 2 } = ( x + y ) \, ( x - y ).$$

## Note:

x 2 + k 2 cannot be factorised.

(b) 49 x 2 (c) 2 x 2 - 18

Hence,

$$\left | \, x ^ { 2 } - k ^ { 2 } = \left ( x + k \right ) \left ( x - k \right ) \, \right |$$

## Example

Factorise

(a) x 2 - 25

## Solution

(a) x 2 - 25 (b) 49 x 2 ( c) 2 x 2 - 18 = x 2 - 5 2 = 7 2 -x 2 = 2( x 2 - 9) = ( x + 5)( x - 5) = (7 + x )(7 x ) = 2( x + 3)( x - 3)

<!-- image -->

Factorise

(a) x 2 - 49

(b) y 2 - 1

(c) 36 - x 2

(d)

y

2

-

(e) x 2 - 16 25

(f ) 4 x 2 - 81

(g) 2 x 2 - 50

(h) 27 - 3 x 2

(i) x 2 - 2 1 4

(j) ( x + 2) 2 - 36

(k) (2 x - 3) 2 - 1

(l) 4 x 2 - 100

1

9

## (3) Factorisation  of x 2 + bx + c, ( a = 1)

Recall that

$$\mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { n } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \mathbb { N } \\ ( x + 2 ) ( x + 3 ) = x ( x + 3 ) + 2 ( x + 3 )$$

$$( x + 2 ) ( x + 3 ) & = x ( x + 3 ) + 2 ( x + 3 ) \\ & = x ^ { 2 } + 3 x + 2 x + 6 \\ & = x ^ { 2 } + 5 x + 6$$

Thus, the factorisation of x 2 + 5 x + 6 is ( x + 2)( x + 3).

## Note:

-   The sum of 2 and 3 is 5 (the coefficient of x , that is b ).
-   The product of 2 and 3 is 6 (the constant term, that is c ).

Thus, to factorise x 2 + bx + c , find two factors of c whose sum is b .

If the factors are p and q then,

$$x ^ { 2 } + b x + c = ( x + p ) ( x + q ).$$

## Example

## Factorise

(a) x 2 + 9 x + 20

## Solution

(a) x 2 + 9 x + 20

sum , b = 9, product , c = 20

Find two factors of 20 whose sum is 9 .

That is, find p and q such that p × q = 20 and p + q = 9 .

The possible values of p and the corresponding values of q are listed below:

|         |   Product = 20 |   Product = 20 |   Sum=9 | Sum=9   |
|---------|----------------|----------------|---------|---------|
| Factors |              1 |             20 |      21 | ✗       |
|         |              2 |             10 |      12 | ✗       |
|         |              4 |              5 |       9 | ✔       |

The required numbers are 4 and 5, thus

$$x ^ { 2 } + 9 x + 2 0 = ( x + 4 ) ( x + 5 )$$

20 = 1 × 20

= 2 × 10

= 4 × 5

$$( b ) \ x ^ { 2 } - 7 x + 1 0$$

Note:

sum, b = p + q product, c = p × q

- (b) x 2 - 7 x + 10

b = -7, c = 10

Find two factors of 10 whose sum is -7.

|         |   Product = 10 |   Product = 10 |   Sum=-7 | Sum=-7   |
|---------|----------------|----------------|----------|----------|
| Factors |              1 |             10 |       11 | ✗        |
| Factors |             -1 |            -10 |      -11 | ✗        |
| Factors |              2 |              5 |        7 | ✗        |
| Factors |             -2 |             -5 |       -7 | ✔        |

The numbers are -2 and -5 , thus x 2 - 7 x + 10 = ( x - 2) ( x - 5).

<!-- image -->

## EXERCISE 3.4

1. Factorise

- (a) x 2 + 4 x + 3

(b) x 2 + 8 x + 15

(c) x 2 + 10 x + 16

(d) x 2 + 10 x + 21

(e) x 2 + 12 x + 35

(f ) x 2 + 14 x + 24

2. Factorise

(a) x 2 - 7 x + 12

(b) x 2 - 13 x + 30

(c) x 2 - 2 x + 1

- (d) x 2 - 9 x + 8

(e) x 2 - 14 x + 13

(f ) x 2 - 15 x + 36

## Example

Factorise

(a) x 2 + x - 6

(b) x 2 - 4 x - 21

## Solution

- (a) x 2 + x - 6

b = 1, c = -6

Find two factors of -6 whose sum is 1

.

|         |   Product = -6 |   Product = -6 |   Sum=1 | Sum=1   |
|---------|----------------|----------------|---------|---------|
| Factors |              1 |             -6 |      -5 | ✗       |
| Factors |             -1 |              6 |       5 | ✗       |
| Factors |              2 |             -3 |      -1 | ✗       |
| Factors |             -2 |              3 |       1 | ✔       |

The numbers are -2 and 3 ,  thus x 2 + x - 6 = ( x - 2)( x + 3).

- (b) x 2 - 4 x - 21

b = - 4 , c = -21

Find two factors of -21 whose sum is - 4 .

|         |   Product = -21 |   Product = -21 |   Sum=-4 | Sum=-4   |
|---------|-----------------|-----------------|----------|----------|
| Factors |               1 |             -21 |      -20 | ✗        |
| Factors |              -1 |              21 |       20 | ✗        |
| Factors |              -3 |               7 |        4 | ✗        |
| Factors |               3 |              -7 |       -4 | ✔        |

The numbers are 3 and -7 , thus x 2 - 4 x - 21 = ( x + 3)( x -7) .

<!-- image -->

## EXERCISE 3.5

## 1. Factorise

- (a) x 2 + 4 x - 5

(b) x 2 + x - 20

(c) x 2 + 3 x - 18

(d) x 2 + 2 x - 15

(e) x 2 + 6 x - 27

(f ) x 2 + 6 x - 16

## 2. Factorise

- (a) x 2 - 8 x - 9

(b) x 2 - 3 x - 10

(c) x 2 - x - 12

(d) x 2 - 14 x - 15

(e) x 2 - 8 x - 20

(f ) x 2  -2 x - 24

## 3. Factorise

- (a) x 2 + 12 x + 36

(b) 4 x 2 - 25

(c) x 2 - 5 x + 6

- (d) 12 x - 3 x 2

(e) x 2 + 7 x - 60

(f ) x 2 - 17 x - 60

## (4)  Complete factorisation of ax 2 + bx + c

## Example

Factorise completely

(a) 2 x 2 + 6 x + 4 ,

## Solution

- (a) 2 x 2 + 6 x + 4

= 2( x 2 + 3 x + 2) [ HCF = 2]

= 2( x + 1)( x + 2)

(b) 3 x 2 - 15 x + 18.

(b) 3 x 2 - 15 x + 18

= 3( x 2 - 5 x + 6) [HCF = 3]

= 3( x - 2)( x - 3)

<!-- image -->

1. Factorise completely.

- (a) 2 x 2 + 10 x + 12

(b) 3 x 2 - 18 x + 24

(c) 5 x 2 + 40 x - 45

- (d) 4 x 2 - 12 x - 40

(e) 6 x 2 - 42 x + 72

(f ) 7 x 2 - 14 x - 105

- (g) 3 x 2 - 3 x - 60

- (h) 4 x 2 + 4 x - 120

(i) 5 x 2 - 20 x - 60

## QUADRATIC EQUATIONS

A quadratic equation in x is an equation of the form ax 2 + bx + c = 0 , where a ≠ 0.

Examples: x 2 + 2 x + 1 = 0,      2 x - 5 x 2 = 0, x 2 = 4 x - 3.

A quadratic equation generally has two solutions.

## Solutions of quadratic equations

The null factor law states that when the product of two numbers is zero, then, at least one of them must be zero.

That is,

$$\text{if} \ \ m \times n = 0,$$

then, either m = 0 or n = 0.

This law is useful to solve quadratic equations in which the RHS is zero and when the expression on the LHS can be factorised.

## Example

Solve the quadratic equations

$$( \mathbf a ) \ x ( x - 2 ) = 0$$

## Solution

(a) x ( x - 2) = 0

either x = 0 or x - 2 = 0

x = 2

$$( b ) \ ( x - 2 ) ( x + 3 ) = 0$$

$$( b ) \ ( x - 2 ) ( x +$$

$$( b ) & \quad ( x - 2 ) ( x + 3 ) = 0 \\ & \quad \text{either} \, x - 2 = 0 \quad \text{or} \, x + 3 = 0 \\ & \quad \text{$x = 2$}$$

<!-- image -->

Solve the following quadratic equations.

- (a) x ( x - 5) = 0
- (b) ( x - 4)( x + 7) = 0
- (d) 2 x ( x - 3) = 0
- (g) (3 x - 1)( x - 7) = 0
- (e) 3 x (2 x - 1) = 0
- (h) (4 x - 5)(5 x - 8) = 0

## Example

Solve the following quadratic equations.

$$( \mathbf a ) \ \ x ^ { 2 } \, -$$

- 4 = 0

## Solution

```
(a) x 2 - 4 = 0 ( x - 2)( x + 2) = 0 either x - 2 = 0 or x + 2 = 0 x = 2 x = -2
```

## Alternatively,

2

x

- 4

= 0

2

x

x

x

= 4

= ±

4

= ±2

<!-- image -->

## EXERCISE 3.8

Solve the following quadratic equations.

```
(a) x 2 - 49 = 0 (b) x 2 + 6 x + 9 = 0 (c) x 2 - 10 x + 9 = 0 (d) x 2 - 8 x + 15 = 0 (e) x 2 + 5 x - 6 = 0 (f ) x 2 -x - 12 = 0 (g) x 2 - 2 x - 15 = 0 (h) x 2 + 4 x - 21 = 0 (i) x 2 - 2 x - 24 = 0
```

## Reducing quadratic equations to the form ax 2 + bx + c = 0

In some quadratic equations, the right hand side (RHS) may not be zero.

These equations have to be reduced to the form ax 2 + bx + c = 0 , before they can be solved.

Note: The RHS must always  be  zero  to  use the null factor law.

- (c) ( x + 1)( x + 2) = 0
- (f ) (2 x + 1)(3 x - 5) = 0
- (i) (5 x - 2)(3 x + 7) = 0

$$( b ) \quad x ^ { 2 } - 5 x + 6 = 0$$

$$( b ) & \quad x ^ { 2 } - 5 x + 6 = 0 \\ & \quad ( x - 2 ) ( x - 3 ) = 0 \\ & \quad \text{either } x - 2 = 0 \text{ or } x - 3 = 0 \\ & \quad x = 2 \text{ \quad } x = 3$$

## Example

Solve the following quadratic equations.

$$( \mathbf a ) \ x ^ { 2 } + 3 x = 1 0 \quad \ \ ( \mathbf b ) \ x ^ { 2 } + 7 x + 1 5 = 5$$

## Solution

(a)

x

2

+ 3

2

x

+ 3

x

= 10

x

- 10

= 0

(

x

+ 5)(

x

- 2) = 0

either x = -5

or x = 2

<!-- image -->

## EXERCISE 3.9

Solve the following quadratic equations.

(a) x 2 - 5 x = 14

(b) x 2 + x = 20

(d)

x

= 2 +

(e)

x

+ 1 =

$$( c ) \ \ x - 5 = \frac { 6 } { x }$$

(c)

x

- 5  =

6

x

By cross multiplication

x

(

x

- 5)

= 6

2

x

- 5

x

- 6

= 0

( x + 1)( x - 6) = 0

either x = -1

or x = 6

(c) x 2 = x + 12

$$( f ) \ \ x - 6 = \frac { - 5 } { x }$$

8

x

12

x

(g) x 2 + 10 x + 40 = 19

$$( h ) \ \frac { x ^ { 2 } + 1 4 } { x } = 9$$

$$( \mathbf i ) \ \ x = \frac { 2 5 } { x }$$

## Solving problems involving quadratic equations

In this section you will learn how to formulate and solve problems involving quadratic equations.

## Example 1

The sum of a positive number and its square is 20. Find the number.

## Solution

Let the number be x , so, its square is x 2 . Now the sum = 20 ∴ x 2 + x = 20 x 2 + x - 20 = 0 ( x - 4)( x + 5) = 0 either x = 4 or x = -5

As x is positive, the number is 4 .

(b)

2

x

x

2

x

+ 7

+ 7

2

+ 7

(

x

x

x

+ 15

= 5

+ 15 - 5   = 0

x

+ 10

= 0

+ 5)(

x

+ 2)

= 0

either x = -5

or x = -2

## Example 2

The length of a rectangle is 3 cm longer than its width. Given that its area is  40 cm 2 , find the length and the width of the rectangle.

## Solution

Let the width of the rectangle be x cm.

The length is thus x + 3 cm.

Area of rectangle = length × width

40 = ( x + 3) × x

40 = x 2 + 3 x

x

2 + 3 x - 40 = 0

(

x - 5)( x + 8) = 0 [factorise the LHS]

either x = 5 or x = -8

Length

= x + 3

= 5 + 3

= 8 cm

Width

= x

= 5 cm

<!-- image -->

Note: x ≠ -8 as the width cannot be negative.

## Example 3

The base of a right angled triangle is ( x + 2) cm and its height is ( x + 3) cm.

Given that its area is

6 cm 2 , calculate the base and the height of the triangle.

## Solution

Area of triangle =     × base × height 1 2

$$6 \, = \, \frac { 1 } { 2 } ( x + 2 ) \, ( x + 3 )$$

12  = x 2 + 5 x + 6

x 2 + 5 x + 6 - 12  = 0

x 2 + 5 x - 6  = 0

( x - 1)( x + 6)  = 0

either x = 1 or x = -6

Length of the base = x + 2

= 1 + 2

= 3 cm.

Height of the triangle

= x + 3

= 1 + 3

= 4 cm.

<!-- image -->

## Note:

x ≠ -6 as dimensions are positive.

<!-- image -->

## EXERCISE 3.10

1. The product of two consecutive positive numbers is 42. Find the numbers.
2. The product of two consecutive even numbers is 24. Find the numbers.
3. The sum of the squares of two consecutive positive numbers is 61. Find the numbers.
4. The difference between the square of a positive number and the number itself is 20. Find the number.
5. The length of a rectangle is 3 times its width. Given that its area is 27 cm 2 , find the length and the width of the rectangle.
6. A rectangle has length ( x + 3) cm and width ( x - 2) . Given that its area is 50 cm 2 , find the dimensions of the rectangle.
7. A right angled triangle has base ( x + 3) cm and height ( x + 8) cm. Given that its area is 42 cm 2 , calculate the length of the base and the height of the triangle.
8. The sides of a right angled triangle are of lengths x, ( x + 7) and, ( x + 8) cm, where x is a positive integer. Show that x 2 - 2 x - 15 = 0 . Hence find the lengths of the sides of the triangle.
9. The sum of the areas of the square and the rectangle shown in the diagram is 54 cm 2 . Show that 2 x 2 + 8 x - 42 = 0 . Hence find the dimensions of the square and the rectangle.
10. The area of a right angled triangle is 24 cm 2 . Given that its base is (2 x ) cm and its height is (4 x ) cm. Find the value of x and hence the length of the base and the height of the triangle.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Summary

- A quadratic expression is an expression of the form ax 2 + bx + c .

where a, b and c are real numbers and a ≠ 0 .

- Factorisation of ax 2 + bx , ( c = 0)

ax 2 + bx = x(ax + b)

- Factorisation of x 2 -k 2

x 2 -k 2 = ( x + k ) ( x -k )

- Factorisation  of x 2 + bx + c , ( a = 1)

To factorise x 2 + bx + c , find two factors of c whose sum is b .

If the factors are p and q then, x 2 + bx + c = ( x + p )( x + q ).

## Continuous Assessment

1. Factorise the following quadratic expressions.

- (a) x 2 + 5 x

- (b) 3 x 2 - 18 x

- (c) x 2 - 49

- (d) 2 x 2 - 50

(e) x 2 + 7 x + 6

(f ) x 2 - 8 x + 15

- (g) x 2 - 4 x - 12

(h) x 2 + x - 20

(i) x 2 - 5 x - 14

- (a) x 2 - 3 x = 0

(b) x 2 = 25

(c) 2 x 2 - 18 = 0

- (d) x 2 + 10 x + 21 = 0 (e) x 2 - 5 x + 4 = 0

(f ) x 2 - 7 x = 30

- (g) x 2 = 8 x - 15

(h)

x

+ 5 =

- (i) = 1 x - 3 x 10

14

x

2. Solve the following quadratic equations.

3. The sum of a positive number and its square is 30. Find the number.
4. A number and its square add up to 42. Find two possible values of the number.
5. When a number is subtracted from its square, the result is 20. Find two possible values that the number can take.
6. The area of a rectangle is 40 cm 2 . If its length is 6 cm longer than its width, find the perimeter of the rectangle.
7. The sides of a right-angled triangle are x , ( x - 7) and 13 cm as shown in the diagram. Using Pythagoras theorem, find a possible value of x and hence find the area of the triangle.
8. The sum of the areas of the two squares shown in the diagram is 52 cm 2 . 2
7. Show that x + 2 x - 24 = 0 . By solving the equation,
8. find the length of the sides of each square.
9. The length of a rectangle is 3 times the length of the sides of a square. Given that they have the same width and the sum of their  areas is 100 cm 2 , find the dimensions of the square and of the rectangle

<!-- image -->

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

## ALGEBRAIC MANIPULATION

<!-- image -->

## Learning Objectives

## By the end of this chapter, you should be able to:

- evaluate an unknown quantity in a given formula/equation.
- change the subject of formula.

## Formulae in real life

<!-- image -->

A commonly used formula is   Savings = Income - Expenditure

<!-- image -->

<!-- image -->

Footprints from prehistoric  human civilisations have been found preserved in sand or volcanic ash. From these tracks it is possible to measure the  foot  length.  This  measurement can be used to estimate the height of the person using the formula height = 7 × length of foot.

## Formula

A  formula  is  a  relationship  between two  or  more variables that contains the mathematical  operators + , - , × , ÷ and the 'equal' (=) sign.

For example, in Grade 7 you learnt that

Area of rectangle = length × breadth.

Thus,  the  formula  for  the  area, A ,  of  a  rectangle  with length l and breadth b is given by A = lb .

Games like 'Angry Birds' would not have existed without algebraic formulae.

Note: The plural of formula is formulae.

## CHECK THAT YOU CAN:

- Perform the four operations, (+, - , × , ÷).
- Substitute  values in algebraic expressions.
- Solve linear equations.

<!-- image -->

## KEY TERMS

- Formula
- Algebraic expression
- Equation
- Additive inverse
- Multiplicative inverse
- Distributive law
- Subject of formula
- Factorisation
- Square root
- Cube root
- Powers

<!-- image -->

## STOP AND THINK

What is  the  difference  between  an expression ,  an equation and  a formula ?

<!-- image -->

l

<!-- image -->

Which of the following is an example of a formula?

(a) C = 2 πr

(b) ax + by

(d) P = 2 l + 2 b

$$( \mathfrak { c } ) \, A & = \pi r ^ { 2 } \\ ( \mathfrak { f } ) \, A & = \frac { 1 } { 2 } ( a + b ) \, h$$

(e) x = 3 - 2 x

## Evaluate an unknown quantity in a given formula

Now, we know that the area, A , of the rectangle is given by A = lb

Suppose, we are given the values l = 7 and b = 4. Then, substituting these values into the formula, we have A = 7 × 4 A = 28.

## Example

A formula states that

$$y = 2 x + k$$

Find the value of

(a) y when x = 4 and k = 2,

(b) k when y = 5 and x = 3,

(c) x when y = 8 and k = -2.

## Solution

## Solution

$$( a ) \ y & = 2 ( 4 ) + 2 \\ & = 8 + 2 \\ & = 1 0$$

## Solution

$$\begin{matrix} & Solution \\ ( c ) & & 8 = 2 x + (- 2 ) \\ & & 8 = 2 x - 2 \\ & & 4 = 2 x - 2 + 2 \\ & & 1 0 = 2 x \\ & 1 & \times 1 0 = \frac { 1 } { 2 } \times 2 x \\ & & 5 = x \\ & & x = 5 \end{matrix}$$

$$\text{solution} ( b ) \quad 5 & = 2 ( 3 ) + k \\ 5 & = 6 + k \\ 5 - 6 & = 6 + k - 6 \\ - 1 & = k \\ k & = - 1$$

Note: To evaluate an unknown quantity,  we  have  to  substitute given values into the formula.

<!-- image -->

l

<!-- image -->

Use  of  inverses  when  solving linear equations.

The additive inverse of " a " is

"-a ". i.e.  the additive inverse of "2" is "-2" and that of "-2" is "2".

$$e. g. Solve x + 2 = 5 \\ x + 2 - 2 = 5 - 2 \\ x = 3$$

The  multiplicative  inverse  of " a " is "      " . 1

$$a$$

e.g. Solve 3 x = 8

× 3

<!-- image -->

<!-- image -->

1.  If p = 7, q = -6, r = 10 and s = -4, calculate:

(a) p + q

(b) p -s

(c) r -q

(e) p -r

(g) pq + r

(i) 3 r + 6 q

(d) q 2 + s 2

(f) r + s 2

(h) r -qs

(j) 5 q - 3 p

(k) 3 s -r

(l) 4 q + 8 s

2.  Circle the correct answer in each of the following.

Given a = 2, b = 4 and c = -3.

- (a) What is the value of y if y = 2 a + b ?

$$\text{A. 2} 6 \, \text{B. 8} \, \text{B. 4} \, \text{C. 1} 6$$

- (b)   What is the value of y, if y = c 2 + b ?

A. -5

B. -2

C. -28

- (c) What is the value of y if y =        -c ? a 3

$$\text{(c)} & \text{What is the value of $y$ if $y = \frac{-}{2}-c\?$} \\ & \text{A. 14.5} & \text{B. 7} & \text{C. 0}$$

3.  The volume, V , of the cuboid having length ' l ' , breadth ' b ' and height ' h ' is given by V = lbh . Find the value of (a) V when l = 10, b = 8 and h = 4. (b) h when V = 144, l = 6 and b = 4.
4.  The diagram shows a circle having radius r . The formula for the area, A , of the circle is given by A = πr 2 .

Taking π =        , calculate the value of 22 7

- (a) A when r = 14.
- (b) r when A = 1 386.
5.  A formula states that v = u + at . Find the value of
- (a) v when u = 5, a = 3 and t = 6.
- (b) u when v = 15, a = 2 and t = 4.
- (c) t when v = 25, u = 5 and a = 4.

<!-- image -->

$$a b = a \times b \\ a ^ { n } = \underbrace { a \times a \times a \dots \times a }$$

n times

$$\begin{smallmatrix} n \, u m e \colon \\ \text{e.g.} \\ (3) ^ { 2 } = 3 \times 3 \\ \therefore (3) ^ { 2 } = 9 \end{smallmatrix}$$

$$\begin{array} { c c c } & ( - 2 ) ^ { 3 } = - 2 \times - 2 \times - 2 \\ &.. & ( - 2 ) ^ { 3 } = - 8 \end{array}$$

When substituting values in expressions you are advised to use brackets.

$$\begin{matrix} \text{e.g. if } a = 2, b = - 3 \text{ and } c = 4 \\ a b c = ( 2 ) ( - 3 ) ( 4 ) \\ a b c = - 2 4 \end{matrix}$$

D. 88

D. 13

D. 6

<!-- image -->

<!-- image -->

6.  If a = 4, b = -5 and c = 8, evaluate each of the following.

$$\text{(a)} \ 3 b c \quad \text{(b)} \ a b c \quad \text{(c)} \ \frac { 1 5 } { \pi }$$

$$( \mathbf f ) \ \underline { c + a ^ { 2 } + b ^ { 2 } }$$

$$\left ( \mathbf g \right ) b ^ { 3 } + a ^ { 2 } \ \left ( \mathbf h \right ) \ \underline { 8 a b ^ { 2 } } \quad \left ( \mathbf i \right ) \ \underline { 2 b ^ { 2 } c }$$

$$&, b = - 5 \text{ and } c = 8, \text{ evaluate each of the following.} \\ & \quad ( b ) \ a b c \quad \text{ (c) } \ \frac { 1 5 } { a b } \quad \text{ (d) } \ 3 b ^ { 3 } - \frac { c } { a } \quad \text{ (e) } a b + b c \quad \text{ (f) } \ \frac { c + a ^ { 2 } + b ^ { 2 } } { 7 } \\ & \cdot a ^ { 2 } \quad ( h ) \ \frac { 8 a b ^ { 2 } } { c } \quad \text{ (i) } \ \frac { 2 b ^ { 2 } c } { a }$$

7.   According to ' Leonardo da Vinci ' , the length of a man's forearm, f cm, and his height, h cm, are approximately related by the formula h = 3 f + 90.
2. (a)   Part of the skeleton of a man is found and the forearm is 25 cm long. Use the formula to estimate the man's height.
3. (b)  A man's height is 172 cm. Use the formula to estimate the length of his forearm.
4. (c) Kiran is 2 years old and he is 78 cm tall. Use the formula to find the length of his forearm and state why this value is impossible.

In this image, we can see a human skeleton. There is a text at the top of the image.

<!-- image -->

## Deriving simple formulae

## Example 1

(a)(i) The cost of one apple is Rs 5.

Copy and complete the following table.

| Number of apples bought   | Total cost, RsC   |
|---------------------------|-------------------|
| 4                         | C = 4 × 5 C = 20  |
| 10                        | C = C = 50        |
| m                         | C = m × C =       |

## Solution

| Number of apples bought   | Total cost, RsC   |
|---------------------------|-------------------|
| 4                         | C = 4 × 5 C = 20  |
| 10                        | C = 10 × 5 C = 50 |
| m                         | C = m × 5 C = 5 m |

- (ii) The cost of one apple is Rs 5 and that of an orange is Rs 10. Copy and complete the following table.

## Solution

| Number of apples bought   | Number of oranges bought   | Total cost, Rs C               |
|---------------------------|----------------------------|--------------------------------|
| 3                         | 1                          | C =(3 × 5)+(1 × 10) =15+10 =25 |
| 4                         | 7                          |                                |
| m                         | n                          |                                |

| Number of apples bought   | Number of oranges bought   | Total cost, Rs C                   |
|---------------------------|----------------------------|------------------------------------|
| 3                         | 1                          | C =(3 × 5)+(1 × 10) =15+10 =25     |
| 4                         | 7                          | C =(4 × 5)+(7 × 10) =20+70 =90     |
| m                         | n                          | C =( m × 5)+( n × 10) = 5 m + 10 n |

- (b) A pizza delivery boy is paid Rs 200 plus Rs 5 for every pizza he delivers.
- (i) Write down a formula for the amount " A " he received for delivering n pizzas.
- (ii) Find the amount he will receive if he delivers 10 pizzas.
- (iii) He received Rs 375 on a particular day. How many pizzas did he deliver?

## Solution

- (i) A = 200 + 5 n

## Solution

## Solution

- (ii) (iii) A = 200 + 5 (10)

A = 200 + 50

A = 250

He will receive Rs 250.

375  =  200 + 5 n

375 - 200

=  200 + 5

n

1 75   =  5

n

1

× 175

=       × 5

1

5

n

5

n =  35

He delivered 35 pizzas.

- 200

## Example 2

A triangle has sides of length x , x + 1 and x + 3, as shown in the diagram.

<!-- image -->

- (a) Write down a formula for the perimeter, P , of the triangle.

(b) Calculate the perimeter when x = 5.

(c) Calculate x when the perimeter is 13.

## Solution

$$P & = x + ( x + 1 ) + ( x + 3 ) \\ & = 3 x + 4$$

$$\begin{array} { c c c c c c c c } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & && & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & - & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & _ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &	 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &   & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & . & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & 
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &.
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  ; & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &, & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & ; & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &$$

<!-- image -->

## EXERCISE 4.2

1. In each of the following, circle the correct answer.
2. (a)  Given  that  the  cost  of  one  article  is Rs 150.  The  formula  for  the  total  cost, Rs T , of n articles is given by

A. T = 150 + n

B.

T

=

C. T = 150 n

150

n

$$D. \ T = \frac { n } { 1 5 0 }$$

- (b) Given the cost of one lemon is Rs x and that of one banana is Rs y . The formula for the total cost, Rs T , of 10 lemons and 15 bananas is given by

A. T = 25 xy

$$\mathbf B. \ T = 2 5 ( x + y ) \quad \ \ C. \ T = \frac { 1 0 } { x } + \frac { 1 5 } { y } \quad \ \ D. \ T = 1 0 x + 1 5 y$$

- (c) The diagram shows a triangle.

The formula for the perimeter, P , of the triangle is given by

<!-- image -->

A. P = 3

B. P = x 3 + 3

C. P = 3 x + 3

- (d) The diagram shows a parallelogram. The formula for the perimeter, P , of the parallelogram is given by

A. P = x (2 x

$$x ( 2 x + 1 ) \quad \ \ B. \ P = 6 x + 2$$

D. P = 4 x

<!-- image -->

C. P = 4 x 4 + 2

D. P = 3 x + 1

2. The diagram shows a trapezium ABCD. (a) Write down a formula for the perimeter, P , of the trapezium.
2. (b) Calculate the perimeter when x = 3.
3. 3.

<!-- image -->

x

- (c) Determine the value of x if the perimeter is 39.

as follows:

- A function diagram produces algebraic expressions. For example, the expression 3 x + 5 can be obtained from x An unknown number is multiplied by 3 and 5 is added to the result.

<!-- image -->

Copy the following function diagrams and fill in the missing parts. Write a sentence to explain the procedure. (a) Input

In this image, we can see a diagram.

<!-- image -->

4. Divya thinks of a number. She adds 10 to the number. She then divides by 4. Her answer is 20. What number did Divya think of?

[ Hint: Let the number be x and you may use a function diagram. ]

5. A taxi firm charges a fixed amount of Rs 200 plus Rs 6 per km travelled. (a) Write down a formula for the cost, Rs C , for travelling d km.
2. (b) Calculate the cost of travelling 20.5 km.
3. (c) The charge for a journey is Rs 504.50. What is the distance travelled?

## Changing the subject of formula

The subject of formula is the variable which is expressed in terms of the other variables involved in the formula. Some examples are illustrated in the table below.

| Examples                                                                           | Formula     | Subject   |
|------------------------------------------------------------------------------------|-------------|-----------|
| S = Selling price B = Buying price S > B P = Profit                                | P = S - B   | P         |
| I = Simple interest R = Rate of interest per annum T = Time in years P = Principal | I = PRT 100 | I         |
| A = Area W = Width L = Length                                                      | A = LW      | A         |

Note: A  formula  is  written  so  that  a  single variable, the subject of the formula is on the left hand side (L.H.S)  and  everything  else  goes  on the right hand side (R.H.S) of the formula.

<!-- image -->

## Activity 2

In each of the following, state the variable which is the subject of the formula.

(a) A = bh 1 2

(b) y = mx + c

(c) A = πr 2

(d) V = at + u

(e) x = p + qx

$$( f ) \ a = \frac { 1 } { b } + c$$

## Example

Given the formula A = P + S , calculate

(a) A when P = 1000 and S = 200

(b) P when A = 2000 and S = 500

(c) S when A = 1750 and P = 1425

## Solution

- A = P + S (a)

A = 1000 + 200

(Substituting values into formula)

A = 1200

In this image, we can see a graph.

<!-- image -->

Solution A = P + S 1750 =  1425 + S (Substituting values into formula) 1750 - 1425   =  1425 + S - 1425 S =  1750 - 1425 S =  325 Note: S is not the subject of formula. Now S = A -P. (c)

## Observe

## Note:

To obtain  the desired result from a formula we can rearrange the formula to make another variable the new subject of formula.

The process of rearranging the formula is called transposition or changing the subject of formula.

(d) p + 2 x = q + r

## Solution

p + 2 x -p = q + r -p

$$\mu _ { 0 } \stackrel { \mu } { 2 } \times \stackrel { \mu } { 2 x } = \stackrel { \mu } { 2 } \times ( q + r - p )$$

$$x = \frac { q + r - p } { 2 }$$

using additive inverse followed by multiplicative inverse

From the formula A = P + S we have:

| Subject of formula   | Formula   |
|----------------------|-----------|
| A                    | A = P + S |
| P                    | P = A - S |
| S                    | S = A - p |

## Changing the subject of formula

## Example

In each of the following, make x the subject of formula.

(a) x + p = q

(b) p + x = q + r

(c) px = q + r

## Solution

x

+

p

-

p

=

q

-

p

Solution

p

+

x

-

p

=

x

=

q

-

p

x

=

<!-- image -->

using additive inverse

q

+

q

+

r

r

-

-

p

p

Solution

$$\vdots \frac { - \cdots \cdots \cdots } { p } \times p x & = \frac { 1 } { p } \times ( q + r ) \quad \vdots p \\ \vdots \frac { p } { p } \quad \vdots \cdots \cdots \\ \vdots \quad \begin{array} { c c c } - \cdots \cdots \cdots \\ p } \end{array}$$

<!-- image -->

using multiplicative inverse

<!-- image -->

## EXERCISE 4.3

1. In each of the following make x the subject of formula.

(a) x + 5 = a

(b) x - 4 = b

(c) x + c = a

(d) x - d = b

(e) a + x = c

(f) x + 5 y = z

(g) x - 3 s = 2 t

(h) b - x = d

(i) 8 l - x = m

(j) k = m - x

(k) k = x + f

(l) y = x - 3 z

Note: When changing the subject of  formula,  the  rules  are  the  same as  when  we  solve  equations  with the only exception being, we end up with another formula rather than a solution.

2. Copy and complete the following in order to make x the subject of formula.

3. In each of the following, make r the subject of formula.

(a) 2 r = a

(b) dr = - a

(c) mr + 4 = y

(d) br - c = a

(e) e + 4 r = 12

(f) p + 5 = qr

(g) cr + mn = k

(h) - r = k

(i) b - 2 r = n

(j) 2 a - 5 r = y

(k) d = k - 3 r

(l) k = 5 r - b

- (a) ax + 1 =   2 c

ax + 1 -

=

2 c -

=

2 c - 1

- × ax 1

=

× (2 c - 1)

=

a

2 c -1

a

(b)

b + cx = m

b

+ c

x -

=

m -

cx = m - b

× (cx)

=

× (m - b)

x

=

m

-

b

## Formulae involving brackets and fractions

## Example 1

Make x the subject of formula given p ( x + q ) = r .

## Method 1: Expand and rearrange

p ( x + q )   = r (Expand the L.H.S using the distributive law)

px + pq = r px + pq -pq = r -pq (Add the additive inverse of " pq " i.e. "pq " to both sides to eliminate " pq " from L.H.S.)

px = r -pq

× px = × (r -pq) (Multiply by the multiplicative inverse of " p " i.e. "    " to eliminate " p " from L.H.S.) 1 p 1 p 1 p

$$x \, = \, \frac { r - p q } { p }$$

## Method 2: Divide and rearrange

```
= x + q = x + q -q =        -q x  = -q x = p ( x + q ) p r -pq p r p r p r p r p (Divide both sides by " p " to eliminate p from L.H.S.) (Add the additive inverse of  " q " i.e " -q " to both sides to eliminate " q " from L.H.S.)
```

## Example 2

In each of the following, make x the subject of formula.

```
(a) = q (b)      = 1 + (c)               =       + p x x p a b b a x + a a 1 q (Multiply by LCM.) (You can also expand brackets and rearrange as in example 2.) × ab = × ab +      × ab b(x + a) = a 2 + b 2 × b(x + a) = × (a 2 + b 2 ) x + a = x + a - a = -a x = -a a 2 + b 2 b a 2 + b 2 b a 2 + b 2 b x + a a a b 1 b 1 b b a Solution (c) × x = q × x p = qx × p =      × qx ∴ x = = × p = × p ∴ x = p x 1 q p q x p x p 1 q 1 q P q 1 q Solution (a) Alternative Method (Multiply by " x " on both sides to eliminate denominator on L.H.S.) (Taking reciprocal) (Multiply the multiplicative inverse of " q " i.e. "    " to eliminate " q " from L.H.S.) × pq = 1 × pq + × pq qx = pq + p × qx = × (pq + p) ∴ x = pq + p q x p 1 q 1 q 1 q 1 q Solution (b) (Multiply by LCM to cancel denominators.)
```

<!-- image -->

## EXERCISE 4.4

- 1.
- Circle the correct answer in the following. Making p the subject of formula in the formula d = 4 - 2( p -a ), we obtain

$$\text{A. } p & = \ \frac { d + 2 a } { 2 } \quad \text{B. } p = \ \frac { 2 a - d + 4 } { 2 } \\ \text{C. } p & = \ \frac { 4 - d + 2 a } { 2 } \quad \text{D. None of these}$$

$$2$$

2. Given the formula       = b - 1. Four students, Yan, Kin, Div and Shiv made t the subject of formula. Their answers are shown below. a t

## Note:

1. If the variable you are rearranging for is in brackets, then you can approach the rearranging in one of the two ways below:
-  either, expand the bracket and rearrange.
- or, divide and rearrange.
2.  To  remove  fractions  in formulae,  first  multiply  by the  appropriate  number  or letters,  but  remember  that the  fraction  bar  acts  as  a bracket, so put the brackets in when appropriate.

| Yan's Answer   | Kin's Answer   | Div's Answer   | Shiv's Answer   |
|----------------|----------------|----------------|-----------------|
| = b - 1 a t    | = b - 1 a t    | a t = b - 1    | = b - 1 a t     |
| a = bt - 1     | a = t ( b - 1) | a = bt - t     | = 1 b - 1 t a   |
| a + 1 = bt     | t = a b - 1    | a = t ( b - 1) | t = a           |
| t = a + 1 b    |                | a b - 1 t =    | b - 1           |

Which student(s) answered correctly?

3. In each of the following, make t the subject of formula.

| (a)     | 3( h + t ) = p    | (b) r = a(b + 2 t)          | (c) a(t - c) = b(d + e)   | (d) 1 + 2 (t + 3 ) = x   |
|---------|-------------------|-----------------------------|---------------------------|--------------------------|
| (e)     | 5 - 3 (t - a) = b | (f) = n (g) r t m           | = (h) t - 1 c             | = s e + at r             |
| (i) t a | = b - (j) c d     | = (k) - a = b c 2 t x t y q | (l)                       | = q r 2 t + a            |

## Further problems involving subject of formula

## Example

In each case, make x the subject of formula

(a) ax + bx = k

(b) bx + c = dx + e

$$( c ) \ \frac { d } { x } + a = b$$

## Solution

## Note:

The  aim  of  rearranging  is  to  manipulate the formula so that all the terms involving the variable is on one side of the equation, and everything else is on the other.

That  is  straight  forward  if  there  is  only one  term  involving  the  variable  we  are rearranging for. If however there are more than one term, then we need to perform an  extra  step,  which  is  to  factorise  after collecting the like terms.

(a) ax + bx = k x(a + b) = k x(a + b) × = k × x = (b) bx + c = dx + e bx + c -dx = dx + e -dx bx -dx + c = e bx -dx + c -c = e - c bx -dx = e -c x(b -d) = e -c x(b -d) × = (e -c) × (Factorise the L.H.S by removing the common factor x. ) (Multiply both sides by to eliminate (a+b) from L.H.S.) ( x becomes the subject.) k a + b e -c 1 ( b -d ) 1 ( b -d ) 1 ( b -d ) 1 a + b 1 a + b 1 a + b (Eliminate "dx" from R.H.S using additive inverse.) (Eliminate "c" from L.H.S using additive inverse.) (Factorise the L.H.S by removing the common factor x. ) (Multiply both sides by to eliminate (b -d) from L.H.S.) ( x becomes the subject.)

$$\therefore x \ = \ \frac { e - c } { b - d }$$

$$( \mathbf c ) \quad \frac { d } { x } + a \, = \, b$$

## Method 1

$$\intertext { w e n o a } \frac { 1 } { x } \times x + a \times x \ & = \ b \times x \\ d + a x \ & = \ b x \\ d + a x - a x \ & = \ b x - a x \\ d \ & = \ b x - a x \\ d \ & = \ x ( b - a ) \\ \therefore x \ & \frac { d } { b - a }$$

## Method 2

## Method 3

$$\begin{array} { c c c c c c c c c c c } & \text{Method $2$} & \text{Method $3$} \\ & & \\ & \frac { d } { x } + a - a & = & b - a & \frac { d } { x } + a - a & = & b - a \\ & & \frac { d } { x } & = & b - a & \frac { d } { x } & = & b - a \\ \times & & x \times & \frac { d } { x } & = & x \times ( b - a ) & \frac { x } { d } & = & \frac { 1 } { b - a } \\ a ) & & \\ & & d & = & x ( b - a ) & \\ & & \vdots x & = & \frac { d } { b - a } & \\ & & & b - a & \end{array}$$

<!-- image -->

## EXERCISE 4.5

1. In each of the following, make y the subject of formula.
2. In each of the following, make x the subject of formula.

(a) ky + by = c

(b) my + c = ny + k

(d) m - ny = r - sy

(e) g ( y + d ) = y + 2

(g) 8(1 - 3 y ) = p + qy

(h) p ( q - y ) = r ( t - y )

$$( \mathbf a ) \, y = \frac { ( x + b ) } { ( x + a ) } \quad ( \mathbf b ) \ \frac { y } { 1 0 } = \frac { ( x + 1 ) } { ( 2 x - 1 ) } \quad ( \mathbf c ) \ \frac { 2 - x } { 3 + 2 x } = \ \frac { c } { d }$$

a

3

4

5

x

x

b

(c) dy -k = p + my

(f) p ( y + a ) = q ( y + b )

$$( \mathrm d ) \ \frac { 2 x } { 3 } \ = \frac { y } { z } + \frac { z } { 6 }$$

(e)      =      +

(f)        =         -

$$( g ) \ \frac { 3 } { 4 x } + \frac { 2 } { y } = \frac { 3 } { z }$$

$$( \mathbf h ) \, \frac { p } { x } - \frac { p } { y } = \frac { r } { z }$$

x

y

z

p

q

3. Mr. Dhruv travelled a distance x km at an average speed of ( x + 30) km/h for t hours by car.
2. (a)  Show that t satisfies the formula t =                . x x + 30

[Hint: Distance = Speed × time ]

- (b) Rearrange the above formula to make x the subject of formula.

<!-- image -->

## Formulae involving Roots and Powers

In Grade 8, you learnt about square and square roots, cubes and cubes roots.

<!-- image -->

<!-- image -->

42

=  4 × 4

42

=  16

16   =  4

√

## Square root property

$$( + 5 ) ^ { 2 } = 2 5 \text{ and } ( - 5 ) ^ { 2 } = 2 5$$

If x 2  = 25

then x = ± 5

Observe

$$\begin{smallmatrix} \text{if $\sqrt{x} = 4$}$$

Thus, if √ x = k then x = k 2.

Thus, if x 2 = k, then x =±√ k .

All three equations are equivalent because √16 = 4. That is, 16 satisfies the original equation.

## Cubes and cube roots

<!-- image -->

If  √ x =  3 3

3

(√

x

)  =  33

3

x =  27

## Example 1

In each of the following, make x the subject of the formula.

$$( \mathbf a ) \sqrt { x } + b = a$$

$$( \mathbf a ) & \sqrt { x } + b = a & ( \mathbf$$

## Solution

## Solution

(a)

√

x

+

b

-

b

√

(√

=

a

x

=

a

x

-

-

)2  =  (

a

x

=  (

b

b

-

a

b

-

)2

)2

b

$$( \text{b} ) \quad ( \sqrt { x + b } ) ^ { 2$$

## Example 2

In each of the following, make x the subject of the formula.

$$\begin{array} {$$

<!-- image -->

## EXERCISE 4.6

1.  In each of the following, make r the subject of formula.

$$& ( \mathbf a ) \sqrt { r } = p & \quad & ( \mathbf b ) \sqrt { r } - p = q & \quad & ( \mathbf c ) \ p = \sqrt { r + 1 } & ( \mathbf d ) \quad p = 2 \sqrt { r - q } \\ & ( \mathbf e ) \ \frac { \sqrt { 3 r } } { 3 } \ = p & \quad & ( \mathbf f ) \ p = \ \frac { \sqrt { 2 r + a } } { 3 } & \quad & ( \mathbf g ) \ \frac { \sqrt { r } - q } { x } = p & \quad & ( \mathbf h ) \ \sqrt { r - 2 } = \sqrt { a + b }$$

33

=  3 × 3 × 3

33

=  27

3 27   =  3

√

Observe

If

x

3

=  27

3

x

=  √27

x =  3

## Note:

1. If

x

3

=

3

2. If √

x

$$( \mathfrak { c } ) \, a + x ^ { 2 } = b$$

## Solution

$$\left ( \mathbf c \right ) \ a + x ^ { 2 } - a & \ = \ b - a \\ x ^ { 2 } & \ = \ b - a \\ x & \ = \ \pm \sqrt { b - a }$$

k,

=

then k,

x

then

= √

x

k

3

=

k

3

.

.

2.  In each of the following, make x the subject of formula.

$$& \text{(a)} \, x ^ { 2 } = p & \text{(b)} \, x ^ { 2 } = y + z & \text{(c)} \, x ^ { 2 } + y ^ { 2 } = z ^ { 2 } & \text{(d)} \, A = \pi x ^ { 2 } \\ & \text{(e)} \, c x ^ { 2 } - n \, = \, m & \text{(f)} \, \frac { x ^ { 2 } } { a } + b = c & \text{(g)} \, \frac { m } { x ^ { 2 } } = y + z & \text{(h)} \, \ p x ^ { 2 } = 2 q x ^ { 2 } - r$$

3.  In each of the following, make x the subject of formula.

$$( \mathrm d ) \, \stackrel { 3 } { \sqrt { x } } - b = d$$

$$& ( \mathbf a ) \, p = \sqrt { x } \quad & \quad & ( \mathbf b ) \, p = \sqrt { x } + q \quad & \quad & ( \mathbf c ) \, c = \sqrt { x - 2 } \quad & \quad & ( \mathbf d ) \, \sqrt { x - b } = d \\ & ( \mathbf e ) \, v = \frac { 4 } { 3 } \, \pi x ^ { 3 } \quad & \quad & ( \mathbf f ) \, y = \frac { k } { x ^ { 3 } } - f$$

## Working with a transformed formula

## Example

The area, A , of the trapezium PQRS is given by the formula

$$A = \frac { 1 } { } \, ( a + b ) h.$$

2

- (a) Transpose the formula to make a the subject.
- (b) Find the value of a given A = 36, b = 7.8 and h = 6.

## Solution

$$( \mathbf a ) \quad A \ = \ \frac { 1 } { 2 } \ ( a + b ) h$$

$$A \times \frac { 2 } { h } \, = \, \frac { 1 } { 2 } \, ( a + b ) h \times \frac { 2 } { h }$$

$$(Eliminate `__` h ` from R.H.S.)$$

$$\frac { 2 A } { h } - b = \, a + b - b$$

(Eliminate ' b ' from R.H.S.)

$$\frac { 2 A } { h } - b = \, a \quad \colon \ a = \frac { 2 A } { h } - b \quad ( a \, \text{becomes the subject.} )$$

$$( b ) \quad a = \frac { 2 A } { h } - b$$

(Use the transformed formula.)

a

$$a = \frac { 2 ( 3 6 ) } { 6 } - 7. 8$$

$$\therefore \, a \, = \, 4. 2$$

(Substitute the given values.)

<!-- image -->

<!-- image -->

1.  It is given that S =       . D T
2. (a)  Find the value of S when D = 200 and T = 4.
3. (b)  (i)  Make T the new subject of formula.
4. (ii) Find the value of T when S = 60 and D = 90.
2.  It is given that I =          . PRT 100
6. (a)  Find the value of I when P =   5000,

R =   10

- T =   2.
- (b)  (i) Make P the new subject of formula. (ii) Find the value of P when I = 500, R = 5 and T = 4.
3.  It is given that v = u + at .
- (a)  Find the value of v when u = 3, a = 2 and t = 5.
- (b)  (i) Change the subject of formula to t. (ii) Find the value of t when v = 10, u = 4 and a = 3.
4.  It is given that S =                  where u and v are positive. v 2 + u 2 2 a
- (a)  Find the value of S when v = 10, u = 2 and a = 1.5.
- (b)  (i) Transpose the subject of formula to v . (ii) Find the value of v when u = 4, a = 3 and S
- = 8.
5.  The  formula C =        ( F -  32)  is  used  to  convert  temperatures  in  degrees  Fahrenheit  to degrees Celsius. 5 9
- (a)  Calculate C when F = 14.
- (b)  (i)  Change the subject of formula to F .
- (ii) Find the value of F when C = -20.
6.  The recommended maximum heart rate, H , for a man during exercise, is given by the formula H =      (220 n ) , where n years is the age of the man. 4
- 5
- (a)  Calculate H when n = 35.
- (b)  (i) Make n the new subject of formula. (ii) Find the value of n when H = 144.

7.  The volume of a cylinder is given by V = π r 2 h where r is  the base radius and h is the height.
2. (a) Make r the subject of the formula.
3. (b) Find r when V = 1540 cm 3 and h = 10 cm. (Take π =       ) 22 7

## Summary

## Working with formula

## When substituting values into formulae:

- Make appropriate use of brackets.
- Make sure you can work with the four operations "+, -, × and ÷".

## Example

$$\Big | \begin{array} { c } \text{$\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{--\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-.\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{+\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{
-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text	-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text.-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text
-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\tt{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\tt
-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\text{-\%}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}+}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}]-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}--}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-
-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}_}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}_]-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}_;
;}}-}}-}}-}}-}}-;
;\-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-}}-;
;
;\;
;
;\;
;\;
;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;$$

## Solution:

```
- (5)(-3) = 2 - (-15) = 2 + 15 = 17 (-2) 2 2
```

## Changing subject of formula

- When changing the subject  of  a  formula,  use  the  rules  of  inverses: always remember that you must perform the same operation to both sides of the equation.
- (i)  Remember that adding and subtracting are the opposites of each other.
- (ii) Remember that multiplying and dividing are the opposites of each other.

## Example

Make x

```
the subject of formula: (a) c + x = b (b) y + 9 x = z Solution: y + 9 x - y = z - y 9 x = z - y × 9 x = × z -y x = 1 9 1 9 Solution: c + x c = b c x = b -c z -y
```

<!-- image -->

- When you have to change the subject of a formula which includes a fraction, you must first multiply both sides of the formula by the denominator of the fraction to get rid of it.

e.g Make r the subject of formula given = b . r + 5

```
Solution: a ×            = a × b r + 5  = ab r + 5 - 5   = ab r = ab r + 5 a
```

```
- 5 - 5 a
```

- When you have to change the subject of formula which includes more than one term containing the variable you are rearranging for, you need to factorise after collecting the like terms.

e.g Make p the subject of formula given 3 p + a = bp + c .

```
Solution: 3 p + a -a = bp + c -a 3 p = bp + c -a 3 p -bp = bp + c -a -bp 3 p -bp = c -a p( 3 -b) = c -a p( 3 -b) × = (c -a) × p = 1 3 b 1 3 b c -a 3 b
```

- When you have to change the subject of formula which involves powers and roots, remember :

```
(i)   if √ x = k then x = k 2 . (ii)  if x 2 = k then x = ±√ k . (iii) if x 3 = k then x = √ k . (iv) if √ x = k then x = k 3 . 3 3
```

e.g Make x the subject in the following.

In this image, we can see a diagram.

<!-- image -->

## Continuous Assessment

1.  A formula states that W = Fd .

Find the value of

- (a) W if F = 10 and d = 5.5,
- (b) d if W = 72 and F = 12 .
2.  Given that y = ax 2 + b . Find
- (a) the value of y when a = 6, b = 3 and x = -4,
- (b) the values of x when y = 73, a = 9 and b = 9.
3.  The diagram shows a shape with dimensions in terms of x .
- (a) Write down a formula for the perimeter, p , of the shape.
- (b) Calculate the perimeter when x = 3.
- (c) Determine x if the perimeter is 50.
4.  A technician charges Rs 200 plus Rs p per hour to repair an air conditioner.

<!-- image -->

At one house a repair takes 4 hours and costs Rs 500.

- (a) Determine the value of p .
- (b) Write down a formula for the cost, Rs C , of a repair that takes x hours.
- (c) A repair costs Rs 387.50. How long does it take?

## 5.  Copy and complete the following table.

| Equation                                | Values of a , b and c   | Substituting given values into equation y   | Value of y   |
|-----------------------------------------|-------------------------|---------------------------------------------|--------------|
| y = a 3 + 2 ab 2 + c 3 (i)              | a = 3, b = -2 , c = -1  |                                             |              |
| (ii) y = 2 ab + 5 bc 2                  | a = 0, b = 6, c = -3    |                                             |              |
| (iii) y = + a + 1 a - 1 2 a - 1 2 a + 1 | a = -3                  |                                             |              |

## 6.  In each of the following, make x the subject of formula.

(a) p = 4 + x

b

x

m

(c) cx -m = n

(b)  8

-

=

(e) 3 ax = k

(i) ax = 2 y + x

f

mn

(

-

)

(j)   2(

b

px

b

=

- 2

x

) =

px

-

q

y

(g)         =

c

mx

(k)

y

=

c + x

a

(d) d = kx -e

p

d

(h)             =

x

-

t

$$( I ) \ \frac { 5 x } { x + d } = y$$

- 2

x

## 7.   In each of the following, make t the subject of formula.

$$\begin{array} { c } \text{$In each of the following, make $t$ the subject of formula.} \\ ( a ) \sqrt { ( c + t ) } = a & ( b ) \, b - \sqrt { t } = 2 \, + \, c & ( c ) \, c = \frac { 1 } { 2 } ( b - 2 t ^ { 2 } ) & ( d ) \, k = \frac { 1 } { 3 } \, t ^ { 2 } + y \\ ( e ) \, a + \sqrt { t } = 1 & ( f ) \, b = \frac { m } { \sqrt { t } } - 1 & ( g ) \, a t ^ { 3 } + b = c & ( h ) \, p - q = \frac { p } { t ^ { 3 } } \end{array}$$

8.  Transpose each of the following equations to make the letter indicated in [  ] brackets the subject.

(a)

p

xy

q

y

x

q

p

x

x

y ]

[

[

+ 4

+

]

(c)

(b)

= 5

=                             [

= 7

]

2

a +

5

x

a

x

t

=                             [

3

t + a

2

t

-

5

v

=

r

2

t

-

g

[

r

(d)

(g

]

]

(e)

(h)

b

=

2

x

2

=

y

c

a

[

+ 3

2

2

+

z

2

[

c

]

z

]

(f)

(i)

w

S

=

=

a

t

-

n

5

(

a

2

+

[

t

l

]

)       [

a

]

## Revision Exercise 1

1. (a)   Simplify 5 a 3  × 2 a 2 . (b) Evaluate 2 -3 . (c)  Solve the equation 3 2 x × 27 = 3 x .
2. (a)   Expand  (2 x + 1)( x + 3).
3. (b)  Use the result ( a -b ) 2 = a 2 + b 2  - 2 ab to evaluate  69 2 .
4. (c)   Factorise completely  2 x 2  - 50 y 2 .
5. (d)  If x 2 + y 2  = 125 and xy = 22, find the value of ( x + y ) 2 .
3. (a)   Factorise the following quadratic expressions.
7. (i) x 2 +  6 x
8. (ii) x 2  + 8 x - 48
9. (b)  Solve the equations.
10. (i) 2  + 11
11. x x + 30 = 0 (ii) x - 1 =  6 x
12. (c)  The sum of a positive number and its square is 12.  Find the number.
4. Given that a = 4, b = - 3 and c = 8, evaluate
14. (i) a + b,

$$( \text{ii} ) \, a b c, \quad \text{ \quad \ \ } ( \text{iii} ) \, 3 c - b ^ { 2 }.$$

5. Make x the subject of formula in the following
2. (i) p = 7 x + 4 q,

(ii) 2(

x

+

t

) = w,

(iii)  A = 2 x 2 + 3.

6. The diagram shows rectangle ABCD where AB = x + 5 and BC = x + 3, find, in terms of x (i)   the area of rectangle ABCD ,
2. (ii) AC 2 .

<!-- image -->

## COORDINATES

## Learning Objectives

## By the end of this chapter, you should be able to:

- find and interpret the gradient (slope) of inclined, horizontal and vertical lines.
- find the relationship between parallel lines and their gradients .
- determine and interpret the equation of a straight line in the form y = mx + c.
- solve problems involving straight line graphs in context.

## Gradient in real life

Observe the picture below and comment on the slopes.

What can be said about the slopes?

## CHECK THAT YOU CAN:

- Work with integers.
- Read a point in the Cartesian plane.
- Change the subject of formula.
- Solve simple linear equations.

The image is a simple diagram with a blue background. It features a few cartoon characters. Here is a detailed description of the image:

- **Title**: The title is "HURRAY!"
- **Characters**: There are three cartoon characters in the image. The first character is a man wearing a blue shirt and a red helmet. He is riding a red bicycle. The second character is a woman wearing a blue shirt and a yellow helmet. She is riding a red bicycle. The third character is a man wearing a blue shirt and a yellow helmet. He is riding a red bicycle.
- **Bicycles**: The bicycles are red and blue. The man is riding a red bicycle, and the woman is riding a red bicycle.
- **Bicycles and Text**: The bicycles are connected by a blue line. The line is labeled with the text "HURRAY!" in a stylized font.
- **Background**: The background is a simple blue color

<!-- image -->

## KEY TERMS

<!-- image -->

- Slope
- Gradient
- Vertical
- Horizontal
- Inclined
- Parallel
- Coefficient
- Constant term
- Equation

<!-- image -->

## DID YOU KNOW

Gradient is an important concept in real  life.    For  example,  it  is  used  in  the construction field. Roofs, roads and football  grounds  are  built  using  gradient to assist drainage of rain water.

In this chapter, you will learn how to measure the slope of a line by finding its gradient.

<!-- image -->

https://www.mathsisfun.com/equation\_of\_line

<!-- image -->

## Gradient of inclined lines

The gradient of a line is a measure of its steepness.

Lines  can  be  inclined  upwards  or  inclined  downwards  and some may be steeper than others.

The gradient of an inclined line is obtained by dividing the vertical increase by the horizontal increase.

## Note:

By  convention,  the  slope  of  a  line  is  always measured from left to right.  Hence, a line which slopes up from left to right, is said to be inclined upwards (       ) and a line which slopes down from left to right, is said to be inclined downwards (           ).

The image depicts a line graph with a vertical increase and a horizontal increase. The graph is labeled as "Vertical Increase" and "Horizontal Increase." The horizontal line is labeled as "A," and the vertical line is labeled as "B."

### Graph Description:
- **Vertical Line:**
  - The vertical line is labeled as "A" and is represented by a dashed line.
  - The line is increasing from left to right.

- **Horizontal Line:**
  - The horizontal line is labeled as "B" and is represented by a dashed line.
  - The line is increasing from left to right.

### Graph Analysis:
- **Vertical Increase:**
  - The vertical line is increasing from left to right.
  - The line is increasing from 0 to 1.

- **Horizontal Increase:**
  - The horizontal line is increasing from left to right.
  - The line is increasing from 0 to 2.

### Analysis

<!-- image -->

<!-- image -->

Use the diagram on the right to complete the following table.

| Line   | Vertical increase   | Horizontal increase   | vertical increase horizontal increase   | Gradient   |
|--------|---------------------|-----------------------|-----------------------------------------|------------|
| AB     | 1                   | 5                     | 1 5                                     | 1 5        |
| AC     |                     |                       |                                         |            |
| AD     |                     |                       |                                         |            |
| AE     | 6                   | 2                     | 6 2                                     | 3          |
| AF     |                     |                       |                                         |            |

In this image we can see a diagram. In the diagram we can see a line, a point and a line.

<!-- image -->

Now compare the steepness of each line with its respective gradient.

What do you observe?

<!-- image -->

- Lines  sloping  upwards  from  left  to  right  have  a positive gradient.
- The steeper the line, the greater the gradient.

## STOP AND THINK

1.  Suppose  you  are  riding  a  bicycle  uphill Is it the same as when you ride downhill?
2.  How  will  the  gradient  of  lines  sloping downwards be?

Now let us find the gradient of a line which is inclined downwards.

## Note:

Consider the straight line segment joining point A to point B.

A line extends indefinitely in both directions whereas a line segment is part of a line.

The image shows a diagram with a horizontal line labeled as "vertical increase" and a vertical line labeled as "vertical decrease." Both lines are represented by a dashed line. The horizontal line is labeled as "0" and the vertical line is labeled as "0."

The diagram consists of a horizontal line labeled as "0" and a vertical line labeled as "0." The horizontal line is positioned at the top of the diagram, while the vertical line is positioned at the bottom.

The diagram is divided into two parts. The left part of the diagram shows a horizontal line labeled as "0" and a vertical line labeled as "0." The horizontal line is positioned at the top of the diagram, while the vertical line is positioned at the bottom.

The diagram is labeled as follows:
- The horizontal line labeled as "0" is positioned at the top of the diagram.
- The vertical line labeled as "0" is positioned at the bottom of the diagram

<!-- image -->

Note that the line AB slopes downwards from left to right, and thus the vertical increase is negative.

Hence, lines which are inclined downwards have a negative gradient.

<!-- image -->

## EXERCISE 5.1

Find the gradient of each of the following line segments.

The image depicts a geometric diagram with a line segment labeled as "a" and another line segment labeled as "b". The line segment "a" is positioned at the top of the diagram and extends upwards, while the line segment "b" is positioned at the bottom of the diagram and extends downwards. Both lines are parallel to each other.

### Description of the Diagram:
- **Line Segment "a"**:
  - The line segment "a" is a straight line.
  - It is positioned at the top of the diagram.
  - The line segment "a" is parallel to the line segment "b".

- **Line Segment "b"**:
  - The line segment "b" is a straight line.
  - It is positioned at the bottom of the diagram.
  - The line segment "b" is parallel to the line segment "a".

### Analysis:
- **Parallel Lines**:
  - The line segments "a

<!-- image -->

## Gradient of lines in the cartesian plane

Consider the line segment joining two points A and B with coordinates (3,1) and (5,7) respectively as shown below.

## vertical increase

horizontal increase

The gradient of line AB =

=

increase in y coordinates increase in x coordinates

=

7 - 1

5 - 3

=

6

In this image we can see a diagram. In the diagram we can see a line, a point, a line, a line, a point, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line, a line

<!-- image -->

2

=    3

In general, if P ( x 1 , y 1 ) and Q ( x 2 , y 2 ) are two points on a line in the cartesian plane, then, the gradient of  line PQ =

vertical increase horizontal increase

=

increase in

y

increase in

x

$$= \, \frac { y _ { 2 } - y _ { 1 } } { x _ { 2 } - x _ { 1 } }$$

In this image, we can see a diagram. There are two lines, one is a line with a point named x and another is a line with a point named y.

<!-- image -->

1

## The gradient formula

The gradient of the line joining ( x 1 , y 1 ) and ( x 2 , y 2 ) is usually denoted by m , where

$$m = \frac { y _ { 2 } - y _ { 1 } } { x _ { 2 } - x _ { 1 } }$$

## Example 1

Find the gradient of the line joining the two points A (1 , 3) and B (2 , 7).

## Solution

Given points    A ( 1 , 3 ) and B ( 2  , 7 )

$$\dot { x } _ { 1 } \dot { y } _ { 1 } \quad \dot { x } _ { 2 } \dot { y } _ { 2 }$$

Using the gradient formula,

$$\text{gradient of AB} = \frac { y _ { 2 } - y _ { 1 } } { x _ { 2 } - x _ { 1 } }$$

$$\begin{smallmatrix} \tilde { \sim } _ { 1 } \end{smallmatrix}$$

$$\ = \ \frac { 7 - 3 } { 2 - 1 }$$

$$= \ \frac { 4 } { 1 }$$

=   4

[Verify the answer from the diagram.]

In this image we can see a graph.

<!-- image -->

Note:  As the gradient of AB is positive, the line AB is inclined upwards.

## Example 2

Find the gradient of the line joining the two points R (0 , 5) and S (3 , -1).

## Solution

$$\begin{array} {$$

Using the gradient formula,

$$\text{gradient of RS} = \frac { y _ { 2 } - y _ { 1 }$$

$$\frac { y _ { 2 } - y _ { 1 } } { x _ { 2 } -$$

$$= \, \frac { ( - 1 ) - 5 } { 3 - 0 }$$

$$= \, \frac { - 6 } { 3 }$$

=   -2

In this image, we can see a graph.

<!-- image -->

[Verify the answer from the diagram.]

Note: As the gradient of RS is negative, the line RS slopes downwards.

<!-- image -->

Find the gradient of the line joining each pair of points shown, using the gradient formula .

In this image, we can see a diagram. There are lines and points.

<!-- image -->

## Gradient of horizontal and vertical lines

Consider the points H (-2,3) and R (4,3) on the horizontal straight line as shown.

In this image there is a graph with some numbers on it.

<!-- image -->

Next, consider the points V (4,5) and T (4,-2) on the vertical line as shown.

In this image, we can see a graph.

<!-- image -->

Hence, the gradient of a vertical line is undefined.

<!-- image -->

## EXERCISE 5.3

1. Find the gradient of the line joining each of the following pairs of points.  State, whether the line is inclined upwards, inclined downwards, horizontal or vertical.
2.  The line joining A (1, 2) and B (4, p ) has gradient 5.  Find the value of p .
3.  If the gradient of the line joining ( k , 1) and (5 k , 4) is -3, find the value of k .

- (a)   A (2, 3)  and B (6, 7) (b)   C (3, 4)  and D (9, 4)

- (c)   E (5, -4)  and F (2, 5)

- (d)   G (-2, -6)  and H (4 , -10)  (e)    I (3, 0)  and J (3, -2)

- (f)    K (8,-2)  and  L (-4, -10)

- (g)   M (9, 17)  and N (2, 0) (h)   O, the origin and P (2, 6)  (i)    Q(13, 0)  and R( 0, 13)

<!-- image -->

FIND OUT

Why is division by zero undefined?

Hint:      Division  is  repeated subtraction.

## EQUATIONS OF LINES

## Equations of lines parallel to the axes

Any line in the cartesian plane can be identified by its equation. In Grade 7, you learnt that

- (1) vertical lines or lines parallel to the y -axis have equations of the form x = h, and
- (2) horizontal lines or lines parallel to the x -axis have equations of the form y = k , where h and k are constants.

The  equation  of  any  vertical line is in the form x = h .

<!-- image -->

<!-- image -->

The equation of any horizontal line is in the form y = k .

<!-- image -->

## EXERCISE 5.4

Circle the correct answer(s). In some questions, more than one answer is possible .

1.  The line y = 4  is

A.  vertical

- B.  inclined upwards
2.  The gradient of a vertical line is
- A.  positive

B.  negative

C.  zero

3.  Which of the following lines are parallel to the x -axis?

A. x = 2

B. y = -3

C. x = 0

4.  The set of points (1, 3), (3, 3), (5. 3)   and (6, 3) all lie on the line

A. x = 3

B. x + y = 3

C. y = 3

5.  Which of the following lines are parallel to line x = 7?

A. x = -5 B. y = 2 C. x = 0

- C.  horizontal
- D.   inclined downwards.
- D.   undefined

D. y = 2

D. y = x

D. y = 7

<!-- image -->

The  equation  of  a  line  represents a relationship between the x -coordinate  and  the y -coordinate of every point on the line.  The coordinates of a point which is NOT on the line will not satisfy the equation.

## Note:

The equation of the x axis is y = 0.

The equation of the y axis is x = 0.

## Equations of lines not parallel to the axes

Consider the ordered pairs (1, 2), (2, 4), (3, 6), (4, 8)… ( x, y ) in Figure 1.

Note that the ycoordinate in each pair can be obtained by multiplying the xcoordinate by 2, so that, y = 2 x .

Observe also that all the given points lie on a straight line whose gradient is 2.

The equation of the line in Figure 1 is y = 2x .

Now add 1 to the y -coordinate in each point. The following set of ordered pairs is obtained: (1, 3), (2, 5), (3, 7), (4, 9)… ( x, y ).

The ycoordinate in each point is  now  obtained  by multiplying the corresponding x -coordinate by 2 and then adding 1.

Thus, y = 2 x +1.

Figure  2  shows  the  plotted  points  and  they  all  lie  on  a straight line.

Note that the gradient is 2 and the value where the graph cuts the y -axis is 1. This value is called the yintercept .

The equation of the line in Figure 2 is y =            . 2 x + 1

<!-- image -->

Use Figure 3 on the right to complete the following table.

| Equation of line   | Coefficient of x   | Gradient   | Constant term   | y -intercept   |
|--------------------|--------------------|------------|-----------------|----------------|
| y = 2 x            | 2                  | 2          | 0               | 0              |
| y = 2 x - 1        |                    |            |                 |                |
| y = 2 x + 1        | 2                  | 2          | 1               | 1              |
| y = 2 x + 3        |                    |            |                 |                |
| y = mx + c         |                    |            |                 |                |

What can you deduce?

In this image I can see a graph.

<!-- image -->

In this image we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

The equation of a line is usually written in the form y = mx + c

where m is the gradient  and c is the yintercept (that is where the line cuts the yaxis).

## Example

Find the gradient and y -intercept of the following lines.

(a) y = 3 x - 8

(b) 3y = 12 x + 6

## Solution

(a) y = 3 x - 8

coefficient of x = 3

∴ gradient = 3

constant term  = -8

∴ y- intercept   = -8

(b) 3y = 12 x + 6

(÷ by 3) y = 4 x + 2

comparing with

y = mx + c ,

m = 4 and c = 2

∴ gradient = 4 and

y- intercept = 2

<!-- image -->

## EXERCISE 5.5

For each of the following lines, find (i) the gradient   and (ii) the y -intercept.

(a) y = 5 x + 7

(b) y = 4 x - 6

(c) y = 10 x

(d) y = 2 - 3 x

(e)    2 y = 6 x + 4

(f)   3 y = x + 8

(g) y + 8 x = 1

(h) y = 5 - x 2 3

(i) y = -2

(j) y = 2 x - 3 4

(k) x = 9

(l)    2 x + 3 y = 6

<!-- image -->

## Note:

To  obtain  the  gradient  or y -intercept  from  the equation of a line, always write y in terms of x .

(c) 4 x + 2 y = 10

(c) Rearranging 4 x + 2 y = 10

in the form y = mx + c ,

2

y = 10 - 4 x

(÷ by 2) y =  5 - 2 x or y = -2 x + 5

comparing with y = mx + c ,

m = -2 and c = 5

∴ gradient = -2  and yintercept = 5

## Example

Write down the equation of the line having

(a)   gradient 3 and yintercept 2

## Solution

(a) gradient = 3 and yintercept = 2

$$\therefore \, m = 3 \text{ and } \, c = 2,$$

replace  into y = mx + c

,

the equation of line is y = 3 x + 2

<!-- image -->

## EXERCISE 5.6

Find the equation of the line with

- (a)  gradient 2 and y- intercept  6

- (b)  gradient -1 and y- intercept  4

- (c)  gradient 3 and y- intercept  -5

- (d)  gradient       and y- intercept 1 2 3

- (e)  gradient -2 and y- intercept 4 5

- (f)  gradient      and y- intercept 3 4 1 8

- (g)  gradient 0 and y- intercept  7

- (h)  gradient 10 and y- intercept 0

## The equation of a line given its gradient and a point on the line

## Example

The equation of a line is y = 4 x + c .  Given that the line passes through (2 , 10), find the value of c .

## Solution

As (2, 10) lies on the line, x = 2  and y = 10  must satisfy the equation of the line.

Substituting x = 2  and y = 10  into y = 4 x + c ,

```
we have 10 = 4(2) + c 10 = 8 + c so that c = 2
```

$$( b ) \, \text{gradient } - \frac { 4 } { 5 } \text{ and } y \text{-intercept } 1$$

$$\begin{array} { l l l } ( b ) \, \text{gradient} = & - \frac { 4 } { 5 } & \text{and} \, y \text{-intercept} = 1 \\ \,. \, m = - \frac { 4 } { 5 } & \text{and} \, \text{c} = 1, \\ \, \text{replace} & \text{into} \, y = m x + c, \\ \, \text{the equation of line is} \, y = - \frac { 4 } { 5 } & \text{x} + 1 \\ \, \text{or} & 5 v + 4 x = 5 \, (Multiply \, \text{throughout} \, b v \, 5. \end{array}$$

or  5 y + 4 x = 5 (Multiply throughout by 5.)

<!-- image -->

If the line y = 2 x + c passes through each of the following points, find c in each case.

(a) (1, 3)        (b)  (4, -1)         (c)  (-2, 5)       (d)  (-7 , -6)       (e)  (-3, 0)        (f)  (0, 10)

## Example

Find the equation of the line passing through (1, 5) and with gradient 4.

## Solution

.

The equation of the line is of the form y = mx + c The gradient of the line is 4.

Therefore m = 4  and the equation is y = 4 x + c .

Now, (1, 5) lies on the line.  So, when x = 1, y = 5 .

Substituting x = 1  and y = 5  into y = 4 x + c , we have

5 = 4(1) + c

5 = 4 + c so that

c = 1

and the equation of the line is y = 4 x + 1

In this image, we can see a graph.

<!-- image -->

<!-- image -->

## EXERCISE 5.8

Find the equation of the line through

(a)   (1, 3) and having gradient 2,

(b)  (2, 4) and having gradient 3,

- (c)   (-1, 2) and having gradient      , 1 2

(d)  (0, 3) and having gradient 5,

- (e)   (5, 0) and having gradien  -     , 2 5

(f)   the origin and having gradient -2,

- (g)  (-4, -2) and having gradient 1,

- (h)  (-3, -3) and having gradient -    . 2 3

## The equation of a line (given two points on the line)

## Example

Find the equation of the straight line passing through

C (-2,-1) and D (1,5).

## Solution

The gradient of line CD, m

In this image, we can see a graph.

<!-- image -->

y

2

- y

1

x

=

2

- x

1

$$= \frac { 5 - ( - 1 ) } { 1 - ( - 2 ) }$$

=

6

3

=  2

Therefore m = 2  and the equation of CD is y = 2 x + c .

To determine c , we can use any one of the two given points.

Let us use (1, 5).  So when x = 1, y = 5.

Substituting the values of x and y into y = 2 x + c , we have

5 = 2(1) + c

5 = 2 + c so that

c = 3

and the equation of the line is y = 2 x + 3.

<!-- image -->

## EXERCISE 5.9

1. Find the equation of the following lines.

Use  the  point  (-2,  -1)  to  check  if  the  same value of c is obtained.

In this image, we can see a diagram. There are two lines, one is a line and the other is a line. There are some points.

<!-- image -->

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

2. Find the equation of the straight line through the points

- (a)  A (2, 3) and B (4, 6)

- (c)  E (1, 3)   and F (6, 0)

- (e)  I (0, 7) and J (2, 3)

- (g) M (4, 0) and N (0, 4)

- (b)  C (1, 3) and D (6, -2)

- (d)  G (-1, -1) and H (-3, 4)

- (f)   K (1, 12)   and L (3, 10)

- (h)  O, the origin and P (5, 4)

## Parallel lines and gradients

Parallel  lines  are  at  a  fixed  distance  apart  and  will  never meet.

Consider  the  parallel  lines  through  AB  and  PQ  in  the diagram.

Calculate the gradient of line AB and of line PQ.

What do you notice?

Parallel lines have the same gradient.

In this image we can see a graph.

<!-- image -->

## Conversely,

if two lines have the same gradient , they are parallel.

<!-- image -->

## EXERCISE 5.10

In each case, find the gradient of line AB and of line PQ. Determine whether the lines AB and PQ are  parallel.

- (a)   A (0, 5), B (2,  9) and P (1, 9) , Q (-2, 3)

(b) A (1, 12), B (-3, -8) and P (1, -2) , Q (3, -12)

- (c)   A (5, -2), B (-7 , 10) and P (1, 9) , Q (-2, 12)
- (e)   A (3, 2),  B (-5, -2) and P (6, 13) , Q (-2,-3)

(d) A (2, 2), B ( 0, -1) and P (-2 ,0) , Q (4 , 9)

- (f) A (6, 0), B (6, -3) and P (-4 ,8) , Q (1, 8)

## Example

Determine whether the lines y = 5 x - 4   and  3 y = 15 x - 6 are parallel. Justify your answer.

## Solution

For two lines to be parallel, they must have the same gradient.

So first find the gradient of each line and compare them.

Consider the line y = 5 x - 4, the coefficient of x = 5

∴ gradient = 5.

The equation of the second line is 3 y = 15 x - 6.

## Note:

To find the gradient from the equation of a line, always write y in terms of x .  Then the coefficient of x is the gradient.

Divide throughout by 3, y = 5 x - 2.

The coefficient of x is 5, so, the gradient of the second line is also 5.

Since their gradients are equal, the given lines are parallel.

<!-- image -->

## EXERCISE 5.11

Determine whether the following pairs of lines are parallel.

(a) y = 2 x + 1  and y = 2 x - 1

(b) y = x + 4   and y = x + 5

(c) y = 3 x + 6  and y = 2 x + 6

(d) y = 3 x - 4   and   3 y = 3 x - 6

(e) x + y = 4   and y = - x

(f) 2 y - 4 x = 8   and y = 2 x - 5

## Equation of a line through a given point and parallel to a given line

## Example

Find  the  equation  of  the  line  passing  through  (1,  2) and which is parallel to the line y = 3 x + 4.

## Solution

The gradient of the given line y = 3 x + 4  is 3.

So the gradient of the required line is also 3 since the two lines are parallel and they must have the same gradient.

Thus the equation of the required line is y = 3 x + c.

In this image, we can see a graph.

<!-- image -->

As this line passes through the point (1, 2) , x = 1, y = 2.

Replacing x = 1 and y = 2  into y = 3 x + c , we have

2 = 3(1) + c

2 = 3 + c c = -1

Therefore the equation of the required line is y = 3 x - 1.

<!-- image -->

## EXERCISE 5.12

- 1.
- In each of the following, a point and a line are given. Find the equation of the line passing through the given point and which is parallel to the given line.
2. Find the equation of the line passing through the point

In this image we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

In this image we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

(a)  (1, 5) and parallel to y = 2 x + 4

- (c)  (-1, 0) and parallel to y = -3 x + 1

- (e)  (-2, -7) and parallel to y - 5 x = 4

(b)  (0, 3) and parallel to y = x + 2

(d)  (2, 1) and parallel to 2 y = 5 x + 6

(f)  (6, 5) and parallel to  3 y + 2 x = 4

## Straight line graphs in practical situations

You will now learn how to use and interpret straight line graphs to solve practical problems.

## Example 1

Consider the table below which shows the number of kilograms of potatoes bought and the cost in rupees.

| No. of kilograms   |   2 |   4 |   6 |
|--------------------|-----|-----|-----|
| Cost in Rupees     |  70 | 140 | 210 |

A straight line graph, as shown, is obtained when the points (2, 70), (4, 140) and (6, 210) are plotted.

In this image, we can see a graph. On the graph, we can see numbers.

<!-- image -->

Note that the graph starts at the origin.  Can you explain why?

Using the points (2, 70) and (4, 140),

$$\begin{array} {$$

The units of the axes give the gradient a meaning so that the gradient actually represents the cost per kilogram. Hence, potatoes cost Rs 35 per kilogram. From the graph, it can also be seen that 5 kilograms of potatoes cost  Rs 175. Also, with  Rs 245, we can buy 7 kg of potatoes.

## Note:

The y -intercept  is  0  and  the  gradient  is 35. Hence the equation of the line can be written as y = 35 x.

<!-- image -->

## NOTE TO TEACHER

Help  students  read  the  required values  from  the  graph.    This  is covered in example 2.

## Example 2

During a certain period of the year, €1 (1 euro) was exchanged for Rs 40. The graph below shows the conversion from euros to rupees or vice versa.

- (a)  Use the graph to convert,
- (i)  € 45  into rupees.
- (ii)  Rs 1400 into euros.
- (b)  What is the gradient of the line and what does it represent?
- (c)  Write down the equation of the line.

In this image, we can see a graph.

<!-- image -->

## Solution

- (a)  From the graph,
- (i) € 45 is equivalent to Rs 1800.
- (ii) Rs 1400 can be converted into € 35
- (b)  Using (0, 0) and (10, 400),

$$\text{gradient} & = \frac { 4 0 0 } { 1 0 } \\ & = \$$

The  gradient  represents  the  exchange rate,  that  is,  the  rate  at  which  one  euro can be changed into rupees.

The image is a graph titled "Rupees" with a linear scale from 0 to 1000. The graph has a blue line that starts at the bottom and extends upwards, indicating a linear relationship. The x-axis is labeled "Rupees" and the y-axis is labeled "Euros." The graph shows a trend of increasing values from 0 to 1000, with a slight dip at the end.

### Analysis:
1. **Graph Line**:
   - The graph line starts at the bottom and extends upwards, indicating a linear relationship.
   - The x-axis is labeled "Rupees," and the y-axis is labeled "Euros."
   - The graph shows a trend of increasing values from 0 to 1000, with a slight dip at the end.

2. **Data Points**:
   - There are five data points on the graph.
   -

<!-- image -->

- (c) The y -intercept is 0, so the equation of the line is y = 40 x.

## Note:

Lines  passing  through  the  origin  have equations of the form y =mx .

<!-- image -->

## EXERCISE 5.13

1.   The graph below shows the hourly wage of a worker. Use the graph to answer the following questions.
2. (a)  How much does the worker earn if
3. he works for
4. (i)  4     hours? 1 2
5. (ii)  6 hours?
6. (b) For how long must he work to earn Rs 320?
7. (c) Calculate the gradient of the line and the wage rate per hour. What do you notice?
2.   The graph below shows the conversion from degrees Celsius ( o C) to degrees Fahrenheit ( o F).
9. (a)  Use the graph to change to o F
10. (i)  20 o C,
11. (ii)  35 o C.
12. (b) Use the graph to change to o C
13. (i)  50 o F,
14. (ii)  104 o F.
15. (c)  Find the y -intercept.
16. (d) Find the gradient of the line.

In this image we can see a graph. On the graph we can see the numbers.

<!-- image -->

Hence write down the formula used to convert o C  to o F.

In this image, we can see a graph.

<!-- image -->

3.  The graph below shows the height of a burning candle in centimetres (cm) at different points in time.
2. Use the graph to answer the following questions.
3. (a)   What is the height of the candle,
4. (i)  before it is lit?
5. (ii) after 40 minutes of burning?
6. (b)  After how many minutes will the candle be of length 6 cm?
7. (c)  How long will it take for the candle to burn completely?
4.  The graph below shows the approximate conversion from length in metres (m) to length in feet (ft).
9. Use the graph to answer the following questions.
10. (a)  Which is longer: 17 feet or 5.8 metres?
11. (b)  A path is 4.5 m long.  What is its length to the nearest foot?
12. (c)  Nuha says that 5 metres is more than 16 feet.  Is she right? Why?
13. (d)  What is 12 feet in metres?

In this image, we can see a graph. On the graph, we can see numbers.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

## Summary

- The gradient of  a  line  is  a  measure  of  its  steepness  and  is  calculated  by  dividing  the vertical increase by the horizontal increase.
- In  the  cartesian  plane,  the  gradient  of  the  line  joining  ( x 1 , y 1 )  and  ( x 2 , y 2 )  is  usually  denoted  by m ,  where m =                . y 2 - y 1 x 2 - x 1
- Orientation of a line and its gradient is illustrated below.
- The equation of an inclined line is usually written in the form y = mx + c , where m is the gradient and c is the y -intercept.
- If two lines are parallel , their gradients are equal . The converse is also true.
- In  many  practical  situations,  information  is  presented  in  the  form  of  a  graph.  We  can interpret and use graphs such as conversion graphs to solve problems.

In this image, we can see a graph. There are two lines on the graph.

<!-- image -->

## Continuous Assessment

1. If the gradient of the line joining the points A (-2, 7 ) and B ( 3, p ) is equal to -1, find p .
2. Find the value of k if the line joining the points P ( k , 7) and Q ( 5 k , -5 ) has a gradient of 2.
3. The line y = 4 x + 5 is parallel to the line 2 y = kx - 6. Find the value of k .
4. Write down the equation of the line which has gradient 2 and which passes through the origin.
5. Find the equation of the line which has gradient 3 and which passes through ( 2,1).  If this line also passes through the point (1, a ) , find the value of a .
6. Given that the line y = px + q passes through (1, -3) and ( 6, 7) .  Find the values of p and q .
7. The point (1, 4) lies on the line y = 5x + c . Find the value of c .
8. Find the value of k if  the line joining the points A (5,  4)  and B (2, k )  is  parallel to a line with gradient       . 1 3
9. Find the equation of the line passing through each of the following pair of points:
10. (a) (2, 6) and (1, 4).
11. (b) (3, -4)  and  (0, 5).
12. (c) (-2, -5) and (1, -5).
10. Find the equation of the line which passes through (4, 2) and parallel to the line y = 5x - 4 .
11. The diagram below shows a straight line having equation x + y = 5 which intersects the x -axis at the point A and the y -axis at the point B . y
15. (a)  Find the coordinates of
16. (i)  the point A .
17. (ii) the point B .
18. (b)  Find the equation of the line parallel to
19. x + y = 5 and which passes through the origin O.

<!-- image -->

## 12.  The graph shows how the Mauritian rupee can be converted into dollar ($), and vice versa.

In this image, we can see a graph. On the graph, we can see numbers.

<!-- image -->

## Use the graph to find:

- (a)  the amount in rupees which is equivalent to
- (i) $20.
- (ii) $50.
- (b)  the amount in dollars which is equivalent to
- (i)  Rs 1080.
- (ii) Rs 1440.
- (c)  the exchange rate.

## SIMULTANEOUS EQUATIONS

## Learning Objectives

## By the end of this chapter, you should be able to:

- identify and use simultaneous equations.
- solve simultaneous equations using graphical, substitution or elimination method.

## Simultaneous Equations

## CHECK THAT YOU CAN:

A  pair  of  simultaneous  equations  consists  of  two  linear equations  which  are  satisfied  by  the  same  values  of  the unknowns.

## Simultaneous Equations in real life

<!-- image -->

## Discovery Activity 1

Rajesh  went  to  the  cinema  with  his  wife  and  bought  two cinema tickets and two boxes of popcorn for Rs 600.

<!-- image -->

- Draw  straight lines given their equations.
- Solve linear equations.
- Substitute values in an equation.
- Change the subject of formula.
- Add and subtract algebraic terms.

<!-- image -->

## KEY TERMS

- Linear Equations
- Simultaneous Equations
- Satisfy
- Graphical Method
- Subject of Formula
- Substitution Method
- Elimination Method
- Coefficient

Wayne went to the same cinema with his cousin Neelven and they bought two cinema tickets and three boxes of popcorn for Rs 700.

<!-- image -->

<!-- image -->

With the information given above, what is the cost of one cinema ticket and of one box of popcorn?

The image is a food chart that contains a food item labeled as "3D Movie Ticket" and a food item labeled as "3D Movie Ticket" with a price of Rs. 600. The chart is divided into two sections, one labeled "3D Movie Ticket" and the other labeled "3D Movie Ticket" with a price of Rs. 600.

The chart is divided into two parts:
1. **3D Movie Ticket**:
   - The first part of the chart contains a box with the text "3D Movie Ticket" and a price of Rs. 600.
   - The second part of the chart contains a box with the text "3D Movie Ticket" and a price of Rs. 600.

2. **3D Movie Ticket**:
   - The first part of the chart contains a box with the text "3D Movie Ticket" and a

<!-- image -->

From the above, it can be found that the cost of one box of popcorn is Rs 100 and hence, the cost of one cinema ticket is Rs 200.

Check:

T wo cinema tickets and two boxes of popcorn = (Rs 200 × 2) + (Rs 100 × 2) = Rs 600.

Two cinema tickets and three boxes of popcorn = ( Rs 200 × 2) + (Rs 100 × 3) = Rs 700.

<!-- image -->

## Transforming the problem into simple equations

## Refer to Discovery Activity 1 .

Denoting the price of a cinema ticket as ' c '  and  the  price  of  a  box  of  popcorn as ' p ' ,  the  two statements can be written as a pair of simultaneous equations :

$$2 c + 2 p = 6 0 0 \\ 2 c + 3 p = 7 0 0$$

From the discovery activity, it was found that c = 200 and p = 100 satisfy both equations, that is,

2 c + 2 p = 600           [ 2(200) + 2(100) = 600] and 2 c + 3 p = 700           [2(200) + 3(100) = 700 ]

Hence, c = 200 and p = 100  is the solution of the pair of simultaneous equations as these values satisfy both equations at the same time.

<!-- image -->

1.    Rewrite each of the following statements as a pair of simultaneous equations.
2. (a)  One sweet and two chocolates altogether cost Rs 10.  Three sweets and one chocolate cost a total of  Rs 10.
3. (b) Five apples and four bananas cost a total of Rs 37.  Six apples and five bananas cost a total of Rs 45.
4. (c) A cup of tea and a cup of coffee cost Rs 14 altogether. The total price of two cups of tea and three cups of coffee is Rs 36.
5. (d)  The sum of two numbers is 5.  Twice the first number and thrice the second number gives a total of 14.
6. (e)  The sum of three times of a number and four times of another number is 14.  The sum of five times the first number and seven times the second number is 24.
2.    Check  whether x =  2  and y =  3  satisfy  the  simultaneous  equations  3 x +  7 y =  27  and 5 x + 2 y =16.

## Solving Simultaneous Equations

To solve simultaneous equations, three commonly used methods will be discussed in this chapter:

- (i) Graphical Method
- (ii)   Substitution Method
- (iii)   Elimination Method

## METHOD 1: GRAPHICAL METHOD

In this method, a pair of simultaneous equations is solved by

## Note:

The  solution  of  a  pair  of  simultaneous equations  are  the  x  and  y-coordinates of the point of intersection between the two lines.

- (i) drawing the two straight line graphs representing the two given linear equations.
- (ii)  finding  the x -coordinate  and  the y -coordinate  of  the  point  of  intersection  of  these  two straight line graphs.  (The point which is common to the two lines drawn.)

## NOTE TO TEACHER

For the graphical method,  at this level, it is appropriate to use x and y as unknowns.

## Example 1

Solve the pair of simultaneous equations.

$$y = 2 x + 1$$

$$y = x + 2$$

## Solution

Draw  the  two  straight  line  graphs  representing  the  two  given  equations  and  find  the coordinates of the point of intersection of the two lines.

In this image we can see a graph. On the graph we can see numbers.

<!-- image -->

The point of intersection is (1, 3).

So, the solution is x = 1 and y = 3.

## Example 2

Solve the pair of equations simultaneously.

y = 3 x - 1

$$2 y + x = 5$$

## Note:

To draw a line, at least two coordinates are needed.  You can construct a table of values for the two lines, as follows:

<!-- image -->

| y = 2 x + 1   | y = 2 x + 1   | y = 2 x + 1   |
|---------------|---------------|---------------|
| x             | 0             | 2             |
| y             | 1             | 5             |
|               | (0, 1)        | (2, 5)        |

y

=

x

+ 2

x

y

0

2

(0, 2)

2

4

(2, 4)

## Note:

Check that these values satisfy both equations.

<!-- image -->

| 2y + x = 5   | 2y + x = 5   | 2y + x = 5   |
|--------------|--------------|--------------|
| x            | 1            | 3            |
| y            | 2            | 1            |
|              | (1, 2)       | (3, 1)       |

## Solution

## Note:

The table shows values of x and y for the two lines.

<!-- image -->

| y = 3x - 1   |        |
|--------------|--------|
| 0            | 2      |
| -1           | 5      |
| (0, -1)      | (2, 5) |

In this image, we can see a graph. There is a point on the graph.

<!-- image -->

<!-- image -->

In each of the following, state the solution of the simultaneous equations.

The image consists of a graph with two axes labeled as x and y. The x-axis is labeled as 2x + y = 1 and the y-axis is labeled as 2x + y = 3. There is a line drawn on the graph that intersects the x-axis at point (2, 3).

<!-- image -->

In this image, we can see a graph.

<!-- image -->

<!-- image -->

Geogebra can be used to find the point of intersection between two straight lines.

You  can  use  Geogebra  to  find  the  solution  to  the  pair  of  simultaneous  equations y = 3 - 2 x and y = 3 - 4 x .

Step 1: Insert the equation y = 3 - 2 x in the "Input" section and press enter.

Step 2: Insert the equation y = 3 - 4 x in the "Input" section and press enter.

Step 3: Click the icon             and then click on the point of intersection of the two straight lines on the graph.

In this image, we can see a graph.

<!-- image -->

The solution to the simultaneous equations is x = 0, and y = 3.

## Note:

Verify that your answers satisfy both equations.

<!-- image -->

Solve the following pairs of simultaneous equations using the graphical method.

- (a) y = 5 + x

y = 3 + 3 x

(b) y = x + 2

x + 3 y = 6

- (c) x = 1- 2 y

x + y = 2

- (d) y = 3 x - 5

y = -1 - x

- (e)    2 y = 3 x + 4

2 x - 3 y = -1

- (f ) y + 2 x = -2 3 x -  2 y = -10

Note: You can check the answers to the above questions with the use of Geogebra.

## METHOD 2: SUBSTITUTION METHOD

This method is useful if, in at least one equation, either x or y is  given as or can be made the subject of the formula .  The steps involved in this method are displayed in the example below.

## Example 1

Solve the pair of simultaneous equations.

$$y = 2 x + 3$$

$$y = 5 x - 3$$

## Solution

Step 1: Label the equations as shown:

y = 2 x + 3

(1)

y = 5 x -3

(2)

From equation (1) y = 2 x + 3

Step 2 : Substituting y = 2 x + 3 into equation (2); we obtain

2

x +

3 = 5

x

-

3

This stage is also known as e quating expressions .  Do you know why?

2

x - 5 x = -3 - 3 (Re-arranging and collecting like terms)

-3 x = -6 (Simplifying)

x = 2  (Solving for x )

Step 3: Also, substituting x = 2 into equation (1) gives y = 2(2) + 3

$$y = 7$$

## Example 2

Solve the pair of simultaneous equations.

$$p = 1 2 - 2 q$$

$$4 p - 5 q = 3 5$$

Note: Substituting x =2 in equation (2) should give the same value of y , that is, y =7.

Note: Simultaneous equations are not always given in terms of x and y .

## Solution

$$\text{Step 1} :$$

$$p = 1 2 - 2 q \ \xrightarrow { ( 1 ) }$$

$$4 p - 5 q = 3 5 \text{ } \xrightarrow { ( 2 ) }$$

Here, p is the subject of formula from equation (1).

Step 2: Substituting p = 12 - 2 q into equation (2) gives

$$4 ( 1 2 - 2 q ) - 5 q = 3 5$$

48 - 8 q - 5 q = 35 (Expanding the brackets)

$$- 1 3 q = - 1 3 \ ( \text{Simplifying} )$$

$$q = 1 \ ( \text{Solving for } q )$$

Step 3: Substituting q = 1 into equation (1) , we have p = 12 - 2(1)

$$p = 1 0$$

## Example 3

Solve the pair of simultaneous equations.

$$3 x + 2 y = 1 1$$

$$y - 5 x = - 1$$

$$3 x + 2 y = 1 1 \xrightarrow { ( 1 ) }$$

Solution

Step 1:

3

$$y - 5 x = - 1 \ \xrightarrow { \pm } ( 2 )$$

Step 2: From equation (2), y =  -1 + 5 x

Substituting  y =  -1 + 5 x into equation (1)

$$3 x + 2 ( - 1 + 5 x ) = 1 1$$

3 x - 2 + 10 x = 11 (Expanding the bracket)

1 3

x = 13 (Simplifying)

$$x = 1 \, (Solving for x )$$

:

Step 3: Finding the value of y

$$y = - 1 + 5 ( 1 )$$

y = 4

Check: Verify whether p = 10   and q = 1 satisfy both equations.

Check: Verify whether x = 1   and y = 4 satisfy both equations.

<!-- image -->

Solve the following pairs of simultaneous equations using the substitution method.

| (a) y = 3 x - 1                 | (b) y = 17 - 3 x               | (c) x = 7 y + 11                | (d) x - 0.4 y = 4                 |
|---------------------------------|--------------------------------|---------------------------------|-----------------------------------|
| y = 3 + x                       | y = 3 x - 19                   | 5 x - 3 y = 23                  | 1.2 y + 5 x = 4                   |
| (e) y - 4 x = 1 2 y - 3 x = -13 | (f) 2 x + 3 y = 12 y + x = 3 1 | (g) 3 x - 5 y = 6 2 x - 3 y = 5 | (h) 3 x + 2 y = 1 4 x - 3 y = -10 |

3

## METHOD 3: ELIMINATION METHOD

This method consists of eliminating one of the two unknowns under the following rules: (i)  if  the  coefficients  of  the  selected unknown are of the same size and have the same signs, perform subtraction.

(ii) if the coefficients of the selected unknowns are of the same size but have unlike signs, perform addition.

<!-- image -->

## Discovery Activity 2

Perform the following additions/ subtractions as indicated. (do not solve the resulting equations.)

(a) (i)

x

+ 2

y

= 10

(ii)      10 x + 2 y = 31

(iii)      4

x

+

y

= 9

-

x

+

y

= 9

(b) (i)      3 x + y = 15

+

2

-

9

x

+ 2

y

= 27

$$\begin{matrix} ( \text{ii} ) & 3 x + 2 y & = 1 2 \\ & + & \\ & \frac { - 3 x + y & = 6 } { } \end{matrix}$$

x -y = 0

From the activity, observe how one unknown has been eliminated .

With some additional steps, the solution of the simultaneous equations can be found.

-

2

x

+

y

= 5

$$( \text{iii} ) \quad x - 2 y \quad = 9 \\ \frac { 3 x + 2 y } { } = 1 4 } { }$$

## Note:

You might remember the rules as follows:

USA ( U nlike S igns A dd) and

SSS ( S ame S igns S ubtract).

## Example 1

Solve the pair of equations simultaneously.

$$2 x + 3 y$$

$$2 x + y =$$

$$2 x + 3 y = 1 9 \, \longrightarrow \, ( 1 ) \, \quad$$

$$2 x + 3 y = 1 9 \\ 2 x + y = 9$$

## Solution

-

SSS ( S ame S igns S ubtract)

$$2 x + y = 9 \ \xrightarrow { \pm } ( 2 )$$

$$3 y - + y = 1 9 - 9 \, (Eliminating terms in x )$$

2

$$2 y = 1 0 \, (Simplifying both sides)$$

$$y = 5 \ ( \text{Solving for } y )$$

From equation (2),  2 x + 5 =9 ( since y = 5)

$$x = 2 \, \text{(Solving for $x$)}$$

The solution to the pair of simultaneous equations is x = 2 and y = 5

## Example 2

Solve the pair of equations simultaneously.

$$x + 2 y = 5 \\ 5 x - 2 y = - 1 1$$

## Solution

(2) USA ( U nlike S igns A dd)

$$\begin{smallmatrix} x + 2 y = 5 & \xrightarrow { ( 1 ) } \\ + & 5 x - 2 y = - 1 1 \xrightarrow { ( 2 ) } \\ \frac { 5 x - 2 y = - 1 1 \xrightarrow { ( 2 ) } } \end{smallmatrix}$$

x + 5 x = 5 + - 11 (Eliminating terms in x )

6 x = -6 (Simplying both sides of the equation)

$$x = - 1 \, \text{(Solving for $x$)}$$

From equation (1), -1 + 2 y = 5 (Replacing y by -1)

$$y = 3 \ ( \text{Solving for } y )$$

The solution to the pair of simultaneous equations is x = -1 and y = 3

Check that x = 2 and y = 5 satisfy both equations.

Check  that x =  -1  and y = 3 satisfy both equations.

## Example 3

Solve the pair of equations simultaneously.

4

$$x + 2 y & = 1 2 \\ 4 x - 5 y & = 3 5$$

## Solution

$$x + 2 y = 1 2$$

$$( 1 )$$

$$4 x - 5 y = 3 5 \ \xrightarrow { \pm } ( 2 )$$

Multiply equation (1) by 4 to make the coefficient of x equal in both equations.

$$\begin{array} {$$

## Example 4

Solve the pair of equations simultaneously.

5

$$3 x + 2 y & = 6 \\ 5 x + 3 y & = 1 1$$

## Solution

$$3 x + 2 y & = 6 \, \xrightarrow { \longrightarrow } ( 1 ) \\ 5 x + 3 y & = 1 1 \, \xrightarrow { \longrightarrow } ( 2 )$$

Multiplying one equation  by a number will not be sufficient to make the terms identical, irrespective of signs.

$$\underline { x \, 5 }$$

To eliminate x ,    make  both coefficients become 15 (the LCM of 3 and 5).

SSS ( S ame S igns S ubtract)

Work out this question again and eliminate y this  time.    Check  whether the same answers are obtained.

$$3 x + 2 y & = 6 \quad \xrightarrow { x 5 } \quad 1 5 x + 1 0 y & = 3 0 \\ 5 x + 3 y & = 1 1 \quad \xrightarrow { x 3 } \quad \overline { 1 5 x + 9 y & = 3 3 } \\ & \quad \overline { y & = - 3 } \\.. \quad. \quad. \quad. \quad. \quad.. \quad..$$

Finding the value of x using y = -3 in Equation (1)

$$3 x + 2 ( - 3 ) = 6$$

$$x = 4$$

The solution that satisfy both equations are x = 4 and y = -3

SSS ( S ame S igns S ubtract)

Note: x + 2 y = 12 and 4 x + 8 y = 48  are equivalent equations.

Remember that the values of x and y can be checked by verifying whether both equations are satisfied.

<!-- image -->

<!-- image -->

Solve the following pairs of simultaneous equations using the elimination method.

(a)  5 x + 3 y = 9

(b)  2 x - 3 y = 9

(c)  7 y + x = 10

(d)  5 x + y = 10

2 x - 3 y = 12

2 x + y = 13

3 x - 2 y = 7

7 x - 3 y = 14

(e)  4 x - 5 y = 35

(f)  5 x + 2 y = 16

(g)  1 1 y + 15 x

= -23 (h)  3 x + 5 y = 0

2 y + x = 12

2 x + 3 y = 13

7 y - 2 x = 20

2 x - 3 y = 0

## Word problems involving simultaneous equations

In this section, you will learn how to model statements into simultaneous equations and these will be solved using one of the methods discussed earlier.

## Example 1

In Kevin's purse, there are fifteen coins, all of which are either Rs 5  or Rs 20 coins.  The total value of the coins is Rs 165.  Find the number of Rs 5 coins and Rs 20 coins that Kevin has.

## Solution

Let x be the number of Rs 5 coins and y be the number of Rs 20 coins. The total number of coins is 15. ( In Kevin's purse, there are fifteen coins )

$$x + y = 1 5 \, \xrightarrow { \pm } ( 1 )$$

Note: Start by denoting the unknowns in the question by 2 different letters.

The total value of the coins is Rs  165.

$$5 x + 2 0 y = 1 6 5 \longrightarrow ( 2 )$$

From equation (1) , x = 15 y

Substitute x = 15 y into equation (2) gives

$$5 ( 1 5 - y ) + 2 0 y & = 1 6 5 \\ 7 5 - 5 y + 2 0 y & = 1 6 5 \\ 1 5 y & = 9 0$$

y = 6

Finding the value of x using equation (1) results to x = 9.

The number of Rs 5 coins is 9 and there are 6  Rs 20 coins.

One Rs 5 coin

One Rs 20 coin (1×20)= Rs20

(1×5)=  Rs 5

Two Rs 5coins (2×5) = Rs 10

Two Rs 20coins (2×20) = Rs 40

.

.

.

.

.

.

x Rs 5 coins

y Rs 20 coins

( x ×5)= Rs 5 x

( y ×20)= Rs 20 y

You can solve this pair of simultaneous equations by using another method.

Note: Verify  that  the  answers  satisfy the two statements given in the question.

## Example 2

In three years' time, a father will be four times as old as his daughter.  Three years ago, the father was six times as old as his daughter.  Find their present ages.

## Solution

Let the daughter's age be x and the father's age be y .

Start by identifying the unknowns in the question: the daughter's age and her father's age

In three years' time, the daughter's age will be  ( x + 3) and father's age will be ( y + 3).

y + 3 = 4 ( x + 3)  [ The father will be four times as old as his daughter. ]

Also, y - 3 = 6 ( x - 3)   [ Three years ago, the father was six times as old as his daughter. ]

Rewrite the two equations:

STOP AND THINK

<!-- image -->

Which method is more appropriate here? Solve these 2 equations using this method.

y

= 4

x

+ 9

(1 )

y

= 6

x

-15

(2)

The solution to the above pair of simultaneous equations is x = 12 and y = 57, that is, the daughter is presently 12 years old and her father is presently aged 57.

Check  that  these  values  satisfy  the  statements given in the question.

<!-- image -->

## EXERCISE 6.6

1.  At  the  market,  2  kg  of  potatoes  and  1  lettuce  cost  Rs  65  whereas,  8  kg  of  potatoes  and 2 lettuces cost Rs 210. Find the cost of one kg of potato and the cost of one lettuce.
2. Tickets for a concert for a fund raising activity are sold at Rs 60 for an adult and  Rs 40 for a child.  A total of 200 tickets was sold for Rs 9600. How many adult tickets and children tickets were sold?
3.  Siew's mark in the Maths class test is 15 more than her mark in the French class test.  The total marks she scored in  the two subjects is 125.  Find how much Siew scored in each subject.
4.  In a triangle, the three angles are x 0 , 3 x 0 and 3 y 0 .  In another triangle, the angles are y 0 , 5 y 0 and 2 x 0 respectively.  Find the value of x and the value of y .
5.  On a farmyard, there are ducks and dogs. In total there are 46 legs and 19 heads.  How many ducks and dogs are there?

## Summary

- A pair of simultaneous equations is a pair of equations which is satisfied by the same values of the unknowns.
- Three methods for solving simultaneous equations have been discussed in this chapter:
- (i) Graphical  Method :  This  method  consists  of  drawing  two  straight  line  graphs representing the two given equations and identifying the solutions of the simultaneous equations as the coordinates of the point of intersection of the two lines.
- (ii) Substitution Method : One unknown from any one of the two equations is made the subject of formula and this is substituted into the other equation.  The resulting equation is then solved and the value of the unknowns are found.
- (iii) Elimination Method :  When the coefficients of an unknown in both equations are of  the  same  size  and  have  the  same  signs,  subtraction  is  performed  to  eliminate  the unknown.  However, if the signs  are  different,  the  two  equations  are  added  and  this eliminates one unknown.  The resulting equation is then solved and the value of both unknowns must be found.
- For word problems, always start by denoting the unknowns by letters.

<!-- image -->

http://mathsfirst.massey.ac.nz/Algebra/SystemsofLinEq/EMeth.htm https://www.math-only-math.com/worksheet-on-simultaneous-linear-equations.html

## Continuous Assessment

1.  In the space provided under each pair of simultaneous equations, state which of the three methods (Graphical, Substitution or Elimination) is more appropriate in each case.

$$( \tt a ) & \ x = 3 y & ( \tt b ) & 7 x + 3 y = - 1 5 & ( \tt c ) & y = 2 x + 3 & ( \tt d ) & 4 x + 7 y = 1 0 \\ 4 x - 5 y = 7 & 1 2 y - 5 x = 3 9 & ( \tt b ) & y = 9 - x & y = 9 - x & y = 3 x = 5$$

Hence, solve the pairs of simultaneous equations by the appropriate method stated.

2.  The line y = 2 x has been drawn below.  By drawing an additional suitable line, solve the pair of simultaneous equations.

$$x + y = 6$$

y = 2x

In this image we can see a graph.

<!-- image -->

3.   The sum of the ages of Mr. Singh and his son Umesh is 61 years.  The difference between their ages is 27. How old is Umesh?  How old will Mr. Singh be when Umesh will be 25 years old?
4.  The sum of two numbers is 72 and the smaller number is equal to one-eighth of the larger number.  Find the two numbers.
5.   The figure shows an equilateral triangle.  Calculate the length of a side in cm.

<!-- image -->

## INEQUALITIES

## Learning Objectives

By the end of this chapter, you should be able to:

- find the solution of inequalities using set-builder notation.

In Grade 8, you were required to:

- demonstrate an understanding of linear inequalities.
- represent linear inequalities on a number line.
- solve linear inequalities.

The above will be revisited before finding the solution of inequalities using set-builder notation.

## Inequalities in real life

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## CHECK THAT YOU CAN:

- Identify the following symbols: &lt; , &gt;, ≤ , ≥.
- Identify algebraic expressions.
- Solve algebraic equations.

<!-- image -->

## KEY TERMS

- Inequality
- Inverse operations
- Set-builder notation

<!-- image -->

RECALL

- &lt;  is less than
- ≤  is less than or equal to
- &gt;  is greater than

## Inequalities

- ≥  is greater than or equal to

An inequality is a statement written using one of the symbols &lt;, &gt; , ≤ and ≥.

## Use of inequality symbol

In this image, we can see a number line.

<!-- image -->

## Example 2

2.  Rewrite each of the following statements using the symbol &gt; , ≥ , &lt; or ≤.
2. (a) 5 is less than 8.
3. (b) x is greater than 7.
4. (c) Anil's height ( h ) is less than or equal to 172 cm.
5. (d) The minimum basic salary ( s ) is Rs 9000.

## Solution

(a) 5 &lt; 8

(b) x &gt; 7

(c) h ≤ 172

<!-- image -->

## EXERCISE 7.1

1.  Fill in the blanks with the symbols  &gt; , &lt; , =.
2.  Mr  Uttam  drove  his  car  in  a  speed  limit  zone  at  a speed of x km/h. State whether each of the following statements is true or false.
3. (a) The speed camera flashed because x ≤ 60.
4. (b) The speed camera did not flash because x &gt; 60.
5. (c) The speed camera flashed because x &gt; 60.
3.  Rewrite each of the following statements using the symbol &gt;, ≥ , &lt;  or  ≤. (a) x is less than 5. (b) n is greater than 0.75.
7. (c) m is less than or equal to 28.
8. (d) a is greater than or equal to 9.81.
9. (e) The maximum speed, y km/h, on motorway is 110 km/h.
10. (f) The average minimum temperature, T ° C , in Mauritius for the year 2018 was 21° C .

(a) 5        2

(b) 5        -2

(c) -5        2

(d) -5        -2

(e) 3 2 16

(f) 0.75 9 16

(g) -5 2 (-6) 2

(h) (-27) 2 -3

(i) 3 3 3 4

(j) (-4) 3 64

(k) 2.25 4

(l) -5 4 (-5) 4

9

<!-- image -->

(d) s ≥ 9000

## Linear Inequalities

A linear inequality is any inequality involving one or two variables whose exponents or powers are one. The following are some examples of linear inequalities containing one variable.

$$x < 10 \\ 3 t > 5 \\ 2 p + 1 0 \geq 1 5 \\ 3 - 2 y \leq 1 0$$

## Representing linear inequalities on a number line

When using a number line, a small shaded circle is used for ≤ or ≥ and an unshaded circle is used for &lt; or &gt;.

In this image, we can see a graph.

<!-- image -->

Here, the shaded circle means that the value 1 is included.

In this image, we can see a graph. There is a number on the graph.

<!-- image -->

Here, the unshaded circle means that the value 4 is not included.

In this image, we can see a diagram.

<!-- image -->

## Example 4

In this image, we can see a graph.

<!-- image -->

<!-- image -->

## EXERCISE 7.2

| 1. Represent each of the following inequalities on a number line.   | 1. Represent each of the following inequalities on a number line.   | 1. Represent each of the following inequalities on a number line.   | 1. Represent each of the following inequalities on a number line.   |
|---------------------------------------------------------------------|---------------------------------------------------------------------|---------------------------------------------------------------------|---------------------------------------------------------------------|
| (a) x > 2                                                           | (b) x ≤ 6                                                           | (c) x < -3                                                          | (d) x ≥ -5                                                          |
| (e) -3 ≤ x ≤ 3                                                      | (f) 0 < x ≤ 4                                                       | (g) -5 < x < -1                                                     | (h) x ≤ 3.5                                                         |
| (i) -0.5 ≤ x < 4.5                                                  | (i) -0.5 ≤ x < 4.5                                                  | (i) -0.5 ≤ x < 4.5                                                  | (i) -0.5 ≤ x < 4.5                                                  |

2.  Write down the inequality represented on each of the following number lines.

In this image, we can see a graph.

<!-- image -->

## Solving linear inequalities

## Example 5

```
Solve the following inequalities. (a) x + 3 > 5 (b) 3 x ≥ 12
```

## Solution

$$\begin{matrix} ( \mathbf a ) & x + 3 \, > \, 5 \\ x + 3 - 3 \, > \, 5 - 3 \\ x \, > \, 2 \\ x \, > \, 2 \end{matrix} \quad \begin{matrix} ( \mathbf b ) & 3 x & \geq \, 1 2 \\ \frac { 1 } { 3 } \times 3 x & \geq \, \frac { 1 } { 3 } \times 1 2 \\ x & \geq \, 4 \end{matrix}$$

x ≥  4

## Example 6

Solve the following inequalities.

$$( \begin{matrix} - \cdots - \cdots - \cdots - \cdots - \cdots - \cdots - \cdots - \cdots - \cdots \\ ( a ) - 3 x > 1 8 \end{matrix} ) ( b ) \ - \frac { x } { 2 } < 5$$

$$3$$

## Solution

$$\underline { x }$$

$$\begin{matrix} - \frac { 3 } { 3 } \times 1 8 & \quad ( b ) & - \frac { x } { 3 } < 5 \\ - \frac { 1 } { 3 } \times - 3 x & < - \frac { 1 } { 3 } \times 1 8 & \quad - 3 \times \frac { x } { 3 } > - 3 \times 5 \\ x & < - 6 & \quad & x > - 1 5 \end{matrix}$$

<!-- image -->

The inequality sign is reversed when taking reciprocal.

E.g.  We know that  2 &lt; 4

Taking reciprocal of 2 and 4

$$\begin{smallmatrix} \xi & i \\ \text{we have } \frac { 1 } { 2 } \text{ and } \frac { 1 } { 4 } \,. \end{smallmatrix}$$

$$\text{Now, } \frac { 1 } { 2 } > \frac { 1 } { 4 }.$$

<!-- image -->

RECALL

The inequality sign is reversed when multiplying or dividing by a negative number.

$$\begin{smallmatrix} \mu \cdots \mu \cdots \mu \cdots \mu \cdots \mu \cdots \mu \\ E. g. \ 1 \ < 5 \\ - 1 \times 1 \ > \ - 1 \times 5 \\ - 1 \ > \ - 5 \end{smallmatrix}$$

## Example 7

$$\left ( \mathfrak { c } \right ) 2 + 2 x < 7 - 3 x$$

$$( c ) \quad 2 + 2 x \, < \, 7 - 3 x \\ 2 + 2 x + 3 x \, < \, 7 - 3 x + 3 x \\ 2 + 5 x \, < \, 7 \\ 2 + 5 x - 2 \, < \, 7 - 2 \\ 5 x \, < \, 5 \\ \frac { 1 } { 5 } \times 5 x \, < \frac { 1 } { 5 } \times 5 \\ x \, < \, 1$$

$$\text{Example 7} \\ \text{Solve the following inequalities.} \\ (a) \, 2 x + 7 < 13 \quad \quad ( b ) \, \frac { 2 x + 5 } { 3 } \, \leq 1 \quad \quad ( c ) \, 2 \\ \text{Solution} \\ (a) \, \frac { 2 x + 7 < \, 13 \quad \quad ( b ) \, \frac { 2 x + 5 } { 3 } \, \leq \, 1 \quad \quad ( c ) \, 2 \\ 2 x + 7 - 7 < \, 13 - 7 \quad \quad \quad 3 \times \, 2 x + 5 \, \leq \, 3 \times 1 \\ \frac { 1 } { 2 } \times 2 x < \, \frac { 1 } { 2 } \times 6 \quad \quad 3 \times \, 2 x + 5 \, \leq \, 3 \times 1 \\ \frac { 2 } { 2 } \times 5 \quad \, 2 \times 5 \, \leq \, 3 \times 1 \\ \quad x < \, 3 \quad \quad \quad 2 x + 5 \, - 5 \, \leq \, 3 \, - 5 \\ \frac { 1 } { 2 } \times 2 x < \, \frac { 1 } { 2 } \times - 2 \\ \frac { 1 } { 2 } \times \, - 1$$

## Example 8

Given that 2 p + 3 ≤ 20, state the largest possible value of p if:

(a) p is an integer.

(b) p is an even number.

(c) p is a prime number.

## Solution

In this image, we can see a graph.

<!-- image -->

- (a) If p is an integer ,

Possible values that p can take are { 8 , 7 , 6 , … }. But the largest possible value of p is 8.

- (b) If p is an even number ,

Possible values that p can take are { 8 , 6 , 4, … }. But the largest possible value of p is 8.

- (c) If p is a prime number ,

Possible values that p can take are { 7, 5 , … }. But the largest possible value of p is 7 .

<!-- image -->

## EXERCISE 7.3

1.  Solve the inequalities.

(a) x + 8 &gt; 13

(b) x - 7 &gt; 4

(c) 5 x ≤ 20

(d) 4 x ≥ 16

(e) x - 7 ≤ -4

(f)       ≥ 5 x 2

(g)       &lt; -3 x 5

(h) -9 &lt; 3 x

2.  Solve the inequalities.

(a) 5 x + 2 ≥ 12

(b) 4 x - 5 &gt; 7

(c) 4 x + 6 ≤ 30

(d) 6 x + 11 &lt; -1

(e) 4 &lt; 12 + 4 x

(f)       + 5 ≤ 2 x 3

(g) 2 +      &gt; 2 x 5

(h)        ≤ -7 x 4

3.  Solve the inequalities.

(a) -6 x &lt; 24

(b) 4 - 6 x ≤ 28

(c) -     &gt; 7 x 3

$$( d ) \ \frac { 2 - 3 x } { 4 } \geq 5$$

(e) 2 - 3( x + 2) &gt; 14

(f)            &gt; 2 x 1 - x 3

(g) 3 - 5 x &lt; 2 - x

(h) -2 x - 3 &gt; 4( x + 1)

(i) 23 + 3(2 x - 5) &gt; 2(4 x + 1)

4.  Given that t &gt; 13, state the smallest possible value of t if (a) t is an integer. (b) t is a prime number. (d) t is a multiple of 5.

(c) t is a square number.

- .
5.  Given that -5 &lt; r ≤ 12, state (a) the largest integer value of r. (b) the smallest integer value of r
6.  Find the smallest integer m which satisfies the inequality 8 m &gt; 36.
7.  Find the largest odd number n which satisfies the inequality 3 n - 5 ≤ 17.
8.  Find the smallest prime number p which satisfies the inequality 15 - 2 p &lt; 9.
9.  Given that 78 - 4 k ≥ 50. Find the largest possible value k if k is a multiple of 3.

## Set-builder notation

Set-builder notation is a mathematical notation for describing a set by enumerating its elements or stating the properties that its members must satisfy. It is sometimes simply referred to as set notation.

## For example:

{ x : 3 &lt; x ≤ 7, x ∈ R} is read as 'the set of all real values of x such that x lies between 3 and 7, including 7' .

<!-- image -->

The table below lists possible ways of describing and representing different sets of real numbers.

In this image, we can see a table.

<!-- image -->

| Description The set of real numbers                             | Representation using a number line   | Set- Builder Notation   |
|-----------------------------------------------------------------|--------------------------------------|-------------------------|
| (i) between a and b , but not including the values of a and b . | a b                                  | { x : a < x < b }       |
| (ii) between a and b , and including a and b .                  | a b                                  | { x : a ≤ x ≤ b }       |
| (iii) between a and b , including a but not including b .       | a b                                  | { x : a ≤ x < b }       |

In this image, we can see a graph.

<!-- image -->

## Example 9

Write down the inequality represented on each of the following number lines using set-builder notation.

In this image, we can see a graph.

<!-- image -->

## Solution

(a) A = { x : x &gt; -3}

(c) C = { x : -2 ≤ x ≤ 4}

(b) B = { x : x ≤ 2}

(d) D = { x : -4 &lt; x ≤ 0}

## Intersection of two sets of real numbers involving inequalities

Consider the sets A = { x : x ≥ 0} and B = { x : x ≤ 4}, where x is  a real number. The two sets are represented on the number line below.

In this image we can see a graph.

<!-- image -->

A ∩ B means the set of values of x common to both A and B . From the given number line, we observe that any value of x between 0 and 4 inclusive is common to both A and B .

The image is a graph titled "The common region is illustrated on the number line below." The graph is a horizontal line with a blue and black line on it. The blue line is labeled "A" and the black line is labeled "B." The x-axis is labeled "A" and the y-axis is labeled "B." The graph has a horizontal line that goes from the bottom left to the top right.

<!-- image -->

<!-- image -->

Therefore, in set notation, A ∩ B = { x : 0 ≤ x ≤ 4}.

## Union of two sets of real numbers involving inequalities

Consider the sets C = { x : -2 ≤ x &lt; 5} and D = {-4 ≤ x ≤ 3} represented on the number line below.

<!-- image -->

C ∪ D means the set of values of x which belong to either C or D or both. This is illustrated below.

Therefore, in set notation, C ∪ D = { x : -4 ≤ x &lt; 5}.

In this image, we can see a graph.

<!-- image -->

<!-- image -->

1.  Match the following.
2.  The number line below shows the set A = { x : x ≥ -3 , x ∈ R }.
3. (a) Make a copy of the number line and on your copy, illustrate the set B = { x : x ≤ 4, x ∈ R }.
4. (b) On the same diagram, illustrate the set A ∩ B .
5. (c) Copy and complete the following statement:

In this image, we can see a graph.

<!-- image -->

<!-- image -->

$$A \cap B = \{ x \colon _ { - } \leq x \leq _ { - } \}$$

3.  The sets A and B are defined as follows:
2. A = { x : x &gt; -5, x ∈ R }
3. B = { x : x ≤ 2, x ∈ R }
4. (a) On the same number line represent the sets A , B and A ∩ B .

$$& ( b ) \, \text{Copy and complete the following statement by inserting the missing inequality symbols.} \\ & \quad A \, \cap \, B = \{ x \colon - 5 \, \_ x \, \_ 2, x \in \, R \}$$

4.  The sets A and B are defined as follows:

}

$$A = \{ x \colon 3 \leq x < 8, x \in R \} \quad \quad B = \{ x \colon 1 < x \leq 5, x \in R \}$$

- (a) On the same number line, illustrate the sets A , B and A ∩ B .
- (b) Express A ∩ B in set-notation.

5.  The number line shows the sets A , B and C .
2. (a) Write A , B and C in set-builder notation.
3. (b) What is the relationship between the sets A , B and C ?
6.  The sets A and B are defined as follows:

In this image, we can see a graph.

<!-- image -->

A = { x : 1 ≤ x &lt; 8, x ∈ R }

B = { x : -1 &lt; x ≤ 3, x ∈ R }

- (a) On the same number line, illustrate the sets A , B and A ∪ B .
- (b) Express A ∪ B in set-notation.
7.  The number line shows the sets A , B , C and D . Fill in the blanks to complete the following statements.
- (a) A = { x :          &lt; x ≤          , x ∈ R }
- (b) B = { x :          ≤ x ≤          , x ∈ R }
- (c) C = { x : -5 x 4, x ∈ R }
- (d) D = { x : -8 x 6, x ∈ R }
- (e) C = A B
- (f) D = A B

The image depicts a line graph with a blue color. The graph has a horizontal axis labeled as "A" and a vertical axis labeled as "D". The x-axis is labeled as "x" and the y-axis is labeled as "y". The graph has a linear scale of range from -8 to 8 on the x-axis, and a linear scale of range from 0 to 10 on the y-axis.

The graph has a blue line that starts at the point labeled "A" and extends to the right, then to the left, and finally to the right again. The line is drawn with a smooth, continuous curve, and it appears to be a straight line.

The graph has a label at the bottom of the graph, which reads "A", indicating that the x-axis is labeled as "x" and the y-axis is labeled as "y".

The graph is labeled as "A", and it

<!-- image -->

## Summary

1. An inequality denotes a set or range of values under certain constraints. (e.g x ≤ 2, x &gt; 5, 3 x + 1 ≥ 1)
2. Linear inequalities in one variable can be represented on number lines as follows.
3. Linear inequalities are solved in the same way as linear equations.
4. When solving inequalities, inequality sign is reversed when:

In this image, we can see a graph.

<!-- image -->

```
Eg. 3 x + 2  ≥   8 3 x + 2 - 2  ≥   8 - 2 3 x ≥   6 × 3 x ≥       × 6 . x ≥  2 [Add the additive inverse of 2 on both sides, i.e. '-2'.] [Multiply by the multiplicative inverse of 3 on both sides, i.e. '    '. ] 1 3 1 3 1 3
```

(i) multiplying by a negative number.

$$\nu \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \cdots \colon \\ \text{Eg.} \quad - x \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 3 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 2 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 5 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 1 \ < \ 3 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 <. 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4. 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 3 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 3 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4. 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 3 \ < \ 4 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 3 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4. 3 \ < \ 4 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 \ < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4 < \ 4. 3 \ < \\ \cd 3 \ < \ 4 } \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 6 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < 5 \ < \ 5 \ < 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < \ 5 \ < 5 \ < \ 5 \ < \ 5 \ < 5 \ < \ 5. 3 \ < 5 \ < \ 5. 3 \ < 5 \ < \ 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ </ 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5. 3 \ < 5$$

(ii) dividing by a negative number.

$$\begin{matrix} E g. & - 2 x & > & 8 \\ & & - 2 x \\ & & \frac { - 2 x } { - 2 } & < & \frac { 8 } { - 2 } \\ & &. \end{matrix}$$

$$\begin{smallmatrix} - 2 & \, ^ { - 2 } & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, &\, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \   & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, &   & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \   \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \ \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \) & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, &
 & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \\ \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \
 & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, & \, \end{smallmatrix}$$

[Multiply both sides by '-1'.]

- (iii)  Taking reciprocal

$$\frac { 1 } { } \leq \frac { 1 } { }$$

$$\begin{matrix} E g. & \frac { 1 } { x } < \frac { 1 } { 7 } \\ & x > 7 \quad & [ \text{Take reciprocal.} ] \end{matrix}$$

- (iv) Interchanging the LHS and RHS of an inequality

$$E g.$$

$$\begin{smallmatrix} E g. & 4 & > & x \\ & x & < & 4 \end{smallmatrix} \quad \begin{smallmatrix} \text{(Interchange the LHS and RHS.} \end{smallmatrix}$$

5. Set-builder notation is a mathematical notation for describing a set by enumerating its elements or stating the properties that its members must satisfy.
2. contains all the real numbers that are greater can  be  represented using a

E.g A={ x : -4 ≤ x ≤ 5, x ∈ R } means the set A or equal to -4 and are less or equal to 5. The set A number line as follows.

<!-- image -->

6. Intersection and union of two sets of real numbers involving inequalities.

In this image, we can see a graph.

<!-- image -->

## Continuous Assessment

1.  Fill in the blanks with &lt; or &gt;.

(a) -10         7

(b) 5         -15

(c) -23         -8

2.  Rewrite the following statements using &gt; , ≥ , &lt; or ≤ .
2. (a) The length, l cm, of a koi fish is less than 90 cm.
3. (b) Pravin's maximum monthly expenses, Rs x , is Rs 17000.
4. (c) t is greater or equal to 56.
5. (d) g is greater than 9.81.

4.  Represent the following inequalities on a number line.

(a) x &gt; 4

(b) x ≥ 2

(c) x ≤ 3

(d) x &lt; -2

(e) -3 ≤ x ≤3

(f) -2 &lt; x ≤7

(g) 2 ≤ x &lt; 6

(h) -3 &lt; x &lt; 0

5.  Solve each of the following inequalities.

(a) x - 6 ≥ -3

(b) x + 8 ≥ 5

(c)       ≤ 3 x 2

(d)      ≤ -2 x 3

(e) 5 x - 3 &lt; 7

(f) 4 x + 2 &gt; 30

(g)      + 3 &lt; 7 x 3

(h)      - 1 ≥ -3 x 5

(i) 4 - 6 x &gt; 22

(j) 5 - 3 x ≤ -1

(k) 20 - 8 x &gt; 4

(l) 32 - 9 x ≥ -4

(m) 2 x - 3 &gt; 5 x - 7

(n) 7 - 3 x ≥ 5 - x

(o) 5(1 - 3 x ) ≤ 8

(p) 2 ≥ 5(1 - x )

In this image, we can see a graph.

<!-- image -->

(d) 6         8

6.  Given that 5 x &lt; 81, write down,
2. (a) the largest integer value of x .
3. (b) the largest prime number x .
4. (c) the largest square number x .
7.   List all the possible values of x if 30 ≤ x ≤ 60 and x is a multiple of 8.
8.  The area of the rectangle shown must be less than or equal to 100. Form an inequality in x using this information and solve it.
9.  The sets A and B are defined as follows.
8. A = { x : x ≤ 7, x ∈ R }

B = { x : x ≥ 3 , x ∈ R }

.

- (a) On the same number line, illustrate the sets A , B and A ∩ B
- (b) Express A ∩ B in set-notation.
10. The sets A and B are defined as follows.

A = { x : 3 ≤ x &lt; 7, x ∈ R }

B = { x : 1 &lt; x ≤ 5, x ∈ R }

.

- (a) On the same number line, illustrate the sets A , B and A ∪ B
- (b) Express A ∪ B in set-notation.

<!-- image -->

## Notes

## TRIGONOMETRY

## Learning Objectives

## By the end of this chapter, students should be able to:

- recognise and apply trigonometric ratios for acute angles (sine, cosine and tangent).
- solve trigonometric problems in two dimensions to find unknown sides/angles.

## Definition

## KEY TERMS

<!-- image -->

- Triangles
- Right angled triangle
- Angles
- Sides
- Hypotenuse
- Adjacent
- Opposite
- Sine
- Cosine
- Tangent
- Pythagoras theorem
- Trigonometric ratios

## Guess !

Have you ever thought how high your school is?

Can you think how you can measure the height using simple mathematical tools?

The activity will enable you to do so.

<!-- image -->

## DID YOU KNOW

The fundamental trigonometric functions like sine and cosine are used to describe the sound and light waves. Trigonometry is used in oceanography to calculate heights of waves and tides in oceans. It is used in the creation of maps. It is used in satellite systems.

<!-- image -->

Trigonometry is  derived from the Greek word 'trigōnon' meaning "triangle" and 'metron' meaning "measure".

Trigonometry  is  a  branch  of  Mathematics  that  studies relationships  between  lengths  and  angles  of  triangles. It  is  widely  used  in  the  fields  of  engineering,  astronomy, architecture,  navigation,  surveying,  the  building  industry, and in many other branches of Science.

## Trigonometry in the real life

Estimating height in architecture

<!-- image -->

<!-- image -->

## Down history lane

The  field  of  trigonometry emerged  in  the  Hellenistic world during the 3 rd century BC from applications of geometry  to  astronomical studies.

<!-- image -->

In fact, during the third century astronomers first noted that the ratio of the lengths of two sides of a right-angled triangle depends only on one acute  angle  of  the  triangle. These  dependencies  are  now called trigonometric functions.

Estimating height of a mountain

8

<!-- image -->

Aim: To measure the height of your school

Materials  required: a  drinking  straw,  a  protractor,  some scotch tape and a measuring tape.

## Procedures:

1.  Tape the drinking straw to the protractor at the 45 degree angle mark.
2.  Hold the protractor with its flat side level with the horizon and then see through the drinking straw.
3.  Walk a distance away from the buiding until you can see the top of your school buiding through the straw.
4.  Since  you  are  sighting  the  top  of  the  building  at  a  45degree angle, your distance from the building is equal to the height of the building.
5.  Measure  your  distance  from  the  base  of  the  building  to know its height.

## Labelling the sides a right-angled triangle

Consider the triangle ABC with the angle x 0 at C

In this image, we can see a diagram. There are two lines, one is a line and the other is a triangle. We can also see a point.

<!-- image -->

<!-- image -->

## Note:

The hypotenuse is  always  opposite to  the  right  angle,  which  means  it never touches the right angle.

Hypotenuse is in fact the longest side of a right angled triangle.

AB is the opposite side of angle x

BC is the adjacent side of angle x

<!-- image -->

Label the three sides of the following triangles for angle x 0.

In this image we can see a diagram.

<!-- image -->

## Trigonometric ratios

In general, for any right angled triangle

<!-- image -->

opposite hypotenuse sin x =

adjacent hypotenuse cos x =

## Note:

Sine, cosine, and tangent are 3 important  trigonometric  ratios  and are abbreviated as sin, cos, and tan.

opposite adjacent tan x =

## Example

State the value of the trigonometric ratios for angle x , in the following triangle.

<!-- image -->

$$\sin x = \frac { \text{ opposite} } { \text{hypotenuse} } = \frac { 4 } { 5 }$$

$$\cos x = \frac { \text{adjacent} } { \text{hypotenuse} } = \frac { 3 } { 5 }$$

$$\tan x = \frac { \text{ opposite} } { \text{adjacent} } \, = \, \frac { 4 } { 3 }$$

## Remembering the three trigonometric ratios

A  simple  strategy  to  remember  the  three  trigonometric  ratio  is  to  remember  the acronym 'SOH CAH TOA' .

$$\text{SO} stands for sin x = \frac { \text{ opposite} } { \text{ hypotenuse} }$$

CAH stands for cos x

=

TOA stands for

tan

x

=

opposite

adjacent

adjacent

hypotenuse

<!-- image -->

<!-- image -->

1.  For each of the following triangles, write down the trigonometric ratios for the given angle.

In this image, we can see a diagram.

<!-- image -->

10

## Trigonometric ratios in calculators

## Consider the following triangle

<!-- image -->

From the triangle, it can be observed that

$$\sin 3 0 ^ { 0 } = \frac { \text{ opposite} } { \text{hypotenuse} } \, = \frac { 2. 5 } { 5 } = 0. 5$$

$$\cos 3 0 ^ { 0 } = \frac { \text{adjacent} } { \text{hypotenuse} } \ = \frac { 4. 3 } { 5 } = 0. 8 6$$

$$\tan 3 0 ^ { 0 } = \frac { \text{ opposite} } { \text{adjacent} } \ = \frac { 2. 5 } { 4. 3 } \ = 0. 5 8$$

## However these values of  sin 30 0 , cos 30 0  and tan 30 0  can be calculated from a scientific calculator

<!-- image -->

On any scientific calculator the keys                                          can be found. sin cos tan

To obtain the value of sin 30 0

,   press                then  30  followed by sin

<!-- image -->

sin 30 0  = 0.5

Repeat the same procedures for cos 30 0  and tan 30 0

<!-- image -->

1.  Use  a  scientific  calculator  to  find  the  values  of  the  following,  giving  your  answer  to 2 decimal places.

(a) cos 40 0

(b) sin 40 0

(c) tan 40 0

(d) cos 70 0

(e) sin 38 0

(f) tan 76 0

(g) cos 140 0

(h) sin 135 0

- (i) tan 100 0

( j) sin 110 0

(k) cos 18 0

(l) tan 170 0

## Using trigonometric ratios to calculate unknown sides

## Example

1.  Calculate the length of side AB , given that the length AC = 10 cm and angle BCA = 30 0 .

( cos 30 0 = 0.866, sin 30 0 = 0.5, tan 30 0 = 0.57)

<!-- image -->

## Solution

B

In the image we can see a triangle with vertices A, B, and C. The length of the hypotenuse is 30 cm.

<!-- image -->

SOH     CAH     TOA

<!-- image -->

$$\sin x = \frac { \text{ opposite} } { \text{hypotenuse} }$$

In this triangle,

$$\sin 3 0 ^ { 0 } = \frac { A B } { 1 0 }$$

sin 30 0 is given as 0.5, so

$$0. 5 \, = \, \frac { A B } { \lambda \cap }$$

$$\frac { A B } { 1 0 }$$

$$\omega. \gamma = \sqrt { 1 0 } \\ 1 0 \times 0. 5 = \frac { A B } { 1 0 } \times 1 0$$

$$5 & = A B \\ i. e \quad A B & = 5 \, \text{cm}$$

(Multiply both sides by 10 to eliminate the denominator.)

Note: In this triangle, the hypotenuse is given and the opposite side is to be calculated, so the ratio sin is used.

Alternate method:

use of cross multiplication

$$s i n \, 3 0 ^ { 0 } = \, \frac { A B } { 1 0 }$$

$$\frac { 0. 5 } { 1 } \stackrel { \mathcal { M } } { \mathbb { M } } \frac { A B } { 1 0 }$$

$$A B \times 1 & = 1 0 \times s i n \ 3 0 ^ { 0 } \\ A B & = 1 0 \times 0. 5 \\ & = 5 \, c m$$

2.  Calculate the length of side AB , given that the length AC = 12 cm and angle BÂC = 40 0 .

( cos 40 0 =   0.77 , sin 40 0 = 0.64, tan 40 0 = 0.84)

<!-- image -->

## Solution

<!-- image -->

$$c o s \, x = \ \frac { \text{adjacent} } { \text{hypotenuse} }$$

In this triangle,

$$\cos 4 0 ^ { 0 } = \ \frac { A B } { 1 2 }$$

cos 40 0 is given as 0.77, so

$$0. 7 7 \ = \ \frac { A B } { 1 2 }$$

$$1 2 \times 0. 7 7 \, = \, \frac { A B } { 1 2 } \times 1 2 \, \ \left ( M \, \\ \text{eli}$$

$$\begin{array} { r c l } 9. 2 4 & = & A B \\ i. e & A B & = & 9. 2 4 \, \text{cm} \end{array}$$

(Multiply both sides by 12 to eliminate the denominator.)

Note: In this triangle, the hypotenuse is given and the adjacent side is to be calculated, so the ratio cos is used.

Alternate method: use of cross multiplication

$$c o s \, 4 0 ^ { 0 } = \frac { A B } { 1 2 }$$

$$\frac { 0. 7 7 } { 1 } \searrow \frac { A B } { 1 2 }$$

$$A B \times 1 & = 1 2 \times 0. 7 7 \\ A B & = 1 2 \times 0. 7 7 \\ & = 9. 2 4 \, \text{cm}$$

3.  Calculate the length of side PQ , given that the length QR = 7 cm and angle PRQ = 70 0 . ˆ

( cos 70 0 = 0.63 , sin 70 0 = 0.77 , tan 70 0 = 2.75)

<!-- image -->

## Solution

<!-- image -->

<!-- image -->

$$\tan x = \frac { \text{ opposite} } { \text{adjacent} }$$

In this triangle,

$$\tan 7 0 ^ { 0 } = \frac { P Q } { 7 }$$

tan 70 0 is given as 2.75, so

$$2. 7 5 \ = \ \frac { P Q } { 7 }$$

$$7 \times 2. 7 5 \ = \ \frac { P Q } { 7 } \times 7 \quad ( \begin{matrix} 0 \\ 0 \end{matrix} )$$

$$1 9. 2 5 \ = \ P Q$$

$$i. e \ \ P Q \ = \ 1 9. 2 5 \, \text{cm}$$

(multiply both sides by 7 to eliminate the denominator)

Note: In  this  triangle,  the  adjacent is given and the opposite side is to be calculated, so the ratio tan is used.

Alternate method: use of cross multiplication

$$t a n \, 7 0 ^ { 0 } = \frac { P Q } { 7 }$$

$$\frac { 2. 7 5 } { 1 } \stackrel { \mathcal { M } } { \mathbb { M } } \frac { P Q } { 7 }$$

$$P Q \times 1 \, & = \, 7 \times 2. 7 5 \\ P Q \, & = \, 7 \times 2. 7 5 \\ & = \, 1 9. 2 5 \, \text{cm}$$

4.  Calculate the length of side ST , given that the length SR = 5 cm and angle TSR = 60 0 . ˆ

( cos 60 0 = 0.5 , sin 60 0 = 0.866, tan 60 0 = 1.73)

<!-- image -->

## Solution

In this image, we can see a diagram. There is a line in the middle of the image. There is a text on the image.

<!-- image -->

## In this triangle

$$c o s \ 6 0 ^ { 0 } \ \ = \ \frac { 5 } { S T }$$

cos 60 0 is given as 0.5

$$0. 5 \ \ = \ \frac { 5 } { S T } \\ \quad \ \ \ \.$$

(Multiply  both  sides  by ST to eliminate denominator.)

$$S T \times 0. 5 \ \ = \ \frac { 5 } { S T } \times S T$$

$$S T \times 0. 5 \ \ = \ 5$$

$$\begin{array} { r c l } S T \times 0. 5 \times \frac { 1 } { 0. 5 } & = & 5 \times \frac { 1 } { 0. 5 } & (Multiply both sides by to \frac { 1 } { 0. 5 } \, \\ S T & = & 1 0 \, c m \end{array} \quad & S T \times 0.$$

Note: In  this  triangle,  the  adjacent is given and the hypotenuse side is to be calculated, so the ratio cos is used.

Alternate method: use of cross multiplication

$$c o s \ 6 0 ^ { 0 } = \ \frac { 5 } { S T }$$

$$\frac { 0. 5 } { 1 } \stackrel { \dots } { \not \leq } \frac { 5 } { S T }$$

$$S T \times 0. 5 = 5 \times 1$$

$$S T \ = \ \frac { 5 } { \cap \varsigma }$$

$$& = \frac { 5 } { 0. 5 } \\ & = \frac { 5 0 } { 5 } \\ & = \, 1 0 \, c m$$

<!-- image -->

1.  Calculate the side x in each of the following triangles using as much information as needed.

<!-- image -->

<!-- image -->

( cos 48 0 = 0.67 , sin 48 0 = 0.74 , tan 48 0 = 1.11)

<!-- image -->

( cos 70 0 = 0.34 , sin 70 0 = 0.94 , tan 70 0 = 2.75)

<!-- image -->

12 mm

( cos 30 0 = 0.87 , sin 30 0 = 0.5 , tan 30 0 = 0.58)

$$\left ( c o s \, m ^ { 0 } = \, \frac { 4 } { 5 } \,, \, \ s i n \, m ^ { 0 } = \, \frac { 3 } { 5 } \, \ t a n \, m ^ { 0 } = \frac { 3 } { 4 } \, \right )$$

<!-- image -->

## CHECK THIS LINK

IT links

We can use a trigonometric calculator to find unknown sides and angles by inputting the known sides and angles.

The following links will enable you to do so. https://www.rapidtables.com/calc/math/trigonometry-calculator.html

(cos 65 0 = 0.423 , sin 65 0 = 0.91 , tan 65 0 = 2.14)

<!-- image -->

( cos 60 0 = 0.5 , sin 60 0 = 0.87 , tan 60 0 = 1.73)

<!-- image -->

2.  Use an electronic calculator to calculate the side x , giving your answer to 2 decimal places.

<!-- image -->

Note: ELECTRONIC CALCULATOR is not allowed in the examination at Grade 9 level. So, for the questions based on trigonometry, the values of trigonometric ratios will be given to you. However you will be asked to use an electronic calculator in the following question for practice.

<!-- image -->

(c)

<!-- image -->

<!-- image -->

<!-- image -->

R

## Calculating sides in compound triangles

## Example

In the following triangle AB is 6 cm, AC is 10 cm and angle ADB = 20 0 . Calculate the value of x and of y .

( cos 20 0 = 0.94, sin 20 0 = 0.34, tan 20 0 = 0.36)

The image depicts a right triangle with one leg labeled as "x" and the other leg labeled as "y". The hypotenuse of the triangle is represented by the line segment "AB", and the other leg is represented by the line segment "BC". The angle at which the hypotenuse is located is labeled as "x", and the angle at which the other leg is located is labeled as "y".

### Description of the Image:
1. **Legs and Points**:
   - The hypotenuse of the triangle is labeled as "AB".
   - The other leg is labeled as "BC".

2. **Angle at the Hypotenuse**:
   - The angle at which the hypotenuse is located is labeled as "x".
   - The angle at which the other leg is located is labeled as "y".

3. **Angle at the Point of Intersection**:
   - The angle at which the hypotenuse and the other leg intersect

<!-- image -->

(f)

<!-- image -->

## Solution

The first step is to separate the triangles into two different right angled triangles.

<!-- image -->

In this image, we can see a diagram. There is a line in the middle of the image. There is a point on the left side of the image. There is a line on the right side of the image.

<!-- image -->

In  right  angled  triangle  ABC,  two  sides are  given,  so  we  can  use  Pythagoras theorem to find the third side.

$$\tan 2 0 \ = \ \frac { \text{ opposite} } { \text{adjacent} }$$

$$1 0 ^ { 2 } \, = \, x ^ { 2 } + 6 ^ { 2 }$$

$$1 0 0 \, = \, x ^ { 2 } + 3 6$$

Use additive inverse of 36 on both sides

$$1 0 0 - 3 6 \ = \ x ^ { 2 } + 3 6 - 3 6$$

$$6 4 \, = \, x ^ { 2 }$$

$$x \, = \, \sqrt { 6 4 }$$

x =   8 cm

<!-- image -->

## EXERCISE 8.5

1.  Calculate the sides x and y in the following

In this image, we can see a diagram.

<!-- image -->

$$0. 3 6 \ = \ \frac { 6 } { B D }$$

$$\therefore \ B D \ = \ \frac { 6 } { 0. 3 6 }$$

$$= \ 1 6. 7 \, c m$$

$$B D \ = \ x + y$$

16.7 =  8 + y

So the length of y = 16.7 - 8

$$\therefore y \ = \ 8. 7 \, \text{cm}$$

<!-- image -->

(b)

( cos 40 0 = 0.77 , sin 40 0 = 0.64 , tan 40 0 = 0.84)

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a diagram with a line and a point.

<!-- image -->

2.   In the following diagram, DÂB = 90 0 , AD = 9 cm, AC = 12 cm and angle ADB = 45 0.
2. (a) State the value of
3. (i) the length of AB,
4. (ii) tan ABD,
5. (iii)  tan DCB.
6. (b) Calculate the length of DC.

<!-- image -->

<!-- image -->

In any isosceles triangle, the perpendicular height is the bisector of the base that is AM = MC.

3.   In the following triangle, angle BÂD = angle ACD = 90 0 , AB = 12 cm and AD = 5 cm
2. (a) Calculate the length of side BD.
3. (b) If the angle ABC = 25 0 , find the length of BC.
4. (c) Hence state the value of sin CÂD.

( cos 25 0 = 0.91, sin 25 0 = 0.42 , tan 25 0 = 0.47)

<!-- image -->

## Finding angles in a right angled triangle

## Example 1

Calculate angle x , using as much information given as necessary.

In this image, we can see a diagram. There is a line in the image.

<!-- image -->

## Solution

<!-- image -->

In the above triangle,

$$\begin{array} { c c c } \sin x = \frac { \text{ opposite} } { \text{ hypotenuse} } & = & \frac { 5 } { \text{ 13} } \\ \\ \cos x = \frac { \text{ adjacent} } { \text{ hypotenuse} } & = & \frac { \text{ 12} } { \text{ 13} } \\ \\ \tan x = \frac { \text{ opposite} } { \text{ adjacent} } & = & \frac { 5 } { \text{ 12} } \\ \\ \end{array}$$

12 13 From the given information, cos 22.6 0 =       , so x = 22.6 0 .

## Example 2

Calculate angle x , using as much information given as necessary.

<!-- image -->

$$( \cos 3 6. 9 ^ { 0 } = \, \frac { 4 } { 5 } \, \quad s i n \, 5 3. 1 ^ { 0 } = \frac { 4 } { 5 } \, \quad t a n \, 3 6. 9 ^ { 0 } = \, \frac { 3 } { 4 } \ )$$

## Solution

In this image, we can see a diagram. There is a line, a point, a triangle, and a line.

<!-- image -->

In the above triangle,

$$\begin{array} { c c c c c c } \dots & \dots & \dots \\ \begin{array} { c } \sin x ^ { 0 } = \frac { \text{ opposite } } { \text{ hypotenuse } } & = & \frac { 4 } { 5 } \\ \end{array} \\ \cos x ^ { 0 } = \frac { \text{ adjacent } } { \text{ hypotenuse } } & = & \frac { 3 } { 5 } \\ \end{array} \\ \tan x ^ { 0 } = \frac { \text{ opposite } } { \text{ adjacent } } & = & \frac { 4 } { 3 } \end{array}$$

From the given information, sin 53.1 0 =       , so x 0 = 53.1 0 4 5

.

<!-- image -->

## EXERCISE 8.6

1.  Calculate angle x in each of the following diagrams using as much information as required.

<!-- image -->

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

$$& ( c o s \ 2 2. 6 ^ { 0 } = \frac { 1 2 } { 1 3 } \quad, \ s i n \ 6 7. 4 ^ { 0 } = \ \frac { 1 2 } { 1 3 } \\ & t a n \ 2 2. 6 ^ { 0 } = \ \frac { 5 } { 1 2 } \ )$$

<!-- image -->

<!-- image -->

<!-- image -->

( cos 36.9 0 = 0.8 , sin 53.1 0 = 0.8 , tan 40.0 0 = 0.6 )

<!-- image -->

( cos 45.4 0 = 0.7 , sin 44.6 0 = 0.7, tan 45.4 0 = 1.0 )

## Summary

## 1.  Trigonometric ratios

In this image, we can see a diagram. There are two sides of a triangle. On the right side, there is a triangle.

<!-- image -->

## 2.   Remembering trigonometric ratios

A  simple  way  to  remember  the  three  trigonometric  ratio  is  to  remember  the acronym "SOH CAH TOA"

opposite

hypotenuse

stands for sin x =

SOH

adjacent

hypotenuse

stands for cos x =

CAH

opposite

adjacent

stands for tan x =

TOA

## Continuous Assessment

1. Circle the correct answer in each of the following cases.
2. (i)  The value of cos x is
- A.  0.6 cm
4. (ii)  The formula for sin x is

- B.   0.4 cm

C.   0.8 cm

D.   0.75 cm

- A. adjacent hypotenuse

- B. hypotenuse

- opposite

C.

D.

hypotenuse

opposite

adjacent

opposite

In this image, we can see a diagram with a triangle and a line.

<!-- image -->

- (iii)  The value of tan x is

A.

3

4

B.

4

5

(iv)  The value of x is

A.   4.35 cm

B.   43.3 cm

C. 3 5

D. 4 3

<!-- image -->

( cos 30 0 = 0.87 , sin 30 0 = 0.5 , tan 30 0 = 0.57)

<!-- image -->

2. A string of a kite is 15 metres long and it makes an angle of 60° with the horizontal. How high is the kite above the ground, assuming that there is no slack in the string.
3. A ladder is leaning against a vertical wall making an angle of 20° with the ground. The foot of the ladder is 2.7 m from the wall. Find the length of ladder.

In this image, we can see a diagram. There is a diagram with a diagram, a line, a point, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle, a circle, a line, a square, a triangle

<!-- image -->

( cos 20 0 = 0.9 , sin 20 0 = 0.3 , tan 20 0 = 0.4)

In this image, we can see a diagram. There is a line in the image.

<!-- image -->

4. The length of a string between a kite and a point on the ground is 30 m. If the string is making an angle x 0 with the ground  such that sin x 0 =      , what is the vertical height of the kite with the ground ? 1 2
5. A pole 15 m long, leans against a vertical wall making an angle of 53˚ with the wall.
3. (a)   How high does the pole reach on the wall?
4. (b) How far is the foot of the pole from the wall?

$$( c o s \, 5 3 ^ { 0 } = 0. 6, \, s i n \, 5 3 ^ { 0 } = 0. 8, \, t a n \, 5 3 ^ { 0 } = 1. 3 )$$

6. The horizontal distance from a point C to the foot of the building, B, is 50 m.  As shown on the diagram the top of the building makes an angle of 60 0  with horizontal. Calculate the height of the building.
7. Mr. Avinash wants to determine the height of a light house. He measured the angle at A , a point on the ground and finds that cos x is     . If C is a point at the top of the light house, calculate the distance AC , given that A is 40 m from the base. 4 5

( cos 60 0 = 0.5, sin 60 0 = 0.9, tan 60 0 = 1.7)

In this image, we can see a diagram. There is a line in the image, which is a part of the diagram. There is a point on the line, which is labeled as A.

<!-- image -->

In this image, we can see a diagram with a lighthouse.

<!-- image -->

8. Calculate the length AX and BC , given that ABCD is an isosceles trapezium. Hence calculate the area of the trapezium.
9. At 2 pm Yesha's shadow is 3.5 m long. If Yesha is 125 cm tall, calculate the angle that the sun's rays make with the ground.
10. A ladder placed against a wall such that it reaches the top of the wall of height 6 m and the ladder is inclined at an angle of 60 0  with the horizontal ground. Calculate the distance between the foot of the ladder and  the wall.
11. In  the  triangle ABC ,  the  length  of  side AB =  10  cm  and angle ABC is  65 0 .  Calculate  the shortest distance from the vertex A to the side BC .

( cos 40 0 = 0.77, sin 40 0 = 0.64, tan 40 0 = 0.84)

In this image, we can see a diagram with a line, a point, a line, a circle, and a line.

<!-- image -->

In this image, we can see a cartoon image. There is a person in the image. There is a text on the image.

<!-- image -->

Note: The  use  of  a  scientific  calculator  is necessary for question 10 and 11.

## Revision Exercise 2

1. Solve the following equations

(a)  4 3 x ÷ 2 4 x = 32,

(b) x 2 = 3 x + 70.

2. Use the result ( a + b ) 2 = a 2 + 2 ab + b 2 to find the value of 49 2 + 98 + 1.
3. Factorise 9 x 2 -  16 49 .
4. It is given that y = 2 a -b 2 .
4. (a)   Find the value of y when a = 5 and b = -2.
5. (b)  (i) Make a the subject of formula.
6. (ii) Hence, or otherwise, find the value of a when y = 7 and b = 3.
5. (i) Find the gradient of the line passing through A (3, 5) and B (5, 9).
8. (ii)   Find the equation of line AB .
9. (iii)  Given that (4, k ) lies on the line AB , find the value of k .
6. Solve the simultaneous equations

3 x = y + 1

$$y = 3 + x$$

7. Solve each of the following inequalities.

$$( \mathbf a ) \ \ 2 x + 8 \geq 1 2, \quad \ \ ( \mathbf b ) \ \frac { 3 x } { 2 } + 1 \leq - 8, \quad \ \ ( \mathbf c ) \, 5 - 2 x < 2.$$

- (b)  3 x 2
8. Using as much of the information provided below, calculate the length of the side PQ, given that PR = 10 cm and PRQ = 60 0 . Calculate the length of the side PQ , using as much of the information as provided below.

<!-- image -->

cos 60 0 = 0.50

sin 60 0 = 0.87

tan 60 0 = 1.73

## Notes

## MATRICES

## Learning Objectives

## By the end of this chapter, you should be able to:

- interpret a matrix as a store of information.
- determine the order of a matrix.
- identify types of matrices.
- perform addition, subtraction and multiplication of matrices.
- solve matrix equations.

In  this  chapter,  you  will  learn  about  matrices,  a  topic  that has wide applications in fields such as pure Mathematics, statistics, engineering and sciences.

## Matrices in real Life

Mr. Rayan owns a canteen and the table below shows the number of items sold during lunch time on a particular day.

<!-- image -->

9

## CHECK THAT YOU CAN:

- Work with integers.
- Solve simple linear equations.

<!-- image -->

## KEY TERMS

| Menuitem   | Menuitem      |   Small portion |   Large portion |
|------------|---------------|-----------------|-----------------|
|            | Fried Noodles |              75 |              48 |
|            | Fried Rice    |              62 |              40 |
|            | Briyani       |              53 |              71 |

- Matrix
- Element
- Row
- Column
- Order
- Scalar

<!-- image -->

The values can be extracted from the above table to form an array of numbers like this:

$$\begin{pmatrix} 7 5 & 4 8 \\ 6 2 & 4 0 \\ 5 3 & 7 1 \end{pmatrix}$$

An array of numbers arranged like this is called a matrix (plural 'matrices'). Each number is an element of the matrix.  In general, a capital letter is used to represent a matrix.

$$\text{For example,} M = \left ( \begin{array} { c c } 7 5 & 4 8 \\ 6 2 & 4 0 \\ 5 3 & 7 1 \end{array} \right )$$

## Order of a Matrix

In a matrix, the horizontal entries are called rows and the vertical entries are called columns .

$$\text{Consider the matrix } M = \left ( \begin{matrix} 7 5 & 4 8 \\ 6 2 & 4 0 \\ 5 3 & 7 1 \end{matrix} \right )$$

<!-- image -->

The order of a matrix is specified by the number of rows followed by the number of columns.

In matrix M , there are 3 rows across and 2 columns down.

Thus, we say that the matrix M has order 3 by 2, written as 3 × 2.

In general, a matrix of order m × n refers to a matrix having m rows and n columns.

In the same way, the matrix S

=                     represents the number of small portions sold for each menu item and its order is 3 × 1.

$$= \binom { 7 5 } { 1. } r \epsilon$$

## Example

| Matrix            |   Number of rows |   Number of columns | Order   |
|-------------------|------------------|---------------------|---------|
| (i) 1 5 ( (       |                1 |                   2 | 1 × 2   |
| (ii) 2 3 ( (      |                2 |                   1 | 2 × 1   |
| (iii) 0 3 ( ( 4 7 |                2 |                   2 | 2 × 2   |

Note: The number of rows is always written first followed by the number of columns.

| (iv) 4 5 6 7 8 ( (   |   1 |   5 | 1 × 5   |
|----------------------|-----|-----|---------|
| (v) 1 1 3 5 8 -4 ( ( |   2 |   3 | 2 × 3   |

<!-- image -->

## EXERCISE 9.1

1. Study the table below which shows the number of gold, silver and bronze medals obtained during the JIOI games held in Mauritius in 2019 and then answer the following questions.
2. (a) Write down the matrix representing the number of
3. (i) gold medals obtained by the first three countries,
4. (ii)  medals of each type obtained by Mauritius,
5. (iii) medals of each type obtained by Mauritius and Madagascar.
6. (b) What do each of the following matrices represent?

In this image I can see the text and the image is in the background.

<!-- image -->

<!-- image -->

2. State the order of each of the following matrices.

$$\left ( \begin{matrix} 1 & 8 & 3 \\ 1 & - 4 & 5 \end{matrix} \right ) \quad \left ( \begin{matrix} \left ( \begin{matrix} 3 \\ 4 \end{matrix} \right ) \quad \left ( \begin{matrix} 1 & 7 \\ - 2 & 5 \end{matrix} \right ) \quad \left ( \begin{matrix} \left ( \begin{matrix} 2 & 2 \end{matrix} \right )$$

$$\begin{pmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \\ 7 & 8 & 9 \end{pmatrix} \quad \text{(f) \ (3 & 6 & 8 & 4 & 1 ) } \quad \text{(g) \ (7 & 4 ) } \quad \text{(h) \ (0 ) }$$

3. Using the digit 7 only, write down a matrix of order

$$( \mathfrak { a } ) \ 2 \times 1 \quad \ \ ( \mathfrak { b } ) \ 1 \times 2 \quad \ \ ( \mathfrak { c } ) \ 2 \times 2 \quad \ \ ( \mathfrak { d } ) \ 3 \times 4 \quad \ \ ( \mathfrak { e } ) \ 5 \times 2$$

## Types of Matrices

There are several types of matrices, but the most commonly used are listed in the table below:

<!-- image -->

| Matrix type                  | Properties                                                                                                       | Examples                                    |
|------------------------------|------------------------------------------------------------------------------------------------------------------|---------------------------------------------|
| • Row matrix                 | • It has only one row.                                                                                           | 5 3 ( ( 2 4 6 ( ( ,                         |
| • Column matrix              | • It has only one column.                                                                                        | , ( ( 1 4 3 5 7 ( (                         |
| • Null matrix or Zero matrix | • All elements are zero.                                                                                         | , ( ( 0 0 0 0 0 0 0 0 0 0 0 0 0 ( (         |
| • Square matrix              | • The number of rows is equal to the number of columns.                                                          | , ( ( 1 -2 7 5 1 4 7 2 5 8 3 6 9 ( (        |
| • Diagonal matrix            | • It is a square matrix with non-zero elements in the leading diagonal (shaded) and all other elements are zero. | , ( ( 0 5 1 0 3 0 0 0 5 0 0 0 4 ( (         |
| • Identity matrix            | • A diagonal matrix whose elements in the leading diagonal shaded are all one.                                   | , ( ( 0 1 1 0 1 0 0 0 1 0 0 0 1 ( (         |
| • Equal matrices             | • Theyarematriceshavingthesameorder and equal corresponding elements.                                            | , ( ( 1 3 2 4 ( ( 1 3 2 4 A = so A = B. B = |

<!-- image -->

1. For each of  the following matrices, write down
2. (i) its order, (ii) its type.

(a)

$$\left ( \begin{matrix} 1 \\ 0 \\ 1 \end{matrix} \right ) \left ( \begin{matrix} 1 & 0 \\ 0 & 1 \end{matrix} \right ) \left ( \begin{matrix} 0 & 0 \\ 0 & 0 \\ 0 & 0 \end{matrix} \right )$$

2   7

(

(

$$\left ( \mathbb { e } \right ) \left ( \begin{array} { c c c } 2 & 0 & 0 \\ 0 & 5 & 0 \\ 0 & 0 & 8 \end{array} \right ) \quad \left ( \mathbb { e } \right ) \left ( \begin{array} { c c c } 0 & 7 & 2 \\ 5 & 1 & 3 \\ 8 & 9 & 2 \end{array} \right ) \quad \left ( \mathbb { e } \right ) \left ( \begin{array} { c c c } 2 & 4 \\ 7 & 8 \end{array} \right ) \quad \left ( \mathbb { h } \right ) \left ( 1 & 3 & 6 \right )$$

## 2. Which of the following matrices are equal?

$$A = \begin{pmatrix} 2 & 4 \\ 6 & 8 \end{pmatrix} \quad, \quad B = \begin{pmatrix} 2 & 4 & 6 \end{pmatrix} \quad, \quad C = \begin{pmatrix} 6 \\ 4 \\ 2 \end{pmatrix} \quad, \quad D = \begin{pmatrix} 2 & 4 & 6 \end{pmatrix}$$

$$E = \begin{pmatrix} 2 \\ 4 \\ 6 \end{pmatrix} \quad, \quad F = \begin{pmatrix} 2 & 4 & 0 \\ 6 & 8 & 0 \end{pmatrix} \, \quad G = \begin{pmatrix} 2 & 4 \\ 6 & 8 \end{pmatrix} \quad, \quad H = \begin{pmatrix} 4 & 2 \\ 8 & 6 \end{pmatrix}$$

## 3. Find the values of x and y if

$$( \mathbf a ) = \binom { 1 } { y } = \binom { x } { 0 } & = \binom { ( \mathbf b ) } { y } \binom { 1 } { x } _ { 4 } = \binom { 1 } { 9 } \binom { 2 } { 4 } & = \binom { ( \mathbf c ) } { y } \binom { x + 2 } { y + 3 } = \binom { 8 } { 1 2 }$$

$$\left ( d \right ) \, \left ( 3 x \, \ 8 \, \right ) \, = \, \left ( 6 \, \ 2 y \right ) \, \int \, \left ( \mathbb { e } \right ) \, \left ( \mathbb { e } ^ { \, 5 x } _ { \ 8 } \right ) = \left ( \mathbb { e } ^ { \, 1 5 } _ { \ 2 \, - \, y } \right ) \, \int \, \left ( \mathbb { f } \right ) \, \left ( \mathbb { e } ^ { \, 3 } _ { \ 5 } \right ) = \left ( \mathbb { e } ^ { \, x } _ { \ 3 \, 0 } \right )$$

$$4. \quad \text{It is given that } P = \begin{pmatrix} 5 & x \\ 7 & 1 0 \end{pmatrix} \text{ and } Q = \begin{pmatrix} 5 & 2 \\ y & 1 0 \end{pmatrix}. \ D e d u e c e \, \text{the values of } x \, \text{and } y \, \text{if } P = Q.$$

## Addition and subtraction of matrices

Consider the information displayed in the table below:

In this image I can see the text on the top and bottom. In the middle I can see the numbers.

<!-- image -->

The column matrices G , S , and B below, show the number of gold, silver and bronze medals obtained by Mauritius, Madagascar and Reunion in the JIOI 2019 games.

$$G = \left ( \begin{matrix} 9 2 \\ 4 9 \\ 4 6 \end{matrix} \right ) \ \, \ \ S = \left ( \begin{matrix} 7 9 \\ 4 7 \\ 5 8 \end{matrix} \right ) \ \, \ \ B = \left ( \begin{matrix} 5 3 \\ 3 1 \\ 7 4 \end{matrix} \right )$$

The matrix T , representing the total number of medals obtained by the three countries can be obtained by adding the corresponding elements in the column matrices as shown below: Thus,

$$\text{onding elements in the column matrices as shown } \text{$\quad$} \\ T = \quad & G \quad + \quad & S \quad + \quad B \\ = \quad & \begin{pmatrix} 9 2 \\ 4 9 \\ 4 6 \end{pmatrix} + \begin{pmatrix} 7 9 \\ 4 7 \\ 5 8 \end{pmatrix} + \begin{pmatrix} 5 3 \\ 3 1 \\ 4 7 \end{pmatrix} \\ = \begin{pmatrix} 9 2 & + & 7 9 & + & 5 3 \\ 4 9 & + & 4 7 & + & 3 1 \\ 4 6 & + & 5 8 & + & 7 4 \end{pmatrix} \\ = \begin{pmatrix} 2 2 4 \\ 1 2 7 \\ 1 7 8 \end{pmatrix}$$

Next,  consider  the  row  matrices M and C representing  thnumber  of  medals  of  each  type obtained by Mauritius and Madagascar.

$$M \ = \ & ( \begin{array} { c c c } 9 2 & 7 9 & 5 3 \end{array} ) \,, \, C \ = \ & ( \begin{array} { c c c } 4 9 & 4 7 & 3 1 \end{array} ) \\ \text{Let } D \ = \ & M \quad - \quad C \quad \\ \quad \ = \ & ( \begin{array} { c c c } 9 2 & 7 9 & 5 3 \end{array} ) - ( \begin{array} { c c c } 4 9 & 4 7 & 3 1 \end{array} ) \\ \quad \ = \ & ( \begin{array} { c c c } 9 2 - 4 9 & 7 9 - 4 7 & 5 3 - 3 1 \end{array} ) \\ \quad \ = \ & ( \begin{array} { c c c } 4 3 & 3 2 & 2 2 \end{array} ) \\ \text{What does matrix} D \, represent?$$

What does matrix D represent?

Addition or subtraction of Matrices is performed by adding or subtracting the corresponding elements.

$$\text{Thus if } A = \, \left ( \begin{matrix} a & b \\ c & d \end{matrix} \right ) \text{ and } B = \, \left ( \begin{matrix} e & f \\ g & h \end{matrix} \right ) \, \text{then}$$

$$A + B = \left ( \begin{matrix} a & b \\ c & d \end{matrix} \right ) + \left ( \begin{matrix} e & f \\ g & h \end{matrix} \right ) \text{ and } \, A - B = \left ( \begin{matrix} a & b \\ c & d \end{matrix} \right ) - \left ( \begin{matrix} e & f \\ g & h \end{matrix} \right ) \text{ of the sam} \right )$$

Note: For matrix addition and subtraction, the matrices involved must be of the same order.

$$= \begin{pmatrix} a & + \ e & b & + \ f \\ c & + \ g & d & + \ h \end{pmatrix} \quad \quad \quad = \begin{pmatrix} a & - \ e & b & - \ f \\ c & - \ g & d & - \ h \end{pmatrix}$$

## Example 1

Consider matrices A , B and C where

$$A \ = \ \begin{pmatrix} 2 & 3 & 4 \\ 8 & 9 & 1 \end{pmatrix} \quad & B \ = \ \begin{pmatrix} 1 & 5 & 2 \\ 0 & 7 & 6 \end{pmatrix} \quad & C \ = \ \begin{pmatrix} 1 & 3 \\ 2 & 8 \end{pmatrix} \quad & \text{are both of} \\ \quad & \text{The result} \\ A \ + B \, a n \ \text{also of order} \ \end{pmatrix}$$

Note: Matrices A and B are  both  of  order  2  ×  3. The resulting matrices A + B and A -B are also of order 2 × 3.

## Solution

$$( \tt a ) \, A + B & = \begin{pmatrix} 2 & 3 & 4 \\ 8 & 9 & 1 \end{pmatrix} + \begin{pmatrix} 1 & 5 & 2 \\ 0 & 7 & 6 \end{pmatrix} \quad ( \tt b ) \, A - B & = \begin{pmatrix} 2 & 3 & 4 \\ 8 & 9 & 1 \end{pmatrix} - \begin{pmatrix} 1 & 5 & 2 \\ 0 & 7 & 6 \end{pmatrix} \\ & = \begin{pmatrix} 2 + 1 & 3 + 5 & 4 + 2 \\ 8 + 0 & 9 + 7 & 1 + 6 \end{pmatrix} & = \begin{pmatrix} 2 - 1 & 3 - 5 & 4 - 2 \\ 8 - 0 & 9 - 7 & 1 - 6 \end{pmatrix} \\ & = \begin{pmatrix} 3 & 8 & 6 \\ 8 & 1 6 & 7 \end{pmatrix} & = \begin{pmatrix} 1 & - 2 & 2 \\ 8 & 2 & - 5 \end{pmatrix} \\ ( \tt a ) \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \, M \end{pmatrix}$$

(c)   Matrices A and C are not of the same order. Hence, A + C is not possible.

<!-- image -->

## 1. Work out the following:

$$\binom { 2 } { 5 } + \binom { 1 } { 3 } \sum \left ( \mathbf b \right ) \left ( 6 \ 3 \right ) - \left ( 3 \ 4 \right ) \right ) \, \quad \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \
 \binom { ( c ) } { 5 } \left ( 3 \ 6 \right ) \left ( 3 \ 6 \right ) \right ) + \binom { 1 } { 0 } \, \frac { 2 } { 5 } \right )$$

$$\left ( \begin{matrix} 4 \\ 8 \end{matrix} \right ) + \left ( \begin{matrix} 2 \\ - 3 \end{matrix} \right ) & \left ( \begin{matrix} 8 & 7 & 6 \end{matrix} \right ) - \left ( 2 & 0 & - 3 \right ) & \left ( \begin{matrix} 2 & 9 \\ 1 & 1 \end{matrix} \right ) - \left ( \begin{matrix} 1 & 5 \\ 0 & 9 \end{matrix} \right )$$

$$\begin{pmatrix} 1 & 4 \\ 3 & 7 \\ 8 & 9 \end{pmatrix} + \begin{pmatrix} 0 & - 2 \\ 1 & 3 \\ 2 & 4 \end{pmatrix} \quad ( h ) \begin{pmatrix} 6 & 3 & 1 \\ 9 & 7 & 8 \end{pmatrix} - \begin{pmatrix} 3 & 4 & 1 \\ 9 & 7 & 1 \end{pmatrix} \quad ( i ) \ \ ( 1 & 1 0 ) + ( 1 6 & 4 )$$

$$\begin{pmatrix} 1 5 \\ 1 0 \\ 3 7 \end{pmatrix} - \begin{pmatrix} 2 5 \\ 8 \\ 5 0 \end{pmatrix} \quad \begin{pmatrix} ( k ) & \begin{pmatrix} 7 \\ 1 \\ 6 \end{pmatrix} + \begin{pmatrix} - 1 \\ 0 \\ 4 \end{pmatrix} + \begin{pmatrix} 4 \\ 5 \end{pmatrix}$$

$$\begin{pmatrix} 1 & \begin{pmatrix} 2 & 6 \\ - 3 & 5 \end{pmatrix} + \begin{pmatrix} 0 & 4 \\ 2 & 1 2 \end{pmatrix} - \begin{pmatrix} 1 & - 3 \\ 7 & 5 \end{pmatrix}$$

$$2. \quad & \text{Given} \, A = \left ( \begin{matrix} 2 & 8 \\ 0 & 1 \end{matrix} \right ) \text{ and } \, B = \left ( \begin{matrix} 1 & 6 \\ 7 & 9 \end{matrix} \right ). \, \text{Find} \\ & \text{(a) } A + B \quad & \text{(b) } A - B \quad & \text{(c) } B - A \quad & \text{(d) } B + A$$

Is A + B = B + A ?

Is A -B = B -A ?

$$\begin{array} { c c c } 3. & \text{Given } A = \begin{pmatrix} 1 \\ 6 \end{pmatrix}, \, B = \begin{pmatrix} 2 & 5 & 7 \\ 1 & 0 & 4 \end{pmatrix}, C = \begin{pmatrix} 5 \\ 2 \end{pmatrix}, \, D = \begin{pmatrix} 3 \\ 0 \\ 6 \end{pmatrix}, E = \begin{pmatrix} 1 & 5 & 9 \\ 4 & 8 & 2 \end{pmatrix}, \, F = \begin{pmatrix} - 5 \\ 6 \end{pmatrix}$$

Work out where possible:

| (a) A + B   | (b) C + A   | (c) D - B   | (d) E - B     | (e) B + A     |
|-------------|-------------|-------------|---------------|---------------|
| (f) B + E   | (g) C - F   | (h) A + D   | (i) F + C - A | (j) C - F + A |

A

## Multiplication of a matrix by a scalar

A scalar is a real number.

The product of a scalar k and a matrix A , is the matrix k A , where each element is k times the corresponding elements of A .

$$\text{Thus if } A = \begin{pmatrix} a & b \\ c & d$$

## Example 1

$$\text{ if } A = \begin{pmatrix} 2 & 0 \\ - 1 & 6$$

$$\frac { 1 } { 2 }$$

## Solution

$$\begin{array} {$$

## Example 2

$$& \text{if $P=\binom {1}{4}$ and $Q=\$$

## Solution

$$\text{Solution} \begin{array} { c c c } \text{Solution} \\ \text{(a)} \, 2 P + 3 Q & = & 2 \begin{pmatrix} 1 & 4 \\ 0 & - 5 \end{pmatrix} + 3 \begin{pmatrix} 2 & 6 \\ - 1 & 1 0 \end{pmatrix} \\ & = & \begin{pmatrix} 2 & 8 \\ 0 & - 1 0 \end{pmatrix} + \begin{pmatrix} 6 & 1 8 \\ - 3 & 3 0 \end{pmatrix} \\ & = & \begin{pmatrix} 8 & 2 6 \\ - 3 & 2 0 \end{pmatrix}$$

$$\text{olution} ^ { \text{1} } \text{2} P + 3 Q & = 2 \begin{pmatrix} 1 & 4 \\ 0 & - 5 \end{pmatrix} + 3 \begin{pmatrix} 2 & 6 \\ - 1 & 1 0 \end{pmatrix} \quad & ( \text{b} ) \, 4 Q - 5 P & = 4 \begin{pmatrix} 2 & 6 \\ - 1 & 1 0 \end{pmatrix} - 5 \begin{pmatrix} 1 & 4 \\ 0 & - 5 \end{pmatrix} \\ & = \begin{pmatrix} 2 & 8 \\ 0 & - 1 0 \end{pmatrix} + \begin{pmatrix} 6 & 1 8 \\ - 3 & 3 0 \end{pmatrix} & = \begin{pmatrix} 8 & 2 4 \\ - 4 & 4 0 \end{pmatrix} - \begin{pmatrix} 5 & 2 0 \\ 0 & - 2 5 \end{pmatrix} \\ & = \begin{pmatrix} 8 & 2 6 \\ - 3 & 2 0 \end{pmatrix} & = \begin{pmatrix} 3 & 4 \\ - 4 & 6 5 \end{pmatrix}$$

## Example 3

Find the unknown elements in each of the following:

$$( i ) \begin{pmatrix} a & 1 \\ 3 & d \end{pmatrix} + \begin{pmatrix} 2 & b \\ c & 0 \end{pmatrix} = \begin{pmatrix} 5 & 1 \\ - 4 & 8 \end{pmatrix} \quad \quad ( i i i ) \begin{pmatrix} 1 & x \\ 5 & 3 \end{pmatrix} - 2 \begin{pmatrix} w & 0 \\ 1 & z \end{pmatrix} = \begin{pmatrix} 7 & 8 \\ y & 1 \end{pmatrix}$$

## Solution

$$\begin{pmatrix} ( i ) & \begin{pmatrix} a & 1 \\ 3 & d \end{pmatrix} + \begin{pmatrix} 2 & b \\ c & 0 \end{pmatrix} = \begin{pmatrix} 5 & 1 \\ - 4 & 8 \end{pmatrix}$$

$$\begin{pmatrix} a \, + \, 2 & 1 \, + \, b \\ 3 \, + \, c & d \, + \, 0 \end{pmatrix} = \begin{pmatrix} 5 & 1 \\ - 4 & 8 \end{pmatrix}$$

Since the two matrices are equal, the  corresponding  elements  are equal.  Thus,

$$a + 2 & = 5 \quad \ \ 1 + b & = \ 1 \\ a & = 3 \quad \ \ b & = \ 0$$

$$\begin{array} { c c c } 3 + c & = - 4 & & & d + 0 = 8 \\ c & = - 7 & & & d = 8 \end{array}$$

<!-- image -->

1. Simplify

$$\text{I. } \underset { ( a ) } { 3 } \binom { 2 } { 5 } \quad ( b ) \ - 5 \left ( 1 \ 0 \ 4 \right ) \quad ( c ) \ 2 \binom { - 4 \ 1 0 } { 6 \ - 1 4 } \ ( d ) \ \frac { 1 } { 2 } \binom { 2 \ - 6 \ 0 } { 1 \ 8 \ 4 } \quad ( e ) \ - 2 \binom { 0. 2 } { 1. 3 }$$

$$2. \quad & \text{Given } A = \begin{pmatrix} 0 & 2 \\ - 1 & 5 \end{pmatrix} \text{and } B = \begin{pmatrix} 3 & 1 2 \\ 0 & 9 \end{pmatrix}, \, \text{find} \\ & \text{(a) } 2 A = \begin{pmatrix} ( b ) & - 5 B & ( c ) & \frac { 1 } { 3 } B & ( d ) & 3 A + 2 B & ( e ) & 4 B - 2 A \end{pmatrix}$$

$$\left ( \text{ii} \right ) \begin{pmatrix} 1 & x \\ 5 & 3 \end{pmatrix} - 2 \begin{pmatrix} w & 0 \\ 1 & z \end{pmatrix} = \begin{pmatrix} 7 & 8 \\ y & 1 \end{pmatrix}$$

$$\begin{pmatrix} 1 & x \\ 5 & 3 \end{pmatrix} - \begin{pmatrix} 2 w & 0 \\ 2 & 2 z \end{pmatrix} = \begin{pmatrix} 7 & 8 \\ y & 1 \end{pmatrix}$$

$$\binom { 1 - 2 w } { 5 - 2 } = \binom { x - 0 } { 3 - 2 z } = \binom { 7 } { y - 1 }$$

On  equating  the  corresponding elements,

$$\begin{matrix} 1 - 2 w = & 7 & & x - 0 = 8 \\ - 2 w = & 6 & & x = 8 \\ & w = - 3 \end{matrix}$$

$$\omega _ { z } & = 1 \\ \omega _ { z } & = - 2$$

$$\begin{matrix} 5 - 2 = y & & & 3 - 2 z = 1 \\ y = 3 & & & - 2 z = - 2 \\ & & & z = 1 \end{matrix}$$

3. Express each of the following as a single matrix.

$$( \mathbf a ) \, \mathbf a _ { 2 } \binom { 1 } { 5 } + \binom { 4 } { 0 } \, \sum \, ( \mathbf b ) \, \binom { 1 } { 0 } \, \frac { 9 } { 4 } \, \mathbf b _ { 2 } \, 3 \binom { 0 } { 5 } \, \frac { 2 } { - 1 } \, \sum \, ( \mathbf c ) \, \mathbf 5 ( 2 \, \mathbf 8 ) \, + \, 4 ( 1 \, \mathbf 0 )$$

$$( \text{d} ) \, \begin{pmatrix} 2 & 5 \\ 8 & 1 0 \end{pmatrix} - 2 \begin{pmatrix} 0 & 1 \\ - 6 & 3 \end{pmatrix} \quad ( \text{e} ) \, \begin{pmatrix} 1 & 3 \\ 2 & 4 \\ 5 & 1 0 \end{pmatrix} - 2 \begin{pmatrix} 2 & 0 \\ 1 & 6 \\ 0 & 7 \end{pmatrix} \quad ( \text{f} ) \, \begin{pmatrix} 3 \\ 4 \\ 5 \end{pmatrix} + 2 \begin{pmatrix} 5 \\ 0 \\ 1 \end{pmatrix} - \begin{pmatrix} 3 \\ 4 \end{pmatrix}$$

4. Find the value of the unknowns in each of the following:

$$& \text{Find the value of the unknowns in each of the following: } \\ & ( a ) \begin{pmatrix} x \\ 2 \end{pmatrix} + \begin{pmatrix} 1 \\ y \end{pmatrix} = \begin{pmatrix} 5 \\ 7 \end{pmatrix} & ( b ) & 2 ( p ) & 3 ) + ( 1 & 4 ) = ( 3 & q ) \\ \\ & ( c ) \begin{pmatrix} a & 3 \\ b & 2 \end{pmatrix} + \begin{pmatrix} 1 & c \\ 5 & d \\ d \end{pmatrix} = \begin{pmatrix} 1 1 & 1 3 \\ 1 5 & 1 2 \end{pmatrix} & ( d ) & \begin{pmatrix} p & 2 \\ 1 & q \\ 1 & q \end{pmatrix} - \begin{pmatrix} 5 & 8 \\ s & 6 \end{pmatrix} = \begin{pmatrix} 7 & r \\ 4 & - 5 \end{pmatrix} \\ \\ & ( e ) & 4 \begin{pmatrix} 2 \\ y \end{pmatrix} - 5 \begin{pmatrix} 1 \\ 0 \end{pmatrix} = \begin{pmatrix} x \\ 2 0 \end{pmatrix} & ( f ) & 3 \begin{pmatrix} x \\ 1 \\ 8 \end{pmatrix} + 2 \begin{pmatrix} 3 \\ - 5 \\ z \end{pmatrix} = \begin{pmatrix} 1 5 \\ y \\ 1 2 \end{pmatrix} \\ \\ & ( g ) \begin{pmatrix} 3 a & 2 b \\ 1 & - 5 \end{pmatrix} + \begin{pmatrix} 4 & 1 \\ c & 7 \end{pmatrix} = \begin{pmatrix} a & 1 1 \\ q & 1 d \end{pmatrix} & ( h ) & \begin{pmatrix} 2 \\ 1 \end{pmatrix} + 3 \begin{pmatrix} 4 \\ x \end{pmatrix} = \begin{pmatrix} 2 x \\ y \end{pmatrix} \\ \\ \end{pmatrix}$$

## Multiplication of matrices

Two matrices can be multiplied if the number of columns in the first matrix is equal to the number of rows in the second matrix.

The product of an m × n matrix and an n × k matrix results in a matrix whose order is m × k .

<!-- image -->

Note: AB means matrix A multiplied by  matrix B.  BA means  matrix B multiplied by matrix A .

| Order of A   | Order of B   | Product of A and B   | Order of AB   |
|--------------|--------------|----------------------|---------------|
| 2 × 3        | 3 × 1        | Possible             | 2 × 1         |
| 1 × 2        | 1 × 2        | Not possible         | -             |
| 3 × 1        | 1 × 3        | Possible             | 3 × 3         |

<!-- image -->

## EXERCISE 9.5

1. Copy and complete the following table.
2. Copy and complete the following table.

| Order of A   | Order of B   | Product of A and B   | Order of AB   |
|--------------|--------------|----------------------|---------------|
| 1 × 2 (a)    | 2 × 3        | Possible             | … × …         |
| 2 × 3 (b)    | … × 3        | Not possible         | -             |
| 1 × 1 (c)    | 1 × 4        |                      |               |
| 2 × 2 (d)    | 5 × 2        |                      |               |
| 4 × 5 (e)    | 5 × 4        |                      |               |
| 2 × … (f )   | 2 × …        | Possible             | 2 × 1         |

<!-- image -->

<!-- image -->

<!-- image -->

| Matrix A            | Matrix B        | Order of matrix A   | Order of matrix B   | Order of matrix AB   |
|---------------------|-----------------|---------------------|---------------------|----------------------|
| (a) 2 3 ( (         | ( ( 1 6         |                     |                     |                      |
| (b) ( ( 1 3 7 4 8 5 | 5 7 9 6 8 1 ( ( |                     |                     |                      |
| (c) ( ( 4 5         | 3 4 0 ( (       |                     |                     |                      |
| (d) ( ( 8 1 2 7     | ( ( 6 9 7 0     |                     |                     |                      |
| (e) ( ( 5 1 6 2 5 1 | 3 5 7 ( (       |                     |                     |                      |

## Matrix Multiplication: step by step

<!-- image -->

This  is  the  product  of  a  1  ×  3  matrix  and  a  3  ×  1  matrix,  which  is  possible  and  results  in a 1 × 1 matrix.

When multiplying a row by a column, the result is obtained by adding the product of the first element in the row by the first element in the column, the  second element in the row by the second element in the column and so on as shown below.

In this image, we can see a ladder and water.

<!-- image -->

Thus

<!-- image -->

$$\text{Next consider } ( 1 \ 2 \ 3 ) \begin{pmatrix} 4 & 9 \\ 5 & 8 \\ 6 & 0 \end{pmatrix}$$

Now, we have the product of a 1 × 3 matrix and a 3 × 2 matrix, which is possible and results in a 1 × 2 matrix.

$$\left ( 1 \ 2 \ 3 \right ) \left ( \begin{matrix} 4 & 9 \\ 5 & 8 \\ 6 & 0 \end{matrix} \right ) & = \left ( ( 1 \times 4 ) + ( 2 \times 5 ) + ( 3 \times 6 ) \quad ( 1 \times 9 ) + ( 2 \times 8 ) + ( 3 \times 0 ) \right ) \\ & = \left ( 3 2 \quad 2 5 \end{matrix} \right )$$

## Example

$$\begin{array} { c } \text{EA} \, \i p \, \colon = \\ \text{Given } A = ( 2 \, 3 ) \, B = \left ( \begin{matrix} - 1 \\ 4 \end{matrix} \right ) \, C = \left ( \begin{matrix} 5 & 0 \\ 1 & 2 \end{matrix} \right ) \, \text{calculate the following products where possible:} \\ \left ( \text{a} \right ) A B = \left ( \text{b} \right ) A C \quad \left ( \text{c} \right ) C B \quad \left ( d \right ) C A \quad \left ( \text{e} \right ) C ^ { 2 } \end{array}$$

## Solution

$$\begin{smallmatrix} ( a ) \, A B = ( 2 & 3 ) & \binom { - 1 } { 4 } \end{smallmatrix}$$

$$& = \, ( 2 \times - 1 + 3 \times 4 ) \\ & = \, ( 1 0 )$$

$$\begin{pmatrix} \left ( b \right ) A C = \left ( 2 & 3 \right ) & \left ( \begin{matrix} 5 & 0 \\ 1 & 2 \end{matrix} \right ) \end{pmatrix}$$

$$= ( 2 \times 5 + 3 \times 1 \quad 2 \times 0 + 3 \times 2 )$$

= (13   6)

$$( \mathbf c ) \, C B & = \begin{pmatrix} 5 & 0 \\ 1 & 2 \end{pmatrix} \begin{pmatrix} - 1 \\ 4 \end{pmatrix} \\ & = \begin{pmatrix} 5 \times - 1 & + & 0 \times 4 \\ 1 \times - 1 & + & 2 \times 4 \end{pmatrix} \\ & = \begin{pmatrix} - 5 \\ 7 \end{pmatrix}$$

Note: A 1 × 2 matrix multiplied by a 2 × 1 matrix results in a 1 × 1 matrix.

Note: A 1 × 2 matrix multiplied by a

2 × 2 matrix results in a 1 × 2 matrix.

Note: A 2 × 2 matrix multiplied by a

2 × 1 matrix results in a 2 × 1 matrix.

$$\left ( \text{d} \right ) C A = \left ( \begin{matrix} 5 & 0 \\ 1 & 2 \end{matrix} \right ) \, \left ( 2 \ 3 \right )$$

CA is not possible as the number of columns in C is not equal to the number of rows in A .

$$( \text{e} ) \, C ^ { 2 } & \, = \, \begin{pmatrix} 5 & 0 \\ 1 & 2 \end{pmatrix} \begin{pmatrix} 5 & 0 \\ 1 & 2 \end{pmatrix} \\ & \, = \, \begin{pmatrix} 5 \times 5 \, + \, 0 \times 1 & 5 \times 0 \, + \, 0 \times 2 \\ 1 \times 5 \, + \, 2 \times 1 & 1 \times 0 \, + \, 2 \times 2 \end{pmatrix} \\ & \, = \, \begin{pmatrix} 2 5 & 0 \\ 7 & 4 \end{pmatrix}$$

Note: C 2 = C × C

## Multiplication of 2 × 2 matrices

$$\text{Multiplication of $2x2matrices} \\ \text{Consider} \quad \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix} \begin{pmatrix} 5 & 7 \\ 6 & 8 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 7 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 3 & 4 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 2 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pmatrix} 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1 } & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 | \end{pagma}{1} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pagma}{1} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 2 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pagma}{1} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 | \end{pagma}{1} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} &= & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 \end{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 2 & 3 & 4 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 \end{pmatrix} & = & \begin{pagma}{1} & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 & 4 & 2 & 3 & 4 \\ 1 & 3 &$$

$$\begin{pmatrix} \widetilde { \infty } ^ { \text{Activity 1} } \\ \text{Find } \begin{pmatrix} 5 & 6 \\ 7 & 8 \end{pmatrix} \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix}. \\ \text{Is } \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix} \begin{pmatrix} 5 & 6 \\ 7 & 8 \end{pmatrix} = \begin{pmatrix} 5 & 6 \\ 7 & 8 \end{pmatrix} \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix}?$$

Is matrix multiplication commutative?

Note: A 2×2 matrix multiplied by a 2×2 matrix results in a 2×2 matrix.

<!-- image -->

## EXERCISE 9.6

1. Calculate the following matrix products where possible.

$$( \mathbf a ) \ \left ( 1 \ \ 2 \ \ 3 \right ) \binom { 3 } { 2 }$$

$$\Gamma _ { 2 } ( 3 ) \binom { 3 } { 2 } \int ( \mathbb { h } ) \, \left ( \begin{matrix} 4 & 1 \\ 3 & 5 \end{matrix} \right ) \binom { 0 } { 2 } \int ( \mathbb { h } ) \, \left ( \begin{matrix} 7 \\ 8 \end{matrix} \right ) \binom { 1 } { 0 } \right )$$

$$( \text{d} ) \ ( 5 \ 2 \ 3 ) \begin{pmatrix} 2 \ - 1 \\ 7 \ 0 \\ 0 \ - 2 \end{pmatrix} \quad ( \text{e} ) \begin{pmatrix} 6 \ 2 \ 1 \\ 7 \ 3 \ 0 \end{pmatrix} \begin{pmatrix} 5 \ 2 \\ 1 \ 3 \end{pmatrix} \quad ( \text{f} ) \begin{pmatrix} 5 \ 2 \\ 1 \ 3 \end{pmatrix} \begin{pmatrix} 6 \ 2 \ 1 \\ 7 \ 3 \ 0 \end{pmatrix}$$

$$\begin{pmatrix} 2 & 0 \\ 1 & 6 \end{pmatrix} \begin{pmatrix} 4 & 5 \\ - 3 & 1 \end{pmatrix} \quad \begin{pmatrix} 1 0 \\ 2 \\ 1 \end{pmatrix} \begin{pmatrix} ( 1 & 0 & 3 ) \quad \begin{pmatrix} ( i ) \end{pmatrix} \begin{pmatrix} 2 & 5 & 5 \\ 7 & 1 & 3 \\ 0 & 0 & 1 \end{pmatrix} \begin{pmatrix} 5 & 8 \\ 9 & 7 \end{pmatrix}$$

$$2. \quad & \text{Given} \, A = \left ( 2 \ 3 \right ) \, \, B = \binom { 5 } { - 1 } \, \, C = \binom { 1 } { 0 } \, \, D = \binom { 2 } { 3 } \, \, E = \binom { 4 \ 9 \ 1 } { 2 \ 1 \ 5 } \, \, F = \binom { 2 } { - 4 } \right ) \\ & \text{Webracket} \, \text{and set with the data and set}$$

Work out where possible:

(a) AB (b) AC

(c) DA

(d) EB

(e) BA

(f) BE

(g) CB

(h) AD

(i) A 2

(j) C 2

$$\begin{array} { c c c } 3. & \text{Given $A=\left(\left(\begin{array} { c c } 2 & 8 \\ 0 & 6 \end{array} \right)\rightarrow \text{ and $B=\left(\left(\begin{array} { c c } 1 & 6 \\ 7 & 9 \end{array} \right)\rightarrow \text{ Find $AB$ and $BA$.} } \end{array}$$

## 4. Work out:

$$\left ( \mathbf a \right ) \left ( \mathbf i \right ) \right ) \left ( \mathbf i ^ { 3 } _ { 6 } \, \mathbf i ^ { 2 } _ { 2 } \right ) \left ( \mathbf i ^ { 2 } _ { 1 } \, \mathbf i ^ { 2 } _ { 2 } \right ) \left ( \mathbf i \mathbf i \right ) \left ( \mathbf i ^ { 2 } _ { 1 } \, \mathbf i ^ { 2 } _ { 2 } \right ) \left ( \mathbf i ^ { 3 } _ { 6 } \, \mathbf i ^ { 2 } _ { 2 } \right )$$

$$\left ( \mathfrak { h } \right ) \left ( \mathfrak { i } \right ) \left ( \begin{matrix} 8 & 1 \\ 0 & 2 \end{matrix} \right ) \left ( \begin{matrix} 2 & - 5 \\ 1 & 3 \end{matrix} \right ) \left ( \begin{matrix} 2 & - 5 \\ 1 & 3 \end{matrix} \right ) \left ( \begin{matrix} 8 & 1 \\ 0 & 2 \end{matrix} \right )$$

$$\left ( \mathfrak { c } \right ) \left ( \mathfrak { i } \right ) \quad \left ( \begin{matrix} 4 & 1 \\ 0 & - 2 \end{matrix} \right ) \left ( \begin{matrix} 5 & 8 \\ - 9 & 3 \end{matrix} \right ) \quad \left ( \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfra \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfrak { i } \mathfring \right )$$

What can you say about matrix multiplication in general?

## Solving matrix equations

A matrix equation is an equation which consists of an unknown matrix.

The unknown matrix can be found by using equal matrices and the properties of addition and subtraction.

## Example

Find the unknown matrix X in each of the following.

$$( \mathbf a ) \ X - \begin{pmatrix} 2 & 6 \\ 1 & 0 \end{pmatrix} = \begin{pmatrix} 3 & - 4 \\ 5 & 7 \end{pmatrix} & ( \mathbf b ) \ ( 4 & 8 & 2 ) + 2 X = ( 1 0 & 1 2 & 0 )$$

$$\begin{array} {$$

$$( b ) \ ( 4 \ 8 \ 2 ) + 2 X = ( 1 0 \ 1 2 \$$

2

X

= (10   12   0) - (4   8   2)

2

X

= (6   4   -2)

$$X = \frac { 1 } { 2 } \left ( 6 \ 4 \ - 2 \right )$$

X

= (3   2   -1)

<!-- image -->

Solve the following matrix equations.

$$\begin{array} { c } & & \text{Solve the following matrix equations.} \\ &$$

$$\begin{pmatrix} 6 & 1 \\ - 5 & 3 \end{pmatrix}$$

$$( \text{i} ) \ \frac { 1 } { 2 } X + ( 1 \ 6 ) = ( 5 \ 8 )$$

$$( h ) \, \begin{pmatrix} 5 \\ 3 \end{pmatrix} - 3 X = \begin{pmatrix} 2 0 \\ - 6 \end{pmatrix}$$

$$( j ) \ 5 \begin{pmatrix} 0. 2 & 0. 1 & 1 \\ 1. 2 & 7. 5 & 4. 1 \end{pmatrix} + 2 X = \begin{pmatrix} 4. 4 & 0. 7 & 5. 5 \\ 3. 6 & 3. 5 & 8. 1 \end{pmatrix}$$

## Summary

- A matrix is a rectangular array of numbers.
- The numbers are called as the elements of the matrix.
- A =                        is an example of a matrix which has 2 horizontal rows and 3 vertical ( ( 1 4 2 5 3 6

columns . Thus the order of the matrix A is 2 × 3.

- There are several types of matrices.  For example, null or zero matrix, square matrix, diagonal matrix, identity matrix and equal matrices.
- For  matrix addition and subtraction ,  the  matrices  involved  must  be  of  the same order.
- Addition or subtraction is  performed by adding or subtracting the corresponding elements.
- A scalar is a real number.
- Scalar  multiplication  of  a  matrix  is  performed  by  multiplying  each  element  by the scalar.

$$\Big | \quad \begin{array} { c c c } \text{the scalar.} \\ \text{Example: 2} \begin{pmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \end{pmatrix} = \begin{pmatrix} 2 & 4 & 6 \\ 8 & 1 0 & 1 2 \end{pmatrix}$$

- Two matrices can be multiplied if the number of columns in the first matrix is equal to the number of rows in the second matrix.
- The product of an m × n matrix and an n × k matrix results in a matrix whose order is m × k .
- Multiplication of two 2 × 2 matrices is performed as follows:

$$\begin{pmatrix} a & d \\ c & b \end{pmatrix} \begin{pmatrix} e & f \\ g & h \end{pmatrix} = \begin{pmatrix} a e + d g & a f + d h \\ c e + b g & c f + b h \end{pmatrix}$$

- In general, the following rules are true for any two matrices A and B :
- (a) A + B = B + A
- (b) A -B ≠ B -A
- (c) AB ≠ BA
- In a matrix equation , the unknown matrix can be found by using equal matrices and the properties of addition and subtraction.

## Continuous Assessment

1. Fill in the blanks.

- (a) In a matrix, the horizontal entries are called \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and the vertical entries are called \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (b) The order of the matrix              is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (c) In a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ matrix, all the elements are zero.

- (d)   A square matrix has the\_\_\_\_\_\_\_\_\_\_\_\_\_\_ number of rows and \_\_\_\_\_\_\_\_\_\_\_\_\_.

- (e) Two  matrices  can  be  multiplied  if  the  number  of  columns  in  the  first  matrix  is

- \_\_\_\_\_\_\_\_\_\_\_\_ to the number of \_\_\_\_\_\_\_\_\_\_\_\_\_ in the second matrix.

- (f) The product of an m × n matrix and an n × k matrix results in a matrix whose order is\_\_\_\_\_\_\_\_\_\_.

(

(

4

7

$$2. & \quad \text{if } P = \begin{pmatrix} 3 & 6 \\ - 2 & 0 \end{pmatrix} \text{ and } Q = \begin{pmatrix} 1 & 1 0 \\ 5 & 0 \end{pmatrix}, \text{find} \\ & \quad ( a ) \, P + Q & \quad ( b ) \, 2 P & \quad ( c ) \, Q - 2 P & \quad ( d ) \, \frac { 1 } { 5 } \, Q & \quad ( e ) \, P Q & \quad ( f ) \, Q P$$

$$3. \quad \text{if} \, A = \, \begin{pmatrix} 0 & 2 \\ 1 & 0 \end{pmatrix} \, \text{and} \, B = \, \begin{pmatrix} 0 & 1 \\ 2 & 3 \end{pmatrix}, \text{find}$$

- (i) A + 2 B ,
- (ii)   the matrix C such that A + C = B ,
- (iii) A 2 .
4. Find the matrix M such that  3 M + =  2                     . ( ( 9 8 7 2 ( ( 6 2 1 4
5. Given that                      +                    =                      , find the value of x and of y . ( ( 3 -1 1 y ( ( x -1 3 4 ( ( 1 0 2 1

6. Express 4              - 5             as a single matrix. ( ( 5 1 ( ( 0 -4
7. Find the value of x and of y if  ( x - 4     5 y ) = (0   -5).
8. Find the matrix M which is such that 2 M -                      = 3 ( ( 0 6 4 8 ( ( 2 0 0 -4

$$9. \quad \text{Given} \, C = \begin{pmatrix} 1 & x \\ 6 & 1 0 \end{pmatrix} \text{ and} \, D = \begin{pmatrix} 4 & 2 \\ 1 & y \end{pmatrix}.$$

$$\text{if } C + D = \left ( \begin{array} { c c } 5 & 8 \\ 7 & 3 \end{array} \right ), \, \text{find the value of } x \, \text{and of } y.$$

10.   Obtain the matrix products, where possible.

$$& ( \tt a ) \ ( 2 \ 8 ) \binom { 1 } { 6 } & & ( \tt b ) \binom { 2 } { 4 } & & ( \tt b ) \binom { 0 } { 2 } & & ( \tt c ) \, \binom { 7 } { 8 } \binom { 2 } { 0 } & & \\ & ( \tt d ) \ ( 8 \ 1 \ 6 ) \binom { 2 } { 0 } & & ( \tt d ) \, \binom { 1 0 } { 5 \ 3 \ 0 } & & ( \tt e ) \, \binom { 1 0 \ 1 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \ 4 \$$

## VOLUME AND CAPACITY

## Learning Objectives

## By the end of this chapter,  you should be able to:

- find the volume of a cylinder and a right prism.
- solve problems involving volume of a cylinder and a right prism.
- distinguish among different units of capacity (mL, cL, L).
- convert units of capacity (mL, cL, L).
- calculate capacity of given containers.
- solve problems involving capacity and volume.

## Volume in Real life

In everyday life, volume is used as a measurement of the space an object occupies for example cupboards, refrigerators or water tanks.

<!-- image -->

<!-- image -->

<!-- image -->

## Solid objects

Also you learnt in Grade 8, that volume of cuboid = length x width x height

<!-- image -->

<!-- image -->

l

<!-- image -->

<!-- image -->

RECALL

In Grade 8 you learnt the definition of volume of an object as the amount of space it occupies.

<!-- image -->

KEY TERMS

- Volume
- Capacity
- Right prisms
- Cylinder
- Solids
- cm 3 ,m 3
- Litres
- Centilitres
- Millilitres

In this chapter, you are going to learn about the volume and capacity of a cylinder and a right prism.

Volume of cube and cuboid  = length x width x height = area of base (shaded) x height

Note: The bases of the cube and the cuboid are shaded.

<!-- image -->

cuboid

<!-- image -->

The above formula can aslo be used to find the volume of a right prism and a cylinder.

## RIGHT PRISM

A right prism can be defined as a three-dimensional figure having a uniform cross section (shaded in the diagrams) .

<!-- image -->

Triangular prism

<!-- image -->

Pentagonal prism

Rectangular prism

<!-- image -->

Hexagonal prism

<!-- image -->

## Example of non-right prism

<!-- image -->

<!-- image -->

## Examples of 3D shapes that are NOT Prisms Example of 3D shapes that are NOT prisms

<!-- image -->

<!-- image -->

<!-- image -->

Volume of a right prism

<!-- image -->

Since a prism has uniform cross-sections, it can be represented by a stack of many slices as shown below.

## EXERCISE 10.1

1. Which of the following are right prisms?

In this image, we can see a wooden object. There are some objects on the surface.

<!-- image -->

## 2. Which of the following are NOT right prisms?

In this image, we can see a diagram.

<!-- image -->

Volume of a right prism

## Since a prism has uniform cross-sections, it can be represented by a stack of many slices as Volume of a right prism

shown below.

Since a prism has uniform cross sections, it can be represented by a stack of many slices as shown below.

In this image, we can see a diagram.

<!-- image -->

Volume of prism = Area of cross section × Length Volume of prism = Area of cross section × Length

= A x L

= AL

Where A is the area of cross section and L is the length of the prism.

## Volume of a triangular prism

Volume of triangular prism of Length L

- = Area of cross section x Length
- = ( 1 2 x base x height of triangle) x Length
- = ( 1 2 x b x h ) x L

<!-- image -->

Note: The cross section is a right-angled triangle.

b

## Example 1

Calculate the volume of the prism given below.

In this image, we can see a diagram. There is a line in the middle of the image.

<!-- image -->

<!-- image -->

## Solution (a)

Volume of prism

- = 1 2 x b x h x L

$$= \frac { 1 } { 2 } \, x \, 3 \, x \, 4 \, x \, 8$$

=  48 cm 3

4 cm

<!-- image -->

- = 1 2 (sum of parallel sides) x height
- = 1 2 ( 5 + 8) x 4
- = 1 2 x 13 x 4

= 13 x 2

= 26 cm 2

## Solution (b)

Area of trapezium

<!-- image -->

Volume of prism = area of trapezium x length

= 26 x 12

= 312 cm 3

Note: Generally, the base of a prism can also be considered as its cross section and height, H .

So we can write

Volume of prism

- = area of cross section x height

<!-- image -->

<!-- image -->

## EXERCISES 10.2

1. A right prism has a square base of side 5 cm and a height of 12 cm. Calculate its volume.
2. The  diagram  shows  a  right  prism  whose  cross  section  is  a  right-angled  triangle ABC where angle B = 90 0 , BC = 5 cm and AC = 13 cm.
3. (a)  Find the length of AB .
4. (b)  Find area of triangle ABC.
5. (c)  Given that the length of prism is 20 cm, calculate its volume.

<!-- image -->

5 cm

<!-- image -->

3. Find the volume of the following prisms.
4. Calculate the volume of the following.

The image consists of a graph with two axes labeled as "a" and "b". The graph is a graph of a function, specifically a parabola, with a minimum value at the bottom of the graph. The graph is a parabola with a minimum value of 25 units on the x-axis and a maximum value of 25 units on the y-axis. The graph is drawn with a dashed line, indicating that the graph is not a straight line.

The graph is labeled as follows:
- "a" is the x-axis, and "b" is the y-axis.
- The graph is a parabola with a minimum value of 25 units on the x-axis and a maximum value of 25 units on the y-axis.

### Analysis and Description:
1. **Graph Type**: The graph is a parabola.
2. **Minimum Value**: The graph has a minimum value of

<!-- image -->

<!-- image -->

<!-- image -->

(b)

<!-- image -->

(e)

<!-- image -->

<!-- image -->

<!-- image -->

5. The diagram shows a container with uniform cross section in the form of a trapezium ABCD. AB is  parallel  to DC and dimensions shown are in metres. Given that its length is 2 m, calculate its volume in (a) m 3 (b) cm 3 .
6. A swimming pool in the form of a prism is 24 m long, 15 m wide, 1 m deep at the shallow end and 8 m at the deep end. PQRS is in form of a trapezium with PQ parallel to SR .
3. (a)   Calculate the length of PS.
4. (b) Calculate the volume of the pool.
7. The diagram shows a right prism with a triangular cross-section XYZ with angle XYZ = 90 0 , angle = 53 0 and = 6 m.
6. XZY YZ [Given sin 53 0 = 0.8, cos 53 0 = 0.6, tan 53 0 = 1.3]
7. (a)  Calculate the length of XY.
8. (b)   Given that the length of the prism is 15 m, calculate its volume.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Volume of a cylinder

A cylinder is a 3D figure having a circular cross section.

<!-- image -->

In this image we can see a few cylinders.

<!-- image -->

Volume of cylinder = Area of cross section x height

= area of circle x height

= πr 2 x h

= πr 2 h

## Example 1

Find the volume of a cylinder having radius 5 cm and height 10 cm. (Take π to be 3.14.)

## Solution

r = 5 cm , h = 10 cm and π = 3.14

Volume of cylinder   = πr 2 h

=  3.14 x 5 x 5 x 10

=  785 cm 3

<!-- image -->

## Example 2

Calculate the volume of a pipe in form of a cylinder of length 2 m and internal radius 3 cm. (Leave your answer in terms of π )

In this case, we can use the formula

Volume  =  Area of cross-section × length

= πr 2 x l

= π x 3 x 3 x 200

=  1800 π

<!-- image -->

## Example 3

The  volume  of  a  cylinder  of  radius  3 1 2 cm  is  770  cm 3 .  Calculate  its  perpendicular  height. (Take π = 22 )

$$7$$

Volume of cylinder = πr 2 h

$$\frac { 2 2 } { 7 } \times \frac { 7 } { 2 } \, \times \frac { 7 } { 2 } \times \mathfrak { h } \ = 7 7 0$$

$$1 1 \times \frac { 7 } { 2 } \times h \ = 7 7 0$$

$$\mathbf h \ = \frac { 7 7 0 \, x \, 2 } { 1 1 \, x \, 7 }$$

h  = 20 cm

<!-- image -->

<!-- image -->

## EXERCISES 10.3

1. Calculate the volume of each of the following cylinders. (Leave your answer in terms of π )

<!-- image -->

<!-- image -->

<!-- image -->

(d)

<!-- image -->

2. Measurements of cylinders are given below. Copy and complete the following table.
3. A hollow pipe has internal diameter 1m and length 10m. Calculate the internal volume of the pipe. (Take π to be 3.14.)
4. A cylinder of height 21 cm has volume of  1650 cm 3 . Taking π to be  22 7 , calculate the radius of base of the cylinder.
5. A cylinder has base radius 7 cm and the volume is 1540 cm 3 . Taking to be  22 7 ,  find the height of the cylinder.

|     | Radius of base   | Height   | π    | Volume   |
|-----|------------------|----------|------|----------|
| (a) | 5mm              | 8mm      | 3.14 |          |
| (b) | 3 1 2 cm         | 7 cm     | 22 7 |          |
| (c) | 20 cm            | 2m       | 3.14 |          |
| (d) | 70mm             | 14 cm    | 22 7 |          |
| (e) | 1 2 m            | 300 cm   | 3.14 |          |

## CAPACITY

Earlier,  you  learnt  that  volume  is  the  quantity  of  space  occupied  by  an  object  and  the  units are cm 3 and m 3 . Capacity is the quantity of liquid that can fill the space and is measured in litres (L), centilitres (cL) and millilitres (mL).

Equivalence between units used for capacity

Note:

1 litre (L) = 100 centilitres (cL)

1 litre (L) = 1000 millilitres (mL)

1 litre (L) = 1000 cm 3

<!-- image -->

Can you find the equivalence between centilitres and millilitres?

## Capacity in real Life

In everyday life, capacity can be seen on containers of water, milk, juice, oil and other liquids.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Calculation of Capacity

Consider a cube of side 1 cm .

Volume of cube   = 1 x 1 x 1

= 1 cm 3

<!-- image -->

Space occupied by the cube = 1 cm 3 .

The space of 1 cm 3 can be filled by 1 mL of liquid. This means that the volume of 1 cm 3 is equivalent to a capacity of 1 mL.  Therefore, to find the capacity of a container we need to find its volume.

## Equivalence of volume and capacity

| Volume   | Capacity   | Capacity   | Capacity       |
|----------|------------|------------|----------------|
| cm 3     | mL         | cL         | L              |
| 1        | 1          | 1 10 = 0.1 | 1 1000 = 0.001 |
| 10       | 10         | 1          | 1 100 = 0.01   |
| 100      | 100        | 10         | 1 10 = 0.1     |
| 1000     | 1000       | 100        | 1              |
| 10000    | 10000      | 1000       | 10             |

<!-- image -->

Complete the table below.

| Volume   | Capacity   | Capacity   | Capacity    |
|----------|------------|------------|-------------|
| cm 3     | mL         | cL         | L           |
| 2000     |            | 200        |             |
|          | 3500       |            | 3.5 = 3 1 2 |
| 100      |            | 10         |             |
|          | 250        |            | 0.25 = 1 4  |
| 5300     |            |            | 5.3= 5 3 10 |

<!-- image -->

## Convert the following volumes to the units of capacity shown in brackets.

- (a)  3000 cm 3 (L) (b)  4500 cm 3

(cL)

- (c)  750 cm 3 (mL)

(d) 900  cm 3 (L)

- (e)  10600 cm 3 (mL)  (f)   500 cm 3 (cL)

- (g)  1 125 cm 3 (mL)

(h) 10  cm 3 (mL)

- (i)  2525 cm 3 (L) (j)   5775 cm 3  (cL)

## Capacity of containers (calculations)

## Example 1

Find the volume and capacity of the following containers.

(a) CUBE

(b) CUBOID

<!-- image -->

<!-- image -->

- (c) CYLINDER

(Take π to be 3.14.) ( water tank)

<!-- image -->

## Solution

- (a) Volume

- = 10 x 10 x 10

= 1000 cm 3

Capacity

= 1000 mL

= 100 cL

= 1 L

- (c) Volume  =

πr

2

h

- =  3.14 x 50 x 50 x 200

- =  1 570 000 cm 3

- =  1 570 000 mL

- =  1570 L

- (b) Volume

- =   20 x 10 x 30

- =   6000 cm 3

Capacity

- =   6000 mL

- =   600 cL

- =  6 L

<!-- image -->

- (a) For the following containers, calculate (i) the volume in cm 3 and (ii) the capacity giving your answers in litres.

(a)

<!-- image -->

In this image, we can see a cube.

<!-- image -->

- (c) (Take π to be 3.14.)

<!-- image -->

(e)  (Take π  to be  22 7 .)

<!-- image -->

In this image, we can see a diagram. There is a circle and a line.

<!-- image -->

(f) (Base area = 30 cm 2 .)

<!-- image -->

## Problems involving capacity and volume

## Example 1

A cylinder with base radius 7 cm and height 50 cm is half full with water.  Taking π to be  22 7 , calculate the number of litres of water it contains.

## Solution

Volume of water  = 2

$$\overset { \ } { \rho } \text{r} \ = & \ \pi r ^ { 2 } \ h \\ \ = & \ \frac { 2 2 } { 7 } \, \times \, 7 \, \times \, 7 \, \times \, 2 5 \\ \ \underset { \ e o r \, \infty \, \dots \, \frac { 3 } { 3 } } { \ e o r \, \infty \, \dots \, \frac { 3 } { 3 } }$$

= 3850 cm 3

= 3850 mL

= 3.85 L

<!-- image -->

## Example 2

The diagram shows a water tank in the form of a cuboid with the given dimensions given (see diagram).

- (a) Given that it is three quarters full, show that it contains 90 litres of water.
- (b) (i)   After  use,  the  level  of  water  goes  down  by  10 cm, calculate the number of litres of water used.
- (ii)  Calculate the number of litres of water remaining.

## Solution

(a) Volume of Cuboid  = 50 x 40 x 60

= 120 000 cm 3

Capacity  = 120 000 mL

= 120 000 1000

= 120 litres

Three quarters full

=  3 4 x 120

= 90 litres

(b) (i) Volume of water used   = 50 x 40 x 10

= 20 000  cm 3

Water used

= 20 000 mL

= 20 L

(ii) Remaining

= 90 - 20

= 70 litres

<!-- image -->

<!-- image -->

1. Copy and complete the following table in which the dimensions of rectangular tanks are given.
2. A cylindrical container with base radius 20 cm contains juice to a height of 50 cm.
3. (a)  Taking π to be 3.14, calculate the capacity of juice in the container  (i) in mL and (ii) in L.
4. (b)  Calculate the number of cups each of capacity 20 mL which can be filled using all the juice in the container.
3. A rectangular water tank of length 30 cm and width 20 cm contains 15 litres of water. Calculate the height of water in the tank.
4. A cylindrical can having a diameter of 14 cm and contains 1.54 litres of fruit juice. Taking π to be  22 7 , calculate the depth of the fruit juice in the can.
5. A rectangular tank of length 0.6 m and width 0.4 m contains 72 litres of water. (a) Calculate the height of water in the tank. (b) 24 litres of water are added in the tank, find the new height of water in the tank.

|     |         |       |        |        | Capacity   | Capacity   | Capacity   |
|-----|---------|-------|--------|--------|------------|------------|------------|
|     | Length  | Width | height | volume | mL         | L          | cL         |
| (a) | 25 cm   | 20 cm | 50 cm  |        |            |            |            |
| (b) | 0.5m    | 0.3m  | 1m     |        |            |            |            |
| (c) | 2 1 2 m | 3 5 m | 2m     |        |            |            |            |
| (d) | 80 cm   | 0.7m  | 1 2 m  |        |            |            |            |

## Summary

Volume of prism = AL or AH Where A is the area of cross section and L = Length

<!-- image -->

<!-- image -->

## Continuous Assessment

## Volume and Capacity

1. How many small cubes are there in each of the following cuboids?
2. The dimensions of cylinders are given in the table below.
3. For each of the prism:
4. (a)  draw the cross section,
5. (b)  calculate the area of cross-section,
6. (c)  calculate the volume.

In this image, we can see a few cubes.

<!-- image -->

|     | Base Radius   | Height   | π    |
|-----|---------------|----------|------|
| (a) | 7 cm          | 10 cm    | 22 7 |
| (b) | 4 cm          | 25 cm    | 3.14 |
| (c) | 0.5m          | 4m       | 3.14 |

Calculate    (a) the volume,

- (b) the capacity, in litres.

In this image, we can see a diagram with a diagram of a box and a diagram of a box.

<!-- image -->

[T ake π =  22 7 ]

<!-- image -->

<!-- image -->

4. A cylindrical can whose base radius is 4 cm contains 704 mL of juice. Taking π to be 22 7 calculate the height of the can. 4 cm
5. A cylinder of height 8 cm has a volume of  77 cm 3 . Taking π to be  22 7 , calculate the radius of base of the cylinder.
6. A cylindrical tank whose area of cross section is 2500 cm 2 contains 200 litres of water when full. Calculate the height of the tank.
4. 7.
5. (b) How many cans of juice, of capacity 500 ml each, can be filled from the container?
6. A cylindrical juice container has a height of 3½ m and radius 1 m. (a) Taking π to be  22 7 , calculate the capacity of the container in litres.
8. The area of cross section and height of right prisms are given in the table below.

<!-- image -->

<!-- image -->

|     | area of cross-section   | Height   |
|-----|-------------------------|----------|
| (a) | 100 cm 2                | 20 cm    |
| (b) | 5m 2                    | 300 cm   |
| (c) | 400 cm 2                | 2m       |

Calculate  (a) the volume and (b) the capacity, in litres.

9. Find the volume and capacity (in litres) of a right prism of height 50 cm whose base is a square of side 25 cm.
10. A right prism has a triangular base whose perpendicular sides are 10 cm and 25 cm. If the prism is 50 cm in length, calculate (a) its volume and (b) its capacity, in litres.
11. A right prism has cross-section in form of a trapezium whose parallel sides have lengths 12 cm and 18 cm and are 20 cm apart. Given that the length of the prim is 2 m,
4. calculate  (a)  its volume and (b) its capacity in litres.
12. A rectangular container whose length is 10 cm and width is 15 cm has an equal volume as a cylindrical container of base radius 7 cm and height 15 cm. Taking π to be  22 7 , calculate the height of the rectangular container.
13. A small toy box has dimensions 5 cm x 5 cm x 6 cm. Toy boxes are packed into a carton of dimension 20 cm x 15 cm x 30 cm. Calculate the number of such toy boxes that will fill the carton completely.

Diagram not drawn to scale

<!-- image -->

<!-- image -->

20 cm

## SURFACE AREA

## Learning Objectives

## By the end of this chapter, you should be able to:

- demonstrate an understanding of nets of a cylinder and a right prism.
- find circumference and area of a circle.
- find the surface area of a cylinder (closed, semi-open and hollow).
- find the surface area of a right prism.
- solve problems involving surface area of a cylinder and a right prism.

In grade 8, you learnt about the net of a cube and of a cuboid. In this chapter, you are going to learn about the net of a cylinder and of a right prism and how to use them to calculate the total surface area.

Surface Area

<!-- image -->

## KEY TERMS

<!-- image -->

- Net
- Surface area
- Cylinders

## Cylinders in Real Life

- Prisms
- Curved surface

## CHECK THAT YOU CAN:

In this image, we can see a few cylinders. There is a metal object.

<!-- image -->

Cylinders can be solid, open at one end or hollow.

- Calculate surface area of a cube and a cuboid.

<!-- image -->

Find out some more examples of cylinders in your daily life and state whether they are closed, open at one end or hollow.

Chapter 11 -

## The Cylinder

A cylinder is a 3D figure having a circular cross section.

The image consists of a geometric figure with various points and lines. Here is a detailed description of the image:

### Description of the Image:
1. **Points and Lines**:
   - **Points**: There are five points marked on the image.
   - **Lines**: There are two lines and two points.
   - **Points on the Line**: The line connecting the points is labeled as "r".
   - **Points on the Line**: The line connecting the points is labeled as "h".
   - **Points on the Line**: The line connecting the points is labeled as "l".
   - **Points on the Line**: The line connecting the points is labeled as "r".
   - **Points on the Line**: The line connecting the points is labeled as "l".
   - **Points on the Line**: The line connecting the points is labeled as "r".
   - **Points on the Line**: The line connecting the points is labeled as "l".
   -

<!-- image -->

The axis is vertical.

In this image, we can see a diagram of a cylinder. There is a line on the diagram. We can see a text on the image.

<!-- image -->

The axis is not vertical.

## The net of a right cylinder

The net of a cylinder consists of three parts: one circle at the base and another circle at the top. A rectangle gives the curved surface.

The image is a diagram of a surface with two curves. The surface is labeled as "Cruised Surface" and "Base". The "Cruised Surface" curve is a curved surface, while the "Base" curve is a straight surface. The curves are connected by a line.

### Description of the Objects in the Image:
1. **Cruised Surface**:
   - The surface is a curved surface.
   - The curve is a straight surface.

2. **Base**:
   - The surface is a straight surface.
   - The curve is a curved surface.

### Analysis:
- **Cruised Surface**:
  - The surface is curved.
  - The curve is a straight surface.

- **Base**:
  - The surface is a straight surface.
  - The curve is a curved surface.

### Relevant Knowledge:
- **Curved Surfaces**:
  - Curved surfaces are surfaces that have a non-

<!-- image -->

<!-- image -->

## DID YOU KNOW

When the two ends are exactly over each  other  and  the  axis  is  at  right angle to the base, it is called a 'right cylinder'.  If  one  base  is  displaced sideways and the axis is not at right angle  to  the  base,  it  is    called  an oblique cylinder.

## The curved surface area

The curved surface is a rectangle rolled about its axis. The length of the rectangle is the circumference of the circle with radius r.

Area of rectangle

= Length × Width

= 2 πr × h

= 2 πrh

That is   Curved Surface Area of Cylinder = 2 πrh

The image consists of two geometrical shapes. The shape on the left is a circle with a radius of 2 units. The shape on the right is a rectangle with a height of 2 units. Both shapes have a specific property: the length of the side of the rectangle is equal to the length of the side of the circle.

The image also contains a line segment labeled as \( h \) that is perpendicular to the side of the rectangle. This line segment is positioned at the top of the rectangle.

The background of the image is white, and the lines and shapes are drawn in blue. The image is a simple geometric diagram, likely intended for educational purposes.

### Analysis and Description:
1. **Shape and Properties**:
   - The circle is a perfect circle with a radius of 2 units.
   - The rectangle is a rectangle with a height of 2 units.
   - The line segment \( h \) is perpendicular to the side

<!-- image -->

## The total surface area of a cylinder

A solid cylinder consists of two circles and the curved surface. So, the total surface area is given by area of two circles and area of curved surface.

Total surface area = πr 2 + πr 2 +2 πrh

## Note:

= 2 πr 2 + 2 πrh

It is important to understand that not all cylinders have bases and tops.

<!-- image -->

Total surface area of solid cyclinder = 2 πr 2 + 2 πrh

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                 | Curved surface   | Base   | Top   | Formula for total surface area   |
|-----------------|------------------|--------|-------|----------------------------------|
| Hollow cylinder | ✓                |        |       | 2π rh                            |
| Open cylinder   | ✓                | ✓      |       | 2π rh + πr 2                     |
| Solid cylinders | ✓                | ✓      | ✓     | 2π rh + πr 2 + π r 2             |

## Example  1

The diagram shows a closed cylinder of base radius 7cm and height 10cm. Taking π to be         find 22

7

- (a) the curved surface area,
- (b) the base area,
- (c) the total surface area of the cylinder.

## Solution

- (a) Curved surface area

$$& = 2 \i r h \\ & = 2 \times \frac { 2 2 } { 7 } \, \times 7 \, x 1 0 \\ & - \, \Lambda \Lambda \cap \Lambda ^ { 2 }$$

= 440 cm 2

- (b) The base area = area of a circle

$$\cdots & = \pi r ^ { 2 } \\ & = \frac { 2 2 } { 7 } \times 7 \times 7 \\ & = 1 5 4 \, \text{cm} ^ { 2 } \\ & \quad. \quad. \quad.$$

- (c ) The total surface area of the cylinder = 2 πrh +2 πr 2

= 440 + (2 x 154)

= 440 + 308

= 748 cm 2

## Example 2

The diagram shows a pipe of length 5 m and of radius 2 cm.

Taking π to be 3.14, find its curved surface area, giving your answer in cm 2 .

## Solution

r = 2 cm

h = 5 m = 500 cm

Curved surface area

= 2 πrh

= 2 × 3.14 × 2 × 500

= 6280 cm 2 .

<!-- image -->

<!-- image -->

<!-- image -->

## Finding radius or height, given the surface area of a hollow cylinder

## Example 3

A hollow cylinder of height 10 cm has a curved surface area of 314 cm 2 .  Taking π to be 3.14, find the radius of the cylinder.

## Solution

Curved surface area = 314

2 πrh = 314

2 × 3.14 × r × 10 = 314

$$r \ = \ \frac { 3 1 4 } { 2 \, x \, 3. 1 4 \, x \, 1 0 }$$

$$r \ = \ \frac { 1 0 0 } { 2 0 } = 5$$

Radius of the cylinder = 5 cm

<!-- image -->

## EXERCISE 10.1

For each of the following cylinders, find the total surface area, leaving your answer in terms of π .

- (a) hollow cylinder
- (b) solid cylinder
- (c) water tank opened at top
- (d) wooden rod

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

2. Measurements of solid cylinders are given below. Copy and complete the following table.
3. A hollow pipe has diameter 1 m and length 10 m. Taking π to be 3.14, calculate its surface area.
4. A cylinder of height 20 cm has a curved surface area of 1256 cm 2 . Taking π to be 3.14, calculate the radius of  the base of the cylinder.
5. An open cylinder has base radius 7 cm and total surface area 374 cm 2 . Taking π to be        , find the height of the cylinder. 22 7

|     | Radius of base   | Height   | π    | Curved Surface Area   | Total Surface Area   |
|-----|------------------|----------|------|-----------------------|----------------------|
| (a) | 5mm              | 8mm      | 3.14 |                       |                      |
| (b) | 3 cm 1 2         | 7 cm     | 22 7 |                       |                      |
| (c) | 20 cm            | 2m       | 3.14 |                       |                      |
| (d) | 70mm             | 14 cm    | 22 7 |                       |                      |
| (e) | m 1 2            | 300 cm   | 3.14 |                       |                      |

## Right prism

A right prism can be defined as a solid three-dimensional figure having a uniform cross section.

<!-- image -->

Rectangular prism

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Hexagonal prism

Triangular prism

Rectangular prism

Pentagonal prism

In this image, we can see a cube.

<!-- image -->

(ii)

4

5

5

4

6

10

6

cross-section

(isosceles triangle)

## Prisms with cross-sections

A right prism can be defined as a solid three-dimensional figure having a uniform cross-section.

## Total surface area of a right prism

For a solid right prism, the total surface area is the sum of areas of all its faces.

5

5

The image depicts a geometric figure with two sides labeled as 5 and 6. The figure is a square with four sides, and each side is a perfect square. The sides of the square are of equal length, and the perimeter of the square is 24.

The image is a simple geometric figure, and it is likely intended to be used for educational purposes, such as teaching about the properties of squares and the perimeter of squares.

### Analysis and Description:
1. **Side Properties**:
   - The side length of the square is 5 units.
   - The side length of the square is 6 units.
   - The perimeter of the square is 24 units.

2. **Area and Perimeter**:
   - The perimeter of the square is 24 units.
   - The area of the square is 5 units.

3. **Geometric Properties**:
   - The diagonals of the square are equal.
   - The

<!-- image -->

b

h

a

6 cm

3 cm

8 cm

RECALL

1

Area of trapezium =                 (sums of parallel sides) x height

2

1

=          (a + b)

2

h

10 cm

## Example  1

The diagram below shows a triangular prism.

- (i) Calculate the length of AC.
- (ii) Draw the net of the prism.

Hence, calculate the total surface area of the right prism.

<!-- image -->

## Solution:

- (i) By Pythagoras Theorem

AC

=  √12 2

+ 5 2

=  √144+25

=  √169

= 13 cm

In this image, we can see a diagram. There are some numbers written on the image.

<!-- image -->

- (iii) Area of two triangular faces

=   2 x (       x base x height) 1 2

=   2 x ( x12x5) 1 2

=   12 x 5

=   60 cm 2

Area of  ACDE

= 13 x 15

= 195 cm 2

Area of ABFE

= 5 x 15

= 75 cm 2

Area of BCDF

= 12 x15

= 180 cm 2

T otal surface area of prism

=  (60 + 195 + 180 +75)

= 510 cm 2

<!-- image -->

1. Calculate the total surface area of the following right prisms.

The image depicts a rectangular box with dimensions of 4 cm by 4 cm. The box is divided into two equal halves, each containing a smaller rectangular box. The smaller boxes are positioned at the corners of the larger box. The smaller boxes are aligned horizontally, with the larger box being aligned vertically.

The box is a standard rectangular box with dimensions of 4 cm by 4 cm. The smaller boxes are aligned horizontally, with the larger box being aligned vertically. The smaller boxes are aligned at the corners of the larger box.

The image is a simple geometric diagram, likely used for educational purposes or to illustrate basic principles of geometry. The box is a standard rectangular box with dimensions of 4 cm by 4 cm. The smaller boxes are aligned horizontally, with the larger box being aligned vertically.

The image does not contain any text, numbers, or other objects that would typically be found in a standard geometric diagram. The image is a simple representation of a box

<!-- image -->

(c)

(b)

<!-- image -->

(d)

<!-- image -->

<!-- image -->

2. A right prism has a square base of side 5 cm long and a height of 12 cm. Calculate its total surface area.

<!-- image -->

3. The diagram shows a right prism whose cross-section is a right angled triangle ABC where angle B = 90 0 , BC = 5 cm and AC = 13 cm
2. (a) Show that the length of AB is 12 cm.
3. (b) Given that the prism is 20 cm long, calculate its total surface area.
4. The diagram shows a container with uniform crosssection in the form of a trapezium ABCD. AB is parallel to DC and dimensions shown are in metres. Find the length of BC.
5. Given that the container is 2 m long, calculate its total surface area in (i) m 2 (ii)  cm 2 .
5. The diagram shows a right prism with a triangular cross-section XYZ with angle XYZ = 90 0 , angle XZY =53 0  and YZ = 6m.
7. [ Given sin53 0 = 0.8, cos53 0 = 0.6, tan53 0 =1.3]
8. (a) Show that XZ = 10 m.
9. (b) Hence or otherwise calculate the length of XY.
10. (c) Given that the length of the prism is 15m, calculate its total surface area.
6. A rectangular tank of length 25 cm and width 20 cm is filled with water to a height of 16 cm. Calculate the total surface area of the tank that is in contact with water.

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a box.

<!-- image -->

|                 | Curved surface   | Base   | Top   | Formula for total surface area   |
|-----------------|------------------|--------|-------|----------------------------------|
| Hollow cylinder | ✓                |        |       | 2π rh                            |
| Open cylinder   | ✓                | ✓      |       | 2π rh + πr 2                     |
| Solid cylinders | ✓                | ✓      | ✓     | 2π rh + πr 2 + π r 2             |

In this image, we can see a table with some text and images.

<!-- image -->

## Continuous Assessment

1. Taking π to be        , calculate the total surface area of the following cylinders. 22 7
2. Taking π to be 3.14, calculate the total surface area of the following cylinders.

| cylinder   | cylinder   | radius of base   | height   |
|------------|------------|------------------|----------|
| (a)        | Hollow     | 7 cm             | 10 cm    |
| (b)        | Open       | 3.5 cm           | 12 cm    |
| (c)        | Closed     | 0.28m            | 1m       |

| cylinder   | cylinder   | radius of base   | height   |
|------------|------------|------------------|----------|
| (a)        | Hollow     | 2 cm             | 5 cm     |
| (b)        | Open       | 4 cm             | 25 cm    |
| (c)        | Closed     | 0.5m             | 2m       |

- 22 7 3. The curved surface area of a cylinder is 1760 cm 2 and its height is 20 cm. Taking π to be , calculate its radius of the base.
4. The area of the base of a cylinder is  25 π cm 2 and its curved surface area is 100 π cm 2 . Calculate the radius of the base of the cylinder and hence its height.
5. The curved surface area of a closed cylinder is 1246 cm 2  and its height is 20 cm. Taking π  to be 3.14, calculate its radius of the base. Hence calculate the total surface area of the cylinder.
6. Calculate the total surface area of the right prisms shown below (All units are in cm, unless otherwise indicated).

(a)

(b)

In this image, we can see a diagram. There is a box in the middle of the image.

<!-- image -->

h

14 cm

10 cm

12 cm

(Hint : Find h first)

In this image, we can see a diagram with a line, a square, and a triangle.

<!-- image -->

10 cm

## Notes

## PERSONAL AND HOUSEHOLD FINANCE 12

<!-- image -->

## Learning Objectives

## By the end of this chapter, you should be able to:

- solve simple problems on salaries, wages and hire purchase.
- interpret and use tables and charts (e.g CEB and CWA bills).

## Personal and household finance in real life

Applications of personal and household finance can be seen everywhere around us.

In this image we can see a couch, a plant and a wall.

<!-- image -->

In this image, we can see a paper with some text and numbers.

<!-- image -->

## CHECK THAT YOU CAN:

- Use percentage
- Convert percentage into a fraction and/or decimal or vice versa
- Calculate profit or loss
- Calculate discount
- Calculate simple interest

<!-- image -->

## KEY TERMS

- Buying price
- Selling price
- Marked price
- Profit and Loss
- Discount
- Commission
- Simple Interest
- Salaries
- Wages
- Hire purchase
- Tables and Charts

In this image, we can see a table with some numbers and some text.

<!-- image -->

| exceltemplate NET   | SALARY SLIP   | SALARY SLIP        | CONFIDENTIAL   |
|---------------------|---------------|--------------------|----------------|
|                     |               | 200000 30000 90000 | 2500           |
|                     |               | 2,900,00           |                |

## Recapitulation

In Grade 8, you learnt how to perform operations involving percentages, calculate profit and loss, and solve problems involving discount, commission and simple interest. Below are some worked examples.

## Example 1 (Calculating percentage profit)

Veer bought a video game at Rs 4 000 and sold it at Rs 5 000.

- (a) Did Veer make a profit or a loss?
- (b) Find the profit/loss that Veer made.
- (c) Find the profit/loss made as a percentage of the cost price.

## Solution

- (a) In this situation Veer made a profit since the selling price is greater than the buying price.
- (b) Buying price = Rs 4 000

Selling price = Rs 5 000

Veer's profit = Selling price - Buying price

= Rs 5 000 - Rs 4 000

= Rs 1 000

- (c) Percentage  Profit =                     × 100% Profit Cost price

1000

4000

=              × 100%

=   25%

## Example 2 (Calculating selling price)

Vidhi bought a phone at Rs 8 000. She sold it making a loss of 20%. Find the selling price of the phone.

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

## Example 3 (Calculation of cost price)

Ashvina sold a dress at Rs 750, making a profit of 25%. What was the buying price of the dress?

## Solution

Buying Price = 100%

Profit = 25%

Selling Price = (100% + 25%) = 125%

125% Rs 750

1%

$$\tilde { \ } R s \, \frac { 1 } { 1 2 5 } \times 7 5 0$$

$$1 0 0 \% \xrightarrow { \ } R s \, \frac { 7 5 0 } { 1 2 5 } \, \times 1 0 0 = R s \, 6 0 0$$

Buying Price = Rs 600

## Example 4 (Calculating discount and percentage discount)

The marked price of a television is Rs 30 000. In a sale, the price is reduced to Rs 24 000. Find the percentage discount.

## Solution

Marked price = Rs 30 000

Sale price = Rs 24 000

Discount = Marked price - Sale price

= Rs 30 000 - Rs 24 000

= Rs 6000

Percentage discount =                         ×100% =               × 100% = 20% 6000 30000 Discount Marked price

<!-- image -->

## Example 5 (Commission)

Taslim, a real estate agent, earned 5 % as commission when he sold a land for Rs 3 500 000. How much commission did he receive?

## Solution

Selling price of land = Rs 3 500 000

Commission received by agent = 5% of Rs 3 500 000

$$= \frac { 5 } { 1 0 0 } \times R s \, 3 \, 5 0 0 \, 0 0$$

= 1 750 000

## Example 6 (Finding Simple Interest)

Paul invests Rs 24000 in a company for 4 years at a rate of interest of 3 % p.a. Find the amount he receives at the end of the 4 years.

## Solution

Principal = Rs 24 000   Rate = 3 % p.a.    Time = 4 years

$$\text{ Interest} = \frac { P R T } { 1 0 0 }$$

$$I = R s \ \frac { 2 4 \, 0 0 0 \times 3 \times 4 } { 1 0 0 }$$

I = Rs 2880

Amount received = Principal + Interest

= Rs (24 000 + 2880)

= Rs 26 880

## Example 7 (Finding Principal)

Tara deposited a certain sum of money in a bank. The rate of interest is 1.5% per annum. Given that after 8 years, she got Rs 6000 as interest, find the principal.

## Solution

$$<_ObjectiveC_>             Solution

            Principal =?    Rate = 1.5% p.a.    Time = 8 years      Interest = Rs 6000

            Interest = \frac { \text{PRT} }
                                                                                                                                                                                                        
            6 000 = \frac { \text{1.5} } \text{8} }
                                                                                                                                                                                                    
   P x 1.5 x 8 = 6 000 x 100

            P = \frac { \text{000} } \text{100} }
                                                                                                                                                                                                    

                                                                                                                                                                                                       

   Tara deposited Rs 50 000 in the bank.$$

Tara deposited Rs 50 000 in the bank.

<!-- image -->

## REVISION EXERCISES

1. In a sale, the price of a washing machine decreases by 20%. If the original price of the washing machine was Rs 19200, find the sale price.
2. Vijayen's salary increases from Rs 25000 to Rs 30000. Find the percentage increase in his salary.
3. Yanish buys 15 calculators for Rs 1800. If he sells them at a profit of 30%, find the selling price of one calculator.
4. Yasmeen bought 25 packets of stickers. She makes a profit of 15% when she sells each packet at Rs 23. Find the amount of money she spent on the 25 packets of stickers.
5. During the New Year sales, Roy Toys Ltd offered a 5% discount on all its toys. If Bala bought toys worth Rs1 800, calculate the price of the toys before the sale.
6. Didier  buys  a  pullover  at  Rs  550  during  a  sale.  The  original  price  was  Rs  600.  Find  the percentage discount he received.
7. Billy's monthly income consists of his basic salary of Rs 25 000 and a commission of 2% on sales. Given that his income for the month of May was Rs 33 000, find his total sales for the month of May.
8. Richard borrowed Rs 250 000 for the construction of his house. If he paid interest rate of 5 % p.a. for 10 years, find the interest that he needed to pay.
9. Vanshi invests Rs 50 000 for a project which offers her a simple interest of Rs 2 500 after 20 months. Find the rate of interest per annum.
10. A gift was sold at a loss of 9%. It was observed that if the selling price was Rs 420 more, then the profit made would have been 5%. What is the actual selling price of the gift?

## Salaries and wages

A salary is a fixed regular payment, typically paid on a monthly basis but often expressed as an annual sum, made by an employer to an employee. An employee might receive a fixed basic salary with allowances and commission.

Wage is  a  fixed  regular payment earned for work or services, typically paid on a daily or weekly basis.

## Example 1

In a month, Mr Paul receives the following.

Basic salary

Rs 45 000

Allowance

Rs 2 000

Travel Grant

Rs 6 000

Calculate his total monthly salary.

## Solution

Total monthly salary = Monthly basic salary + Allowance + Travel Grant

= (45 000 +2 000+ 6 000)

= Rs 53 000

## Example 2

A salesman earns a monthly basic salary of Rs 15 000 plus 2% commission on his total sales. He also receives a monthly travel allowance of Rs 5 500. Given that his total sales for the month of February is Rs 120 000, calculate (i) the commission received and (ii) his total salary for that month.

## Solution

$$<_Lisp_>   Solution
  (i) Commission received =         2                                                                                                                                                                                                        
                                                                                                                                                                                                        "                                                                                                                                                                                                       '                                                                                                                                                                                                       :                                                                                                                                                                                                        ;                                                                                                                                                                                                        -                                                                                                                                                                                                        (i)                                                                                                                                                                                                        1                                                                                                                                                                                                       .                                                                                                                                                                                                        )                                                                                                                                                                                                        0                                                                                                                                                                                                        2                                                                                                                                                                                               1        
                                                                                                                                                                                               1         -                                                                                                                                                                                               1         0                                                                                                                                                                                               1         1                                                                                                                                                                                               1         2$$

## Example 3

A gardener is paid weekly for the number of days he worked. His daily rate pay is Rs 300 and his daily transport fare is Rs 52. Given that he works for 6 days in a week, calculate his wages for that week.

## Solution

Wages for 6 days work        = 6 × Rs 300 = Rs 1 800

Total transport fare              = 6× Rs 52    = Rs 312

Total wages for the 6 days = Rs  (1 800 + 312) = Rs 2 112

## Example 4

A woman working in a factory is paid Rs 75 per hour for normal hours and Rs 90 per hour for overtime hours. In a given week, she works for 48 normal hours and 12 overtime hours. Calculate her wages for that week.

## Solution

Wages for normal hours      = 48 × Rs 75 = Rs 3 600

Wages for overtime hours  = 12 × Rs 90 = Rs 1 080

Total wages for the week    = Rs 4 680

## Example 5

A machinist is paid Rs 25 for each shirt stitched. She is paid Rs 35 per shirt in excess of 60 shirts stitched.

- (a) On a given day, she stitched 70 shirts. Calculate her earnings for that day.
- (b) On another day, her earnings were Rs 2550. How many shirts did she stitch on that day?

## Solution

- (a) Amount received on first 60 shirts stitched = Rs 25 × 60 = Rs 1 500 Amount received on 10 shirts in excess of 60 = Rs 35 × 10 = Rs 350        [Excess = 70 - 60] Earnings for that day = Rs 1 500 + Rs 350 = Rs 1 850

- (b)

```
From (a) above, the amount received on first 60 shirts stitched = Rs 1 500 Amount received in excess of Rs 1 500 = Rs (2 550 - 1 500) = Rs 1 050 ∴ Number of shirts produced in excess of 60 =            = 30 Hence, the total number of shirts produced = 60 + 30 = 90 1 050 35
```

<!-- image -->

## EXERCISES: SALARIES AND WAGES

1. A salesman earns a monthly basic salary of Rs 25 000 and 3% commission on his total sales. Given that his total sales for the month of February is Rs 300 000, calculate his total salary for that month.
2. An insurance agent received 2% commission on his sales. He also received a monthly travel allowance of Rs 5 500. In January, his sales amounted to Rs 350 000. Find his total earnings for January.
3. Jaweed earns Rs 350 and an additional Rs 60 for travelling per day. Given that he works for 5 days in a week, calculate his total wages for that week.
4. Parveen, an electronic shop saleswoman, is paid a basic salary of Rs 9 000 monthly. She also receives a transport allowance of Rs 2 000 per month and 2.5 % commission of her total sales at the end of the year. During a certain year, her total sales were Rs 4 000 000. Find
5. (i) her commission received for that year,
6. (ii)  Parveen's total earnings for that year.
5. A worker earns Rs 40 per shirt she makes during normal working hours. If she works overtime, she gets an additional Rs10 per shirt.
8. (a)  In a week, she made 60 shirts during normal hours and 15 shirts during the overtime. Find her total earnings for that week?
9. (b)  On another week, her total earnings were Rs 3 400. Given that she made 12 shirts during the overtime. Calculate the number of shirts she made during normal working hours?

## Hire Purchase

Hire  purchase  is  an  arrangement  for  buying  goods,  where  the  buyer  makes  a  first  payment (deposit) followed by several (usually monthly) instalments (parts).

The  marked  price  of  this  television  is Rs  4999  after  a  discount  of  Rs  3500.  A customer  has  two  ways  of  buying  the television.  He  can  either  buy  it  cash paying in Rs 4999 or on hire purchase paying Rs 194 monthly for a period of 30 months. When paying on hire purchase there is an initial down payment (deposit)  which  needs  to  be  done.  In this situation there is no deposit.

In this image, we can see a television. On the television, we can see text.

<!-- image -->

## Example 1

Mr Liu bought a new van on hire purchase under the following conditions:

Marked Price: Rs 760 000

Deposit: Rs 160 000

Period: 5 Years

Interest: 10% per annum

In this image we can see a white color van.

<!-- image -->

- (a) How much interest was paid by Mr Liu for the 5 years?
- (b) Find the total amount due including interest.
- (c) Calculate the monthly instalment.
- (d) What is the total price paid for the van on the hire purchase system?

## Solution

- (a) Marked price = Rs 760 000

Deposit = Rs 160 000

Amount due = 760 000 - 160 000 = Rs 600 000

Interest on amount due = (600 000 ×         × 5) 10 100

= Rs 300 000

<!-- image -->

- (b) The total amount due = (600 000 + 300 000)

= Rs 900 000

- (c) Monthly instalment   =  Rs 900 000

[ 5 years = 60 months]

60

= Rs 1 5 000

- (d) Total price paid for the van = Principal + Interest

= (760 000 + 300 000)

- = Rs 1 060 000

P: Principal, R: Rate, T: Time

## Example 2

The marked price of a washing machine is Rs 18 000. Rekha decides to buy it on hire purchase, with no deposit, over 24 equal monthly instalments at 12% interest per annum. Calculate the monthly instalment that Rekha will have to pay.

## Solution

Marked Price of the washing machine = Rs 18 000

$$\begin{array} { l } \text{Interest} = P \times \frac { R } { 1 0 0 } \times T \\ = 1 8 \, 0 0 0 \times \frac { 1 2 } { 1 0 0 } \times \frac { 2 4 } { 1 2 } \\ = R s \, 4 \, 3 2 0 \end{array}$$

Total amount due = (18 000 + 4 320)

$$= R s \, 2 2 \, 3 2 0$$

$$\text{Monthly instant} = R s \, \frac { 2 2 \, 2 3 0 } { 2 4 }$$

<!-- image -->

= Rs 930

<!-- image -->

## EXERCISES: Hire Purchase

1. The marked price of a laptop is Rs 25 000. Mr Ahmed decided to buy the laptop on hire purchase. He makes a down payment of Rs 5000 and has to pay 20 monthly instalments of Rs 1 050. Calculate
2. (a)  the total amount Mr Ahmed has to pay for the laptop.
3. (b) the amount of money paid in excess of the marked price.
2. Eric  decides to buy a TV set which is marked at Rs 30 000 on hire purchase. He makes a deposit of 15% and pays 24 equal monthly instalments of Rs 1 120.

Find

- (i)  his deposit amount,
- (ii)  the total amount of money he paid for the TV.
3. The marked price of a refrigerator is Rs 27 000. What would be the monthly instalment if it is bought on hire purchase over 30 months at a 10% interest per annum?
4. The cash price of a car is Rs 300 000. It is bought on hire purchase at an interest rate of 10% per annum. The initial deposit is 15% of cash price and it is paid in 30 equal monthly instalments.
- (a)  Calculate the interest paid.
- (b) Calculate the monthly instalment.
- (c)  How much more is the amount paid on the hire purchase system than the cash price?

## Interpretation of tables and charts

Each month we pay bills for water and electricity that we use in our daily lives. The rates for the payment of such tariffs are based on tables and charts released by organisations like the Central Water Authority (C.W.A) and the Central Electricity Board (C.E.B).

The table below is a modified C.W.A bill.

| Customer Category   | Minimum Charge applicable when the monthly volume consumption is less than10m 3   | Volumem 3        |   CWATariff 11 perm 3 (Rs) |
|---------------------|-----------------------------------------------------------------------------------|------------------|----------------------------|
| Domestic            | Tariff 11: Rs 45.00 per month                                                     | First 10         |                        6   |
| Domestic            | Tariff 11: Rs 45.00 per month                                                     | Next 10          |                        8   |
| Domestic            | Tariff 11: Rs 45.00 per month                                                     | Next 30          |                       17   |
| Domestic            | Tariff 11: Rs 45.00 per month                                                     | EVERY ADDITIONAL |                       32   |
| Commercial          | Tariff 15: Rs 391.00 per month                                                    | All Cubic Metres |                       23   |
| Agricultural        | Tariff 19: Rs 60.00 per month                                                     | All Cubic Metres |                        7.5 |

Meter Rental is Rs 10 for each customer.

If a payment is made after the due date, surcharge of 10% will be charged on the Current Amount Payable.

The following examples are based on the table given earlier.

## Example 1

Mr Dev used 42 m 3  of water for his personal use. How much will he have to pay the C.W.A?

## Solution

Total amount of water used = 42 m 3

| Units used   | Cost per Unit   | Total cost             |
|--------------|-----------------|------------------------|
| First 10     | Rs 6            | 10 × Rs 6 = Rs 60.00   |
| Next 10      | Rs 8            | 10 × Rs 8 = Rs 80.00   |
| Next 22      | Rs 17           | 22 × Rs 17 = Rs 374.00 |

## Meter Rental is Rs 10 for each customer.

The total sum paid = Total cost for number of units used + meter rental

- = Rs (60 + 80 + 374) + Rs10

= Rs 524

## Example 2

A factory paid Rs 3506 for its water consumption for the month of June. How many cubic metres of water were used under tariff 15?

## Solution

Meter Rental is Rs 10 for each customer

Total cost for number of units used = Rs (3 506 -10) = Rs 3 496

Under tariff 15 the amount per m 3  is Rs 23

- ∴ the number of cubic metres of water used under tariff 15 = 3496

23

= 152 m 3

## Example 3

Mr Raj used 26 cm 3  of water in May and 28 cm 3 in June. He did not pay his bill for the month of May. If a payment is made after the due date, a surcharge of 10% will be applicable on the Current Amount Payable.

## Calculate

- (i) the total amount he had to pay for the month of May.
- (ii) the surcharge paid for the month of May.
- (iii) the total amount he had to pay for the month of June.
- (iv) the total amount paid for the two months.

## Solution

- (i) Total amount of water used in May = 26 m 3

| Units used   | Cost per Unit   | Total cost            |
|--------------|-----------------|-----------------------|
| First 10     | Rs 6            | 10 × Rs 6 = Rs 60.00  |
| Next 10      | Rs 8            | 10 × Rs 8 = Rs 80.00  |
| Next 6       | Rs 17           | 6 × Rs 17 = Rs 102.00 |

## Meter Rental is Rs 10 for each customer

The total sum paid = Total cost for amount of units used + meter rental = Rs (60+80 +102) + Rs10

= Rs 252

- (ii) The surcharge paid for the month of May = 10% of Rs 252

= Rs 25.20

- (iii) Total amount of water used in June = 28 m 3

| Units used   | Cost per Unit   | Total cost            |
|--------------|-----------------|-----------------------|
| First 10     | Rs 6            | 10 × Rs 6 = Rs 60.00  |
| Next 10      | Rs 8            | 10 × Rs 8 = Rs 80.00  |
| Next 8       | Rs 17           | 8 × Rs 17 = Rs 136.00 |

## Meter Rental is Rs 10 for each customer

The total sum paid = Total cost for number of units used + meter rental

= Rs (60+80 +136) + Rs10

= Rs 286

- (iv) The total amount paid for the two months = Total amount of water used in May and

June + the surcharge = Rs (252 + 286 + 25.20)

= Rs 563.20

The table below is a modified C.E.B chart.

| Customer Category   | Units per month (Kilowatt hours)   |   Rates applicable per Kilowatt hour (Rs) |
|---------------------|------------------------------------|-------------------------------------------|
| Domestic            | First 25                           |                                       3.2 |
| Domestic            | Next 25                            |                                       4.4 |
| Domestic            | Next 25                            |                                       4.8 |
| Domestic            | Next 25                            |                                       5.5 |
| Domestic            | Next 100                           |                                       6.2 |
| Domestic            | Next 50                            |                                       7   |
| Domestic            | Next 50                            |                                       8   |
| Domestic            | All Additional Units               |                                       9   |

Meter Rental is Rs 10 for each customer.

If  a  payment is made after the due date, a surcharge of 5% will be levied on the Current Amount Payable.

## Example 4

Mr Lim used 167 units of electricity during the month of September. How much will he have to pay the C.E.B?

## Solution

Total units used = 167 units

| Units used   | Cost per Unit   | Total cost               |
|--------------|-----------------|--------------------------|
| First 25     | Rs 3.20         | 25 ×Rs 3.20 = Rs 80.00   |
| Next 25      | Rs 4.40         | 25 ×Rs 4.40 = Rs 110.00  |
| Next 25      | Rs 4.80         | 25 × Rs 4.80 = Rs 120.00 |
| Next 25      | Rs 5.50         | 25 × Rs 5.50 = Rs 137.50 |
| Next 67      | Rs 6.20         | 67 × Rs 6.20 = Rs 415.40 |

Meter Rental is Rs 10 for each customer.

Total amount to be paid = Total cost for number of units used + meter rental

- = Rs (80 + 110 + 120 + 137.50 + 415.40) + Rs 10

- = RS 872.90

<!-- image -->

## EXERCISES: TABLES AND CHARTS

The following exercises are based on the two tables below.

| Units per month (Kilowatt hours)   |   Rates applicable per Kilowatt hour (Rs) |
|------------------------------------|-------------------------------------------|
| First 25                           |                                         3 |
| Next 25                            |                                         4 |
| Next 25                            |                                         5 |
| All Additional Units               |                                         6 |

Meter Rental is Rs 10 for each customer.

If a payment is made after the due date, a surcharge of 5% will be applicable on the Current Amount Payable.

| Customer Category   | Volumem 3        |   CWATariff 11 PERm 3 (Rs) |
|---------------------|------------------|----------------------------|
| Domestic            | First 10         |                          4 |
| Domestic            | Next 10          |                          6 |
| Domestic            | Next 30          |                         12 |
| Domestic            | EVERY ADDITIONAL |                         22 |
| Commercial          | All Cubic Metres |                         20 |
| Agricultural        | All Cubic Metres |                          7 |

Meter Rental is Rs 10 for each customer

If a payment is made after the due date, surcharge of 10% will be charged on the Current Amount Payable.

1. Mr Tom used 220 units of electricity for a month. Find the amount he had to pay for his bill?
2. Mrs Tanuja paid Rs 1 060 for her electricity bill. Find how many units she used for that month.
3. A supermarket used 1100 units and 1130 units of electricity for the months of June and July respectively. Find the total amount that needs to be paid for the two months if the bill for the month of June is left unpaid.
4. Mrs Karim used 72 m 3  of water in her house. How much will she pay the C.W.A?
5. A manufacturing industry used a total of 1 200 m 3  of water for a month. How much was its CWA bill for that month?
6. A sugar cane industry paid Rs 13 205 for its consumption of water for the month of June. How many cubic metres of water were used?
7. Mr Selven used 21 m 3  and 38 m 3  of water for the months of March and April respectively. He did not pay his bill for the month of March. Calculate the total amount he had to pay for the two months.
8. A customer used 53 m 3  of water and used 153 units of electricity for a month for his personal use. Find the total amount he had to pay for the two bills.

## Summary

1. Total Salary = Basic salary + Travel Allowance + Commission received
2. Hire Purchase = Principal + Interest

## Continuous Assessment

1.  Mike bought 150 oranges at Rs 3.50 each. The next day, he found that 15 were rotten. Find the selling price of each orange if Mike made a total profit of Rs 217.50 in selling the remaining oranges.
2.  Fatima sold a skirt at Rs 1 035 making a profit of 15%. What was the buying price of the skirt?
3.  Tanuja deposited a certain sum of money in a bank. The rate of interest is 2.5% per annum. Given that after 6 years, she got Rs 3 750 as interest, find the principal.
4.  An agent earns a monthly basic salary of Rs 25 000 plus 3% commission on his total sales. He also receives a monthly travel allowance of Rs 7 500. Given that his total sales for the month of February is Rs170 000, calculate
5. (i) the commission received.
6. (ii) his total salary for that month.
5.  The table below shows Kevin's daily payment scheme.
8. (a) Calculate the amount received for 5 days with a total of 10 hours overtime.
9. (b)  Calculate the number of hours he worked overtime if he received a total of Rs 4100 for 6 days.
6.  Mr Vinod bought a new house under the following conditions:

| Basic Pay   | Transport fare   | Overtime   |
|-------------|------------------|------------|
| Rs 480      | Rs 30/day        | Rs 80/hour |

Marked Price: Rs 1 800 000

Deposit: Rs 300 000

Repayment period: 20 Years

Interest: 10% per annum

- (a) Calculate the interest paid by Mr Vinod for the 20 years.
- (b) What is the total price paid for the house?
- (c) Calculate the equal monthly instalment.

7.

| Units per month (Kilowatt hours)   |   Rates applicable per Kilowatt hour (Rs) |
|------------------------------------|-------------------------------------------|
| First 25                           |                                         3 |
| Next 25                            |                                         4 |
| Next 25                            |                                         5 |
| All Additional Units               |                                         6 |

Meter Rental is Rs 10 for each customer.

If  a  payment is made after the due date, a surcharge of 10% will be applicable on the Current Amount Payable.

A shop used 950 units and 1 050 units of electricity for the month of August and September respectively. If a payment is made after the due date, surcharge of 10% will be levied on the Current Amount Payable. Find the total amount that needs to be paid for the two months if the bill for the month of August was left unpaid.

## Revision Exercise 3

1. The price of a dining room set is Rs 1 8000 if paid in cash. The set can also be bought on hire purchase by making a down payment of Rs 2 000 followed by 15 monthly payments of Rs 1 250 each. Vanshi buys the dining set on hire purchase.  Find
- a)   the total installments she paid,
- b)   the price she paid under hire purchase,
- c)   the amount saved if payment was made by cash.
2. The volume of a cube is 216 cm 3

.

- (a)  Calculate the length of a side.
- (b)   Calculate its total surface area if it is open at the top.
- (c)  How many smaller cubes of side 2 cm will fit exactly in the given cube?
3. Given A = 0   7 2   1 and B = 3   4 -1   1 .  Find

<!-- image -->

$$( \mathbf a ) \ A + B, \quad ( \mathbf b ) \, 2 B - A, \ \ ( \mathbf c ) \, B A.$$

4. In the following diagram, CÂD = 90 0 ,

.

AD =  4 cm, AB = 3 cm and DCB = 22 0

- (a)  Find DB .
- (b)   Using as much of the information given,
- (i)   calculate AC,
- (ii)  hence, find BC .
- (c)  Find the area of triangle ADC.

$$[ \, c o s \ 2 2 ^ { 0 } = 0. 9 3 \ \ \sin \ 2 2 ^ { 0 } = 0. 3 7 \ \ t a n \ 2 2 ^ { 0 } = 0. 4 0 \ ]$$

<!-- image -->

5. The perimeter of the given shape is less than or equal to 63.
2. (a)  Form an inequality in x and solve it.
3. (b)   What is the minimum possible integer value of x ? Justify your answer.
6. Vida bought 2 banana tarts and 5 neapolitans for a total of Rs 96.  Gaetan bought 3 banana tarts and 2 neapolitans for Rs 56.  What is the cost of each cake?
7. Find the equation of the line which passes through (1,7) and parallel to the line y = 5 x - 4.
8. Given p = 7 x + a 2 x -a ,  make x the subject of formula.
9. The base of a triangle is 5 cm longer than its height.  Given that the height of the triangle is h cm and the area is 33 cm 2 ,
8. (i)   form an equation in h and show that it reduces to h 2  + 5 h - 66 = 0.
9. (ii)  solve this equation and hence find the length of the base.
10. Using ( a + b ) ( a -b ) = a 2  b 2 , evaluate  201 × 199.
11. (a)  Evaluate 125 2 3 .
12. (b) Solve the equation  5 3 x × 5 x ÷ 25 = 625.

<!-- image -->

## PATTERNS AND SEQUENCES

## Learning Objectives

By the end of this chapter, you should be able to:

- identify and complete Pascal's triangle.
- extend given number patterns and figures and find the general term.
- find the relation between ordered pairs of a sequence (including positive and negative numbers).

## Number Patterns and Figures

## Real life context

Numbers are found and used everywhere in our daily life. In many circumstances, we see number patterns, that is, numbers following a specific order/rule.  Around us, we may also find patterns involving figures.

<!-- image -->

<!-- image -->

## CHECK THAT YOU CAN:

- Manipulate real numbers
- Compare and order real numbers
- Make subject of formula

<!-- image -->

## KEY TERMS

- Sequence
- Fibonacci Sequence
- Pascal's Triangle
- Number sequence
- Pattern
- Term
- General term
- Sequence of ordered pairs
- Subject of formula

<!-- image -->

<!-- image -->

D2

C1

|   S |   M |   T | W   | T   | F   | S   |
|-----|-----|-----|-----|-----|-----|-----|
|   1 |   2 |   3 | 4   | 5   | 6   | 7   |
|   8 |   9 |  10 | 11  | 12  | 13  | 14  |
|  15 |  16 |  17 | 18  | 19  | 20  | 21  |
|  22 |  23 |  24 | 25  | 26  | 27  | 28  |
|  29 |  30 |  31 |     |     |     |     |

<!-- image -->

In Grades 7 and 8, you learnt about several number sequences (including Fibonacci Sequences) and sequences of ordered pairs.

A brief recapitulation of these concepts is made below.

## Fibonacci Sequence

## Definition

A  Fibonacci  sequence  is  a  sequence  of  numbers  in  which  each successive number is obtained by adding the two previous numbers in the sequence.

## Example

Write down the next 5 terms of Fibonacci sequence starting with 2,3.

## Solution

In this image, we can see a graph.

<!-- image -->

## Note:

A sequence that starts with 1,1 is called 'The Fibonacci sequence'.

1

1

2

3

5

8

1 +1 = 2

1 + 2 = 3

2 + 3 = 5

3 + 5 = 8

13

5 + 8 = 13

It is named after the Italian mathematician Leonardo Fibonacci.

Leonardo Fibonacci, Italian mathematician (c1170- c1250)

<!-- image -->

21

34

8 + 13 = 21

13 + 21 = 34

<!-- image -->

1. This is part of the Fibonacci Sequence 13, 21, 34.  Which is the next number in the se- quence?

A.  54

B.  55

C.  68

D.  17

- 2.

- Complete the number pattern: 1, 3, 4, 7, 11, \_\_\_\_\_\_ , \_\_\_\_\_\_\_ , \_\_\_\_\_\_\_ .

3. Write down the next 5 terms of Fibonacci sequence starting with:

(a) 1, 3

(b) 2, 4

(c) 5, 6

(d) 2, 7

(e) 9, 5

(e) 4, 4

4. If the 3 rd and 4 th  terms of a Fibonacci sequence are 5 and 9 respectively, write down the first 8 terms of the sequence.
5. What is the first number which is greater than 100 in the Fibonacci sequence?

## Class Activity

The first fifteen Fibonacci numbers are:

1   1   2   3   5   8   13   21   34   55   89   144   233   377   610

- (a) Every third term of the sequence is

A.  Odd

B.  Prime

C.  Square

D.  Even

- (b) Choose any three consecutive Fibonacci numbers. Multiply the first by the third. Square the second. Repeat this for other groups of three.  Write what you notice?
- (c) Choose any four consecutive Fibonacci numbers. Multiply the first by the fourth. Multiply the second by the third.  Repeat for other groups of four.  Write what you notice.

<!-- image -->

This link allows you to learn more about Fibonacci Sequences. www.mcs.surrey.ac.uk/Personal/ R.Knott/Fibonacci/fibnat.html

## Pascal's triangle

Pascal's triangle is an infinite, equilateral triangle composed of numbers. The numbers that make up Pascal's triangle follow a simple rule: each number is the sum of the two numbers above it.

In this image, we can see a graph.

<!-- image -->

## Class Activity

Observe the Pascal Triangle below and answer the following questions.

In this image, we can see a table with some numbers.

<!-- image -->

In this image we can see a chart.

<!-- image -->

<!-- image -->

## DID YOU KNOW

The sum of the elements of a single row is twice the sum of the row preceding it. For example, row1 (the topmost row) has a value of 1, row 2 has a value of 2, row 3 has a value of 4, and so on.

<!-- image -->

## DID YOU KNOW

Pascal's Triangle was originally developed by the ancient Chinese, but Blaise Pascal was the first person to discover the importance of all of the patterns it contained.

Blaise Pascal (1623-1662 CE)

<!-- image -->

- (a) What can you observe from the
- (i) first diagonal,
- (ii) second diagonal,
- (iii) third diagonal,
- (iv) first and the last numbers of each row,
- (v) the number of elements in each row.
- (b) Describe the symmetry of the triangle.
- (c) What do you notice about the horizontal sums? Is there a pattern?
1.  Complete the Pascal's Triangle below.
2. What is the 6th row in Pascal's triangle?
3. Write down the 8 th and 9 th row of Pascal's Triangle.
4. Which row has a sum of 2048?

<!-- image -->

In this image, we can see a chart.

<!-- image -->

- A. 1 , 5 , 10 ,10 , 5 , 1

B. 1 , 5 , 10 , 5 , 1

- C. 1 , 5 , 5 , 10 , 5 , 5 , 1

- D. None of the answers are correct.

## Number sequences

## Example 1

Write down the missing terms in each of the following sequences.

- (a)
- (c) 1 1 3
- (e) 50, \_\_\_\_\_, \_\_\_\_\_\_, 68, 74.

```
4, 7, 10, _____, ______. ,        ,       ,    _____ , _____  . 4 2 4
```

- (b) 96, 85, 74, \_\_\_\_\_\_, \_\_\_\_\_\_.

- (d) -9, -7, -5, \_\_\_\_\_, \_\_\_\_\_.

## Solution

+3

+3

+3

+3

- (a) 4, 7, 10,  13, 16 .

$$\stackrel { - 1 1 } { 1 } \stackrel { - 1 1 } { 2 } \stackrel { - 1 1 } { 3 } \stackrel { - 1 1 } { 4 }$$

- (b) 96, 85, 74, 63, 52.
- (c) , 1 4 1 2 3 4 1 4

,         ,   1,   1     .      Observe that       =        and that 1 =       gives a sequence which is easier to complete. (use of common denominator 4) 1 2 2 4 4 4

- (d) - 9, - 7, - 5, -3, -1. +2 +2 +2 +2

- 6

- 6

- 6

- 6

- (e) 50, 56, 62, 68, 74.

## Example 2

Write the missing terms in each of the following sequence of ordered pairs.

```
(a) (0 , 5), (1 , 7), (2 , 9), ( _____ , _____ ),  ( _____ , _____ ). (b) (3, ),  (7 , _____ ), (12 ,      ), ( _____ , ), ( _____ , _____ ). 1 6 1 2 2 3
```

## Solution

## Note:

- (a) (0 , 5), (1 , 7), (2 , 9), (    3  , 1 1 ),  (   4  , 13 ).

For a sequence of ordered pairs, consider  as  two  separate  sequences  of  numbers, one for the first set of numbers ( x values) and one for the second set of numbers ( y values).

- (b) (3 , ),  (7  , ),  (12 ,    ), ( 18 ,    ), ( 25 ,    ). 1 6 1 3 1 2 2 3 5 6

( Write all the fractions in equivalent form with denominator 6.)

<!-- image -->

1. Complete the following sequences.
2. (a) 10, 13, 16, \_\_\_\_ , \_\_\_\_ .
3. (c) 3, 6, 12, \_\_\_\_ , \_\_\_\_ .
4. (e) -16, -9, -2, \_\_\_\_, \_\_\_\_ .
5. (g) 0.2, 0.4, 0.6, \_\_\_\_ , \_\_\_\_ .
6. 1 1 3
7. (i)
8. ,      ,      ,  \_\_\_\_ , \_\_\_\_ . 8 4 8
2. Write the missing terms in each of the following sequence of ordered pairs.
10. (a) (10,1) , (9,2), (8, 3),( \_\_\_\_ , \_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_ ) .
11. (b) (1, 48), (2, 24), (4, 12), ( \_\_\_\_ , \_\_\_\_ ) , ( \_\_\_\_ , \_\_\_\_ )
12. (c) (1, 25), (4, 16) , ( \_\_\_\_ , \_\_\_\_ ), (16, \_\_\_\_ ), ( \_\_\_\_ , 1)
13. (d) (     ,0.8)  ,(        ,\_\_\_\_), ( \_\_\_\_, 0.2), ( \_\_\_\_, 0.1), (      ,\_\_\_\_\_). 1 8 3 8 3 16
14. (e) (1, -12), ( \_\_\_\_ , \_\_\_\_ ), (27, -18), ( \_\_\_\_ , \_\_\_\_\_ ) , (125, -24) .
15. (f ) (0.2, 1), (0.4, 1.4), (0.8, \_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_\_ ), ( \_\_\_\_ , 2.6)
16. (g) (1,      ), ( \_\_\_\_, \_\_\_\_ ) , (4,2      ), (8, \_\_\_\_ ), (\_\_\_\_\_, 4     ) . 1 2 1 2 1 2
17. (h) (-5, 10), (-3, \_\_\_\_ ) , ( \_\_\_\_ , 40), (1, 80), ( \_\_\_\_ , \_\_\_\_ 0) .

- (b) 58, 54, 50, \_\_\_\_ , \_\_\_\_ .

- (d) 100, 50, 25, \_\_\_\_ , \_\_\_\_ .

- (f )

- -22, -31, -40, \_\_\_\_ , \_\_\_\_ .

- (h) 37.5, 7.5, 1.5, \_\_\_\_ , \_\_\_\_ .

- (j) 5 5 10

- ,        ,       , \_\_\_\_ , \_\_\_\_ .

- 1 2 3

## Patterns of figures

## Example 1

The figures below have been formed by using matchsticks.

Figure 1

<!-- image -->

## Solution

(i)

<!-- image -->

Figure 1

<!-- image -->

- (i) Draw Figures 4 and 5.
- (ii)   Count the number of matchsticks in figures 1, 2, 3, 4 and 5 respectively.
- (iii)   State the number of matchsticks that figures 6, 7 and 10 will consist of.
- Can you identify the three matchsticks that are being added each time in the Figures? (ii)
- (iii) The number of matchsticks in Figure 6 is 20.

Figure 3

<!-- image -->

Figure 4

<!-- image -->

In this image, we can see a table with some numbers and there are some arrows.

<!-- image -->

|                       |   Figure 1 | Figure 2   |   Figure 3 |   Figure 4 | Figure 5   |
|-----------------------|------------|------------|------------|------------|------------|
| Number of matchsticks |          5 | 8          |         11 |         14 | 17         |
|                       |         +3 |            |         +3 |         +3 |            |

The number of matchsticks in Figure 7 is 23.

- The number of matchsticks in Figure 10 is 32.

<!-- image -->

Figure 2

Figure 3

<!-- image -->

Figure 2

<!-- image -->

<!-- image -->

1.      In the diagram, fill in each brick so that the sum of the numbers on two bricks is equal to the number on the bricks above them.
2.      The figures below have been formed using matchsticks.

In this image, we can see a graph.

<!-- image -->

<!-- image -->

Figure 1

<!-- image -->

<!-- image -->

Figure 2

Figure 3

- (i)  Draw Figures 4 and 5.
- (ii)   How many matchsticks will there be in Figures 10 and 11 respectively?
3.      By counting the number of squares formed in each diagram, state the number of squares in Diagrams 6 and 7 respectively.

In this image, we can see a diagram.

<!-- image -->

## The general term of a sequence

The general term of a sequence is a formula, often written in terms of n .  When n is replaced by a specific value, it gives a specific term in the sequence.  For example, replacing n by 5 would give the 5 th term.

In this image, we can see a text.

<!-- image -->

The image is a bar chart titled "Example 2". The chart consists of four different bars, each representing a different type of data. The x-axis is labeled "Diagram 1", and the y-axis is labeled "Diagram 2". The bars are color-coded, with each color representing a different type of data.

### Description of the Bar Chart:
1. **Title**: The title of the chart is "Example 2".
2. **Bars**:
   - **Diagram 1**: This bar is colored yellow.
   - **Diagram 2**: This bar is colored blue.
   - **Diagram 3**: This bar is colored green.
   - **Diagram 4**: This bar is colored red.
3. **Data Representation**:
   - **Diagram 1**: The bar for "Diagram 1" is yellow.
   - **Diagram 2**: The bar for "Diagram

<!-- image -->

- (i) Find the number of squares in Diagram 1, 2, 3 and 4.
- (ii) Find an expression for the number of squares in Diagram n of this sequence.
- (iii) Hence, find the number of squares in Diagram 5 and in Diagram 13.

## Solution

- (i) The number of squares in diagrams 1, 2, 3, and 4 are : 1, 4, 7, 10.
- (ii) The sequence 1, 4, 7, 10 can be written as follows:

In this image, we can see a graph.

<!-- image -->

The n th term for this sequence will be 1+3× ( n -1) which simplifies to 1+ 3 n -3 , i.e., 3 n -2.

The 5th term is 13 by replacing the value of n by 5.

- (ii) In Diagram 5, the number of squares will be 3(5)-2, that is, 13 squares. Diagram 13 will consist of 3(13)-2 squares, that is, 37 squares.

<!-- image -->

## EXERCISE 13.5

1. (a) Find, in terms of n ,  the general term for the following sequences. (i) 5, 10, 15, ...  (ii) 0, 1, 2, ...      (iii) 5, 7, 9, ...         (iv) 1, 8, 27, 64, ...
2. (b) Hence write down the 15 th  term in each of the sequences above.
2. Consider the sequence of pictures below.

<!-- image -->

Picture 1

<!-- image -->

<!-- image -->

- (i) Find the total number of circles in Pictures 5 and 6.
- (ii) How many blue circles will there be in Picture 7?
- (iii) Find an expression, in terms of n , for the total number of circles in  Picture n .
- (iv) Hence, find an expression, in terms of n , for the number of blue circles in Picture n .
- (v) Find the number of blue circles in Picture 25.

## Finding the relation between ordered pairs of a sequence

An ordered pair is comparable to coordinates. For an ordered pair, the first number may be considered as the x coordinate and the second number as the y coordinate. values within the ordered

Sometimes, we are required to find the relation between the x and y pairs.

Picture 4

<!-- image -->

## Example

In each of the sequence of ordered pairs below, find y in terms of x .

- (i) (1, 1), (2, 2), (3, 3), ...

## Note:

- (i)   The question can also be 'find a relation between  x  and  y'.  In  that  case,  it  will  not  be necessary to make y subject of formula.
- (ii)   You  are  not  required  to  write  down  the  next terms in the sequence here.
- (ii) (1, 2), (2, 3), (3, 4), ...
- (iii) (3, 1), (4, 2), (5, 3), ...
- (iv) (7, 2) , (6, 3), (5, 4), ....
- (v) (3, -6), (4, -8), (5, -10), ...

## Solution

- (i) (1, 1), (2, 2), (3, 3), ...

| x   |   1 |   2 |   3 |
|-----|-----|-----|-----|
| y   |   1 |   2 |   3 |

In this sequence, all the x values are equal to the y values.

The expression for y in terms of x is y = x .

- (ii) (1, 2), (2, 3), (3, 4), ...

| x   | 1       | 2       | 3       |
|-----|---------|---------|---------|
| y   | 2       | 3       | 4       |
|     | 2-1 = 1 | 3-2 = 1 | 4-3 = 1 |

In this sequence, observe that all the x values differ from the y values by 1.

So, the relation between y and x is

## Note:

$$y - 1 = x.$$

The expression for y in terms of x is y = x + 1.

- (iii) (3, 1), (4, 2), (5, 3), ...

<!-- image -->

| x      | 3      | 4   | 5      |
|--------|--------|-----|--------|
| y      | 1      | 2   | 3      |
| 3-2= 1 | 4-2= 2 |     | 5-2= 3 |

It is a good practice to check the expression for y in terms of x with the values given in the sequence of ordered pairs.

Can you observe that if we subtract 2 from x here, we get y ?

Does this work for the three ordered pairs?

In that case, y = x -2 .

$$( \text{iv} ) \ \ ( 7, 2 ) \,, ( 6, 3 ), ( 5, 4 ), \dots$$

Here, there is no constant difference between the two terms.

However, observe the sum of the two numbers in each ordered pair.

You will find that x + y = 9. ( which is not y in terms of x yet.)

Hence,

$$y = 9 - x. \, ( making y \, the \, subject \, of formula.)$$

- (v) (3, -6), (4, -8), (5, -10), ...

In this sequence, the relation between x and y is           = - 2.[ Note that other versions of this  relation can be  found:           = x or x × - 2 = y . ] However, for y in terms of x , the answer is y = -2 x . [Making y subject of formula] y x y -2

<!-- image -->

For each sequence of ordered pairs below, find y in terms of x .

(i) (1, 4) , (2, 5) , (3, 6),...

(ii) (6, 4) , (5, 3) , (4, 2),...

(iii) (1, 4) , (2, 3) , (3, 2),...

(iv) (1, 4) , (2, 8) , (3, 12),...

(v) (20, 4) , (15, 3) , (10, 2),...

(vi) (27, -9) , (24, -8) , (21,-7),...

## Summary

- A Fibonacci sequence is a special type of sequence where a term can be obtained by adding its preceding two terms.
- We can construct a Fibonacci sequence if we know any two consecutive terms.
- Pascal's Triangle is a special triangle formed with numbers in which all the rows start and end with 1.  Moreover,  each of the other numbers is the sum of the nearest two numbers in the row above.
- A number sequence is a list of numbers which follows a certain rule.
- To find the missing terms in a sequence of ordered pairs, remember that all the first numbers in the ordered pairs form a sequence.  All the second numbers in the ordered pairs form a sequence.
- The general term of a sequence is a formula, generally  in terms of n.  When n is replaced by a number, it gives a specific term of the sequence.
- To find a relation between x and y within an ordered pair, check if, for all ordered pairs,
- the difference between the terms is constant.
- the sum of the terms is constant.
- the product of the terms is constant.
- the division of the terms results as a constant.

<!-- image -->

These links allow you to find out more on this topic.

https://www.cimt.org.uk/projects/mepres/book9/bk9i10/bk9\_10i2.html https://havefunlearning.com/free/worksheets/fibonacci-sequences-number-patterns-worksheet-2/

## Continuous Assessment

1. If the 5 th and 6 th  terms of a Fibonacci sequence are 21 and 34 respectively, write down the first 8 terms of the sequence.
2. Look at this row of numbers in Pascal's triangle.
3. 1, 9, 36, 84, 126,…
4. (a) Complete the sequence.
5. (b) Which row is it?
6. (c) List the elements of the next row.
7. (a) Find the sum of the elements of each of the first five rows of Pascal's triangle.
8. (b) What is the pattern of the sums ?
9. (c) How could you relate the row number to the sum of that row?
10. (d) How would you express the sum of the elements in the 20 th  row ?
4. Write down the next two terms in the following sequences.
12. (i)   12, 17 , 22, 27 , \_\_\_\_, \_\_\_\_\_ .
13. (ii)   7       , 7       , 7      , 7       , \_\_\_\_\_, \_\_\_\_\_ . 1 5 2 5 3 5 4 5
14. (iii)  6.9, 5.7 , 4.5, \_\_\_\_\_ , \_\_\_\_\_\_ .
15. (v) 8, 4, 2, \_\_\_\_ , \_\_\_\_\_ .

In this image, we can see a diagram.

<!-- image -->

(iv) 1, 5, 25, \_\_\_\_\_ , \_\_\_\_\_\_ .

(vi) 243, 81, 27, \_\_\_\_\_ , \_\_\_\_\_ .

(vii) IX, XIX, XXIX, \_\_\_\_ , \_\_\_\_.

(viii) 0, 7 , 26, 63, \_\_\_\_ , \_\_\_\_\_ .

5. Write down the next two terms in the following sequence of ordered pairs.
2. (i) (2, 15), (4, 14), (6, 13), ( \_\_\_\_ , \_\_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_\_ )
3. (ii) (1, 7), (3, 1 1), (5, 15), ( \_\_\_\_ , \_\_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_\_ )
4. (iii) (16, 64), (15, 27), (14, 8), ( \_\_\_\_ , \_\_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_\_ )
5. (iv) (10, 5), (20, 10), (30, 15), ( \_\_\_\_ , \_\_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_\_ )
6. (v) (6 ,      ) , (6     ,      ), (6     ,     ), ( \_\_\_\_ , \_\_\_\_\_ ), ( \_\_\_\_ , \_\_\_\_\_ ) 1 4 1 2 2 7 3 4 3 7 1 7

3

6. Study the pattern below and answer the following questions.

Diagram 1

In this image there is a diagram.

<!-- image -->

Diagram 2

Diagram 3

- (i) Draw Diagram 4.
- (ii) Write down the number of triangles formed in each diagram and hence deduce the number of triangles in Diagrams 5, 6 and 7 respectively.
- (iii)   Count the number of matchsticks in each diagram.  Hence deduce the number of matchsticks in Diagram 5, 6 and 7 respectively.
- (i) What is the special name of the shape in Diagram 1 ?
- (ii) How many matches will there be in Diagram n ?
- (iii)    Find the number of matches in Diagram 20.
8. Find a relationship between x and y in each of the following sequence of ordered pairs.

In this image, we can see a diagram.

<!-- image -->

- (i)   (1, 4), (2, 8), (3,12), ...

(ii)  (2, 7), (3, 8), (4, 9),...

- (iii) (1, 6), (2, 5), (3, 4), ...

(iv) (2, 18), (3, 12), (4, 9), ...

- (v) (2, -8), (3, -12), (5, -20), ...

(vi) (10, -5), (8, -4), (6, -3), ...

## Notes

## VECTORS AND TRANSLATION

## Learning Objectives

## By the end of this chapter, students should be able to:

- distinguish between a scalar and a vector quantity.
- express a vector in column form.
- find the magnitude of a vector.
- describe a translation by using a vector (column vector or in the form AB or a ).
- find translation vector when image and object are given.
- find the image of a point or shape under a translation.
- find object when image and translation vector are given.

## Definition

'Vector' is defined as a quantity having both magnitude and direction . Vectors can be represented geometrically by a directed line segment.  The length of the directed line is the magnitude and the arrow indicates the direction .

<!-- image -->

Quantities such as forces, velocities, accelerations etc. are vector quantities as they have both magnitude and direction.

## Vectors in real life

<!-- image -->

The force, the boy is applying on the box can be represented by a vector.

<!-- image -->

Wind  and  waves  can  be represented by vectors because  they  have  both magnitude and direction.

<!-- image -->

## KEY TERMS

- Scalar quantity
- Vector quantity
- Magnitude
- Direction
- Position vector
- Equal vectors
- Parallel vectors
- Translation vector
- Object
- Image

<!-- image -->

DID YOU KNOW

## Down history lane

Vectors  appeared  in  late  19th  century when  Josiah  Willard  Gibbs  and  Oliver Heaviside (of the United States and Britain, respectively) independently developed  vector  analysis to express the new laws of electromagnetism discovered by the Scottish physicist James  Clerk  Maxwell.  Since  that  time, vectors have become essential in physics, mechanics, electrical engineering, and  other  sciences  to  describe  forces mathematically.

Quantities  having  only  magnitude  are called scalars ,  example  distance,  mass, age and so on.

<!-- image -->

## Difference between a scalar and a vector quantity

A scalar is a quantity having only magnitude whereas a vector has both magnitude and direction.

## Example

1. The distance between a football player and the goal post is 9 m. This is a scalar quantity because it has only a magnitude.
2. The same football player was running at a speed of 7 m/s towards the goal post. This is a vector quantity because it represents both magnitude (7 m/s) and direction (towards the goal post).

In this image we can see a football ground.

<!-- image -->

In this image we can see a person riding a skateboard on the ground. There is a net. There is a ball. There is a person.

<!-- image -->

<!-- image -->

Classify the following as vector or scalar quantity by putting a tick in the table below

|      | Quantity     | Scalar   | Vector   |
|------|--------------|----------|----------|
| (a)  | Length       |          |          |
| (b)  | Speed        |          |          |
| (c)  | Acceleration |          |          |
| (d)  | Mass         |          |          |
| (e)  | Weight       |          |          |
| (f ) | Distance     |          |          |

## Representation of a vector

<!-- image -->

This vector can be represented as AB or a

When the vector        is drawn on a grid, it is represented as a column vector where h is the horizontal distance and k is the vertical distance. AB

<!-- image -->

In this image, we can see a line. There is a text on the image.

<!-- image -->

In this image, we can see a graph. There are two lines on the graph.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

In this image we can see a graph.

<!-- image -->

<!-- image -->

Express each of the following as column vectors.

In this image, we can see a diagram.

<!-- image -->

## Equal vectors

Consider the following pair of vectors.

In this image we can see a diagram.

<!-- image -->

- It can be observed that both            or m AB 4 3
- =                and           or n =             . ( ) CD 4 3 ( )

These two vectors are represented by the column vector                 and they are called

- equal vectors. 4 3 ( )

$$\mathbf A \mathbf B \ = \ \mathbf C \mathbf D \quad \text{or} \, m = n.$$

In general, two vectors are said to be equal if they have the equal magnitude and the same direction .

<!-- image -->

1. State whether the following pairs of vectors are equal.

In this image we can see a diagram.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

## 2. State which of the following vectors are equal.

In this image, we can see a graph.

<!-- image -->

## Negative vectors

Consider the following vector.

In this image we can see a graph.

<!-- image -->

It can be observed that the vector AB 4 2 ( ) =

Suppose the direction of the vector is changed,

In this image we can see a line on the graph.

<!-- image -->

it can be observed that

$$\begin{array} { l l l } \text{if can be observed that} \\ \overrightarrow { \text{BA} } & = & \binom { - 4 } { - 2 } \\ \text{Also} \\ \overrightarrow { \text{BA} } & = & \binom { - 4 } { - 2 } & = & - \binom { 4 } { 2 } \\ & & \vdots & & \vdots \end{array}$$

$$\text{That is } \ \overline { \ B A } \ = \ \overline { - A \overline { B } }$$

The vector         is the negative of vector . BA AB

$$\text{Similarly if the vector } \overrightarrow { P Q } = \binom { 3 } { - 2 } \text{ then } \overrightarrow { Q P } = \binom { - 3 } { 2 }$$

<!-- image -->

<!-- image -->

<!-- image -->

1. Complete the following table.
2. In the following diagram, state the pairs of vectors which are negative to each other.

| AB 4 ( =   | (   |    | 5 )    | BA   | =   |    | )        |
|------------|-----|----|--------|------|-----|----|----------|
| PQ         | =   | (  | 1 -2 ) | QP   | =   | (  | )        |
| MN         | =   |    | ( )    | NM   | =   |    | -4 2 ( ) |
| AB         | =   |    | ( )    |      | BA  | =  | 4 0 ( )  |

In this image, we can see a diagram.

<!-- image -->

## Magnitude of a vector

Consider the vector                          shown in the diagram. AB 6 8 ( ) =

The magnitude of        , written as | AB| means the length of AB . AB

By using  Pythagoras' theorem , we have

AB 2 =  6 2 +8 2

AB 2 =  36 + 64

AB 2 =  100

AB =    100 √

AB =  10 units . . .

Hence, the magnitude of AB is 10 units.

In this image, we can see a diagram. There is a line labeled as \(a\) and a line labeled as \(y\).

<!-- image -->

## Example

Find the magnitude of each of the following vectors.

$$( i ) \quad p = ( \begin{matrix} 3 \\ 4 \end{matrix} )$$

$$( \text{ii} ) \, q \ = \binom { 6 } { - 8 }$$

## Solution

$$\left ( \mathbf i \right ) \ \left | p \right | \, = \ \sqrt { 3 ^ { 2 } + 4 ^ { 2 } }$$

$$\begin{array} { r c l c r c l } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & && & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & _ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & - & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &   & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & . & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &.. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &.
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &$$

In this image, we can see a graph. There is a line on the graph.

<!-- image -->

$$( \text{iii} ) \ r \ = \ \binom { - 2 4 } { - 7 }$$

$$( \text{iii} ) \ \ | r | \ = \ \sqrt { ( - 2 4 ) ^ { 2 } + ( - 7 ) } ^ { 2 }$$

$$( \text{iii} ) \quad | \text{r} | \ = \ & \sqrt { ( - 2 4 ) ^ { 2 } + ( - 7 ) ^ { 2 } } \\ \ & \ = \ & \sqrt { 5 7 6 + 4 9 } \\ \ & \ = \ & \sqrt { 6 2 5 }$$

=     25 units.

## Example 4

AB =              . Given that the length of AB is 13 units, find the possible values of k . 12 k ( )

## Solution

The length of AB is 13 units, we have

|

AB

|

=

13

√

12 2

+

k

2

=

13

12 2 + k 2 = 13 2 (squaring on both sides)

144 + k 2

=

169

144 +

k

2

- 144  =

k 2

k

k

=

=

=

169 - 144 ( using additive inverse)

25

±

√

±5

<!-- image -->

## EXERCISE 14.4

1. Choose the correct answer in each of the following.
2. (a) Given that a =             , the magnitude of a is 0 5 (  )

A. 25

B. 0

C. 5

D. None of these.

- (b) Given that p =             , the length of the vector p is -6 8 ( )

A. 28

B.

√

28

C. 100

D. 10

- (c) Given that r =              , the value of | r | is -5 -12 ( )

A. -13

B. -169

C. 13

D. None of these.

2. Find the magnitude of each of the following vectors.

$$\binom { 4 } { 3 } \int \binom { 5 } { 1 2 } \int \binom { ( c ) } { 4 } \binom { - 3 } { 4 } \binom { 7 } { - 2 4 }$$

$$\begin{array} { c c c } \binom { \cdot } { - 6 } & \binom { ( f ) } { 0 } & \binom { 2 0 } { 0 } & \binom { ( g ) } { 2 1 } & \binom { ( h ) } { \frac { 3 } { 5 } } \\ 3. \ \text{It is a given that } s = \binom { 0. 3 } { \Lambda \, A }. \ \text{Find } | s |. \end{array}$$

3.  It is given that s =             . Find | s |. 0.4 ( )
4. Given that AB =              . Find the length of AB . -0.8 -0.6 ( )
5. The vector r is defined by r =             . Given that | r | = 10 units, find the possible values of k . -8 k ( )

$$6. \underbrace { \text{Given that $\overrightarrow { A B } = \binom { 1 2 } { 9 }$ and $\overrightarrow { C D } = \binom { 0 } { x }$, find } } \quad \ \rightarrow$$

$$( a ) \left | A B \right | \quad \left ( b \right ) \text{ two possible values of } x \text{ if } | A B | = | C D |.$$

25

Note:

k can either br 5 or -5.

## Translation

A translation moves a set of points from one position to another through the same distance in the same direction .

In the diagram below,      ABC translated to       A'B'C'.

ABC is called the object and      A'B'C' is called the image . Thus the vertices  A', B' and C' are the respective images of the points A, B, and C.

In this image, we can see a diagram with a line, a point, and a line.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

## Representation of a translation by means of a column vector

=             .

A translation is usually denoted by the letter T and represented by a column vector as T

<!-- image -->

where h represents the  horizontal movement and k represents the vertical movement.

| h un its   | Move h units to the right.   | h is positive.   | Note: When we move a point,                                           |
|------------|------------------------------|------------------|-----------------------------------------------------------------------|
| h units    | Move h units to the left.    | h is negative.   | (a) we do the horizontal movement (right or left) first, either +or-, |
| k units    | Move k units up.             | k is positive.   | (b) then we do the vertical movement (up or down), either +or-.       |
| k units    | Move k units down.           | k is negative.   |                                                                       |

In the above diagram        ABC, has moved 3 units to the right (+3) and 4 units up (+4).

<!-- image -->

## Finding translation vector when image and object are  given

In this image there is a diagram. In the diagram there is a table. There is a graph.

<!-- image -->

<!-- image -->

## EXERCISE 14.5

Each of the following shows a point and its image under a translation. For each one, express the translation by means of a column vector.

In this image, we can see a diagram.

<!-- image -->

## Example 6

The following diagram shows a line segment AB and its image A'B' under  a translation T . Write down the column vector representing the translation.

In this image, we can see a diagram. There are two lines, one is a line and the other is a line. There are some numbers written on the lines.

<!-- image -->

## Solution

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

## EXERCISE 14.6

Each of the following diagrams shows a line segment and its image under a translation. For each one, express the translation by means of a column vector.

The image depicts a line segment labeled as "A" and another line segment labeled as "B". The line segment "A" is positioned at the top of the image and extends to the right, while the line segment "B" is positioned at the bottom of the image and extends to the left. Both lines are parallel to each other.

### Description of the Line Segment:
- **Line Segment A**:
  - The line segment "A" is a straight line that extends from the top of the image to the bottom.
  - The line segment "A" is parallel to the line segment "B".

- **Line Segment B**:
  - The line segment "B" is a straight line that extends from the bottom of the image to the top.
  - The line segment "B" is parallel to the line segment "A".

### Analysis:
- **Parallel Lines**:
  - The line segments "A" and "B

<!-- image -->

<!-- image -->

<!-- image -->

(c)

<!-- image -->

<!-- image -->

(f)

<!-- image -->

## Example 7

In each of the following diagrams, shape B is the image of shape A under a translation T . For each one, express the translation in terms of a column vector.

In this image we can see a diagram. In the diagram we can see a line, a triangle and a point.

<!-- image -->

In this image, we can see a diagram. There is a line in the middle of the image. There is a text at the bottom of the image.

<!-- image -->

(b)

## Solution

- Triangle A has moved 4 units to the right and 4 units up . (a)
- The translation vector is

<!-- image -->

In this image, we can see a diagram. There is a line in the image.

<!-- image -->

## Solution

- Shape A has moved 3 units to the right and 5 units down . The translation vector is (c)

<!-- image -->

## Solution

- Triangle A has moved 4 units to the left and 4 units up . (b)
- The translation vector is

<!-- image -->

In this image, we can see a diagram with a line and a point.

<!-- image -->

## Solution

- Shape A has moved 3 units to the left (d)
- and 5 units down . The translation vector is

<!-- image -->

<!-- image -->

## EXERCISE 14.7

Each of the following diagrams, write down the column vector which represents the translation which maps shape U onto shape V.

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a diagram. There are two lines and a point.

<!-- image -->

(c)

(d)

In this image, we can see a diagram.

<!-- image -->

(e)

(f)

In this image, we can see a diagram.

<!-- image -->

In this image we can see a graph.

<!-- image -->

In this image we can see a diagram.

<!-- image -->

## Finding the image of a point or shape under a translation

## Image of a point under a given translation

## Example 1

Three points A, B and C have coordinates (2, 3), (-2, 6) and (9, -2) respectively. A', B' snd  C'

3 4 ( ) are the images of A, B and C respectively under a translation T =             . 3 4 ( )

- (a) On the same diagram, represent the points A, B, C and their respective images.
- (b) State the coordinates of A', B' and C'.

## Solution (a)

In this image, we can see a diagram. There are lines and points.

<!-- image -->

- (b) The coordinates of

A' is (5, 7)

B' is (1, 10)

C' is (12, 2)

## Image of a line segment under a given translation

## Example 2

The diagram shows the line segment of CD.

The translation T =              maps CD onto C'D'. - 2 4 ( )

Draw the line segment C'D'.

<!-- image -->

## Solution

<!-- image -->

The translation is              .

To find the image of CD we proceed as follows:

1. Move the end-points (C and D) by 2 units to the

left and 4 units up.

Mark the images as C' and D'.

2. Join C'D'.

This is shown in the diagram.

- 2

4

(

)

In this image, we can see a diagram with some lines and symbols.

<!-- image -->

## Image of a shape under a given translation

## Example 3

The diagram shows a triangle P with vertices A, B and C.

The translation T =               maps triangle P onto triangle Q. - 6 - 4 ( )

Draw and label triangle Q.

## Solution

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

Under the translation             , triangle P will move 6 units to the left and 4 units down. The position of triangle Q is shown in the diagram below. - 6 - 4 ( )

The image depicts a geometric figure with a right triangle and a line segment labeled as "A" and another line segment labeled as "B". The line segment "A" is positioned at the top of the image and extends upwards, while the line segment "B" is positioned at the bottom of the image and extends downwards.

### Description of the Figure:
- **Right Triangle**: The right triangle is a right-angled triangle, meaning the right angle is at the top of the triangle.
- **Line Segment "A"**: This line segment is positioned at the top of the image and extends upwards.
- **Line Segment "B"**: This line segment is positioned at the bottom of the image and extends downwards.

### Analysis:
- **Right Angle**: The right angle at the top of the triangle is a right angle, which means the angle formed by the line segment "A" and "B" is 90 degrees.
-

<!-- image -->

<!-- image -->

1. On a copy of each of the following diagrams draw the image of the given points under the given translations.
2. (a) T 1 = 3 6 ( )

<!-- image -->

<!-- image -->

)

)

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

2. On a copy of each of the following diagrams draw the image of the line segment PQ under the given translations.
2. (a) T = -2 3 ( )

<!-- image -->

(b)

T

=

<!-- image -->

)

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

(c)

T

=

(d)

<!-- image -->

In this image, we can see a graph.

<!-- image -->

T

=

<!-- image -->

)

In this image, we can see a graph.

<!-- image -->

3. On a copy of each of the following diagrams draw the image of the shape X under  the given translations.
4. The coordinates of a point A are (7, 2).
3. (a) Plot point A on  a sheet of graph paper.
4. (b) The translation T 1 =              maps A onto A' . 2 3 ( )
5. (i) Use your graph to find the position of A'.
6. (ii) State the coordinates of A'.
7. (c) The translation T 2 =               maps A onto A" . -3 5 ( )
8. (i) Use your graph to find the position of A".
9. (ii) State  the coordinates of A".

In this image, we can see a graph.

<!-- image -->

5. Triangle P has vertices A  (2, 2), B (4, 2) and C (3, 4). Triangle Q has vertices A' (4, 4), B' (6, 4) and  C' (5, 6).
2. (a) Using a scale of 1 cm to represent 1 unit on both axes, draw for values of x and y in the ranges 0 ≤ x ≤ 7 and 0 ≤ y ≤ 10. Draw and label triangle P and triangle Q.
3. (b) Triangle P can be mapped onto triangle Q by means of a translation. Find the column vector that represents this translation.
4. (c) The translation T =               maps triangle P onto R. -2 5 ( )

On your graph paper, draw and label triangle R.

## Finding object when image and translation vector are given.

## Example

The following diagram shows the object A which has been mapped onto the image A' under a translation T .

- (a) Write down the column vector representing the translation T .

Another translation T 1 maps A' onto A.

- (b) Write down the column vector representing the translation T 1 .
- (c) What is the relationship between T and T 1 .

## Solution

In this image, we can see a graph.

<!-- image -->

$$\begin{array} { c c } ( a ) & T = \binom { 6 } { 7 } \end{array}$$

$$\begin{pmatrix} ( b ) & T _ { 1 } = \binom { - 6 } { - 7 } \end{pmatrix}$$

- (c) T 1 = -T (They are negative vectors.)

## Observe

<!-- image -->

<!-- image -->

1. The diagram below shows five sectors, A, B, C, D and E.

In this image we can see a diagram. In the diagram we can see a diagram of a graph.

<!-- image -->

## Write down the translation that maps

- (i) sector A onto sector B,
- (iii) sector B onto sector D,
- (v) sector C onto sector D,
- (vii) sector B onto sector C,
- (ii) sector B onto sector A,
- (iv) sector D onto sector B,
- (vi) sector D onto sector C,
- (viii)   sector C onto sector B
- (ix) sector E onto sector D,
- (x) sector D onto sector E.
2. In the following table, fill in with the appropriate column vectors representing the given translations.

<!-- image -->

<!-- image -->

<!-- image -->

| Column vector representing the translation which maps X onto Y .   | Column vector representing the translation which maps Y onto X .   |
|--------------------------------------------------------------------|--------------------------------------------------------------------|
| 3 - 5 ( )                                                          |                                                                    |
| -5 - 4 ( )                                                         |                                                                    |
| 0 5 ( )                                                            |                                                                    |
|                                                                    | 5 0 ( )                                                            |
|                                                                    | -2 5 ( )                                                           |

<!-- image -->

<!-- image -->

3. Copy each of the following diagrams and draw the object X, given its image X' and the translation T which maps X onto X'.

In this image we can see a graph.

<!-- image -->

## Summary

- 1)  A ' Vector '  is defined as a quantity having both a magnitude and a direction .
- 2)  A scalar quantity has magnitude only.
- 3)  Two vectors are said to be equal if they have equal magnitude and same direction.
- 4)  Column vector:

In this image, we can see a diagram. There are two lines and a point.

<!-- image -->

<!-- image -->

- 5)  A translation moves a set of points from one position to another through the same distance in the same direction .

In this image, we can see a diagram with a line and a point.

<!-- image -->

<!-- image -->

same direction

<!-- image -->

same distance

- A translation is denoted by the letter T and represented by a column vector as T =              . The letter h represents the horizontal movement and k represents the vertical movement. h k ( )
- When we move a point,
- (a) we do the horizontal movement (right or left) first, either + or -,
- (b) then we  do the vertical movement (up and down), either + or -.

In this image, we can see a diagram. There is a line, which is in the shape of a triangle. There is a point, which is in the shape of a line. There is a line, which is in the shape of a triangle. There is a point, which is in the shape of a line. There is a line, which is in the shape of a triangle. There is a point, which is in the shape of a line. There is a line, which is in the shape of a triangle. There is a point, which is in the shape of a line. There is a line, which is in the shape of a triangle. There is a point, which is in the shape of a line. There is a line, which is in the shape of a triangle. There is a point, which is in the shape of a line. There is a line, which is in the shape of a triangle. There is a point, which is in

<!-- image -->

· If T =             is the translation which maps A onto A', then T = is the translation which maps A' onto A. h k ( ) -h -k ( )

In this image, we can see a diagram with some text and numbers.

<!-- image -->

## Continuous Assessment

1. Circle the correct answer.
2. (a) What is a scalar quantity?
- A. A quantity described by direction only.
- B. A quantity described by magnitude only.
- C. A quantity described by both a magnitude and a direction.
- D. A quantity with a magnitude of one.
7. (b) What is a vector quantity?
- A.     A quantity described by direction only.
- B.     A quantity described by magnitude only.
- C.     A quantity described by both a magnitude and a direction.
- D.     A quantity with a magnitude of one.
- c) Which of the following measurements is a scalar measurement?
- A. Speed
- B. Velocity
- C. Force
- D. Acceleration
17. (d)  What symbol is typically used to draw a vector?
- A.   A directed line
- B.   A line segment
- C.  A box
- D.  A cross
2. Choose between scalar and vector quantity by putting a tick accordingly

|     |                                                                          | Scalar quantity   | Vector quantity   |
|-----|--------------------------------------------------------------------------|-------------------|-------------------|
| (a) | An airplane is flying at 250 km/h due west from Mauritius to Madagascar. |                   |                   |
| (b) | The Rs 200 000 car was parked in the backyard.                           |                   |                   |
| (c) | The athlete accelerated towards the finish line at a rate of 3 m/s 2 .   |                   |                   |
| (d) | The tree was pulled downward with the force of 25 N.                     |                   |                   |

3. Draw the vector AB =               in the grid below. -2 3 ( )
4. Draw a vector which is equal to the vector p in the grid below.
5. Are the following pairs of vectors equal? Justify your answer.
6. Find the magnitude of each of the following vectors.

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

In this image we can see a diagram.

<!-- image -->

$$\left ( \begin{matrix} & p = \left ( \begin{matrix} & 5 \\ 1 2 \end{matrix} \right ) & \left ( \text{(ii)} \right ) & q = \left ( \begin{matrix} - 9 \\ 1 2 \end{matrix} \right ) & \left ( \text{(iii)} \right ) & r = \left ( \begin{matrix} - 0. 3 \\ - 0. 4 \end{matrix} \right ) & \left ( \text{(iv)} \right ) & s = \left ( \begin{matrix} - 4 \\ 0 \end{matrix} \right ) & \left ( \text{(v)} \right ) & t = \left ( \begin{matrix} \sqrt { 5 } \\ 2 \end{matrix} \right )$$

7. The vector u is defined as u =               . Given that | u | = 20 units, find the possible values of k . k 16 ( )

8. In each of the following diagrams, write down the column vector which represents the translation that maps object A onto image A'.
9. On a copy of each of the following diagrams draw the image of the object Q under the given translation.

In this image, we can see a diagram with some lines and a symbol.

<!-- image -->

(a)

T

=

<!-- image -->

<!-- image -->

- 3

2

(

)

<!-- image -->

<!-- image -->

<!-- image -->

10. On a copy of each of the following diagrams draw the object Z, given its image Z' and the translation T which maps Z and Z'.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Notes

## STATISTICS

## Learning Objectives

## By the end of this chapter, you should be able to:

- use raw data to construct a frequency table.
- determine the mean, median and  mode for ungrouped frequency distribution (using frequency table).

In  Grades 7 and 8, you learnt about Statistics, which is all about collecting, representing and analysing data.  In this chapter,  you  will  learn  how  to  construct  frequency  tables and use them to find mean, median and mode.

Before going any further into this chapter, a brief recap will be done on topics learnt in Grades 7 and 8.

## Pictograms, Bar Charts and Pie Charts

## Example 1

The pictogram below shows the oil consumption, in litres, by a group of people in a month.

| Name    | Number of litres of oil used   |
|---------|--------------------------------|
| Sandeep |                                |
| Yannick |                                |
| Nancy   |                                |
| Zaynah  |                                |
| Kenny   |                                |
| Ansen   |                                |

## CHECK THAT YOU CAN:

- Use and interpret frequency tables.
- Construct pictograms, bar charts and pie charts.
- Find the mean, mode and median of a set of numbers.

<!-- image -->

## KEY TERMS

- Data
- Tally marks
- Pie chart
- Bar Chart
- Pictogram
- Average
- Mean
- Mode
- Median
- Frequency

<!-- image -->

<!-- image -->

Study the pictogram and answer the following questions.

- (a)  How many litres of oil did Zaynah  use during the month?
- (b)  Who used the least amount of oil during the month? How many litres did he/she use?
- (c)   Express, in its simplest form, the ratio of  the number of litres of oil used by Nancy to the number of litres of oil used by Ansen.
- (d)  Express  Sandeep's  monthly  oil  consumption  as  a  percentage  of  Ansen's  monthly  oil consumption.
- (e)  Draw a pie chart to represent the monthly oil consumption of the six persons.
- (f) Kunal used 1 litre of oil more than Ansen. On a sheet of graph paper and using an appropriate scale, draw a bar chart to illustrate the monthly oil consumption of the seven persons.

## Solution

- (a)  Zaynah  used 4.5 litres of oil. (4 bottles and a half)
- (b)  Sandeep used the least amount of oil.  He used 2 litres of oil.
- (c)  Nancy : Ansen  = 3.5 litres : 2.5 litres

= 7 : 5 (simplest form)

- (d)  Sandeep's  oil consumption as a percentage of Ansen's oil consumption  =          × 100% 2 2.5

=  80%

(e)

| Name    |   Numberoflitres ofoilused | Angle of sector   | Angle of sector   |
|---------|----------------------------|-------------------|-------------------|
| Sandeep |                        2   | 2 20              | × 360 0 = 36 0    |
| Yannick |                        4.5 | 4.5 20            | × 360 0 = 81 0    |
| Nancy   |                        3.5 | 3.5 20            | × 360 0 = 63 0    |
| Zaynah  |                        4.5 | 4.5 20            | × 360 0 = 81 0    |
| Kenny   |                        3   | 3 20              | × 360 0 = 54 0    |
| Ansen   |                        2.5 | 2.5 20            | × 360 0 = 45 0    |

In this image we can see a chart. In the chart we can see a number of different numbers.

<!-- image -->

In this image there is a graph. On the graph there is a scale from 0 to 5. On the left side of the graph there is a text.

<!-- image -->

## Example 2

The pie chart below shows the monthly expenditures, in categories, of Mr. Kensley.

Use the data on the pie chart to answer the following questions.

- (a) In which category does Mr Kensley spend the most?
- (b) Calculate the angle for the category 'POWER'.
- (c) Express  the  expenditure  on  POWER  as  a percentage of the expenditure on FOOD.
- (d) It  is  given  that  Mr.  Kensley  spends  Rs  6000 on FOOD.  Calculate
- (i)  the amount Mr. Kensley spends on Clothes.
- (ii) the total expenditure of Mr. Kensley.

## Image Description

The image is a pie chart that is divided into several sections. Each section represents a different category, and the colors of the sections correspond to the percentage values of the categories. The pie chart is titled "Household expenditure."

### Pie Chart Description

- **Left Section:**
  - The left section is labeled "Food" and has a value of 120.
  - The right section is labeled "Power" and has a value of 55.
  - The left and right sections are colored in a gradient of blue, orange, and purple.

- **Middle Section:**
  - The middle section is labeled "Clothes" and has a value of 55.
  - The right section is labeled "Transport" and has a value of 60.
  - The left and right sections are colored in a gradient of purple, orange, and green.

- **Right Section:**
  - The right section

<!-- image -->

## Solution

- (a)  Mr Kensley spends the most on FOOD. (biggest sector; largest angle)
- (b)  Angle for Category 'POWER' = 360°- (120° + 35° + 55° + 50° + 60°)
- = 360°- 320°
- = 40°.

- (c)   Expenditure on POWER as a percentage of expenditure on FOOD  =            × 100% =  33     %. (d)  120° Rs  6000 1° Rs (i) Amount spent on 'Clothes' = Rs              × 55° = Rs 2750. (ii) Total amount spent = Rs              × 360° = Rs 18000. 40 0 120 0 6000 120 0 6000 120 0 6000 120 0 1 3

<!-- image -->

## EXERCISE 15.1

1. The pictogram below shows the number of honey jars sold by Mrs Edouard in Rodrigues island.
2. (a)   In which month was the least amount of honey jars sold?  State the number of jars sold in this month.
3. (b)  What is the difference in the number of jars sold  in April and May?

| Month    | Number of honey jars sold                 |
|----------|-------------------------------------------|
| January  | HONEY HONEY HONEY HONEY HONEY             |
| February | HONEY HONEY HONEY                         |
| March    | HONEY HONEY HONEY HONEY HONEY HONEY HONEY |
| April    | HONEY HONEY HONEY                         |
| May      | HONEY HONEY HONEY HONEY HONEY HONEY       |

<!-- image -->

50

0

- (c)   Mrs Edouard sells honey jars at Rs 100 each.
- (i)  What was the amount she received in March for the honey jars sold?
- (ii) Calculate the total amount of money she received in selling the honey jars over the first five months of the year.
2. The bar chart below shows the number of students present in a class of 36 each day in a given week.
- (a)   On which day were all the students present?
- (b)  What was the difference between the number of students present on Friday and Tuesday?
- (c)   On which day was there a greater number of students absent ?
- (d)  Calculate  the  total  number  of absences for the given week.
3. The table below shows the different regions which the members of the National Football team come from.
- (i) From which region do most players come from?
- (ii)   How many members does the National Football team consist of?
- (iii)  What fraction of the players come from the South?
- (iv)  Draw a bar chart to illustrate the information given in the table.
4. The pie chart shows information about the sales of 1200 tickets for a concert.
- There were twice as many adult ticket sales as senior citizen ticket sales.
- (a)  Calculate the angles for the sectors  representing  Adult  and Senior Citizen.
- (b)  Show that there were 420 Adult ticket sales.
- (c)   Find the difference between the Child ticket sales and the Senior Citizen ticket sales.
- (d)  Draw a bar chart to represent the Child,  Adult  and  Senior  Citizen ticket sales.

In this image we can see a graph. On the graph we can see numbers.

<!-- image -->

| Region         |   North |   South |   East |   West |   Centre |
|----------------|---------|---------|--------|--------|----------|
| No. of players |       4 |       5 |      3 |      9 |        4 |

The image is a pie chart titled "Ticket Sales." The pie chart is divided into four sections, each representing a different category of tickets sold. The categories are: "Senior Citizen," "Child," and "Adult." The x-axis represents the percentage of tickets sold, ranging from 0% to 100%. The y-axis represents the percentage of tickets sold, ranging from 0% to 100%.

### Detailed Description:
1. **Senior Citizen**
   - The pie chart represents the percentage of tickets sold for the Senior Citizen category.
   - The percentage is represented by the segment labeled "171%."

2. **Child**
   - The pie chart represents the percentage of tickets sold for the Child category.
   - The percentage is represented by the segment labeled "170%."

3. **Adult**
   - The pie chart represents the percentage of tickets sold for the Adult category.
   - The

<!-- image -->

<!-- image -->

## MEAN, MODE, MEDIAN

## THE MEAN

Shane has 4 children.  He bought 20 sweets and shared them among his children as follows:

Yushi

Myiesha

Aki

Shivangi

8 sweets

<!-- image -->

5 sweets

<!-- image -->

<!-- image -->

3 sweets

<!-- image -->

## Was it a fair sharing?

If Shane had made an equal sharing, every child would have obtained

$$\frac { 8 + 4 + 5 + 3 } { 4 } \ & = \ \frac { 2 0 } { 4 } \\ & = \ 5 \text{sweets}$$

The mean number of sweets (or average number of sweets)  per children is the number of sweets each child would have received if there had been a fair sharing.

In this example, mean = total number of sweets number of children =  5 sweets

As you have learnt in Grade 8,

Mean

=

sum of all observations

total number of observations

## THE MODE

The mode is the element which occurs most frequently.

## THE MEDIAN

The Median is the middle value of  the  data  set  when arranged in ascending or descending  order.    If  the  data set  consists  of  an  even  number of information, there will be two middle values.  In this case, the median will be the mean of these two middle values.

## Example 1

The following  information represents the marks scored in a Maths test which was on 50 marks.

31, 36, 39, 35, 32, 22, 39, 30, 18, 44, 27, 39, 33, 23.

From the set of marks, find  the mean.

## Solution

Mean   =

=

## sum of all observations

total number of observations

31 + 36 + 39 + 35 + 32 + 22 + 39 + 30 + 18 + 44 + 27 + 39 + 33 + 23

14

=

448

14

=    32

## Note:

- (i)   The mean needs not always be a whole number.
- (ii)   The mean is always a number which lies between the smallest and the largest value of the data set.

## Example 2

The following data represent the size of shoes sold at a particular shop.

42, 43, 39, 38, 39, 40, 42, 43, 42, 41, 42, 45, 39, 40, 42

Find the mode.

## Solution

The mode is 42. ( The shoe size which was most commonly sold.)

## Example 3

- (a) Find the median of   5, 1, 6, 3, 9.
- (b) The following represent the marks scored in a test.

31, 36, 39, 35, 32, 22, 39, 30, 18, 44, 27, 39, 33, 23

Find the median mark.

## Solution

- (a) Arrange the numbers in ascending order. (or descending order)

1, 3, 5, 6, 9.

Cut one number on each side of the list until the middle term is located.

1, 3, 5, 6, 9.

The median is 5.

- (b)   For the median, the information  must first be arranged in ascending order.

18, 22, 23, 27, 30, 31, 32, 33, 35, 36, 39, 39, 39, 44

Cut off one number on each end until we find the middle number/s.

18, 22, 23, 27, 30, 31, 32, 33, 35, 36, 39, 39, 39, 44

There are two middle values: 32 and 33.

$$\text{Therefore, median } = \, \left [ \frac { 3 2 + 3 3 } { 2 } \right ]$$

=    32.5

## Note:

- (i)  Median  =  32.5  means  that  seven  students scored more  than 32.5 marks  and seven students scored  less than this mark.
- (ii)  The median is a mark which lies between the lowest and the highest mark in the list.

## Note:

- (i)   In a data set, there may be two modes, that is, two values which occur most frequently (in an equal number of times.)
- (ii)  There  are  data  sets  which  do  not  have  any mode. (Each information occurs only once.)
- (iii) If data values are all alike, there is no mode. Example: There is no mode for the set 6, 6, 6, 6 ,6.
- (iv) If all values occur the same number of times, there is no mode. Example: There is no mode for the data set 3, 2, 3, 2, 3, 2, 4, 4, 5, 5. (as all values occur the same number of times)

<!-- image -->

1. Find the mean, mode and median  for the following sets of numbers.
2.    Fawwaz  received  Rs  825  for  a  week  in  which  he  worked  for  5  days.  Calculate  the  mean amount of money he received per day.
3.    The mean mass of  Rayaan,  Ah Kwet, Yoni and Vidoushi is 64 kg. The mass of Rashid is 44 kg. Calculate the mean mass of the five boys.
4.    The following are the daily lengths of time taken by Julia to do her homework: 58 minutes, 1 hour and 10 minutes, 75 minutes, 1.2 hours, 1     hours, 5 hours and 1.25 hours. 1 4
5. What is the modal length of time spent on doing homework by Julia?
5.    If a number is removed from the set 15, 14, 18 ,17, 15, 17, 16, 14, 15, 17, the mode will be 17 only. What is the number?
6.    The median of  5, 2, 8, 9, 4, 10, 11, 7, 13,  and x is 8.  Find the value of x .

| (a)   | 2, 3, 7, 3, 5                    | (b) 12, 18, 25, 23, 30, 24               |
|-------|----------------------------------|------------------------------------------|
| (c)   | 22.1, 23, 24.4, 26, 22.8, 23, 26 | (d) -2.4, 3.6, -1.8, 2.0, 1.6, 2.4, -1.2 |

## Frequency tables

<!-- image -->

The figure  below  shows  a  tablet  of  chocolate  beans  of  different  colours  (red,  blue,  yellow, green and orange). Study the figure, complete the table and answer the questions which follow.

In this image we can see a group of capsules.

<!-- image -->

Activity

| Colour of bean   | Tally Marks   | Frequency   |
|------------------|---------------|-------------|
| Red              |               |             |
| Blue             |               |             |
| Yellow           |               |             |
| Green            |               |             |
| Orange           |               |             |

- (a) What is the total number of beans?
- (b) Which colour has the most number of beans?
- (c) Which colour of bean  is least common?
- (d) What is the difference between the number of red beans and green beans?

## The mean  from a frequency table

<!-- image -->

The following data represents the number of goals per match that Lionel Messi scored in La Liga during the season 2018-2019.

Lionel Messi

2, 0, 2, 0, 1, 0, 0, 1, 1, 2, 0, 0,

2, 3, 1, 1, 1, 1, 1, 1, 2, 0, 1, 3,

0, 1, 3, 2, 1, 1, 0, 0, 1, 0, 2

In this image we can see a jersey with number 10 on it.

<!-- image -->

Using the information above, find

- (i)  the number of  matches Messi played during that season,
- (ii)   the total number of goals he scored,
- (iii) the mean number of goals Messi scored.

## Solution

- (i)   Messi played 34 matches during the season 2018 - 2019.  (counting the number of values)
- (ii)   He scored 36 goals. (adding all the values)
- (iii) Mean number of goals for Lionel Messi  = = total number of goals scored total number of matches played 36 34

## An alternative approach

When there is a large number of data values, we can use a frequency table.

The information gathered concerning the number of goals by Lionel Messi during the season 2018-2019 can be displayed on a frequency table as follows.

| Lionel Messi          | Lionel Messi          | Lionel Messi                      |
|-----------------------|-----------------------|-----------------------------------|
| Number of goals ( x ) | Tally Marks           | Number of matches (frequency, f ) |
| 0                     | | | | | | | | | |     | 11                                |
| 1                     | | | | | | | | | | | | | 13                                |
| 2                     | | | | | | |           | 7                                 |
| 3                     | | | |                 | 3                                 |

Note: It  is  a  good  practice  to label the columns as x and f .

- (i) Total number of matches played by Messi = 11 + 13 + 7 + 3  (Sum of frequencies, f ) =  34
- (ii) It is important to understand what the information in the table represents.
- For instance, Messi scored 2 goals in each of the 7 matches and  this gave a total of 2 + 2 + 2 + 2 + 2 + 2 + 2 + 2 , i.e, 2 × 7 = 14 goals for these 7 matches. (See yellow row in table.)

Hence, the total number of goals Messi scored was

<!-- image -->

( (0 × 11) + (1 × 13) + (2 × 7) + (3 × 3) ) = 36 goals.  (Sum of  all goals scored)

In the frequency table, an additional column ( xf )  can be added so that the total number of goals can be calculated in a systematic way.

| Lionel Messi          | Lionel Messi                              | Lionel Messi                             |
|-----------------------|-------------------------------------------|------------------------------------------|
| Number of goals ( x ) | Number of matches (frequency, f )         | xf (Number of goals in all the matches)  |
| 0                     | 11                                        | 0 × 11 = 0                               |
| 1                     | 13                                        | 1 × 13 = 13                              |
| 2                     | 7                                         | 2 × 7 = 14                               |
| 3                     | 3                                         | 3 × 3 = 9                                |
|                       | Total number of matches = 34 (Sum f = 34) | Total number of goals = 36 (Sum xf = 36) |

- (iii)   Mean number of goals for Lionel Messi   =

total number of goals scored total number of matches played

- = = =     1 sum of xf sum of f 36 34 1 17

## Try it!!

The number of goals Cristiano Ronaldo scored in Italian ' Serie A' during the season 2018-2019:

<!-- image -->

| Cristiano Ronaldo             |
|-------------------------------|
| 0, 0, 0, 2, 1, 0, 0, 1, 1, 2, |
| 0, 1, 1, 1, 0, 1, 0, 1, 2, 0, |
| 1, 2, 1, 1, 0, 0, 0, 1, 1, 0  |

- (a)  Construct  a  frequency  table  to  represent the given information.
- (b) Calculate  the  mean    number  of  goals  for Cristiano Ronaldo using the frequency table.
- (c)  Between Messi  and  Ronaldo,  who  has the  highest  goal  scoring  average  for  the season 2018-2019?

<!-- image -->

## EXERCISE 15.3

1. Find the mean of the following frequency distributions.

(a)

| x   |   0 |   1 |   2 |   3 |   4 |   5 |
|-----|-----|-----|-----|-----|-----|-----|
| f   |  13 |  10 |  10 |   4 |   7 |   6 |

## (b)

| Score, x   |   1 |   2 |   3 |   4 |   5 |
|------------|-----|-----|-----|-----|-----|
| Frequency  |  10 |   8 |   9 |   6 |   7 |

2. Thirty women were asked how many children they had. The answers were as follows.
2. (i) Construct a frequency table for the above results.
3. (ii)  Calculate the mean number of children per woman.

|   1 |   0 |   0 |   2 |   3 |   1 |   1 |   0 |   2 |   4 |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
|   1 |   0 |   1 |   2 |   3 |   2 |   1 |   1 |   0 |   3 |
|   5 |   1 |   2 |   4 |   2 |   3 |   0 |   1 |   0 |   2 |

3. Thirty four students were asked about the number of copybooks they had used during the first term.  The record was as follows.
2. (i)   Find the value of x .
3. (ii) Find the mean number of copybooks used by the students during the first term.

| No. of copybooks   |   6 |   7 | 8   |   9 |   10 |
|--------------------|-----|-----|-----|-----|------|
| No. of students    |   1 |   5 | x   |  12 |    6 |

## The mode from a frequency table

To find the mode from a frequency table, simply identify the information which has the highest frequency.

## Example

Refer to the frequency table for the number of goals scored by Messi.  Find the mode number of goals scored by Messi.

| Lionel Messi    | Lionel Messi                  |
|-----------------|-------------------------------|
| Number of goals | Number of matches (frequency) |
| 0               | 11                            |
| 1               | 13                            |
| 2               | 7                             |
| 3               | 3                             |

## Solution

| Lionel Messi    | Lionel Messi                  |
|-----------------|-------------------------------|
| Number of goals | Number of matches (frequency) |
| 0               | 11                            |
| 1               | 13                            |
| 2               | 7                             |
| 3               | 3                             |

## Try it!

From the frequency table that you have constructed for the number of goals scored by Cristiano Ronaldo, state the mode.

Note: The  mode  is  the  information with the highest frequency. So, the mode is 1.

## Caution

The highest frequency is not the mode. In this case, the mode is not 13, but 1 that is the data value which occurred the most number of times.

<!-- image -->

1. State the mode from the following frequency distributions.

(a)

| x   |   30 |   40 |   50 |   60 |   70 |   80 |
|-----|------|------|------|------|------|------|
| f   |   27 |   29 |   30 |   12 |    5 |    4 |

## (b)

| Score     |   1 |   2 |   3 |   4 |   5 |   6 |
|-----------|-----|-----|-----|-----|-----|-----|
| Frequency |  15 |  12 |  15 |  20 |  22 |  10 |

2. In a book, there are some misprints on the pages.
2. (a) How many pages are there in the book?
3. (b) State the modal number of misprints.
3. The table below shows the number of cakes eaten by a certain number of pupils.

| No. of misprints   |   0 |   1 |   2 |   3 |   4 |   5 |   6 |
|--------------------|-----|-----|-----|-----|-----|-----|-----|
| No. of pages       |  20 |  39 |  12 |   5 |   4 |   1 |   1 |

| No. of cakes    |   0 |   1 | 2   |   3 |   4 |
|-----------------|-----|-----|-----|-----|-----|
| No. of children |   5 |  15 | x   |   9 |   5 |

In each of the following cases, find

- (i) the value of x if there are 40 pupils.
- (ii) the greatest possible value of x if the mode is 1.
- (iii)   the least possible value of x if the mode is 2.

## The median from a frequency table

Suppose that we want to find the median number of goals scored by Lionel Messi

In this image there is a jersey on the right side.

<!-- image -->

We first arrange the information in ascending order as follows:

0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3

Median =                   (the average of the two middle values, that is, the 17 th and the 18 th value)

$$\text{Median} & = \frac { \Omega + \Omega } { 2 } \\ & = 1.$$

Alternatively,  to calculate the median from the frequency table, it would be desirable to know the positions of each data.

| Lionel Messi    | Lionel Messi                  | Lionel Messi               | Lionel Messi   |
|-----------------|-------------------------------|----------------------------|----------------|
| Number of goals | Number of matches (frequency) | Cumulative frequency (c.f) | Position       |
| 0               | 11                            | 11                         | 1 st to 11 th  |
| 1               | 13                            | 11 + 13 = 24               | 12 th to 24 th |
| 2               | 7                             | 24 + 7 = 31                | 25 th to 32 nd |
| 3               | 3                             | 31 + 3 = 34                | 33 rd to 36 th |

The 17 th and the 18 th value are both in this row, that is , they are both equal to  1.

Messi played 34 matches.  The middle values will be the 17 th  and the 18 th   data and hence,

$$t h$$

## Note:

- (i) If  there  are  n  values  in  the  data  set,  the  middle value will be the th value.  In case n is ( ( n + 1 2

even, the median will be the average of the two middle values.

- (ii)   The  median  can  be  a  value  which  is  not  in the table.

$$\begin{array} { c c c } & \text{Mesi played 34 matches.  The middle values v \\ & \text{Median } = & \left ( \frac { 3 4 + 1 } { 2 } \right ) ^ { \text{th} } \text{term} = 17.5 ^ { \text{th} } \text{term} \\ & & = & \frac { 1 7 ^ { \text{th} } \text{term} + 18 ^ { \text{th} } \text{term} } \\ & & = & \frac { 1 + 1 } { 2 } \\ & & = & 1 \end{array}$$

## Try it!

From the frequency table for the number of goals scored by Cristiano Ronaldo, find the median.

<!-- image -->

## 1. Add the cumulative frequency (C.F) column to the following frequency tables.

(a)

| x   |   3 |   4 |   5 |   6 |   7 |   8 |
|-----|-----|-----|-----|-----|-----|-----|
| f   |   2 |   9 |   3 |   1 |   5 |   3 |

## (b)

| x   |   10 |   11 |   12 |   13 |   14 |   15 |
|-----|------|------|------|------|------|------|
| f   |    7 |    3 |   12 |   10 |    4 |    5 |

## 2. Find the median from the frequency tables given below.

(a)

| x   |   1 |   4 |   5 |   7 |   9 |   10 |
|-----|-----|-----|-----|-----|-----|------|
| f   |   8 |   9 |  12 |  14 |   4 |    2 |

(b)

| x   |   100 |   200 |   300 |   400 |   500 |   600 |
|-----|-------|-------|-------|-------|-------|-------|
| f   |    25 |    36 |     9 |    20 |    22 |    10 |

3. The table below shows the number of matchsticks in 50.
2. (i)  Find the value of x .
3. (ii) Find the median number of matchsticks.

| Number of matchsticks   |   58 |   59 | 60   |   61 |   62 |   63 |
|-------------------------|------|------|------|------|------|------|
| Number of boxes         |    9 |   12 | x    |   11 |    7 |    3 |

## Summary

- Pictograms, pie charts and bar charts are used to represent data.  They should always have a title.
- A pictogram is a chart which consists of pictures or symbols to represent data. A key is essential when drawing a pictogram.
- A pie chart consists of sectors such that each sector represents the proportion of the data.
- A bar chart is constructed using spaced  rectangular bars of equal width.  The height of the bars correspond to the frequency of each data.
- Mean  = sum of all observations total number of observations
- =                      (from a frequency table) sum of xf sum of f
- Mode is the observation that appears most often. From a frequency table, it is the information which has the highest frequency.
- The median is the middle value of a data set.

## Some helpful links

<!-- image -->

https://www.mathsisfun.com/data/bar-graphs.html

## Continuous Assessment

1. Some children were asked to name their favourite sweet flavour. The pie chart and table show some information about their answers. Use the pie chart to complete the table.
2. The table below shows the number of children in the families living in Trafford Lane.

<!-- image -->

| Flavour    | Number of children   | Angle of sector   |
|------------|----------------------|-------------------|
| Vanilla    | 24                   | 90 0              |
| Chocolate  |                      | 120 0             |
| Strawberry |                      |                   |
| Mint       |                      | 45 0              |

|   Number of children |   Number of families (Frequency) |
|----------------------|----------------------------------|
|                    0 |                                4 |
|                    1 |                               11 |
|                    2 |                               13 |
|                    3 |                                5 |
|                    4 |                                1 |
|                    5 |                                1 |

From the information provided in the table, find

- (i)   the number of families living in Trafford Lane.
- (ii)   the number of children living in Trafford Lane.
- (iii)   the number of families in which are more than two children.
- (iv)   the mean number of children per family.
- (v)  the median number of children.
- (vi)   the mode for the number of children.
3. A six sided die is thrown 49 times. The results are summarised in the table below.
- (i)   State the mode.
- (ii)   Find the median.
- (iii)   The die is thrown one more time.  Find the number shown on the die if the mean of the 50 throws is to be exactly 3.
4.  The numbers 13, 17, 23, 24, 26, 29, 30 and x are arranged in ascending order.  Find the value of x given that the mean is equal to the median.
5.  The mean of ( x + 1), ( x + 2), (2 x + 1), ( x - 3) and (2 x - 1) is 28.  Find the value of x .
6. The mean, median and mode of  4 numbers are 104, 106, and 110 respectively.  Find the four numbers.

| Number on die   |   1 |   2 |   3 |   4 |   5 |   6 |
|-----------------|-----|-----|-----|-----|-----|-----|
| Number of times |  11 |   9 |  12 |   6 |   7 |   4 |

## Notes

## PROBABILITY

## Learning Objectives

## By the end of this chapter, you should be able to:

- demonstrate an understanding of the terms: probability, sample space, outcome and event (simple ,combined ,complement).
- find the probability of simple and combined events.
- construct and use simple possibility diagrams to find probabilities.

## Probability in real life

Probability has something to do with chance. We do not actually calculate  probability  in  our  daily  life  but  use  it  subjectively  to determine the course of action or any judgment. Everything from the  weather  forecast,  the  chance  of  reaching  school  on  time, the possibility of a student to become a Prime Minister, and so on is a probability.

<!-- image -->

<!-- image -->

KEY TERMS

- Probability
- Outcomes
- Events
- Random
- Likely
- Chances

## Probability is a measure of the chance that an event will occur.

- Sample space
- Possibility diagram

<!-- image -->

<!-- image -->

In this image we can see the weather forecast.

<!-- image -->

## History of Probability

In the 17 th  century, gambling was very popular and fashionable. In a discontinued dice game, De Mere, a nobleman, wanted to divide the stake according to the chance each player could win the game. As he was unable to do so, he asked the French mathematicians Blaise Pascal and Pierre de Fermat to find a mathematical method for computing chances. The correspondence between these two mathematicians to find a solution for De Mere is the origin of the mathematical study of probability.

Pierre de Fermat

In this image we can see a few paintings.

<!-- image -->

Blaise Pascal

## The sample space

The sample space is the set of all possible outcomes (result) of an experiment.

## For example

- For the experiment of tossing a coin, the sample space is {Head, Tail}.
- For the experiment consisting of rolling a single six-sided die, the sample space is {1, 2, 3, 4, 5, 6}.

<!-- image -->

<!-- image -->

## An event

An event is the set of outcomes of an experiment and is a subset of the sample space.

For example, obtaining a 'Head' while tossing a coin is an event.

## Calculating probability of an event

The probability of an event A, is denoted by P (A) and is calculated as follows:

P (A) =

total number of outcomes resulting in A

total number of possible outcomes

## Example 1

A fair die is tossed. Find the probability of obtaining an even number.

## Solution:

Sample Space = {1, 2, 3, 4, 5, 6} Number of favourable outcomes = 3 Event A = {outcome is even} = {2, 4, 6}

Total number of outcomes = 6

Thus P(even number) = 3 6

= 1 2

Note: Probability answers are given in simplified fractions.

<!-- image -->

## Example 2

A drawer contains 10 identical handkerchiefs of which 2 are white, 5 are blue and 3 are pink. A handkerchief is drawn at random.

What is the probability that it is white or pink?

2 W

5 B

3 P

## Solution:

Total number of outcomes =  10

P(the handkerchief is white or pink) = 2 + 3 10

$$= \frac { 5 } { 1 0 }$$

= 1 2

## Example 3

Sandy wants to organise a party next week. She picks a day at random from the days of a week. State the probability that the day she chooses

- (i) is Monday,
- (ii) starts with the letter S,
- (iii) ends with the letter y,
- (v) has an even number of letters,
- (iv) consists of 10 letters,
- (vi) is a school day.

## Solution:

The sample space consists of the 7 days of the week: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday and Sunday.

- (i) P(Monday) = 1 7
- (ii) P(the day chosen is a word starting with the letter S ) = 2 7
- (iii) P(the day chosen is a word ending with the letter y) =       = 1 7 7
- (iv) P( the day chosen is a word with 10 letters) = 0
- (v) P(the day chosen is a word with an even number of letters) = 5 7
- (vi) P(the day chosen is a school day) = 5 7

## Observations

1. It is very important to understand that the probability of any event always takes values from 0 to 1 inclusive, that is 0 ≤ P (A) ≤ 1 .
2. When we are  certain  (that  is  we  are  100%  sure),  that  an  event  will  take  place,  the probability of that event is 1. Example: The probability that we will die one day is 1.
3. When it is impossible for the event to happen, the probability of that event is 0. Example: A bag contains 4 red and 2 blue marbles. The probability of getting a yellow marble is 0.
4. Otherwise it is always a proper fraction.

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

1. Circle the correct answer.
2. (i) The sample space when an ordinary die is rolled once is
3. A {1, 2, 3, 5, 6} C {d, i, e} B {0, 1, 2, 3, 5, 6} D {1, 2, 3, 4, 5, 6}
4. (ii) The greatest value that a probability can take is

$$\text{A} \ \ 0 \ \ \ B \ 1 \ \ 0 \ \ 0 \ \ 0 C \ 1. 2 \ \ 0 \ \ 0 \ \ 0 D \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \$$

2. A multiple-choice question consists of 4 possible answers. Larry answers the question by guessing. What is the probability that he gets the correct answer?
3. A fair die is rolled once. Find the probability of obtaining
3. (a) a prime number,
4. (b) the factors of 6,
5. (c) an even number,
6. (d) a number less than 8,
7. (e) a number greater than 4,
8. (f) the number 7.
4. ξ = {integers from 1 to 15 inclusive}

A = {multiples of 5}

B = {odd numbers}

A number is selected at random from the universal set.

Find

- (a) P( A ),

(b) P( B ),

- (c) P( A ∩ B ), (d) P( A ∪ B ),

- (e) P( A ' ∩ B ) .

5. A number is selected from the list below.

$$\sqrt { 2 } \,, \ \ 4 \,, \ \stackrel { s } { \sqrt { 3 2 } } \,, \ \frac { 2 0 } { 5 } \,, - 3 \,, \ \ 6 4 \,, \ \ - 2 0 \,.$$

Find the probability that it is

- (a) an irrational number,
- (b)   a square number,
- (c) equal to 2,
- (d)   the number 10,
- (e) less than -1.

6. 30 students were asked whether they have a cat or a dog. The information is illustrated in the Venn diagram below.

<!-- image -->

A student is chosen at random from the class. Calculate the probability that this student

- (a) has a cat,
- (b)   has a dog only,
- (c) does not have a dog,
- (d)   has a dog or a cat,
- (e) has both a cat and a dog,
- (f) has neither a dog nor a cat.
7. A box contains red, white and black balls. There is a total of 30 balls in the box. A ball is
- drawn at random. The probability that it is white is         and the probability that it is black 1 3
- is        . 2 5

Calculate the probability of obtaining a red ball and hence, find the number of red balls in the box.

8. A basket contains a certain number of balls.         of the balls is red,       is white and the rest is black. 1 4 2 5
2. A ball is taken out of the box at random. Find the probability that
3. (a) it is either red or white,
4. (b) it is not white,
5. (c) it is black.

If there are 40 balls in the bags, how many balls are red?

<!-- image -->

9. A letter is chosen at random from the word P  R  O  B  A  B  I  L  I  T  Y Find the probability that the letter is
2. .
3. (a) B or I ,
4. (b)   neither A nor R ,
5. (c) S ,
6. (d)   a consonant or a vowel.

10. A bag contains 5 black balls, 2 blue balls and 8 green balls. A ball is chosen at random from the bag.

Find the probability that it is

- (a) green,
- (b)   yellow,
- (c) blue or green,
- (d)   not blue,
- (e) black or white or blue or green.

## The probability of the complement of an event

## Example

Vidoushi has 7 pens in her pencil case, 2 of which are black. She takes a pen at random from her pencil case. Find the probability that the pen is

- (i) black,
- (ii) not black.

## Solution

- (i) Total number of pens
- = 7

Number of black pens    = 2

$$P ( \text{black} ) = \, \frac { 2 } { 7 }$$

- (ii) Number of pens which are not black

= 7 - 2 = 5

In this image, we can see a brown color pencil case. Inside the pencil case, we can see some colored pencils.

<!-- image -->

$$P ( \text{not black} ) = \frac { 5 } { 7 }$$

Observe that P(black) + P( not black) =       + 2 7 5 7

Note also that P(not black) = 1- P(black)

The event 'not black' is known as the complement of event 'black' .

The complement of an event A , denoted by A΄ , is the event that A does not occur .

$$\text{Hence,} P ( A ^ { \prime } ) = 1 - P ( A )$$

## Example

The probability that Kevin will be late to school tomorrow  is        . 1 10

What is the probability that he will not be late tomorrow?

## Solution

P(Kevin is not late)

=1- P(Kevin is late)

$$& = 1 - \frac { 1 } { 1 0 } \\ & = \frac { 9 } { 1 0 }$$

In this image we can see two boys running on the road. In the background there is a building.

<!-- image -->

<!-- image -->

## EXERCISE 16.2

- 1 The probability that a team wins a football match is 0.7. State the probability that the team does not win the match.
- 2 In a competition, the probability that an archer misses a target is      . 1 3

What is the probability that he hits the target?

<!-- image -->

- 3 An advertisement claims that 9 children out of 10 like a particular brand of cereal. According to this advertisement, what is the probability that a child chosen at random
- (a) will like this brand of cereal,
- (b) will not like this brand of cereal?
- 4 90% of the families of a small village have access to the internet. What is the probability that a family selected at random does not have access to the internet?

## Possibility Diagram

A possibility diagram is used to show all the possible outcomes of an experiment.

## Example 1

Two  fair  coins are thrown together.

The possibility diagram below displays all the possible outcomes.

In this image, we can see a table with some text and numbers.

<!-- image -->

|      |      | Coin 1   | Coin 1   |
|------|------|----------|----------|
|      |      | Head     | Tail     |
| 2    | Head | HH       | HT       |
| Coin | Tail | TH       | TT       |

<!-- image -->

Write down the probability that the coins show

- (a)   two heads,
- (b)   a head and a tail,
- (c)   at least one head.

## Solution

There are 4 possible outcomes : HH, TH, HT and TT

$$( a ) \ \ P ( \text{two heads} ) = \ \frac { 1 } { 4 }$$

- (b)   P(a head and a tail) = P(HT) or P(TH)

2

4

=

1

2

=

- P(at least one tail) = P (the coins show one tail or two tails)

3

4

=

- (c)

## Example 2

Two ordinary fair dice are rolled together.

- (a) Construct the possibility diagram to display all the possible outcomes and state the number of possible outcomes.
- (b)   Hence find the probability of obtaining
- (i) two sixes,
- (ii) two similar numbers,
- (iii) two numbers whose sum is less than 6,
- (iv) two numbers whose product is atleast 25.

## Solution

|       |    | Die 1   | Die 1   | Die 1   | Die 1   | Die 1   | Die 1   |
|-------|----|---------|---------|---------|---------|---------|---------|
|       |    | 1       | 2       | 3       | 4       | 5       | 6       |
| Die 2 | 1  | (1, 1)  | (1, 2)  | (1, 3)  | (1, 4)  | (1, 5)  | (1, 6)  |
| Die 2 | 2  | (2, 1)  | (2, 2)  | (2, 3)  | (2, 4)  | (2, 5)  | (2, 6)  |
| Die 2 | 3  | (3, 1)  | (3, 2)  | (3, 3)  | (3, 4)  | (3, 5)  | (3, 6)  |
| Die 2 | 4  | (4, 1)  | (4, 2)  | (4, 3)  | (4, 4)  | (4, 5)  | (4, 6)  |
| Die 2 | 5  | (5, 1)  | (5, 2)  | (5, 3)  | (5, 4)  | (5, 5)  | (5, 6)  |
| Die 2 | 6  | (6, 1)  | (6, 2)  | (6, 3)  | (6, 4)  | (6, 5)  | (6, 6)  |

- (a) The sample space contains 36 elements, so there are 36 possible outcomes.
- (b) (i) Two sixes = { (6, 6) }

$$P ( \text{two sixes} ) = \frac { 1 } { 3 6 }$$

- (ii) Two similar numbers = {(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)}

$$P ( \text{two similar numbers} ) \, = \, \frac { 6 } { 3 6 } \, = \, \frac { 1 } { 6 }$$

- (iii) Two numbers whose sum is less than 6 = {(1, 1), (1, 2), (1, 3), (1, 4), (2, 1), (3, 1),(4, 1)}

$$P \text{ (two numbers whose sum is less than 6) } = \frac { 7 } { 3 6 }$$

- (iv) Two numbers whose product is at least 25 = {(5, 5), (5, 6), (6, 5), (6, 6)}

P (

two numbers whose product is at least 25)  =

4

36

1

9

=

<!-- image -->

<!-- image -->

1. A six-sided ordinary die and a fair coin are tossed together.
2. (a)   Draw a possibility diagram to represent the possible outcomes.
3. (b)   Hence, state the probability of obtaining
4. (i) a six and a head,
5. (ii) a tail and a square number,
6. (iii)   a head and a tail.
2. A game consists of throwing together two fair tetrahedral dice, one with faces numbered 1, 2, 3, 4 and the other with faces numbered 2,3,4,5. The score is the difference between the two numbers shown on the faces of the dice facing down.
8. (a) Complete the possibility diagram below.
9. (b) Hence, state the probability that the score is
10. (i) 0,
11. (ii) 1 or 2,
12. (iii)   an odd number,
13. (iv)   greater than 3.
3. A basket contains 25 cookies. Some were baked by Lydia and the others were baked by Lydia's mother. There were 12 chocolate cookies and Lydia baked 5 of them. Her mother baked 15 cookies.
15. (a) Complete the table below.

<!-- image -->

<!-- image -->

|       |    | Die 1   | Die 1   | Die 1   | Die 1   |
|-------|----|---------|---------|---------|---------|
|       |    | 1       | 2       | 3       | 4       |
| Die 2 | 2  | (2, 1)  |         |         |         |
| Die 2 | 3  |         | (3, 2)  |         |         |
| Die 2 | 4  |         |         |         |         |
| Die 2 | 5  |         |         |         | (5, 4)  |

|                         | Chocolate cookies   | Non-chocolate cookies   |
|-------------------------|---------------------|-------------------------|
| Baked by Lydia          | 5                   |                         |
| Baked by Lydia's mother |                     |                         |

Lydia's sister selects a cookie at random from the box.

- (b) Find the probability that
- (i) the cookie was baked by Lydia's mother,
- (ii) the cookie was a non-chocolate biscuit baked by Lydia.

<!-- image -->

In fact, Lydia's sister selects a chocolate cookie and she eats it. Lydia then selects a cookie at random from the box. What is the probability that Lydia also selects a chocolate cookie?

In this image, we can see coins and a paper.

<!-- image -->

## Continuous Assessment

- 1 Three unbiased coins are thrown together. List all the possible outcomes.
- 2 Two fair dice are thrown at the same time. The total number of possible outcomes is equal to

A 8

B

12

C

36

D

66

- 3 A bunch of flowers consists of a certain number of identical pink and red roses. A florist picks a flower at random from the bunch of flowers. The probability of choosing a red rose
- is       and there are 18 red roses. Find 2 5
- (a) the probability that the florist chooses a flower which is not red,
- (b) the number of roses in the bunch of flowers,
- (c) the number of pink roses.
- 4 The number of international competitions that each of the 30 sportspersons participates in is recorded in the table below.
- (a) Find the value of x .
- (b) A sportsperson is selected at random.

<!-- image -->

| Number of international competitions   |   0 |   1 |   2 |   3 |   4 | 5   |
|----------------------------------------|-----|-----|-----|-----|-----|-----|
| Number of sports persons               |   5 |   4 |   6 |   8 |   5 | x   |

Write down the probability that the sportsperson has

- (i) never participated in an international competition,
- (ii) participated in less than 3 international competitions,

- (iii)  participated in more than 5 international competitions,
- (iv)   participated in more than the mean number of competitions of the group.
- 5 A social worker records the number of children per family in a particular residential area. The bar chart below displays the information recorded.
- (a)   Write down the total number of families. A family is chosen at random.
- (b) Calculate the probability that it is a family with
- (i) no children,
- (ii) five children,
- (iii)   the median number of children,
- (iv)   one or two children.
- 6 A multiple of 6 which is less than 100 is written down at random. State the probability that it is
- (i) the least common multiple of 24 and 36,
- (ii) a multiple of 7,
- (iii)   a factor of 48,
- (iv)   an odd number,
- (v)   a square number and a multiple of 10.
- 7 Two ordinary fair dice are rolled together.
- (a)   Construct the possibility diagram to display all the possible outcomes and state the number of possible outcomes.
- (b)   Hence find the probability of obtaining
- (i) two number three,
- (ii)   two different numbers,
- (iii)   two numbers whose sum is more than 7,
- (iv)   two numbers whose product is less than 10,
- (v) at most one number three.

In this image, we can see a chart. There is a number of children and a bar chart.

<!-- image -->

<!-- image -->

## Revision Exercise 4

- 1 (a)  Simplify the following
- (i) 18 p 5 3 p 4 , (ii) ( m 3 n ) 7 × ( n 5 ) 3 × m 5 , (iii) 3 x -2 × x -3 .
- (b) Using a 2  b 2 = ( a + b )( a -b ), evaluate

$$( i ) \, 7. 7 ^ { 2 } - 2. 3 ^ { 2 }, \text{ \quad \ \ } ( i i ) \, 1 1 \times 9.$$

2. Given that w 2 1 x + 0 x -5    4 = 6   7 y z , find the values of w, x, y and z .
3. Given the formula y = 2 √3 t - 1 , express t in terms of y .
4. Given that the line y - 3 x = 9  is parallel to the line 3 y = k x - 2,  find the value of k .
6. The rectangular sheet of paper below has a perimeter of  120  cm.  When  it  is  folded  along  its  longer  line  of symmetry,  the  perimeter  of  the  rectangle  formed  is 98 cm.  What are the dimensions of the original shape?
7. A ladder of length 5 m leans against a wall so that the angle between the ladder and the wall is 60 O .  Using as much of the information given below, find how far the foot of the ladder is from the wall.

The image is a graph titled "The number line shows the sets A and B." The graph is a line graph with a minimum and maximum value of 8. The x-axis is labeled as "a" and the y-axis is labeled as "b." The graph is drawn with a blue line that starts at the point (0, 3) and extends to the right until it reaches the point (10, 11). The line is marked with a blue dot at the point (10, 11).

<!-- image -->

<!-- image -->

[sin 60 0 = 0.87, cos 60 0 =  0.50, tan 60 0 = 1.73]

8. A six-sided ordinary die and a fair coin are tossed together.
2. (a)  Draw a possibility diagram to represent the possible outcomes.
3. (b)  Hence, find the probability of obtaining
4. (i) a five and a tail, (ii) a tail and an even number,

(iii) no tail.

9. Janvee works as a hairdresser. She is paid Rs 100 per hour and her normal working hours are  9  am  to  5  pm,  Monday  to  Friday. The  times  at  which  she  starts  and  finishes  work during one week are shown in the table below.

| Day       |   Start |   Finish |
|-----------|---------|----------|
| Monday    |       9 |     5    |
| Tuesday   |       9 |     6    |
| Wednesday |       9 |     5    |
| Thursday  |       9 |     5.45 |
| Friday    |       9 |     6    |

When Janvee works overtime, she is paid twice her normal rate. Calculate Janvee's total wage for that week.

10. A cylindrical can whose base radius is 3.5 cm contains 30.8 cl of juice. Taking π to be 22 7 , calculate the height of the can.  [1Litre = 1000 cm 3 ]
11. In  a  right  angled  triangle,  the  hypotenuse  is x cm.  Its  base  is  2  cm shorter than  its hypotenuse. The height is 16 cm shorter than the hypotenuse.
3. (i)  Find the base and the height of the triangle in terms of x .
4. (ii) Using Pythagoras'  Theorem, form an equation in x and show that it reduces to

$$x ^ { 2 } - \ 3 6 x + 2 6 0 = 0.$$

- (iii) Solve the above equation and hence, find the area of the triangle.
12. The number of children per family in Harris Street was recorded.  The table below shows the results.

| Number of children   |   0 |   1 |   2 |   3 |   4 |   5 |
|----------------------|-----|-----|-----|-----|-----|-----|
| Number of families   |   8 |   5 |   5 |   4 |   2 |   1 |

For this distribution,

- (i) find the number of families in Harris Street,      (ii) find the mean, mode and median.

$$1 3. \quad ( a ) \, \text{Given} \, \overline { A B } \, = \, \binom { - 5 } { 1 2 } \, \text{and} \, \overline { C D } = \binom { 0 } { k } \,. \, \text{Find}$$

(i) BA , (ii) | AB |,       (iii) the possible values of k , for which | AB | = | CD |.

- (b)  On a copy of each of the following diagrams, draw the object Q 1 , given its image Q 1 and the translation T which maps Q onto Q 1 .

-4

-5

(i)

T

=

-5

5

(ii)

T

=

(iii)

0

<!-- image -->

-4

<!-- image -->

<!-- image -->

14. The first four diagrams of a sequence are shown below.

<!-- image -->

Diagram 1

<!-- image -->

<!-- image -->

Diagram 2

Diagram 3

Diagram 4

<!-- image -->

The table below shows the number of black and white triangles for the first three diagrams.

| Diagram Number            |   1 |   2 |   3 | 4   | 5   |
|---------------------------|-----|-----|-----|-----|-----|
| Number of white triangles |   1 |   3 |   6 |     |     |
| Number of black triangles |   0 |   1 |   3 |     |     |
| Total number of triangles |   1 |   4 |   9 |     |     |

- (a) Complete the table.
- (b) What will be the total number of triangles in Diagram 12?
- (c) Vedesh proposes a general rule to find the number of white triangles in Diagram n as n ( n +1).  Rajiv proposes an alternative rule for finding the number of white triangles in Diagram n as n ( n +1) 2 .  Which rule is correct?
- (d) Using the correct rule in part(c) above, (i) state the total number of triangles in diagram 20 (ii) state the number of white and black triangles in Diagram 20. Show any calculations that you make.

T

=

## Revision Exercise 5

- 1 (a)  Evaluate
- (i)   72.6 × 10 - 2.52 × 100, (ii) 16 - 6 ÷ 2 + 1, (iii)  5 1 5 - 4 1 5 .
- 2 (a)  Express 0.076 57 correct to 3 decimal places.
- (b)   Express 56% as a fraction in its lowest terms.
- (c)  Write down an irrational number between 7 and 8.
- 3 (a)  Write these numbers in order of size, starting with the smallest

$$\frac { 1 } { 4 } \quad 0. 2 7 \quad \frac { 7 } { 2 5 } \quad 0. 2 \quad \frac { 2 9 } { 1 0 0 }$$

- (b)  (i)  Simplify  (2 x 4 ) 3 .  (ii)  Find the value of  5 3 + 5 0 .  (iii)  Solve the equation 3 1 y = 81.
4. Simplify (a) 3 a + 4 b -a + b

$$\text{Simplify} \quad & ( a ) \ 3 a + 4 b - a + b & & ( b ) \ 3 ( x - 2 y ) - 2 ( x + 5 y ) \\ & ( c ) \ \frac { 3 x } { 1 0 } + \ \frac { 2 x - 1 } { 5 } & & ( d ) \ \frac { 1 2 x ^ { 2 } } { y ^ { 2 } } \ \div \frac { 4 x ^ { 2 } } { y ^ { 2 } }$$

- 5 (a) Solve the equation 2( x + 3) = 2(2 x -  4) + x .
- (b)   (i) Solve the inequality 7 - 2 x &lt; 19.
- (ii) Hence find the smallest possible integer x which satisfies the inequality in part (b) (i).
- (c) Given that √5=2.24 and √50=7.07, find

$$( \mathbf i ) \, \sqrt { 5 0 0 }, \quad \ \ ( \mathbf i \mathbf i ) \, \sqrt { 0. 5 }$$

- 6 (a)  A  car  travels  at  an  average  speed of 60 km/h for 1 1 2 hours. Calculate the distance travelled by the car.
- (b) Convert 180 km/h to m/s.
- (c)  If  10  men  can  paint  a  house  in  12  hours,  how  many  men  are  needed  to  paint the same house for 30 hours?
- (d)   A map is drawn to scale 1 : 50 000. On the map, the distance between the two towns A and B is 3.6 cm. Calculate the actual distance between the two towns. Give your answer in km.

- 7 (a)  (i)   Write 196 as the product of its prime factors in index form.
- (ii)  Find the smallest possible integer k such that 196 k is a cube number.
- (b) Given ξ = { x : 1≤ x ≤ 9, x Є Z } , A = { 2 , 5 , 6 , 9 } and B = { 1, 2 , 3 , 6 , 8 , 9 } ,
- (i) draw a labelled Venn diagram to represent the above information.
- (ii) List the elements of A B, (iii) Find n (B').
- 8 (a)  In a sale, all prices are reduced by 15%. Calculate the original price of an article whose sale price is Rs 510.
- (b)   Vidoushi has Rs 5 600. She spends 5 7 of this on a new phone. Work out the cost of the phone.
- (c)  Express 150 g as a percentage of 1 kg.
- (d)   Anita invests Rs 20 000 in an account that pays simple interest.
- She leaves the money in the account for 4 years.
- At the end of 4 years she has Rs 25 600.
- Calculate the rate of simple interest paid per year.
- 9 (a) Use the expansion of (a + b)(a - b) to find the value of 59 x 61.
- (b) Given that x 2 + y 2  = 106 and xy = 45, find the value of ( x - y ) 2
- 10 (a) B is the point (3, 9) and C is the point ( p , -3). If the gradient of the line BC is -4 , find the value of p .
- (b)  Find the equation of the line passing through the point (4, 3) and parallel to 3 x - 2 y = 13.
- 11 (a) A = 7   -1 1   5 and B = 2   -4 1   0 . Find
- (i)   2 B -A , (ii) AB .
- (b)   Given that x = √ t - 121 , 3
- (i)   find x when t =148, (ii) rearrange the formula to make t the subject.

12. In the diagram, ACD and ECD are triangles with CD = DE. AD and EC intersect at B is the point on AC such that BF is parallel to CD .

BÂF = 26°, BFC = 28° and CFD = 120°.

The image depicts a geometric figure consisting of several points and lines. Here is a detailed description of the image:

### Points and Lines:
1. **Center Point**: The center of the figure is marked as point A.
2. **Points on the Line**:
   - **Point A**: Located at the top left corner of the image.
   - **Point B**: Located at the top right corner of the image.
   - **Point C**: Located at the bottom left corner of the image.
   - **Point D**: Located at the bottom right corner of the image.
   - **Point E**: Located at the top right corner of the image.
3. **Lines**:
   - **Line AB**: A line that runs from point A to point D.
   - **Line BC**: A line that runs from point A to point E.
   - **Line CD**: A line that runs from point A to point F.
   - **Line EF**: A

<!-- image -->

Find   (i) FĈD ,       (ii) EDC , (iii) ABF .

13. The diagram shows sector OAB of a circle with centre O and radius 35 cm.

Given that angle AOB = 36 0 .

- Taking π to be  22 7 ,  calculate
- (a)  the length of the arc AB,
- (b) the perimeter of the sector,
- (c)  the area of the sector.
- 14 (a)  The interior angle of a regular polygon is 108°. Work out the number of sides of this polygon.
- (b) A hexagon has four angles of 2 x ° eacand the remaining angles are each x °.
- Calculate the value of x .
- 15 Solve the simultaneous equations
- 4 x - 5 y = -7
- 9 x + 2 y = 24
- 16 Given that vector AB = , find (i) BA , (ii) | AB | . -5 -12
- F.

<!-- image -->

- 17 A bag contains red, green and yellow pegs. A peg is taken at random from the bag.
- The probability that it is red is 0.25 and the probability that it is green is 0.6.
- (a)  Find the probability that it is
- (i)  not red,
- (ii)  yellow.
- (b)   Originally there were 30 green pegs in the bag.
- Find the total number of pegs.
- 18 A closed cylinder has base radius 14 cm and volume 6160 cm 3 .
- (a)  Taking π to be  22 7 , calculate
- (i)   the height of the cylinder,
- (ii)  its curved surface area,
- (iii) its total surface area.
- (b) Find the capacity of 100 such cylinders, giving your answer in litres
- 19 Two vertical poles DE and GF stand on horizontal ground.
- A rope is used to join E to F such that EF makes an angle of 20 o with EH.
- The rope has length 30 m and the pole DE is 16 m high.

<!-- image -->

Calculate (a) the distance EH,

- (b) the height of the pole GF,

- (c) the area of the figure.

[ sin 20 O = 0.342

cos 20 O = 0.940

[ sin 20 O = 0.342

cos 20 O = 0.940

tan 20 O = 0.364]

- 20 (a)  A cubical die was thrown 50 times. The table shows the number of times that each score occurred.

| Score     |   1 |   2 |   3 |   4 |   5 |   6 |
|-----------|-----|-----|-----|-----|-----|-----|
| Frequency |   6 |  12 |   7 |   8 |   4 |  13 |

## For the above distribution, find the

- (i) mode,
- (ii) mean,

(iii) median.

- (b) A group of students were asked if they wanted
- a later start to the school day.

The pie chart summarises the results.

70 students said they 'agree' .

Work out the number of students who 'disagree' .

<!-- image -->

- 21 (a)  If  the  5 th and  7 th terms  of  a  Fibonacci  sequence  are  16  and  42  respectively,  write down the first 8 terms of the sequence.
- (b)  Part of a row of numbers in Pascal's triangle is given below.
- 1, 10, 45, 120, 210, 252, …
- (i)  Complete the row.
- (ii)  Which row is it?
- (iii) List the elements of the next row.
23. A water tank is 30 cm long, 12 cm wide and 12cm high. It contains water to a depth of 8 cm.

The image depicts a right triangle with a length of 12 cm. The hypotenuse of the triangle is 30 cm, and the legs of the triangle are 8 cm and 12 cm. The legs of the triangle are perpendicular to the base of the triangle.

### Description of the Image:
1. **Right Triangle**: The image is a right triangle with the base labeled as 12 cm. The legs of the triangle are labeled as 8 cm and 12 cm.
2. **Length of the Triangle**: The length of the hypotenuse of the triangle is 30 cm.
3. **Legs of the Triangle**: The legs of the triangle are labeled as 8 cm and 12 cm.

### Analysis:
1. **Right Triangle Properties**:
   - The hypotenuse of a right triangle is the longest side.
   - The legs of a right triangle are perpendicular to the base.

<!-- image -->

- (a) Calculate the surface area of the tank which is in contact with water.
- (b)   Calculate the volume of water in the tank.

Five identical cubes of length 6 cm are now completely immersed in the water tank, as shown in the diagram.

Diagram not drawn to scale

In this image, we can see a box with some cubes.

<!-- image -->

## (c) Calculate

- (i)  the volume of each cube,
- (ii)  the increase in the volume,
- (iii) the rise of the water level in the tank.

Will water overflow from the tank? Why?

- 24 Make a copy of the graph below and find the image of triangle ABC under a
- (a) reflection in the line l ,
- (b) translation with translation vector             . -2 1

In this image, we can see a graph. There is a line on the graph. There is a number on the graph.

<!-- image -->