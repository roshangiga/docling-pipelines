## TECHNOLOGY STUDIES:

## FOOD AND TEXTILES STUDIES

Grade

<!-- image -->

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

Food &amp; Textiles Studies  |

I

Dr Aruna Ankiah-Gangadeen, Head Curriculum Development, Implementation and Evaluation

## TECHNOLOGY STUDIES: FOOD AND TEXTILES STUDIES PANEL

Ashwina Engutsamy-Borthosow

- Coordinator, Senior Lecturer, MIE

- B. Swalehah Beebeejaun-Roojee

- Senior Lecturer

Mithila Gowreesunkur-Veerapen

- Lecturer

Dr Vishnee Bissonauth

- Lecturer

- R. Marie-Lys Cadet

- Educator

- S. Homeshwaree Samboo

- Educator

Sudarshinee Ramma-Gutty

- Educator

Ressmah Bee Janoo

- Educator

## Design

Kunal Sumbhoo

- Graphic Designer, MIE

Leveen Nowbotsing

- Graphic Designer, MIE

<!-- image -->

- © Mauritius Institute of Education (2023) ISBN: 978-99949-75-26-6

## Acknowledgements

The Technology Studies Panel wishes to acknowledge the contribution of:

- Mangala Jawaheer , Lecturer, MIE - Proof reading
- -Staff of Home Economics Department, MIE
- -Educators of Validation Panels

## Rodrigues:

- L. Gravel Speville

- Educator

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the   NCF, while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the efforts of  the  graphic  artists  who  put  in  much  hard  work  to  maintain  the  quality  of  the  MIE  publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## Preface

In line with the philosophical principles underpinning the Nine Year Schooling educational reform and the National Curriculum Framework, Technology Studies is offered to all secondary school students of Mauritius and Rodrigues irrespective of their ability, level and gender.

The challenges in transforming education for the needs of 21 st  century learners is at our doorstep and Technology Studies promotes a holistic and broad-based education whilst anchoring the development of creative and critical skills.

Technology Studies comprises two strands:

- Design and Technology
- Food and Textiles Studies

Students studying Technology Studies: Food &amp; Textiles Studies will emerge through a system which provides  them  with  the  opportunity  to  think  critically,  develop  the  ability  to  create,  innovate, adapt,  communicate and lead. At the same time, Technology Studies encourages students to work collaboratively and responsibly in teams. All in all, Technology Studies paves the way for students to stimulate their thinking, communication and entrepreneurship skills while nurturing respect for others. It also allows them to be self-disciplined.

This textbook, has taken into account the current trends among adolescents and particular attention has been given to the needs of our Grade 9 students. Illustrations, contextual pictures, graphs and charts support the explanation of concepts throughout the textbook. The content of the textbook is presented in units and topics to gradually guide the students. The learning objectives are clearly indicated at the beginning of each unit for more focused teaching and learning.

Educators are encouraged to act as facilitators and to guide students accordingly. Projects are proposed, which can be adapted according to the schooling context, resources available, students' abilities and interests. The projects aim at helping students to become prepared to take action for the well-being of themselves and others whilst addressing everyday living challenges.

The authors hope that this Grade 9 textbook offers a pleasurable teaching and learning adventure in Technology Studies: Food &amp; Textiles Studies.

## Content pages

## Food and Textiles Studies

| Unit 1   | Nutrition and Health                       |   1 |
|----------|--------------------------------------------|-----|
| Unit 2   | FoodTechnology                             |  25 |
| Unit 3   | Principles and Methods of Food Preparation |  35 |
| Unit 4   | Self and Family Awareness                  |  61 |
| Unit 5   | Consumer Awareness                         |  73 |
| Unit 6   | Textile Technology                         |  81 |
| Unit 7   | Fashion Sense                              |  97 |
| Unit 8   | Design & Creativity through Textiles       | 107 |

Appendix | 150

## Icons are included throughout the units to guide you through the textbook:

Learning Objectives: These  are  found  at  the  beginning  of  each  unit  to  enable  you  to structure, sequence and plan your learning.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Activities:                   | In-built activities are integrated in the units/topics as formative tasks to stimulate thinking and encourage communication in class.   |
|-------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| Did you know? / More to Know: | These will give you facts that will increase your level of interest in the concepts covered.                                            |
| Find out More:                | Weblinks are provided to extend learning outside the classroom.                                                                         |
| Research work:                | To enable you to find interesting information which is relevant to the concepts introduced in the unit.                                 |
| KeyTerms:                     | Terminologies are included to explain the terms properly.                                                                               |
| Exercises:                    | A list of questions is included to reinforce concepts learned.                                                                          |
| Recall                        | Therecall icon reviews ideas andconcepts already covered at primary level.                                                              |

In this image there is a text on the left side of the image.

<!-- image -->

## FOOD STUDIES SECTION:

Unit 1 - Nutrition and Health

1

Unit 2 - Food Technology

25

Unit 3 - Principles and Methods of Food Preparation

35

## SELF AND FAMILY AWARENESS SECTION:

Unit 4 - Self and Family Awareness

61

Unit 5 - Consumer Awareness

73

## TEXTILE STUDIES SECTION:

Unit 6 - Textile Technology

81

Unit 7 - Fashion Sense

97

Unit 8 - Design and Creativity through Textiles

107

Food  and Textiles  Studies  provide  opportunities  for ALL adolescents  at  the  lower  secondary,  irrespective  of gender, to develop a unique repertoire of knowledge, practices and dispositions that will assist them in meeting the challenges of everyday life in our evolving society.

This section of the textbook is in line with the National Curriculum Framework (NCF) and the Teaching and Learning Syllabus for Grade 9.  The Food and Textiles Studies strand aims at enabling Grade 9 students to:

- Explain the importance of selected vitamins, minerals and water in the diet.
- Recognise the importance of consuming fruits and vegetables daily.
- Adopt healthy food habits and healthy food choices to reduce the risk of NCDs.
- Provide examples of sustainable food production and consumption practices.
- Demonstrate safe use of the oven, stove and microwave oven during food preparation.
- Prepare and serve healthy and attractive meals using convenience foods.
- Describe ways to build and maintain strong family relationships.
- Discuss the impact of technology on family life.
- Read and interpret information on food and care labels and manuals of household appliances.
- Relate fabric construction and fabric finishes to performance characteristics and end-uses of textiles.
- Recognise the wide use of smart and modern fabrics in various sectors.
- Demonstrate an understanding of the nature of fashion design and evolution of fashion trends.
- Use sewing machine and steam iron safely.
- Make textile items with the creative use of scrap textile materials and decoration techniques.

VII

<!-- image -->

This section has been organised around 8 themed units which are sub-divided into the following topics:

| Units 1-3 provide the foundation for healthy nutrition with practical and technological skills development related to food preparation.                                                                      | Nutrition and Health: • Micronutrients (Vitamins, minerals and water) ; their food sources, importance and the health consequences linked to either a lack and or excess; Fruits and vegetables, Food habits and food choices. FoodTechnology: • Sustainable food production and consumption Principles and Methods of Food Preparation: • Kitchen equipment; Healthy meals, Convenience foods, Healthy cooking   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Units 4- 5 create awareness about family relationships, technology and family life and labels (food, clothing, manual)                                                                                       | Self and Family Awareness • Building strong family relationships; Family andTechnology • Consumer Awareness • Food, clothing and manual labels                                                                                                                                                                                                                                                                    |
| Units 6-8 provide the foundation for fashion and textiles where a number of basic concepts and ideas are introduced. The units help to pave the way for students' practical and creative skills development. | TextileTechnology • Fabric construction; Fabric finishes; Smart and modern fabrics Fashion Sense • Elements of fashion design; Fashion trends Design and Creativity throughTextiles • Sewing and Pressing equipment, Textile decoration techniques; Creative textile projects                                                                                                                                     |
| Appendix                                                                                                                                                                                                     | Cooking for fun , Sewing for fun                                                                                                                                                                                                                                                                                                                                                                                  |

To awaken students' interest, each topic includes activities and questions to reinforce understanding. Units may be taught and learnt in the order which suits the school context, the students' abilities and teaching and learning styles, provided students derive the most enriching learning experience.

Educators are encouraged to develop additional resources for specific contents to reflect originality, creativity and efficient use of technology. It is advised that educators use a range of pedagogical strategies to meet the needs and abilities of their students. Learning will thus become meaningful and rewarding. Recipes and textile projects are proposed and should in no way be restricted to those in the textbook. These can be adapted to the resources and facilities available at school, as long as the technical skills and content targeted for Grade 9 are achieved.

## Nutrition and Health

## Nutrients

## 1. Introduction

There  are  six  essential  nutrients  that  the  body  needs  to  function  properly.  These  are carbohydrates, fats, proteins, vitamins, minerals and water.

Nutrients that are needed in large amounts are called macronutrients . These are:

- proteins
- carbohydrates
- fats

Micronutrients are those nutrients which are required in small amounts but are essential for the normal functioning of the body. These micronutrients are vitamins and minerals .

In this image, we can see a chart.

<!-- image -->

## TOPIC 1A: Micronutrients - Vitamins

## Learning Objectives

## By the end of this unit, you will be able to:

- List common examples of sources of micronutrients and water.
- State the importance of micronutrients.
- State the deficiencies of micronutrients.
- State the excess of micronutrients.

## 1. Introduction

Vitamins  are  essential  nutrients  as  they  help  the  body  fight  infections  and  promote  good health. Vitamins are found in small amounts in various foods. Eating a balanced diet containing a variety of foods will ensure the adequate supply of vitamins in the body. When their intake is insufficient, vitamin deficiency occurs.

## 2. Classification of Vitamins

There are two types of vitamins. They are classified as follows:

In this image, we can see a chart.

<!-- image -->

Vitamin K

## 3. Fat-soluble Vitamins: sources, importance, deficiencies and excess

## Vitamin A

<!-- image -->

<!-- image -->

<!-- image -->

| Food sources                                                                                                                                                                                                                                                                       | Importance                                                               | Deficiencies                                                                                                                                                                                | Excess     |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------|
| Animal sources (Retinol): Liver, fish liver oil, sardines, egg yolk, milk, cheddar cheese, butter cream, ghee Plant sources (Carotene): Red, orange and yellow coloured fruits and vegetables, e.g carrots, tomatoes, pawpaw Dark green leafy vegetables. e.g. spinach, watercress | • Maintains good vision in dim light • Keeps the skin smooth and healthy | • Poor vision in dim light • Dry eyes and skin Deficiency disease: • Night blindness The picture shows normal eye before and after the disease night blindness • Loss of sight Before After | • Toxicity |

## Vitamin D (also known as sunshine vitamin)

<!-- image -->

<!-- image -->

| Sources                                                                                 | Importance                                                                             | Deficiencies                                                                                               | Excess     |
|-----------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|------------|
| Exposure to sunlight, fish liver oils, liver,egg yolk, sardines, milk, cream, margarine | • Helps to build strong bones and teeth • Helps the body to absorb the mineral calcium | • Poor bone growth in children • Weak bones and teeth Deficiency disease: • Rickets (bow legs) in children | • Toxicity |

## Vitamin E

<!-- image -->

<!-- image -->

<!-- image -->

| Food sources                                                                      | Importance                                                         | Deficiencies   | Excess   |
|-----------------------------------------------------------------------------------|--------------------------------------------------------------------|----------------|----------|
| Vegetable oils, oatmeal, wheat germs, nuts, seeds, eggs, liver, margarine, butter | • Prevents fats and Vitamin A from oxidation • Protects body cells | • Rare         | • Rare   |

## Vitamin K

<!-- image -->

<!-- image -->

<!-- image -->

| Food sources                                                 | Importance                               | Deficiencies                                                                          | Excess   |
|--------------------------------------------------------------|------------------------------------------|---------------------------------------------------------------------------------------|----------|
| Liver, vegetable oils, dark green leafy vegetables egg, milk | • Essential for normal clotting of blood | • Delays clotting of blood • Excessive bleeding especially in infants during injuries | • Rare   |

## 4. Water-soluble Vitamins: Sources, importance, deficiencies and excess

## Vitamin B group

<!-- image -->

| Food sources                                                                                                       | Importance                                                                                                             | Deficiencies                                                                                                               | Excess   |
|--------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|----------|
| Animal: meat and poultry, milk, egg Plant: whole grain cereals, nuts, dried beans, green leafy vegetables, legumes | • Helps in the release of energy from food after digestion and absorption • Helps to maintain a healthy nervous system | • Poor appetite, fatigue, irritability • Poor functioning of the nervous system Deficiency diseases: - Beriberi - Pellagra | • Rare   |

<!-- image -->

<!-- image -->

## Vitamin C

<!-- image -->

<!-- image -->

<!-- image -->

| Food sources                                                                                                                             | Importance                                                                                                                      | Deficiencies                                                                                                                      | Excess               |
|------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|----------------------|
| 'Goyave de chine' , citrus fruits (grapefruit, orange, lemon, mandarin) , Kiwi fruits, guavas, strawberries, capsicum, cabbage, tomatoes | • Protects the body from infections • Helps in the healing of wounds • Helps in the absorption of the mineral iron in the body. | • Lowered resistance to infection • Poor wound healing Deficiency diseases: • Anaemia • Scurvy (dry scaly skin and bleeding gums) | • Diarrhoea • Nausea |

<!-- image -->

Anaemia is the most common iron deficiency disease among children, adolescents, women and pregnant women.

<!-- image -->

## ACTIVITY 1: COMPLETE THE CROSSWORD ON VITAMINS BY USING CLUES FROM THE BOX.

In this image, we can see a diagram.

<!-- image -->

## Across:

1. Deficiency of Vitamin A
2. Deficiency of Vitamin D

## Down:

1. Deficiency of Vitamin B group
2. Deficiency of Vitamin C
3. Cheapest source of Vitamin D
4. Source of Vitamin C

## TOPIC 1B: Micronutrients - Minerals

## 1. Introduction

Minerals are substances present in small amount in foods. They are required for the normal functioning of the body. There are different types of minerals. These are:

In this image, we can see a table with some data.

<!-- image -->

## 2. Minerals: Food Sources, importance, deficiencies and excess

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Calcium                                                                                                      | Calcium                                                                                         | Calcium                                                                                                                                                       | Calcium                                                                                         |
|--------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------|
| Food sources                                                                                                 | Importance                                                                                      | Deficiencies                                                                                                                                                  | Excess                                                                                          |
| Milk, cheese, yoghurt, canned fish with bones, e.g sardines, green leafy vegetables, broccoli, cabbage, okra | • Helps in the formation of strong bones and teeth • Needed for the clotting of blood in wounds | • Poor growth in children • Mottling of teeth • Weakening of bones in adult Deficiency disease: • Rickets in children (combined with a shortage of Vitamin D) | • Calcification of soft tissues • Increase in the level of calcium in the blood (Hypercalcemia) |

## Iron

<!-- image -->

<!-- image -->

<!-- image -->

| Food sources                                                                                                | Importance                                        | Deficiencies                                                                                                          | Excess                                                                  |
|-------------------------------------------------------------------------------------------------------------|---------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------|
| Liver, red meat, egg yolk, whole grain cereals, dark green leafy vegetables, pulses, dried fruits, potatoes | • Needed for the formation of the red blood cells | • Fatigue • Pale skin • Abnormally heavy and continuous bleeding • Increased heart beat Deficiency disease: • Anaemia | • May cause diarrhea/ constipation, dizziness and damage to some organs |

## Potassium

<!-- image -->

| Food sources                                                                                                                                      | Importance                                                                                   | Deficiencies                                             | Excess                |
|---------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|----------------------------------------------------------|-----------------------|
| Banana, orange, avocado, white beans, sweet potato, spinach, watermelon, butternut, coconut water, dried apricots, dairy products, seafoods, meat | • Assists in maintaining normal blood pressure • Supports healthy nerves and muscle function | • Weakness and fatigue • Muscle aches and muscles cramps | • Weakness • Numbness |

## Sodium

<!-- image -->

<!-- image -->

<!-- image -->

| Food sources                                                                                    | Importance                                                                                                     | Deficiencies                | Excess                                                                                           |
|-------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|-----------------------------|--------------------------------------------------------------------------------------------------|
| Table salt, soya sauce, pickles, canned foods, savoury packaged foods, chilly and tomato sauces | • Needed to maintain the amount of water balance in the body • Needed for the proper functioning of the nerves | • Muscles cramps • Weakness | • May cause bloating and swelling of body tissues and water retention • May lead to hypertension |

## Iodine

<!-- image -->

<!-- image -->

| Food sources                           | Importance                                                                             | Deficiencies                                                                          | Excess                                                                                                 |
|----------------------------------------|----------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
| Table salt, seafoods, edible sea weeds | • Needed to produce thyroxine, a hormone that regulates the use of energy in the body. | Deficiency diseases: • Goitre- enlargement of the thyroid gland • Cretinism in babies | • Hypothyroidism (Disorder which occurs whenthe thyroid gland does not produce enough thyroid hormone) |

<!-- image -->

<!-- image -->

<!-- image -->

## ACTIVITY 2: POSTER ON NUTRIENTS

Prepare a poster illustrating the food sources of the following nutrients:

- Vitamins
- Minerals
- Water

<!-- image -->

## TOPIC 1C: Water

## Learning Objectives

## By the end of this unit, you will be able to:

- List common examples of food sources of water.
- State the importance of water in the body.
- Describe what happens when the body lacks water.

## 1. Introduction

Water is essential for all living plants and animals to stay alive.  The human body is made up of about 72% water, most of which is contained in the blood, body fluids and body cells. The body loses water continually through activities such as breathing, perspiration and urine.

## 2. Water: Food sources, importance, lack

<!-- image -->

<!-- image -->

| Food sources                                                                                                                                                                                       | Importance                                                                                                                                                                                               | Lack of water in the body                                                                                                                                   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
| • Plain drinking water • Beverages such as fruit juices, milk (plain or flavoured) , milkshakes, tea • Soups • Fruits and vegetables such as: watermelon, melon, coconut water, cucumber, tomatoes | Water is needed to: • regulate body temperature • transport nutrients and oxygen in blood • digest food • remove waste products and toxins through urine, stools and perspiration • prevent constipation | Not consuming enough of water causes dehydration . Symptoms of dehydration are: • feeling thirsty • dry mouth and lips • dizziness • headache • sunken eyes |

<!-- image -->

## Some healthy tips to avoid dehydration are:

- Start the day by drinking a glass of water.
- Always include a glass of water, with your meal.
- It is advisable to consume about 1.5 - 2 litres (6-8 glasses) of water daily.
- Consume plenty of fruits and vegetables as they are high in water content.
- Include soups in your meals.
- Drink more water during hot weather.

<!-- image -->

<!-- image -->

## MORE TO KNOW

- People who are suffering from illness such as fever, cold, cough and diarrhea lose more water from the body.
- Pregnant women need to drink more water to keep the body well hydrated and cope with the demand of the changing body.
- Lactating mothers need to drink more water to produce milk.

<!-- image -->

EXERCISES

1. Fill in the blanks with the words from the list below:

## K, blood, nervous, C, vision, light, fat

- (i)   The water soluble vitamins are Vitamins B and \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .
- (ii)  Fat soluble vitamins dissolve in \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

(iii) Vitamin \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is needed for \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ clotting.

- (iv)   Vitamin B group helps to maintain a healthy \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ system.
- (v)  Vitamin A maintains good \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ in dim \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.
2. State two plant sources and two animal sources of Vitamin E.
3. State two deficiencies of:
- a. Vitamin A
- b. Vitamin D
- c. Vitamin C
4. List four sources of:
- a. Vitamin B group
- b. Vitamin C
5. Name two animal and two plant sources for the minerals listed below:

| Minerals   | Animal Sources   | Plant Sources   |
|------------|------------------|-----------------|
| Calcium    |                  |                 |
| Iron       |                  |                 |
| Potassium  |                  |                 |
| Sodium     |                  |                 |
| Iodine     |                  |                 |

6.  State one deficiency of:
- i. Calcium
- ii. Sodium
- iii. Iron
7. List four food sources of water.
8. List two reasons why water is important for maintaining good health.
7. 9 a. Name four common symptoms of dehydration.
- b. Explain how a person can avoid dehydration.

## TOPIC 2: Fruits and Vegetables

## Learning Objectives

## By the end of this topic, you will be able to:

- Recognize the need to consume fruits and vegetables daily.

## 1. Introduction

Fruits and vegetables are important components of a healthy diet.

There are many varieties of fruits and vegetables available and there are several ways to prepare, cook and serve them.

## 2. Importance of fruits and vegetables in the daily diet

Fruits and vegetables are important sources of vitamins, minerals, dietary fibre, plant protein, healthy fats and antioxidants. They help in the prevention of several micronutrient deficiencies. A daily intake of fruits and vegetables can help to:

- reduce obesity by maintaining a healthy weight
- lower cholesterol level in blood
- lower the risk of Type 2 diabetes, stroke, some forms of cancers and high blood pressure (hypertension)
- prevent constipation

## 3. Benefits of eating coloured fruits and vegetables

Fruits and vegetables contain plant pigments which not only provide colours but also have other health benefits.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Colours of fruits and vegetables and their health benefits                                     | Nameof fruits and vegetables                                                 |
|------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|
| Red fruits and vegetables help to: • fight cancer • reduce risk of diabetes and heart diseases | • watermelon, apples, red grapes, strawberries, tomatoes, beets, red peppers |

14

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Orange and yellow fruits and vegetables help to: • improve the immune system • promote healthy eyes and vision • decrease risk of cancer   | • Orange, pawpaw, corn, peach, pineapple, carrots, pumpkin                                             |
|--------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
| Green fruits and vegetables help to: • boost the immune system • prevents constipation • reduce risk of cancer                             | • Green apple, kiwi, green grapes, green leafy vegetables, broccoli, spinach, parsley                  |
| Blue and purple fruits and vegetables help to: • protect cell damage • fight inflammation • boost memory                                   | • Prunes, blueberries, eggplant, red cabbage                                                           |
| White fruits and vegetables help to: • protect against certain cancers • lower cholesterol • reduce inflammation                           | • Banana, cauliflower, cucumber, garlic, onion, mushroom, potatoes, white radish (rave) , bean sprouts |

<!-- image -->

<!-- image -->

<!-- image -->

## 4. Ways to increase fruits and vegetables for a healthy diet

- Fruits and vegetables can be served as: handy snack, main dishes, accompaniment, desserts and drinks.
- Choose freshly squeezed or pressed fruit juices instead of syrups.
- Eat  attractive  and  healthy  breakfast  by  adding  tomatoes,  onions,  spring  onions  and mushroom to your omelettes.
- Include a fruit in your lunch bag as a handy mid-morning snack.
- Add  extra  vegetables  such  as  cucumbers,  carrots,  tomatoes,  peppers,  and  sprouts  to sandwiches and wraps.

- Enjoy colourful vegetables salads by adding fruits such as apple, red grapes and pineapple chunks.
- Choose fresh fruits as desserts.
- Choose smoothies with fresh fruits for your afternoon drinks.
- Keep snack-size fruits and vegetable portions easily accessible in your fridge.

<!-- image -->

## MORE TO KNOW

- You should eat at least five vegetables and five fruits each day. Include different varieties of fruits and vegetables in your diet.

<!-- image -->

## EXERCISES

## 1.  Complete the table below:

| Colours of fruits and vegetables   | Benefits   | Nameof fruits / vegetables   |
|------------------------------------|------------|------------------------------|
| 1. 2.                              | 1. 2.      | Red                          |
| 1. 2.                              | 1. 2.      | Orange and yellow            |
| 1. 2.                              | 1. 2.      | Green                        |
| 1. 2.                              | 1. 2.      | Blue and purple              |
| 1. 2.                              | 1. 2.      | White                        |

2. Suggest three ways of how you would include fruits and vegetables in your diet.

16

## TOPIC 3: Food habits and Food choices

## Learning Objectives

## By the end of this topic, you will be able to:

- Discuss the factors influencing food habits and food choices.
- Propose healthy food habits and food choices to reduce the risk of Non-Communicable Diseases.
- Relate food habits and food choices to eating disorders.

## 1. Introduction

The food we eat directly influences our health. People of all age groups who have unhealthy eating habits, have greater risk of developing health problems known as Non-Communicable Diseases (NCDs) .

A Non-Communicable Disease is a disease that is not transferred from one person to another.

Examples of NCDs are:

- diabetes
- cardiovascular disease (CVD)
- obesity
- high blood pressure
- some types of cancer

In the long run, an excessive food intake in elaborate meals and excessive snacking can lead to the development of Non-Communicable Diseases. This kind of decision has a direct impact on health and forms part of healthy food choice .

Hence, one of the major ways of reducing the risk of NCDs is to develop healthy food habits and food choices.

## 2. Food Habits and Food Choices

Food habits refer to why and how people eat , which foods they eat , and with whom they eat .

Food choices are the selection of food a person makes for his own consumption.

Food  habits  and  food  choices  differ  from  person  to person, from one ethnic group to another and from one country to another. Making healthy food choices leads to adopting healthy food habits.

Good  eating habits during adolescence involve considering both the quality and quantity of foods eaten to ensure that meals consumed on different occasions remain healthy and help to reduce snacking.

<!-- image -->

## Food habits and food choices are influenced by both personal and external factors. These are:

## Personal factors:

- -Needs of a person: hunger, nutritional needs, activity level, state of health, appetite.
- -Nutritional  requirements: each  individual  has  a  specific nutrient requirement at different life stages.
- -Personal  preferences: like  or  dislike  of  different  types  of food: taste, smell, colour and texture of the food.
- -Moods and emotions: happiness, sadness, stress.
- -Lifestyle of people: eating out and use of convenience food.

## External Factors:

- -Availability  of  food: food  that  are  commonly  and  easily grown in the garden at home, local foods, food in season as well as imported foods.
- -Individual and family income: money available to spend on food for the family and pocket money of each individual.
- -Social occasions: family mealtimes, parties, picnic lunches.
- -Peer influence: people of the same age group eat different food and they may see their friends eating a food which they are not used to and in the long run they can start eating that particular food.
- -Ethnic group: traditions and religious beliefs.
- -Advertising: radio,  TV,  social  media and billboards promoting different types of food.

Factors affecting food habits and food choices

## 3. Eating Out

Eating out among adolescent is very common nowadays.  There  is  a  wide  variety  of  food available  from  which  adolescents  can  choose from.

## Some common eating outlets are:

- School or workplace canteen
- Street food vendors
- Food courts
- Fast-food outlets
- Restaurants

## Points to consider when eating out:

- Choose a variety of healthy food from the three food groups.
- Avoid foods that are oily/fatty, too sweet or too salty.
- Drink water instead of sweetened fizzy drinks or fruit juices.
- Choose foods that are steamed, grilled, stir-fried or roasted instead of deep fried.
- Choose fresh foods instead of processed foods.
- Opt for plain boiled rice/wholemeal bread.
- Use sauces, mayonnaise or dressings sparingly.
- Limit intake of cakes with cream/icing.

## Some hygiene practices to consider while eating out

## Ensure that:

- the place is clean.
- food is properly covered and kept in clean containers.
- drinking and running water is readily available for food preparation and for washing dirty utensils.
- food is not sold near dustbins or toilets.

In this image we can see a group of people sitting on the chairs and holding a pizza. In the background there is a table and there are glasses on the table.

<!-- image -->

<!-- image -->

## Work in groups.

1. Make a list of the food you normally eat for the following occasions:
- a) A religious festival
- b) Breakfast
- c) Fasting period
- d) Wedding reception
2. (i) Make a list of food you would choose to eat:
- a) At the school canteen
- b) Before going to tuition
- c) For snacks during the day
- d) When eating out
11. (ii) Discuss with your friends whether you have made healthy food choices or unhealthy food choices.

## 4. Healthy food habits and food choices to reduce the risks of NCDs

Healthy food habits and food choices established in childhood are often carried into adulthood. Learning how to eat healthy right from an early age will help to reduce the risk of developing NCDs.

## Examples of healthy food choices:

1. Increase intake of fruits and vegetables
2. Eat less salt
3. Limit consumption of foods rich in saturated fats
4. Limit intake of refined foods

## Examples of healthy food habits:

1. Do not skip breakfast
2. Include five fruits and vegetables in your daily diet
3. Increase the use of aromatic herbs and spices to season dishes
4. Increase intake of wholegrain products

## 5. Eating disorders

It  is  important for adolescents to acquire good eating habits for a healthy body weight. Unhealthy food habits and food choices are major causes of eating disorders among adolescents and adults.

Eating disorders include inadequate or excessive food intake which affect the body weight. The most common types of eating disorders which affect individuals (both males and females) are:

1. Binge eating
2. Anorexia Nervosa
3. Bulimia

<!-- image -->

## MORE TO KNOW

- Body Mass Index (BMI) is a person's weight in kilograms divided by the square of height in metres. A high BMI can be an indicator of high body fat and having a low BMI can be an indicator of having too low body fat. BMI can be used to screen for weight categories that may lead to health problems.

The table below gives a summary of the BMI range and category of body weight:

| BMI Range          | Category              |
|--------------------|-----------------------|
| Less than 15 to 16 | Severely underweight  |
| 16 - 18            | Underweight           |
| 18 - 24            | Normal healthy weight |
| 24 - 30            | Overweight            |
| 30 - 35            | Moderately obese      |
| 35 - 40            | Severely obese        |

<!-- image -->

BMI calculator: Calculate your BMI https://www.cdc.gov/healthyweight/bmi/calculator.html

## 1. Binge Eating

Binge eating is a condition characterised by eating larger than normal amounts of foods in a relatively short period of time. The person is unable to stop eating.

People suffering from binge eating will:

- eat until they feel uncomfortably full
- eat larger amounts without feeling hungry
- eat alone due to feelings of embarrassment and shame
- feel guilty and unhappy

Stress and depression are the main causes of binge eating.

## Undesirable health effects

Binge  eating  can  have  negative  effects such as gastrointestinal problems, overweight and obesity in the long run.

A person binge eating behaviour

<!-- image -->

<!-- image -->

## 2. Anorexia Nervosa

Anorexia  Nervosa  is  a  condition  characterized  by  an obsessive fear of gaining weight.

People who are affected by Anorexia Nervosa have an unrealistic perception of their body image.

These people will adopt:

- extreme diets
- extreme fasting
- excessive exercise

Very often, they severely limit the quantity of food they consume. They are underweight but they view themselves as overweight.

<!-- image -->

<!-- image -->

22

## Undesirable health effects

Anorexia can have severe damaging health effects such as brain damage, multi-organ failure, bone mass loss, heart difficulties and infertility.

## 3. Bulimia Nervosa

Bulimia Nervosa is a worsening condition of binge eating characterised by behaviours that compensate for the overeating, such as:

- forced vomiting
- excessive exercise
- extreme use of laxatives

In this image, we can see a picture of a woman holding a sandwich in her hands. We can also see some text on the image.

<!-- image -->

In this condition, binge eating is followed by self-induced vomiting and is typically done in secret, creating feelings of shame, guilt and lack of control of oneself.

Men and women who suffer from Bulimia Nervosa may fear weight gain and feel severely unhappy with their body size and shape.

## Undesirable health effects

Bulimia Nervosa can have injuring effects such as gastrointestinal problems, severe dehydration, body weakness and bad breath.

<!-- image -->

1. Fill in the blanks from the list provided below:

## healthy, water, less, fat, more

- a. Eat \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ fruits and vegetables.

- b. Choose food with \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ salt and sugar.

- c. Eat foods that are low in \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_, especially saturated and trans fat.

- d. Maintain a \_\_\_\_\_\_\_\_\_\_\_\_ body weight by exercising regularly and controlling food intake.

- e. Drink plenty of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

2. List two personal factors and two external factors that influence food choices and food habits.
3. State two points you need to consider when eating out to ensure that the food is healthy, clean and safe.
4. It is a hot summer day. Your family decides to go out to the beach for a picnic lunch. Explain the three factors that you will consider while making your food choice for the picnic lunch.
5. List four examples of
- i) healthy food choices
6. ii) healthy food habits
6. a) Name three eating disorders.
- b) State one undesirable effect for each of the eating disorders you mentioned in 5 (a).

## Food Technology

## TOPIC: Sustainable Food Production and Consumption

## Learning Objectives

## At the end of this unit, you will be able to:

- Differentiate between sustainable and unsustainable food production and consumption practices.
- Give examples of sustainable food production and consumption practices.

## 1. Introduction

Sustainable food production is when food is produced, processed, distributed and disposed of in ways that contribute to the community's environmental, economical and ecological wellbeing.

<!-- image -->

<!-- image -->

GRADE

Sustainable food consumption is the result of choices that consumers make when purchasing products in order not to affect the environment and reduce waste.

Unsustainable food production and consumption practices lead to:

- deforestation
- soil depletion
- increased energy demand (energy wastage)
- food wastage
- water wastage
- increase in landfill sites

Unit 2

## 2. Sustainable food production and consumption practices

Sustainable  food  production  and  consumption  practices  can  be  adopted  at  individual, agricultural and industrial levels.

## 1. Individual/ Community level:

- People are advised to cultivate vegetables and fruit trees. As a result this will help to reduce weed invasion, prevent land erosion and promote a healthy biodiversity.
- Instead  of  travelling  by  individual  cars  regularly,  people  can  use  alternative  transport systems.  Example:  walking,  riding  a  bicycle  and  using  public  transport  while  going  for grocery shopping.

## 2. Agricultural level

Sustainable agriculture has an important role to play in:

- preserving natural resources
- reducing greenhouse gas emissions
- reducing biodiversity loss
- caring for valued landscapes

One example of sustainable agriculture is the cultivation of Cassava (Manioc).

This image consists of two images. The first image is a collage of two images. The first image is a picture of a plant with green leaves. The second image is a picture of a plant with green leaves. Both images are taken from a top-down view. The background of the first image is blurred, while the background of the second image is not visible.

The first image shows a plant with green leaves. The leaves are smooth and have a glossy texture. The plant is not very detailed, but it is still recognizable by its shape and size. The leaves are arranged in a way that they are not perfectly aligned, but they are still visible.

The second image shows a plant with green leaves. The leaves are also smooth and have a glossy texture. The plant is not very detailed, but it is still recognizable by its shape and size. The leaves are arranged in a way that they are not perfectly aligned, but they are still visible.

Both images have

<!-- image -->

Cassava  plant  grows  well  in  soil  that  does not  require  much  fertilizer  and  the  plant requires low  rainfall. It shows good resistance to drought,diseases and pests. It is an environment-friendly plant that does not need  treatment  with  pesticides  or  chemical fertilizers.

Other examples of sustainable agriculture are: cultivation of banana and coconut plants.

In this image we can see a collage of different types of bananas.

<!-- image -->

## 3. Industrial level

Food industries can develop more sustainable food production practices by:

- Reducing  use  of  chemicals  for  example,  artificial  food  additives,  food  sweeteners,  food colours, etc.
- Using recycled materials for food packaging.

## 3. Examples of sustainable food production and consumption practices

## Sustainable food production practices

Sustainable  food  production  practices  take  into  consideration  the  social,  economical  and ecological wellbeing. Some examples of sustainable food production practices are:

1. save water
2. encourage 3 Rs (reduce, reuse and recycle)
3. support local food production
4. grow your own food

## 1. Save water

Every living organism consists of about 80% of water. Without water, neither people, nor plants, nor animals would survive. Crops would not be able to grow in the fields, and eventually, there would be no food. Saving water helps to:

- preserve our environment
- saves money
- allows constant safe food supplies

<!-- image -->

## MORE TO KNOW

Food and agricultural industries are the largest consumers of water, requiring one hundred times more than for personal needs.

Up to 70% of the water we use from rivers and boreholes are fed into irrigation, 20% in industries and about 10% is used in domestic applications.

Two-thirds  of  the  world's  population  will  live  in  water-stressed  countries  by  2025  if  the current consumption patterns continue.

<!-- image -->

<!-- image -->

Water stress occurs  when  the  demand  for water exceeds  the  available  amount  of  water  during  a certain period of time.

<!-- image -->

## Work in groups.

Make a list of actions that could be taken to save water at:

- (i) At school level

(ii) Household level

## 2. The 3 Rs: Reduce, Reuse and Recycle

<!-- image -->

The concept of the 3 Rs help to cut down on the amount of waste so that a reduced amount of it goes to the landfill.

## Reduce: Reduce waste.

Examples: Compost food wastes at home:

- The use of manure or compost for plantation helps to reduce the use of chemical fertilizers which in turn helps to reduce water and land pollution.
- To reduce waste use cloth napkins instead of paper napkins.

## Reuse: Reuse materials.

Example: Old glass jars and pots can be used to store items in the kitchen.

- Scrap fabrics can be used to make craft items.

## Recycle: Make new products with materials that have been discarded.

Examples: Buy products that can be recycled such as glass jars.

- Dispose of your PET bottles in special bins to be recycled, thus decreasing land pollution.

<!-- image -->

## KEY TERMS

PET (polyethylene terephthalate) bottle: a bottle constructed from high density plastic. They are typically used to store liquids such as water, soft drinks, motor oil, cooking oil, medicine and shampoo.

<!-- image -->

## Work in groups.

Discuss and come up with examples to illustrate how you can apply the 3Rs concept at home. Fill the table below and present your findings to the whole class.

## 3. Support local food production

Local  production  reduces  transportation  of  food  products  and  thus  reduces  air  pollution produced by smoke from vehicles.

In this image we can see a collage of two images. In the first image we can see a grated cheese and a grated cheese is placed on a grater. In the second image we can see a grated cheese and a grated cheese is placed on a grater.

<!-- image -->

Although Cassava is primarily grown for its roots, all the parts of the plant can be used: the wood as fuel, the leaves and peelings for animal feed and even the stem for dietary salt.

It can be processed into flour to make biscuits as well as Tapioca from which different cassava-based dishes are prepared.

## 4. Grow your own food

Plant some of your own vegetables and herbs.  Pots, old boots, boxes, car tyres, old furniture, can be used to cultivate herbs. If you do not have a yard, you can use indoor pots.

In this image we can see a collage of images. In the first image there are many tires placed in the soil. In the second image there are many plants and potatoes placed in the soil. In the third image there are many plants and potatoes placed in the soil. In the fourth image there are many plants and potatoes placed in the soil. In the fifth image there are many plants and potatoes placed in the soil. In the sixth image there are many plants and potatoes placed in the soil.

<!-- image -->

<!-- image -->

## MORE TO KNOW

Follow the concept of Farm to Fork . A food system includes everything that starts from the farm to the table where the food production, processing, distribution and consumption are integrated to enhance environmental, economical, social and nutritional health.

## Sustainable Food Consumption Practices

Consumers are called upon to take responsibility for sustainable food consumption practices. Sustainable  food  consumption  practices  help  to  save  energy,  water  and  to  protect  the environment and get value for money. There are different ways of practising sustainable food consumption practices, for example:

1. preparing and cooking food
2. shopping smartly
3. eating different types of local foods
4. preserving different types of foods

## 1. Preparing and cooking food

- Make use of local ingredients.
- Make smart use of leftovers to reduce food wastage; for example: left over bread can be used to make bread pudding and left over rice can be used to make fried rice.

<!-- image -->

Fried rice made from left over rice

<!-- image -->

- Using kitchen appliances efficiently for cooking food. For example: boiling and steaming can be carried out at simultaneously. Make use of residual heat from hot plates or oven to heat food.
- Soak rice and pulses to reduce cooking time.
- Boil pulses in bulk and freeze in small containers to be used afterwards

<!-- image -->

<!-- image -->

## MORE TO KNOW

Residual heat is the heat that remains after something has been hot or heated up.

## 2. Shopping smartly

- When shopping for food, think about carrying eco-friendly bags with you.
- Buy less processed foods.
- Choose products that have less packaging. Many packaging materials cannot be recycled and  much  energy  was  required  for  their  production.  Packaging  is  one  of  the  main contributors of land pollution.
- Prepare a shopping list to avoid buying more than required thus, preventing wastage.
- Check expiry dates.
- Preserve your food correctly by checking the temperature of your refrigerator. Use FIFO (First in First Out) as a kitchen rule to avoid food wastage.

In this image we can see a group of people, some of them are holding fruits in their hands, there are some baskets, some objects on the racks, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby, there is a man holding a cart, there is a woman holding a baby,

<!-- image -->

## 3. Eating different types of local foods

- Eat local foods in season. This saves energy from being spent on freezing/refrigerating and transporting food over thousands of kilometres.

In this image we can see the fruits and leaves.

<!-- image -->

- When  purchasing  meat,  poultry,  eggs  and  dairy  products,  look  for  food  raised  in  an environment (e.g. local farms) where animals are allowed outdoors and are nourished with balanced diets.
- Choose locally caught and raised fish. Destructive fishing practices and poorly managed fisheries hurt the fish population and the environment.

In this image we can see a woman is holding some food items. In the background there are some hens.

<!-- image -->

## 4. Preserving different types of foods

Growing and preserving food is one of the most important aspects of sustainability. Preserving surplus food increases the shelf life of food, thus preventing wastage and making them available when not in season.

Examples of food preservation methods are: pickling , canning , dehydrating and freezing .

In this image, we can see a jar of food.

<!-- image -->

In this image we can see fishes in the bowl.

<!-- image -->

<!-- image -->

## REMEMBER

- Sustainable food production and consumption aim to improve the overall environment through healthier and safer food production and consumption practices.

34

<!-- image -->

1. Define the following terms:
2. (a) sustainable food production
3. (b) sustainable consumption practices
2.  List one example under each of the 3 Rs:
5. (i) Reduce
6. (ii) Reuse
7. (iii) Recycle
3. Classify the following statements in the table given below to differentiate between sustainable and unsustainable food production and consumption practices:
- Optimise land use for agriculture and use compost as fertilisers.
- Do not preserve food and throw away leftovers.
- Increase biodiversity through farming that protects land, water and energy resources.
- Reduce, reuse and recycle materials.
- Buy more processed foods and products that have a lot of packaging.
- Increase the use of coal, oil and natural gas.

## Principles and Methods of Food Preparation

## TOPIC 1: Kitchen Equipment

## Learning Objectives

By the end of this unit, you will be able to:

- Demonstrate the safe use of the stove, oven and microwave oven during food preparation.

## 1. Introduction

GRADE Some foods can be eaten raw while others require cooking to make them edible. The main reasons for cooking food are to:

- kill harmful bacteria
- make food attractive and palatable
- preserve food
- add variety

The main equipment used for cooking are the:

- Stove
- Oven
- Microwave oven

In this image there is a picture of a microwave oven, oven, stove and a stand.

<!-- image -->

Unit 3

36

Important points to consider when choosing these equipment are:

- functions
- size and capacity
- space available
- cost of appliance
- care and maintenance

## 2. The kitchen stove

The kitchen stove is  one of the most common cooking appliances. It uses either gas or electricity to provide heat for cooking food.

In  Mauritius,  Rodrigues  and  the  outer  islands,  the gas stove is  a  popular  and  budget-friendly choice.

Main features of a Table-top gas stove with 2 burners

In this image there is a diagram, in the diagram there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a gas burner, there is a

<!-- image -->

## Different models of stoves:

In this image there is a stove.

<!-- image -->

The main methods of cooking on a stove include:

1. Boiling
2. Steaming
3. Frying

<!-- image -->

<!-- image -->

<!-- image -->

| Boiling                                                                                                                                     | Boiling                                                                                                                                     |
|---------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| Definition                                                                                                                                  | Boiling is cooking food in liquid usually water, at 100 0 C                                                                                 |
| Suitable foods                                                                                                                              | Egg, rice, macaroni, potato                                                                                                                 |
| Advantages                                                                                                                                  | 1. Easy to digest 2. Cheap method of cooking                                                                                                |
| Disadvantage                                                                                                                                | Water-soluble vitamins are lost in the cooking water                                                                                        |
| Steaming                                                                                                                                    | Steaming                                                                                                                                    |
| Definition                                                                                                                                  | Steaming is cooking food in water vapour                                                                                                    |
| Suitable foods                                                                                                                              | Fish, cauliflower, pudding, sponge cake                                                                                                     |
| Advantages                                                                                                                                  | 1. Less loss of water-soluble nutrients 2. Various foods can be cooked at the same time                                                     |
| Disadvantage                                                                                                                                | Special equipment may be required                                                                                                           |
| Frying                                                                                                                                      | Frying                                                                                                                                      |
| Definition                                                                                                                                  | Frying is cooking food in hot oil                                                                                                           |
| Suitable foods                                                                                                                              | Chicken, pancakes, vegetables, tofu, eggs, samoussas, ' gato pima '                                                                         |
| Advantages                                                                                                                                  | 1. Quick method of cooking 2. Fried food is tasty and has a crisp texture                                                                   |
| Disadvantage                                                                                                                                | Constant attention is required                                                                                                              |
| Note: The four types of frying are: 1. Dry frying 2. Stir frying 3. Shallow frying 4. Deep frying (Listed in increasing amount of oil used) | Note: The four types of frying are: 1. Dry frying 2. Stir frying 3. Shallow frying 4. Deep frying (Listed in increasing amount of oil used) |

## Note:

Electric steamers are available on the market nowadays.

<!-- image -->

## Safety tips when using the stove

1. Be careful when opening the lid of the cooking utensil as hot steam may cause scalds (wet burn) on the face.
2. Turn all pot and pan handles inwards.

They can be pulled and knocked over when they are turned out.

## 3. The oven

An oven is an enclosed compartment used for cooking and heating food. Gas and electricity are the main fuels used.

Main features of a modern oven (built-in model)

In this image there is a machine, there is a control panel, there is a door with handle, there are some objects, there is a text.

<!-- image -->

## Note:

- Electric ovens have heating elements either in the base or sides of the oven compartment.
- A thermostat controls the temperature in the oven.
- Automatic timers control the starting time, duration of cooking and time at which cooking finishes.

<!-- image -->

## MORE TO KNOW

A cooker is a kitchen appliance which consists of a top stove, a front oven and a grill.

The type of fuel used for ovens can be:

- a combination of gas and electricity
- only gas
- only electricity

Main features of a free-standing cooker operated by gas and electricity

In this image, we can see a picture of a stove, oven, and a door.

<!-- image -->

Note: Features vary according to make and models.

The main methods of cooking in an oven include:

1. Baking
2. Roasting
3. Grilling

<!-- image -->

<!-- image -->

<!-- image -->

| Baking         | Baking                                                                                                   | Baking   |
|----------------|----------------------------------------------------------------------------------------------------------|----------|
| Definition     | Baking is cooking food in a hot oven                                                                     |          |
| Suitable foods | Cakes, biscuits, pastries, breads                                                                        |          |
| Advantages     | 1. Needs less constant attention 2. Residual heat can be used to keep food hot or for reheating purposes |          |
| Disadvantage   | Consumes much electricity                                                                                |          |
| Roasting       | Roasting                                                                                                 | Roasting |
| Definition     | Roasting is cooking food in a hot oven with little fat                                                   |          |
| Suitable foods | Meat, chicken, potatoes                                                                                  |          |
| Advantages     | 1. Good development of colour, flavour and texture 2. Can be cooked and served in the same dish          |          |
| Disadvantage   | A slow method of cooking                                                                                 |          |
| Grilling       | Grilling                                                                                                 | Grilling |
| Definition     | Grilling is cooking food using intense heat                                                              |          |
| Suitable foods | Gratin, brochettes, sausages, bread, meat                                                                |          |
| Advantages     | 1. Easy to digest 2. Little loss of nutrients                                                            |          |
| Disadvantage   | Wrap some foods in foil to prevent burning and loss of flavour                                           |          |

## Safety tips when using the oven

1. Position oven racks before pre-heating.
2. Use oven gloves to handle cake tins, baking trays or ovenproof dishes to avoid burns.

## 4. The Microwave Oven

A microwave oven is  an  electric  appliance that uses waves of energy to cook or heat food quickly.

Main features of a modern microwave oven

In this image there is a microwave oven. There is a glass door. There is a control panel. There is a switch. There is a power level control panel. There is a door lock.

<!-- image -->

## Microwave power levels

Most microwave ovens are equipped with a variable power level control knob namely High , Medium and Low .

Each power level is used to cook different types of foods as indicated below:

| HIGH       | MEDIUM     | LOW       |
|------------|------------|-----------|
| Pasta      | Eggs       | Rice      |
| Vegetables | Custards   | Puddings  |
| Fish       | Casseroles | Pot roast |

42

## Standing time

After the cooking time, the molecules in the food continue to generate heat. This additional cooking after the microwave stops is called standing time .

During this time, the temperature of a food can increase by several degrees. For that reason, recipe instructions may advise to let a food 'stand' or 'rest' for a few minutes after cooking time.

<!-- image -->

| Microwave cooking is cooking food by electromagnetic waves which agitate molecules in food   | Definition     |
|----------------------------------------------------------------------------------------------|----------------|
| Rice, noodles, puddings, small or thin pieces of meat, chicken, fish, fruits and vegetables  | Suitable foods |
| 1. Quick cooking as heat is produced immediately 2. Easy to use                              | Advantages     |
| Risk of overcooking foods                                                                    | Disadvantage   |

## Safety tips when using the microwave oven

1. Never use metal, aluminium foil nor polysterene in the microwave oven. Not all plastic containers can be used in the microwave oven.
2. Always allow food to stand for a few minutes after cooking/heating time to avoid burning.

## The microwave safe symbol

This is used to indicate whether a food or a container is safe to use in the appliance.

<!-- image -->

The microwave safe symbol

<!-- image -->

Uses of microwave oven:

Find out other uses of the microwave oven. You may consult a microwave manual.

<!-- image -->

Refer to the recipes provided in this textbook and identify the:

- method of cooking used
- type of cooking appliance required
- cooking temperature
- cooking time

You may follow the example in the table below:

| Nameof recipe                      | Method of cooking used   | Type of cooking appliance   | Cooking temperature ( 0 C/ low/ medium/high)   | CookingTime   |
|------------------------------------|--------------------------|-----------------------------|------------------------------------------------|---------------|
| Cinnamon Oat Cookies (in appendix) | Baking                   | Oven                        | 160 0 C                                        | 15 minutes    |
| Sponge cake                        |                          |                             |                                                |               |
| Chop Suey                          |                          |                             |                                                |               |
| Caramel Bread Pudding              |                          |                             |                                                |               |

## TOPIC 2: Healthy meals

## Learning Objectives

## By the end of this unit, you will be able to:

- Plan healthy and attractive meals.

## 1. Introduction

Eating healthy meals is essential for maintaining good health throughout life.

A healthy meal provides all the nutrients and dietary fibre needed by the body in the right proportions for the individual.

Meals refer to foods eaten at a specific time of the day.

The three main meals of the day are:

- Breakfast
- lunch
- dinner

Use the Three Food Groups to plan healthy meals.

## FOOD FOR ENERGY

Foods that belong to this group provide the body with the energy required for daily activities. Some examples of Food for Energy are rice, bread, biscuits, farata, sugar, cooking oils and butter.

## FOOD FOR HEALTH

Foods that belong to this group protect our body against diseases. Some examples of Food for Health are fruits and vegetables .

In this image, we can see a plate with different food items.

<!-- image -->

## FOOD FOR GROWTH

Foods that belong to this group help the body to grow and repair body tissues. Some examples of Food for Growth are milk, eggs, meat, pulses, seafood, nuts and soya.

## Examples of healthy meals:

## 1. Healthy breakfast

Milk, cereal and fresh fruit

<!-- image -->

## 2. Healthy packed lunch

Bread with chicken and tomato and lettuce salad

<!-- image -->

## 3. Healthy vegetarian dinner

<!-- image -->

Soya curry, dhal, cooked greens pumpkin and fresh salad with rice

<!-- image -->

bread, butter, banana, cheese and milk

Pasta with cheese, vegetables and fruit

<!-- image -->

Whole-wheat wrap with sautéed vegetables and cheese

<!-- image -->

46

<!-- image -->

A meal usually consists of different courses.

A two-course meal consists of:

Main Course

Main dish

First accompaniment

Second accompaniment

Sweet course

Dessert

## A three-course meal consists of:

| Course       | Component            | Examples                                                                                |
|--------------|----------------------|-----------------------------------------------------------------------------------------|
| First course | Starter dish         | Appetiser, soups, crudités                                                              |
| Main Course  | Main dish            | Meat/poultry/fish/vegetable protein dish                                                |
|              | First accompaniment  | Cooked vegetable dish (e.g. steamed cauli- flower) Carbohydrate dish (e.g. bread/ rice) |
|              | Second accompaniment | Fresh vegetable dish (e.g. Vegetable salad with dressing)                               |
| Sweet course | Dessert              | Fresh fruits, yoghurt, sweet dishes (e.g. Caramel custard)                              |

<!-- image -->

## ACTIVITY 2: PLANNING HEALTHY MEALS (Groupwork)

1. Using the Three Food Groups, plan healthy meals for the following occasions:
2. (a) Breakfast for your family
3. (b) A packed lunch for an adolescent going to school
4. (c) A two-course dinner for your family on a weekday
5. (d) A three-course Sunday lunch for your family
2. Present your work on a poster.
3. Make a display of the posters in class.

## Tip for healthy food choice:

In a two-course meal , the amount of food served on the plate make up the portion size that an individual usually eats in a standard meal.

However, when a three-course meal is to be consumed, it is advised to reduce the amount of  food  eaten  in  the  different  courses  so  as  not  to  exceed  the  normal  nutritional  body requirements.

## 2. Garnish and decoration

To  make  meals  appealing  and  attractive,  it  is  essential  to  garnish  and  decorate  the  dishes prepared.

A garnish is  the  attractive  finish  given  to  a savoury dish  whereas  a decoration is  used  to complete a sweet dish.

Garnishes and decorations add nutritive value and contribute to the colour, flavour and texture of the dish.

## Garnishes

In this image, we can see some food items.

<!-- image -->

## Decorations

In this image, we can see a food item. There are some fruits and a knife. We can also see some text.

<!-- image -->

| Decoration             | Example                |
|------------------------|------------------------|
| Orange segments        | Orange segments        |
| Lemon slices and rinds | Lemon slices and rinds |
| Decorative fruits      | Decorative fruits      |
| Chocolate curls        | Chocolate curls        |

## TOPIC 3: Convenience foods

## Learning Objectives

## By the end of this unit, you will be able to:

- Use different types of convenience foods to prepare healthy meals.

## 1. Introduction

A convenience food is a food that has been prepared partly or wholly by the food manufacturer to facilitate the ease of:

- preparation
- cooking
- consumption

The three main types of convenience foods are:

In this image I can see a box, a bowl, a plate, a bottle and a few other objects. In the background I can see a person and a table.

<!-- image -->

| 1. Ready to eat food             | 2. Ready to cook food                                        | 3. Ready to use food                                               |
|----------------------------------|--------------------------------------------------------------|--------------------------------------------------------------------|
| • Cereals • Canned pulses • Milk | • Pizza • Dehydrated potato • Frozen dumplings • Minced meat | • Indian curry • Grated cheese • Tart shells • Salads in barquette |

49

50

## Advantages of convenience foods:

- save time
- save energy
- less wastage
- can be kept for emergencies
- may have extra nutrients added

## Disadvantages of convenience foods:

- expensive
- must follow instructions carefully for good results
- small serving portions
- nutrients lost during processing are not replaced
- low in dietary fibre
- wide variety available
- high in fat, sugar and salt

## 2. How to use convenience foods in healthy meals?

Convenience foods tend to have a high salt, sugar and fat content. Therefore, they should be used judiciously.

## Examples for 'healthy' use of convenience foods are:

| Type of convenience food   | Example                          | Uses                                                                                                                                             |
|----------------------------|----------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| Ready to eat food          | Breakfast cereals                | • Cereals can be used for breakfast with milk                                                                                                    |
| Ready to eat food          | Canned pulses                    | • Canned pulses can be used in curries and served with rice, bread or'faratha'                                                                   |
| Ready to eat food          | 'Rougaille'                      | Rougaille can be used as: • Topping for pizza • Filling for'dhal puri'or faratha • Sauce to serve with pasta, rice, grilled sausages/ vegetables |
| Ready to cook food         | Minced meat                      | • Burgers • Pie filling • Bolognese sauce                                                                                                        |
| Ready to cook food         | Dehydrated potato                | • Can be rehydrated with milk/egg • Flavoured with cheese/ butter/ herbs                                                                         |
| Ready to use food          | Tart shells, salads in barquette | • Fresh fruits tarts can be made by simply filling with custard and decorating with fresh fruits.                                                |

<!-- image -->

## ACTIVITY 1: MARKET RESEARCH

1. With the help of your parents/guardians, find out the different types of convenience foods available on the market and classify each of them under:
- ready to eat
- ready to cook
- ready to use

## TOPIC 4: Healthy Cooking

## Learning Objectives

## By the end of this unit, you will be able to:

- Prepare and serve healthy and attractive meals.

## 1. Introduction

The healthy recipes proposed for Grade 9 are:

Caramel Bread Pudding

<!-- image -->

<!-- image -->

<!-- image -->

## NOTE TO EDUCATORS

- These recipes have been selected to help adolescents follow the dietary guidelines for healthy eating.
- Plan recipes according to the school context, facilities and resources available.

<!-- image -->

## REMEMBER

|   Personal hygiene rules | Personal hygiene rules                                |
|--------------------------|-------------------------------------------------------|
|                        1 | Wear a clean apron and head cover.                    |
|                        2 | Avoid wearing jewellery.                              |
|                        3 | Keep fingernails short and clean without nail varnish |
|                        4 | Do not sneeze or cough on or near food.               |

| Weights and measures   | Weights and measures   |
|------------------------|------------------------|
| tablespoon             | Tbsp                   |
| teaspoon               | tsp                    |
| litre                  | l                      |
| millilitre             | ml                     |
| grammes                | g                      |

51

## 2. Food preparation techniques: Cake Making

The five main methods of cake making are:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Methods of Cake Making        | Principles                                                                                                     | Example                     |
|-------------------------------|----------------------------------------------------------------------------------------------------------------|-----------------------------|
| Rubbing-in method             | Rub in fat with flour using the fingertips until the mixture looks like fine breadcrumbs.                      | Fruit loaf                  |
| Creaming method               | Cream fat and sugar until a light and fluffy mixture is obtained.                                              | Victoria Sandwich           |
| All-in-one / One-Stage method | All ingredients are mixed together until a soft, light, fluffy mixture is obtained.                            | Chocolate muffins           |
| Whisking method               | Whisk eggs and sugar into a stable foam before folding in the flour.                                           | Swiss roll                  |
| Melting method                | Melt fat with sugar over a gentle fire until all sugar crystals are dissolved. Add to the flour after cooling. | Gingerbread (Pain d'Epices) |

## Sponge Cake

## Ingredients

Quantity

Eggs

2

Castor sugar

50 g

Plain flour

50 g

Vanilla essence

½ tsp

## For lining cake tin:

Baking paper

1 sheet

Oil

1 tsp

<!-- image -->

Number of servings:

5

Preparation Time:

30 minutes

Cooking appliance:

Oven

Cooking temperature:

180 0 C

Shelf position

Middle

Cooking time

10 - 15 minutes

## Step-by-step Instructions

<!-- image -->

- Grease cake tin. 1
- Break eggs in a mixing bowl. 4
- Line the base of cake tin with greaseproof paper and grease on top. 2
- Add sugar. 5
- 3
- Sieve flour. Preheat oven to 180  0 C.
- Whisk with an electric mixer until a trail is clearly visible. 6

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

53

54

<!-- image -->

- Test readiness by dropping some mixture on top of the surface. It should remain visible for 3-5 seconds. Add vanilla essence. 7
- Transfer to a baking tin immediately. 10
- Sift half flour on the surface of whisked egg and sugar mixture (foam) . 8
- Bake for 10 -15 minutes until well risen and golden brown. 11

<!-- image -->

<!-- image -->

<!-- image -->

## Suggested decoration:

- Sprinkle 1 Tbsp icing sugar on top for a snowy finish
- Spread 1 Tbsp Jam on top for a glossy finish
- Use fresh local fruits for a colourful finish

## Variations:

Chocolate sponge cake:  Substitute 1 level Tbsp of flour with 1 level Tbsp of cocoa powder. Genoese sponge cake: Fold in gently 1 Tbsp of oil or 1 Tbsp melted unsalted butter after flour is mixed.

<!-- image -->

- Fold in flour gently using a metal spoon to prevent loss of air and to keep the mixture light. Repeat the procedure with the rest of flour. 9
- Transfer on a cooling rack. Remove greaseproof paper and allow to cool. 12

<!-- image -->

## Chop Suey

## Ingredients

## Quantity

Baby corn (canned)

100 g

Mushrooms, canned/dried

100 g

Onion

2 large

Carrot

100 g

Red pepper/capsicum

100 g (optional)

Bok choy (Bredes 'Tompouce')

2 bunches

Shallots

1 bunch

Soyabean oil

1 Tbsp

Garlic cloves

2

## Sauce

Tapioca powder

30 g

Water

100 ml

Oyster sauce

1 tsp

Soya sauce

2 drops

Pepper

To taste

## Garnish

Coriander

1 bunch

## Method

1. Wash all fresh vegetables.
2. Drain and rinse canned corn and mushroom.
3. Peel onion and cut into wedges.
4. Top and tail then scrape the carrots.
5. Deseed and slice pepper.
6. Separate stems and leaves of Bok Choy.
7. Slice all vegetables diagonally.
8. Heat oil in wok, add garlic, corn and mushroom.
9. Stir fry (toss rapidly over high heat).

<!-- image -->

Number of servings:

5

Preparation Time:

30 minutes

Cooking appliance:

Stove

Cooking temperature:

Medium

Cooking time:

Vegetables:

~10 minutes

Sauce:

2 - 3 minutes

<!-- image -->

## MORE TO KNOW

Chop Suey is  a  Chinese vegetable dish with a tasty savoury sauce which can be served as accompaniment in a meal.

Tapioca ('poudre  cange') ,  a  gluten-free starch extracted from the cassava root, is used to thicken the sauce.

<!-- image -->

10. Add carrot, pepper, onion, stem of Bok Choy and stir fry.

## Prepare sauce:

11. Blend tapioca powder with 2 tablespoons of water and mix with all other ingredients.
12. Add to the stir-fried mixture. Cook for 2-3 minutes until thickened.
13. Add leaves of Bok Choy.
14. Remove from heat.

## Serving Suggestion

Serve hot in a deep serving dish, garnished with chopped coriander.

55

56

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Chop SueyVariations   | Method                                                                                                                                          |
|-----------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Peanuts/ Cashew nuts  | Dry fry 50 g of nuts then add to the sauce.                                                                                                     |
| Tofu                  | Slice 250 gtofu, season with ½tspsoya sauce and 1 tsp garlic paste and pepper to taste. Shallow fry until golden on each side.                  |
| Fish                  | Cut 500 g fish fillet into mouth size pieces, season lightly with salt and pepper to taste. Shallow fry or steam.                               |
| Chicken               | Cut 500 g chicken fillet, into mouth size pieces, season with ½tsp soya sauce and 1 tsp garlic paste and pepper to taste. Shallow fry or steam. |

<!-- image -->

## MORE TO KNOW

In  the  above  variations  of  chop  suey,  either  a  plant  protein  food (nut/tofu) or  an  animal protein food (fish/chicken) is added to the vegetables hence making the dish a main dish .

## Caramel Bread Pudding

## Ingredients

## Quantity

Caramel:

Sugar

75 g

Bread Pudding:

Bread

1/100g (1 day old)

Eggs

2

Milk

200 ml

Sugar

2 Tbsp

Vanilla essence

1 tsp

Orange zest, finely grated

1 tsp

## Method

- In a saucepan, make caramel by melting sugar over low heat until a golden colour is obtained. (You may add 2 Tbsp water to obtain a pouring caramel). 1

Transfer immediately to coat evenly the base of  an  ovenproof  dish (for  example  a  large soufflé dish) . Allow to cool and set.

<!-- image -->

Number of servings:

5

Preparation Time:

30 minutes

For Caramel

Cooking appliance

Stove

Cooking temperature

Low

Cooking time

~5 minutes

For Pudding

Cooking appliance

Microwave oven

Cooking temperature

Power level: Medium - 700 W

Cooking time

8 minutes

Standing time

2 minutes

<!-- image -->

<!-- image -->

<!-- image -->

- Cut whole bread into small pieces. 2

<!-- image -->

<!-- image -->

57

- Whisk  eggs,  sugar,  milk  and flavourings lightly and use to soak bread. 3
- Cook for 8 minutes in microwave oven set on 700W, until well set. Allow to stand 1-2 minutes. 5
- Mash soaked bread until smooth and thick using either a fork or a potato masher. Pour bread mixture onto cooled caramel. 4
- Unmould immediately. Cool, then decorate. 6

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Serving Suggestion

- Serve in a deep plate decorated with fresh mint leaves.

## Variations

Chocolate and Orange Bread Pudding: Use 1 tablespoon cocoa powder and 1 teaspoon orange zest as flavouring.

Mini Puddings: To make mini puddings, use small soufflé dishes or a silicone patty tin. Cook for 3 minutes.

<!-- image -->

## 1. a) List the five methods of cake making and name 1 example for each method.

- b) Which method of cake making
- i. uses less fat?
- ii. does not require an electric mixer?
- c) Differentiate between the all-in-one method and the creaming method of cake making.

## 2. Match Column A with Column B

| ColumnA          | Column B                                                   |
|------------------|------------------------------------------------------------|
| Microwave oven   | Whisking of eggs and sugar in a stable foam.               |
| Convenience food | The attractive finish given to a sweet dish.               |
| Garnish          | Melting of fat and sugar over gentle heat.                 |
| Decoration       | An electric appliance which reduces cooking time.          |
| Whisking method  | The attractive finish given to a savoury dish.             |
| Melting method   | Food which is ready to eat or require minimal preparation. |

## 3. Chop Suey is a popular Chinese dish.

- a) Name two local vegetables used in the dish.
- b) Why is Chop Suey also considered as an accompaniment?
- c) Suggest an additional ingredient to be added to make it a main dish suitable for:
4. (i) a vegetarian
5. (ii) a non-vegetarian
- d) Propose a different garnish for the dish.

## 4. a) Rearrange the correct order of making the recipe of Caramel Bread Pudding:

| Steps   | Method                                                                 |
|---------|------------------------------------------------------------------------|
|         | Mix eggs, milk sugar and flavouring.                                   |
|         | Cool, decorate and serve.                                              |
|         | Soak bread with egg mixture.                                           |
|         | Make a golden caramel.                                                 |
|         | Cut bread into small pieces.                                           |
|         | Transfer caramel to coat the base of microwave dish and allow to cool. |
|         | Mash soaked bread until fine. Pour onto caramel.                       |
|         | Cook in microwave oven then allow to stand.                            |

- b) Identify a sustainable food consumption practice used in the recipe.
- c) Suggest a different way of decorating the dish.
- d) Plan a healthy dinner for your family using this dish as a dessert .

## Self and Family Awareness

## TOPIC 1: Building Strong Family Relationships

## Learning Objectives

## By the end of this unit, you will be able to:

- Explain the importance of strong family relationships.
- Suggest ways to cope with the challenges for building and maintaining strong family relationships.

## 1. Introduction

GRADE Families are considered as the building blocks of society. The health and well-being of a society is strongly linked to that of the family. Families who share strong relationships help contribute to the well-being and emotional health of its members. They live in happiness and harmony with each other. Building strong healthy family relationships is therefore the basis of a healthy society.

<!-- image -->

In this image we can see a group of people. In the background there are trees.

<!-- image -->

In this image we can see a collage of different people.

<!-- image -->

62

## 2. Importance of building strong family relationships

In this image we can see a person wearing a green color t-shirt and a woman wearing a pink color t-shirt and a man wearing a green color t-shirt. They are smiling and giving a pose to the camera.

<!-- image -->

Strong family relationships also help to:

- overcome everyday hurdles  such  as  coping  with  school  problems,  health  issues  or  any other important decisions.
- respect differences in  opinions.
- provide children with the skills they need to build healthy relationships of their own.

## Ways to build strong family relationships:

In this image we can see a picture of a group of people holding hands. In the background there is a sunset and the sky is in orange color.

<!-- image -->

## To build strong relationships, each member should be able to:

<!-- image -->

trust and rely on each other for support, love and affection.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

value and respect each other.

discuss among family members before  making important decisions.

share responsibilities for house chores.

spend time together doing things they enjoy (e.g., sports, reading, camping, playing games such as Snakes and Ladders, Dominos, Scrabble.).

show affection and care regularly through kind words, hugs and  encouragement.

Families with strong relationships share common goals and work together to reach those goals. The family well-being should be viewed as top priority and each member should work hard to maintain the strong relationships.

<!-- image -->

Family goals are the targets that families set out to achieve. Family goals are  very powerful ways to build trust, communication and togetherness.

Examples of family goals are: buying/building a house, sending children abroad to study, going on a family vacation, buying a car and so on.

<!-- image -->

## RESEARCH WORK: FAMILY GOALS

- (a) Discuss with your parents /guardian to find out what are your family goals.
- (b) Make a list of these and reflect on how you could contribute to achieve these goals.

| Myfamily goals                | What I can do to help reach these goal?   |
|-------------------------------|-------------------------------------------|
| For example : Build our house | I should be careful whenspendingmoney     |

<!-- image -->

Fill in the report card below to know about your contribution in building strong family relationships.

1. Do I use praise at least once a day towards any family member?

Yes                           No                           Will do

2. Do I behave properly inside and outside the home?

Yes                           No                           Will do

3. Am I available when needed?

Yes                           No                           Will do

4. Do I include my family members in my plans and decisions?

Yes                           No                           Will do

5. Do I treat my family members the way I treat my best friends?

Yes                           No                           Will do

6. Do I set  good examples for others to follow?

Yes                           No                           Will do

7. Do I display affection towards other members of my family?

Yes                           No                           Will do

8. Do I spend time each day talking to my parents/siblings?

Yes                           No                           Will do

9. Do I apologise when I am wrong?

Yes                           No                           Will do

10. Do I show respect to all members of my family (including those younger than me)?

Yes                           No                           Will do

## 3. Ways to cope with the challenges for building strong family relationships

Building and maintaining strong family relationships with all family members is not always easy. All families face difficult times and misunderstandings can occur. Communication and problem solving are two ways to cope with the challenges of building and maintaining strong family relationships.

## 1. Communication

It is important to listen to each other. This helps members to feel understood, respected and valued thus strengthening family relationships. Relationships can be weakened by negative comments or criticisms. This occurs when family members do not listen to each other and speak in a disrespectful manner.

<!-- image -->

## MORE TO KNOW

Not all communication take place in the form of words. Pay attention to the feelings that are expressed non-verbally. For example hugs, kisses, high-five, clapping and eye contact.

<!-- image -->

Another  important  aspect  of  good  communication  which  helps in  building  strong  family  relationships  is  to apologise .  Mistakes happen but saying ' I am sorry '  makes a huge difference. This means assuming responsibility of one's behaviour and giving assurance not to repeat the mistake.

<!-- image -->

Design a card to say ' SORRY' to your parents/or any other family member for a mistake you made.

Your card should include a 'promise' for not making the mistake again.

## 2. Problem solving

Building positive family relationships does not mean having no problems. Dealing with problems positively, helps to build strong family bonds.

In this image we can see a group of people. In the background there are trees.

<!-- image -->

1    Identify the problem that needs to be solved.

- 2    Listen to everyone's views.
- 3    Come up with a range of options or alternatives.
- 4    Choose and reach a family agreement for a solution or a plan of action.

5    Try out the solution /plan of action.

6    Check how the solution has worked.

7    Review and amend the solution if needed.

The problem-solving process

<!-- image -->

Use the problem-solving approach to address the issues below:

## Case Study 1

There is a religious ceremony at home and on the same day you had planned to attend your friend's birthday party.

## Case Study 2

You want to opt for technical subjects at Grade 10 but your parents are insisting that you opt for languages.

## 3. Strengthening family relationships

Strong family relationships are not automatically created. They need time and effort from all family members. Strong family relationships help its members to feel secure and loved. You can strengthen your family relationships by:

- giving your time
- building family teamwork
- talking and listening to each other
- showing appreciation with warm loving words or gestures

In this image we can see a group of people standing on the water.

<!-- image -->

## TOPIC 2: Family and Technology

## Learning Objectives

## By the end of this topic, you will be able to:

- Discuss the positive and negative impact of technology on family life.

## 1. Introduction

Technology  has  transformed  our  everyday  living.  Mobile  phones,  internet,  smart  television, security systems and cooking appliances are a few examples of how technology is present in our homes. Technology has both a positive and negative impact on the family life.

In this image, we can see a collage of different images. We can also see some text and some icons.

<!-- image -->

<!-- image -->

## Work in groups.

Make a list of the technological devices that you and your family use. Share your findings with the whole class.

## 2. Positive impact of Technology on family life

Facilitates communication: Skype, video chats, Whats App.

Saves time and energy: E-shopping, online booking, use of labour saving appliances (electric mixer, microwave oven, pressure cooker).

In this image we can see a group of people.

<!-- image -->

Ensures safety: Alarms, automatic timer in all devices , home surveilllance and sensors,video cam,instant notification in case of fire and gas leakage.

Positive impact of  Technology

Provides entertainment: home cinema, music, games, hobbies (cookery classes,craft) .

Promotes learning opportunities: Information is easily available for e.g. E-books, learning apps, online lessons.

<!-- image -->

## Discuss the positive impact of technology on family life

Example: How technology help family members to be connected? Give examples to support your point.

## Work in groups.

Students are encouraged to give examples from real life experiences.

## Present your work to the whole class.

## NOTE TO EDUCATORS

Allocate each group one positive impact from the above chart. Ask the group to discuss and come up with examples to illustrate how technology has a positive impact on their family.

## 3. Negative impact of technology on family life

Separation: Isolation of family members, too much screen time, poor face to face interactions.

Dangers /risks: Internet predators, harmful games, problems with the law, poor maintenance of appliances leading to electrocution.

In this image we can see a person wearing a watch and hand on his hand.

<!-- image -->

## Addiction/dependency:

Negative impact of Technology

Games, chatting, taking selfies lead to health issues and poor performance at  school. Becoming too dependent on technological appliances may  lead to  family dysfunction ( e.g. in case of breakdown of the appliance and power cut) .

Limited outdoor activities: Laziness, sedentary lifestyle leading to health issues.

<!-- image -->

Technology addiction: involves the obsessive use of mobile devices, internet or video games, despite negative consequences to the user of the technology. The disorder may also be referred to as digital addiction or internet addiction .

Harmful internet games: social media games which challenge its players to also participate in a series of levels which are detrimental to their health and well-being. Internet predator: a person who uses the internet to locate and trap his intended prey, especially children.

<!-- image -->

## MORE TO KNOW

Gaming  addiction: It  is  classified  as  a disorder by World  Health  Organization (WHO). Gaming addiction has been listed as a mental health condition for the first time by the WHO. Its 11 th International Classification of Diseases includes the condition 'gaming disorder' .

<!-- image -->

## FIND OUT MORE

Gaming addiction https://www.who.int/features/qa/gaming-disorder/en/

https://www.webmd.com/mental-health/addiction/news/20180620/who-recognizesgaming-disorder-as-a-condition

<!-- image -->

## ACTIVITY 3: NEGATIVE IMPACTS OF TECHNOLOGY ON FAMILY LIFE

Discuss the negative impact of technology on family life

Example: How technology can cause addiction and how this affects the family? Give examples to support your point.

Work in groups.

Students are encouraged to give examples from real life experiences.

## Present your work to the whole class.

## NOTE TO EDUCATORS

Allocate each group one negative impact of using technology. Ask the group to discuss and come up with examples to illustrate how technology has a negative impact on the family.

<!-- image -->

1. Give two reasons why strong family relationships are important.
2. List four ways to build strong family relationships.
3. Define the term 'family goals' .
4. Give two examples of family goals.
5. Write down the steps for the Problem Solving Process.
6. Give four examples of how technology is used in the home.
7. Give four positive and four negative impact of technology on family life.

## Consumer awareness

## TOPIC: Reading and Interpreting Labels

## Learning Objectives

## At the end of this unit, you will be able to:

- Analyse and interpret information found on labels and manuals.
- Recognize the importance of caring for textiles.

## 1. Introduction

Labels provide useful information to the consumer about a particular product.

Product labels include:

## Labels

Food labels

The image is a food product label for a product called "Chocolate Chip." The label is primarily in white and blue colors, with the product's name prominently displayed in red and blue. The label is divided into two main sections: the top section contains the product's nutritional information, and the bottom section contains the product's ingredients.

### Nutritional Information:
- **Chocolate Chip**: The label states that the product contains 8g of chocolate chips, which is a common ingredient in chocolate chip cookies.
- **Total Calories**: The total calories are 230, which is a significant number, indicating that the product contains a substantial amount of calories.
- **Sodium**: The sodium content is 5mg, which is a relatively low amount compared to other common sodium-containing foods.
- **Sugars**: The sugars are 14g, which is a moderate amount, indicating that the product is a good source of carbohydrates.
-

<!-- image -->

In this image we can see a paper with some text and symbols on it.

<!-- image -->

Care labels (for clothing)

The smart consumer should always read and interprete the information found on labels.

## Importance of reading labels

Labels help consumers to:

- learn more about the products.
- make wise decisions towards choosing the  products which best suit their needs.
- make healthy food choices.
- know how to care for textile items/clothing and equipment.

## 2. Food Label

A food label is found on the packaging of a food item. It is an important communication tool between the consumers and the food manufacturers .

## Reading and Interpreting Food labels

| Information           | Meaning                                                                                                                                                                                                                                                                                                                                                       |
|-----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Product name          | The name of the product and/or a brief description of the product (e.g tomato puree).                                                                                                                                                                                                                                                                         |
| Ingredient list       | The list of ingredients that the food contains. Ingredients are listed, from the highest to the least quantity. It also includes the list of food additives present. It is the most important information for someone with'food restrictions' (See ' More to know ').                                                                                         |
| Nutrition information | Abreakdownofthenutritional content of the food, most often per 100 g or 100 ml.                                                                                                                                                                                                                                                                               |
| Net weight and volume | The actual weight and volume of the product without the packaging.                                                                                                                                                                                                                                                                                            |
| Serving/ portion size | The average serving size of the product, according to the food manufacturer. It is often expressed in terms of grams, millilitres, cups, spoons, slices or pieces.                                                                                                                                                                                            |
| Date marking          | • The manufacturing date and the expiry date of the food. These inform consumers until when the product can be consumed. • Date of manufacture: The date the food has been manufactured. • 'Sell by': last day to sell fresh foods. • 'Use by' date: howlongthefoodwill be at its best for consumption. • Expiry date: last day for safe consumption of food. |
| Instruction for use   | Provides step by step instructions to the consumer of how to prepare the product.                                                                                                                                                                                                                                                                             |
| Storage instructions  | Instructionstoensurethatfoodissafe,e.g:'keeprefrigerated' ,'refrigerate once opened', 'once opened, use within 3 days' or 'store in a cool, dark place' .                                                                                                                                                                                                     |

<!-- image -->

## MORE TO KNOW

Food restrictions means that there are certain types of food which people do not consume for different reasons.

These are as follows:

- Health : The person is on a low sugar diet as he/she is diabetic or the person is on low salt diet due to  high blood pressure.
- Allergy : The person is allergic to a particular food. The most common food allergies are peanuts, tree nuts (such as walnuts, almonds), fish, shellfish, milk, eggs, soy products and wheat.
- Culture/ethnic .

Note: Food additives are substances that are added to food to maintain or improve its freshness as well as taste, texture and appearance.

## Additional information found on  a food label

- No added sugar: no sugar is added to the product during production. The product could still be naturally high in sugar, e.g. fruit juice or dried fruit.
- Do not use any food or drink after the ' use by '  date on the label, even if it looks and smells fine, as it could put your health at risk.
- Gluten-Free: the product excludes the protein gluten which is found in grains such as wheat, barley or rye.
- Lactose-Free: indicates that the product is free from lactose. Lactose is the sugar that is found naturally in milk and milk products, as well as in foods with ingredients such as milk.

<!-- image -->

## ACTIVITY 1: READING AND INTERPRETING LABEL

Materials required:

'Food labels' .

Collect and bring samples of labels from different food items that you find at your place.

In pairs or in small groups, list the information you can find on the food labels.

## NOTE TO EDUCATORS

Allocate a food label to each group. Food labels can be from canned foods (e.g: canned maize, canned tuna) , packaged foods (e.g: biscuits, cheese) or liquid foods (e.g: juice, milk, tomato/chilli sauce).

You may use the table below to note down your findings:

| Product :   | Product :   |
|-------------|-------------|
| Information | Meaning     |

## 3. Caring for textiles and clothing

It is important to learn how to care for textiles and clothing as they pick up dirt and stains during everyday use. Dirt and stains may come from soil, grease, food and vegetation. Soiled textiles (e.g. furnishing fabrics and household textiles) and clothes can harbour microorganisms and can lead to skin infections. Consequently, textiles and clothing should be given proper care.

## Importance of caring for textiles and clothing

Caring for textiles and clothing will:

- help them last longer
- save money
- enhance one's appearance
- help to be hygienic

## General care of textiles and clothing

Proper care of textiles and clothing include:

- frequent airing, laundering or dry cleaning.
- immediate repair and mending when damaged (e.g. torn fabric/hem, split seams, frayed buttonholes, securing loose fastenings)
- removing stains before washing or further use.
- right interpretation of care labels.
- proper ironing or pressing.

## 4. Care label

Most ready-made garments/textile items have a care label sewn on them.

A care label is a set of instructions provided to consumers about how to  care  for  garments/textile  items. The  International  Care  Labelling Company uses symbols to make the instructions user friendly so that garments/textile items are not spoilt by incorrect washing and ironing.

Being familiar with the following care symbols will help to care for garments/textile items in a proper way.

<!-- image -->

## 5. Care symbols

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|     | Washing                    | Drying                       |
|-----|----------------------------|------------------------------|
|     | Handwash                   | Tumble drying                |
| 300 | Wash at 30 0 C             | Do not tumble dry            |
|     | Do not wash                | Dry flat                     |
|     | Bleaching                  | Dry in the shade             |
| CL  | Use chlorine bleach        | Ironing                      |
|     | Do not bleach              | Iron at low temperature      |
|     | Dry cleaning               | Iron at moderate temperature |
| A   | Dry clean with any solvent | Iron at high temperature     |
|     | Do not dry clean           | Do not iron                  |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## KEY TERMS

Solvent: A solvent is a chemical solution which is used to remove stains.

<!-- image -->

ACTIVITY 2: READING A CARE LABEL

Study the label which is found on a garment.

In small groups, identify the care symbols on the care label provided. Record your answers in the table below:

<!-- image -->

Explain how you will care for the garment.

## 6. Product Manuals

Manuals  help  consumers  to  understand  the  products  and/or  services  bought. They  always accompany electrical appliances (e.g: refrigerator, oven, sewing machine, iron) .  Without a  manual, it is very difficult to understand how to operate  the product.

In this image, we can see a poster with some text and images.

<!-- image -->

In this image there is a table with some text on it.

<!-- image -->

In this image we can see a sewing machine and a text on it.

<!-- image -->

Manuals can also be known as product manuals, manufacturer's manual, operation manual or service manual. Manuals provide important information on 'how to use the product' to endusers. The table below shows the information that are commonly found in manuals.

<!-- image -->

| Information               | Description                                                                                                                                                                                                                                                                              |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Brand name                | Helps consumers to identify the same product in different makes.                                                                                                                                                                                                                         |
| Product                   | Gives the name of the product e.g, steam iron, refrigerator, electric sewing machine.                                                                                                                                                                                                    |
| Product specifications    | State the model, weight, dimension, voltage required and accessories.                                                                                                                                                                                                                    |
| Nameandfunctions of parts | Give a full description of the product parts and its corresponding function.                                                                                                                                                                                                             |
| Operating instructions    | Provide a step by step guide of how to use the product correctly.                                                                                                                                                                                                                        |
| Safety instructions       | Include the following: • Safety mark symbol • Voltage requirements • Installation and positioning of product • Instructions before using for the first time • Warning advice such as'keep out of reach of children' • Precautions to adopt to keep the product in good working condition |
| Cleaning and maintenance  | Provides step by step instructions of how to clean and maintain the product in good working condition.                                                                                                                                                                                   |

<!-- image -->

If a manual has been misplaced, it can be easily accessed online and downloaded.

<!-- image -->

Material required:

Product manuals.

Collect and bring any product manual which you have at home.

## NOTE TO EDUCATORS

Allocate a product manual to each group. Product manuals for ovens, sewing machines, irons, refrigerators, blenders and mixers can be used.

## Work in groups.

List  and describe the information that can be found on the manual. You may use the table below to note your findings.

<!-- image -->

1. State three reasons why it is important to read labels.
2. Study the food label provided below.  Answer the questions below:
- a) Name the product.
- b) Is the product suitable for a person who is trying to reduce his salt intake?
- c) What is the net weight of the product?
- d) Where was the product manufactured?
3. Sometimes sugar and fat are listed on the ingredients list under other names. Find out the other names used.
4. Explain why it is important to care for household furnishings and one's clothes?
5. Draw the following care symbols:
- a) Wash at 30 0 C.
- b) Iron with hot temperature.
- c) Do not tumble dry.
- d) Dry cleaning.
- e) Do not bleach.
6. Explain why a manufacturer's manual is very important when buying a home appliance.

In this image we can see a food packet.

<!-- image -->

## Textile Technology

## TOPIC 1: Fabric constructions, their performance characteristics and end-uses

## Learning Objectives

## At the end of this unit, you will be able to:

- Relate fabric construction to performance characteristics and end-uses of textile fibres:
- Differentiate among the three main fabric construction techniques.
- List fabrics' performance characteristics related to fabric construction and their end-uses.

## 1. Introduction

Fibres are converted into yarns. Yarns are then used to make fabrics. Both fibres and yarns can be used to construct fabrics. There are three main fabric construction techniques, namely: weaving , knitting and felting .

## Fabric construction techniques

GRADE

In this image we can see a machine, there are some objects, there are some objects, there are some objects, there is a machine, there is a machine, there are some objects, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there is a machine, there

<!-- image -->

## 2. Weaving

Woven fabrics are made up of two sets of yarns: the warp and the weft yarns. Warp yarns run lengthwise in the fabric while weft  yarns  run  across  the  width  of  the fabric.

Warp  yarns  are  stronger  than  the  weft yarns and are also known as the straight grain.

Weft yarns are interlaced over and under the  warp  yarns  alternately,  creating  a structure known as weaving .

The  two  narrow  finished  edges  of  a woven fabric are referred to as selvedges .

<!-- image -->

## KEY TERMS

## Straight grain

The straight grain of a fabric runs parallel to the selvedges.  The selvedges of a fabric do not fray but  the  raw  edges  have  a  tendency  to  unravel (fray) easily.

In this image there is a graph. On the graph there are numbers. At the bottom there is a text.

<!-- image -->

The image is a diagram showing the width of a fabric roll. The diagram is divided into two parts. The top part of the diagram is labeled as "length of fabric" and the bottom part is labeled as "length of straight grain". 

### Diagram Description:

#### Top Part:
- **Label:** Length of fabric
- **Description:** The length of fabric is shown as a vertical line extending from the top of the image to the bottom.
- **Color:** The length of fabric is shown in orange.

#### Bottom Part:
- **Label:** Length of straight grain
- **Description:** The length of straight grain is shown as a horizontal line extending from the bottom of the image to the top.
- **Color:** The length of straight grain is shown in orange.

### Analysis:

#### Length of Fabric:
- **Description:** The length of fabric is shown as a vertical line extending from the top of the image to

<!-- image -->

<!-- image -->

## REMEMBER

- The performance characteristics of  textile  fibres  relate to the qualities or properties that the fibres have.
- End use relates to the final use of the textile item.

## Woven fabrics: performance characteristics and end-uses

## Woven fabrics

While observing a woven fabric, it can be noticed that the weft (horizontal) yarns pass over and under each warp (vertical) yarns.

Woven fabrics fray easily.

Example: Calico

Example: Denim

<!-- image -->

<!-- image -->

<!-- image -->

## Performance characteristics

Woven fabrics are usually stable which make them strong and suitable for many household items as well as for garments.

Woven fabrics are easy to care for.

## End-Uses

Household and furnishings: curtains, bedcovers, tablecloths and pillow cases.

Clothes and accessories: dresses, Jeans, banners and accessories.

<!-- image -->

<!-- image -->

<!-- image -->

## MORE TO KNOW

Did you know that you can create your own woven fabric using woollen yarns and a piece of cardboard?

## Create your own woven fabric sample by following those simple steps:

1. Cut a cardboard of size 15x15 cm.
2. Notch  two  opposite  ends  of  the  cardboard  at  1  cm  interval  along  the  edge  of  the cardboard.
3. Wrap one colour of woollen yarn around the cardboard by passing it in between each notch.  This will be referred as the warp yarns.
4. Thread another coloured woollen yarn in a tapestry needle. Pass the yarn over and under each warp yarn. This yarn will represent the weft yarns.
5. Continue the second row by passing the needle under and over the warp yarns.
6. Repeat steps 4 &amp; 5 until you obtain a  woven  piece  of  fabric!  You  can change colours of yarns after working several rows.

The image is a folded piece of cloth. The cloth is made up of multiple colors, which are arranged in a horizontal pattern. The colors are blue, green, purple, and pink. The folds in the cloth are visible, and the folds are arranged in a horizontal pattern. The cloth appears to be made of a woven material, which is a type of fabric that is woven together with threads. The background of the image is white, which helps to make the colors stand out clearly.

### Description of Objects in the Image:
1. **Cloth**: The cloth is folded in a way that it appears to be folded in half.
2. **Color Scheme**: The colors of the cloth are blue, green, purple, and pink.
3. **Pattern**: The pattern on the cloth is a horizontal pattern.
4. **Folded Pattern**: The folds in the cloth are visible, and the folds are arranged in a horizontal pattern.
5. **Background

<!-- image -->

## 3. Knitting

Knitted fabrics are manufactured(knitting process) by using a single continuous yarn to make loops which are interlocked together in horizontal rows, thus creating a knitted structure.

In this image we can see a person's hand holding a knitting needle and a red color yarn.

<!-- image -->

<!-- image -->

## Knitted fabrics: performance characteristics and end-uses

## Knitted fabrics

Upon examining the loops of a knitted fabric, it can be seen that the loops are connected to one another in rows. They can easily distort out of shape (snag) and can unravel.

Example: Jersey

## Example: Rib knit

<!-- image -->

<!-- image -->

<!-- image -->

## Performance characteristics

Knitted fabrics are elastic , thus making them very comfortable to wear as they allow for body movements.

Knitted fabrics provide warmth when worn.

## End-Uses

Jersey fabrics: T-shirt, dresses, underwears, tops and leggings

Rib knit fabrics: Pullovers, cardigans and socks.

<!-- image -->

<!-- image -->

In this image we can see a collage of different clothes.

<!-- image -->

## KEY TERMS

Unravel: To separate out knitted or woven yarns from a fabric.

<!-- image -->

<!-- image -->

<!-- image -->

## ACTIVITY 1: KNITS AND THEIR PERFORMANCE CHARACTERISTICS

Materials: Knitted garments (for example a pair of socks, a tracksuit or a pullover) and a magnifying glass.

- Observe the fabric structure of the knitted garments with the help of a magnifying glass.
- Draw your observations in your copybook.
- Discuss why the fabric is suitable for the purpose intended.

<!-- image -->

## MORE TO KNOW

Knitting  was  first  done  manually  using  two  long needles. Hand knitting is considered as a craft activity and  hobby.  For  some  people  it  is  their  source  of income by knitting clothes for babies and adults.

<!-- image -->

## 4. Felting

Unlike woven and knitted fabrics, no yarns are used to make felt fabrics.  Felts can be made from short, recycled waste fibres (e.g. wool and acrylic) .  Felt  fabrics  are  produced by adding moisture,  pressure  and  heat  to  a  web  of  fibres, (felting  process) causing  them  to  matt  and interlock together.

## Felt fabrics: their performance characteristics and end-uses

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Felt fabric                                                                                                                                                | Performancecharacteristics                                                                                    | End-Uses                                                                                                                     |
|------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
| Felt fabric is different from woven and knitted fabrics. No yarns can be seen in the fabric structure. Felt fabrics do not fray. Woollen felt Acrylic felt | Felt is an excellent insulator for both temperature (warmth) and sound. Felt can shrink . It is not elastic . | Tablet cases, puppets, hats and boots, pool table covers Felt is also used on items such as vases, picture frames and lamps. |

Since felt does not fray, it is suitable for a wide range of crafts. Felt is often used for decorative purposes but are not suitable for making garments.

Another purpose of felt fabric is to make winter hats as they can be shaped easily and they also provide warmth.

<!-- image -->

The way in which a fabric is constructed affects the structure and the performance characteristics of the fabric. This will eventually determine the end-use of the fabric.

Summary of performance characteristics of in relation to fabric construction are as follows:

<!-- image -->

Woven  fabrics  are  stable  which  makes  them  strong  and suitable to be worn regularly. They are easy to care for.

<!-- image -->

<!-- image -->

Knitted fabrics provide warmth when worn. They are elastic.

Felt  fabrics  provide  warmth.  However,  they  are  not  strong and can shrink.

<!-- image -->

REMEMBER

- The performance characteristics of a fabric are what make it suitable for its purpose.

<!-- image -->

## 1. End-uses of woven, knitted and felt fabrics.

Complete the table by listing items made from woven, knitted and felt fabrics. Two examples of each have been provided:

## Fabric construction techniques

|          | Weaving                                                          | Knitting                                                       | Felting                                            |
|----------|------------------------------------------------------------------|----------------------------------------------------------------|----------------------------------------------------|
| End-uses | Handkerchief Kitchen towel __________________ __________________ | T-shirt Gloves __________________ __________________ Hats Pool | table covers __________________ __________________ |

2. Fill in the blanks with an appropriate word provided below:

strong      loops      yarns      hats      selvedges      boots

- (i).   Fabrics are made from \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ which are made from fibres.
- (ii). The narrow borders of woven fabrics are known as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

(iii). Knitted fabrics consist of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ which are interlooped together.

(iv). Felt fabrics are not \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and thus are not used to make garments.

However they provide warmth and are used to make \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- 3a). State which performance characteristics make the following textile items  suitable for its end-use:
- (i) towel
- (ii)  school bag
- (iii) pullover
- (iv) hat
- b). Give two reasons to support the answers given in 3(a) for each textile item.

## TOPIC 2: Fabric finishes and their related end-uses

## Learning Objectives

## At the end of this unit, you will be able to:

- Relate fabric finishes to performance characteristics and end-uses of textile fibres.

## 1. Introduction

Once fabrics have been constructed, they go through another process which add value and give them certain desirable properties. This process is referred to as the fabric finish . Hence, as a result of going through the finishing process, fabrics can become very soft to the touch. Some fabrics can obtain a shiny appearance whilst others can be given a finish to resist water penetration to a certain extent.

Fabric finishes aim at improving existing properties of fabrics to make them more:

- suitable for their intended end-use (functionality)
- acceptable to the consumer (feel, final appearance)

Finishes that are applied to fabrics can be categorised as follows:

In this image, we can see a diagram with some text and a few lines.

<!-- image -->

Hence, the main reasons to apply finishes to fabrics are to improve:

- their appearance
- their handle (feel)
- the performance of the fabrics
- their insulating properties, for example, by providing increased warmth

## 2. Application of fabric finishes

## Brushing

Brushing is a finish whereby wire rollers brush the surface of the fabric making it fuzzy and very soft. This makes the fabric warmer.

Brushed fabric (raised surface)

<!-- image -->

<!-- image -->

Pyjama made from flannel fabric

## Crease-resistant

Fabrics which have been given a crease-resistant finish will crease very little or not at all during wear.  A  crease-resistant  finish  is  mainly  applied  to  shirts,  dresses,  trousers,  suits  and  office uniforms.

## Flame-proofing/retardant

Yarns or fabrics are treated with chemicals to make them  less  flammable.  A  flame-retardant  finish  is usually applied to children's garments, nightwears, bedsheets,  toys,  curtains,  firemen's  uniforms  or upholstery materials for safety purposes.

In this image we can see a cloth hanging on a rope. There are two candles on the cloth.

<!-- image -->

## Water-proofing

Chemicals are applied to fabrics to make them impermeable to liquids.  Water droplets will thus remain on  the  surface  of  the  waterproofed  fabric  rather  than being absorbed by it.

Items that are commonly given water-proof finishes are tablecloths,  raincoats,  umbrellas,  shoes,  gloves,  jackets, pants and school bags.

In this image we can see a watermark.

<!-- image -->

<!-- image -->

## MORE TO KNOW

- Starching or resin-coated yarns add stiffness to a fabric.
- For  example,  napkins  appear  neat  and  give  a  good  finish  when  starched.  Starched napkins are often used in restaurants and in hotels.
- Another example where starching is used is on shirts' collars.

<!-- image -->

## RESEARCH WORK: Starching a garment

## Tips to starch your shirts like a pro

<!-- image -->

<!-- image -->

Shirt must be made of a woven fabric

- like cotton or linen. 1
- Dip shirt in starch solution. Do not use a spray. 2

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Hang dry.

Iron shirt while still damp.

<!-- image -->

Find out the difference between a starched and an un-starched textile item that you have at home.

<!-- image -->

Conduct a research to find out about other common fabric finishes such as:

- (i) moth-proofing finish
- (ii) anti-bacterial finish
- Why are these finishes applied to fabrics?
- To which items are these finishes commonly applied?

<!-- image -->

## EXERCISES

1. Explain the term 'fabric finishes'?
2. Name the two types of finishes commonly given to fabrics.
3. State two reasons why finishes are given to fabrics.
4. Name and describe two fabric finishes.
5. Outline why is it important to apply a flame-retardant finish to children's clothes and toys?

## TOPIC 3: Smart and Modern fabrics

## Learning Objectives

## At the end of this unit, you will be able to:

- Differentiate between smart and modern fabrics.
- List common uses of smart and modern fabrics.

## 1. Introduction

The textile field is always coming up with new fibre and fabric innovations to improve our daily life and to satisfy the needs of consumers. Recent developments in textiles have brought about the introduction of smart and modern fabrics .  Smart and modern fabrics are manufactured for specific uses such as sportswear, medical and safety materials and for fashionable clothing.

## 2. Smart fabrics

Smart fabrics can sense , react and adapt to the environment or conditions in which they are exposed to, for example, to heat , moisture and light .  Smart fabrics can revert back to their original state.

## Heat - The fabric reacts to heat .

For example:

- Ski suits react to body temperature and can increase their insulating properties to make it warmer.
- Thermal clothing such as two-piece underwear (long johns) with long legs and long sleeves are worn during cold weather to keep the body warm.

Moisture - The fabric changes colour when it becomes moist . For example:

- Indicators in disposable nappies change colour when they are wet.

## Light - The fabrics respond to light conditions by changing colour.

For example:

- Military uniforms adapt to the environment they are exposed to, thus helping for camouflage purposes.

In this image we can see a person standing and wearing a jacket, cap and gloves. In the background there is a poster.

<!-- image -->

Other smart fabrics are available, for example:

- UV  fabrics: the  fabric  protects  against  UV (ultra  violet) sunrays, e.g. swimming suits.
- Smart  skins/intelligent textiles: Built-in  computers  or optional  sensors  detect  changes  such  as  pressure  and temperature.
- Medical textiles: Pillows and mattresses that respond and mould to the shape of the consumer.
- Reflective  textiles: They  are  used  for  enhanced  safety  in cycling, for pedestrians walking at night and for sportswear amongst others.
- Micro-encapsulated textiles: Some leggings can be micro-encapsulated to help people lose weight.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a person wearing a bag and holding a bottle. We can also see some text and a picture of a person.

<!-- image -->

Micro-encapsulation technology is a smart technology where liquid and/or solid substances required by the body are inserted for a specific purpose (e.g.  medications, aromes/perfumes, chemicals and mosquito repellents) in micro-bubbles.

These are then slowly released from the fabric to be absorbed by the skin.

## 3. Modern fabrics

Modern fabrics have been developed through the invention of new and improved processes. They have special properties and are manufactured to perform a particular function.  Examples of modern fabrics are Kevlar and Nomex . The properties and uses of each one of them are given below:

Kevlar is  a  lightweight  fibre  and  is five times  stronger  than  steel  but  is  quite flexible.

It has very good resistance against abrasion, chemicals and flame. It can also resist rust.

## Uses of Kevlar fabrics

To  make  sails,  parachutes,  bulletproof vests, building materials, underwater cables and aeroplane wings.

In this image we can see a person standing on the boat, there is a kite, there is a boat, there is a water, there is a sky, there is a mountain, there is a mountain, there is a boat, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water, there is a boat on the water,

<!-- image -->

Nomex is  a  very  light  and  very  strong fibre.  It  can  resist  very  high  heat  and flame.

## Uses of  Nomex fabrics

To make uniforms for firemen; gloves for racing-car drivers and astronauts.

In this image we can see a person wearing a suit and a helmet.

<!-- image -->

## 4. New advancements

Modern materials also include the synthetic fibre, Elastane, which is commonly referred to as Lycra or Spandex . It is durable, stretchable, resistant to tear and are easy to care for.  They are widely used in the making of sportswear, swimwear and underwear.

Gore-Tex is another example of a modern fabric.  It is a breathable, waterproof and windproof. It is widely used for outdoor sportswear and to make clothing which can withstand extreme weather conditions.

## |   Unit 6 - Textile Technology

96

<!-- image -->

1. Fill in the blanks with an appropriate word provided below:

## kevlar      waterproof      smart      properties modern      light      breathable

- a) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ fabrics  that  respond  to  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  and  changes  colour

according to their environment.

b)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ fabrics have special \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and are manufactured to perform a particular function.

c)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is a modern fabric which has excellent resistance against chemicals and flame.

- d) In extreme

weather conditions,

Gore-Tex fabrics

are used

because they

are

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ , \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and windproof making them suitable for their purpose.

2. Copy and fill the table below in your copybook. State whether each statement is True or False by putting a tick in the appropriate box. Justify your answer if the statements are False.

|     | Statements                                                                                                      | True   | False   | Justification   |
|-----|-----------------------------------------------------------------------------------------------------------------|--------|---------|-----------------|
| (a) | Smart textiles can sense, react and adapt to the environment in which they are exposed to.                      |        |         |                 |
| (b) | Fabricsthatareimpregnatedwithmicroscopic bubbles of perfumes are known as micro- encapsulated fabrics.          |        |         |                 |
| (c) | Lycra is an example of a smart fabric used to make mattresses.                                                  |        |         |                 |
| (d) | Modern fabrics include reflective fabrics used to enhance the safety of motorcyclists and pedestrians at night. |        |         |                 |

## Fashion Sense

## TOPIC 1: Elements of Fashion Design

## Learning Objectives

## At the end of this unit, you will be able to:

- Demonstrate an understanding of the nature of fashion design.
- Apply basic elements of fashion design when creating textile items.

## 1. Introduction

Selecting the right clothes to enhance one's appearance requires wise decisions. A knowledge of  the  basic  elements  of  fashion  design  is  helpful  when  choosing  clothing.  The  four  basic elements of fashion design are:

In the image we can see there is a chart. In the chart we can see few things.

<!-- image -->

Colour and texture have a major influence on one's clothing choice.

The colour wheel guides consumers to understand how colours can be matched and how they work best with each other. People can also enhance their appearance by choosing the right colour combinations for their clothes.

Texture refers to the appearance and feel (smooth/ rough) of the surface of a fabric. The texture of fabrics have an influence on the garment's overall aspect.

## 2. Lines

Lines refer to an elongated mark that connects two or more points.

There are two types of 'lines' in fashion. These are:

- Structural lines
- Decorative lines

## Structural lines

Structural lines are created when sewing a garment.

Seams in garments, for example, are known as structural lines.

## Decorative lines

Decorative lines are  printed lines found on a fabric.

They create visual effects. They are also known as stripes.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## MORE TO KNOW

Fabrics are available in a variety of prints and designs. Some common examples are illustrated below:

One way

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

All over

Border

Checks

<!-- image -->

<!-- image -->

Stripe

<!-- image -->

Dots

The arrangement of lines in clothing is important as they can influence the overall appearance of the wearer, for example, they can make the wearer appear taller, shorter, slimmer or wider. Lines have directions.  They can be vertical, horizontal or diagonal.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                                                                                             | Structural lines   | Decorative lines   |
|-----------------------------------------------------------------------------------------------------------------------------|--------------------|--------------------|
| Vertical lines go up and down along a garment. They give the impression of height and slimness.                             |                    |                    |
| Horizontal lines lead the eye across the garment from oneside to the other.They give the impression of width and shortness. |                    |                    |
| Diagonal lines are slanted lines found on a garment. They give an elegant impression.                                       |                    |                    |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## REMEMBER

## Body Shape

Body comes in all sizes and shapes. Each person is unique and has a different body shape. It is important to know the body shape as it helps to determine what looks best on the wearer.

Body shapes can be categorised as illustrated below:

<!-- image -->

Rectangle

<!-- image -->

<!-- image -->

<!-- image -->

Inverted triangle

Triangle

Round

Rectangle

<!-- image -->

Hourglass

<!-- image -->

Inverted triangle

Triangle

<!-- image -->

Round

<!-- image -->

## 3. Silhouettes

The term 'silhouette' refers to the overall shape of garments. The silhouette of a garment can reveal or hide the natural contour of the body. Understanding different silhouettes can help to choose the appropriate garments which will suit one's body shape, thus helping to enhance one's appearance.

In the 'A' line silhouette, the lower part of the garment is  larger  in  proportion  compared  to  the  upper  part (chest and waist) , thus giving the classic 'A' appearance. The A-Line silhouette works well for most body shapes since it is not fitted closely to the body.

<!-- image -->

<!-- image -->

Tubular silhouette is a popular shape for both women's and men's fashion and can  have a slimming effect. It does not cling to the body and comes straight down without any flares. It is ideal for round body shapes.

Wedge silhouette fits both women's and men's fashion. The  garment  is  wider  at  the  top  than  at  the  bottom making  shoulders appear broader. It is ideal for triangular body shapes.

<!-- image -->

<!-- image -->

<!-- image -->

Colour,  texture,  lines  and  silhouette  are  the  four basic  elements  of  fashion  design  that  can  be applied to textile items.

The  bag  and  the  hat  illustrate  how  elements  of fashion design can be combined and integrated,

<!-- image -->

<!-- image -->

for example, colour, texture and lines can be combined for an overall appealing fashion item.

<!-- image -->

## ACTIVITY 1: SILHOUETTE OF GARMENTS

Identify the different silhouettes. Collect and stick pictures illustrating the silhouette in the corresponding column.

## Silhouette

## Name of Silhouette

## Picture

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

101

102

## TOPIC 2: Fashion Trends

## Learning Objectives

## At the end of this unit, you will be able to:

- Demonstrate an understanding of the evolution of fashion trends.

## 1. Introduction

Fashion refers to what most people are wearing at a particular period of time. It  attracts  people's  interest  and  needs for change. Fashion is always based on style.  There  are  styles  that  repeatedly come and go out of fashion.

In this image we can see a collage of four people. The people are wearing different color dresses.

<!-- image -->

<!-- image -->

## KEY TERMS

Style can be defined as the specific features that distinguish  a  garment  from  another,  for  example,  a round neckline is a style and a V-neckline is another style.

<!-- image -->

## 2. Nature of fashion

Fashion is divided into two main categories namely:

- Haute Couture
- Prêt-a-Porter

Round neckline

<!-- image -->

Haute Couture refers to the creation of exclusive customfitted clothing. It is usually made from high-quality, expensive fabrics and sewn with extreme attention to details and  finishes.  They  are  time-consuming,  hand-executed techniques  such  as  embroidery,  lace  work  and  beadwork. These items are often referred to as 'designer' pieces.

Prêt-à-Porter or 'Ready to Wear' is the fashion design term for items of clothing which are sold in a finished condition (readymade), in standard clothing sizes. Prêt-à-Porter clothing are commonly available in most shops and are often produced in bulk.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## MORE TO KNOW

Fashion does not apply only to clothing.  It also refers to popular hairstyles, makeup, footwear, bags and jewelry amongst many other.

## 3. Fashion Trends

Fashion trend refers to a style that is popular at some point in time. It also refers to the direction in which fashion is moving. The garments which are from the trend are stitched in bulk.

## Examples of fashion trends:

Off-shoulders were popular in the 1960's. They came back in fashion as from 2017.

Leggings were popular in the 1960's. They were revived in the 1980's upto present days.

Ripped jeans were popular in the 1990's and 2000's. Now, it is back in fashion.

In this image we can see a girl standing and smiling.

<!-- image -->

In this image we can see a girl standing and holding a bag in her hand.

<!-- image -->

In this image we can see a man walking on the road. He is wearing blue shirt, blue jeans and brown bag.

<!-- image -->

Fashion trends are influenced by four main factors. These are:

- economical factors
- social (cinema, celebrities, media) factors
- cultural factors
- technological factors

## Economical factors

Some  fashion  items  are  made  from  very  good quality  materials  and  are  thus  costly.  Very  often people  who  are  financially  well  off  buy  these fashionable items. However, some of these designs are imitated on cheaper fabrics and are sold in mass in the market at affordable prices.

Jumpsuits were popular in the 1970's and revived in 2015.

<!-- image -->

In this image we can see a person wearing a coat and holding a bag. In the background we can see a person standing and holding a bag.

<!-- image -->

## Social factors

Continually changing lifestyles provide people with a variety of activities such as sports and leisure facilities. These  changes  have  led  to  a  whole  new  fashion industry in leisure and holiday wear.

The  entertainment  world  has  a  major  influence  on fashion. Designers specifically design outfits for celebrities to wear in movies, fashion shows, red carpet events, etc.  These outfits, when seen on celebrities, get the attention of the public and become popular.

## Cultural factors

Fashion is created by people living in different cultures,  different  countries  and  regions.  Designers and manufacturers produce clothing and accessories in accordance with the culture of a particular region. People  usually adopt  the  trend  in clothing  and accessories only if it is in accordance with the culture of the region/country they live in.

## Technological factors

New technologies are continually influencing fashion. Advances and new developments in fibres and fabrics, for  example,  smart  and  modern  fabrics  are  creating current and future trends. Some examples are interactive and intelligent fabric, Nomex and Kevlar.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a collage of two images. In the first image a man is standing and smiling. In the second image a woman is standing and smiling. In the background there is a building.

<!-- image -->

<!-- image -->

105

<!-- image -->

1. List the four basic elements of fashion.
2. State the importance of the basic elements of fashion design.
3. Fill in the blanks with the following words:
4. Explain what you understand by structural lines.
5. With the help of sketches, illustrate one example of:
6. (i) Vertical line
7. (ii) Diagonal line
6. Explain two factors that influence fashion trends.

style               silhouette               wider               tubular               taller               haute couture

- (i) Vertical lines make the wearer appears \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

- (ii) Horizontal lines make the wearer appears \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

- (iii) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ refers to the overall shape of garments.

- (iv) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ silhouette comes straight down without any flare.

- (v) Fashion trend refers to a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ that is popular at some point in time.

- (vi) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_refers to the creation of exclusive custom-fitted clothing.

## Design &amp; Creativity through Textiles

## TOPIC 1: Sewing and Pressing Equipment

## Learning Objectives

## At the end of this unit, you will be able to:

- Name the different types of sewing machines available.
- Identify the parts of an electric sewing machine.
- Use an electric sewing machine and the basic pressing equipment safely.

## 1. Introduction

GRADE Various sewing equipment are needed to make textile items.  In addition to small sewing tools, the sewing machine and the steam iron are also essential equipment required.

## 2. The sewing machine

The sewing machine is used for stitching fabrics together.  Machine stitching is much quicker than hand stitching.  Sewing machines offer a variety of machine stitches that can be used to enhance the appearance of garments and textile products.

## Types of sewing machines

Nowadays, there are different types of sewing machines available on the market. Examples are:

The domestic electric sewing machine

<!-- image -->

<!-- image -->

<!-- image -->

The computerized sewing machine (Embroidery sewing machine)

The overlock sewing machine

107

108

<!-- image -->

## DID YOU KNOW?

Previously, sewing machines were operated either by hand or with a foot pedal. These machines could only sew straight machine stitches.

<!-- image -->

Treadle sewing machine

<!-- image -->

Hand-sewing machine

## The electric sewing machine

The electric sewing machine is operated by using electricity and is used to sew different types of machine stitches. Before operating the electric sewing machine, it is important to know the different parts in order to use it properly.

## Parts of an electric sewing machine

Note: Depending upon the make of a sewing machine, some parts of a sewing machine may be positioned differently, but their basic functions remain the same.

In this image we can see a machine. There is a pipe, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle, a needle,

<!-- image -->

<!-- image -->

## ACTIVITY 1: GETTING ACCUSTOMED TO THE ELECTRIC SEWING MACHINE

With the help of your teacher, identify the main parts of the electric sewing machine available in your school.

## NOTE TO EDUCATORS

Labelled  tags  can  be  used  for  labelling  the  different  parts  of  an  electric  sewing  machine during explanation.

The electric sewing machine is mainly used for sewing straight and zig-zag machine stitches:

In this image we can see a sewing machine.

<!-- image -->

## Straight machine stitches

Straight sewing machine stitches resemble backstitches. They are usually used to sew two or more pieces of fabric together, e.g., when stitching a seam.

## Zig-zag machine stitches

Zig - zag machine stitches are often used  to  neaten  the  raw  edges  of seams.

<!-- image -->

## Using the electric sewing machine

The electric sewing machine needs to be threaded properly before starting to stitch (refer to appendix for threading of the electric sewing machine).

## SAFETY NOTE:

While using the electric sewing machine:

- hands should be dry when using the sewing machine to avoid electric shock.
- fingers should not be too close to the path of the sewing machine needle when sewing.
- do not lean too close to the electric sewing machine during stitching.
- always switch off the electric sewing machine after use.

## Starting to sew

Before you begin to sew, ensure that:

In this image, we can see a machine. There is a thread. We can see a needle. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread. We can see a thread

<!-- image -->

## Start stitching as follows:

3. Lower the presser foot gently and press the foot pedal slowly to start stitching.

In this image, we can see a sewing machine. There are some objects on the sewing machine.

<!-- image -->

## End stitching as follows:

1. Lift your foot from the foot pedal. Raise the presser foot and the needle to its highest position.
2. Pull the fabric and threads gently towards  the  back.  Cut  a  tail  of thread of about 10 cm.

<!-- image -->

In this image we can see a person's hand holding a pair of scissors.

<!-- image -->

111

112

<!-- image -->

## Instructions:

1. On a piece of A4 paper, draw the following line as shown in the diagram below:

Note: the sewing machine should not be threaded to carry out this activity.

In this image, we can see a diagram. There are two arrows. One arrow is pointing to the left and the other arrow is pointing to the right.

<!-- image -->

## Stitching around a corner

- Leave the needle in fabric at the corner.
- Raise the presser foot.
- Turn (pivot) the fabric at angle of 90 0 .
- Lower the presser foot.
- Continue machining.
- Repeat the process at each corner.
2. With the help of your teacher, use the electric sewing machine to sew along the sewing trail to familiarize yourself with the sewing machine available at your school.

The image consists of a diagram with a red circle and a line. The red circle is positioned at the top of the diagram and has a dotted line extending from it. The dotted line starts from the top of the red circle and extends to the bottom of the diagram. The line is a straight line, and it is not curved.

Below the red circle, there is a line that starts from the top of the diagram and extends to the bottom. This line is a straight line, and it is not curved.

The diagram is labeled as "Start."

<!-- image -->

## 3. Pressing equipment

Pressing is applying heat and pressure with a steam iron during the making up of a textile item. It is carried out by lifting and then lowering the steam iron on one section of the textile item at a time.  Pressing is done after working of a process, for example, after working a plain seam or a hem. Pressing gives a neat finish and enhances the appearance of the textile item.

Pressing is usually carried out using the following equipment:

<!-- image -->

Steam iron

<!-- image -->

Ironing board

<!-- image -->

Pressing cloth

<!-- image -->

Ironing board: It is a long, narrow, padded board used for pressing fabrics/garments. It can be adjusted in height for ease of user.

Pressing cloth:

It is a piece of lightweight fabric (white cotton fabric) placed between the iron and  the  fabric/garment  to  protect  the  surface  of  the  garment/fabric  during pressing.

## The steam iron

The steam iron has a small water tank where water can be filled in. When the iron is heated, the water is converted into steam which is released through the holes found in its soleplate.

In this image, we can see an iron machine. There is a water tank.

<!-- image -->

The steam iron helps to remove wrinkles and creases from fabrics and garments more easily and quickly than when using the dry iron.

113

In this image we can see a cloth and a bag.

<!-- image -->

<!-- image -->

A seam roll is also another pressing equipment used for pressing. It is cylindrical in shape and is used for pressing of seams.

## MORE TO KNOW

<!-- image -->

Long ago, people used charcoal iron. It was made of metal and was quite heavy. Hot glowing charcoals were used in the base of the iron.

## SAFETY NOTE:

While using the steam iron:

- Hands should be dry to avoid electric shock.
- Hands should be kept away from the hot soleplate to avoid burns.
- The iron should stand vertically on its heel when not in use.
- The iron should be switched off and left to cool down after use.
- The water tank should be emptied before storage.
- Do not use the iron if the cord or plug is damaged as this could lead to an electric shock.

<!-- image -->

1. Identify the small sewing tools illustrated below:
2. (a) Label the numbered parts of the electric sewing machine illustrated by arrows:
3. (b) Name the two common machine stitches that can be done using the electric sewing machine.
4. (c) Explain four safety rules that should be observed when using the electric sewing machine.

In this image we can see a white color object. There are some objects in the image.

<!-- image -->

In this image, we can see a machine. There is a switch board. We can see a thread.

<!-- image -->

3. State whether the following statements are TRUE (T) or FALSE (F) .

- (a) Pressing is applying pressure with a steam iron during the making up of a textile item.

\_\_\_\_\_\_\_\_\_\_\_

- (b) The steam iron can be stored without emptying the water tank after use.

\_\_\_\_\_\_\_\_\_\_\_

- (c) The steam iron should stand vertically on its heel when not in use.

\_\_\_\_\_\_\_\_\_\_\_

- (d) The dry iron removes wrinkles and creases in garments more easily than the steam iron.

\_\_\_\_\_\_\_\_\_\_\_

## TOPIC 2: Textile Decoration Techniques

## Learning Objectives

## At the end of this unit, you will be able to:

- Make fabric Yoyos to decorate textile items using scrap fabrics.
- Assemble pieces of scrap fabrics to create a patchwork.
- Apply colour to fabric using the tie and dye technique.
- Work out the quilting technique to create a padded material.

## 1. Introduction

Yoyos, patchwork, tie and dye and quilting are various decoration techniques which are used to enhance the appearance of fabrics and textile items.

<!-- image -->

Fabric Yoyo

<!-- image -->

<!-- image -->

<!-- image -->

Patchwork

Tie and Dye

<!-- image -->

RECALL

- Identify the fabric decoration techniques illustrated below:

<!-- image -->

<!-- image -->

<!-- image -->

Quilting

<!-- image -->

117

## 2. Fabric Yoyo

<!-- image -->

A  fabric  Yoyo  is  usually  made  from  scrap  fabrics  and  is round in shape. It is gathered at the centre.  It is a colourful technique which is used to decorate items. for example, cushion covers, garments, handbags and other accessories.

<!-- image -->

Cushion covers

<!-- image -->

Keyring

T-shirt

<!-- image -->

<!-- image -->

Necklace

<!-- image -->

Handbag

Slippers

<!-- image -->

## How to make a fabric Yoyo?

## You will need:

- Lightweight or medium weight scrap fabrics
- 1 two-holed plastic button
- Sewing kit
- Cut round shapes of 12 cm diameter from scrap fabrics. 1
- Starting with a double backstitch, work running stitches close to the folded edge. 3
- Measure 0.5 cm from the raw edge and make a fold. Pin in position. 2
- Gently pull the running stitches to gather the fabric.  Fasten with a double backstitch. 4
- Attach  a  button  to secure and decorate the fabric Yoyo. 5

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

ACTIVITY 1: PRACTISE THE MAKING OF A FABRIC YOYO

## How to sew a button on a fabric Yoyo?

- 1 Start with a double backstitch.
- 2 Bring the needle through one hole of the button and pull tightly.
- 3 Next, bring the needle down through the second hole of the button and the  fabric.
- 4 Repeat the process 2 to 3 times to secure the button in position.
- 5 Finish with a double backstitch on the wrong side of fabric.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

R.S: Right side of fabric W.S: Wrong side of fabric

119

120

## 3. Patchwork

<!-- image -->

Patchwork consists of cut pieces of scrap fabrics, joined together by hand or by machine stitching. The cut pieces can be of different shapes such as squares, hexagons and triangles. Patchwork is one way  of  recycling  and  reusing  fabrics  from  old  clothes  or  textile items. Patchwork can be used to make textile items such as bed covers, throws, pillow cases, clothing and accessories.

Jacket

In this image we can see a person standing. In the background there is a white color wall.

<!-- image -->

<!-- image -->

Bed cover

<!-- image -->

Skirt

Bag

In this image we can see a bag.

<!-- image -->

## How to create a patchwork?

## You will need:

- 1 sheet of tracing paper
- Lightweight or medium weight scrap fabrics
- Sewing kit
- Electric sewing machine (if available)

## Preparation of pattern for patchwork

In this image, we can see a diagram.

<!-- image -->

- 1 Draft a pattern on tracing paper as per dimensions given.

<!-- image -->

## Seam

A seam is a method of joining two pieces of materials together.

A seam must be strong, neat, well stitched and well-pressed.

Let us see how to work a seam, namely, a plain seam.

A plain seam is flat and is used on a wide variety of garments except on see-through fabrics.

## How to work a plain seam?

- Place two pieces of materials together with right sides facing and pin in position.
- Measure 1 cm from raw edges and tack in position.
- Work backstitches or straight machine stitches just above the tacking stitches.
- Remove the tacking stitches.
- Press the seam using a seam roll.

<!-- image -->

<!-- image -->

122

## Laying out, pinning, cutting out and transferring of pattern markings

1 a) Lay out and pin the pattern pieces on scrap fabrics. Pin diagonally at corners and at right angles to straight edges. The patchwork will consist of four squares of fabrics. b) Transfer pattern markings on the fabric using dressmaker's carbon paper and tracing wheel.

## Note: Squares can be cut from scrap fabrics of different colour/designs.

In this image, we can see a diagram with some text and images.

<!-- image -->

## Joining pieces of fabric

In this image we can see a poster with some text and images.

<!-- image -->

In this image, we can see some colorful pictures and text.

<!-- image -->

- Your patchwork is now completed. 7

<!-- image -->

Note: You may join several pieces of various shapes and sizes.

<!-- image -->

ACTIVITY 2: PRACTISE THE MAKING OF A PATCHWORK  CONSISTING OF FOUR SQUARES

Transferring pattern markings using dressmaker's carbon paper and tracing wheel

<!-- image -->

## REMEMBER

In this image, we can see a person's hand holding a tool. We can also see a white cloth.

<!-- image -->

## 4. Tie and Dye

<!-- image -->

Tie  and  dye  is  a  process  in  which  areas  of  a  fabric  are  tied  off according  to  a  desired  design  and  then  immersed  in  a  dyebath. The tied areas resist the dye and keep the original colour of the fabric.  Below are examples where the tie and dye technique has been used:

<!-- image -->

Summer dress

<!-- image -->

<!-- image -->

Shawl/Scarf

<!-- image -->

A pair of shorts

Cushion

<!-- image -->

Beach bag/shopping bag

There are many ways in which fabrics can be folded, pleated or rolled to create interesting patterns. Some examples are illustrated below:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Method                                                                                                                      | Tying technique   | Patterns   |
|-----------------------------------------------------------------------------------------------------------------------------|-------------------|------------|
| Dots Tie fabric in bunches at equal intervals.                                                                              |                   |            |
| Bulleye Pinch centre of fabric to a point and tie at equal intervals with a cord.                                           |                   |            |
| Crumple Crumple the fabric and tie tightly with cord.                                                                       |                   |            |
| Bands/Strips Fold fabric backward and forward to form pleats similar to an accordion. Tie folded fabric at equal intervals. |                   |            |
| Spiral Make a pinch in the centre of the fabric and twist until it is in a spiral shape. Secure with a cord.                |                   |            |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

MORE TO KNOW

<!-- image -->

Small objects such as buttons, pebbles, clothes pegs and bottle caps can also be combined with the ties to create a variety of patterns.

## How to dye fabric?

## Materials required:

<!-- image -->

Salt

<!-- image -->

Wooden spoon

1 packet of dye powder

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Method

<!-- image -->

<!-- image -->

Aluminium vessel

1

- In an aluminium vessel, add boiled water, the dye powder and the salt (2 tablespoons per 1 litre of water)
- Place the aluminium vessel with the dye mixture on the stove (medium heat). Stir the mixture with a wooden spoon to dissolve the dye powder and the salt.
- Immerse the tied fabric in the dyebath for approximately 25 minutes. Continue to stir the mixture gently.

<!-- image -->

<!-- image -->

<!-- image -->

Remove the fabric from the dyebath and rinse thoroughly. Untie the strings and hang the fabric to dry.

Tied fabric

<!-- image -->

## NOTE TO EDUCATORS

- Fabric should be prewashed  before  tying and dyeing fabric.

## SAFETY NOTE:

- Work in a welllighted and wellventilated room.
- Wear protective clothing such as an apron, mask and gloves during handling and use of dyes.
- Tie hair back during the dyeing process.
- Be careful with hot liquids.
- Do not inhale the vapour.

## 5. Quilting

Quilting consists of stitching three layers of fabric together using hand (running stitches) or straight machine stitches. A layer of cotton/wool wadding, is sandwiched between a top and a bottom layer of fabric, creating a thicker padded material.

In this image there are two pieces of fabric. On the left side there is a green color fabric. On the right side there is a blue and white color fabric.

<!-- image -->

Quilting  is  a  fabric  surface  decoration  technique  which  provides  warmth.  It  also  acts  as  a protective padding in some textile items.  Different designs can be worked for quilting.  Some examples where quilting has been used are illustrated below:

<!-- image -->

Jacket

<!-- image -->

<!-- image -->

<!-- image -->

Cap

<!-- image -->

Waistcoat

Blanket

<!-- image -->

Hand gloves

Hand bag

<!-- image -->

Boots

128

## How to carry out the quilting technique?

## You will need:

- 1 sheet of tracing paper
- Lightweight or medium weight scrap fabrics
- 50 cm wadding
- Sewing kit
- Electric Sewing machine (if available)

## Preparation of pattern for quilting

In this image, we can see a diagram.

<!-- image -->

- Draft a pattern on tracing paper as per dimensions given. 1

## Cutting out scrap fabrics

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Using the pattern:

- Cut out two squares in scrap fabric from old and unused textile items.
- Cut out one square in wadding material.

- Using  fabric  pen/  dressmaker's  pencil,  draw  lines  parallel  to  each  other  and  at  equal intervals on the right side of the top layer of the fabric. 3
- Place  the  wadding  in  between  the  two  layers  of  scrap  fabrics,  with  right  sides  facing outwards. 4
- Pin and tack the three layers together to hold the fabrics in position. Remove pins. 5
- Stitch the three layers together either by using running stitches or straight machine stitches. 6

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a graph. There are two lines on the graph. There is a text on the graph.

<!-- image -->

Note: When quilting is done with an electric sewing machine, the thread tension of the machine should be loosen and the stitch length should also be lengthened.

In this image we can see a machine and a table. On the table we can see a cloth.

<!-- image -->

<!-- image -->

ACTIVITY 4: USING PIECES OF SCRAP FABRIC, WORK OUT A SAMPLE TO PRACTICE THE QUILTING TECHNIQUE.

<!-- image -->

1. Rearrange the following steps to explain how to work a fabric Yoyo:
2. Create a patchwork design in your copybook with the shapes given below. Colour your design.
3. (a) What is 'tie and dye'?
4. (b)  Which tying technique has been used to obtain the patterns in the following textile items illustrated below:

| Making of fabricYoyo                                                                | Steps   |
|-------------------------------------------------------------------------------------|---------|
| Measure 0.5 cm from the raw edge and make a fold.                                   |         |
| Attach a button to secure and decorate the fabric Yoyo.                             |         |
| Gentlypulltherunningstitchestogatherthefabricandfastenwithdoublebackstitch.         |         |
| Work running stitches close to the folded edge, starting with a double backstitch . |         |
| Cut round shapes of diameter 12 cm in scrap fabrics.                                |         |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

(c) List three safety rules to consider when dyeing a textile item.

## 4. Fill in the blanks using the words given below:

## warmth, three, running stitches, protective, wadding, decoration

A quilted textile item consists of one layer of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ which, is sandwiched between a

top and a bottom layer of fabric.  The \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ layers of fabric can be stitched together

using \_\_\_\_\_\_\_\_\_\_\_\_\_ \_\_\_\_\_\_\_\_\_\_\_\_\_\_ or straight machine stitches. Quilting is usually done

for surface\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_, to provide\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and  for \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ padding

in some textile items.

132

## TOPIC 3: Creative Textile Project

## Learning Objectives

## At the end of this unit, you will be able to:

- Identify ways to recycle existing clothing and scrap textiles materials into new textile items.
- Construct a textile item using basic sewing skills and techniques.
- Apply different textile decoration techniques to personalize a textile item.

## 1. Introduction

Using scrap fabrics from old clothing and furnishings is a good way of recycling textiles to promote sustainability. A tote bag is proposed as a creative textile project for Grade 9. Tote bags are trendy and can be used for several purposes, for example, to carry your school materials, as a shopping bag or as a beach bag.

Front view

In this image we can see a bag.

<!-- image -->

In this image we can see a bag.

<!-- image -->

Back view

## NOTE TO EDUCATORS

- Textile  items  can  be  planned  and  adapted  according  to  school  context,  facilities  and resources available, as long as students acquire the skills and techniques in Unit 8, Topic 2 (Textile decoration techniques) targeted for Grade 9.
- Avoid very thick, fraying, fine or stretchy fabrics as these are difficult to handle.

For your textile project, you may use an old pair of denim trousers (Jean) , an old curtain, old tablecloth, bedsheet and any other old garments as scrap fabric.

## 2. Making a tote bag from a pair of old denim trousers ('Jeans') and shirt

During the construction of the tote bag, you will learn basic construction techniques such as seams, working of a hem and attaching a button. Patchwork and fabric Yoyo have been used as decoration techniques on the tote bag.  Alternatively, a tied and dyed fabric can be quilted and used to make the tote bag.

<!-- image -->

<!-- image -->

Quilted tote bag made from tied and dyed fabric

In this image, we can see a bag. There are some objects on the bag.

<!-- image -->

In this image we can see a bag.

<!-- image -->

## For drafting the pattern, you will need:

- 1 sheet of tracing paper
- Pencil, ruler and rubber

## For making up the tote bag, you will need:

- Scrap fabrics from old clothing (e.g. an old pair of denim trousers/ old curtain/old men's shirt)
- Sewing thread
- Tacking thread
- Sewing kit
- Electric sewing machine

## Order of work

1. Draft the pattern pieces for the tote bag.
2. Lay out, pin and cut out the required fabric pieces from scrap fabrics. Transfer pattern
3. markings onto the fabric.
3. Create a patchwork with four squares of scrap fabrics.
4. Work a hem of 2 cm at the top edges of the patched fabric and the fabric for the back of bag.
5. Place the right side of the patched fabric and the fabric for the back of bag together.
6. Work the seams on the three sides of the tote bag.
7. Machine stitch across the bottom corners of the tote bag.
8. Prepare and attach the bag handles.
9. Decorate the tote bag on the right side with buttons or with fabric Yoyos.

## Procedure:

- Draft the pattern pieces for the tote bag as per the dimensions given below. 1

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

## Bag handle

<!-- image -->

135

|   Unit 8 - Design &amp; Creativity through Textiles

136

## Laying out, pinning, cutting out and transferring of pattern markings

- (a) Lay out the fabric and pin the pattern pieces in position. Cut out the fabric pieces for the patchwork. The four squares of fabric will form the front of the tote bag. 2
- (b) Using the pattern for bag, cut out one piece of  fabric. This would be used for the back of the tote bag.
- (c) Using the pattern for bag handle, cut out four strips of fabrics as follows.

In this image, we can see a collage of different images. There is a blue color object at the bottom.

<!-- image -->

In this image, we can see a bag.

<!-- image -->

Cut 2

In this image we can see a bag with some text and a picture of a paper and a sticker.

<!-- image -->

## Creating a patchwork with scrap fabric

- Create a patchwork with the four squares of scrap fabric. (refer to Topic 2 for creating a patchwork). 3

<!-- image -->

## Working of hem

In this image, we can see a sewing machine. There is a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a thread and a thread. We can see a

<!-- image -->

## Working of seams

- With right sides together, pin and tack patched fabric and back of bag along the stitching line on the three sides as illustrated below. 5

Note: Pin diagonally at corners and at right angles to straight lines.

In this image, we can see a table with some objects on it.

<!-- image -->

138

In this image, we can see a sewing machine. There are some text on the image.

<!-- image -->

## Working of bottom corners

In this image we can see a bag.

<!-- image -->

<!-- image -->

- Machine stitch across the bottom corners of the tote bag as shown. 9

## NOTE TO EDUCATORS

- Backstitches can be worked if an electric sewing machine is not available.
- Matching sewing thread to fabric colour should be used.

## SAFETY NOTE:

- DO NOT put pins and needles in your mouth as you sew.
- DO NOT leave pins and needles lying on the table or on the floor.
- Store pins and needles in a container or pin cushion when not using them.
- Keep scissors closed when not using them.
- Never run with scissors.

## Preparation of bag handle

- With right sides together, pin and tack denim fabric and striped fabric along the stitching line on three sides as illustrated below: 10
- Trim edges to 0.5 cm and press. 11
- Turn bag handle with right sides out and press again. 12

<!-- image -->

<!-- image -->

## Attaching of bag handle to bag

In this image, we can see a bag. There is a text on the image.

<!-- image -->

140

## Finishing the tote bag

- Turn the tote bag to the right side. 16
- Decorate with buttons or with fabric Yoyos. 17

<!-- image -->

In this image we can see a bag.

<!-- image -->

Front view

In this image we can see a bag.

<!-- image -->

<!-- image -->

1. State two safety precautions you should consider when using dressmaker's pins during the making of your creative textile item.
2. (a) Label the numbered parts of the tote bag illustrated by arrows:
3. (b) Name two other fabric surface decoration techniques which you can work to embellish the tote bag.
4. (c) Line is an important element of fashion design.  Identify the two types of 'lines' present in the tote bag.
3. Plain seam has been used to make the tote bag.
6. (a) In your copybook, trace out the diagram of the plain seam illustrated below.
7. (b) On your sketch, show two ways in which the raw edges of the plain seam can be neatened.

In this image, we can see a bag. There are some objects on the bag.

<!-- image -->

The image is a diagram of a box with a label "W.S." on the top. The box is labeled as "W.S." and has a dashed line on the top of the box.

<!-- image -->

4. Evaluating my creative textile project.

Copy the table below to evaluate your creative textile project.

| Nameofcreative textile project:            |   Nameofcreative textile project: |
|--------------------------------------------|-----------------------------------|
| The positive points in myproject:          |                                 1 |
| The positive points in myproject:          |                                 2 |
| The positive points in myproject:          |                                 3 |
| Areas that could be improved in myproject: |                                 1 |
| Areas that could be improved in myproject: |                                 2 |
| Areas that could be improved in myproject: |                                 3 |

In this image, we can see a poster with some text and images.

<!-- image -->

Appendix  |

143

<!-- image -->

## Pancakes

| Ingredients          | Quantity   |
|----------------------|------------|
| Batter               |            |
| Flour, self- raising | 100 g      |
| Salt                 | Pinch      |
| Sugar                | 1 Tbsp     |
| Milk                 | 100 ml     |
| Egg                  | 1          |
| Unsalted butter      | 1 Tbsp     |
| Vanilla essence      | 1 tsp      |
| Cooking              |            |
| Oil, cooking         | 1 Tbsp     |

## Method

1. Sieve flour with salt into a mixing bowl.
2. Melt butter on 'Low' in microwave oven.
3. Make a well in the centre of flour and add other ingredients.
4. Beat to obtain a thick smooth batter.

<!-- image -->

Number of servings:

5

Preparation Time:

10  minutes

Cooking appliance:

Stove

Cooking temperature:

Low

Cooking time:

5 minutes

<!-- image -->

A batter is  a  mixture of flour and other ingredients  used  to  make  pancakes  or to coat food before frying.

5. Grease a small non-stick frying pan and pour ¼ cup of batter in the centre.
6. Allow to cook until the underside is browned, and the top is covered with bubbles.
7. Flip and cook until a light pale brown colour is obtained.
8. Repeat with remaining batter.
9. Serve hot or cold.

## Serving Suggestion

Can be served with ice-cream/ yoghurt/ cream/ fruits/ maple syrup or honey.

## Variations

For a savoury version, omit sugar and vanilla essence in the batter; add 50 g grated cheese / a chopped onion / 1 Tbsp mixed chopped herbs. Serve with chutney.

<!-- image -->

Sweet pancakes with yoghurt, chocolate and fruits

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Sweet pancake sandwich

Savoury pancakes with scrambled eggs

Pizza style pancakes

Savoury pancake sandwich

## MORE TO KNOW

## Macaroni des Iles

Ingredients

Quantity

Macaroni

200 g

Cheese, cheddar

50 g

## Tuna mixture:

Pieces of tuna

1 can in soyabean oil

Salt and pepper

To taste

Thyme and parsley

1 bunch

Ginger and garlic paste

1 tsp

Macedoine, frozen/ fresh

100 g

<!-- image -->

## Rougaille:

Onion  / leek

Ginger and garlic paste

Tomato, whole peeled

Shallots

Salt

## Topping:

Toasted breadcrumbs

Cheddar cheese, grated

## Garnish:

Tomatoes

Shallots

## Method

## 1. Prepare pasta:

1

1 tsp

1 can

1 bunch

1 level tsp

50 g

50 g

4-5

4-5 sprigs

Number of servings:

5

Preparation Time:

10  minutes

For Macaroni, rougaille and

tuna mixture:

Cooking appliance

Stove

Cooking temperature

Medium

Cooking time

Macaroni:

Tuna mixture:

Rougaille:

8-10 minutes

5 minutes

5 minutes

For Topping

Cooking appliance

Grill

Cooking temperature

Maximum.

Middle shelf

Cooking time

~5 minutes

<!-- image -->

## MORE TO KNOW

Macedoine is a mixture of vegetables cut into small pieces

- Fill a large pan with water to ¾ level and bring to boil.
- Add macaroni in boiling water and cook until soft. Drain.
- Transfer back to pan and mix with grated cheese.

## 2. Prepare tuna mixture:

- Defrost frozen macedoine in microwave oven for 1 minute on 'High' and drain.
- Reserve 1 tablespoon oil from the tuna can and drain the rest.
- Flake tuna lightly with a fork and season to taste.
- Chop onion and parsley finely.
- Heat ½ Tbsp reserved oil in a non-stick frying pan, sauté onion with ginger and garlic paste.

<!-- image -->

- Add macedoine and cook 2-3 minutes until all water has evaporated.
- Add tuna and chopped herbs. Cook 1 - 2 minutes.

## 3. Prepare 'rougaille' :

- Chop onion/ leek and shallots finely.
- Blend chopped onions and herbs with canned tomatoes until smooth.
- Heat remaining reserved oil, add blended mixture and allow to cook 5 minutes.

## 4. Preheat grill.

## 5. Prepare topping:

- Grate cheese finely, mix with breadcrumbs.

## 6. Assemble the dish:

- Grease a deep, large ovenproof dish.
- Mix macaroni, tuna mixture and rougaille. Check the seasoning.
- Transfer to dish.
- Cover with topping.
- Grill until golden brown on top.

## Serving suggestion

Serve hot/cold garnished with tomato wedges and spring onions.

## Variations

<!-- image -->

<!-- image -->

## MORE TO KNOW

<!-- image -->

In this image we can see a wooden spoon and a wooden plate. On the plate we can see pasta.

<!-- image -->

- Pasta is a dough made with flour, water and sometimes eggs, which is moulded into a variety of shapes and boiled.
- There are many types of pasta, the most common ones are spaghetti , fusilli and lasagne .
-  Use other types of pasta instead of macaroni
-  Use corned beef or mutton instead of canned tuna
-  Use frozen/ fresh minced meat instead of canned tuna
-  Use fresh vegetables in season to make macedoine

## Cinnamon Oat Cookies

| Ingredients                  | Quantity   |
|------------------------------|------------|
| Melted mixture: Caster sugar | 100 g      |
| Unsalted butter              | 100 g      |
| Honey                        | 1 Tbsp     |
| Dry mixture: Plain flour     | 100 g      |
| Cinnamon                     | 1 tsp      |
| Oats                         | 100 g      |
| Greasing:                    |            |
| Butter                       | 1 g        |

## Method

1. Preheat oven. Grease baking tray.
2. Cook  ingredients  for melted  mixture on low heat in a heavy-based pan. Make sure all sugar crystals have well dissolved, do not allow mixture to boil.
3. Remove melted mixture from heat and allow to cool.
4. Sieve flour and cinnamon in a large mixing bowl and add oats.
5. Pour cooled melted mixture into the dry mixture and mix well.
6. Divide into small balls, flatten and place on a baking tray, keeping space in between.
7. Bake until golden brown.
8. Remove immediately from tray and allow to cool until crisp.

<!-- image -->

Number of servings: Preparation Time:

5

30  minutes

For melted mixture:

Cooking appliance

Stove

Cooking temperature

Low

Cooking time

~5 minutes

Cooling time

10 minutes

For Cookies:

Cooking appliance

Oven

Cooking temperature

160 0  C

Cooking time

15-20 minutes

Cooling time

5 minutes

## Serving Suggestion

Serve on doyley paper, dusted lightly with icing sugar and pinch of cinnamon powder.

## Variations

## Chocolate chip Oat Cookies:

Add 50 g chocolate chips to the mixture and mix well before shaping taking care not to break the chocolate chips.

## Almond Oat Cookies:

Add 50 g blanched and chopped almonds to the mixture and mix well before shaping.

<!-- image -->

<!-- image -->

## Cassava Pudding

| Ingredients              | Quantity    |
|--------------------------|-------------|
| Pudding:                 |             |
| Cassava, fresh           | 500 g       |
| Milk, liquid 1           | 50 - 75 ml  |
| Milk powder 2            | 25 g - 50 g |
| White sugar              | 75 g        |
| Vanilla essence Coating: | 2 tsp       |
| Desiccated coconut       | 50 g        |

## Method

1. Wash, peel and grate cassava.
2. Blend with liquid milk until smooth.
3. Add sugar, milk powder and essence and blend until well dissolved.
4. Pour into a deep rectangular ovenproof dish. Spread evenly and smooth the surface.
5. Cook in microwave oven for 8 minutes on 'Low' until well set in the centre. Allow to stand before removing.
6. Test with a skewer. Allow to cool.
7. Slice evenly into bars.
8. Coat each bar well in coconut and serve.

<!-- image -->

Number of servings:

5

Preparation Time:

30  minutes

For pudding:

Cooking appliance

Microwave oven

Cooking temperature

Power level:

Low

Cooking time

8 minutes

Standing time

2 minutes

Cooling time

10 minutes

## Serving suggestion

Serve well coated with desiccated coconut neatly displayed in a rectangular dish.

## Variations

Use freshly grated coconut for coating.

## Note:

1. The amount of liquid milk required for blending depends on the toughness of cassava. Use 50 ml to start, up to 75 ml.
2. The amount of milk powder depends on the consistency of the mixture and also if a milky variation is preferred. Use 25 g for binding the mixture and up to 50 g for a milky flavour.

## Appendix - Unit 8

In this image we can see a sewing machine, a cloth, a scissors, a measuring tape and some other objects.

<!-- image -->

Appendix  |

149

## APPENDIX

## Threading the electric sewing machine

In this image, we can see a diagram.

<!-- image -->

## Sewing for fun An oven mitt made from an old pair of denim trousers (Jeans)

The oven mitt is a protective textile item which is  used  in  the  kitchen  to  handle  hot  utensils safely  while  cooking.  You  can  make  your  own oven mitt using scrap material and also put into practice the two decorative techniques you have learned, namely: quilting and tie &amp; dye .

<!-- image -->

## How to make an oven mitt?

## For pattern drafting, you will need:

- 1 sheet of tracing paper
- Pencil, ruler and rubber

## For making up the oven mitt, you will need:

- 50 cm white Tergale fabric (toile à drap) to be tied and dyed
- 1 packet of dye powder
- 1 m of cord
- 30 cm wadding
- A pair of jean or skirt/shorts with pockets
- Sewing thread
- Tacking thread
- Sewing kit
- Electric sewing machine

## Order of work

1. Pre-wash white Tergale fabric. Tie and dye.
2. Draft the pattern for the oven mitt.
3. Use the pattern to cut out fabric pieces:
- Two pieces in the 'Tergale' fabric
- One piece of fabric from an old garment or any other textile item made of thick material, for example, denim (Jean)
- One piece in wadding
4. Transfer pattern markings onto the fabric pieces..
5. Place the wadding between the dyed fabric and second piece of white fabric.
6. Work the quilting technique.
7. Place the right side of the quilted fabric and the denim fabric together.
8. Work the seams, leaving an opening of 8 cm on one side.
9. Turn the oven mitt to the right side.
10. Fold to the inside the raw edges of the opening in the oven mitt.
11. Work oversewing stitches along the folded edge.

<!-- image -->

## Procedure:

- Draft the pattern as per dimensions given below. 1

In this image, we can see a diagram. There is a text on the image.

<!-- image -->

## Cutting out fabric and wadding

- Using the pattern, cut your fabric and wadding as follows: 2

2 pieces in white fabric

<!-- image -->

<!-- image -->

<!-- image -->

1 piece in wadding

1 piece in denim fabric cut from an old pair of denim (jean) trousers with a patch pocket

## Tie and dye fabric

- Tie and dye one piece of the white fabric in a colour of your choice (refer to Unit 8, Topic 2). 3

<!-- image -->

## Work quilting technique

- Place the wadding between the dyed fabric and second piece of white fabric. 4
- Work the quilting technique (refer to Unit 8,  Topic 2). 5

In this image there is a white and blue color pattern.

<!-- image -->

## Working of seams

In this image, we can see a picture of a board. There are some arrows and text.

<!-- image -->

- With  right  sides  facing (quilted fabric and denim fabric) ,  pin and tack along the stitching line. Leave an opening of 8 cm on one side, as illustrated. 6

| Appendix

154

- Machine stitch along the stitching line. Remove tacking stitches. 7

## Opening of 8 cm on one side

In this image we can see a picture of a cloth.

<!-- image -->

## NOTE TO EDUCATORS

- Backstitches can be worked if an electric sewing machine is not available.
- Matchine sewing thread to fabric colour should be used.
- Trim the seams.  Snip the corners.  Press open the seams. 8
- Turn the oven mitt to the right side. 9

Trim seams

In this image, we can see a picture of a cloth. There are some objects at the bottom of the image.

<!-- image -->

Opening of 8 cm on one side

<!-- image -->

<!-- image -->

## Finishing the opening

<!-- image -->

Fold to the inside the raw edges of the oven mitt and work oversewing stitches along the folded edge. 10

In this image, we can see a pair of jeans. There are arrows and text written on the image.

<!-- image -->

## NOTE TO EDUCATORS

Refer to Grade 8 textbook - page 299 on how to work oversewing stitches.

## The oven mitt is ready for use!

In this image we can see a cloth, a pair of denim trousers and a scrap fabric.

<!-- image -->