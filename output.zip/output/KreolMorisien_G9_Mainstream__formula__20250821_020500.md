## KREOL MORISIEN ;9

In this image I can see the sky, clouds, the ground, the plants, the trees, the grass, the sky and the water. I can see the people.

<!-- image -->

## Grad 9

In this image, we can see a person.

<!-- image -->

Nom: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Prenom:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Professor Vassen Naëck

- Head Curriculum Implementation, Textbook Development and Evaluation

## KREOL MORISIEN PANEL

Beatrice Antonio-Françoise

- Panel Coordinator, Lecturer, MIE

Nuckiren Pyeneeandee

- Senior Lecturer, Officer in charge Kreol Unit, MIE

Dr Shrita Hassamal

- Lecturer, MIE

Dr Yannick Bosquet

- Senior Lecturer, UoM

Dr Guilhem Florigny

- Lecturer, UoM

Marjorie Munien

- Deputy Rector, Vice-President of the Creole Speaking Union

Yani Maury

- MPhil/PhD Student, UoM, Resource Person for the Kreol Rodrige

Christelle Ah-Choon Angeline

- Representative of the Creole Speaking Union

Tenusha Jundoosing

- Educator, Poet, Prize Winner, Literary Contest of the Creole Speaking Union

Cindy François Lam Ching Kow

- Educator

## VALIDATION PANEL

Akademi Kreol Repiblik Moris (AKRM)

<!-- image -->

Design

Leveen Nowbotsing

- Graphic Designer

- © Mauritius Institute of Education (2021)

ISBN : 978-99949-53-92-9

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

<!-- image -->

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine-Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The  development  of  textbooks  has  been  a  very  challenging  exercise  for  the  writers  and  the  MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the   NCF, while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic designers who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

<!-- image -->

Nou pou rapel ki Maniel Grad 8 Kreol Morisien ti met laksan lor bann tem ki kadre avek liniver anvironnmantal bann zenn ki pe viv dan 21 em  siek. Pou Maniel Grad 9 Kreol Morisien, nou finn swazir pou al dan mem direksion. Se pou sa rezon-la ki dan Sapit 1, nou pou dekouver tem lamizik ki pou antrenn nou ver Sapit 2 ki konsantre lor bann invansion. Dan Sapit 3, nou pou al  sirtou  dekouver  bann  diferan  mwayin  transpor  ki  ena  dan  Moris  ek  an  zeneral,  ek  li  pou transport nou ver Sapit 4 ki koz lor dekouvert langaz. Nou pe terminn par enn Sapit 5 ki ena pou tem: 'Perspektiv lor lavenir' . Li enn rapel ki apre Grad 9, bann zenn pou bizin fer enn swa lor bann diferan perspektiv ki pou prezant devan zot.

Kouma pou Maniel Grad 8, nou espere ki sa liv-la pou fer plezir otan piblik zelev ki piblik adilt. Sa maniel-la finn realize gras-a soutien ek koudme plizier dimounn ek institision. Parmi bann institision,  nou  pou  sit  MIE,  Liniversite  Moris  (UoM),  Minister  Ledikasion  ek  Resours  Imin, Ledikasion Tersier ek Resers Siantifik ek Akademi Kreol Repiblik Moris (AKRM).

Lekip ki finn permet realizasion sa maniel-la ek momem tenir pou remersie an partikilie Dr Om Varma, Direkter MIE, Professer Vassen Naëck, Head of Curriculum MIE, ek Profeser Arnaud Carpooran, Dwayen Fakilte Sians Sosial ek Humanities UoM, pou zot konfians ek zot soutien.

## Beatrice Antonio-Françoise

Kordinatris, Lecturer,

Kreol Unit,

MIE

## Tab-de-matier

| Sapit 1:   | Lamizik                | 1 - 28   |
|------------|------------------------|----------|
| Sapit 2:   | Bann invansion         | 29 - 50  |
| Sapit 3:   | Mwayin transpor        | 51 - 70  |
| Sapit 4:   | Dekouvert langaz       | 71 - 92  |
| Sapit 5:   | Perspektiv lor lavenir | 93 - 114 |

## Sapit 1 Lamizik

- Sapit 1

Kreol Morisien

|

1

## Lir sa text-la, answit reponn bann kestion.

## LAMIZIK DAN LAPO

In this image we can see a woman is playing a guitar. She is wearing a red color dress.

<!-- image -->

Anushka Shankar konsidere kouma enn parmi bann meyer zwer sitar dan lemond. Li finn zwe avek bann gran-gran artist kouma Herbie Hancock, Sting, Chaka Khan e li finn ousi zwe dan boukou pei kouma Langleter, Lafrans,  Lenn  ek  Moris.  Tou  dimounn rekonet, ek limem an-premie ki, si pa ti ena so papa, li pa ti pou ariv kot li ete azordi.

Anfet,  Ravi  Shankar  finn  premie  star  internasional lamizik indien. Se probableman kolaborasion ki ti ena ant li ek George Harrison - enn manb group Beatles - an 1966 ki finn kontribie pou ki lemond antie konn li. Sa lepok-la, Anushka pa ti ankor ne. Depi sa dat-la ziska so lamor an 2012, li finn zwe sitar partou dan lemond e li finn gagn plizier rekonpans.

Referans foto: http://www.beachcomber-events. com/fr/anoushka-shankar

Anushka rakonte: ' Mo pa finn trouv mo papa souvan kan mo ti ti-baba. Mo ti konpran bien vit ki li ti enn gran mizisien parski sak fwa ki nou ti al so bann konser, ti ena boukou dimounn. Kan mo papa finn konpran ki mwa ousi mo anvi vinn mizisien, toutswit li finn deside ki limem pou mo profeser. Li finn enn extra bon guru . '

Ravi Shankar finn fer ledikasion so tifi limem e finn fer li dekouver bann tradision lamizik klasik indien. Se sa bann leson lamizik la ki finn fer zot relasion ranforsi.

'Nou relasion finn vinn inik gras-a sa bann leson-la. Nou finn partaz enn nivo kominikasion profon ki zis lamizik kapav done.'

Depi laz 13 an, Anushka finn zwe ek so papa dan boukou pei e souvan sa finn fer li pa al lekol. Se akoz sa ousi ki, konpare ar lezot zanfan so laz, li pa finn fer boukou kamarad.

Mem si li finn kontign zwe ek so papa ziska ki li vinn enn adilt, Anushka finn koumans enn karyer solo laz 17-an kan li finn fer so premie album. Zordi, so lamizik nepli kouma lamizik so papa. Bann son ki li fer reflet boukou so leritaz miltikiltirel (li finn pas so lanfans ant Lenn ek Langleter).

'Ena boukou eleman mo leritaz dan mo lamizik parski mo krwar ki sa rann li pli fasil pou dimounn konpran. Answit, mo pe sey demistifie sitar ek lamizik ki mo zwe. Boukou dimounn ankor get li dan enn manier inpe tradisionel. Kan zot tann sitar zot pans bann zafer spiritiel, lansan tousala. Mwa mo pe sey montre ki profonder linstriman-la ena. Se sa ki mo anvi partaze ek dimounn ki vinn dan mo bann konser.'

Apart so bann konser, Anushka Shankar finn travay pou bann fim e li finn ekrir dan bann zournal indien. An 2002, li finn ekrir biografi so papa, Bapi: Lamour mo lavi .

Referans foto: http://www.beachcomber-events.com/fr/anoushka-shankar

1. Reponn par Vre (V) ou Fos (F). Zistifie sak repons.
2. Nomm de mizisien ki finn partaz lasenn ek Anushka Shankar.
3. Dapre twa, kouma kolaborasion ek George Harrison finn ed Ravi Shankar pou vinn enn mizisien renome?
4. Kifer Anushka pa ti ena boukou kamarad?
5. Ki to konpran par fraz: 'dimounn ankor get [sitar] dan enn manier inpe tradisionel'?

In this image, we can see a table with some text on it.

<!-- image -->

|                                                         | V/F        |
|---------------------------------------------------------|------------|
| a. Anushka Shankar zwe tabla.                           | __________ |
| b. Ravi Shankar finn zwe zis dan Lenn.                  | __________ |
| c. Ti touletan ena lafoul dan bann konser Ravi Shankar. | __________ |
| d. Anushka finn fer enn album laz 13-an.                | __________ |
| e. Anushka finn fer lamizik pou fim.                    | __________ |

## 6. Explik bann mo/expresion ki trouv an-gra dan text.

- a. kontribie
- b. guru
- c. leritaz miltikiltirel
- d. demistifie
- e. biografi

## 7. Trouv bann tradiksion ki apropriye pou bann mo ek expresion ki swiv, dapre manier ki finn servi zot dan pasaz.

| Kreol Morisien   | Angle            |
|------------------|------------------|
| konsidere        |                  |
| lamor            |                  |
|                  | was not yet born |
| so tifi          |                  |
|                  | classical        |
|                  | compared to      |
| karyer           |                  |
|                  | album            |

In this image we can see a music sheet.

<!-- image -->

## Ribrik 2 Vokabiler

## Exersis 1

## Relie sak mo ek so definision.

Sef lorkes

- Sinkiem not lamizik.

Akapela

- Enn dimounn ki ena pli ot tonalite lavwa.

Sol

- Enn bwat kare an banbou kot ena plizier ti-lagrin ladan e ki bien popiler dan bann zil Mascareignes.

Kaset

- Enn dimounn ki diriz enn group mizisien.

Soprano

- Enn bwat an plastik kot ena enn band magnetik ki anrezistre ek prodwir bann son.

Maravann

- Kan pe sante san akonpagnman okenn linstriman lamizik.

## Exersis 2

Lir sa text-la ek donn enn definision pou bann mo souligne.

In this image we can see a poster with some text and some images.

<!-- image -->

In this image we can see a diagram.

<!-- image -->

2. Enn bwat ena plizier lagrin ladan.
3. Enn instriman lamizik dan fami perkision.
4. Nou itiliz enn mediator pou grat li.
5. Enn instriman ki forme par enn tib ek plizier trou.

## Vertikal

- A. Enn instriman a-van.
- B. Li kapav sintetik ou fer ek lapo zanimo.
- C. Enn mo ki servi an zeneral pou instriman perkision.
- D. Enn instriman a-kord ki zwe avek enn lars.

## Exersis 4

Enn instriman lamizik se enn obze ki permet fer bann son.

## Ena trwa diferan prinsipal fami instriman lamizik:

- i.    Instriman a-van
- ii.  Instriman a-kord
- iii. Perkision
- a. Klas sa bann instriman lamizik la dan zot kategori.

Lagitar, violon, saxofonn , laflit, piano, batri, maravann, kontre-bas, marakas, ravann, tanbour.

- b. Apar bann instriman ki finn mansione lao, azout omwin enn instriman dan sak kategori.

In this image, we can see some musical notes.

<!-- image -->

## Anou dekouver rezo lexikal

## Lir text ki swiv.

## Lamer

Lamer otour nou aport nou mil kiksoz. Nou benefisie bann prodwi marin ki nou kapav konsome kouma bann pwason , krab ek alg . Lindistri lamer ofer travay boukou dimounn kouma bann peser , marin ek plonzer . Li enn atou ki lindistri lotelri egalman explwate. Lamer ousi enn sours relaxasion ek detant, avek so bann laplaz ki rekouver ek disab , ek so bann lagon kot nou kapav naze . Li inportan prezerv sa lanvironnman akwatik la.

This image is taken outdoors. At the top of the image there is the sky with clouds. In the middle of the image there is a beach. On the beach there are two boats. In the background there are trees and a mountain.

<!-- image -->

## Rezo lexikal

- Sa text-la koz lor lamer ek so linportans: se samem lide prinsipal (tem).
- Tou bann mo (nom, verb, adzektif) ki ena lien avek enn tem, se samem ki nou apel rezo lexikal .
- Tou bann mo an gra dan sa text-la ena enn lien avek tem lamer ek zot form parti so rezo lexikal .

Lir sa text-la ek idantifie tou bann mo ki apartenir a rezo lexikal lamizik ek soulign zot.

In this image we can see a guitar.

<!-- image -->

Fabien ti toultan fasine par bann instriman lamizik. Kan li ti dan primer, li finn koumans swiv  bann  kour  lagitar  dan  konservatwar lamizik François-Mitterand. Mem si li ti pe fer enn long vwayaz par bis, li ti pe inpasian pou al sak leson. Li ti ousi form parti enn koral. Souvan, li ti pe al zwe dan bann fet laniverser,  dan  bann  seremoni  relizie  ek mem dan lekol. Kan li finn rant dan kolez, li ek trwa bon kamarad finn mont enn group. Toule  Samdi,  zot  fer  bann  partaz  mizikal ansam.  Pou  so  laniverser  kinz-an,  Fabien finn demann enn lagitar. Li santi li bien kan so  bann  paran  ekout  so  lamizik  ek  motiv li  pou kontigne. Fabien reve ki li pou vinn enn gitarist profesionel. Koumsa, li pou kapav montre so talan kan li zwe devan bann diferan lodians.

## Rezo lexikal - Bann sinonim

So regar ti persan kouman enn leg. Apre enn kou, san atann, li ti drese, ti arme ek ti lans so zarm dan lamer avek enn vites ek enn lafors inkrwayab. Rar li ti rat so target.

Depi 'Tom Kamaleon', (Jason Lingaya, 2017)

Dan sa text-la, nou kapav ranplas bann mo souligne.

1. persan = vif
2. drese = dibout
3. vites = rapidite
4. inkrwayab = inimazinab

Enn sinonim se enn/bann mo ou expresion ki ena mem sans, mem sinifikasion ki enn lot mo.

## Sinonim mo

## Exanp:

Mo bien tris ki mo pa finn reisi vinn to laniverser.

Mo bien sagrin ki mo pa finn reisi vinn to laniverser.

## Sinonim expresion

## Exanp:

Mo pe bizin gagn sa liv-la atoupri.

Mo pe bizin gagn sa liv-la koutkekout.

An zeneral, bann sinonim dan enn text permet evit fer repetision bann mo. Zot osi ede pou ki text-la pa paret monotonn.

Nou note ki enn mo kapav ena plizier sinonim.

## Exersis 5

## Ranplas bann mo/expresion souligne par enn sinonim. Finn fer enn lexanp pou twa.

- a. Kot to finn met mo lagitar? (poz)
- b. Lamizik ti mari serye dan fet.
- c. Kan mo latet pa anplas, mo ekout enn bon lamizik pou relax.
- d. Met an avan to talan, pa bizin to per, to enn bon mizisien.
- e. Dousman-dousman to pou resi konn manie violon-la, to bizin ena pasians.
- f.  Maloya se enn tip lamizik ki oriziner depi Larenion.
- g. To kapav itiliz mo armonika ziska ki to paran aste enn pou twa.
- h. To savwar-fer vreman inik, pena boukou dimounn parmi nou ki konn zwe laflit kouma twa.
- i.  Mo rev se vinn enn mizisien popiler.
- j.  Observ bien kot mo pe plas mo ledwa pou fer bann not lamizik.

<!-- image -->

## Kwiz Kiltir zeneral

- Kopie tou bann kestion ki liste anba lor bann bout papie.
- Avek led profeser, desid enn fason pou zwe sa kwiz-la pou fer li vinn pli interesan.
- Finn donn lexanp enn kestion-repons anba.
- a. Nomm trwa stil lamizik popiler? Rap, Jaz ek tekno se bann lexanp lamizik popiler.
- b. Kouma apel enn mizisien ki fer perkision?
- c. Enn saxofonis se enn kikenn ki zwe ki linstriman?
- d. Nomm 2 tip lorkes ki ena.
- e. Nomm 3 instriman lamizik oriziner Lenn.
- f. Nomm kat instriman ki servi dan sega tipik.
- g. Ki instriman a-van ki bann Rodrige servi?
- h. Seggae se enn fizion ant de tip lamizik. Nomm zot.
- i. Nomm 5 group santer / santez ki ti bien popiler dan bann lane 2000.
- j. Kouma apel instriman lamizik tradisionel Lekos?
- k. Nomm 5 santer/santez seleb ki souvan zwe piano kan zot pe sante.

In this image we can see a poster with some text and images.

<!-- image -->

## Anserkle tou bann mo ki kapav fer parti rezo lexikal lamizik dan tablo ki swiv.

Ena 11 mo pou to trouve.

Finn fer de lexanp pou twa. Bann mo-la kapav dan sans vertikal, orizontal ou diagonal.

| r   | i   | t   | m   | l   | a   | m   | s   | o   | n   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| k   | r   | a   | z   | s   | w   | a   | p   | a   | k   |
| k   | r   | o   | c   | k   | v   | e   | v   | s   | o   |
| l   | a   | s   | e   | g   | a   | t   | i   | e   | r   |
| a   | p   | v   | e   | r   | l   | a   | b   | r   | e   |
| r   | i   | s   | l   | a   | t   | s   | r   | e   | g   |
| i   | o   | p   | o   | m   | r   | o   | e   | t   | r   |
| n   | s   | c   | r   | o   | o   | n   | r   | e   | a   |
| e   | r   | s   | k   | f   | n   | o   | a   | o   | f   |
| t   | i   | a   | a   | o   | p   | r   | a   | a   | i   |
| m   | s   | w   | a   | n   | e   | a   | l   | l   | t   |
| j   | a   | z   | z   | n   | t   | i   | l   | t   | r   |
| s   | e   | r   | e   | n   | a   | d   | b   | o   | s   |

## Ribrik 3 Lortograf

## Lir sa text-la for

Lamizik akonpagn nou dan nou lavi. Kan nou ekout li, nou gagn lazwa dan nou leker ek li swagn nou stres.

- Ki son paret dan bann mo ki an gra?
- Ki bann let nou servi pou ekrir sa son-la dan Kreol Morisien?

Dan KM, nou servi let  'g+n'  pou reprezant son  [л]. Par exanp: sign, konpagnon, lakanpagn.

## Exersis 1

Ranpli bann tire. Swazir mo depi sa lalis-la.

## Sign , lagign , pengn , bengn , lalign

- a. Gran dimounn dir 'Al \_\_\_\_\_\_\_\_\_\_\_\_ dan lamer pou tir \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ '.

b. Gramatin li finn \_\_\_\_\_\_\_\_\_\_ enn kontra inportan.

- c.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_ to seve avan to sorti.

- d. Li pa konn ekrir lor \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

Dan KM, nou servi let  'c+h' pou reprezant son [t∫] ki nou trouv dan bann mo kouma cheke , chake, etc .

Dan KM, nou servi let 's+h' pou reprezant son [∫] ki nou trouv dan bann mo kouma brushing , flush, etc .

## Exersis 2

## Ranpli bann tire par ch ou sh.

1. \_\_\_\_\_\_ombo! Pa gagn drwa rant dan sa lasal-la.
2. Avan ki bann zelev rann zot travay, zot bizin \_\_\_\_eke si zot inn ekrir zot nom.
3. Zour fet, Amirah met so zoli \_\_\_\_\_ampal pou al kot so bann fami.
4. Rita pe al dan salon pou al fer enn bru\_\_\_ing ek enn \_\_\_ampooing.
5. Toule lane Anita kontan al fer \_\_\_\_opping dan Rozil.
6. Fer atansion to glise, ena enn ta \_\_\_iping lor sime.
7. Sa \_\_\_\_ow-la ti mari serye. Ti ena boukou son ek lalimier.

## Exercis 3

## Konplet sa mo-krwaze lor son [л].

In this image we can see a game board.

<!-- image -->

## Orizontal

- A Enn elevasion natirel ki bien larz ek bien ot lor enn terin
- B Rekiper enn kiksoz ki finn perdi avan
- C Enn mamzel ouswa enn madam ki viv avek enn misie
- D Enn pei dan Lerop
- E Exprim enn mekontantman dousman ek dan enn fason kot pa tro konpran
- F Ki finn sorti premie dan enn konkour

## Vertikal

- 1 Fer enn aksion ki permet enn kiksoz aret alime
- 2 Ki kontan grogne
- 3 Enn ti far ki alime-tengn kan pe double ouswa pe vire
- 4 Atrap kikenn/kiksoz par so kole
- 5 Bann tre orizontal ki ena dan kaye, lor ki bizin ekrir

## Ribrik 4 Gramer

## Kategori konzonksion

i. Ziad pou al laboutik ek Zakari pou al laplaz. ii. Ziad pou al laboutik kan Zakari pou al bazar.

## Ki diferans zot trouve ant sa de fraz-la?

Kouma dan laplipar lang, nou ena de tip konzonksion: bann konzonksion kordinasion ek bann konzonksion sibordinasion.

Bann konzonksion kordinasion relie de mo ou group mo lor mem nivo. i. Ziad pou al laboutik ek Zakari pou al laplaz.

Bann konzonksion sibordinasion relie de mo ou group mo lor diferan nivo. ii. Ziad pou al laboutik kan Zakari pou al bazar.

[Nou pou aprann plis lor sa dan Sapit 4, kan nou pou travay lor bann fraz konplex]

## 1. Konzonksion kordinasion

## Exersis 1

Soulign bann konzonksion kordinasion dan sa bann fraz-la.

1. Mo neve pe aprann zwe lagitar ek piano.
2. Madonna pou fer so konser an Fevriye ouswa an Mars.
3. Lamizik kapav rann nou ere me li kapav rann nou tris ousi.
4. Mo granparan pa konn ni Lady Gaga ni Maître Gims.
5. Adrien kontan sante e danse.

Ala enn lalis konzonksion kordinasion an KM:

e, me, oubien, ouswa, ou, ek, ni, swa

Ena kapav aparet dan bann konstriksion sinp kouma:

- Mo pou manz enn pom oubien enn zoranz.

Ena kapav aparet dan bann konstriksion redouble kouma:

- Mo pou manz ouswa enn pom ouswa enn zoranz.

Parmi bann konzonksion koordinasion, ena ki ena bann kontrint. Nou get ka ME ek NI .

ME aparet inikman dan konstriksion sinp.

## Exanp

Nou kapav dir:

- So lagitar pa roz me blan.

## Me nou PA kapav dir:

- So lagitar pa me roz me blan.

NI ousi enn konzonksion inpe spesial. Li kapav aparet dan enn konstriksion sinp ouswa redouble.

## Exanp

Nou kapav dir:

- Li pa konn zwe ravann ni tabla.
- Li pa konn zwe ni ravann ni tabla.
- Li konn zwe ni ravann ni tabla.

Kan li aparet dan enn konstriksion sinp, li oblize aparet avek enn mo ki ena enn sans negatif.

## Exanp

Nou kapav dir:

- Li pa konn zwe ravann ni tabla.

## Nou PA kapav dir:

- Li konn zwe ravann ni tabla.

## Exersis 2

Fer 2 fraz avek sak konzonksion kordinasion swivan:

i. me

ii. ou

iii. oubien

iv. swa

v. ni

vi. ek

## 2. Konzonksion sibordinasion

Enn konzonksion sibordinasion konbinn de fraz sinp; enn-la nou apel fraz prinsipal ek lot-la nou apel fraz sibordone . Fraz sibordone la depann lor fraz prinsipal la.

## Exanp

- Ziad pou al laboutik kan Zakari pou al bazar.

'KAN' li enn konzonksion sibordinasion parski li fer sa de fraz-la (i &amp; ii) zwenn. Nou remarke ki fraz (ii) depann lor fraz (i).

- (i) Ziad pou al laboutik. &amp;

(ii) kan Zakari pou al bazar.

- (iii) Ziad pou al laboutik. &amp;

(iv) si Zakari al bazar.

Ala enn lalis bann konzonksion sibordinasion ki nou ilitize souvan dan KM:

kan, si, akoz, pandan ki, depi (ki), alor ki, kouma

## Exersis 3

Fer enn fraz avek sakenn sa bann konzonksion sibordinasion-la.

## Kategori prepozision

## Prepozision, group prepozisionel ek konpleman

Enn prepozision, se enn mo invaryab; savedir ki li pa sanz form. Par exanp, dan, lor, avek, par, etc. Se enn mo ki kre enn lien ant bann mo ou group mo dan enn fraz.

Ex.:

Pron

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Group prepozisionel

Exanp:

Mo pe manz avek enn fourset . Mo telefonn pe sarze lor latab .

Sa bann group mo an gra la se enn group prepozisionel. Enn group prepozisionel koumans par enn prepozision.

<!-- image -->

## Atansion

Enn prepozision pa kapav existe dan enn fraz si pena nanye ki vinn zis apre.

Ex.:

*Mo finn aste legim dan.

## Exersis 4

## Met prepozision ki bizin dan bann fraz ki pe swiv.

- 1.

- Lucie finn met so plim \_\_\_\_\_\_ so plimie.

- 2.

- Robert pou al travay \_\_\_\_\_\_ so bann koleg.

- 3.

- Roshan pou al aste enn boutey delo \_\_\_\_\_\_ laboutik ki \_\_\_\_\_\_ lekol.

4. \_\_\_\_\_\_ letan pa bon zordi, Aisha pa pou zwe deor.

5. Sa liv-la \_\_\_\_\_\_ mwa, lotla-la \_\_\_\_\_\_ Shrutee.

Verb

Nom

## Fonksion group prepozisionel

Sa group mo ki li pe introdir vinn razout enn informasion dan fraz-la. Se seki nou apel enn fonksion konpleman .

Ex.3:

<!-- image -->

<!-- image -->

al Verb

dan Prep

<!-- image -->

Bann konpleman vinn azout enn informasion dan enn fraz, ki kapav konsern lespas, letan, manier, mwayin, koz, akonpagnman, etc. Nou pe liste de-trwa anba:

| Kriter      | Prepozision   | Lexanp                                                          |
|-------------|---------------|-----------------------------------------------------------------|
| Lespas      | akote ar/ek   | Bizin fer sa garson-la asiz akote ar profeser pou li aret koze. |
| Rezon       | akoz          | Akoz sa gro lapli-la, lekol inn fini boner zordi.               |
| Akonpagnman | avek          | Li pe partaz gato avek tou so bann kamarad.                     |
| Letan       | dan           | Tou so fami pe vinn promne Moris dan trwa mwa.                  |
| Mwayin      | par           | Zordi mopebizin al travay par bis.                              |
| Apartenans  | pou           | Sa liv-la pou Zan.                                              |

## Exersis 5

Razout enn konpleman ek bann prepozision ki finn donn twa.

1. Yousouf pou zwe badminton (avek)

\_\_\_\_\_\_\_\_.

2. Fanny pou poz so sak (akote ek)

\_\_\_\_\_\_\_\_\_\_\_.

3. Jean-Marie finn al pas vakans (kot)

\_\_\_\_\_\_\_\_\_\_.

4. (Akoz)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ , Ludmilla pa pou kapav vini.

5. Tania finn aste enn liv (pou)

\_\_\_\_\_\_\_\_\_\_\_\_\_.

## Ribrik 5 Prodiksion oral ek ekri

## Exersis 1

Obzerv sa bann zimaz-la.

In this image we can see a sign board.

<!-- image -->

In this image, we can see a red circle with a black line. Inside the circle, we can see a black smoke.

<!-- image -->

In this image, we can see a green color symbol.

<!-- image -->

- Ki obzektif sa bann sinbol-la?
- Ki sak sinbol pe rod dir? Ekrir enn fraz ki kapav akonpagn sakenn.

Sa bann sinbol-la inflians nou konportman pou fer nou azir dan enn sertin fason.

<!-- image -->

## Ala enn lafis ki to kapav trouve dan bann batiman.

## KAN ENA DIFE

## Si ou trouve ki ena dife kikpar:

## 1. FER BANN DIMOUNN OTOUR OU KONE

## 2. TELEFONN PONPIE LOR NIMERO 115

Donn zot sa bann informasion-la:

1. Ou nom ek nimero telefonn
2. Plas exakt kot ena dife
3. Kouma dife-la ete

## Konfirme ki bann ponpie finn bien gagn ou lapel ek tou bann informasion.

## 3. EVAKIASION

1. Kan tann alarm dife, tou dimounn bizin kit batiman deswit ek al dan plas rasanbleman.
2. Servi sorti ki pli pre avek ou.
3. Pa servi lasanser.
4. Pa arete pou ramas ou bann zafer personel.
5. Ed bann dimounn ki an difikilte pou sorti depi batiman.
6. Pa rerant dan batiman tan ki pa finn dir ki ou kapav rantre.

## 4. LAPEL

- Enn dimounn dan sak batiman/departman bizin ena responsabilite fer lapel pou fer enn check rapid. Bizin inform bann ponpie kan zot arive si zame mank kikenn.

## 5. TENGN DIFE

- Esey tengn dife si ou kapav fer li an sekirite. Servi bann ekipman apropriye ki ena.
- Dapre sirkonstans, bann ponpie pou gete si zot pou intervenir ou non.
- Sekirite dimounn bizin touzour pli inportan ki tengn dife.

In this image there is a silhouette of a person standing on the right side of the image. The person is wearing a cap. There are flames at the top of the image.

<!-- image -->

- a. Ki to kapav dir lor form ek striktir sa text-la?
- b. Ki tip fraz finn servi plis dan sa text-la? Kifer? Mod bann verb kapav ed twa pou reponn.
- c. Eski to trouve ki li pli fasil pou lir sa text-la, ki enn text naratif, deskriptif ou explikatif? Kifer to dir sa?
- d. Ki fonksion / lintansion deryer sa lafis-la?

## Text inzonktif

Sa text-la, se enn text inzonktif . Kouma bann sinbol ki nou finn trouve lao, enn text koumsa donn bann konsign, bann instriksion. Obzektif oter-la, se gid dimounn pou fer bann zafer dan enn lord.

Nou trouv boukou text inzonktif dan lavi toulezour: reset lakwizinn, enn lafis pou lav lame prop dan peryod epidemi, notis pou mont enn laparey ek tou mod-anplwa.

To konn lezot exanp?

## Exersis 3

Dan to lekol, ena enn klas lamizik kot ena boukou instriman. To profeser demann twa kree enn notis (ki pou kol lor miray) pou dir bann zelev kouma zot bizin konport zot dan klas ek kouma zot bizin servi/pran swin bann instriman lamizik la.

Fer sa travay-la ek prezant to notis devan klas.

In this image, we can see a musical note.

<!-- image -->

## Ribrik 6 Tradiksion

## Introdiksion

Tradiksion se enn zouti ki permet nou konpran seki dir ek ekrir dan enn lot lang. Si nou bizin tradir enn fraz/text depi lang A pou al ver lang B, nou apel lang A lang sours ek lang B apel lang sib .

Zot finn deza gagn lokazion dan ribrik Lektir - Konpreansion, fer enn exersis tradir bann mo depi KM ver Angle ek vis-versa, setadir depi Angle ver KM.

Isi, nou pou travay tradiksion inpe plis an-detay dan bann fraz ek bann paragraf. Ena plizier manier fer tradiksion e dan sak sapit nou pou konsantre lor enn manier.

## Get sa 2 exanp-la:

| Exanp 1 KM: Mo   | ti     | gagn enn   | lagitar   | pou       | mo   | laniverser.   |
|------------------|--------|------------|-----------|-----------|------|---------------|
| ANGLE: I got     | a      | guitar     | for my    | birthday. |      |               |
| Exanp 2          |        |            |           |           |      |               |
| ANGLE: My        | friend | was        | learning  | to        | play | the piano.    |
| KM:              | Mo     | kamarad ti | pe        | aprann    | zwe  | piano.        |

Kouma zot trouve, nou finn tradir mo pou mo. Lord bann mo ek zot fonksion pa finn sanze.

<!-- image -->

## Parkont, zot sirman finn remarke ki,

1. dan ka bann verb, kapav arive ki kan nou tradir, ena enn oubien de mo ki anplis:

got                                     ti gagn was learning                   ti pe aprann to play                               zwe

2. dan ka bann nom, nou pa servi enn lartik defini

the piano                         piano

ATANSION

<!-- image -->

## Exersis 1

## 1. Tradir sa bann fraz-la ver Angle.

- a. Mo frer ek mwa pe al konser demin.
- b. Rihanna finn koumans sante kan li ti ena 16-an.
- c. Granper pa ekout ragga; li pli kontan bann vie sante.
- d. Enn gran lorkes kapav ena ziska 100 mizisien.
- e. Dapre enn letid, deplizanpli zenn pe ekout jazz.

## 2. Tradir sa bann fraz-la ver KM.

- a. According to a study, Music could replace medicine before an operation.
- b. Afrobeats is a term which describes Westernised music from Africa.
- c. In my school, students can study Music for Cambridge exams.
- d. Most of the Mauritian musicians perform in hotels.
- e. Atif Aslam is my favourite singer.

## Ribrik 7 Literatir

Dan Grad 8, nou finn konsantre lor Literatir ekri , setadir nou finn etidie bann text literer atraver zot lekritir. Nou ti zet enn koudey lor de zanr literer: poem ek kont. Dan Grad 9, nou pou get bann lezot zanr literer kouma fab, teat, roman, nouvel ek ousi konpran ki ete Literatir oral .

## Ki ete literatir oral?

- Kan nou koz literatir, nou souvan pans bann text ki finn ekrir ek inprime. Me avan ki kreasion literer finn transmet par lekritir, li ti dabor oral. So mod transmision ti laparol.
- Pandan plizier siek, boukou sosiete dan lemond finn kree ek partaz bann text atraver loralite. Bann premie text literer kreolofonn finn ne dan bann kontext kot pa ti ena lekritir.
- Boukou bann prodiksion literer ki sorti depi Lafrik finn pran nesans ek finn transmet atraver loralite ek apre finn transkrir lor papie atraver lekritir.
- Literatir  oral  regroup  bann  prodiksion  oral  kouma  bann  sante  popiler,  bersez,  kontinn, lezand, etc.
- Sak pep ek sak kominote atraver lemond partaz kiksoz inik atraver so bann prodiksion oral (tradision, kilt, krwayans, valer moral, kiltir, etc.).

## Exersis 1

- a. Klas sak prodiksion literer ki finn liste dan kolonn apropriye.
- b. Fer  enn  ti  resers  pou  donn  omwin  enn  exanp  pou  sakenn. To  kapav  servi  exanp  bann prodiksion literer ki apartenir a bann lezot langaz/kominote osi.

## Finn fer enn exanp pou twa.

<!-- image -->

| Literatir ekri   | Literatir oral   | Exanp enn prodiksion literer             |
|------------------|------------------|------------------------------------------|
|                  |                  | Lezand Lezand Lerwa Arthur (Anglo-saxon) |
|                  |                  | Sirandann                                |
|                  |                  | Roman                                    |
|                  |                  | Proverb                                  |
|                  |                  | Nouvel                                   |

## Enn Rakonter dan Literatir oral

- Literatir oral inplike ki bizin ena kikenn ki rakont ou sant a ot-vwa sa bann prodiksion oral la.
- Enn dimounn ki propaz bann zistwar atraver so talan ek so lavwa apel enn rakonter ou enn konter tradisionel.
- Ekout enn rakonter, li enn pratik ki bien komin dan bann pep afriken ek bann kominote kreolofonn. Souvan, enn rakonter so rol se pas enn mesaz ou enn moral atraver so bann zistwar. Enn rakonter servi so limazinasion pou donn laparol bann zanimo, bann imin ou mem bann eleman imaziner.
- Kapte latansion ek diverti so loditwar se enn eleman inportan pou enn rakonter. Li fer so lodians riye ek amize atraver ton so lavwa, bann mo ki li servi ek latmosfer ki li kree kan li pe rakonte. Ena fwa, dan bann sware spesial, li pou kaptiv so lodians atraver plizier performans.

## Reflexion:

Ki diferans ena ant, ekout enn rakonter ki pe rakont enn zistwar ek lir enn zistwar ki dan enn liv?

9

## Literatir oral dan kontext Moris

Moris ena boukou prodiksion oral ki bann zoli travay literer. Sa bann prodiksion oral la, finn lege par bann zenerasion avan, ek souvan nou pa tro kone kisann-la finn invant zot. Bann proverb ek sirandann an Kreol tom dan sa kategori-la. Ena ousi bann lezand ki bann gran-dimounn lontan ti pe rakonte.

## Fanfan, enn rakonter dan kontext Moris

In this image we can see a person wearing a hat and holding a drum.

<!-- image -->

https://www.lemauricien.com/article/lesegatier-emblematique-fanfan-est-decedece-matin-a-88-ans/

<!-- image -->

Travay resers

Fer enn interview ek enn vie dimounn ou enn paran dan to lantouraz ki konn bann zistwar Fanfan. Partaz zistwar-la ek to bann kamarad klas ek to profeser.

## Mo pase larivier Tanie, enn bersez popiler ki form parti patrimwann oral Moris

Enn bersez,  li  enn  konpozision  mizikal  ki  destine  a  bann  zenn  zanfan.  Malgre  sa,  dimounn ninport ki laz apresie enn bersez parski li dous ek li fer nou rapel bann souvenir.

Enn bersez ena bann parol sinp ki fasil pou kapte ek ki an zeneral repetitif osi. Enn bersez ki finn bers lanfans boukou bann Morisien se Mo pase larivier Tanie.

Fanfan,  de  so  vre  nom  Louis  Gabriel  Joseph (19302018), enn  segatie  ki  finn  donn  lepep  Moris  enn  ris leritaz sega tipik. Mem si li finn gagn popilarite atraver sega, li ti enn rakonter egalman.

Parmi  bann  zistwar  ki  li  ti  pe  rakonte  ena zistwar kayman, zistwar sat ek tig, etc.

## 'Mo pase larivier Tanie'

Mo pase Larivier Tanie, Mo zwenn enn vie granmama. Mo dir li ki li fer la, Li dir mwa li lapes kabo.

Way, way, me zanfan, Fo travay pou gagn son pin. Way, way me zanfan, Fo travay pou gagn son pin.

Gran dimounn ki ou'a pe fer, Sa ki vie res dan lakaz. Li dir mwa mo bien mizer, Me ou ena tou mo kouraz.

Way, way, me zanfan, Fo travay pou gagn son pin. Way, way me zanfan, Fo travay pou gagn son pin.

In this image we can see a river flowing. There are rocks and plants.

<!-- image -->

## Exersis 2

- a. Eski to finn deza tann sa sante-la? Si wi, partaz to experyans ek to bann kamarad ek profeser.
- b. Ki bann tem ki kapav resorti dan parol sa sante-la? Dan ki kontext to panse sa sante-la finn kree?
- c. Eski bann tem ki finn aborde dan sa sante-la ankor form parti nou realite? Si wi ou non, zistifie to repons.

<!-- image -->

## Travay resers

Fer enn ti resers lor bann diferan interpretasion ki finn fer pou sa sante-la pou fer li vinn popiler. (to kapav liste bann diferan artis ki finn sant li)

## Prolonzman

Mont to prop koregrafi sa sante-la ek enn group kamarad. Avek led to profeser, to kapav ousi interpret ek sant li pou enn evennnman dan lekol kouma Music Day.

This image consists of a river flowing through the forest. The river is in the middle of the image. There are many rocks in the river. The background of the image is blurred.

<!-- image -->

Sapit 2

## Bann invansion

- Sapit 2

Kreol Morisien

|

29

## Ribrik 1 Lektir-Konpreansion

Lir sa text-la, answit reponn bann kestion.

## SMARTPHONE

In this image we can see a mobile phone on the table.

<!-- image -->

Smartphone kapav fer enn pake zafer. Apart telefone, nou kapav ekout lamizik, fer video chat,  servi  map pou trouv nou semin. Me mem si zordizour zot nepli resanble zot bann anset , fode pa nou bliye ki zistwar bann smartphone finn koumanse ver lafin 19 em  siek.

Avan  linvansion  telefonn,  laplipar  dimounn  ti  koz ek  zot  kamarad  an  fas-a-fas. Apie ,  lor  seval  ouswa bourik,  dan  kales  ouswa  saret,  zot  ti  al  vizit  zot kamarad ek zot bann fami pou fer konversasion. Pou bann dimounn ki ti rest pli lwin, ti ena let. Me enn let ti pran boukou letan pou arive dan bann lane 1800. Anplis, li ti kout kas.

Se  probableman pou sa bann rezon-la ki, an 1842, enn invanter ameriken,  Samuel  Morse,  finn  invant enn masinn ki kapav avoy bann mesaz lor bann long distans.  Li  ti  apel  masinn-la  enn  telegraf.  Me  se  an 1844 ki li finn kapav avoy premie telegram parski li ti bizin atann ki li gagn ase kas pou li instal enn lalign telegraf ant Baltimore ek Washington D.C. Telegraf ti servi enn sistem pwin ek tire ki ti apel kod Morse. Me telegraf pa ti touzour pratik parski dimounn ti bizin sorti dan zot lakaz pou al avoy mesaz-la dan enn biro. Answit, pa tou dimounn ki ti konn kod Morse e donk se enn operater telegram ki ti pe avoy bann mesaz.

Se dan sa kontext-la ki bann invanter ti reflesi pou amelior kominikasion. De dant zot, enn Ameriken, Graham Bell, ek enn Italien, Antonio Meucci, pou reisi fer kominikasion progres dan enn fason remarkab, gras-a zot invansion. Alexander Graham Bell finn ne le 3 Mars 1847 dan Edinbour, Lekos. Etandone ki so papa ti enn profeser ki ti montre elokision, Alexander Graham Bell ti swiv so exanp e kan li finn fini lekol, li finn vinn enn profeser elokision ek lamizik. So travay finn amenn li ansegn bann zelev sourd e se dan kad sa travay-la ki li finn koumans reflesi lor posibilite fer son travers atraver bann lalign telegraf. Li finn fer boukou experyans lor kouma pou fer kouran sarye son e an 1876, avek koudme so asistan Thomas Watson, li finn reisi fer son sorti depi enn lasam pou al dan enn lot lasam. Apartir sa moman-la, li ti res zis pou perfeksionn so kreasion.

Pandan ki Bell ti pe reflesi lor so kreasion, enn lot invanter Antonio Meucci, li ousi ti pe reflesi lor enn mwayin pou amelior kominikasion long-distans. Meucci ti enn Italien ki ti ne le 13 Avril 1808 dan Florans. Ant laz 15 ek 17-an, li finn etidie pou vinn enn inzenier simik ek mekanik me

malerezman parski so fami pa ti ena ase kas, li ti bizin aret so letid. Nou retrouv li an 1834 kouma enn teknisien dan Teat Pergola. Se dan sa kontext-la ki li invant enn telefon akoustik ki permet kominikasion ant lasal kontrol ek lasenn. Apre enn peryod ki li pase dan Kiba, Antonio Meucci emigre dan Lamerik kot li kontign travay lor so bann invansion. Se koumsa ki an 1856 li invant enn laparey ki li apel telettrofono.

Se prinsipalman travay sa de invanter-la ki Listwar finn retenir kouma bann grandper nou bann telefonn aktiel. Li bon ki nou rapel zot laprosenn fwa ki nou servi nou smartphone; si pa ti ena zot travay, pa kone kot nou ti pou ete lor sime kominikasion long-distans.

## Kod Morse

A

w

G

9

8

9

0

In this image, we can see a table with some numbers.

<!-- image -->

Sey avoy to kamarad enn mesaz par kod Morse. Enn pwin tap vit. Enn tire bizin tini pli lontan.

| Enn tire =                            | 3 pwin   |
|---------------------------------------|----------|
| Lespas ant banndiferanpartiennmemlet= | 1 pwin   |
| Lespas ant bann diferan let =         | 3 pwin   |
| Lespasantbannmo=                      | 7 pwin   |

To kapav ousi konverti to bann mesaz an kod Morse si to al lor:

1. www.unitconversion.
2. info/texttools/morse-code.

Oubien to kapav avoy bann mesaz an Morse lor morsecode.me

## 1. Reponn par Vre (V) ou Fos (F). Zistifie sak repons.

In this image we can see a table with some text on it.

<!-- image -->

|                                                                | V/F        |
|----------------------------------------------------------------|------------|
| a. Zistwar smartphone finn koumanse avan lane 1800.            | __________ |
| b. Telefonn finn obliz dimounn deplase pou koz ek zot kamarad. | __________ |
| c. Alexander Graham Bell ti pli vie ki Samuel Morse.           | __________ |
| d.ThomasWatson finn kolabore pou invant telefonn.              | __________ |
| e. Meucci ek Bell ti al memlekol.                              | __________ |

2. Ki de zafer enn smartphone kapav fer?
3. Donn 1 dezavantaz kominikasion par let.
4. Kouma nou kone ki instalasion lalign telegraf ant Baltimore ek Washington D.C. ti kout ser?
5. Dapre twa, kouma travay ki Bell ti fer avek bann zelev sourd relie avek so travay lor telefonn?
6. Kifer nou apel Bell ek Meucci 'granper' bann telefonn aktiel?
7. Explik bann mo an-gra:
- a. bann anset
- b. invanter
- c. pratik
- d. perfeksionn
- e. prinsipalman
12. 8.

## 9. Trouv bann tradiksion pli apropriye pou bann mo ek expresion ki swiv, dapre manier ki finn servi zot dan pasaz.

| Kreol Morisien   | Angle       |
|------------------|-------------|
| resanble         |             |
| kas              |             |
|                  | probably    |
|                  | telegram    |
|                  | compared to |
| elokision        |             |
| reflesi          |             |
|                  | improve     |

In this image we can see a paper with some text and a picture of a light bulb. There are some papers and clips.

<!-- image -->

## Ribrik 2 Vokabiler

Dan Sapit 1, nou finn get bann sinonim.  Dan Sapit 2, nou pou get bann antonim.

## Antonim

Enn antonim, se enn mo ki par so signifikasion, opoz limem avek enn lot mo. Se enn mo ki ve dir lekontrer enn lot mo.

## Exanp 1: Enn nom

Mo partner sa.

Mo rival sa.

## Exanp 2: Enn azektif

Sa liv zistwar la bien zoli. Sa liv zistwar la bien vilin.

## Exanp 3: Enn verb

Mo aksepte ki zot ale.

Mo refize ki zot ale.

## Exanp 4: Enn adverb

Erezman mo pa pou vinn kot twa tanto. Malerezman mo pa pou vinn kot twa tanto.

## Not 1

Parfwa, enn mo kapav ena plizier signifikasion. Lerla, so antonim pou depann lor signifikasion ki li ena.

## Exanp

Sa lisien-la so karakter bien dou. Sa lisien-la so karakter bien for/move.

Sa mang-la bien dou. Sa mang-la bien amer/eg.

## Not 2

Bann antonim kapav ousi forme apartir bann mo ki zot opoze, kot azout enn prefix avek mo-la. Enn prefix, se enn eleman ki plase dan koumansman enn mo e ki vinn modifie so sans.

## Exanp 1

Erezman mo pa pou vinn kot twa tanto. Malerezman mo pa pou vinn kot twa tanto.

## Exanp 2

Li konpetan dan so travay. Li inkonpetan dan so travay.

## Exersis 1

## Ranplas mo souligne par so antonim

- a. Ki diferans ena ant enn dekouvert ek enn invansion?
- b. Mekanisien pou remet sa pies-la dan moter.
- c. Ena plizier invansion ki finn gat lavi bann dimounn.
- d. Sa gadjet-la bien itil pou koup legim.
- e. To kapav debrans televizion, silteple?
- f.  Samem pli tipti invansion ki finn kree sa lane-la.
- g. Sa lantenn-la mari ot.
- h. Akoz siklonn, avion pa pou kapav dekole.
- i.  Eski to kone ki invanter pli popiler?
- j.  Enn kreasion, se enn zefor kolektif.

In this image we can see a diagram.

<!-- image -->

## Exersis 2

## Rod antonim bann mo swivan ek fer enn fraz ek zot.

- a. Ranze
- b. Pov
- c. Demare
- d. Rise
- e. Perdi
- f.  Alime
- g. Drwat
- h. Invanter
- i.  Kapasite
- j.  Otomatik

## Exersis 3

1. Relie sak mo ek so definision. Finn fer enn exanp pou twa.

| Mo                                          | Definision                                                                                                                                                                                                                                                                                                                                                                                                                         |
|---------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Prototip Patant Pionie Teste Inplemantasion | Aksion konkretiz ou met an-mars enn etap apre ki finn pran enn desizion lor kouma pou prosede Enn drwa ki bann invanter gagne lor zot invansion pou anpes bann lezot kokin, reprodir ek servi zot invansion Enn dimounn ou enn group ki finn lans zot dan kreasion kiksoz pou premie fwa Premie model enn kiksoz ki finn invante apre enn lexperyans. Li ofer enn avan-gou pou prodwi ki pe vini. Sey kiksoz pou verifie si li bon |

## Exersis 4

## Anou servi nou imazinasion pou vinn bann savan.

Propoz enn invansion itil ki kapav ed limanite dan lefitir pou sak domenn swivan. Donn enn nom pou sak invansion ek explike kouma li itil.

Domenn

lanvironnman

lasante

sosial

lagrikiltir

ledikasion

## Exanp

Domenn lanvironnman

Nom invansion: ' Gaz absorb-tou '

Gaz absorb-tou enn formilasion gaz ki anti lefe-ser, anti-karbonn ek ki ed absorb enn dizenn gaz toxik ki emet par tiyo lesapman bann veikil ek bann lizinn.

In this image, we can see a picture of a robot and a picture of a laptop.

<!-- image -->

## Trouv bann invansion ki finn revolisionn lemond dan sa griy-la. Ena 18 mo ki bizin trouve

| K   | T   | E   | M   | O   | R   | A   | B   | S   | P   | O   | B   | T   | M   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| A A | E   | E   | P   | F   | K   |     | M A | T   | J   | O   |     | D   | I   |
| M S | R   | L   | A   | R   | O   | U   | G   | R   | Y   | U   | U   |     | K   |
| E U | Z   | E   | E   | R   |     | T   | S   | E   | I   | L   | S   | J   | R   |
| R N | L   | L   | E   |     | V   | E   | D   | D   | N   | K   | O   | A   | O   |
| A N | K   |     | E   | A   | E   | I   | X   | A   | O   | R   | L   | Q   | S   |
| E I | F   | K   |     | I   | Z   | L   | Z   | G   | N   | E   | X   | P   | K   |
| O L | S   |     | T   | I   | J   | R   | D   | I   | N   | T   | R   | A   | O   |
| B I | W   |     | R   | P   | A   | A   | T   | X   | O   | A   | F   | R   | P   |
| N S | F   | I   |     | L   | N   | D   | I   | M   | F   | N   | Q   | A   | N   |
| P I | H   |     | S   | Y   | P   | I   | Q   | F   | E   | I   | K   | T   | L   |
| Y N | O   |     | I   | V   | A   | O   | J   | R   | L   | D   | V   | O   | T   |
| N E | Q   |     | T   | R   | K   | R   | D   | S   | E   | R   | E   | N   | G   |
| S P | L   |     | E   | I   | P   | A   | P   | W   | T   | O   | H   | E   | P   |
| L A | S   |     | A   | N   | S   | E   | R   | T   | Z   | F   | C   | R   | D   |
| A T | E   |     | M   | O   | M   | R   | E   | T   | B   | S   | S   | M   | G   |
| T   | E   | L   | E   | S   | K   | O   | P   | G   | Z   | N   | A   | Y   | T   |

## Ribrik 3 Lortograf

## Di/j

Kan enn mo sorti depi Franse, pou pli souvan servi let 'd+i' pou reprezant son  [d    ] kouma dan mo media.

Kan enn sorti depi enn lot lang kouma Angle ou enn lang indien, pou pli souvan servi 'j' pou reprezant son [d    ]  kouma dan joker.

| Franse/Angle ou lang indien   | Kreol Morisien   |
|-------------------------------|------------------|
| media                         | media            |
| joukal                        | joukal           |
| diadème                       | diadem           |
| diarrhée                      | diare            |
| jet                           | jet              |

## Exersis 1

## Ranplas bann tire par 'di' ou 'j' .

- a. Mo kontan ekout dimounn rakont zistwar lor \_\_\_\_ab.

- b. \_\_\_\_abet se enn maladi danzere.

- c. Met to \_\_\_\_aket lor twa, pe fer fre deor.

- d. Mo kontan manz ba\_\_\_\_a ek gato pima.

- e. Sindy pe met ka\_\_\_\_al anba so lizie.

- f.  Dan Sidafrik ena boukou langaz ek \_\_\_\_alek.

## Exersis 2

Rod omwin 2 lezot mo avek 'di'  ek 'j' .

## Exersis 3

Fer enn fraz apartir sa bann mo ki to finn trouve.

## Ribrik 4 Gramer

## Kategori Azektif

Enn zenn madam ti met enn ti rob ble ek enn larz sapo blan . Li ti pare pou al Flic-en-Flac. Kan li finn ariv laba, li finn trouv enn gran laplaz avek zoli disab dore. Letan ousi ti bon. Vit, li finn instal so serviet anba enn gro pie ek desid pou al plonz dan lamer.

Kouma nou remarke dan sa text-la, ena plizier mo ki servi pou dekrir bann diferan nom. Nou apel zot bann azektif .

Enn azektif, se enn mo ki ena enn sans ek li donn enn indikasion lor kalite bann dimounn, bann zanimo, bann landrwa ek bann obze.

## Exanp

1. Enn zanfan intelizan
2. Enn gro lisien
3. Enn zoli landrwa
4. Enn pantalon rouz

## Exersis 1

- i. Relev leres azektif ki ena dan text lao la.
- ii. Anserkle ki nom li pe akonpagne.

In this image, we can see a diagram. In the diagram, we can see a machine, a wrench, a light bulb, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench, a wrench

<!-- image -->

## Kategori Adverb

Alor ki bann azektif kalifie zeneralman bann nom, bann adverb kapav donn linformasion lor bann lezot kategori ousi. Enn adverb kapav azout enn linformasion lor enn verb, enn azektif, enn fraz ou enn nom.

Bann adverb kapav indik plizier diferan tip sans.

## 1. Bann adverb manier

Bann adverb ki donn enn informasion lor manier enn aksion deroule ou manier enn dimounn azir.

## Exanp

Kan mo koz poliman avek li, li koz brit avek mwa.

## 2. Bann adverb lokatif

Bann adverb ki indik enn landrwa.

## Exanp

Mo ser pe aprann deor .

## 3. Bann adverb tanporel

Bann adverb ki donn enn indikasion lor moman kan enn evennman finn pase, kantite letan enn evennman inn pran pou deroule oubien kantite fwa enn evennman deroule.

## Exanp

Rita ti vinn kot mwa resaman .

Mo granmer pou res kot mwa lontan .

Mo al sinema souvan .

## 4. Bann adverb degre

Bann adverb ki indik kantite.

## Exanp.

Rita extra kontan so garson. Zohra ena boukou liv. Sophie bien zoli.

Shanaya kondir pli vit ki Emma.

## Exersis 2

## Soulign adverb dan sak fraz.

1. Jessica manz boukou.

2. Sa rob-la tro larz pou mwa.

3. Li pou travers larivier alanaz.

4. Sarah pe fer sa travay-la zantiman.

5. Adrien sant bien.

6. Lontan mo ti kontan al sinema.

7. Li enn zanfan bien malere.

8. Kevin dormi mwins ki mwa.

9. Dan Moris, nou kondir agos.

10. Lapli tonbe frekaman dan Curepipe.

## Exersis 3

## Swazir enn mo dan lalis anba pou ranpli bann tire.

kontan

rapid

bien

dir

vit

1. Rithvi galoup \_\_\_\_\_\_\_\_ ; li finn mem gagn meday lor.

2. Zordi mo extra \_\_\_\_\_\_\_\_ ; mo pou, anfin, al get sa fim mo ti anvi la.

3. Mo kontan sant karaoke mem si mo pa sant \_\_\_\_\_\_\_\_.

4. Savannah enn tifi bien \_\_\_\_\_\_\_\_ ; li finn sorti premie dan lekours pou Sports Day.

5. Nou paran travay extra \_\_\_\_\_\_\_\_ pou nouri nou lafami.

## Exersis 4

## Ranpli bann tire avek enn mo depi kategori ki indike ant braket.

1. Toulezour dan zournal, nou tann dir ena aksidan \_\_\_\_\_\_\_\_ (azektif).

2. \_\_\_\_\_\_\_\_ (adverb) mo finn manz brinzel.

3. Mo ena \_\_\_\_\_\_\_\_

(adverb) boukou liv ki twa.

4. Mo nies enn \_\_\_\_\_\_\_\_

(adverb)

\_\_\_\_\_\_\_\_ (azektif) tifi.

## Ribrik 5 Prodiksion oral ek ekri

## Exersis 1

## Observ sa de zimaz-la ek reponn bann kestion ki finn poze apre.

In this image we can see a group of people. There are emojis.

<!-- image -->

In this image, we can see a text on the screen.

<!-- image -->

- a. Ki diferans to trouve ant sa de text-la ?
- b. Aster-la, get bann mo ki finn servi ek fason bann fraz finn ekrir. Ki to remarke ?
- c. Dan ki fason dimounn ki finn ekrir sa de text-la adres zot dimounn a ki zot pe kontakte ?
- d. Apartir to bann observasion, ki relasion kapav ena ant dimoun ki inplike dan sa de konversasion-la.

Sa de text-la, se 2 exanp korespondans. Enn korespondans, se enn text ki enn dimounn (enn emeter ) ekrir a enn lot dimounn (enn resepter ) . Ena de stil korespondans:

## 1. Stil informel

Stil informel servi ant de dimounn ki pros ek ki ena bann relasion amikal ou familial. Bann mo ki servi kapav familie ouswa kouran. Bann striktir fraz mwins konplex ek kapav ena bann mark oralite.

## 2. Stil formel

Stil formel servi ant de dimoun ki ena enn relasion profesionel. Sa stil-la ousi servi kan emeter pa konn resepter personelman. Dan sa stil-la, servi enn vokabiler kouran ek bann fraz pli striktire. Pena mark oralite. Ena ousi bann formil salitasion ki servi pou met enn form distans ek respe ant de dimounn-la.

## Lir sa text-la ek diskit lor bann kestion ki vinn apre.

15, Rue du Tertre Montmartre Paris 15 Desam 2019

Alo Amanda, Ki manier, to bien?

Mo pe ekrir twa pou partaz bann top moman ki mo  pe  pase  pandan  mo  vakans  dan Lafrans. Fer enn semenn depi ki mo'nn ariv isi e mo pe res kot mo matant dan Montmartre, enn kartie ki trouv dan Paris. Mo  mari  kontan  seki  mo  pe  dekouver, mem si pe fer bien fre isi. Paris enn zoli lavil kot ena boukou plas pou vizite. Depi ki nou'nn arive, mo pe al bann plas ki zame mo ti panse kapav existe. Mo mari kontan!

Yer, avek mo paran, nou'nn vizit enn mize ki apel 'Musée des Arts et Métiers' .

In this image we can see a photo frame.

<!-- image -->

Se  enn  plas  mazik  kot  mo'nn  fer  boukou dekouvert. To pa pou krwar! Mo'nn trouv premie kalkilatris mekanik ki finn invante. Enn misie ki apel Blaise Pascal finn invant sa pou ed so papa ki ti bizin fer bokou kalkil pou so travay. Pascal finn gagn lide kree sa masinn-la an 1642 ek li ti ena zis 19-an. To realize, Mandou? 19-an! E sa finn pran li trwa lane ek sinkant prototip pou li reisi dan so proze. Extra non? Mo pe avoy twa enn ti foto sa masinn-la pou to kapav trouv li. Bann-la apel sa enn paskalinn ek ena zis 8 ki reste zordi!

Si bizin rakont tou lor mo vakans, mo kapav res ekrir mem. Me mo gard inpe zistwar pou twa kan mo retourn Moris. Mo espere tou korek pou twa. Fer enn alo tou bann kamarad lekol ek bann profeser pou mwa.

Nou zwenn biento. Bizou,

<!-- image -->

## Kestion

- a. Kouma apel enn text koumsa?
- b. Dapre twa, ki relasion ena ant Amanda ek Anna? Idantifie bann eleman ki montre sa.

## Karakteristik enn let informel

Sa text-la se enn let informel . Kouma to finn trouve dan Exersis 1, stil informel servi kan enn emeter pe ekrir enn lot dimounn kouma so kamarad ouswa so fami pou rakont li bann zafer plito personel, parey kouma dan ka Anna ek Amanda.

To finn ousi sirman remarke ki let ki Anna pe ekrir, li swiv enn form presi avek bann eleman kouma dat, ladres, bann formil salitasion. Sa bann eleman-la fer parti bann partikilarite enn let, ki li informel ou formel . Li  inportan respekte zot.

## Exersis 3

## Anou ekrir enn let informel

Dan sa ankadre-la, to pou trouv bann eleman ki inportan kan pe ekrir enn let informel. Observ bien sa striktir-la ek ekrir enn let to kamarad ou enn fami pou partaz avek li enn zistwar personel ki finn ariv twa.

Ekrir to ladres isi Nimero, Nom lari Nom lavil/vilaz

Ekrir dat isi

Koumans avek enn formil salitasion:

Mo kamarad…

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Formil salitasion pou fini to let

Nou zwenn apre Salam

To signatir/to nom

## Ribrik 6 Tradiksion

Kan nou fer tradiksion, kapav arive ki nou bizin gard enn mo parey kouma dan langaz sours. Souvan nou fer sa parski mo-la pa existe dan langaz sib.

Bizin note ki mo-la gard so form orizinal (setadir ki li ekrir parey).

| Exanp 1    |                                                                                                |
|------------|------------------------------------------------------------------------------------------------|
| KM:        | Mofinn manz enn pizza dan Bagatelle.                                                           |
| ANGLE:     | I ate a pizza in Bagatelle.                                                                    |
| Exanp 2    |                                                                                                |
| ANGLE: KM: | Do not download any software on that computer. Pa download okenn software lor sa ordinater-la. |

## Exersis 1

## Tradir sa bann fraz-la ver Angle.

- a. Lapli finn tonbe non-stop yer swar.
- a. Roentgen finn invant masinn X-Ray an 1895.
- b. Duster ti servi pou efas lakre lor tablo.
- c. Larbit finn soufle parski Jenny ti offside.
- d. Nou bizin anrezistre lor website MITD pou nou kapav swiv kour.

## Exersis 2

## Tradir sa bann fraz-la ver KM.

- a. There is a new duty-free shop at the airport.
- b. The teacher asked us to do our project on bristol paper.
- c. My grandfather watches Westerns on Sundays.
- d. The organisers had to refund the money because it has been raining.
- e. Kevin's father now works in an offshore bank.

## Ribrik 7 Literatir

## Anou dekouver bann fab

Enn fab se enn zistwar kourt ki ena pou obzektif donn enn leson lor lavi. Anou lir enn fab ki finn adapte an Kreol depi enn fab La Fontaine.

Exersis 1

In this image I can see the sky, clouds, trees, grass, and the sky is blue.

<!-- image -->

## Apre ki zot finn lir fab Zistwar Korbo ek Zako, diskit lor bann kestion ki swiv pou konpran inpe plis fason ki enn fab organize.

1. Komie personaz ena dan sa fab-la? Ki rol sak personaz?
2. Kouma zistwar-la koumanse?
3. Ki bann levennman ki deroule dan fab-la? Idantifie sak evennman.
4. Kouma fab-la fini?
5. Ki moral ouswa leson lor lavi sa fab-la pe transmet?

|    | Bann konpozant ki nou trouve dan enn fab                                                 | Dan Zistwar Korbo ek Zako                                             | Dan Zistwar Korbo ek Zako                                                                                |
|----|------------------------------------------------------------------------------------------|-----------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
|  1 | Dan so introdiksion, enn fab prezant sitiasion kot zistwar-la deroule ek bann personaz . | Kot fab-la pe deroule?                                                | Pre kot enn pie.                                                                                         |
|  1 | Dan so introdiksion, enn fab prezant sitiasion kot zistwar-la deroule ek bann personaz . | Ki personaz ena dan sa fab-la?                                        | Korbo ek Zako.                                                                                           |
|  2 | Dan so devlopman, enn fab kontenir enn evennman ki pou amenn enn lot evennman            | Ki valer sak personaz reprezante?                                     | Korbo reprezant kredilite. Zako reprezant flatri.                                                        |
|  2 | Dan so devlopman, enn fab kontenir enn evennman ki pou amenn enn lot evennman            | Ki premie evennman deroule dan fab-la? Ki deziem evennman ki deroule? | Zako trouv Korbo ek koumans flat li. Korbo ouver so labous pou sante ek bibas ki ti dan so labous tonbe. |
|  3 | Enn leson lor lavi                                                                       | Ki leson ki sa fab-la kontenir?                                       | Parol ki tro dou kapav tronp ou.                                                                         |

## Analiz Zistwar Liev ek Torti dapre tablo konpozant enn fab.

In this image we can see a painting. In the painting we can see a rabbit, a bird, a tree, a grass, a flower, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird, a bird

<!-- image -->

## Analiz bann konpozant Zistwar Liev ek Torti

|   1 | Sitiasion ek personaz.                           | Kot fab-la pe deroule?                                           |
|-----|--------------------------------------------------|------------------------------------------------------------------|
|   1 | Sitiasion ek personaz.                           | Ki bann personaz ena dan sa fab-la?                              |
|   2 | Devlopman (enn evennman ki amennennlot evennman) | Ki valer sak personaz reprezante?                                |
|   2 | Devlopman (enn evennman ki amennennlot evennman) | Ki premie evennman ki deroule dan fab-la?                        |
|   2 | Devlopman (enn evennman ki amennennlot evennman) | Ki bann lezot evennman ki deroule apartir sa premie evennman-la? |
|   3 | Enn leson lor lavi                               | Ki leson sa fab-la kontenir?                                     |

In this image we can see a cartoon image of a rabbit and a tortoise on the ground. In the background there are trees, hills and the sky.

<!-- image -->

## Sapit 3

## Mwayin transpor

## Ribrik 1 Lektir-Konpreansion

## Lir sa text-la, answit reponn bann kestion.

## PREMIE DEKOLAZ

In this image we can see an airplane on the runway.

<!-- image -->

Mo  leker  ti  pe  bat  extra  for  kan  mo  finn  rant  dan aeropor.    Ti  ena  telman  boukou  dimounn  ki  mo  ti inpe abriti . Mo mama finn fer mwa atrap mo paspor ek biye dan mo lame pou mo kapav al anrezistre.

-  Dres to linz lor twa! Trap to valiz! Met to sak bien lor to zepol! Pa bliye met to palto kan to arive!

Mo mama ti kouma enn mous zonn. Mo krwar li ti pe plis gagn per ki mwa.

Mo papa, li, kom dabitid, ti vey lor mo sekirite.

-  Vey to bann zafer! Pa koz ek dimounn ki to pa kone! Si  to  perdi,  al  lapolis!  Gard  nimero to matant dan to latet!

Mo ti pe al lotpei kot mo matant ki finn invit mwa pou vakans Desam. Ti premie fwa ki mo ti pe vwayaz tousel e mo ti inpe trakase .  Selman mo pa ti pe les mo bann paran trouve.

Avek enn lame, mo finn met mo sak lor mo zepol ek mo finn trap mo valiz. Dan lot lame, ti ena mo paspor ek mo biye. Mo finn anbras mo mama ek mo papa e mo finn avans ziska devan enn kontwar kot ti ena enn long lake.  Ti inpe difisil tini tousala anmemtan.  Rezman lake-la ti avans dousman-dousman. Mo ti santi mwa bien fier. Finalman, bann prosedir finn fini e apre enn dernie salam, mo finn pran direksion avion. Dis minit plitar,  enn lavwa finn anons, 'Vol MK729 pou Paris, anbarkman laport 23B.' Mo finn degaze mo finn ale. Mo finn donn mo biye otes ki ti devan laport la e mo finn rant dan avion.

Ti ena enn steward devan laport. Kan mo finn pas kot li, li finn dir mwa, 'Bonzour. Bienveni abor.' Mo finn montre mo tiket e li finn montre mwa dan ki direksion mo bizin ale.  Mo plas ti nimero 15F. Pa ti fasil pou avanse. Sime ti bloke detanzantan parski bann pasaze ti pe met zot bann bagaz dan enn kof lao zot latet. Kan mo finn ariv dan mo plas, mo'nn dekouver ki mo ti kot iblo. Sa finn fer mwa plezir parski mo ti pou kapav get peisaz kan dekole ek ateri. Mo pa ti ankor kone sa ler-la ki sa plas-la kapav ousi bien anbarasan . Mo finn rant dan mo plas e mo finn koumans lir enn liv ki montre ki bizin fer si ena enn irzans . Sa finn fer mwa gagn per e mo finn poz li dan so plas. Bien vit, avion finn ranpli e de misie finn vinn asiz kot mwa. Apenn zot finn asize, zot finn met enn mask lor zot lizie ek zot finn dormi. Avion finn koumans roule e mo finn koumans tranble. Mo ferm mo lizie, mo fer enn lapriyer. Kan mo reouver zot, nou ti deza dan ler.

Mo bizin dir ki tou finn bien pase pandan mo vol. Mo finn get de fim, apre mo finn dormi. Pandan premie fim, bann otes finn servi manze. Mo finn bien riye kan mo finn get zot pous zot ti saret koumadir marsan konfi. Manze-la ti bien bon!

Kan mo finn leve mo'nn trouv enn espes azitasion otour mwa… Boukou dimounn ti pe debout kot twalet e detrwa lezot ti pe fouy dan zot bann zafer ki trouv dan kof lao zot latet. De misie akote mwa la ti finn leve. Inpe ezitan, mo finn demann zot ki pe arive. Enn ladan finn get mwa e li finn dir:

- Pre pou arive! Bann dimounn pe remet zot korek pou pa trouve ki zot finn pas douz-er-tan dan avion.  Douz-er-tan! Mo pa ti le kwar. Sa vwayaz-la finn pas extra vit. Mo ti pare pou fer enn lot vwayaz bien vit.

## 1. Reponn par Vre (V) ou Fos (F). Zistifie sak repons.

In this image, we can see a table with some text on it.

<!-- image -->

|                                                  | V/F        |
|--------------------------------------------------|------------|
| a. Tou dimounn ti abriti dan aeropor.            | __________ |
| b. Mamanarater ti dir li met so palto dan avion. | __________ |
| c. Lake divan kontwar pa ti pe avans vit.        | __________ |
| d. Narater finn trouv peizaz pandan dekolaz.     | __________ |
| e. Steward-la ti bien poli.                      | __________ |

2. Kifer narater dir ki so mama ti pe gagn per?
3. Dapre twa, kifer li pa ti les so paran trouve ki li ti inpe trakase?
4. Ki bann santiman ki sa vwayaz-la ti provoke?

5. Dapre twa, kifer li dir ki so plas ti 'anbarasan' ousi?
6. Kan prosin fwa ki li pou pran avion?
7. 'Kan mo finn leve mo finn trouv enn espes azitasion otour mwa.' Reekrir sa fraz-la, me ranplas mo 'azitasion' par enn verb.
8. 'Mo finn met mo sak lor mo zepol... Mo finn rant dan avion.' Rezim sa paragraf-la dan mwins ki 50 mo.
9. Trouv enn sinonim pou sa bann mo-la (fer atansion kontext):
- a. abriti
- b.  trakase
- c. anbarasan
- d.  irzans
- e.  koumadir

## 10. Trouv bann tradiksion ki apropriye pou bann mo ek expresion ki swiv, dapre manier ki finn servi zot dan pasaz.

| Kreol Morisien   | Angle             |
|------------------|-------------------|
| leker            |                   |
|                  | suitcase          |
| mous-zonn        |                   |
|                  | abroad            |
| selman           |                   |
| dousman-dousman  |                   |
|                  | procedures        |
| anbarkman        |                   |
|                  | from time to time |
|                  | hostess           |

## Ribrik 2 Vokabiler

## Omonim

Enn omonim, se enn mo ki ena mem son e ki ekrir parey ki enn lot mo, me sinifikasion sa de mo-la li bien diferan.

## Exanp

Mo 'san'

1. Mo ena san roupi dan mo pos.
2. Mo pa kapav viv san bwar ek manze.

Dan fraz nimero 1, mo 'san' vedir sif 100 ek dan fraz nimero 2, li vedir 'si pena' . Toule-de mo ekrir parey, me zot vedir de zafer bien diferan.

## Exersis 1

Ranplas  bann  mo  souligne  par  enn  ou  plizier  mo  pou  montre  ki  to  finn  bien  konpran definision enn omonim.

- 1a) To finn tronp bis, to ti bizin pran bis nimero 2 olie nimero 12.
- b) To tronp kamion pa pe marse, mo krwar li finn gagn delo ladan.
- 2a) Li pe anvi penn so motosiklet ver.
- b) Sa bisiklet-la pe vinn ver mwa.
- 3a) Li enn fann bann mark masinn zapone.
- b) To papa finn fann boukou delo lor kapo loto.
- 4a) Bann soumarin emet bann signal radio pou kominike.
- b) Ena enn emet dan landrwa, okenn transpor pa pe kapav rantre.
- 5a) So leta finn bien ameliore apre sa gran aksidan skouter li finn gagne la.
- b) Leta finn desid pou introdir metro-leze dan Moris.

## Exersis 2

Donn de diferan definision bann mo swivan ek fer enn fraz avek zot. Finn fer enn exanp pou twa.

## Exanp

## roz

Definision 1: Nom enn kouler ki gagne kan melanz kouler rouz ek blan. Fraz: Mo bann kamarad pe organiz enn fet, tou dimounn bizin abiy an roz.

Definision 2: Nom enn varyete fler ki existe an plizier kouler. Fraz: Mo'nn ofer li enn roz blan pou montre li ki mo santiman sinser.

1. met
2. feyte
3. avwe
4. exersis
5. lavi
6. lor
7. kont
8. touse
9. liv
10. lakour

## Exersis 3

1. San rekopie depi Exersis 1, donn 2 mwayin transpor ki servi pou vwayaz:
- a. dan ler
- b. lor later
- c. lor lamer.

The image is a detailed illustration of a cityscape, specifically focusing on the streets and transportation modes. The image is divided into several sections, each representing different modes of transportation.

### Transportation Models:
1. **Trains**:
   - **Type**: Passenger train
   - **Number of Trains**: 1
   - **Color**: Red
   - **Design**: Rectangular with a single carriage.

2. **Cars**:
   - **Type**: 2
   - **Color**: Red
   - **Design**: Rectangular with a single car.

3. **Buses**:
   - **Type**: 1
   - **Color**: Red
   - **Design**: Rectangular with a single bus.

4. **Taxis**:
   - **Type**: 1
   - **Color**: Red
   - **Design**: Rectangular with a single taxi.

5. **Airplanes**:
   - **Type**: 1
   - **Color**: Blue

<!-- image -->

## Rezis langaz

## Fraz 1

'Sa loto-la mari serye. Tou dimounn finn flase lor so form ek so teknolozi ibrid.'

## Fraz 2

'Sa loto-la milti-fonksionel. So form inpresionan, ek anplis li ekipe ek teknolozi ibrid.'

## Reflexion

Malgre ki mem mesaz pe transmet dan Fraz 1 ek Fraz 2, ena enn diferans dan langaz ki pe servi.

- Kisann-la pe kapav dir fraz 1? Dan ki kontext?
- Kisann-la pe kapav dir fraz 2? Dan ki kontext?

Diferans dan bann mo ki servi dan fraz 1 ek 2 pa vedir ki ena enn fraz ki pa korek. Ena sinpleman bann varyasion ki existe dan langaz. Nou pa kominik mem fason avek tou dimounn ou dan tou kontext.

Pou diferan sitiasion ou avek diferan dimounn, nou anplway diferan rezis langaz .

Langaz oral/ekri kapav regroupe dan 3 diferan rezis

## 1. Rezis formel

Kan enn dimounn servi enn rezis formel, li servi bann mo teknik ek enn vokabiler bien elarzi. (par exanp dan enn avan-propo enn diksioner, enn deba ant bann siantifik, etc.).

## a. Rezis elve

Sa rezis-la, li inplik enn langaz konplex ki nou pa servi pou exprim nou dan lavi kotidien. Par exanp bann text relizie, dan dokiman legal, etc.

## 2. Rezis kouran

Rezis kouran pa otan sofistike ki rezis elve, me li pena okenn vilgarite ek bann mo ki servi bien reflesi (liv lekol, prezantasion biltin informasion lor televizion, etc)

## 3. Rezis informel

## a. Rezis familie

Rezis  familie,  se  langaz  ki  nou  plis  servi  dan  nou  lavi  kotidien (avek  koleg,  kamarad,  dan sipermarse, dan bann plas lwazir, etc).

## b. Rezis relase

Rezis relase, li  enn  itilizasion  langaz  ant  bann  dimounn ki telman pros ki zot kapav paret vilger pou enn lot group dimounn. Li kapav inklir enn langaz ki inklir bann kod, bann mesaz sekre, bann zoure, etc.

## Exersis 4

Reget Fraz 1 ek Fraz 2. Soulign bann mo dan Fraz 1 ki permet nou asosie li ek enn rezis familie.

## Exersis 5

Ki rezis langaz ki koresponn avek bann text/sitiasion swivan? Explik to repons.

- a. Dokiman konstitision enn pei
- b. Enn sms partaze ant de konesans long-dat
- c. Text Lalwa Travay
- d. Enn ansiklopedi ki pe koz lor evolision bann mod transpor
- e. Enn blog lor Internet ki pe koz lor bann lamizik popiler
- f. Enn meyl ki to pe adres to kamarad lanfans
- g. Enn animater dan enn laniverser
- h. Enn komedien ki pe prezant enn text Shakespeare
- i. Enn komantater lor enn match football
- j. Enn dokter ki pe anim enn konferans ek bann lezot dokter

## Exersis 6

Miven fek dekouver ki li finn pas so dernie lexame Grad 9. Li pe koz ek so meyer kamarad Ashley lor telefonn. Li pe servi enn rezis familie. Li ena pou transmet mem nouvel so profeser pou remersie li.

## Amenn sa konversasion-la dan enn rezis kouran.

'Weh, to'le krwar, mo'nn pas sa dernie lexamen-la! Mari serye, momem mo pa'le krwar. Mo mari kontan. Mo profeser finn fer mwa enn mari lizaz avek so bann konsey tousa. Mo bizin fer so labous dou.'

In this image, we can see some vehicles and some people.

<!-- image -->

## Ribrik 3 Lortograf

## Virgil

An zeneral, enn virgil servi pou mark enn poz dan enn fraz. Me nou itiliz virgil pou ankor lezot rezon. Nou servi enn virgil pou separ bann mo ou bann group mo dan enn seri trwa kitsoz ou plis.

## Exersis 1

## Azout virgil kot neseser.

1. Mo kontan manz dipin diber ek fromaz.
2. Kari poul ek diri blan ek enn bon zi limon samem mo manze prefere!
3. Lor lalis komision Sam ti ena dipin savonet delwil lay ek zinzam ek dile.

## Exersis 2

## Azout bann virgil kot bizin dan sa ti pasaz-la.

Yer mo mama mo papa ek mo gran-ser ti al lamer. Letan ti bien ansoleye ek mama ti lev boner pou prepar diri ek kari gato pomdeter salad fri ek pima ek boukou bann lezot kiksoz. Nou finn pas enn bon lazourne me dernie ler zis avan nou ale enn gro lapli finn tonbe.

## Apostrof

Dan  bann  dialog  ou  konversasion,  souvan  nou  servi  form kontrakte kan  nou  exprim  nou. Kontraksion se kan nou kol de mo ansam avek itilisasion enn apostrof .

Exanp enn mo ki finn kontrakte :

To finn bwar delo = To'nn bwar delo

Me kan nou ekrir, an zeneral nou evit servi apostrof ek pa met bann mo dan form kontrakte. Nou observ sa dialog ki 2 kamarad pe gagne.

Kevin:

'Kot to'nn ale yer?'

Fanni:

'Mo'nn al fer enn letour Flak.'

Kevin: 'Mari serye! Kan nw'al fer letour ansam?'

## Remark

Zot pou remarke ki dan sa konversasion-la, Kevin ek Fanni pe servi kontraksion 'To'nn' pou dir 'To finn al' e 'Mo'nn' pou 'Mo finn' .

Nou reprezant sa kontraksion-la par enn apostrof.

|

## Exersis 3

Remet sa bann kontraksion-la dan zot form long.

1. Nw'al lamer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Ki'nn arive yer tanto?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. To'nn fer tou to bann dewvar?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Li'a koz ar twa kan to pou al get li.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Nou ti'a kontan zwenn twa pou organiz sa fet-la.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Exersis 4

Remet sa bann fraz-la dan form kontrakte kouma nou ti pou servi li dan enn konversasion oral.

1. To finn al laboutik?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Nou finn al lamer yer tanto.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image there are a few people and vehicles.

<!-- image -->

## Ribrik 4 Gramer

## Kategori Pronom

Tradisionelman, nou definir enn pronom kouma enn mo gramatikal ki nou servi dan plas enn nom prop ouswa enn group nominal.

## Exanp

Fabrice inn al bazar, li finn al aste legim.

Enn sat inn rant dan lakwizinn, pous li!

Zordizour, nou plito aksepte ki enn pronom li enn mo gramatikal ki ena kouma fonksion pou ranplas enn lot kitsoz dan enn fraz. Sa lot kitsoz-la, li kapav enn nom prop, enn group nominal (GN), enn verb, enn group verbal (GV), enn fraz, etc.

## Ex:

| Nomprop   | Christelle finn manze gramatin. Li finn bwar enn sokola so ousi.    |
|-----------|---------------------------------------------------------------------|
| GN        | Sa banndimounnkinouti zwennyer swar la, zot tou ti sorti Mahebourg. |
| Verb      | Manze, li esansiel pou viv.                                         |
| GV        | Fer spor toule semenn, se enn aktivite inportan pou leker.          |
| Fraz      | Li inposib leve avan trwa-z-er gramatin. Samem, ki moti pe dir li.  |

Bann pronom kapav ranpli rol size, obze ouswa konpleman dan enn fraz.

| Size      | Li pankor pase zordi.                           |
|-----------|-------------------------------------------------|
| Obze      | Pret mwaoulagazet, moretourn li dan de minit.   |
| Konpleman | Li bien malin, akoz sa mokontan travay avek li. |

## Ena plizier kategori pronom:

1. pronom personel
2. pronom demonstratif
3. pronom posesif
4. pronom indefini
5. pronom interogatif.

## 1. Pronom personel

Nou kapav kategoriz bann pronom personel dapre zot fonksion, setadir, selon ki zot size , obze ouswa reflexif :

| Tablo lor pronom personel   | Tablo lor pronom personel   | Tablo lor pronom personel   | Tablo lor pronom personel       | Tablo lor pronom personel   |
|-----------------------------|-----------------------------|-----------------------------|---------------------------------|-----------------------------|
|                             | Size                        | Obze                        | Reflexif size                   | Reflexif obze               |
| 1 e personn singilie        | mo gete                     | get mwa                     | momem mo gete                   | get momem                   |
| 2 e personn singilie        | to/ou gete                  | get twa/ou                  | tomem/oumem to/ou gete          | get tomem/ oumem            |
| 3 e personn singilie        | li gete                     | get li                      | limem li gete                   | get limem                   |
| 1 e personn pliryel         | nou gete                    | get nou                     | noumem nou gete                 | get noumem                  |
| 2 e personn pliryel         | zot gete                    | get zot                     | zotmem zot gete                 | get zotmem                  |
| 3 e personn pliryel         | zot/bann-la gete            | get zot/ bann-la            | zotmem zot gete bann-lamem gete | get zotmem/ bann-lamem      |

## Exersis 1

## Eski bann pronom dan bann fraz ki pe swiv ena enn valer anaforik ouswa deiktik?

1. Papa ti al bazar gramatin. Li konn tou bann marsan legim.
2. Roseda finn perdi enn kaye yer. Sann-la, li finn kit li dan bis.
3. Get zot enn kou!
4. Darlene ti zwe poker ek so bann kamarad; zot finn perdi.
5. Pa asiz lor sann-la! Mo krwar li kase.

## 2. Pronom demonstratif

Enn pronom demonstratif fonksionn exakteman kouma enn determinan demonstratif, setadir li kapav swa deiktik swa anaforik. Anfet, li ranplas enn nom ek so demonstratif anmemtan.

Ex: sa garson-la  =  sannla-la / sana-la / sann-la

Enn pronom demonstratif kapav ranpli rol size , obze ouswa konpleman dan enn fraz.

| Size      | Sann-la pankor stanpe.                      |
|-----------|---------------------------------------------|
| Obze      | Mobizin get sann-la avan moale.             |
| Konpleman | Mokontan travay ar sann-la plito ki lot-la. |

## 3. Pronom indefini

Enn pronom indefini ranplas enn nom (ouswa enn group nominal) san ki nou ena (ouswa san ki nou donn) enn indikasion presi lor idantite so referan.

Ex: Intel pankor vini.

Samem ki bizin. Kikenn inn fek rantre.

Kitsoz pe bwi lor dife.

Enn pronom indefini kapav zwe rol size, obze ouswa konpleman dan enn fraz.

| Size      | Kikenn inn perdi so kab telefonn gramatin.    |
|-----------|-----------------------------------------------|
| Obze      | Li ti bwar kitsoz apre so lekours.            |
| Konpleman | Li ti vinn ek kikenn ki zame moti zwenn avan. |

## 4. Pronom interogatif

Enn pronom interogatif kapav definir kouma enn mo gramatikal ki ranplas enn nom (ouswa enn group nominal) e ki permet poz enn kestion.

Ex: Kisann-la pe manze? Kifer lapli tonbe? Lakel ant zot pou vini tanto?

## Exersis 2

Reper bann diferan pronom ki prezan dan sa pasaz-la.

'Eski kikenn finn deza trouv enn lougarou?' Samem kestion ki Marc ti pe poz so bann kamarad san ki okenn pa reisi donn li enn repons. Zot nek get lao, koumadir kestion li ti poze pa ti konsern zot. Sann-la ti pe get so soulie, lotla-la ti pe siflote koumadir nanye ete. 'Bon, eski personn pa kapav reponn mwa?'

## Exersis 3

## Ki bann pronom ape ranplase dan ban fraz ki pe swiv?

1. Rambo finn ramas so fizi. Li ti poze anba.
2. Rambo finn ramas so fizi. Li ti kone li pa ti tousel dan sa lafore-la.
3. Brezil  finn  ranport  Mondial  football  sink  fwa  ek  Lafrans  de  fwa.  Kisann-la  finn  gagne  pli souvan?
4. Bann Amerikenn finn gagn meday lor dan Mondial feminin. Zot-mem ti meyer lekip.
5. Kan eski pou gagn vakans? Apre lexamen!

<!-- image -->

- Sapit 3

Kreol Morisien

|

## Ribrik 5 Prodiksion oral ek ekri

## Exersis 1

Lir ek observ sa let formel la ek reponn bann kestion ki swiv.

Minister Ledikasion ek Kiltir 50, Apple street Port-Louis

25 Avril 2019

Misie Marcus Emilien 13, Rue des Abricots Rose-Hill

Misie Emilien,

O-nom Minister  Ledikasion  ek  Kiltir,  mo  ena  plezir  anons  ou  ki  desin  ki  ou  finn  avoy Minister dan kad konkour 'Desinn lavenir to pei avek Metro Express' finn swazir parmi bann 5 meyer desin dan kategori 12-15 an. Minister prezant ou so felisitasion pou sa performans-la.

Le 15 Me 2019, Minister pe organiz enn expozision bann meyer desin dan tou kategori. Sa zour-la pou ena ousi anons nom bann gagnan dan sak kategori ek enn seremoni remiz pri an prezans Minis Ledikasion. Expozision ek seremoni pou deroul dan hall siez prinsipal Minister ki trouv dan Port-Louis apartir 2.00 p.m.

Nou pe invit ou ek ou paran pou partisip dan sa evennman-la. Nou swete ki ou konfirm ou prezans par telefonn lor 4646464 oplitar le 30 Avril. Si nou pa gagn enn konfirmasion lor ou partisipasion ziska le 30 Avril, nou pou konsidere ki ou pa pou prezan.

Mo prezant ou mo salitasion distinge,

Mm Karine Latin

Responsab konkour 'Desinn lavenir to pei avek Metro Express'

Enn let formel swiv enn striktir presi e li inportan respekte sa striktir-la.

Konpar striktir sa let formel ek striktir let informel ki Anna finn ekrir Amanda (dan dernie sapit). Gete kot finn plas ladres emeter, kouma finn ekrir formil salitasion etc.

Not 1

Enn kominasion formel li kapav pran form enn e-mail ousi.

## Exersis 2

Observ model let formel ki finn donn twa ek reponn bann kestion ki swiv.

## Model enn let formel

Nom emeter Institision emeter (si aplikab) Ladres emeter Ladres mail emeter (si aplikab)

Dat Mwa Lane

Nom resepter

Linstitision resepter (si aplikab) Ladres resepter

Ladres mail resepter (si aplikab)

Misie/ Madam Nom resepter

Introdiksion Emeter ekrir enn-de fraz pou prezant dan ki kontext li pe ekrir.

Devlopman Emeter ekrir enn ou de paragraf pou explik an detay so reket ou obzektif so let.

Konklizion Emeter explik klerman ki aksion li swete resepter pran par rapor a reket/ obzektif so let.

Formil salitasion.

Signatir

Nom emeter

## Kestion

1. Kifer li inportan donn ladres emeter?
2. Kifer li inportan servi bann tit kouma 'Misie/Madam' dan enn let formel? Eski to kapav pans lezot tit ki kapav servi dan enn let formel?
3. Ki bann lezot formil salitasion kapav servi dan enn let formel?

## Exersis 3

Dapre twa, dan ki kontext, nou ekrir enn let formel?

## Exersis 4

## Prodiksion enn let formel

Ena problem bis dan to landrwa. Ekrir enn let formel National Transport Authority(NTA) pou raport ek dekrir problem ki twa ek bann dimounn dan to landrwa pe fer fas. Dan konklizion to let, formil enn reket kler ki to pe adres  NTA.

## Ribrik 6 Tradiksion

Kapav arive kan nou pe tradir enn fraz ki nou pa gagn so ekivalan dan langaz sib.

Parfwa se parski nou pa gagn bann mo ki vedir mem zafer.  Me parfwa, se ousi parski pa servi mem fason pou dir bann zafer dan de langaz-la.

Kan ariv sa, nou bizin kas konstriksion text sours e rekonstrir li dan langaz sib.

| Exanp 1    |                                                                                                                             |
|------------|-----------------------------------------------------------------------------------------------------------------------------|
| KM:        | Nou finn bien amize parski tou nou bann kamarad ti finn vini.                                                               |
| ANGLE:     | It was fun because all our friends were there.                                                                              |
| Exanp 2    |                                                                                                                             |
| ANGLE: KM: | Jen is good at football and usually scores at every match. Jen enn bon footballer e li met gorl laplipar-di-tan kan li zwe. |

## Exersis 1

## Tradir sa bann fraz-la ver Angle.

1. Ti servi seval pou vwayaze avan invansion loto.
2. Dan aeropor, si ou bagaz res san sirveyans, bann travayer kapav ramas li ek detrir li.
3. Lenny ti telman fin ki li finn manz so dipin enn sel kou.
4. To bizin met serye sinon to pou fel lafin lane.
5. Mo finn transpir gro kan met-dekol finn apel mwa dan biro.

## Exersis 2

## Tradir sa bann fraz-la ver KM.

1. It's a pity I did not meet your parents.
2. What a beautiful house! I wish I could live in it.
3. I've never heard such a sad story.
4. Kris lost his car keys but still managed to open the car.
5. Shopping malls are usually crowded during the weekends.

## Ribrik 7 Literatir

## Roman

In this image we can see a boy sitting on the ground and holding a book. In the background there is a sky with clouds.

<!-- image -->

Enn roman, li enn zistwar ki souvan fiktif e ki souvan finn piblie pou enn apresiasion ek enn lektir individiel.

Enn roman met an plas enn nonb personaz ki evolie dan enn lespas-tan, avek zot bann prop lavantir ek destine.

Kan nou koz enn roman dan literatir, nou etidie boukou zafer. Parmi ena:

| Bann personaz (zot karakter, zot desizion, seki zot pe viv, etc.)            |
|------------------------------------------------------------------------------|
| Bann tem ki pe aborde                                                        |
| Narasion text-la (ki manier li finn ekrir, kifer li finn ekrir koumsa, etc.) |
| Valer letan dan roman-la (eski resi-la pe arive dan lepase, etc.)            |
| Konstriksion bann fraz, bann expresion, etc.                                 |
| Rezis langaz ki pe servi                                                     |

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

## Exersis 1

## Bann diferan tip roman

Relie sak tip roman ki liste anba ek so deskripsion. Fer enn travay resers (si bizin) pou ed twa.

Roman siansfiksion

Enn tip roman ki souvan santre lor enn krim. Deroulman bann  evennman  dan  sa  roman-la  baze  lor  bann  lanket, koleksion ek analiz bann prev.

Roman otobiografik

Roman polisie

Roman istorik

Roman fantastik

Roman epistoler

Roman inisiasion/ Roman laprantisaz

Enn roman ki santre lor Listwar. Li evok lepase ek so bann personaz (reel ou imaziner) viv dan sa lepok-la.

Enn tip roman ki koumans par lanfans ou ladolesans enn personaz  prinsipal.  Narasion  roman-la  rakont  enn  seri evennman ki pou devlop personaz-la so vizion lor lavi.

Enn roman ki deroul lor lesanz bann let. Bien souvan, de personaz pe esanz bann let pou partaz zot bann emosion ek  experyans.  Koumsamem  lintrig  ek  deroulman  aksion prosede.

Sa tip  roman-la koz lor lavi enn personaz depi so nesans ziska enn pwin inportan dan so lavi (sanzman idantite, bann dernie moman, etc.) . Personaz lamem pe rakont so zistwar.

Bann evennman bizar ou sirnatirel,  bann  kreatir  mitik  ek imaziner, bann aparision inexplikab form parti sa roman-la.

Sa roman-la prezant enn zistwar ki baze lor bann fe siantifik, lor bann evennman ki emervey ek fasinn lemond siantifik, par exanp bann explorasion lespas.

Adaptasion enn extre depi roman 20 000 lie anba delo ki  finn  piblie  par  Jules Verne  an 1869-1870.

## Enn resif koray ki pe sov-sove

Lane 1866 finn marke par enn fenomenn extraordiner, mem sirnatirel pou sertin. Pandan sa lepok-la, pa ti ena boukou mo pou explik ou konpran sa fenomenn-la. Bann rimer finn koumans sirkile avek enn vites extraordiner, wadire finn fann petrol lor dife. Rimer-la ti pe fane, sirtou parmi bann dimounn ki zot travay relie avek losean. Pa ti ena enn dimounn ki  pa  ti  intrige  par  seki  ti  pe  arive:  bann  peser,  bann marin, bann kapitenn bato, bann komersan  maritim,  bann  skiper.  Gouvernman,  servis  militer  ek  maritim  plizier  pei  ek kontinan ti ousi preokipe par sa sitiasion-la. Sa intrig-la ti pe propaze depi Lamerik ziska lot bout lamer, kot Lerop.

Ki ti pe arive koumsa?

Depi inpe letan, 'enn kiksoz enorm' finn krwaz sime boukou bann navir.  Finn raporte ki 'kiksoz-la' bien long, boukou pli gro ki ninport ki labalenn ek setase ki nou kone ziska ler.  Finn ousi observe ki pa kapav konpar 'kiksoz-la' so vites ek enn balenn ou mem enn navir so vites.  'Kiksoz-la' ti pe res alime-tengn ek briye anba delo, ek pa ti pe konpran si ti elektrisite sa ouswa bann desarz elektrik natirel.

Ti ena enn krint zeneral ki enn mons inkoni ti pe viv bann fonder losean.  Ninport kan, li ti pou kapav fer bann ravaz, ek personn pa ti pou kapav aret li.

Ki ti ete sa 'kiksoz-la'? Eski li ti enn aparision sirnatirel, enn rev ou enn invansion bann dimounn ki ti pe delire?  Mil kestion ti pe ant zot tou zot lespri… Kiryozite, apre tou, enn linstin imin.

In this image we can see a wave.

<!-- image -->

## Kestion

1. Ki tem prinsipal ki pe aborde dan sa extre roman la? Konstrir enn rezo lexikal lor tem prinsipal sa extre-la.
2. To pou konstate ki oter-la pa rant dan zistwar-la enn sel kout.  Enn latmosfer sispans kree dan louvertir sa zistwar-la.  Kifer, selon twa, oter-la swazir sa stil narasion-la?
3. Baze lor seki to finn lir, ki tip roman to panse 20 000 lie anba delo pou ete?

In this image we can see a man wearing a suit and tie. In the background there is a text.

<!-- image -->

## Travay resers

Fer enn ti resers lor bann roman ki Jules Verne finn ekrir. Swazir enn ladan ek fer enn ti rezime anviron 30 lalinn lor tem liv-la.

In this image we can see a person with a beard.

<!-- image -->

BONZOUR

<!-- image -->

Sapit 4

<!-- image -->

## Dekouvert langaz

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a cartoon image of a person.

<!-- image -->

Lir sa text-la, answit reponn bann kestion.

## APRANN DAN ENN LOT LANGAZ

In this image, we can see a poster with some text and images.

<!-- image -->

Mo bann klas ti pli difisil ki dan lekol primer. Malgre ki mo ti bien kontan ki M. Bogart ti nepli mo profeser, mo ti bizin fer boukou zefor pou ki mo pa perdi pie . Enn parmi mo bann pli gro difikilte, sete kwiz kotidien dan  klas  M.  Scoggins,  nou  profeser Social  Studies. Sete  enn  kwiz  lor  laktialite.  Mo  ti  touletan  dernie. M.  Scoggins  pa  ti  konpran  kifer  nou  pa  ti  get linformasion  si-z-er  toule  tanto,  oubien zet  enn koudey lor New York Times nou bann paran.

'Si zot pa konpran enn zafer, demann zot paran! Diskit bann nouvel toulezour, se enn zafer bien inportan.' Toulezour M. Scoggins ti repet mem zafer.

Sak fwa li dir sa, mo ti imazinn mo mama ek mwa dan enn zoli sal-a-manze kouma kot Annette, ek enn zoli latab bien glase, ek mo mama ti pou pe explik mwa bann detay lor zafer Watergate .  Mo finn deza sey poz mo mama kestion lor konservasion lavi sovaz kan ti ena enn devwar lor la.  'Kisannla ki anvi sov bann zanimo sovaz kouma bann tig?' Sa ti rann li bien tris. 'Kot nou ti reste laba, dan Lasinn, enn zour enn tig ti kokin enn ti-baba.'

Parfwa mo ti trouv li zet enn koudey dan mo bann liv e li ti sey eple bann mo tanzantan, me malerezman li ti kontign lir depi drwat ziska gos. Li ti ena enn ti liv ki li ti finn aste dan Chinatown pou li aprann Angle e toule Dimans, mo ti sey montre li. Parkont, mo mama pa ti ena enn latet aprann.  E de langaz-la ti telman diferan, ki li ti koumadir mo ti pe dimann li sanz kouler so lizie.

Dan lizinn, mo ti met radio zwe pandan ki nou ti pe travay, e mo ti sey konpran bann informasion. Malerezman, ti ena enn moter zis kot nou etabli e li ti ronfle telman for ki laplipar bann mo ti nwaye dan tapaz. Ti ena telman mo ki mo pa ti kone! Mem si mo ti kapav konpran bann fraz, mo konesans zeneral pa ti ase pou ki mo konpran bann zistwar ki zot ti pe rakonte.  Mo ti travay bien dan sians ek matematik, me dan tou lezot size, mo ti pran trwa fwa plis letan pou lir Angle ki Sinwa. Mo ti oblize konsantre e si mo ti perdi konsantrasion enn moman, fraz-la ti vinn inkonpreansib net ek mo ti bizin rekoumans a-zero. Pou sak sink mo ki mo ti lir, mo ti bizin get de dan diksioner. Laplipar letan, apenn mo ti konpran bann kestion. Pa koz trouv repons!

Trace  the  theme  of  violence  in  the  story  from  inception  to  its  inevitable  climax;  how  is  violence unleashed in each of the main characters?*

Mo finn lev mo latet e mo finn trouv mo mama pe pare pou li al dormi. Li ti paret bien frazil anba sa pake linz ki li ti finn mete la. Anplis, li ti met enn palto ki li ti fabrike ar lapo enn gro nounours ki nou ti ramase. Li ti met so legan me mem sa , li ti bizin frot so de lame ansam pou sof zot. Vakans dernie, mo ti lir enn zistwar kot enn papa ti asiz ar so tifi pou montre li kouma ekrir enn sek labank. Souvan mo ti pans sa senn-la.

'Eski mo kapav donn twa enn koudme?' mo mama demande. 'Non, Ma.' Li finn soupire. 'To  pe bizin travay bien dir! Pa al dormi tro tar, mo piti.'

Mo ti anvi al dormi. Mo ti santi mo likou pe vinn pli lour, mo latet nepli tini, mo lizie ferme. Nou lakaz ti som ek vid. Detrwa lera ti pe fer lekours dan lakwizinn.  Mo finn frot mo latanp ek mo finn relir kestion-la.

* Retras tem laviolans dan sa zistwar-la depi so koumansman ziska so denouman final; kouma eski laviolans devlope dan sak personaz prinsipal?

Tradiksion ek adaptasion depi A Girl in Translation par Jean Kwok, 2010.

## 1. Reponn par Vre (V) ou Fos (F). Zistifie sak repons.

In this image we can see a table with some text on it.

<!-- image -->

|                                                   | V/F        |
|---------------------------------------------------|------------|
| a. Narater ti bien kontan M. Bogart.              | __________ |
| b. Informasion ti memler toulezour.               | __________ |
| c. So mamaek li ti ena enn zoli sal-a-manze.      | __________ |
| d. So mamati bien sagrin bann zanimo sovaz.       | __________ |
| e. Li ti gagn difikilte pou konpran bann kestion. | __________ |

## 2. Ki li ti bizin fer pou ki li pa 'perdi pie'?

- 3a. Mansionn 1 kitsoz ki M. Scoggins pa ti konpran ar so bann zelev.
- 3b. Dapre twa, kifer bann zelev-la pa ti kapav fer sa?
4. Dir kouma narater so mama ti reazir kan li ti pe koz lor konservasion lavi sovaz.

5. Ki insidan ti arive dan Lasinn?
6. Dapre twa, kifer narater travay bien zis dan sians e matematik?
7. Donn 2 rezon kifer so mama pa ti kapav lir.
8. Ki detay montre ki ti pe fer extra fre?
9. 'Pa koz trouv repons!' Reekrir sa fraz-la me sa fwa-la servi mo 'inkapab' .
10. Explik sa bann mo-la.
- a. perdi pie
- b. zet enn koudey
- c. nwaye
- d. inkonpreansib
- e. mem sa

## 10. Trouv bann tradiksion ki apropriye pou bann mo ek expresion ki swiv, dapre manier ki finn servi zot dan pasaz.

| Kreol Morisien   | Angle         |
|------------------|---------------|
| laktialite       |               |
| koumadir         |               |
| lekol primer     |               |
| laplipar letan   |               |
| soupire          |               |
|                  | unfortunately |
|                  | daily         |
|                  | dining room   |
|                  | teddy bear    |
|                  | holidays      |

## Ribrik 2 Vokabiler

## Dekouvert langaz

Manier ki bann dimounn koz Kreol atraver lemond diferan. Dan Moris, nou pou trouve ki mem kan nou pe koz Kreol Morisien ena diferan manier dir enn mem mo. Nou apel bann diferan fason dir enn mo bann varyant , par exanp, 'delo -  dilo' , 'kouma - kouman' .

Ena plizier rezon ki fer varyant existe me pa ve dir ki ena enn fason prononse pli bon ki lot. Bann varyant rann enn langaz pli interesan.

## Exersis 1

## 1. (a) Trouv omwin enn varyant pou sakenn sa bann mo-la

- Bokou
- Bwem
- Kannson
- Karton
- Demin
- Lafnet
- Lakouzinn
- Krab
- Pwanie

## (b) Par tomem, trouv 3 lezot per varyant.

(i)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(ii)   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(iii) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Ki manier?

How are you?

Comment ç a va ?

Kaise ba?

## Lir text ki swiv.

## Pou mon bann kamarad

## (Lor ler Braves de la Germanie)

Bann kamarad, si fie lor latristes Nou lavenir pa sir li briye. Anou gard plito lasazes Nou bann vie ki ti konn touzour riye. Dan tou traka lavi Sagrin, douler, sousi Anou konn extrer sa ti lagrin foli Ki amenn lazwa dan pei.

Pa pran mo ti prefas Pou enn move pretansion Fer parti bann gran poet deklas. Sa ti zame mo lanbision.

Me kan letan pe met lipie lor akselerater E ki mo lavenir paret plis deryer ki divan Les mo sey omwin fer enn kout zwer Ek fer mo adie dan enn fason ki plezan.

'Pou Madam Borel Jeune' adapte par Chrestien (1822), readapte par Carpooran et al. (2018)

In this image we can see a sketch of three people.

<!-- image -->

- (a) Propoz enn definision pou bann mo souligne.
- (b) Donn enn sinonim pou mo:
- (i)   Fie
- (ii)  Fason
- (iii) Plezan
- (c) Donn enn antonim pou mo 'sagrin' .
- (d)  Idantifie 2 mo dan sa text-la ki ena varyant. Donn omwin enn ou de varyant pou sakenn.

## Exersis 3

Apart bann varyant ki existe dan Kreol Morisien, ena bann lezot manier koz Kreol ki existe andeor Moris.

Apart Moris, nomm 3 zil kot bann abitan koz Kreol dan Losean indien.

Get bann fraz ki swiv ki an Kreol Reyone, ek esey konpran ki zot pe dir.

- (i) Sa lé dou.
- (ii) Mi ariv pa.
- (iii) Pa bezoin ou la per.
- (iv) Kossa la arive?
- (v) Nou la kas mang?

In this image we can see a sketch of a person and a person holding a book.

<!-- image -->

## Diskision dan klas ant zelev-profeser

- (i) Dir ki bann fakter finn ed zot konpran sa bann fraz-la.
- (ii) Dir ki bann difikilte zot kapav finn gagne pou konpran sertin fraz.
- (iii) Eski zot ti pou kontan aprann enn lot lang? Kifer?

Apart bann lang kreol, ena bann lezot lang ki koze atraver lemond. Ala enn lalis avek diferan pei oubien zil.

Fer enn ti resers ek trouv lang (ou bann lang) ki koze dan sa bann pei-la. Finn fer enn lexanp pou twa.

(Not: Pa bliye nom bann lang touletan koumans par enn maziskil.)

|   Pei | Pei        | Lang   |
|-------|------------|--------|
|     1 | Lafrans    | Franse |
|     2 | Langleter  |        |
|     3 | Lespagn    |        |
|     4 | Lalmagn    |        |
|     5 | Lamerik    |        |
|     6 | Sesel      |        |
|     7 | Madagaskar |        |
|     8 | Lasinn     |        |
|     9 | Lenn       |        |
|    10 | Lostrali   |        |
|    11 | Canada     |        |
|    12 | Brezil     |        |

## Ribrik 3 Lortograf

## Vwayel 'OU' ouswa 'U'

Dan KM, nou servi let 'o+u' pou reprezant son [u] par exanp boul . Dan KM, nou servi let 'u' pou reprezant son [ ^ ] par exanp brushing .

## Lir sa bann fraz-la.

- a. Kan dimounn sorti dan twalet, bizin pa bliye flush.
- b. Mo likou extra fermal, mo krwar mo finn mal dormi.
- c. Bann mason servi marto ek koulou.
- d. Azordi dan restoran, ti ena enn rush pa posib.
- e. Enn zelev kapav pran duster ek efas tablo.
- f. Mo kontan manz burger poul.

## Exersis 1

## Idantifie bann mo depi dan sa bann fraz-la kot zot ena son [u] ek [ ^ ] ek plas zot kot bizin dan tablo.

## Exersis 2

## Konplet sa bann mo-la par 'ou' ouswa 'u' .

- a. Kan bann magazin pe ferme, bann anplwaye bes sh\_\_\_tters.
- b. R\_\_\_l brit, mor brit!
- c. Servi cotton b\_\_\_d pou netway nou zorey.
- d. Toulez\_\_\_r delo aret k\_\_\_le 9-er.
- e. Ena enn b\_\_\_g dan so sistem informatik.

## Ribrik 4 Gramer

## Enn fraz sinp

Enn fraz sinp, se enn fraz ki kontenir enn sel verb ek enn sel size.

## Exanp1

- a. Zahil galoupe.
- b. Lisien zape.
- c. Bis pou demare 3.30 p.m.

So size kapav enn group nominal (GN), sa ve dir enn group mo avek enn nom prinsipal ek so verb kapav fer parti enn group verbal (GV).

## Exanp 2

- a. Anne-Claire ek John pe aste komision.
- b. Mo kouzinn Nina bien kontan bann liv romantik.

Kouma dan exanp (2b), enn group verbal kapav kontenir enn GN ki konpleman obze ousi.

## Not

Seki pli bizin rapel se ki enn fraz sinp ena ENN SEL VERB ek ENN SEL SIZE.

Nou ousi konsider bann fraz inperatif ek inpersonel kouma bann fraz sinp, mem si zot pena size.

## Exanp 3

- a. Vinn ek mwa! (Inperatif)
- b. Ouver zot liv bann zanfan. (Inperatif)
- c. Ena trwa zwazo lor brans. (Inpersonel)
- d. Ena sis zwer dan enn lekip volley-ball. (Inpersonel)

## Exersis 1

## Idantifie bann fraz sinp dan lalis ki swiv.

- a. Mo pou al laboutik demin gramatin.
- b. Vanessa so granmer pou kwi enn kari tanto.
- c. Amenn to sak ek twa taler.
- d. Lydia finn manz farata gramatin ek li finn bwar dite.
- e. Rishi pou rant so lakaz inpe tar akoz ena lapli.
- f. Juanito kontan so gran frer.
- g. Mo fatige.
- h. Eski to pou vinn lantrennman demin?
- i. Pran enn sez ek asiz twa.
- j. Paul ek Anna finn al grinp montagn Dimans.

## Form fraz

Enn fraz kapav ena de form: form afirmatif ek form negatif .

Nou servi form afirmatif kan enn dimounn pe fer kitsoz ek form negatif kan li pa pe fer sa kitsozla. Pou kre enn fraz dan form negatif, nou azout pa devan verb ouswa devan bann marker TMA si ena.

## Exanp 1

- a. Leila pe al bazar. (form afirmatif) Leila pa pe al bazar. (form negatif)
- b. Ben kontan lir. (form afirmatif) Ben pa kontan lir. (form negatif)

In this image, we can see a person. In the background, we can see the sky, clouds, and the sun. We can also see the text.

<!-- image -->

## Exersis 2

## Met bann fraz ki pe swiv dan form negatif.

1. Jean-Luc kontan gato.
2. Fatima finn aroz so bann fler.
3. Demin, Yash pou amenn so lisien promne.
4. Mo granper ti abitie rakont nou zistwar.
5. Davina pou amenn enn kado pou mo ser tanto.
6. Kunal ti pe fer enn desin lor so laptop.
7. Nikita so lavwa resanble Beyoncé.
8. Julien ti kontan zwe kart ek so bann kamarad pandan rekreasion.
9. Nishi ti invit mwa pou so laniverser.
10. Christian ti fer enn kari poul Samdi dernie.

## Tip fraz

## Ena 4 tip fraz:

1. fraz deklaratif
2. fraz interogatif
3. fraz exklamatif
4. fraz inperatif.

## Not

Toule 4 tip fraz kapav swa dan form afirmatif, swa dan form negatif.

## Fraz deklaratif

Nou servi enn fraz  deklaratif pou enons enn kitsoz ki nou konsider vre ouswa pou konstat kitsoz, ouswa ankor pou donn nou lopinion lor kitsoz.

## Exanp

Jean-Marie kontan manz gato-banann.

Jean-Marie pa kontan manz gato-banann.

Mo panse ki Jean-Marie kontan manz gato-banann.

## Fraz interogatif

Nou servi enn fraz interogatif pou poz enn kestion apartir enn fraz deklaratif. Pou form enn fraz interogatif, nou azout eski pou koumans fraz-la ek nou azout enn pwin interogasion alafin.

## Exanp 1

Eski Jean-Marie kontan manz gato-banann ?

## Not

Nou kapav kree bann lezot kestion kan nou servi enn pronom interogatif.

## Exanp 2

Avek kisann-la Jean-Marie kontan manz gato-banann? Kifer Jean-Marie kontan manz gato-banann? Kan eski Jean-Marie kontan manz gato-banann?

## Fraz exklamatif

Nou servi enn fraz exklamatif pou indik enn emosion (lakoler, lazwa, latristes, sirpriz, etc.) ki pe akonpagn seki nou pe dir. Nou azout enn pwin exklamasion alafin sa fraz-la.

## Exanp

Jean-Marie kontan manz gato banann!

Ayo! Get ki kantite gato banann Anna pe manze!

## Fraz inperatif

Nou servi enn fraz inperatif pou donn enn lord. Pou nou kree enn fraz inperatif, nou pa met size devan verb-la.

## Exanp

Manz to gato-banann.

Aret ekrir.

## Exersis 3

Fer bann fraz interogatif apartir bann fraz dan exersis 2.

Exersis 4

Fer bann lezot kestion apartir bann fraz dan exersis 2. Pou fer sa bann lezot kestion, servi enn pronom interogatif.

## Ribrik 5 Prodiksion oral ek ekri

## Exersis 1

Lir dialog ki pe deroule ant Ravi ek Jane ek reponn bann kestion ki swiv.

In this image we can see a cartoon image of a boy and a girl. They are standing in the middle of the image. They are smiling. There is a tree in the middle of the image. There are some plants and grass in the background.

<!-- image -->

In this image we can see a cartoon image of a boy and a girl. The boy is wearing a red shirt and blue pant. The girl is wearing a red and blue dress. The boy is smiling and the girl is smiling. In the background there are trees and plants.

<!-- image -->

In this image we can see a cartoon image of two people. The person on the left is wearing a t-shirt and the person on the right is wearing a t-shirt. In the background there are trees and mountains.

<!-- image -->

In this image we can see a cartoon image of a boy and a girl. The boy is wearing a blue t-shirt and the girl is wearing a red t-shirt. In the background there are plants and trees.

<!-- image -->

## Reponn bann kestion ki swiv.

- a. Ki lopinion Jane lor seki Ravi pe dir?
- b. Eski, dapre twa, Ravi finn baz li lor bann exanp presi pou donn so lopinion?
- c. Lor ki Jane baz so lopinion?

## Explikasion bann nosion 'lopinion' , 'argiman' , 'lexanp'

Sa dialog ant Ravi ek Jane la montre ki sakenn ena enn lopinion diferan.

## Lopinion

Enn lopinion , se enn lide ouswa enn zizman ki enn dimounn ena lor enn kiksoz. Enn lopinion, li kapav fonde lor bann fe ouswa lor bann santiman.

Kan enn lopinion baze lor bann fe, nou dir ki se enn lopinion obzektif.

Kan enn lopinion baze zis lor bann santiman, nou dir ki se enn lopinion sibzektif.

Dan ka Jane, nou trouve ki li devlop so lopinion apartir bann fe obzektif (observasion lanatir, kiltir, langaz) alor ki Ravi devlop so lopinion apartir enn sel inprision. Toulede lopinion valab, me dan kad enn deba, setadir enn esanz bann lide, li inportan devlop bann lopinion ki fonde apartir bann fe obzektif.

Nou apel lopinion obzektif bann argiman ki pou servi pou defann enn lide. Nou ousi servi bann exanp pou soutenir enn argiman.

Enn-de exanp argiman :

1. Mo  panse  ki  Moris  enn  zoli  pei [lopinion] parski  li  ena  bann  laplaz [argiman  baze  lor  fe observab] kouma Blue Bay [exanp], me osi bann montagn [argiman baze lor fe observab] kouman Le Morne [exanp] .
2. Li inportan servi portab an moderasion [lopinion] parski so lalimier ble [argiman baze lor fe observab] kapav amenn bann maladi lizie [exanp] .

In this image, we can see a group of people standing and holding some objects. We can also see some text and images.

<!-- image -->

## Exersis 2

Apartir bann tem ki aparet anba, devlop enn lopinion ki to pou soutenir par enn argiman baze lor enn fe obzektif ek enn lexanp. Finn fer enn exanp pou twa.

Sigaret - Sigaret move pou lasante parski bann prodwi simik ki li kontenir afekte poumon ek devlop bann maladi kouman kanser.

1. Larzan
2. Zanimo
3. Lar

## Deba

Enn deba se enn diskision ki de dimounn ou enn group dimounn ena lor enn size. Pandan enn deba, zot exprim bann lopinion diferan atraver bann argiman ek bann lexanp. Enn deba kapav bien formel kouma bann deba ki nou trouve dan televizion. Li kapav ousi plis informel ek pran plas ant bann kamarad ou bann mamb enn fami. Seki inportan, se prosesis reflexion ek esanz bann argiman dan enn atmosfer konstriktif.

Dan klas ousi kapav fer enn deba lor enn size ki konsern bann zelev. Kouma dan tou deba, ena bann etap inportan ki bizin respekte.

## Bann letap preparasion ek deroulman enn deba:

1. Idantifikasion enn tem ou enn size diskision
2. Idantifikasion de group zelev ki pou defann de lopinion diferan lor size-la. Par exanp, enn group ki pou an faver size-la ek enn lot group ki pou kont size-la.
3. Faz resers lor tem ou size diskision par bann zelev dan sak ban group.
4. Organizasion bann lide, argiman ek exanp par sak group.
5. Deroulman deba dan klas dapre bann reg ki pou etablir ant zelev ek profeser.
6. Konklizion deba.

## Pandan deba, li bon ki:

- -Enn zelev zwe rol Time-keeper pou checke ki sak manb dan sak group ena mem letan pou koze.
- -Enn zelev zwe rol Moderator pou distribie laparol ant bann manb sak group.
- -Moderater anons deba ek donn laparol sak manb dan sak group.
- -Sak manb sak group ena so tour pou devlop enn ou enn bann argiman pou defann lopinion so group lor size-la.
- -Dan konklizion deba, sak group pou rezim lide ki li pe defann.

## Exersis 3

Apartir bann explikasion ki finn done, prepar enn deba lor enn bann size ki swiv:

1. Enn sosiete ki miltileng ena plis potansiel devlopman.
2. Bann lang kreol enn fami lang kouma ninport ki lezot fami lang.
3. Bizin servi lang maternel dan koumansman skolarizasion.

<!-- image -->

Pratik deba finn invante par bann Grek. Bann filozof, orater, ekriven ek mem bann sinp sitwayen ti ena labitid diskit an piblik lor bann size inportan dan zot sosiete. Pratik deba kot bann Grek, li lie avek prinsip fondamantal 'demokrasi' . La,  pouvwar (mo grek pou 'pouvwar' li 'kratos' , '- krasi' dan Kreol) dan  lame  tou  bann dimounn dan enn sosiete (mo grek pou dimounn li 'demos' , 'demo-' dan so form Kreol) .

In this image we can see a group of people sitting on the floor. In the background there is a building.

<!-- image -->

## Ribrik 6 Tradiksion

Tradiksion se enn konpetans ki devlope avek pratik. Lir bann text ki swiv ek tradir zot. Pa bliye fer referans bann explikasion ki ena dan 3 premie sapit.

## Exersis 1

## Tradir bann text swivan ver Angle ou Kreol Morisien.

1. Se a sa moman-la ki Polly ti rant dan lasam. So zoli visaz ron ti krispe.  So regar ti sever. Sis gro roulo roz flio ti pe tini so seve ek enn fisi delave ti poze lor so latet. Li ti ena sinkant an me li ti paret swasant fasil.

Extre: Tom Kamaleon, Jason Lingaya. (2017)

2. Every 21st June, the Fête de la Musique is celebrated in France. It is a very popular festival and all the events are free. Participants are both professionals and amateurs. A lot of French people play music. This festival started in 1982.
3. Ti ena enn fwa enn vie bonnfam ki ti ena enn garson, me pov boug-la ti bien bet. Enn zour so mama avoy li aste enn lasi bazar. Ler li retourne, li pe zwe-zwe ek sa lasi-la ziska maler arive, li al koup latet mouton so mama! So mama ankoler, zour li, dir li: 'To ti bizin met li dan enn saret lapay, pa ti pou ariv sa!' Garson dimann pardon, promet li pou fer atansion lot kout.

Adaptasion 'Zistoire éne malinbougue' , Le Folk-lore de l'île Maurice, Ch. Baissac. (1888)

4. When asked to introduce herself, Jen said, 'I am 16 and I go to college. I also volunteer for an NGO. I do lots of things for them. I type documents and do research on the internet. I think that we must all help each other. This has enabled me to learn a lot.'

## Ribrik 7 Literatir

## Nouvel

## Ki ete enn nouvel?

Enn nouvel, se enn tip text ki zeneralman kourt. Parey kouma enn roman, li rakont enn zistwar. Li telman kourt ki nou kapav lir li enn sel kout konpare ek enn roman ki nesesit enn lektir plizier zour. Nou osi konstate ki ena tigit personaz. Ena enn sel sitiasion ou intrig, e zistwar-la deroul otour samem. Enn nouvel kapav ena kouma personaz prinsipal bann zanimo. Li kapav drol ek komik, me li pa touletan ena enn moral. Langaz ki servi dan enn nouvel direk pena siperfli pou ki denouman zistwar-la arive san fer bann detour initil.

In this image we can see a book with a few lines and a few lines of text on it.

<!-- image -->

## Reflexion

Reflesi ek propoz enn similarite ek enn diferans pou bann zanr literer ki to finn etidie ziska ler dan ribrik Literatir (fab, roman, nouvel).

9

## Lektir ek apresiasion enn extre depi enn nouvel

## Korbo

Mo ti pe asize lor enn sez. Dan enn saldatant. Tou bann lezot sez ti vid me mo ti ena linpresion mo pa ti tousel. Lasal-la, ki ti penn an kouler blan, ti bien ilimine. Ti enn drol kalite iliminasion selman. Ki ti ni depi enn glob ni depi enn tib. Ni depi soley ousi. Wadire lalimier lalinn mem si ti gran lizour. Enn lalinn eklipse, kler-obskir. Ti ousi ena de-trwa pofler. Dan ki pa ti ena fler. Dan enn kwin, ti ena enn poubel ki ti vid. Ti ena salte otour poubel-la. Omilie lasal-la ti ena enn ti latab dibwa ki ti ena form enn krwasan. Enn gro parasol zonn ti pe kouver latab-la lor ki ti ena enn vie magazinn. Ki mo ti pe atann? Kisann-la mo ti pe atann? Mo bien lapenn dir. Kouma mo ti pe plin ar atann, mo'nn pran enn magazinn mo'nn koumans lir. Ti ena enn interview enn korbo ki ti pe travay ramas salte. Zame mo'nn lir interview enn korbo dan mo lavi, ek ti premie fwa ki mo tann dir ki ena korbo ki travay ramas salte. Mo'nn koumans lir lartik-la avek boukou plezir.

Zournalis: Ou travay ramas salte. Ou mem premie zanimo ki travay. Ki sa fer ou resanti koumsa?

Korbo: Enn gran santiman fierte pou tou fami zwazo me sirtou pou kominote korbo.

Zournalis: Depi kan ou'nn koumans travay?

Korbo:

Sa fer plis ki de mwa. Me, pou revinn lor ou kestion konsernan premie zanimo ki travay, sannla-la mo pa tro sir. Se enn tro gran loner ki ou pe fer mwa. Mo krwar mo bizin fer atansion. 'Apprenez, monsieur, que tout flatteur vit au dépens de celui qui l'écoute.'

Zournalis: Pa gagn traka. Mo pa atire ek ou manze ek ousi pena okenn fromaz dan  ou  labek.  Ou  pa  zis  koz  Kreol  me  Franse  ousi?  Ou  enn  korbo poliglot tou?

Korbo: Wi Kreol mo lalang maternel, me dan anvol parsi, anvol parla, mo'nn aprann lezot langaz ousi. E kouma nou abitie dir: Franse ze koz, Angle ze debriy. (Li kas enn gran riye)

Anmemtan ki mo ti pe lir ki korbo-la ti kas enn gran riye apre so repons, wadire mo'nn tann riye ousi.  Selman, ler mo ti get otour mwa, pa ti ena nanye mem. Okenn sours riye.

<!-- image -->

Extre Longanis, saser, korbo ek lezot ti zistwar , enn rekey nouvel par Aanas Ruhomaully (2016).

## Kestion

- a. Ki travay korbo fer?
- b. Donn enn rezon kifer korbo kapav personaz prinsipal sa text-la.
- c. Ki to panse vedir term 'poliglot'?

## A-propo sa text-la:

Aanas Ruhomaully enn oter morisien ki finn prezant sa nouvel-la dan enn rekey pou premie konkour literer organize par Creole Speaking Union an 2015. So text ti prime dan kategori 'Nouvel' .

Longanis, saser, korbo ek lezot ti zistwar enn rekey ki regroup wit nouvel.

## Kestion

- a. Ki latmosfer ki kree dan koumansman sa nouvel-la? Ki bann eleman inportan kontribie a sa latmosfer-la?
- b. Dapre sa extre-la, ki to kapav dedwir lor Korbo so personalite?
- c. Fer enn ti resers lor seki korbo dir: 'Apprenez, monsieur, que tout flatteur vit au dépens de celui qui l'écoute.'

Ki so lorizinn, ek kifer korbo servi sa kouma enn replik pou so interlokiter?

## Sapit 5

## Perspektiv lor lavenir

<!-- image -->

- Sapit 5

Kreol Morisien

|

Lir sa text-la, answit reponn bann kestion.

## KI POU SWAZIR?

In this image we can see a person's legs and shoes. We can also see a drawing on the road.

<!-- image -->

Lane Grad 9, se enn lane bien inportan parski kan sa lane-la fini,  to  pou  finn  bizin  swazir  ki  bann  size  to pou fer dan Grad 10. E souvan, swa ki to fer pou Grad 10 determinn seki to pou fer plitar, dan Grad 12 ek 13, oubien mem ki travay to pou fer kan to kit lekol. Donk, sa swa-la li krisial .

Me kouma fer pou fer enn bon swa? Kouma nou kapav sir ki swa ki nou fer asterla li bon pou nou lavenir? Mo bizin dir ki pena enn sel repons pou sa bann kestionla. Tou dimounn diferan e kontext kot nou viv diferan. Donk, pena enn sel repons ki pou al ar tou dimounn. Parkont, mo kapav dir zot ki tou repons depann lor mem zafer: enn bon konesans nou personalite, bon informasion ki nou ena ek soutien bann dimounn ki ena lexperians.

Kan nou bizin fer bann swa, li extremman inportan ki nou kone ki kalite dimounn nou ete, savedir ki nou kontan dan lavi, ki nou bann defo, ki nou bann kalite. Eski nou enn dimounn ki kontan pas letan dan lanatir oubien  nou  prefer  res  dan  lakaz?  Eski  nou  kontan travay an-group oubien nou kontan tousel dan enn kwin?  Pou sertin dimounn, li bien konplike reponn sa bann kestion-la, pou lezot li pli sinp. Me li inportan ki sakenn pran letan pou li trouv so prop repons parski zot swa depann lor enn bon konesans zot personalite. Enn zafer ki fode pa bliye: se zot ki ena lakle zot personalite.

Enn fwa ki zot finn trouv sa bann repons-la, li neseser ki zot al rod linformasion lor bann size oubien bann domenn ki interes zot. Internet finn vinn premie mwayin rod linformasion zordi. Zot kapav vizit bann sit zeneralize oubien al lor bann sit pli spesialize. Zot kapav al lor bann blog  ki  bann  dimounn  ekrir  lor  zot  bann  sant  lintere.  Sit  bann  liniversite  enn  bon resours ousi. Zot kapav ed nou konpran kot bann size kapav amenn nou. Tousala, pou permet enn aprofondisman nou konesans.

Anfin, zot kapav ousi koz avek bann dimounn otour zot. Bann dimounn ki pli pre ar  zot, se zot paran. Zot bizin pran letan pou diskite ek ekoute ki bann paran dir zot parski bann paran ena experyans lavi ek experyans travay. Anplis, se bann dimounn ki kontan zot e ki pou fer tou pou donn zot bann meyer sans dan lavi. Answit, dan boukou lekol zordi, ena bann profeser ki fer 'Careers' ; se bann profeser ki finn forme pou ed bann zelev reflesi ek fer bann swa pou zot bann size me ousi, souvan, pou karyer ki zot pe pans swazir. Finalman, si zot gagn lasans, zwenn bann profesionel ki pe travay dan domenn ki interes zot, profite koz ar zot e poz tou kestion ki zot ena.

Si zot servi enn konbinezon sa trwa letap ki nou finn mansione-la, zot ena boukou sans fer enn swa ki adapte avek kalite dimounn ki zot ete.

Enn dernie ti konsey: kan zot pe koumans reflesi, touzour koumans par pli vag pou al ver pli spesifik.  Par  exanp, dan sa tablo ki pe swiv, ena 3 kolonn: premie-la dir bann domenn bien vag e de lezot-la vinn pli spesifik. Sa kapav donn zot enn lide kouma zot kapav reflesi dan zot domenn.

| Zeneral       | Spesifik            | Pli spesifik                |
|---------------|---------------------|-----------------------------|
| Sians         | Medsinn             | Pediat                      |
| Biznes        | Marketing           | Lavant prodwi elektromenaze |
| Travay maniel | Elektrik            | Kree enn antrepriz elektrik |
| Teknolozi     | Inzenier informatik | Robotik                     |
| Lamizik       | Mizisien            | Ravanie                     |

## 1. Reponn par Vre (V) ou Fos (F). Zistifie sak repons.

In this image we can see a table with some text on it.

<!-- image -->

|                                                            | V/F        |
|------------------------------------------------------------|------------|
| a. Swa size dan Grad 9 pena okenn inportans pou lavenir.   | __________ |
| b. Si tou dimounn ti parey, tou dimounn ti pou fer memswa. | __________ |
| c. Swa ki enn dimounn fer depann lor so personalite.       | __________ |
| d. Paran inportan parski zot ena experyans.                | __________ |
| e. Enn travayer maniel kapav kree enn antrepriz.           | __________ |

1. Ki savedir 'kontext kot nou viv diferan'?
2. Dapre twa, kifer pou sertin dimounn li difisil reponn bann kestion lor zotmem?
3. Reformil sa fraz-la: 'se zot ki ena lakle zot personalite' .
4. Ki ete enn 'blog' ?
5. Ki kontribision bann profesionel kapav amene dan nou swa?
6. Donn 2 travay 'pli spesifik' ek diferan, ki enn dimounn ki interese par lamizik kapav fer.
7. Dapre loter, ki 2 obzektif final bizin ete kan nou swazir enn travay.
8. Dan mwins ki 50 mo, rezim 3 etap ki loter dir bizin pase pou fer enn swa.
9. Explik bann mo swivan:
- a. krisial
- b.  extremman
- c. resours
- d.  konbinezon
- e.  lavansman

## 10. Trouv bann tradiksion ki apropriye pou bann mo ek expresion ki swiv, dapre manier ki finn servi zot dan pasaz.

| Kreol Morisien   | Angle     |
|------------------|-----------|
| determinn        |           |
| soutien          |           |
| bliye            |           |
| spesialize       |           |
| experyans travay |           |
|                  | choose    |
|                  | teamwork  |
|                  | general   |
|                  | therefore |
|                  | advice    |

## Lavenir

Tania, Joey ek Ravi trwa meyer kamarad ki ti zwenn pou premie fwa dan lekol primer.  Profeser ti met zot asiz ansam pou fer enn devwar kot zot ti bizin diskit lor zot bann proze fitir.

Sa lepok-la, Tania ti reponn ki li reve vinn enn otes-de-ler. Sa ti pou permet li vwayaze pou dekouver bann lezot orizon. Joey ti riye ek ti dir ki li bon ena bann rev, me kifer li pa fer kiksoz pou so pei? Joey ti ena lanbision pou vinn enn polisie pou servi so pei. Enn gran diskision ti pou eklate ant sa de-la si Ravi pa ti intervenir. Ravi ti dir zot ki pa ti ena okenn bon ou move swa pou fer. Toulede ti ena rezon ek zot ti ena drwa fer seki zot anvi plitar. Ravi ti ousi rakont zot seki so mama finn touletan dir li: lemond ase gran pou akeyir sakenn so vizion ek so rev . Ena plas pou zot tou zot vizion lavi. Ravi, de so kote, ti anvi vinn enn papa plitar. Li ti touletan admiratif devan so papa ki ti abitie okip so kat zanfan apre so ler travay. Sa ti toultan fer li reve ena bann zanfan plitar. Anplis, bann konsey ki so mama ti donn li finn amenn enn mision dan so latet: kifer pa partaz sa bann ti koze-la evek so bann prop zanfan dan lavenir?

Kan so de kamarad finn ekout Ravi so pwin-de-vi , zot ti etone par sinplisite so panse. Zot finn res trankil pandan enn bon moman, apre toule trwa zanfan finn deside pou forz enn lamitie pou lavi. Avek letan, zot finn terminn lekol primer ek finn debark dan kolez. Apre trwa lane dan kolez, zot finn realize ki lavi pa otan fasil ki zot ti panse kan zot ti tipti.

Zot finn konn esek, bann konplex ek bann dout, ek enn miltitid problem ki relie ek ladolesans. Zot finn gagn bann moman febles, me kan toule-trwa zwenn, koumadir lespwar renet a sak fwa andan zot. Enn lalimier invizib ekler zot sime, ek zot trwa lespri fonksionn kouma enn sel.  Lerla, zot bliye tou bann negativite ek fonse pou get divan.

Aster ki zot finn gagn kinz-an, zot bann perspektiv lor lavenir finn agrandi. Tania finn dekouver ki  li  ena  enn  lamour pou kwafir ek pe panse pou lans li ladan. Li nepli anvi vwayaze akoz li realize ki so bann paran dan laz, ek li prefer res avek zot. Joey kone ki plitar li pou vinn enn aktivis , parski li santi ki li bizin denons bann problem ki ena otour li. Me li realize ki sa an konfli avek so rev lontan: vinn enn polisie. Avan li fini kolez, kitfwa, li pou gagn inpe plis lekleraz lor seki li bizin fer. Ravi, de so kote, finn anvi aret letid apre kolez ek fer so prop biznes otour bann plant ek legim. Pou premie fwa, li gagn konfli ek so papa, akoz li ti ena lezot proze pou Ravi. Me aster-la, se Joey ek Tania ki rapel Ravi ki li bizin res ouver a so prop vizion lor lavi.

## Exersis 1

## Konstrir enn rezo lexikal avek omwin 10 mo pou sakenn sa bann tem-la. Finn fer enn lexanp pou twa.

Lespwar : espere, lasans, respire, viv, deziem sans, ankouraze, lafwa, eseye, pozitif, vinker

- a. Metie
- b. Lanbision
- c. Rev
- d. Pozitivite
- e. Diskision
- f. Vizion
- g. Pwin-de-vi
- h. Miltitid
- i. Biznes

## Exersis 2

## Relie sak mo ek so definision. Finn fer enn lexanp pou twa.

| Mo          | Definision                                                                                                                                      |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Frilans     | Enn dimounn ki fer bann kanpagn pou amenn bann sanzman nivo sosial, anvironnmantal, politik, etc.                                               |
| Reflexion   | Enn momandan letan ki pa ankor arive.                                                                                                           |
| Filozofi    | Enn dimounn ki pa okip enn travay fix, meki souvan travay a so prop vites avek enn ou plizier kontra.                                           |
| Korperativ  | Aksion panse, reflesi ou bien medit lor kiksoz.                                                                                                 |
| Aktivis     | Enn group dimounn ki zwenn ansam pou fer enn antrepriz, ek apre partaz zot profi dan enn fason egal.                                            |
| Lavenir     | Enn brans letid ki poz bann kestion lor nou lexistans, ou bann panse ki enn dimounn ena lor manier ki li bizin viv, fer bann swa, reflesi, etc. |
| Antreprener | Enn dimounn ki ouver so prop biznes. Li pran risk, investi, gagn profi lor so prop kont.                                                        |

## Exersis 3

Sak mo anba ena enn omonim. Rod so definision ek fer enn fraz avek sakenn.

- a. reflexion
- b. batri
- c. rans
- d. tablet

## Exanp: regar

- i. regar: enn konter delo ou enn laparey ki mezir konsomasion delo

Toule semenn, enn travayer CEB vinn chek so regar delo.

- ii. regar: fason ki nou pe get kikenn

Li pe lans mwa bann regar pertirbe akoz li pe gagn traka.

In this image, we can see some plants.

<!-- image -->

## Ribrik 3 Lortograf

## Tretman let 'x' , 'ks' ek 'gz'

Dan KM, nou servi let 'x' pou reprezant son [ks] sirtou dan bann mo relativman kourt, par exanp tax, taxi, box, fax .

Nou ousi servi let 'x' pou reprezant son [gz], par exanp examen, exazere .

Nou servi let 'k+s' pou reprezant son [ks] pou lezot mo, pou bann rezon klarte ek lizibilite an akor ek bann lezot lang ki dan kontext morisien par exanp aksidan , aksan , aksepte , perfeksion .

<!-- image -->

## Exepsion

'x ' servi dan tou bann ka kot ena son [gz] ( exit , lexame , exazere , exile , etc.) sof dan enn ka ki fer exsepsion: sigzere .

## Exersis 1

## Ranplas par ks ou x.

1. So bann profeser dir ki so bann travay e\_\_elan.
2. Sa artis-la ena boukou si\_\_e.
3. Bizin ena boukou refle\_\_ kan kondir.
4. Bann zelev bizin prepar enn e\_\_poze lor ladrog.
5. Angela ena enn zoli a\_\_an kan li koz Franse.
6. Pou e\_\_kirsion, nou profeser ti amenn enn de\_\_i briani pou partaze.
7. Tou zanfan oblize gagn a\_\_e ledikasion.
8. Sa devwar matematik la bien konple\_\_.

## Ribrik 4 Gramer

## A. Fraz konplex

Enn fraz ki kontenir plis ki enn verb ek enn size, se sa ki nou apel enn fraz konplex . Nou kapav konsidere lerla ki li konpoze avek plizier fraz sinp.

## Ena trwa fason pou kre bann fraz konplex:

- zixtapozision
- kordinasion
- sibordinasion.

## 1. Zixtapozision

Pou kre enn fraz konplex par zixtapozision, nou azout enn sign ponktiasion ant bann diferan fraz sinp. Sa sign ponktiasion kapav swa enn virgil, swa de-pwin, swa enn pwin-virgil.

## Exanp fraz konplex zixtapoze:

- a. Mo galoupe, mo mank respirasion.
- b. Jordy ti perdi: li ti perdi sime.
- c. Feroz ti al fer shopping; li ti aste enn simiz.

## 2. Kordinasion

Pou kre enn fraz konplex par kordinasion, nou azout enn konzonksion kordinasion ant de fraz sinp (reget Sapit 1 pou lalis bann konzonksion kordinasion) .  Kouma nou finn trouve avan, nou servi enn konzonksion kordinasion pou zwenn ansam de kitsoz ki parey (lor mem nivo) . Isi nou servi enn konzonksion kordinasion pou zwenn ansam (omwin) de fraz sinp.

## Exanp 1

In this image there is a table with a few things on it.

<!-- image -->

Dan ka nou pe anvi met ansam plis ki de fraz sinp, nou pou servi enn konzonksion kordinasion zis ant avan-dernie ek dernie fraz sinp. Ant tou bann lezot ki ena avan, nou pou servi enn virgil. Nou pa oblize remet size ek marker TMA si se mem size pou tou bann fraz sinp ek si tou aksion sitie dan mem letan.

Exanp 2

In this image there is a table with a few rows and a few columns. In the first column there is a text and in the second column there is a text.

<!-- image -->

| Mofinn lir enn BD,   | ouver modiksioner   | ek          | dekouver boukou kitsoz   |
|----------------------|---------------------|-------------|--------------------------|
| fraz sinp            | fraz sinp           | konzonksion | fraz sinp                |

## Exanp fraz konplex kordone:

- a. Mo galoupe e mo mank respirasion.
- b. Jordy ti perdi donk li ti pe panike.
- c. Feroz ti al fer shopping me li ti ariv tro tar.
- d. Marianne ni kontan fer spor ni kontan desine.

## 3. Sibordinasion

Pou kree enn fraz konplex par sibordinasion, nou azout enn konzonksion sibordinasion ant de fraz  sinp (reget Sapit 1 pou lalis bann konzonksion sibordinasion) .  Kouma nou finn trouve avan, nou servi enn konzonksion sibordinasion pou zwenn ansam de fraz ki pa parey (pa lor mem nivo) :  nivo  pli  inportan, nou apel li propozision prinsipal ek nivo segonder, nou apel li propozision sibordone.

Propozision sibordone la depann lor propozision prinsipal la. Kan nou pe koz depandans enn propozision lor enn lot, nou pe dir ki aksion dan propozision prinsipal pli inportan ki aksion dan propozision sibordone dan sa fraz konplex la. Setadir ki propozision sibordone vinn donn enn informasion siplemanter lor aksion prinsipal (ki rezon sa aksion-la pe arive, kan li pe arive, kotsa li pe arive, ki kondision neseser pou li arive, etc.).

Isi nou servi enn konzonksion sibordinasion pou zwenn ansam (omwin) de fraz sinp ki pa lor mem nivo.

## Exanp

Davina pou al bibliotek akoz li kontan lir.

Dan sa fraz konplex la, nou ena enn propozision prinsipal ('Davina  pou al bibliotek') ek  enn propozision sibordone ('akoz li kontan lir') ki  introdir par konzonksion sibordinasion 'akoz' . Sa propozision sibordone la vinn donn enn informasion siplemanter lor rezon pou lakel 'Davina pou al bibliotek' .

## Exersis 1

Bann fraz swivan, zot bann fraz konplex. Dir par ki fason finn kree sa bann fraz-la (zixtapozision, kordinasion, sibordinasion) .

- a. Mo pou al laboutik tanto, mo pou aste biskwi.
- b. Kouma nou lekip finn bien prepar li, li finn gagn konpetision.
- c. Mo kontan manz sokola me mo bizin pa manz tro boukou.
- d. Pa ekout tou seki li pe dir twa: to pe perdi to letan.
- e. Kan nou pou retourne, nou pou ena boukou meday.
- f. Get dan drwat, mo get dan gos.
- g. Li finn galoupe pou 100-met ek li finn gagn lekours-la.
- h. Mem si mo pou vini boner, mo pa sir pou gagn plas devan.
- i. Li finn pare pou vini parski li finn prepar so sak yer swar.
- j. Nou pou ni manz burger ni bwar gazez.
- k. Anou aste enn ravann pou nou met lanbians.
- l. Mo vwazin so lisien finn bien zape aswar: li finn anpes mwa dormi.

## Exersis 2

Kre  enn  fraz  konplex  kordine  apartir  sa  de  fraz  ki  finn  done (parfwa  finn  fini  donn  twa  enn konzonksion kordinasion) :

- a. Mo pou al boulanzri tanto. Mo pou aste trwa dipin. (ek)
- b. Mo kontan zwe volleyball. Mo pa kontan sa lekip anfas la. (me)
- c. Mo vini tanto. Mo vini demin. (swa)
- d. Mo pa kontan manz karot. Mo pa kontan bwar dite. (ni)
- e. Eski li pou kwi manze tanto? Eski li pou al restoran tanto? (ou)
- f. Ramas bann salte. Zet zot dan poubel. (ek)
- g. Li pou al naze lamer. Li pou al naze dan pisinn. (ouswa)

## Exersis 3

Servi bann konzonksion sibordinasion ki finn done pou kree bann fraz konplex apartir bann fraz prinsipal ki swiv.

- a. Mo pou al fer shoping tanto. (akoz)
- b. Li nepli al lantrennman. (depi ki)
- c. Li finn al dan stad. (pou)
- d. Mo pou pret twa mo bann kreyon. (si)
- e. To pou fer sa desin. (ki)

- f. Li manz so dipin. (mem si)
- g. Mo ti bien prepar mwa pou lexamen final. (avan ki)
- h. Mo mama ti al bazar. (pandan ki)
- i. Li pou donn mwa sa reset-la. (kouma)
- j. Nou pou gagn konpetision badminton. (kan)

## B. Transformasion fraz

Dan Sapit 4 nou finn trouve ki ena diferan tip ek diferan form fraz. Nou kapav transform enn fraz kan nou azout enn ou plizier mo ek nou sanz so ponktiasion.

## Exanp.

Nou azout enn mo interogatif ek met enn pwin interogasion pou transform enn fraz deklaratif an enn fraz interogatif.

Fraz deklaratif:

To manz poul.

Fraz interogatif:

Eski to manz poul?

## Aster, anou observ sa bann fraz-la:

1. Bernard , li kontan manz gato.
2. Se sa tifi-la ki mo kontan.

## Ki nou remarke?

Ena lanfaz lor bann mo ki an gra.

Kan nou anvi met lanfaz lor enn kiksoz, nou fer seki nou apel enn fokalizasion . Nou focus lor kiksoz-la. Ena diferan fason fer fokalizasion lor enn parti fraz.

Enn fason fer enn fokalizasion san transform enn fraz, se par intonasion kan koze Par exanp, nou kapav insiste lor enn mo ou enn group mo pou met lanfaz lor li.

.

- a. Kevin le manz ziromon.
- b. Kevin le manz ZIROMON.
- c. KEVIN le manz ziromon.

## Aster, nou observ sa de fraz-la:

- a. Sahil kontan manz pom.
- b. Sahil , li kontan manz pom.

## Ki nou remarke?

Nou finn met lanfaz lor 'Sahil' , ek nou finn avoy li dan gos, ek nou finn repran sa size-la avek pronom 'li' .

Nou apel sa transformasion-la enn dislokasion. Enn dislokasion se enn prosede kot nou met lanfaz lor enn parti enn fraz ek nou repran sa parti lor ki nou pe met lanfaz-la par enn pronom. Nou kapav fer  enn  detasman agos (kouma nou trouve dan lexanp lao ou nou kapav fer enn detasman adrwat , kouma nou trouve dan bann exanp anba) . Lerla nou apel li enn dislokasion agos ouswa enn dislokasion adrwat.

Dislokasion adrwat pli rar, me li kapav existe.

- a. Sa boug-la finn vini.
- b. Li finn vini, sa boug-la .

Dan  bann  exanp  lao,  nou  trouve  ki  nou  finn  fer  dislokasion  size  enn  fraz.  Nou  ousi  kapav dislokaliz obze enn fraz.

- a. Sahil kontan manz brinzel.
- b. Brinzel , Sahil kontan manz sa .
- a. Mo finn trouv sa zanfan-la.
- b. Mo finn trouv li , sa zanfan-la .

## Exersis 1

Pou sak fraz ki swiv, dir ki tip dislokasion ena (agos ou adrwat) ek reper pronom ki pe repran li.

1. Sa zi-la, mo pou bwar li plitar.
2. Sa zoli tifi-la, li pe mont bisiklet.
3. Mo kontan li, sa garson-la.
4. Nou pou vini taler, mwa ek mo bann kamarad.
5. Li pa pe dormi depi trwa semenn, Christophe.

Aster, nou observ sa bann fraz-la:

- a. Li finn kas mo tas.
- b. Se li ki finn kas mo tas.
- c. Se mo tas ki li finn kase.

Kouma nou trouve, dan (b), nou finn met lanfaz lor pronom personel 'li' ek dan (c), nou finn met lanfaz lor 'mo tas' .

Nou apel sa kalite transformasion-la enn klive .

Nou pa oblize met 'se' , kouma nou trouve dan bann exanp anba.

- a. Mario enn dokter.
- b. Mario ki enn dokter.

## Exersis 2

1. Sa tablo-la kouler blan. (dislokasion adrwat)
2. Francis enn bon santer. (klive)
3. Lor sa montagn-la ena bann zoli fler. (klive)

## Ribrik 5 Prodiksion oral ek ekri

## Tem: Sitwayennte

Dan ribrik prodiksion oral ek ekri, to finn aprann ekrir let informel ek let formel. To finn ousi aprann organiz to bann lide ek konstrir to lopinion lor bann fe obzektif atraver enn deba. Sa bann form kominikasion-la,  zot  egalman  fer  parti  lavi  enn  sitwayen  ki  ena  bann  drwa  dan sosiete.

Nosion sitwayennte, li relie avek sa bann drwa ek devwar la.

## Exersis 1

Apartir bann mo ki finn done dan sa zimaz-la, reflesi lor bann drwa ek devwar ki enn sitwayen ena.

In this image, we can see a diagram, which is in the shape of a circle. In the center of the circle, we can see the text. On the left side, we can see the text. On the right side, we can see the text. In the background, we can see the image of a map.

<!-- image -->

## Kestion

1. Dapre twa, lekel parmi sa bann aspe-la bann drwa ek lekel bann devwar?
2. Eski to panse ki tou dimounn dan lasosiete ena sa bann drwa-la? Donn inpe exanp pou ilistre to lopinion.
3. Antan ki enn zenn, ki drwa ki pli inportan pou twa? Kifer?
4. Si to trouve ki enn dimounn so drwa pa pe respekte, ki devwar to ena antan ki enn sitwayen? Ki to kapav fer pou fer sa dimounn-la so drwa respekte?

## Exersis 2

To finn temwin enn inzistis e to anvi denons sa. Enn opsion ki to ena, se ekrir enn lartik ki pou paret  dan  zournal.  Prezant  to  bann  argiman  dan  enn  fason  striktire.  Servi  bann  exanp  pou soutenir zot. (50 - 100 mo)

In this image we can see a picture of a person holding a gun.

<!-- image -->

## Ribrik 6 Tradiksion

Tradiksion, se enn konpetans ki devlope avek pratik. Lir bann text ki swiv ek tradir zot. Pa bliye pran an kont bann explikasion ki to finn gagne dan 3 premie sapit.

## Tradir bann text swivan ver Angle ou Kreol Morisien.

1. Mo finn al partou. Pou al get lanez tonbe, pou al get Big Ben sone. Oubien pou get dimounn mont lor latour Eiffel. Pou get avion pas ant gran-gran batiman dan New-York. Dekole. Aterir. Anvole. Poze. Tousala mo finn fer. Lanwit, lizour, bo tan, move tan. Vwayaze. Zordi, mo zenes finn ale. Mo kone pou ena lot zenes ki pou al pran avion ou bato.
2. Enn lorkes se enn group mizisien ki zwe ansam lor plizier instriman. Kapav arive ki enn lorkes zwe tousel, me arive ki enn lorkes zwe avek bann santer. Lorkes fer konser ek zot zwe pou bann spektak bale oubien lopera. Kan nou koz lorkes, an zeneral, nou pe koz lorkes sinfonik. Zot ena boukou instriman e laplipar ditan, zot zwe lamizik klasik dan bann konser.
3. Nowadays, a lot of youngsters smoke. I don't because I think it's very dangerous. Smoking causes heart and lungs diseases and increases the probability of cancer. Many people smoke because they believe it's cool. They want other people to think that they are grown-ups. But I think that this is not very intelligent.
4. During the month of July, many tourists come to Mauritius. Most of them come from France, United Kingdom and Germany. They usually go to hotels because they like the beach and its  activities.  In  recent  years,  however, many of them stayed in smaller accommodations because they want a more authentic experience.
5. Learning  a  foreign  language  is  a  great  way  to  learn  about  another  culture.  People  use different means to learn. Some watch TV. Others listen to songs while others join language groups. No matter which way you decide to learn, the most important thing is that the learning experience is enjoyable.

## Ribrik 7 Literatir

Teat

Exersis 1

Observ sa desin-la. To finn deza al dan enn plas koumsa? Dekrir bann eleman ki atir to latansion.

In this image we can see the inside view of the theater. In the theater there are red color chairs and curtains.

<!-- image -->

Exersis 2

Ki bann mo ki vinn dan to lespri kan to trouv ou tann mo Teat?

In this image we can see a cloud and a sketch.

<!-- image -->

## Kan nou koz Teat

Atraver letan, bann pies teat finn distrer ek instrir bann dimounn ek finn donn lavi bann personaz ki lor papie. Pena narater, alor se bann personaz ki fer zistwar-la avanse.

Lorizinn bann performans teatral remont a lepok bann Grek, avan Zezi-Kris. Bann pies teat sa lepok-la ti ena bann fonksion relizie, sosial ek edikatif.

Teat amenn enn text literer devan enn lodians dan form enn spektak viziel. Sa spektak viziel la regroup bann akter ki interpret bann personaz dan enn zistwar. Enn pies teat kapav ousi ena interpretasion mizikal kouma opera.

- Enn pies teat kapav enn:
- -Trazedi
- -Komedi
- -Dram

## Reflexion

Fer enn ti resers pou kone ki vedir enn trazedi, enn komedi ou enn dram.

9

## Ala inpe term ki servi kan etidie enn text teat:

| Dialog Lansanb bann parol ki esanze ant bann personaz.                                                          |
|-----------------------------------------------------------------------------------------------------------------|
| Replik Text ki prononse par enn personaz (text-la kapav destine personaz).                                      |
| Tirad Enn long replik ki enn personaz fer.                                                                      |
| Monolog Enn replik kot enn personaz pe koz avek limem, souvan santiman ou met lord dan so latet.                |
| Aparte Bann replik ki enn personaz dir apar (pa avek enn lezot replik-la destine indirekteman a bann spektater. |
| Didaskali aksion-la pe deroule, lantre ek sorti bann personaz, deskripsion                                      |

Anou lir ek etidie extre enn text teat.

Ak 1 Senn 2:

(Tou dimoun pe asize dan lamor. Dimounn pe rantre pou prezant zot sinpati.)

## Sante

Kot konper Robin ete?

Li finn mor, mor, mor, mor, mor, mor, mor.

Gramatin mo'nn fek trouv li ar so linz travay.

Me li'nn mor, mor, mor, mor, mor, mor, mor.

Mwa mo'nn fek trouv li ver midi bien vivan, bien fringan.

Me lamor finn vinn kouma enn voler, nek finn kokin li.

Mor, mor, mor, mor, mor, mor, mor.

Enn sel kout koutou finn tir so lavi

Aster li dan paradi akot tou so bann fami.

Li finn mor, mor, mor, mor, mor, mor, mor.

Robin inn mor…

(Kan sante fini, Bess rantre ek fler dan so lame. Li al devan kanape, tourn ek Serena, verse pou anbras li.)

In this image we can see a group of chairs.

<!-- image -->

Clara:

Kisann-la pe vinn ar Porgy?

Maria:

Bess.

Jake:

Bess?

Serena:

Mo pa bizin ni to fler ni to sinpati.

Bess:

Porgy ki'nn dir mwa amenn sa.

Serena:

Poz li la alor.

(Bess poz fler devan serkey, al asize. Lapriyer ek tan silans kouma dan veye.)

Porgy:

Segner, twa ki kone ki bon, ki pa bon. To kone Robin ti enn bon boug. Aster li'nn fatige e li pe retourn lakaz. Anvway to lame e pran li ar twa. Mersi Segner.

Tou dimounn:

Mersi Segner.

(De-trwa gard rantre. Zot koz ek bann dimounn pou kone kisannla Serena)

Clara:

Gard pe vini!

Gard 1:

Misie, madam, bonzour. Oumem so madam?

(Serena bouz so latet.)

Gard 1:

Sinpati. (Li get bann lezot) Kot Pier?

Ton Pier:

Wi?

Gard 1:

Mo pe aret twa pou lamor Robin.

Ton Pier:

Ki li pe dir?

Maria:

Pa li sa!

Ton Pier:

Ki li pe dir?

Maria:

Li pe kwar ou ki'nn touy Robin.

Ton Pier:

Be pa mwa sa.

Gard 1:

Pa twa sa, kisann-la sa?

Ton Pier :

Crown sa! Mo'nn trouv li!

## Apropo sa text-la:

Porgy ek Bess enn opera ki finn ekrir an Angle par George Gershwin.  Li baze lor enn ti roman ek enn pies teat ki apel Porgy .  Se an 1935 ki sa opera-la ti zwe pou premie fwa dan enn teat dan Boston, Lamerik.

Sa opera-la finn tradir an Kreol Morisien par Marjorie Munien. Dan Moris, li finn zwe an 2013 dan Case Noyale, Grand Gaube ek Mahebourg. Se ousi pies ki finn fer louvertir Caudan Arts Centre an Desam 2018.

## Kestion

1. Komie personaz pran par dan sa extre-la?
2. Kisann-la finn mor e kisann-la pe fer dey dan sa extre-la?
3. Ki bann didaskali ena dan sa extre-la? Kouma sa ede pou sitie nou dan text-la?

In this image we can see a stage with red curtains and a wooden floor.

<!-- image -->

The image is a colorful graphic with a mix of orange and green colors. The background is white, and the graphic is made up of overlapping circles and ovals. The colors are vibrant and saturated, giving the image a lively and cheerful feel.

The image is divided into two main sections: the upper and the lower part. The upper section is a solid orange color, while the lower section is a mix of green and red colors. The orange color is more prominent in the upper section, while the green and red colors are scattered throughout the lower section.

The overall design of the image is visually appealing and has a cheerful, vibrant feel. The use of overlapping circles and ovals creates a sense of depth and movement, while the colors add a pop of color and make the image more visually engaging.

The image is likely intended to be used as a background for a graphic design or a poster. The use of overlapping circles and ovals suggests a playful and dynamic design,

<!-- image -->