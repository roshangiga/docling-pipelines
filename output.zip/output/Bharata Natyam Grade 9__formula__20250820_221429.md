In this image we can see a poster with some text and images.

<!-- image -->

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology

<!-- image -->

In this image we can see a sticker.

<!-- image -->

Based on the National Curriculum Framework 2016

## MAHATMA GANDHI INSTITUTE

<!-- image -->

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology. Republic of Mauritius 202 1

<!-- image -->

## © Mahatma Gandhi Institute (2019)

All  rights  reserved.  No  part  of  this  publication  may  be  reproduced,  stored  in  a retrieval  system,  or  transmitted  in  any  form  or  by  any  means,  electronic, mechanical, photocopying, recording or otherwise, without the prior permission of the Copyright owner.

## Printed by:

T-Printers Co. LTD Industrial Zone, Coromandel. Tel: (230) 233 2500

First published 2020 Reprinted 2021

While every effort has been made to trace the copyright holders for reproductions, we might have not succeeded in some cases. We offer our sincere apologies and hope that they will take our liberty in good faith. We would appreciate any information that would enable us to acknowledge the copyright holders in our future editions. All materials should be used strictly for educational purposes.

ISBN: 978-99949-54-31-5

## Performing Arts (Indian Music and Dance) Panel

Mr. K. Mantadin

- Project Coordinator

- (organisation and development), Senior Lecturer (Tabla), Head, Department of Curriculum Development, MGI

Ms. S. Dabee

- Panel Coordinator

Senior Lecturer (Bharata Natyam), Head, Department of Decentralisation of Music and Dance, Distance Education and E-Learning, MGI

## Writing Team

## Bharata Natyam

Mrs. P. D. Luchman

- Team Leader , Educator (Bharata Natyam) - MGI

Mrs. A. D. Dwarka-Bania

-   Educator (Bharata Natyam) - M.O.E, T.E, Sc. &amp; Tech.

## Contributors

Dr. D. Pentiah-Appadoo

-   Music Organiser (Oriental) - M.O.E, T.E, Sc. &amp; Tech.

Mrs. K. Mahadoo Coonlic

-   Educator (Bharata Natyam) - M.O.E, T.E, Sc. &amp; Tech.

Ms. S. Jootun

-   Educator (Kathak) - M.O.E, T.E, Sc. &amp; Tech.

Mrs. R. Khadoo

-   Educator (Kathak) - M.O.E, T.E, Sc. &amp; Tech.

## Vetter

Mrs. S. Mungur

-   Former Assoc. Professor (Dance) - MGI

## Proof Reading

Mrs. D. Balaghee

-   Deputy Rector - MGISS

## Graphic Designers - MGI

(cover, illustration, layout and photography)

Ms. P . Juckhory

Ms. V. Jatooa

Mr. V. Napaul

## Photography

Mr. G. Moonesawmy

-   Pro Foto Plus

## Word Processing Operator

Mrs. N. Mugon

## Acknowledgements

Mrs.  S.  N.  Gayan,  GOSK,  Director  General,  Mahatma  Gandhi  Institute  and Rabindranath  Tagore  Institute for  her  continued  advocacy  for  music  education especially Indian Music and Dance.

Dr.  (Mrs.)  V.  Koonjal,  Director,  Mahatma  Gandhi  Institute for  her  unwavering support to this project.

## The Performing Arts (Indian Music and Dance) panel is also grateful to the following persons:

Dr. Mrs. S. D. Ramful Mrs. U. Kowlesser Dr. D. Ramkalawon

-   Director Schooling - MGI

-   Registrar - MGI

-   Senior Lecturer (Sitar),

Head, School of Performing Arts, MGI

Dr. D. Pentiah-Appadoo

-   Music Organiser (Oriental),

M.O.E, T.E, Sc. &amp; Tech.

## Quality Vetting Team

Dr. J. Chemen

-   Assoc. Professor, Head, Centre for Quality Assurance - MGI

Dr. (Ms.) S. D. Ramdoo Mrs. S. Gopee Ms. N. Lallmamode

-   Lecturer (Bharata Natyam) - MGI

-   Educator (Bharata Natyam) - M.O.E, T.E, Sc. &amp; Tech.

-   Lecturer, Head, Department of Design and

Communication - MGI

Mrs. D. Ramcharan-Maloo

-   Educator (English) - MGSS

## Administrative Staff

Mrs. H. Chudoory

-   Administrative Officer - MGI

Ms. V. Cahoolessur

-   Office Supervisor - MGI

Mrs. G. Checkooree

-   Clerical / Higher Clerical Officer - MGI

Mrs. S. Appadoo

-   Clerical / Higher Clerical Officer - MGI

Mrs. P. Purmessur

-   Word Processing Operator- MGI

## Photo Courtesy

Ms. Yoshita Gangabissoon Ms. Prajakta Auree

Ms. Manasvi Runglall Ms. Yuveena Kavya Hazareesing

The  parents  and  their  wards  for  giving  us  the  permission  to  reproduce  their photographs and images in the textbook.

## Foreword

'Where the mind is allowed to stumble upon cascades of emotion and where the surprise of creative exchange comes out of tireless striving towards perfection'

Rabindranath Tagore

Should music, dance, arts, drama be taught in schools? Do such subjects matter?

As in the case of all debate, there are those who are for and those who are against. The decision, in the context of the reforms leading to the Nine Year Continuous Basic Education, to include teaching of the performing arts in the secondary school curriculum shows that 'the ayes have it.' At least for the time being.

Traditionally, music teaching takes place in a one-to-one mode. The piano teacher teaches one student at a time, so does the sitar guru. Dance is more of a group experience. But for each of these disciplines, the context of institutional level teaching introduces opportunities of reaching  a  broader  cross-section  of  population,  thereby  giving  rise  to  fresh  challenges. Students come from a variety of social and cultural environments which expose them to different types, genres and registers in the arts. Students also come with different levels of aptitude. These are but two of challenges encountered.

From another perspective, it has been repeatedly pointed out that the 'digital natives', while definitely coming to learning with resources hitherto not available, may, in the process, be losing their ability to grasp, decipher and understand emotional language. In short they may be losing empathy.

The ultimate aim of arts education in the curriculum is to provide a pedagogical space where the  young  will  be  able  to  explore  their  own  affective  responses  to  forms  of  artistic expression, to develop sensibility, while acquiring a whole set of skills, including not only spatial awareness, pattern recognition or movement coordination, but also the benefits of group and team work, of joint effort, higher level creative thinking and expression, as well as an overall sense of shared pleasure and of achievement. This is what emotional intelligence is all about.

The specialists who prepared the syllabus and the present textbooks for Indian music and dance had all the above in mind while undertaking the task. The teacher training for these disciplines needs to be a continuous process of exchange between curriculum developers, teaching practitioners, textbook-writers and learners.

The MGI is particularly happy to be part of this major development, at a time when the country  is  looking  at  new  avenues  for  continued  economic  development,  and  more importantly at new avenues to enhance equity, social justice and inclusion. It is our small contribution to the 'grande aventure' of holistic education.

Mrs Sooryakanti Nirsimloo-Gayan, GOSK Director-General (MGI &amp; RTI)

## Preface

This textbook is the first instructional material in the field of Performing Arts (Indian Music and  Dance)  written  by  a  team  of  experienced  Mauritian  teachers  and  experts  in  Vocal Music, Instrumental Music and Dance.

It has been designed on the Aims, Objectives and the Teaching and Learning Syllabus of the Performing Arts from the National Curriculum Framework (2016), under the Nine Year Continuous Basic Education Programme.

The Performing  Arts Curriculum is articulated around four strands: Performing, Creating,  Responding  and  Performing Arts  and  Society.  Thus,  the  textbook  takes  into account the development of key skills and understandings under the four strands.

This set of textbooks for grade 7, 8 and grade 9 lays the foundation in each discipline and provides learners  with  the  essential  knowledge,  skills  and  attitudes  needed  to  progress towards higher grades. It also takes into consideration the multicultural nature of our society and its traditions.

This textbook is a support material that gives direction to the educators in the teaching and learning process by linking the curricular components, curricular expectations, pedagogical principles and assessments.

A textbook is not an end in itself like any other instructional material.It is a means to facilitate learning to take place in a continuous and continual manner.

Learning objectives in each chapter of the textbook reflect the curricular outcomes.  It will help the teacher to design his/her lesson plans which will further ease the teaching and learning transaction towards achievement.  Teachers will have to plan their work so that learning takes place in an effective and efficient way.  They will have to provide appropriate and enriched experiences and modify the teaching and learning strategies according to the needs of learners.

The  practical  aspects  of  the  discipline  have  been  integrated  under  'practical'  with step-by-step technique laying emphasis on the mastery of skills from one level to another.

We  are  aware  that  children  construct  knowledge  in  their  own  way  and  have  different learning styles.The textbook has been designed to cater for such needs.

Special  features  and  a  generous  number  of  illustrations,  pictures,  concept  maps  and activities have been included to promote collaborative learning and other additional skills like  team spirit,  cooperation and understanding diverse nature of learners. These would help  teachers  to  organise  their  interactions  at  classroom  level.  Teachers  may  give  more activities, depending upon the availability of resources and time.

## Preface

Assessments in the form of activities, projects and questions are also included at the end of each chapter.  These are check points to assess the learners.  It will help teachers gather evidences about the expected level of learning taking place in the learners.

I  would  also  request  all  the  Educators  to  go  through  the  National  Curriculum  Framework (2016), the Teaching and Learning Syllabus of the Performing Arts (Indian Music and Dance) documents and especially the 'Important Note to Educators' which has been provided in the textbook to have a thorough understanding of the Philosophy and Perspective behind those documents  and  their  implications  in  the  implementation  of  the  Reform  process  in  the education system.

I hope that this new journey of learning Indian Music and Dance will be an enriching one.

Mr. K. Mantadin, Project Co-ordinator - Performing Arts (Indian Music and Dance), Senior Lecturer (Tabla), Head, Department of Curriculum Development, Mahatma Gandhi Institute.

## Important Note To Educators

This teaching and learning syllabus of Indian Music and Dance has been designed on the spiral curriculum model in which core components and essential topics are revisited within the three years.  It caters for both the theoretical and practical aspects of each discipline.

It also comprises different blocks of knowledge and skills and each block is supported by specific  learning  outcomes  which  cover  all  the  three  domains  of  learning;  cognitive, psychomotor and affective.

The Listening and Viewing component has been integrated in the syllabus as it is a key factor  in  the  development  of  music  and  dance  abilities. Teachers  should  provide  a  wide variety of listening and viewing experiences for learners to stimulate active listening and viewing through questioning, prompting and suggestion.

In order to achieve the objectives of the syllabus and to keep a good balance between theory and practical sessions, the teacher will have to plan his / her work and teaching and learning activities according to the topics to be taught as specified in the scheme of studies. However, educators may modify the sequence of the topics in which they wish to teach for the smooth running of the course.

## Educators should:

1. Ensure that learners use the knowledge, skills and understanding developed from grades 1-6 and build upon that prior knowledge to construct new knowledge.
2. Provide learning experiences that include opportunities for hands-on and interactive learning, self-expression and reflection.
3. Find a variety of ways to align their instruction with the Aims, Learning Outcomes and Specific Learning Outcomes by focusing on active learning and critical thinking.
4. Provide learning activities that are appropriate in complexity and pacing.
5. Provide opportunities for individual and multiple groupings.
6. Actively engage and motivate students in the process of Learning Music and Dance.
7. Develop the ability in the learners to use and understand the language of Music and Dance through listening and viewing as well as responding to live and recorded repertoires.
8. Enrich the musical experience of the students by gaining an understanding of the cultural and historical context of music and dance exploring personal connections with them.

## Important Note To Educators

9.   Carry out active listening and viewing sessions through the use of Information Learning T echnologies (ILT's). This will facilitate developing their investigative and methodological abilities.
10. Model and demonstrate accurate and artistic musical and dance techniques.
11. Differentiate Music and Dance instruction to meet a wide range of students needs.
12. Educators should also ensure that learners:
-  Show proper care and maintenance of classroom instruments
-  Demonstrate respectful behavior as performers and listeners
-  Participate in classroom protocole and traditions for music making and dance
13. Reinforce effort and provide recognition.
14. Discuss student performances by using peer assessment as a tool.
15. Give opportunities to students to assume various roles in music performances, presentations and collaborations.
16. Motivate students to maintain a musical collection and portfolio of their own work over a period of time. It can be an individual or group initiative that the learner will undertake under the supervision of the educator.

## Table of Contents

| Invocation                           |   1 |
|--------------------------------------|-----|
| Body Conditioning For Dance          |   7 |
| Indian Classical Dances In Mauritius |  23 |
| Bharata Natyam Gestures              |  29 |
| Adavus                               |  41 |
| Components of Indian Classical Dance |  79 |
| Dance Stories Of Indian Gods         |  87 |
| Evolution Of Bharata Natyam          | 105 |
| Aharya Abhinaya For Bharata Natyam   | 115 |

## Table of Contents

| Musical Instruments For Bharata Natyam   |   131 |
|------------------------------------------|-------|
| Exponents Of Bharata Natyam              |   145 |
| Notation Form                            |   153 |
| Creative Exercise                        |   163 |
| Practice For Bharata Natyam              |   169 |
| Glossary Of Terms                        |   171 |

In this image we can see the globe. On the globe there are people. In the background there is text.

<!-- image -->

In this image we can see a flower petals. In the background there is a text.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

-  Memorise the Sanskrit Shlokas on Lord Vishnu and Goddess Lakshmi .
-  Translate the Sanskrit Shlokas in English.
-  Recite the Sanskrit Shlokas.
-  Translate verbally the Sanskrit Shlokas in English.
-  Develop a sense of discipline.

<!-- image -->

## INVOCATION

## LORD VISHNU

<!-- image -->

Lord Vishnu is one among  the Hindu  Trinity. He  is considered as the preserver of the universe. It is believed that Lord Vishnu incarnates in various forms in order to re-establish religion, to protect the good people and to destroy evil.

In this image we can see a painting of a person sitting on the lotus flower. There are two persons sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a person sitting on the lotus flower. There is a

<!-- image -->

## Sanskrit Shloka on Lord Vishnu

Shanta karam bhujaga shayanam Padma nabham suresham Vishva dharam gagana sadrisham Megha varnam shubhangam Lakshmi kantam kamala nayanam Yogi bhirdhyanagamyam Vande Vishnu bhava bhaya haram Sarva lokaika natham

<!-- image -->

## Context translation

Lord Vishnu who has a peaceful form or nature,

He rests on the bed of serpents

From His navel springs out a lotus and He is the lord of lords,

He is the upholder of the Universe, infinite and all pervasive as the sky,

His complexion is like the dark clouds and his limbs are pure and auspicious,

He is the consort of Lakshmi and His eyes are like the lotus,

He always resides in minds of the yogis in their meditation,

I bow to Lord Vishnu, who removes all the feelings of fears in the world,

He is the Lord of the whole Universe.

## DID YOU KNOW?

Lord Vishnu has 10 incarnations known as the Dasavataras.

Koorma

Varaha

Narasimha

Balarama

Krishna

<!-- image -->

Parasurama

Matsya

Rama

<!-- image -->

Vamana

Kalki

<!-- image -->

<!-- image -->

## GODDESS LAKSHMI

<!-- image -->

Goddess Lakshmi is  the  consort  of  Lord Vishnu .  She  is  considered  as  the Goddess of wealth.

In this image we can see a person holding a flower and a stick.

<!-- image -->

In this image we can see a poster.

<!-- image -->

## Context translation

Salutations to the supreme illusionary power, Mahalakshmi, The one who is auspicious and a source of prosperity and who is worshipped by the Gods,

The one who holds the conch-shell, the disc and the club, I bow down to the great Goddess of wealth (Lakshmi).

<!-- image -->

## KEYWORDS

Invocation, Trinity.

## Links

<!-- image -->

https://www.youtube.com/watch?v=SkBcaBz9rxY https://www.youtube.com/watch?v=yByIevIUNN8

## POINTS TO REMEMBER

- Lord Vishnu is one among the Hindu Trinity.
- Lord Vishnu is considered as the preserver of the universe.
- The consort of Lord Vishnu is Goddess Lakshmi .
- Goddess Lakshmi is considered as the Goddess of wealth.

<!-- image -->

<!-- image -->

<!-- image -->

## ASSESSMENT

## 1. Fill in the blanks in the Shlokas  given below:

## Vishnu

Shanta karam …………………….. shayanam

Padma nabham ……………………..

…………………. dharam gagana sadrisham

Megha varnam ……………………………

………………………kantam kamala nayanam

………………………….bhirdhyanagamyam

Vande Vishnu bhava ……………………haram

Sarva lokaika …………………………….

## Lakshmi

Namastestu …………………

Sri peethe ……………… poojite

Shankha ……………….. gada haste

………………………….namostute

## 2. Rearrange in sequence the Shlokas on Lord Vishnu.

Megha varnam shubhangam Yogi bhirdhyanagamyam Vishva dharam gagana sadrisham Shanta karam bhujaga shayanam Vande Vishnu bhava bhaya haram Lakshmi kantam kamala nayanam Sarva lokaika natham Padma nabham suresham

<!-- image -->

In this image we can see a woman standing and doing a dance.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Demonstrate an understanding of warm-up, pre-dance and cool-down exercises for safe and effective dance practice.
-  State the benefits of warm-up, pre-dance and cool-down exercises.
-  Condition the body through warm-up, pre-dance and cool-down exercises for safe and effective practice.
-  Execute the warm-up, pre-dance and cool-down exercises with accuracy.
-  Practise the exercises to develop flexibility, agility and endurance.
-  Adhere to warm-up, pre-dance and cool-down exercises for safe and effective practise.

<!-- image -->

## Dress Code For Bharata Natyam Class

<!-- image -->

In this image we can see a woman standing and smiling. She is wearing a pink color dress and a blue color jacket. She is wearing earrings.

<!-- image -->

In this image we can see a poster with some text and a picture of a man.

<!-- image -->

## BODY CONDITIONING FOR DANCE

Body conditioning consists of warm-up, pre-dance and cool-down exercises. Body conditioning exercises are important for safe and effective practice of dance.

<!-- image -->

<!-- image -->

## WARM-UP EXERCISES

<!-- image -->

It  is  important  for  dancers  to  warm-up  before  any  dance  activity  in  order  to prepare the body for longer training. Warm-up exercises also help to decrease stiffness and tension in the muscles and joints. A safe warm-up gradually  increases  the  body  temperature  to  an  optimal  working  level  and helps to avoid injuries.

## An effective warm-up of the body should:

- Prepare dancers both mentally and physically.
- Improve performance and reduce prevalence of injuries.
- Increase coordination and awareness of the position and movements of the body.
- Increase heart rate and blood circulation gradually.
- Increase body temperature.
- Permit more free movement of the joints.
- Improve the muscle actions.
- Reduce the risk of injury.
- Improve the transmission of nerve impulses.
- Mobilise all the joints that are exerted during the dance class.

One should never feel tired after the warm-up. Warm-up should always consist of simple and low impact movements. The movements should be controlled and continuous with the correct alignment to reduce the risk of injury.

A warm-up should include exercises for ankles, knees, hips, spine, shoulders, elbows and wrists. By the end of the warm-up exercises one should feel warm, relaxed and ready to start dancing.

<!-- image -->

<!-- image -->

## LEG EXERCISES

<!-- image -->

## 1 st  Exercise

In this image we can see a woman standing and doing some exercise.

<!-- image -->

## 2 nd  Exercise

In this image we can see a woman standing and doing a pose.

<!-- image -->

In this image we can see a woman standing and wearing a dress.

<!-- image -->

<!-- image -->

In this image we can see a woman standing and posing for the photo.

<!-- image -->

## Lateral Leg Swings

## 1 st  Exercise

- Stand straight and hold onto a wall.
- Shift the weight to the right leg and swing the left leg to the side and back 5 times. Repeat the same movements on the opposite side.

## 2nd Exercise

- Shift the weight to the right leg and swing the left leg to the left and then across the body to the right 5 times. Repeat the same movements on the opposite side.

<!-- image -->

In this image we can see two women standing and doing a pose.

<!-- image -->

## Squat side kick

- Start in a squat position with the hips back and the feet apart.
- Stand up, switch the weight to the left leg and lift the right leg out to the side.
- Return to the squat position and repeat the same movements on the left side. Repeat the movements 5 times on each side.

<!-- image -->

<!-- image -->

<!-- image -->

## ABDOMINAL EXERCISES

In this image we can see a woman standing on the floor. She is wearing a blue and pink color dress.

<!-- image -->

<!-- image -->

## Basketball shots

- Stand with the feet apart and the toes pointing slightly outward.
- Bend the knees, hold the hips back and place both hands down on the right side as if lifting a ball.
- Jump up and extend the arms above the head and to the left as if throwing a ball.
- Land with the knees slightly bent and go back into the squat position.
- Repeat on each side.

## CALVES EXERCISES

<!-- image -->

- Jump with both feet to the right and then to the left in a quick repetitive movement.
- Repeat 5 to 10 times.

In this image we can see a woman standing and she is wearing a pink and blue color dress.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## INNER THIGHS EXERCISES

In this image we can see a woman standing and she is wearing a blue and pink color dress.

<!-- image -->

## Plie squat calf raise

- Start in a sumo squat position with the feet in a wide stance, the toes pointing out to the sides and the thighs parallel to the floor.
- Raise the heels off the floor and squeeze the calves.
- Lower the heels and return to the starting position.
- Repeat the movements 5 to 10  times.

## BACK EXERCISES

<!-- image -->

In this image we can see a woman is lying on the floor. She is wearing a blue color dress and pink color pant.

<!-- image -->

## Superman twist

- Lie on the stomach with the legs fully extended, and hands behind the ears.
- Lift and twist the upper torso to the side and pause for 2 seconds.
- Return to the starting position and repeat while twisting the torso to the opposite side. Repeat the movements 5 times on each side.

<!-- image -->

<!-- image -->

## PRE-DANCE EXERCISES

<!-- image -->

After the body is warmed, dancers can execute certain movements within their routine during the dance class.

Pre-dance exercises are intended to warm-up the core muscles that are to be used during the dance class. They also help the dancer's body to become more flexible and hence, increase the range of movements. It is important to note that once the body is warmed, it should remain as such until the dance class starts.

## TRIANGULAR POSES

<!-- image -->

In this image we can see a woman standing and doing a yoga pose.

<!-- image -->

- Stand with the feet apart and arms stretched on the sides.
- Bend on the right side with the right hand touching the right ankle, while the left hand is stretched upwards.
- Repeat the movement on the opposite side.
- Keep each posture for 30 seconds.

<!-- image -->

## HAMSTRING STRETCH

<!-- image -->

## 1 st  Exercise

In this image we can see a woman standing and wearing a blue and pink color dress.

<!-- image -->

- Start in the Araimandi posture.
- Bend the right knee and stretch the left leg at the back on the toe.
- Press the right knee with both hands and hold the posture for 30 seconds.
- Repeat the same movements on the opposite side.

## 2 nd  Exercise

In this image we can see a woman standing and doing a yoga pose.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- Start in the Araimandi posture.
- Stamp the right foot and sit in the Muzhumandi with the right leg while stretching the left leg with the foot placed on the heel.
- For the left side, raise the body in half sitting posture ( Araimandi ) and shift the body weight on the left leg.
- Sit in Muzhumandi while stretching the right leg with the foot placed on the heel.
- Hold the movement for 30 seconds.
- Repeat the same movement on the opposite side.

## KNEES WARM-UP

<!-- image -->

## 1 st  Exercise

In this image we can see a woman standing and she is wearing a blue and pink color dress.

<!-- image -->

- Hold the knees with both hands. Bend the knees and rotate them clockwise and anti-clockwise at least five to ten times each.

<!-- image -->

<!-- image -->

## 2 nd  Exercise

In this image we can see a woman standing and wearing a blue and pink color dress.

<!-- image -->

- Bend the knees and then straighten them 5 to 10 times.
- Start in the Araimandi posture.
- Lift the right foot and press on toes.
- Keep the movement for 30 seconds.
- Repeat the movements 5 to 10 times on each side.

<!-- image -->

In this image we can see a woman standing and she is wearing a blue color saree and she is wearing a belt.

<!-- image -->

<!-- image -->

<!-- image -->

## COOL-DOWN EXERCISES

<!-- image -->

Cool-down  exercises  can  last  for  two  to  three  minutes  depending  on  the intensity of the activity performed.

An  intense  activity  should  not  be  stopped  suddenly  because  blood  will accumulate within the muscles instead of returning to the brain and this can cause dizziness. By gradually slowing the body movements, the breathing rate will decrease and reverse the warm-up process. Hence, cool-down exercises will help the body to gradually return to normal.

Cool-down exercises are also important after dancing as this can help reduce muscle  soreness  and  speed  up  the  recovery  process  after  intense  activity. Extra soreness may occur due to the intensity of the exercise or unfamiliar movements performed. To relieve soreness on the following day, performing some light gentle exercise and stretching may help to ease out the pain.

## CHEST STRETCH

<!-- image -->

In this image we can see a girl standing and wearing a blue jacket and pink pant.

<!-- image -->

In this image we can see a woman standing. She is wearing a blue color dress.

<!-- image -->

- Stand with the side of the body facing a wall, place the left palm on the wall.
- Slowly rotate the torso to the right until a stretch is felt in the chest and on the
- left shoulder. Hold for 15 to 20 seconds and repeat on the right side.
- Lie flat on the back and bend both knees.
- Cross the right leg over the left and bring both knees towards the chest.
- Gently pull the left leg towards the head until a stretch is felt in the glute.
- Hold the stretch for 30 seconds and repeat with the other leg.
- Sit on the floor with crossed legs by placing each foot under the opposite knee and keep the spine straight.
- Stay in this relaxing posture and concentrate on the breathing movements.

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a woman wearing a pink dress and blue pant is doing yoga.

<!-- image -->

<!-- image -->

In this image we can see a woman sitting on the chair and she is wearing a pink and blue color dress and she is holding a pearl bracelet.

<!-- image -->

<!-- image -->

<!-- image -->

## KEYWORDS

Warm-up exercise, pre-dance, cool-down exercises, safe practice.

## Links

<!-- image -->

https://www.youtube.com/watch?v=jmdusPNrjgQ&amp;t=1350s

## POINTS TO REMEMBER

- Warming up before any dance activity is important in order to prepare the body for longer and safer training.
- A warm-up gradually increases the body temperature to an optimal working level and helps to avoid injuries.
- Pre-dance exercises are intended to warm-up the core muscles that are to be used during the dance class.
- Cool-down exercises are important after dancing as they help to reduce muscle soreness.
- Cool-down exercises speed up the recovery process after intense activities.

<!-- image -->

## ASSESSMENT

1. State 3 benefits of warm-up exercises.

2. State 1 benefit of pre-dance exercises.

3. Explain the importance of cool-down exercises.

<!-- image -->

<!-- image -->

<!-- image -->

In this image I can see a paper with some text on it.

<!-- image -->

<!-- image -->

In this image we can see a painting of a woman.

<!-- image -->

Indian Classical Music And Dance In Mauritius Chapter 3

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

-  Identify the Indian classical dances practised in Mauritius.
-  Describe how the Indian classical dances were introduced in Mauritius.
-  Describe the propagation of Indian classical dances in Mauritius.
-  Develop gratitude and respect towards the pioneers of Indian classical music and dance in Mauritius.

<!-- image -->

## INDIAN CLASSICAL DANCES IN MAURITIUS

In Mauritius, only three Indian classical dance forms are practised. The three classical dance forms are Bharata Natyam , Kathak and Kuchipudi .

In this image we can see a group of people. There are three people in the image. The person in the middle is wearing a purple color dress. The person in the middle is wearing a pink color dress. The person in the middle is wearing a green color dress. The person in the middle is wearing a yellow color dress. The person in the middle is wearing a red color dress. The person in the middle is wearing a white color dress. The person in the middle is wearing a green color dress. The person in the middle is wearing a yellow color dress. The person in the middle is wearing a red color dress. The person in the middle is wearing a white color dress. The person in the middle is wearing a green color dress. The person in the middle is wearing a yellow color dress. The person in the middle is wearing a red color dress. The person in the middle is wearing a white color dress. The person in the middle is wearing a green color dress. The

<!-- image -->

Ancestors who came from India had their roots from the South, South-East, South-West and the Northern regions of India. As Bharata Natyam originated from  Tamil  Nadu, Kuchipudi from  Andhra  Pradesh  and Kathak from  the Northern regions, these classical dance forms had an influence on the people of Mauritius and got established in the island.

In this image I can see the map of India.

<!-- image -->

<!-- image -->

RECAP

The 7 main Indian classical dance forms are:

Bharata Natyam, Kathak, Kathakali, Manipuri, Kuchipudi, Odissi, and Mohini Attam

<!-- image -->

## How the Indian classical music and dance were introduced in Mauritius?

<!-- image -->

India became Independent in 1947, and the diplomatic relations were established between India and Mauritius. The Indian Embassy was set up in Mauritius in 1948. Since then, various Indian classical music and dance experts visited Mauritius for performances, concerts and awareness programmes.

## DID YOU KNOW?

In  1962, Pandit Ram  Gopal  and  his troupe  left  a  remarkable  impact  on  the people of Mauritius.  They presented dance performances in Bharata Natyam , Kathakali and Kathak which  led  to  an increase of interest for learning the classical dance forms in the country.

Before the setting up of the Indian Embassy in Mauritius, Indian indentured labourers were only adept in folk music and dance.

As there was a significant growth in the interest of Mauritians about Indian music and dance, Sir Veerasamy Ringadoo, the then Minister of Education set up the School of Indian Music and Dance at Beau-Bassin in 1964. The School was established with the collaboration of the Indian High Commission and the British government as Mauritius was still a British colony. It was inaugurated by Lady Rennie, wife of the then Governor, Sir John Shaw Rennie, on 11 th  April 1964.

The Indian Government sent Mr. and Mrs. Nandkishore to Mauritius to teach Indian  music  and  dance.  They  were  experts  in  Indian  classical  music and  dance  and  taught  the  following  disciplines:  Vocal Hindustani music, Sitar, Harmonium, Tabla, Bharata Natyam, Kathak, Kathakali, and folk dances.

There  was  such  a  growing  demand  amongst  the  Mauritian  people  to  learn Indian  classical  music  and  dance,  that  a  larger  complex  was  required  to accomodate  the  students.  Thus,  the  School  of  Indian  Music  and  Dance integrated the Mahatma Gandhi Institute with the mission to promote education and Indian culture including Indian music and dance. As a matter of fact, the foundation stone of the Mahatma Gandhi Institute at Moka was laid on the 3rd June 1970 and the Mahatma Gandhi Institute was inaugurated in 1975 by late Shrimati Indira Gandhi, the then Prime Minister of India.

<!-- image -->

<!-- image -->

## Pioneers of Indian classical Music and Dance in Mauritius

<!-- image -->

The  High  Commission  of  India  annually  granted  scholarships  to  Mauritian students to study Indian classical music and dance in India. In 1950, the first Mauritian,  Mr  Ishwarduth  Nundlall  was  offered  a  scholarship  by  the  Indian Government to study Indian classical music in India. Dr Ishwarduth Nundlall came back to Mauritius in 1958 with degrees in Vocal Hindustani , Sitar and Violin from the National Academy of Music, Lucknow.

Dr. I. Nundlall started performing all over the island arousing interest in many Mauritians to learn the art of music. He is considered to be the first Mauritian to teach, train and propagate Indian classical music in Mauritius.

In this image we can see a man. In the background there is a wall.

<!-- image -->

In this image we can see a poster with some text.

<!-- image -->

Furthermore, Indians and Mauritians who got training in eminent Institutions from  India  contributed  enormously  in  the  propagation  of  Indian  classical dances in Mauritius.

Some of  them  are:  Mrs.  Padma  Naidu-Ghurbhurun,  Mrs.  Sandhya  Mungur and  Mrs.  Rekha  Deerpaul  in Bharata  Natyam ;  Mr  Ramesh  Nundoo  and Mrs Nirmala Gobin in Kathak ;  Mrs  Damayantee Algoo in Manipuri and  Mrs Premila Balakrishna Uppamah in Kuchipudi .

Many Mauritians who were initiated in these classical art forms by the above named mentors,  went to India to pursue further studies in the field of Tabla, Kathak,  Violin, Vocal Hindustani ,  Vocal Carnatic,  Sitar,  Bharata  Natyam, Mridangam, Kuchipudi, Mohini Attam and Veena .

Since 1964 onwards, there has been a continuous effort of the Mahatma Gandhi Institute staff to propagate  Indian classical  music  and  dance.  Regional Centres  were  set  up  in  1982  throughout  the  island  by  the  Mahatma  Gandhi Institute so that these art forms could reach out the population at large.

<!-- image -->

<!-- image -->

The Ministry of Education, Ministry of Arts and Culture, Indira Gandhi Centre for  Indian  Culture,  Indian  socio-cultural  associations,  and  private  dance schools have  all played important roles in preserving,  promoting  and propagating the Indian classical music and dance in Mauritius.

Indian classical dance has been part of the secondary schools curriculum for more than 40 years. Today, Indian classical music and dance have attained such  a  standard  that  they  are  being  taught  up  to  tertiary  level  at  the Mahatma Gandhi Institute in collaboration with the University of Mauritius.

The Mahatma Gandhi Institute through its various initiatives, in the domains of music and dance education, performance and production, have contributed immensely to enrich the cultural landscape of the nation.

## KEYWORDS

Originate, practised, classical, pioneers, embassy, culture

## POINTS TO REMEMBER

- Only Bharata Natyam, Kathak and Kuchipudi are practised in Mauritius.
- Due to the fact that Bharata Natyam originates from Tamil Nadu, Kuchipudi from Andhra Pradesh and Kathak from the regions of Lucknow and Jaipur, these classical dance forms have established themselves in Mauritius.
- It is only after the setting up of the Indian Embassy in Mauritius in 1948 that Indian classical dances were introduced in Mauritius.
- The School of Music and Dance was inaugurated in 1964.
- Ishwarduth Nundlall is known as the first pioneer of Indian classical music in Mauritius.
- The three Indian classical dance forms; Bharata Natyam, Kathak and Kuchipudi are part of the cultural panorama of Mauritius

<!-- image -->

<!-- image -->

## ASSESSMENT

1. State whether the following statements are TRUE or FALSE.
2. Name the three Indian classical dance forms commonly practised in Mauritius.
3. Write a summary on how Indian classical dances were introduced in Mauritius.

| Statements                                                                                                          | True/ False   |
|---------------------------------------------------------------------------------------------------------------------|---------------|
| 1) Bharata Natyam, Kathakali and Odissi are the three Indian classical dance forms commonly practised in Mauritius. |               |
| 2) Dr. Ishwarduth Nundlall is known as the first pioneer of Indian classical music in Mauritius.                    |               |
| 3) Indian classical dances were introduced in Mauritius before the Independence of India.                           |               |
| 4) The School of Music and Dance was inaugurated in 1964.                                                           |               |
| 5) Bharata Natyam, Kathak and Kuchipudi are part of all major socio-cultural occasions in Mauritius.                |               |

<!-- image -->

In this image we can see a woman wearing jewelry and a red color nose ring.

<!-- image -->

## LEARNING OBJECTIVES LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Recall the Asamyuta Hastas , Samyuta Hastas and Basic dance postures.
-  Memorise the names and Shlokas of the Shiro Bhedas , Drishti Bhedas and the Greeva Bhedas .
-  List the names of the nine Shiro Bhedas , eight Drishti Bhedas and the four Greeva Bhedas .
-  Identify the nine Shiro Bhedas , eight Drishti Bhedas and the four Greeva Bhedas .

<!-- image -->

## GESTURES

Dance is considered as non-verbal communication through which an emotion, an  idea  or  a  story  can  be  conveyed.  In  order  to  communicate  through  the medium of dance, the whole body is used along with the face.

In  Indian  classical  dances  there  are  specific  codes  of  gestures  that  are used for expressions.

Bharata Natyam refers to the Abhinaya Darpanam, a Sanskrit text on dance, for  its  gestures. According  to  the Abhinaya  Darpanam,  nine  Shiro  Bhedas, eight Drishti Bhedas and four Greeva Bhedas are mentioned.

<!-- image -->

## SHIRO BHEDAS

Shiro Bhedas are the head movements. The Shiro Bhedas refer to the head positions while executing dance movements.  According to Abhinaya Darpanam , there are nine types of head movements.

In this image there is a board with some text on it.

<!-- image -->

## The meaning of the last line of the Shlokas is as follows:

Thus the head movements are said to be of nine types by the scholars of Natya Shastra.

## Names of the Shiro Bhedas

Sama, Udhvahita, Adhomukha, Alolita, Dhuta Kampita, Paravritta, Utkshipta, Parivahita

<!-- image -->

<!-- image -->

<!-- image -->

## NAMES AND PICTURES OF THE SHIRO BHEDAS

In this image I can see a woman and I can see she is wearing a blue color saree and I can see she is wearing a yellow color saree. I can see she is wearing a necklace and I can see she is wearing a headband. I can see she is wearing a red color saree. I can see she is wearing a red color headband. I can see she is wearing a red color saree. I can see she is wearing a red color headband. I can see she is wearing a red color saree. I can see she is wearing a red color headband. I can see she is wearing a red color saree. I can see she is wearing a red color saree. I can see she is wearing a red color headband. I can see she is wearing a red color saree. I can see she is wearing a red color saree. I can see she is wearing a

<!-- image -->

Dhuta (head moving from right to left)

<!-- image -->

<!-- image -->

In this image we can see a woman wearing a necklace and earrings. We can also see a nose ring and a nose. We can also see a white color background.

<!-- image -->

6

<!-- image -->

Kampita (nodding - head moving up and down)

<!-- image -->

7

Paravritta (head turned on the side and bent down)

Utkshipta (Head turned on the side and raised up)

8

In this image we can see a woman wearing a saree and a necklace.

<!-- image -->

9

Parivahita (Head moving side to side)

<!-- image -->

<!-- image -->

<!-- image -->

Drishti Bhedas are the eye movements. They are the different eye movements used in Indian classical dances. According to the Abhinaya Darpanam there are eight types of eye movements.

In this image I can see a banner.

<!-- image -->

## The meaning of the last line of the shlokas is:

These are the eight types of eye movements according to ancient scholars.

## Names of the eight Drishti Bhedas

1. Sama
2. Alokita
5. Nimilite
6. Ullokita
3. Sachi
7. Anuvritta
4. Pralokita
8. Avalokita

<!-- image -->

<!-- image -->

<!-- image -->

## NAMES AND PICTURES OF THE DRISHTI BHEDAS

<!-- image -->

<!-- image -->

Sama (Straight)

<!-- image -->

In this image we can see a collage of different images.

<!-- image -->

Sachi (Looking from the corner of the eyes) 3

<!-- image -->

<!-- image -->

Pralokita (Looking from side to side)

<!-- image -->

<!-- image -->

Alokita (The eyes move in a circular movement)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Nimilite

(Tip of the nose)

<!-- image -->

<!-- image -->

Avalokita

(Looking down)

Ullokita (Looking up)

<!-- image -->

Anuvritta (Looking up and down)

<!-- image -->

<!-- image -->

## GREEVA BHEDAS

<!-- image -->

Greeva Bhedas are known as the neck movements. There are four types of Greeva Bhedas according to Abhinaya Darpanam .

In this image we can see a board with some text on it.

<!-- image -->

## The meaning of the last line is:

Scholars on bhavas know that Greeva Bhedas is of four types.

## Names of the Greeva Bhedas

1. Sundari
2. Tiraschina
3. Parivartita
4. Prakampita

## NAMES AND PICTURES OF THE GREEVA BHEDAS

In this image we can see a woman wearing a necklace and earrings.

<!-- image -->

1

Sundari

<!-- image -->

<!-- image -->

In this image we can see a collage of images. In the center of the image there is a woman.

<!-- image -->

2

Tirashchina

(moving like a question mark (   ) on both sides)

In this image we can see a woman wearing jewelry and a necklace. The background is white in color.

<!-- image -->

Parivartita (moving from right to left)

In this image we can see a woman wearing jewelry.

<!-- image -->

Prakampita (moving from back to front)

<!-- image -->

(Side View)

3

4

<!-- image -->

## KEYWORDS

Non-verbal, emotion, head movements, eye movements, neck movements.

## POINTS TO REMEMBER

- Gestures are non-verbal movements which are used to convey a message.
- According to Abhinaya Darpanam , there are nine head movements, eight eyes movements and four neck movements.
- Head movements are called Shiro Bhedas .
- Eye movements are called Drishti Bhedas .
- Neck movements are called Greeva Bhedas .

<!-- image -->

<!-- image -->

## ASSESSMENT

1. Write down the names of the eye movements given below:

<!-- image -->

<!-- image -->

..............................

<!-- image -->

..............................

<!-- image -->

..............................

..............................

## 2. State whether the following statements are True or False.

| Statements                                                                                             | True/ False   |
|--------------------------------------------------------------------------------------------------------|---------------|
| Gestures are non-verbal movements which are used to convey a message.                                  |               |
| According to Abhinaya Darpanam we have eight Shiro Bhedas, nine Drishti Bhedas and five Greeva Bhedas. |               |
| Greeva Bheda is also known as neck movement.                                                           |               |
| Kampita is an eye movement.                                                                            |               |
| Sama is when the head is kept straight.                                                                |               |

<!-- image -->

## ASSESSMENT

3.  List the four Greeva Bhedas.

4. Name and describe any 5 Shiro Bhedas.

<!-- image -->

<!-- image -->

<!-- image -->

In this image I can see a paper with some text on it.

<!-- image -->

<!-- image -->

In this image we can see a woman dancing.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

-  Memorise the basic dance postures.
-  Memorise the sequence of movements in the prescribed Adavus .
-  Memorise the Sollukattus of the Adavus.
-  List the names of the series of Adavus .
-  Identify the different hand gestures and basic dance postures as performed in the Adavus .

<!-- image -->

## ADAVUS

The word Adavu means basic unit of dance. Adavus form the ABCs of pure dancing ( Nritta ) in Bharata Natyam. Just like a combination of alphabets gives words and thereafter sentences, Adavus are the basic units of Bharata Natyam dance compositions. In order to develop good dancing skills, mastering the Adavus in all three speeds is of crucial importance.

<!-- image -->

## SHUTRU ADAVUS

The Shutru Adavu usually consists of the twisting and turning movements of the body.

## The Sollukattus of the Shutru Adavus are:

## Tat Tai Tam Dhit Tai Tam

## FOURTH STEP

The image is a poster with a red and yellow color scheme. The background is white, and there is a large yellow rectangle in the center with text written in red and yellow. The text is in a sans-serif font, and it reads:

"Notes to Student

Recall the first three steps in the Shutru Adavus series.

<!-- image -->

## 1 st  Variation

## Method

1

-  Start  in  the Araimandi posture  with  both hands in the Shikhara gestures in front of the chest.

2

- Stamp the right foot, followed by the left on the syllable 'Tat Tai' and  simultaneously move the  hands  slightly  up  and  down  while looking up and in front.

<!-- image -->

In this image we can see a woman standing and doing a pose.

<!-- image -->

3

-  On  the  syllable 'Tam' the  right foot is stretched on the heel on the right side.
-  Look  at  the  right  hand  as  the  arms  are opened in Natyarambhe position with the right shoulder slightly pulled in on the  same syllable.

<!-- image -->

In this image we can see a woman is standing and she is wearing a green color saree.

<!-- image -->

4

- Strike the right foot back  to  the  initial position, while the right shoulder pushes out slightly on the syllable 'Dhit' .
- Look at the right hand, then in front on the same syllable.
- Pause in the same position on the syllables 'Tai Tam' .

In this image we can see a woman standing and doing a dance.

<!-- image -->

5

- Lift the right foot and turn at the back to sit in Muzhumandi with the Avahitta hand gestures on the syllables 'Tat Tai' .

<!-- image -->

Rear view of the hand movement

<!-- image -->

<!-- image -->

<!-- image -->

- On the syllable 'Tam' lift the left foot to stand on Samapada posture while the arms open in Natyarambhe with Katakamukha hand gestures.
- Repeat the above movements once again on the syllables 'Dhit Tai Tam' .

## 2 nd  Variation

## Method

<!-- image -->

- Repeat method numbers 1-5 of the 1 st  variation.
-  In  method  number  5  the  only  change  that  occurs  is  the Tripataka hand gestures that are held at the back in Muzhumandi and the Pataka hand in the Samapada position.

In this image we can see a woman standing and wearing a green and red color dress.

<!-- image -->

In this image we can see a woman standing and she is wearing a green saree and red t-shirt.

<!-- image -->

## Fifth Adavu

## Method

1

- The Adavu starts in Araimandi posture with the right hand in Tripataka in front of the chest.
- The left hand is held above the head in Tripataka gesture.

2

- Jump on toes on the syllables 'Tat Tai' .
-  Kick  the  right  foot  up  at  waist  level  on  the side, on the syllable 'Tam' .
-  The  right  arm  is  stretched  on  the  side simultaneously.
- Repeat the same movements again on the syllables 'Dhit Tai Tam' .

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a green color saree and a gold color belt.

<!-- image -->

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a green color saree and red color pant.

<!-- image -->

<!-- image -->

<!-- image -->

## NOTES TO TEACHER

Adavus may differ according to different schools of learning.

Ensure that the differences are clearly explained to learners so as not to create any confusion.

## NOTES TO TEACHER

Note that the movements for the 5th Adavu can also be executed diagonally instead of on the sides.

4

- Jump on the side by lifting the right and the left  leg  consecutively  while  crossing  the  left foot at the back on the syllables 'Tat Tai' .
- The right hand is extended on the right side simultaneously.

5

- On the syllable 'Tam' jump back and cross the right foot at the back, while the right hand returns in front of the chest.

In this image we can see a woman is dancing. She is wearing a green color saree and a red color t-shirt. She is wearing a gold color belt.

<!-- image -->

<!-- image -->

<!-- image -->

6

- Strike the right toes at the back on the syllable 'Dhit' , then stamp the left foot, which is in front, on the syllable 'Tai' and end the movement on the syllable 'Tam' by joining both feet.
- The right arm is extended in the Natyarambhe position on the last syllable.

In this image we can see a woman standing and dancing. She is wearing a green saree and a red saree. She is wearing a gold bracelet on her right hand.

<!-- image -->

## Sixth Adavu

1

- The Adavu starts in Samapada position with the right arm stretched down on the side and the left hand is placed above the head.
- Both hands are in Tripataka gestures.

<!-- image -->

In this image we can see a woman standing and doing a pose. In the background there is a banner.

<!-- image -->

<!-- image -->

2

- Jump slightly forward with both feet together on the syllables 'Tat Tai' .
- Then jump again on the toes and sit down in Muzhumandi posture on the syllable 'Tam' .
- The right hand is brought in front of the chest on the same syllable.

3

- Stamp  the  left  foot while  rising in  the Araimandi posture and lift the right leg at waist level on the side on the syllables 'Dhit Tai' .
-  On  the  syllable 'Tam' the  right foot is crossed at the back.
-  On  the  syllables 'Tat  Tai  Tam' repeat number 4 and 5 of fifth Adavu.

<!-- image -->

<!-- image -->

In this image we can see a group of women dancing.

<!-- image -->

5

- Then stamp the right foot away from the left foot followed by the stamping of the left and again the right foot on the syllables 'Dhit Tai Tam' .
- The right arm is extended on the side.

In this image we can see a woman is standing and she is wearing a green color saree and a red color saree.

<!-- image -->

## YETTA ADAVU

The Yetta Adavu series consist of Adavus that are executed in the same place. The feet movements comprise mainly of stamping and small jumps on the toes with both feet simultaneously. In this series only the Tripataka hand gesture is used in all the steps.

## The syllables for Yetta Adavu series are:

Tat Tai Ta Ha Dhit Tai Ta Ha

## First Adavu

## Method

<!-- image -->

-  The  first Adavu starts  in  the Araimandi posture with both hands in Tripataka gestures which are placed in front of the chest.

<!-- image -->

In this image we can see a woman standing and doing a pose. She is wearing a green color saree. In the background there is a white color background.

<!-- image -->

<!-- image -->

2

-  Stamp  the  right  foot  while  the  right  hand  stretches  on  the  right  side  at shoulder level on the syllable 'Tat' .
- The right Tripataka hand is turned with the palm facing up.
- The left Tripataka hand is turned with the palm facing down.
- The same movement is repeated on the opposite side on the syllable 'Tai' .
- The eyes follow the hand movements.

In this image we can see a woman standing and doing a pose.

<!-- image -->

3

-  On  the  syllable 'Ta' jump  on  the  toes  with both  feet  simultaneously  while  keeping  the hands in the same position.
- Look at the right hand.

In this image we can see a woman is standing and dancing.

<!-- image -->

<!-- image -->

4

-  Stamp  the  right  foot  while  the  left  foot remains on the toes.
- The palm of the right hand is turned up and the left arm is changed into the Natyarambhe position on the syllable ' Ha' .

5

-  The  above  sequence  of  movements  from numbers 1 to 4 is repeated on the left side on the syllables 'Dhit Tai Ta Ha' .
-  Stamp  the  right  foot  and  stretch  the  right hand  diagonally  in  front,  pointing  to  the  left hand corner, on the syllable 'Tat' .
- On the syllable 'Tai' stamp the left foot and bring the right hand in front of the chest and stretch the left hand  on  the  left side at shoulder level.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a woman is standing and she is wearing a red and green color dress and she is wearing a belt and she is also wearing a bracelet.

<!-- image -->

<!-- image -->

In this image we can see a woman standing and she is wearing a green saree.

<!-- image -->

<!-- image -->

8

- Jump on toes with both feet while the hands remain  in  the  same  position  on  the  syllable 'Ta' .
- Look at the right hand.
-  Stamp  the  right  foot  while  the  left  foot remains on the toes.
-  The  right  hand  is  turned  up  and  the  left arm is changed into the Natyarambhe position on the syllable 'Ha' .
-  The  movements  of  number  6  to  9  are repeated on the left side.
-  Jump  with  both  feet  on  the  toes  with  the hands  in Tripataka gestures  placed  in  front of the chest on the syllable 'Tat' .
- Look up.

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a woman dancing.

<!-- image -->

1 1

- On the syllable 'Tai' stamp the right foot.
- Stretch the right arm and bend on the right side.
- Look at the right hand.

12

- Repeat movements number 10 and 11 on the left side on the syllables 'Ta Ha' .

<!-- image -->

In this image we can see a woman is dancing. She is wearing red and green color dress.

<!-- image -->

13

- Stretch the right arm in front and keep the left hand,  palm  facing  up,  in    front  of  the  chest while jumping on the toes with both feet on the syllable 'Dhit' .

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

14

-  The  right  foot  is  stamped  on  the  syllable 'Tai' ,  while  the Tripataka hands  are  turned in the opposite direction simultaneously.
- Look at the right hand.

15

-  Repeat  movements number 13 and 14 on the left side on the syllables 'Ta Ha' .

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress. She is wearing a gold color belt and a bracelet. She is wearing a white color t-shirt. She is wearing a yellow color belt. She is wearing a red color pant. She is wearing a white color t-shirt. She is wearing a yellow color bracelet. She is wearing a white color t-shirt. She is wearing a white color belt. She is wearing a white color t-shirt. She is wearing a white color belt. She is wearing a white color t-shirt. She is wearing a white color belt. She is wearing a white color t-shirt. She is wearing a white color belt. She is wearing a white color t-shirt. She is wearing a white color belt. She is wearing a white color t-shirt. She is wearing a white color belt. She is wearing a white color t-shirt. She is wearing

<!-- image -->

<!-- image -->

## Second Adavu

## Method

<!-- image -->

-  The  second Adavu starts  in  the Araimandi posture with both hands in Tripataka gestures in front of the chest.

2

-  Stamp  the  right  foot  while  the  right  hand moves slightly forward on the syllable 'Tat' .
-  Then  the  left  foot  is  stamped  while  the  left hand  moves  slightly  forward  on  the  syllable 'Tai' .
-  The  eyes  look  at  the  hands  on  the  syllable 'Tat' and then in front on the syllable 'Tai' .

In this image we can see a woman standing and she is wearing a red and green color dress and she is also wearing a yellow color belt.

<!-- image -->

3

- Stamp the right foot and stretch the right hand on the right side at shoulder level on the syllable 'Ta' .
- The right Tripataka hand is turned with the palm facing up.
-  The  left Tripataka hand  is  turned with the palm facing down.
-  The  same  movement  is  repeated on the opposite side on the syllable 'Ha' .
- The eyes follow the hand movements.
- On the syllable 'Dhit' , jump on the toes with both  feet  simultaneously  while  keeping  the hands in the same position.
- Look at the right hand.

In this image we can see a woman standing and doing a pose.

<!-- image -->

<!-- image -->

<!-- image -->

5

-  Stamp  the  right  foot  while  the  left  foot remains on the toes.
-  The  palm  of  the  right  hand  is  turned  up and the left arm is changed into the Natyarambhe position on the syllable 'Tai' .

6

-  Repeat  movements  number  5  and  6  once more on the syllables 'Ta Ha' .

7

-  The  above  sequence  of  movements  from number 1 to 6 is repeated on the left side on the syllables 'Tat Tai Ta Ha Dhit Tai Ta Ha' .

8

-  Stamp  the  right  foot  while  the  right  hand moves slightly forward on the syllable 'Tat' .
- Then the left foot is stamped while the left hand  moves  slightly  forward  on  the  syllable 'Tai' .
- The eyes look at the hands on the syllable 'Tat' and in front on the syllable 'Tai' .

<!-- image -->

In this image we can see a woman dancing.

<!-- image -->

<!-- image -->

9

-  Stamp  the  right  foot  while  stretching  the right hand diagonally in front, pointing to the left hand corner on the syllable 'Ta' .

10

- On the syllable 'Ha' stamp the left foot and bring the right hand in front of the chest and stretch the left hand  on  the  left side at shoulder level.

1 1

- Jump on toes with both feet while the hands remain  in  the  same  position  on  the  syllable 'Dhit' .
- Look at the right hand.

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

12

-  Stamp  the  right  foot  while  the  left  foot remains on the toes.
-  The  palm  of  the  right  hand  is  turned  up and the left arm is changed into the Natyarambhe position on the syllable 'Tai' .

13

-  Repeat  movements  numbers  11  and  12 once more on the syllables 'Ta Ha' .
-  The  movements  of  numbers  9  to  12  are repeated  on  the  left  side  on  the  syllables 'Tat tai Ta Ha Dhit Tai Ta Ha' .
- Jump  on  toes  with  both  feet with the hands  in Tripataka gestures  in  front  of  the chest on the syllable 'Tat' .
- Look up at the same time.

<!-- image -->

In this image we can see a woman is standing and she is wearing a green color saree and red color t-shirt.

<!-- image -->

In this image we can see a woman standing and doing a pose.

<!-- image -->

14

-  Stamp  the  right  foot  on  the  syllable 'Tai' and stretch the right arm with Tripataka hand gesture while bending on the right side.
- Look up at the same time.

15

-  Repeat  movements  number  13  and  14  on the left side on the syllables 'Ta Ha' .

In this image we can see a woman dancing. She is wearing a red and green color dress.

<!-- image -->

<!-- image -->

<!-- image -->

16

- Stretch the right arm in front and keep the left hand,  palm  facing  up,  in  front  of  the  chest while jumping on the toes with both feet on the syllable 'Dhit' .

17

- Stamp  the  right  foot  on  the  syllable 'Tai' , while the Tripataka hands turn in the opposite directions simultaneously.
- Look at the right hand.

18

- Repeat  movements  numbers  16  and  17 on the left side on the syllables 'Ta Ha' .

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

## Third Adavu

1

- Start in Araimandi posture with the hand in Tripataka gestures in front of the chest.

<!-- image -->

In this image we can see a woman standing and doing a pose. She is wearing a red and green color dress.

<!-- image -->

<!-- image -->

2

- The right and then the left foot are stamped on 'Tat Tai' .
- The  right  arm  is  stretched  downward  on the side along with the body bent sideways.

In this image we can see a woman is dancing. She is wearing a red and green color dress.

<!-- image -->

3

- On the syllable 'Ta' jump on toes with both feet  while  the  right  hand  is  raised  up  above the head.
- The  body is  bent  on  the  left  side  while  the head is raised to look at the hand.
- Stamp the right foot and lower the right arm down on the side on the syllable 'Ha' .

In this image we can see a woman is dancing. She is wearing a red and green color dress.

<!-- image -->

<!-- image -->

5

- Repeat the movements of number 2 to 4 on the left side on the syllables 'Dhit Tai Ta Ha' .

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

<!-- image -->

<!-- image -->

6

- The right and the left foot are again stamped  on  the  syllable 'Tat  Tai' while  the right hand is stretched in front.
- On  the  syllable 'Ta' jump on the toes with both feet.
- Stamp  the  right  foot  while  both  hands,  in Tripataka gestures, turn in the opposite direction on the syllable 'Ha' .

<!-- image -->

8

- Repeat the movements of numbers 6 and 7 on the left side on the syllables 'Dhit Tai Ta Ha' .

## Fourth Adavu

<!-- image -->

- Start  in Araimandi posture  with  the  hands in Tripataka gestures in front of the chest.

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

In this image we can see a woman standing and doing a pose.

<!-- image -->

2

- Stamp  the  right  and  left  foot  four  times alternately on the syllables 'Tat Tai Ta Ha' .
- Stretch the right arm downward on the side while the body bends sideways.

3

- On  the  syllable 'Dhit' jump  on  toes  with both feet  while  the  hand  is  raised  up  above the head.
- The body is bent on the left side while the head is raised to look at the hand.
- Stamp  the  right  foot  and  lower  the  right arm down on the side on the syllable 'Tai' .

<!-- image -->

5

- Repeat the movements of numbers 3 to 4 once more on the syllables 'Ta Ha' .

<!-- image -->

In this image we can see a person standing and holding a stick.

<!-- image -->

<!-- image -->

6

- The right and the left foot are stamped four times alternately on the syllables 'Tat Tai Ta Ha' while the right hand is stretched in front.

7

- On the syllable 'Dhit' jump on the toes with both feet.

8

- Stamp  the  right  foot  on  the  syllable 'Tai' while both hands, in Tripataka gestures, turn in the opposite direction.

9

- Repeat movements numbers 7 and 8 once more on the syllables 'Ta Ha' .
- Then, repeat the whole step on the left side.

## Fifth Adavu

1

- Start in the Araimandi posture with the hands in Tripataka gestures, palm facing upward in front of the chest.

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

In this image we can see a woman standing and doing a pose.

<!-- image -->

2

- In  the Araimandi posture  jump  on  the  left hand corner in front with both feet.
- Stretch the arms forward with the palms of the Tripataka hands  facing  upward  on  the syllable 'Tat' .

3

- Stamp  the  right  foot  to  return  to  the  initial place while both hands return in front of the chest on the syllable 'Tai' .

4

- Stamp  the  left  foot  close  to  the  right  foot and  extend  the  left  arm  in Natyarambhe on the syllable 'Ta' .

<!-- image -->

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

<!-- image -->

5

- Stamp the right foot while opening the right arm  in the Natyarambhe position on  the syllable 'Ha' .
- The  eyes  follow  the  movements  of  the hands.

6

- On  the  syllable 'Dhit' jump  on  the  toes  of both  feet  and  the  right  hand  is  brought  in front of the chest with the palm  of the Tripataka hand facing down while the left arm is stretched on the left side at shoulder level with the palm of the Tripataka hand facing up.
- Look at the right hand.

7

- Stamp  the  right  foot  while  the  left  foot remains on the toes.
- The  palm  of  the  right  hand  is  turned  up and the left arm is changed into the Natyarambhe position on the syllable 'Tai' .

8

- Repeat the movements of numbers 6 and 7 once more on the syllables 'Ta Ha' .
- Repeat the whole step on the left side.

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a green color saree.

<!-- image -->

<!-- image -->

## Dhitenda Tatai Adavu

This series of Adavus consists mainly of jumps with the hands extended on the sides or turning in circular movements.

## The syllables of Dhitenda Tatai Adavu are as follows:

## Dhitenda Tatai Dhittenda Tatai

## First Adavu

## Method

<!-- image -->

- Start in the Araimandi posture with the hands in Katakamukha gestures in front of the chest.
- Lift up the right and then the left leg to jump on the right side.
- The left foot lands on the toes while crossing at the back of the right foot on the syllables 'Dhitenda Tatai' .
- Simultaneously the right hand in Alapadma gesture is stretched upward and moves  to  the  right  side  in  a  semi-circular  movement  to  finally  extend  at shoulder level.

In this image we can see a woman standing and posing for the photo. She is wearing a red blouse and a green saree. She is wearing a necklace and a bracelet.

<!-- image -->

<!-- image -->

3

- Repeat number 2 on the left side on the syllables 'Dhitenda Tatai' .

<!-- image -->

<!-- image -->

In this image we can see a woman standing and holding an object.

<!-- image -->

4

- The right and then the left leg are lifted to jump in front.
- The left foot lands on the toes on the side of the right foot.
- The  right  hand  is  stretched  in  front  in Alapadma gesture  while the left hand  is placed above the head with the Katakamukha gesture  in  an  upside  down  position  on  the syllables 'Dhitenda Tatai' .

5

- The left and then the right foot are lifted to jump back.
- The right foot lands on the toes on the side of the left foot on the syllables 'Dhitenda Tatai' .
- The  right  hand  is  brought  back  in  front  of the  chest  in Katakamukha gesture  and  the eyes follow the hand movements.

6

- Repeat the whole set of movements on the left side.

<!-- image -->

In this image we can see a woman is dancing. She is wearing a red and green color dress. She is wearing a gold color belt. She is wearing a gold color bracelet. She is wearing a gold color ring. She is wearing a gold color ring on her finger. She is wearing a gold color bracelet on her wrist. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger. She is wearing a gold color ring on her finger

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

## Second Adavu

## Method

1

- Start in the Araimandi posture with the hands in Katakamukha gestures in front of the chest.
- Repeat movements of the first adavu from number 1 to 3.

In this image we can see a woman standing and doing a pose.

<!-- image -->

2

- Lift  the  right  and  then  the  left  foot  to  jump  and  sit  down  in Muzhumandi posture in front with the body turned sideways so as to face the left side on the syllables 'Dhitenda Tatai' .
- The hands in Alapadma move in a circular movement from down to above the head where they change into Katakamukha gestures in an upside down position.
- The eyes follow the right hand's movements.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

3

- From  the Muzhumandi posture  get  up  in Araimandi posture and place the left foot at the back on the heel.
- The right hand is brought in Katakamukha gesture in front of the chest and the left hand is  placed  above  the  head  in Katakamukha gesture upside down on the syllable 'Dhit' .
- Take  a  turn  of  360  degrees  with  the  right foot  placed  on  the  left  knee  and  the  right hand opens and turns along on the syllables 'Tenda Tatai' .
- The movement ends in a standing posture with the right hand in Katakamukha gestures in front of the chest and the left hand remains above the head.
- Repeat the whole set of movements on the left side.

<!-- image -->

## Third Adavu

## Method

1

- Start in the Araimandi posture with the hands in Shikhara gestures in front of the chest.
- Lift  the  right  and  then  the  left  foot  to  jump  and  stretch  the  left  leg  at  the back while the body turns so as to face the left side.
- The right leg remains bent in front.
- The right arm with the Pataka hand gesture rotates around the side of the body to end up in front on the syllables 'Dhitenda Tatai' .
- The  same  movements  are  repeated  for  the  left  side  on  the  syllables 'Dhitenda Tatai' .
- This is followed by executing the same movement on the right and left while the body turns in front on the syllables 'Dhitenda Tatai' .
- The eyes follow the hand movements throughout the execution of the Adavu .

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a woman standing and doing a pose.

<!-- image -->

In this image we can see a woman is standing and she is wearing a red and green color dress and a gold color belt.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Second Adavu TIRMANAM ADAVUS

Tirmanam  Adavus are usually used in patterns of three consecutive movements to form the ending part of dance sequences in dance compositions.

## Tirmanam Adavus consists of two series of steps namely:

Gi Na Tom and Dhari Kita Tom .

1 st   series

Gi Na Tom

The syllables are:-

Gi Na Tom

Tadi Gina Tom

Taka Tadi Gina Tom

Taka Diku Tadi Gina Tom

## First Adavu

## Method

<!-- image -->

- The Adavu starts  in  the Araimandi posture with both hands, in Tripataka gestures, in front of the chest.
- Stretch  the  right  leg  in  front  with  the  foot resting on the heel, on the syllable 'Gi' .
- The  right  arm,  with  the  palm  facing  up,  is also stretched in front on the same syllable.
- The  left  elbow  is  stretched  at  the  back  to form one line with the right arm.

<!-- image -->

In this image we can see a woman standing and she is wearing a red and green color dress and she is also wearing a gold color belt.

<!-- image -->

<!-- image -->

3

- Stamp the left foot at the back while moving slightly forward on the syllable 'Na' .
- The  right  hand  is  then  brought  in  front  of the chest.
- On  the  syllable 'Tom' the  right foot is stamped  to  join  the  left  foot  while  the  right arm is stretched at the back.
- The eyes follow the movements of the right hand.
- Repeat the whole set of movements on the left side.

<!-- image -->

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

<!-- image -->

## Second Adavu

## Method

- The Adavu starts  in  the Araimandi posture  with  both  hands,  in Tripataka gestures, in front of the chest.
- Stamp the right foot on the syllable 'Tadi' and move the right hand slightly forward in a crisp movement.
- The eyes look at the hands then in front on the syllable 'Ta' .
- On  the  syllables 'Gi  Na  Tom' repeat  movements  of  the  first adavu from number 2 to 4.

## Third Adavu

## Method

- The Adavu starts  in  the Araimandi  posture  with  both  hands,  in Tripataka gestures, in front of the chest.
- Stamp the right and then the left foot on the syllables 'Taka Tadi' and move the right and then the left hand slightly forward in a crisp movement.
- Then look at the hands in front on the syllables 'Taka Tadi' .
- On  the  syllables 'Gi  Na  Tom' repeat  movements  of  the  first adavu from number 2 to 4.

## Fourth Adavu

## Method

- The Adavu starts  in  the Araimandi  posture  with  both  hands,  in Tripataka gestures, in front of the chest.
- Stamp  the  right  and  then  the  left  foot  on  the  syllables 'Taka  Diku' and move the right and then the left hand slightly forward in a crisp movement.
- Look at the hands then in front on the syllables 'Taka Diku' .
- On the syllables 'Gi Na Tom' repeat movements of the first adavu from number 2 to 4.

<!-- image -->

## 2 nd  Series

## Dhari Kita Tom

The syllables are:- Dhari Kita Tom Kitataka Dhari Kita Tom Taka Kitataka Dhari Kita Tom Taka Diku Kitataka Dhari Kita Tom

## First Adavu

## Method

<!-- image -->

- Start  in  the Araimandi position  with  the arms in the Natyarambhe position.
- On  the  syllable 'Dhari' lift  the  right  foot and place it in front on the heel.
- Extend  the  left  arm  at  the  back  in  the  left hand  corner  with  the  hand  in Katakamukha gesture.
- The body turns slightly on the left side.

<!-- image -->

<!-- image -->

In this image we can see a woman standing and she is wearing a green saree.

<!-- image -->

<!-- image -->

<!-- image -->

3

- On the syllable 'Ta' jump on toes with both feet while the right hand is raised up above the head.
- The body is bent on the left side while the head is raised to look at the hand.
- Stamp the left foot in the same position while the left hand moves above the head on the syllable ' Kita' .
- The right foot finally returns and stamps near the left foot on the syllable 'Tom'.
- The left hand goes down from the front in Alapadma gesture on the same syllable.
- The eyes follow the left hand's movements.
- Look at the left hand throughout the execution.
- Repeat the movements on the left side.

In this image we can see two women are standing and dancing.

<!-- image -->

<!-- image -->

## Second Adavu

## Method

<!-- image -->

- Start  in Araimandi posture  with  the  hand in Tripataka gestures in front of the chest.
- The  starting  posture  is  in Araimandi with the hand in the Natyarambhe position.

<!-- image -->

In this image we can see a woman standing and posing for the photo.

<!-- image -->

2

- Start in Araimandi posture with the hand in Tripataka gestures in front of the chest.
- Strike the right foot and move the right arm in front while the hand in Pataka gestures gives a slight jerk outward on the syllable 'Kitataka' .
- On  the  syllables 'Dhari  Kita  Tom' repeat movements of the first adavu from number 2 to 3.

In this image we can see a woman is standing and she is wearing a red and green color dress and a gold color belt.

<!-- image -->

## Third Adavu

## Method

<!-- image -->

- The  starting  posture  is  in Araimandi with the hand in the Natyarambhe position.

<!-- image -->

In this image we can see a woman standing and doing a pose. The background is in white and red color.

<!-- image -->

<!-- image -->

3

- Strike  the  right  and  then  the  left  foot  and simultaneously  move  the  right  arm  in  front while  the  hand,  in Pataka gestures,  gives  a slight  jerk  outward  and  then  inward  on  the syllable 'Taka Kitataka' .
- On  the  syllables 'Dhari  Kita  Tom' repeat movements  of  the  first adavu from  number 2 to 3.

In this image we can see a woman standing and dancing.

<!-- image -->

## Fourth Adavu

## Method

1

- The  starting  posture  is  in Araimandi with the hand in the Natyarambhe position.
- Strike the right and the left foot, then again the  right  foot  on  the  syllables 'Taka  Diku Kitataka' while simultaneously extending the right  arm  in  front  at  chest  level  and  move the right hand in Pataka gesture 3 times.
- On  the  syllables 'Dhari  Kita  Tom' repeat movements  of  the  first adavu from  number 2 to 3.

In this image we can see a woman standing and posing for the photo.

<!-- image -->

<!-- image -->

In this image we can see a woman standing and dancing. She is wearing a red and green color dress.

<!-- image -->

<!-- image -->

Fifth Adavu

## KEYWORDS

Basic units, dance composition, dance sequence.

## POINTS TO REMEMBER

- The word Adavu means basic unit of step.
- Adavus form the ABCs of pure dancing ( Nritta ) in Bharata Natyam.
- The Yetta Adavu series consists of Adavus that are executed in the same place.
- The Dhitenda Tatai series of Adavus consists mainly of jumps with the hands extended on the sides or turning in circular movements.
- Tirmanam Adavus are usually used in patterns of three consecutive movements to form the ending part of dance sequences in dance   compositions.
- Tirmanam Adavus consist of two series of steps namely the Gi Na Tom and the Dhari Kita Tom.

<!-- image -->

<!-- image -->

<!-- image -->

## ASSESSMENT

1. List the hand gestures and basic dance postures used in the Shutru Adavu series.

2. Answer the following short questions:

- a. Name one series of Adavus where only Tripataka hand gesture is used.

- b. Name one step where Araimandi and Muzhumandi posture are used.

- c. Name one step where Shikhara and Pataka hand gestures are used.

3. Count the syllables of Shutru and Yetta Adavus in the three speeds of Adi Tala .

<!-- image -->

In this image, we can see a person dancing. There is a background.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

-  Explain the following compoents of indian classical dances: Nritta, Nritya, Natya, Tandava, Lasya and Abhinaya .
-  Differentiate between Nritta and Nritya .
-  Differentiate between Tandava and Lasya .

<!-- image -->

## COMPONENTS OF INDIAN CLASSICAL DANCES

In Indian classical dances, there are different terms to categorise distinct facets in dancing according to the Abhinaya Darpanam and the Natya Sashtra . These different facets as used in Indian classical dance are known as: Nritta, Nritya, Natya, Tandava and Lasya.

## Nritta

<!-- image -->

Nritta is often referred to as 'pure' or 'abstract' dance. The movements and hand gestures are beautiful, decorative, graceful and artistic with rhythmic patterns of footwork.

Nritta is solely intended to display the technique and beauty of the body in motion and the statuesque poses of the particular dance style.

In this image we can see a woman standing and dancing.

<!-- image -->

The  musical  accompaniment  for Nritta does  not  have  any  poetic  or  lyrical content  to  be  interpreted  by  the  dancer. Nritta dance  compositions  do  not convey any story or idea. Emphasis is rather laid on beautiful and structured body movements with intricate rhythmic patterns.

Example of Nritta in Bharata Natyam are the Adavus and dance compositions such as Alarippu, Jatiswaram and Tillana .

## Nritya

<!-- image -->

Nritya is known  as  an  expressional or emotive  dance. Nritya dance  compositions are used to interpret the lyrics of the song through hand gestures and facial expressions.

Nritya may express just a sentence, a poem, small episodes or a whole dramatic story.

In this image we can see a woman standing and dancing.

<!-- image -->

<!-- image -->

<!-- image -->

Nritya can  also  express  the  idea  of  a  song  in  different  ways.  The  dancer interprets  the  lyrics  ( Sahitya )  with  the  help  of  facial  expressions,  hand gestures and bodily movements. It is the narrative form of dance.

In Nritya dance compositions, emphasis is laid upon sentiments. The themes of Nritya dance composition are mostly based upon divine love and devotion towards God.

Examples of Nritya dance compositions in Bharata Natyam are: Shabdam and Padam .

There are also other dance compositions such as the Shabdam , kirtanam and Varnam where both Nritta and Nritya aspects are used.

## Natya

<!-- image -->

The word Natya is derived from ' Nata ' which means  actor. Natya is  considered  to  be  a combination of acting with dialogue or speech, music and dancing. Natya is dance-drama, that is, drama involving music and  dance.  It  is  the  dramatic  element  of Indian classical dance.

In this image we can see two women are dancing.

<!-- image -->

## Tandava

<!-- image -->

Tandava is  considered  as  the  masculine aspect  of  dance.  These  forms  of  dances consist of forceful and vigorous movements with heavy steps. The music is usually very rhythmic and fast in tempo.

Tandava dance is mostly appropriate for the masculine body but women also can perform this  dance.  According  to  Hindu  mythology, the  dances  of  Lord Shiva are  known  as Tandava dances.

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

<!-- image -->

<!-- image -->

Lasya is  considered  as  the  opposite  of Tandava . Hence, it is the feminine aspect of dance.

Lasya is the graceful, soft and gentle body movement with light steps in  dance.    It  is executed in a reduced speed compared to the Tandava . According to Hindu mythology,  this  dance  was  performed  by Goddess Parvati .

## Abhinaya

<!-- image -->

Abhinaya is the art of expression in Indian classical dances.

Abhinaya is  a  Sanskrit  word  which  is made of the prefix ' abhi ', meaning 'towards',  and  the  root  ' ni ',  meaning  'to carry'. Abhinaya means  to carry the expression  of  the  dancer  towards  the audience so as they experience the sentiments expressed.

In  Indian  classical  dances, Abhinaya is the expressional aspect of dance where the dancer interprets the lyrics of a song.

The dancer has to visualise the  mental and physical conditions of any character to be depicted.

In this image we can see a woman standing and holding a jewelry.

<!-- image -->

She  has  to  depict  and  convey  these  conditions  through  imitation,  mime, expressions or dance movements.

<!-- image -->

In this image we can see a woman standing and smiling. She is wearing a blue and orange color dress.

<!-- image -->

<!-- image -->

Abhinaya or expression is divided into four types, namely: Angika, Vachika, Aharya and Sattvika .

## · Angika Abhinaya

Anga means limbs and the part of the body. Angika Abhinaya is  expression made through the  use  of  the  physical  body,  that  is, Anga,  Pratyangas and Upangas.

## · Vachika Abhinaya

Vacha means speech and Vachika Abhinaya is the verbal expression in dance. It  is  the  expression  made  through  the  use  of  dialogue,  poetry,  song  and recitation.

## · Aharya Abhinaya

Aharya Abhinaya is the expression of a character through the use of costumes, make-up and jewellery. Stage decors are also included in Aharya Abhinaya .

## · Sattvika Abhinaya

Sattvika Abhinaya is the expression of the feelings which have been produced through  the  manifestations  of  different  mental  and  emotional  states.  The various states can be represented through facial expressions, gestures and dance movements. Some examples are laughing, weeping, shivering and so on.

<!-- image -->

<!-- image -->

## KEYWORDS

Pure dance, abstract dance, expressional dance, dramatic elements, masculine, feminie, forceful, graceful.

## POINTS TO REMEMBER

- Nritta is pure dance movements.
- Nritya is an expressional dance.
- Natya is the dramatic element in Indian classical dance.
- Tandava is the masculine aspect of dance and consists of forceful and vigourous movements.
- Lasya is the feminine aspect of dance and consists of soft and graceful movements.
- Abhinaya is the art of expression in Indian classical dances.
- Abhinaya is divided into four categories, namely: Angika, Vachika, Aharya and Sattvika .
- Angika Abhinaya is the expression through the use of Anga, Pratyangas and Upangas .
- Vachika Abhinaya is the expression made through speech, dialogue and lyrics.
- Aharya Abhinaya is the expression made through the use of costumes, make-up and jewellery as well as stage decors.
- Sattvika Abhinaya is the physical expression of the mental and emotional states.

<!-- image -->

<!-- image -->

## ASSESSMENT

1. State whether the following statements are either TRUE or FALSE.

- a) Natya is pure dance movements.

- b) Nritya is an expressional dance.

- c) Nritta is a form of dance and drama.

- d) Tandava is forceful dance.

- e) Lasya is a graceful and soft dance.

2. Match the following terms with the correct description.

3. Explain the following terms:

- a) Tandava

- b) Lasya

- c) Nritta

- d) Nritya

- a) Angika  Abhinaya

expression made through the use of costumes, make-up and jewellery

- b) Vachika  Abhinaya

is the physical expression of the mental and emotional states.

- c) Aharya  Abhinaya

expression made through the use of verbal expression

- d) Sattvika  Abhinaya

expression made through the use of Anga , Pratyangas and Upangas.

<!-- image -->

<!-- image -->

## ASSESSMENT

4. Differentiate between (a) Nritta and Nritya

- (b) Tandava and Lasya .

5. (a) Explain the term Abhinaya .

- (b) Explain the four types of Abhinaya .

<!-- image -->

In this image, we can see a statue and some text.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

-  Interprete the hand gestures and feet movements in the posture of Lord Nataraja.
-  Name the seven types of Tandavas.
-  Describe Ananda Tandava and Urdhva Tandava.
-  Describe the dance stories Kaliya Mardana and Rasa Leela.
-  Explain the moral teachings underlying the dance stories of Lord Shiva and Krishna.
-  Identify the various Indian Gods and Goddesses.
-  Value the virtues of good over evil.

<!-- image -->

## NATARAJA, SHIVA - THE KING OF DANCE.

<!-- image -->

In the center of the image we can see a statue.

<!-- image -->

Lord Shiva is also known as Lord Nataraja more prominently in the south of India. In this form He is worshipped as the king of dance.

Lord Nataraja , in His dance posture, represents the spiritual cosmic dance of Lord Shiva known as the Nadanta or Ananda Tandava . The Tandava dances of Lord Nataraja represent the masculine aspect of dance, which is a forceful and vigorous style.

He performed this dance in the golden temple of Chidambaram in Tillai.

In this image we can see a building with pillars and a roof. We can also see some buildings and a sky.

<!-- image -->

<!-- image -->

<!-- image -->

In the Ananda Tandava , Lord Shiva dances with four hands. The upper right hand sounds the Damru , sound representing the very first creating force and the intervals of beat in time process.

In this image we can see a sculpture of an animal.

<!-- image -->

## DID YOU KNOW?

A Damru is a small two-headed drum and is played by holding the middle part and shaking it with one hand.

<!-- image -->

The lower right hand in the pose of Abhaya Hasta , gives protection to his devotees.

In this image we can see a statue.

<!-- image -->

<!-- image -->

<!-- image -->

The  upper  left  hand  holds  the  sacred  flame  which  represents  the  fire  of sacrifice.

In this image we can see a statue.

<!-- image -->

The lower left hand in the Danda Hasta pose is stretched across his body and is pointing to the upraised left foot ( Kunchita Pada ) signifying blissful refuge to those who seek his love and grace.

In this image we can see a picture of a person standing and holding a stick in his hand. There is a text at the bottom of the image.

<!-- image -->

<!-- image -->

<!-- image -->

The right foot tramples down the dwarf Muyalaham , signifying the destruction of the evil; the left foot raised in the Kunchita Pada showers grace on all those who seek it.

Muyalaham

In this image we can see a statue.

<!-- image -->

The  face  of  Lord Nataraja has  a  blissful  expression,  with  his  radiant  eyes showing and spreading love and abundant mercy. He spreads his glory over the entire world, graciously granting release to the countless souls that seek him.

In this image we can see a sculpture.

<!-- image -->

<!-- image -->

<!-- image -->

## SEVEN TYPES OF TANDAVA

Tandava dance is the dance of Lord Nataraja . Lord Shiva passed on this art of dancing to human beings on earth through his disciple Tandu.

1. Ananda Tandava
- which expresses joy
2. Sandhya Tandava
3. Uma Tandava
4. Gauri Tandava
5. Kalika Tandava
6. Tripura Tandava
- the evening Tandava
- the Tandava in which Shiva danced with his consort Uma
- the Tandava in which Shiva danced with his consort Gauri
- the Tandava danced by Lord Shiva when he killed Kalika , the demon of evil and ignorance
- the Tandava danced by Lord Shiva when he killed the demon Tripura
7. Samhara Tandava
14. -Shiva's Tandava dance of death, symbolising the release of the soul from ' maya ' or illusion

## ANANDA TANDAVA OR NADANTA DANCE

One day, Lord Vishnu went to Mount Kailash in  the  Himalayas  to  visit  Lord Shiva .

In this image we can see a mountain.

<!-- image -->

Lord Shiva told  Lord Vishnu that  a  group  of  sages,  living  in  the  forest  of Taragam ,  were  very  arrogant  and  ill-behaved  and  refused  to  accept  the existence of God.

<!-- image -->

<!-- image -->

In this image we can see a group of people standing and holding a stick in their hands.

<!-- image -->

To teach them a lesson, Lord Shiva disguised himself as a handsome beggar and Lord Vishnu disguised himself as a beautiful woman, Mohini , the wife of the beggar.

This is a collage image, which consists of two images of the same person. The person in the first image is wearing a pink dress and a hat. In the second image, the person is wearing a red and blue dress and a white turban. Both images are in a colorful and vibrant style.

<!-- image -->

On seeing Mohini , the sages fell in love with her. The sages started quarrelling among themselves as each one wanted to have Mohini for himself.

In this image we can see a group of people sitting on the ground. In the background there are trees and the sky.

<!-- image -->

<!-- image -->

<!-- image -->

On  the  other  hand,  the  wives  of the sages got attracted to the handsome  beggar  who  made  the sages angry. They decided to make a big sacrificial fire and recited verses ( Mantras ) which created ferocious animals in order to destroy the beggar.

They created a ferocious tiger, with one  of  the Mantras ,  which  rushed to attack the beggar.  The latter caught  it,  killed  it  and  wore  its  skin around his waist.

The sages continued with their sacrificial  fire  and  created  a  huge poisonous serpent. Lord Shiva seized it and coiled it around his neck and began his mystic dance.

The sages were not discouraged by the failure  of  their  attempts.  They continued  with  the  rituals  and,  this time, the black demon dwarf, Muyalaham , came out of the fire and rushed  upon  Lord Shiva .  The  Lord pulled  the  demon  down  and  placed His sacred foot on the demon's back, thus breaking its spine.

Lord Shiva continued his dance. The sages recognized Lord Shiva's true form and they fell at his feet.

In this image we can see a group of people. In the front of the image there is a fire.

<!-- image -->

In this image we can see a snake.

<!-- image -->

In this image we can see a painting.

<!-- image -->

The philosophical meaning of this story is that God always protects and grants release from worldly attachment to all those who seek Him. He destroys evil in men and leads them to the path of righteousness.

<!-- image -->

<!-- image -->

## URDHVA TANDAVA

Once upon a time in the city of Chidambaram in the forest of Tillai, there lived Queen Kali who governed the city. One day, Lord Shiva was  invited  by  his devotees to visit the city of Chidambaram, which he accepted.

Unfortunately, when Lord Shiva came down to visit Chidambaram , the gate-keepers and soldiers of Kali did not allow him to enter the city. Lord Shiva was disappointed and felt insulted.

He then made a plan to challenge Queen Kali . He  proposed  her  to  take  part  in  a  dance competition with him. The condition was that the winner of this dance competition would rule the city of Chidambaram whereas the loser would have to leave the city for ever. Kali accepted the challenge of this dance competition.

In this image we can see two persons standing and holding a sword. In the background we can see a wall and a door.

<!-- image -->

In this image we can see a person holding a bowl and a bowl.

<!-- image -->

All the Gods were invited to witness the competition and to be the judges also. During the performance, both Kali and Shiva danced with enthusiasm.

Each dancer tried to imitate the movements of the other and each one tried to do better than the other. For a long time, they were both able to imitate each other.

<!-- image -->

<!-- image -->

In this image we can see the pictures of people.

<!-- image -->

At  last,  Lord Shiva got  impatient  and  he lifted  his  leg  above  his  head and touched his crown with his foot. Out of modesty and in respect for the audience, Queen Kali did not imitate Lord Shiva . So, Lord Shiva was declared the winner of the competition.

This dance came to be known as Urdhva Tandava because Lord Shiva danced with his foot raised upwards to touch his crown. The word ' Urdhva ' means upward.

As  per  the  condition  of  the  competition, the loser,  Queen Kali , left the city of Chidambaram forever.  The  devotees  of Shiva built a temple at the place where the competition  took  place  and  later  it  was developed as the huge temple of Nataraja at Chidambaram .

In this image we can see a painting. In the painting we can see a woman and a man.

<!-- image -->

The  followers  of Kali also  built  a  small shrine  for Kali near Chidambaram where she settled down.

In this image we can see a temple, there are trees, there is a building, there is a water body, there are clouds in the sky.

<!-- image -->

The philosophical aspect of this dance is that God shows the path towards freeing the self from ego and arrogance.

<!-- image -->

## DANCES OF KRISHNA

<!-- image -->

## LORD KRISHNA AS NATWAR

Krishna , as the dancer, is known as Natwar in the North of India. In Vaishnavite literature Krishna is  named  as Natwar the  supreme  dancer  as  he  is said  to  have  danced  on  several  occasions  and  he  is  often  represented as the divine dancer.

## KALIYA MARDANA

Krishna ,  in  his boyhood, was living in Gokula with his foster parents, Nanda and Yashoda .  In  the river Yamuna ,  which flowed through the village, lived a hundred-headed serpent called Kaliya. Kaliya , being a wicked serpent, was a menace to the herdsmen and their cattle.

In this image we can see a painting. In the background there are trees and mountains. At the bottom there is water.

<!-- image -->

The village  people  approached  Lord Krishna to  help  them  to  get  rid  of  this wicked creature.

In this image we can see a painting of a scene. In the background there are trees, water, grass, rocks, and a few animals. There are two people and a few animals.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Krishna recognised the forces of evil, which the serpent Kaliya represented, through his divine power.

One day Krishna was playing a game of ball together with his friends near the Yamuna river. While they were playing, suddenly the ball fell into the river and Krishna , without hesitating, jumped into the water to get back the ball.

In this image we can see a cartoon image of a person, a person is holding a stick, there are some people, there are some animals, there are some rocks, there are some trees, there is a water body, there is a ball, there are some flowers, there are some plants, there are some flowers, there is a sky.

<!-- image -->

His  friends  and  the  villagers  got  scared  for Krishna as  they  knew  that  the serpent Kaliya resided in the deep water of the river.

In this image we can see a cartoon image of a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a person and a

<!-- image -->

As soon as Kaliya saw Krishna he rushed to attack Him.

In this image we can see a group of people standing on the ground. In the background we can see trees, water, grass and the sky.

<!-- image -->

<!-- image -->

<!-- image -->

Krishna jumped on the serpent and with one foot upraised, danced his famous Tandava dance. He moved with force and determination. He jumped on the monster from one head to the other and subdued it.

In this image we can see a painting of a person. We can also see a snake and a bird.

<!-- image -->

The villagers were happy to see Krishna emerge victoriously out of the river.

In this image we can see a group of people. The people are wearing different color dresses. In the background there are trees.

<!-- image -->

In this youthful dance, Krishna symbolises that aspect of God which destroys evil and subjugates the enemies of the innocent.

In this image we can see a person standing. In the background there are flowers and leaves.

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a poster with some text and an image of a person.

<!-- image -->

## THE 'RASA LILA DANCE'

The Rasa Lila dances of Krishna cover almost the entire episodes of Krishna's life from his childhood to his adulthood.

There are four main Rasa Lila dances, namely Vasanta Rasa, Maha Rasa, Kunja  Rasa and Nitya  Rasa. The  main  apparent  form  that  recurs  in  every aspect of Rasa dances is the circle.

The Maha-Rasa is  performed on the full moon night of Kartik in  November. On  this night, Lord Krishna performs the Rasa-Lila with the Gopis . Charmed by the music of his flute, Radha and the Gopis abandon their work and set out to meet him.

In this image we can see a group of people standing and holding some objects. In the background we can see trees, flowers and the sky.

<!-- image -->

The intensity of their love is satisfied only when they meet Lord Krishna and dance with him in joy. As soon as the Gopis become conscious of their good fortune and are overcome with pride, Lord Krishna senses this and disappears with Radha .  When Radha considers  herself  more  fortunate  than  the Gopis Lord Krishna disappears from her as well. The Gopis become restless and pray ardently for Krishna to appear before them.

<!-- image -->

<!-- image -->

In their relentless search they woefully implore the trees, birds and animals to help  them  find  their  beloved.  Instead,  they  find Radha, also  weeping  and wandering in search of her Lord.

This separation melts their pride and Lord Krishna appears again, not as one person but in multiple forms. There are as many Krishnas as Gopis and all of them dance in ecstasy, performing the Rasa . At the end of the Rasa dance, Krishna suggests  to Radha and  the Gopis that  they  should  return  to  their homes.

In this image we can see a group of people. The people are standing on the ground. In the background there are trees and water.

<!-- image -->

## The moral teachings underlying the Maha-Rasa are:

Krishna's beautiful dances with the Gopis at Brindavan , on the banks of the Yamuna river, are symbolic.

Lord Krishna is  the  divine  lover,  dancer  and  musician.  The Gopis represent human beings in search of the Divine. This represents the freedom of man from earthly attachments and his taking the path of renunciation of the self.

<!-- image -->

<!-- image -->

## KEYWORDS

Cosmic dance, masculine, blissful, sacrificial fire, subjugate, ecstasy, renunciation.

<!-- image -->

https://www.youtube.com/watch?v=N5ppLY9XopE

## POINTS TO REMEMBER

- Lord Shiva is also known as Lord Nataraja more prominently in the South of India.
- The dances of Lord Shiva are known as the Tandava .
- Tandava is the masculine aspect of dance.
- Ananda Tandava is the dance where Lord Shiva subdues the demon dwarf Muyalaham .
- The Urdhava Tandava is the dance where Lord Shiva lifts his leg to his crown and wins the dance competition over Queen Kali .
- Lord Krishna is known as Natwar in the North of India.
- Kaliya Mardana is the dance story where Lord Krishna subdues the demon serpent Kaliya .
- Rasa Leela is the dance of Lord Krishna where he dances with the Gopis on the full moon night of Kartik month.

<!-- image -->

## ASSESSMENT

1. Interpret the image of Lord Nataraja.

2. Label the image of Lord Nataraja given below:

In this image we can see a statue of a person. There are few rays of light.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ASSESSMENT

3. Name the seven types of Tandava.

4. Narrate one dance story of Lord Shiva and of Lord Krishna.

<!-- image -->

In this image we can see a woman wearing a red and green color dress. She is smiling. In the background there is a text.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Outline the origin of Bharata Natyam.
-  Describe the growth, decline and rehabilitation of Bharata Natyam dance.
-  Explain the propagation of Bharata Natyam.

<!-- image -->

## EVOLUTION OF BHARATA NATYAM

## PREVIOUS FORMS

<!-- image -->

Bharata Natyam is the oldest and most popular classical dance style of India. It originated from and evolved in Tamil Nadu, a state in the south of India. The foundation of this dance form can be traced in the 'Natya Shastra', a text on performing  arts  written  by  Bharata  Muni,  which  is  often  referred  to  as  the encyclopaedia of Indian Classical Dances.

Originally, Bharata Natyam  was presented in dance-drama form in different  variations.  In  the  Tanjore district and elsewhere in the south, dance-dramas, called the Bhagavata Mela Nataka, were regularly performed and are to be seen, occasionally and even today in the South Indian temples. All the characters  of  the  dance-dramas were exclusively taken by men who were Brahmins, priests, musicians, scholars and dancers.

In this image we can see a book with the cover of it.

<!-- image -->

Other variations of dance-dramas were the Kuruvanji dance ballet, which were performed by a group of female dancers and the Navasandhi dance which were  performed  as  a  ritual  in  the  temples.  Bharata  Natyam  took  all  these forms  before  it  adopted  its  present  form,  which  is  performed  today  on stage as a solo dance.

Bharata  Natyam  had  many  other  names  such  as Dasiattam  (dasiservant attamdance ) , Sadirattam (sadirto present attamdance ) , Chinna Melam and Bharatam before  it  took  its  actual  name  in  the  present  context.  It  is  only recently that the term 'Bharata Natyam' has come into general use instead of Dasiattam, meaning the dance of the Devadasis .

<!-- image -->

<!-- image -->

## TEMPLE RECORDS

<!-- image -->

During the rule of the Pallavas , Cholas , Nayakas and later the Pandyas , Bharata  Natyam  dance  flourished  in  temples  as  an  art  form  and  also  as  an integral  part  of  worship.  The  dance  has  been  handed  down  from  one generation to the other in its purest form for many centuries.

In this image we can see a temple.

<!-- image -->

In this image we can see a bridge, buildings, trees, poles and some objects.

<!-- image -->

Under these dynasties, great temples like Brihadeeshwara of Tanjavur and  the Nataraja of Chidambaram were built. These famous temples have preserved records of Karanas or basic dance postures, through  stone  sculptures,  as  described  in  the Natya Shastra and as used in Bharata Natyam.

<!-- image -->

Tamil  inscriptions  also  mention  that  about  four  hundred Devadasis were attached  to  the  great Shiva temple  at Tanjore and  one  hundred  to  the Kanchipuram temple.

## GROWTH

<!-- image -->

During the Pallava and Chola reign (9 th  to 13 th  Centuries), the art of dancing and music blossomed, and concurrently the Devadasis and the Nattuvanars were  highly  appreciated  for  their  art.  For  many  centuries,  Bharata  Natyam dance was performed in the temples, as part of daily worship, by young girls called Devadasis (servants of God) or temple dancers and Nattuvanars (dance masters/gurus).

<!-- image -->

<!-- image -->

These Devadasis ,  who dedicated their lives to serve the temple deity, were accomplished artistes. They were not only well-versed in Sanskrit and other languages but would sing, dance and play many musical instruments as well. During this period, Bharata Natyam was known by the name of Dasiattam .

In royal Durbars (courts) dancing girls called ' Rajadasis '  danced  during  state  and  festive occasions. On the other hand, the ' Alankaradasis ' performed for marriages, birth celebrations and other communal functions.  Their  dance  performances  were considered auspicious and was  also an essential part of rituals.

The Devadasis and the Nattuvanars maintained  these  traditions  from  generation to generation together with their families who were  specialised  in  the  art  of  music  and dance.  Thus  the  dance  of  the Devadasis has been preserved in its purest form for many centuries.

In this image we can see a group of people standing.

<!-- image -->

## MARATHA RULE

<!-- image -->

During the Maratha rule (AD 1674 - AD 1854) the dance of the Devadasis came to be known as  ' Sadirattam '.  In  Marathi,  ' Sadir '  means  to present  and  ' attam' means  dance.  The  term ' Sadir ' came into vogue as it corresponded to the  presentation  of  the  dance  in  the  courts, when dancers were being announced before the King.

During the time when Raja Sarfoji II was ruling (AD 1798 - 1832), four court  musicians  and dancers contributed in shaping the repertoire of Bharata Natyam for a dance recital.

Raja Serfoji II

<!-- image -->

In this image we can see a painting of a person.

<!-- image -->

<!-- image -->

The Bharata Natyam repertoire as it appears today is an enhanced form owing to the contribution of those four Pillai musician brothers, namely: Chinayya, Ponnaya, Shivanandum and Vadivelu.

In this image we can see a few paintings of people.

<!-- image -->

Nattuvanar Subbarayan, their father, who was a court musician of Tulaja, was a great master of music and dance. Due to their innovation and artistic changes in Bharata Natyam dance, the four brothers became famous and came to be known as the Tanjore Quartet accross history.

<!-- image -->

## MOGHUL

Bharata Natyam dance experienced a major setback with the invasion of the Moghul sultanate in Tamil Nadu. The Muslim dominance caused a disorder in the Tamil region. Hinduism alongside Indian arts was under stress in the south as well as in the north. The dance of the Devadasis , known as 'Dasiattam',  ' dasi' means  servants  and  ' attam' means  dance  at  that  time, entered  the  courts  as  the  Sultans  were  also  great  patrons  of  arts. At  that moment, with the Muslims in power, some modifications in  the  dance  form were unavoidable.

<!-- image -->

<!-- image -->

Consequently,  terms  from  Muslim  usage  like 'Salami' and 'Tillana' were added to Dasiattam . Both these terms were adaptations of Persian words. In the Abhinaya or expression segment, love songs took the place of spiritual songs and more importance was being put on pure dance. Devadasis , who were once considered as highly valued members of the society, were falling into disrepute by the last half  of  the  19 th   century.  Consequently,  the dance  of  the Devadasis lost  its  devotional value and the public started to view them as women of low virtue.

Moghul King

In this image we can see a person wearing a green color dress and a white color hat. In the background there is a wall.

<!-- image -->

## BRITISH

Under the British  rule,  all  Indian  arts  suffered  a  big  setback. Temples  were looted and destroyed. The Royal patronage of musicians and dancers were stopped. Political instability and changes in the social and cultural values were the  main  reasons  for  the  drastic  decrease  in  the  status  of  the Devadasis . Bharata Natyam was no more considered as a respectful dance. At that time, everything from the West was being more appreciated and adopted than the native arts which were being ignored and deplored.

Devadasis had no other option but to earn their living outside the temples to satisfy their basic needs. They started to perform in courts and for wealthy families during weddings and other functions as a form of entertainment. At  this  juncture,  Bharata  Natyam  was  considered  only  as  a means  of  entertainment  for  rich  people  and  lost  its  religious  and  spiritual essence. Somehow, the religious sanctity of the dance was lost. Devadasis and their dance were regarded as crude, archaic and vulgar. Along with the Devadasis, Bharata Natyam was also stigmatised as cheap and low.

The British misunderstood the role of the Devadasis and started to see the art as a public disgrace. Even the terms Sadirattam and Dasiattam, used at that time for Bharata Natyam obtained harsh criticism.

<!-- image -->

<!-- image -->

Social reformers, influenced by the Western culture, launched an anti-nautch campaign to refrain not only the Devadasis from performing but also ban the art form from the temple.

Bills prohibiting the activities of the Devadasis were passed with the support of the British Government.

Bharata Natyam thus suffered a decline as these temple dancers formed the main repositories of its techniques and styles.

## REHABILITATION AND PROPAGATION

The early decade of the 20 th  century was the revival of the Indian arts due to a few historic incidents  and  the  work  of  a  few  dedicated pioneers.  During  a  period  between  political and cultural turmoil, Bharata Natyam expanded out of the walls of the Hindu temples to the stage.

This could be achievable not only due to the hard work of Indian artists like E. Krishna Iyer but a few westerners as well.

In this image we can see a woman standing. In the background there is a pillar and a wall.

<!-- image -->

While the British colonial government enforced laws  to  suppress  Bharata  Natyam  and  other Indian arts, some westerners, like the American dancer Esther Sherman, moved to India in 1930.

She learnt Indian classical dances and changed her name to Ragini Devi in order to save and revive Indian classical dances.

Ragini Devi (born Esther Sherman)

<!-- image -->

In this image we can see a woman sitting on the chair.

<!-- image -->

<!-- image -->

The  Russian  ballerina, Anna  Pavlova,  suggested  to  Rukmini  Devi  to  learn Indian classical dances instead of ballet. Later, Rukmini Devi Arundale played a very important role in the revival of Bharata Natyam. Her entry raised the status of the art.

In this image we can see a woman.

<!-- image -->

Anna Pavlova

In this image we can see a person.

<!-- image -->

Shrimati Rukmini Devi Arundale

Many other famous artists like Balasaraswati, Ram Gopal, Mrinalini Sarabhai also contributed in popularising Bharata Natyam through their public performances.  Many  others  followed  the  tide  and  with  their  efforts  today Bharata Natyam is one of the most popular dance form in India and worldwide.

In this image we can see a woman dancing.

<!-- image -->

Balasaraswati

In this image we can see a woman dancing.

<!-- image -->

In this image we can see a person wearing a crown.

<!-- image -->

Ram Gopal

<!-- image -->

Mrinalini Sarabhai

<!-- image -->

## KEYWORDS

Evolution, dance-dramas, solo dance, dynasties, sculptures, temples, courts, Tanjore quartet, Moghul, British, decline, revival, pioneers.

## POINTS TO REMEMBER

- Bharata Natyam is among the oldest of the Indian classical dances.
- Bharata Natyam is based on the Natya Shastra .
- Bharata Natyam was originally presented in dance-drama form.
- Bharata Natyam had other names such as Dasiattam , Sadirattam, Chinna Melam and Bharatam .
- Great temples were built, during the Pallavas, Cholas, Nayakas and later the Pandyas rule.
- Bharata Natyam grew positively during the Pallava and Chola reign.
- Bharata Natyam was known as Sadirattam during the Maratha rule.
- The Tanjore Quartet contributed in shaping the repertoire of Bharata Natyam for a dance recital.
- Bharata Natyam suffered a setback during the Moghul and British rule.
- Bharata Natyam was revived by a few dedicated pioneers.

<!-- image -->

<!-- image -->

## ASSESSMENT

1. Fill in the blanks in the sentences given below with the appropriate words:

- a. Dance-drama in the Tanjore district and elsewhere in the South of India, is called the -----------------------------.

- b. Bharata Natyam had many other names such as -----------------,

-------------------- and ----------------------.

- c. During the Maratha rule the dance of the Devadasis came to be known as ---------------------

- d. The Chidambaram temple is dedicated to Lord-------------------.

- e. The four Pillai brothers were known as the ---------- -----------

-------------- --------------.

- f. The two pioneers namely;----------------- and ---------------- contributed a lot in the revival of Bharata Natyam.

2. Write about the origin, growth, decline and revival of Bharata Natyam.

3. Write about the reasons that caused the decline of Bharata Natyam

<!-- image -->

In this image we can see a collage of different items.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

-  Describe the costumes of Bharata Natyam.
-  List the jewelleries of Bharata Natyam.
-  Describe the Ghungroos used for Bharata Natyam.
-  List the accessories for Bharata Natyam make-up.
-  Describe the procedure of applying make-up for Bharata Natyam.
-  Describe the hairstyle for Bharata Natyam.

<!-- image -->

## AHARYA ABHINAYA FOR BHARATA NATYAM

Aharya Abhinaya , as derived from the Sanskrit text Natya Shastra , is the art of expression  through  costume,  make-up  and  jewellery.  Each  classical  dance form of India has distinctive Aharya Abhinaya which depends on the region and style of dancing.

The Bharata Natyam dancer is aesthetically very pleasing to the eyes with  its  elaborate  make-up,  colourful costume and ornaments.

## COSTUME

RECAP

<!-- image -->

Bharata  Natyam  costume  has  always been an integral part of the dance since its origin. Ancient sculptures portrayed dancers with a piece of cloth worn like an  ' Odhni '  as  upper  garment  and  a loosely draped Dhoti style costume as lower garment.

Later the costume was stitched into a blouse  and  the Saree was  draped passing through between the legs with the  end  tucked  at  the  back  at  waist level  as  often  seen  in  Tamil  Nadu.

The traditional costume of the Devadasis was a tight blouse or Choli and  gold  embroidered Saree .  A silk cloth of about eight metres with bright colours and broad contrasting borders was  usually used.  The Saree was pleated in front and the long end was draped over the left shoulder and tucked  on  the  waist.  The  S aree was also worn by the Devadasis as  it  was convenient for the ageing artistes.

<!-- image -->

Bharata Natyam involves 4 types of Abhinaya :

1. Angika Abhinaya: expression through body movements
2. Vachika Abhinaya: expression through speech or language
3. Aharya Abhinaya: expression through costume, make-up and jewellery
4. Satvika Abhinaya: expressing inner emotions.

In this image we can see a stone carving.

<!-- image -->

<!-- image -->

Nowadays, the costume that is most in fashion  is  the  stitched  pleated  one which  evolved  during  the  1930's.  The  costume  consists  of  a  pyjama  with attached fan-like pleats from the waist to knee or mid calf length. This type of costume allows the dancer to move freely.

In this image we can see a person dancing.

<!-- image -->

In this image we can see two women standing and holding some objects. In the background we can see a house.

<!-- image -->

Over the years, Bharata Natyam costumes have evolved to become something quite distinctive. The costume worn today still resembles a Saree but is actually a unique amalgamation of separate stitched pieces of cloth.

There are two types of Bharata Natyam costumes which are currently worn by women namely:

## 1. Skirt ( Saree ) style

## 2. Pyjama or Dhoti style

In this image I can see a woman standing and dancing. I can see the black background.

<!-- image -->

In this image we can see a woman dancing.

<!-- image -->

<!-- image -->

<!-- image -->

The main feature of both types remains the pleats in the middle which opens up beautifully like a hand fan when executing the Araimandi (half-sitting) and the Muzhumandi (full-sitting) dance postures.

The costumes consist of a ' Choli ',  a  short  and  tight  blouse  with  a  piece  of pleated  cloth  covering  the  chest.  The  trouser  ( Pyjama or Dhoti )  has  a pleated fan attached in front and a semi-circular waist-band worn on top of the Pyjamas . Fan-like pleats are worn in front, on top of the long pleat on the waistband.

The  costumes  for  men  are  simpler, usually a Dhoti with  pleats  in  the  middle  covering  the lower  part  of  the  body  with  no  upper  garment except  for  a  long  piece  of  cloth  ( angavastram ) covering the chest.

## JEWELLERY

In this image we can see a person standing and dancing.

<!-- image -->

<!-- image -->

Bharata Natyam dancers wear a unique set of jewellery known as 'Temple  jewellery',  adorning  the  head,  nose,  ear,  neck,  and  arms  while performing. The hair is neatly plaited and beautified with flowers. The waist of the dancer is adorned by a belt while musical anklets, called Ghungroo, with small metallic bells are tied around the ankles.

## List of jewellery used in Bharata Natyam

## Talai-saman

Head ornament which covers the central parting of the head and the two sides of the hairline above the forehead.

<!-- image -->

## Surya and Chandra

Head  ornaments Surya (sun)  on  the right  side  and Chandra (moon)  on  the left side.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Chutti Small ornament that covers the central parting of the head.   |
|----------------------------------------------------------------------|
| Rakodi A round ornament worn on the hair bun.                        |
| Jhumki Earrings                                                      |
| Mattal Small ornaments hanging from the earrings.                    |
| Kasu Malai and Muttu Malai Long chain                                |
| Attikai Short necklace                                               |

<!-- image -->

<!-- image -->

## Odiyanam

Waist Belt

## Valaiyal

A pair of bangles

## Mukuti

A set of nose rings consisting of 3 kinds: a small clip for the right nostril, a ring decorated with jewels for the left nostril and a pendant that is fixed on the lower part of the nasal septum.

## Vanki

Arm band

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## GHUNGROO

<!-- image -->

Ghungroos are also known as ' nupura '  or ' kinkini '. They are ornaments, that are worn around the ankles, which consist of tiny bells having the following characteristics  according  to Nandikeshwara ,  the  author  of  the Sanskrit text Abhinaya Darpanam :

- They should be made of bronze. (i)
- They should have a pleasant sound. (ii)
- They should have stars as their protective deities. (iii)
- It  is  also  mentioned that a dancer should bind a hundred of them or two hundred in each of her two feet with blue thread in tight knots, at a distance of one finger apart from one another. (iv)

<!-- image -->

<!-- image -->

Nowadays the ankle bells ( Ghungroos ) of Bharata Natyam as well as that of other Indian dance forms are fixed on a velvet of dark red or blue colour or on a leather pad and are usually round or bell-shaped. The number of Ghungroos for  Bharata  Natyam  are  usually  not  more  than fifty for each foot.

Before any performance the dancer always pays obeisance  to  God  and  Guru  before  tying  the Ghungroos .

<!-- image -->

<!-- image -->

## IMPORTANCE OF GHUNGROOS

The purpose of wearing Ghungroos is  to  clearly  mark  the  different  footwork executed by the dancer. They help to hear the dancer's footsteps clearly and allow a better grip on rhythm.

There should be fine synchronisation between the ankle bells of the dancer and the main accompanying percussion instruments, that is, the Mridangam and the Nattuvangam . The sound of the Ghungroos also contributes to the overall effect of the orchestra accompanying the dancer.

## MAKE-UP

<!-- image -->

Make-up  is  applied  for  both  male  and female Bharata Natyam dancers to accentuate  and  make  the  expressions more visible from far.

In this image we can see a woman. She is wearing a necklace, earrings, and a headpiece.

<!-- image -->

<!-- image -->

<!-- image -->

## ACCESSORIES FOR BHARATA NATYAM MAKE-UP

Pancake

## Sponge

Powder

<!-- image -->

Blush

<!-- image -->

Eyeliner

<!-- image -->

Nail Polish

<!-- image -->

<!-- image -->

Lipstick

<!-- image -->

Mascara

Forehead dot (Tikka)

<!-- image -->

<!-- image -->

<!-- image -->

Eyebrow Pencil

<!-- image -->

<!-- image -->

Eye Shadows

<!-- image -->

Red liquid Colour (Alta)

<!-- image -->

<!-- image -->

## PROCEDURE

<!-- image -->

The face is first washed with soap and water then dried with a clean towel. A moisturiser  can  be  applied  for  those  with  dry  skin. The  foundation  or  base, appropriate to the complexion of the dancer, is then applied on the face, neck and ears. The base should be blended evenly on the skin with the help of a sponge.

In this image we can see a person holding a pink object.

<!-- image -->

In this image, we can see a poster with some text and a logo.

<!-- image -->

Loose  powder  is  then  applied  on  the  face  with  a  puff.  Here  also  it  must match the complexion of the dancer. The powder should be allowed to set for a few minutes. Then, the excess powder is rubbed off gently with a brush to give a smooth finish.

In this image we can see a person holding a makeup brush.

<!-- image -->

<!-- image -->

<!-- image -->

The blush is then applied on the cheekbones; this gives a glow to the cheeks and imparts a bright colour to the face.

In this image we can see a person's face.

<!-- image -->

After the blush, the eye make-up is done. Firstly, the eyebrow pencil is applied to thicken and darken the eyebrows. It is made into a natural arch and is curved at the end.

In this image we can see a person's face and a pencil is on the face.

<!-- image -->

The eyeliner is then applied next to the lash line to give the eyes a darker appearance.

In this image we can see a person's face. In the image we can see a person's hand holding a brush.

<!-- image -->

<!-- image -->

<!-- image -->

The mascara is applied to the eyelashes with a lash comb.

In this image we can see a person's face.

<!-- image -->

Eye shadows are also applied on the eyelids.

In this image we can see a person's face.

<!-- image -->

After the eye make-up, lipstick is applied on the beautifully drawn lip contours.

In this image we can see a person's lips and a lipstick.

<!-- image -->

<!-- image -->

<!-- image -->

Lastly, the ' Tikka '(forehead dot) is applied which is underlined by a white line and a small dot.

In this image we can see a person's face.

<!-- image -->

Red colour ( Alta ) is applied with a paint brush decoratively on the palm of the hands, tips of the fingers and the feet to highlight movements.

The image is a collage of two photos. The top half of the image shows a person wearing red and gold traditional attire, including a red and gold bangles and a red and gold necklace. The bottom half of the image shows a person wearing red and gold traditional attire, including a red and gold bangles and a red and gold necklace. Both people are standing and have their hands spread out. The background of the top half of the image is white, while the background of the bottom half of the image is a light blue.

<!-- image -->

## Procedure to remove make-up

In order to remove the make-up, a good liquid make-up remover or make-up remover wipes should be used.

For liquid make-up remover, use a soft cotton ball to rub off gently the make-up. Use a new cotton ball each time and repeat until the face and the neck area is thoroughly  cleaned.  After  having  removed  all  traces  of  make-up,  use  a moisturiser or tonic on the face.

Use  make-up  remover  wipes  by  rubbing  gently  all  over  the  face  and  neck areas. Use a new wipe each time until all traces of make-up are removed.

<!-- image -->

<!-- image -->

## Accessories:

- Hair pins
- False hair (for plait and bun)
- Kunjalam (for the tip of the plait)
- Flowers (white &amp; orange)
- Rakodi (ornament to be placed on the bun)

<!-- image -->

In this image we can see a person wearing a white and black color dress and holding a white color object.

<!-- image -->

A bun is made (using false hair where necessary) at the top central part of the back of the head and well stuck in with hairpins. A long plait (using false hair where necessary) is made with the Kunjalam tied at its end. The Kunjalam is of black colour with silken strands. The bun is adorned with white and orange flowers. The plait may also be decorated with flowers. The Rakodi is tucked in on the bun.

Sometimes the end of the long plait is tucked at the  back  of  the  waist  belt  to  prevent  it  from dangling around which can disturb the movements of the dancer.

<!-- image -->

<!-- image -->

ACTIVITY

In groups or in pairs find different hand gestures that can be used to depict different jewelleries.

Example: wearing of earrings Katakamukha gesture

<!-- image -->

<!-- image -->

## KEYWORDS

Costume, make-up, jewellery, enhance.

## Links

<!-- image -->

https://www.youtube.com/watch?v=3TuUoWkZ2VI https://www.youtube.com/watch?v=zERIzCzql80

## POINTS TO REMEMBER

- Aharya Abhinaya is the art of expression through the use of costume, make-up and jewellery
- The traditional costume of Bharata Natyam was a Saree of about eight metres.
- The main feature of Bharata Natyam costume for both men and women is the pyjama or skirt with pleated fan attached to them in front.
- Bharata Natyam dancers wear a set of jewellery called the 'Temple jewellery'.
- Bharata Natyam dancers apply make-up in order to enhance the facial expressions.
- In Bharata Natyam, the hair is decorated with white and orange flowers.
- The dancer's hands and feet are highlighted with red colour ( alta ).
- The Ghungroos (ankle bells) are crucial for the dancers as they make rhythmic footwork more perceptible to the audience.

<!-- image -->

<!-- image -->

<!-- image -->

1. What is the importance of Aharya Abhinaya in Indian classical dance?

2. Describe the costumes of Bharata Natyam for both male and female dancer.

3. Describe the procedure of applying make-up for a Bharata Natyam dancer.

<!-- image -->

<!-- image -->

In this image I can see a paper with some lines on it.

<!-- image -->

<!-- image -->

In this image, we can see musical instruments.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Identify the musical instruments.
-  Name the musical instruments.
-  Describe the musical instruments.

<!-- image -->

## MUSICAL INSTRUMENTS FOR BHARATA NATYAM

<!-- image -->

In this image we can see a wooden object.

<!-- image -->

Mridangam is an ancient double-headed drum.

It  was  originally  made  of  clay  and  that  is  why  the  meaning  of  the  word Mridangam is the clay body, ( mrid meaning clay and angam meaning body). Mridangam is  one of the main instruments used in South Indian or Carnatic music.

The  construction  of  the  Mridangam  is  quite  fascinating.  It  consists  of  a barrel-shaped shell usually carved out of single piece of jackfruit wood or redwood.

In this image we can see a tree with fruits.

<!-- image -->

Jack fruit tree

<!-- image -->

The two heads of the instrument are covered either with goat skin or calf hide. The heads are connected to each other with the help of leather  lacing  which  is  tightened  enough  to produce resonance.

The left head ( Thoppi ) contains a temporary paste made from a mixture of semolina and water and it is larger in size. This paste has to be removed after each use so as to protect the instrument from insects.

The  smaller  head  contains  a  permanent black spot which is a mixture of boiled rice, manganese and iron filings and is responsible for producing the various harmonics.

The  pitch  of  the Mridangam varies  with  its size.  Larger  ones  produce  a  bass  sound whereas smaller ones generate a high frequency sound. Also a Mridangam contains only one resonator which helps in matching the sound between both the heads.

The Mridangam player  sits  on  the  floor  and keeps the Mridangam on  the  right  foot  and ankle  and  is  cushioned  with  the  help  of  a wrapped cloth, since it is heavy.

Normally the length of a Mridangam is 22-23 inches but there is a specific type of Mridangam known as Maha-Mridangam which is 26 inches in length.

The  tuning  of  the Mridangam is  performed with the help of a pitch pipe, a small wooden stick ( Pallu ) and a small stone called ( Kalu ).

Mridangam playing

<!-- image -->

<!-- image -->

In this image we can see a person's hands and a drum.

<!-- image -->

In this image we can see a person playing a musical instrument.

<!-- image -->

In this image we can see a person is standing and holding a drum.

<!-- image -->

<!-- image -->

Notable Mridangam Players

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

The Veena is  a  string instrument used in South Indian Carnatic music. It consists of a large body hollowed out of a  block  of  wood.  The  stem  of  the instrument  is  usually  made  of  wood from the Jackfruit tree.

The bridge is placed on the flat top of the  body  of  the Veena and  the  neck which is attached to the stem is usually carved into a dragon figure.

In this image we can see a sculpture.

<!-- image -->

A  gourd, which  is smaller than  the rounded part of the body of the Veena , is  fixed  underneath  the  neck.  Metallic frets are fixed on the stem by means of a resinous substance.

<!-- image -->

In this image we can see a wooden object.

<!-- image -->

- T. K. Murthy
- Umayalpuram K. Sivaraman
- T. V. Gopalakrishnan
- T. S. Nandakumar

<!-- image -->

The Veena has seven strings of which four are  main  strings  that  pass  over  the  frets and are attached to the pegs of the neck. The other strings are used as side strings for rhythmic accompaniment. These strings pass over an arched bridge made of brass. They lie flat over the top of the body and are secured to the main bridge.

Veena

<!-- image -->

The Veena is  played  by  sitting  cross-legged  upon  the  floor  and  holding  the instrument in front. The small gourd on the left rests on the left thigh. The left arm passes under the stem so that the fingers rest easily upon the frets. The main body of the instrument is placed on the ground and is partially supported by the right thigh.

In this image we can see a woman sitting on the floor and playing a musical instrument.

<!-- image -->

There are different varieties of Veena . Some of them are Mahanataka Veena , Saraswati Veena , Rudra Veena .

Notable Veena Players

- Muthuswami Dikshitar
- Veenai Dhanammal
- Sriram Parthasarathy
- V. Raghavan

<!-- image -->

<!-- image -->

## SOUTH INDIAN FLUTES (Venu)

<!-- image -->

<!-- image -->

The Venu is  a  transverse  flute  made  entirely  of  bamboo  and  is  one  of  the oldest  instruments  of  India.  The Venu is  also  known  as  the  Carnatic  flute. It is a wind instrument.

This flute has one open end where the sound comes out and a knotted closed end at the other. The blow hole is set down from the closed end and followed by eight or nine finger holes that are placed closely together. Both ends of the Venu are bound near the opening and closing with various materials such as decorative tape. The tape is used to prevent the ends of the instrument from splitting or being altered by temperature.

The Venu player typically plays while seated on the floor or on a cushion with the legs crossed, back straight and the head held high. This posture allows the player  to  take  in  air  while  maintaining  control  over  the  flow  of  air  into  the instrument. The flute is held horizontally from the mouth of the player with the open end tilted slightly toward the ground with both hands used to cover the sound holes.

Kudamaloor Janardanan

In this image we can see a person sitting on the chair and playing a musical instrument. There are some objects on the floor.

<!-- image -->

The size of the flute determines the specific tones it is able to produce. The sound of the Venu depends on the length of the instruments.

<!-- image -->

Notable Venu Players

- G. S. Rajan
- K. Bhaskaran
- B. Shankar Rao
- Kudamaloor Janardanan

Nattuvangam

<!-- image -->

In this image we can see some objects.

<!-- image -->

The Nattuvangam is a pair of cymbals consisting of two round metal plates held in both hands. The person who plays it is called the Nattuvannar .

Nattuvangam has two metal pieces; the one held in the right hand is made up of brass and the one held in the left hand is made up of iron. A thick thread made of cotton is tied to the two metals separately.

The Nattuvangam reproduces the alternate hard and soft beats of the dancer's feet by striking the metal piece held in the right hand on the metal piece held in the left hand.

In this image we can see a person holding a knife and a rope.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The Nattuvanar plays an important role  in  a  Bharata  Natyam  dance performance. The Nattuvangam keeps the rhythm and enhances the intricate footwork of the dancer.

In  ancient  days,  the Nattuvangam was  made  out  of Panchaloham ( Pancha means five and Loham means metal). The Nattuvanars believe that a heavier one maintains a steady tempo. Traditionally Nattuvanars were the teacher or Guru  of  Bharata  Natyam  and  they  were  well  versed  in  dance,  music  and choreography. In this traditional approach, the Nattuvanar was considered the conductor of the entire dance programme.

## NOTABLE MUSICIANS

- G. S. Rajan
- K. Bhaskaran
- K. S. Gopalakrishnan
- Kudamaloor Janardanan
- Raghavendran Rajasekaran

<!-- image -->

The Violin  is  a  wooden  string  instrument. The Violin typically has four strings and is most commonly played by drawing a bow across its strings.

Violins are important instruments in a wide variety  of  musical  genres.  They  are  most prominent in the Western classical tradition and in many varieties of folk music.

Furthermore,  the  violin  has  come  to  be played in many non-Western music cultures, including Indian music and Iranian music.

In this image we can see a violin.

<!-- image -->

<!-- image -->

Most Popular Venu Players Today

Violin

<!-- image -->

The violin  is  sometimes  informally  called  a  fiddle,  regardless  of  the  type  of music played on it. The parts of a violin are usually made from different types of wood,  although  electric violins may  not  be  made  of  wood  at  all.

Their  sound  is  not  dependent  on specific  acoustic  characteristics  of the instrument's construction.

In the western classical tradition, the violin is supported between the chin and shoulder.

In the Indian classical tradition, music  is  almost  always  performed sitting cross-legged on the floor.

The  violin  is  held  by  the  performer with the chin resting on the chin-rest and  the  neck  held  on  the  left  foot.

Western style of playing Violin

<!-- image -->

Indian style of playing Violin

In this image we can see a person sitting and playing a musical instrument.

<!-- image -->

Notable Violin Players in India

- T. N. Krishnan
- A. Kanyakumari
- H. K. Venkatram
- Jyotsna Srikanth
- L. Subramaniam

## DID YOU KNOW?

A person who makes or repairs Violins is called a Luthier.

<!-- image -->

<!-- image -->

## SHRUTI BOX (wind instruments)

Shruti Box

<!-- image -->

In this image we can see a wooden box with different colors and designs. On the left side of the image we can see a person's hand holding a box.

<!-- image -->

A Shruti box or Surpeti is a wind instrument. It is used to provide a drone in a practice session or concert of Indian classical music. Adjustable buttons allow tuning.

Nowadays, electronic Shruti Boxes are commonly used.

Electronic Shruti Box

<!-- image -->

## According to Sangeetam, Vadyam is classified as follows:

- (i) Tata Vadya

-  String instruments (Chordophones)

- (ii) Sushira Vadya

-  Wind instruements (Aerophones)

- (iii) Avnadha Vadya

- Instruments having a surface covered

with a membrane (Membranophones)

- (iv) Ghana Vadya

-  Solid Instruments (Idiophones)

<!-- image -->

RECAP

<!-- image -->

## KEYWORDS

Percussion instruments, accompaniment, stringed instrument, wind instrument.

## Links

<!-- image -->

https://www.youtube.com/watch?v=dwFdBztKJiM https://www.youtube.com/watch?v=sFLh4uYxbe0

## POINTS TO REMEMBER

- Mridangam is the main percussion instrument of Bharata Natyam.
- Mridangam is an ancient double-headed drum.
- Veena is a stringed instrument used in Carnatic music.
- The flute of Carnatic music is known as the Venu .
- The Nattuvangam is the main accompanying instrument of Bharata Natyam.
- The Violin is a stringed instrument used  in the accompaniment of Bharata Natyam.
- The Shruti Box provides the drone.

<!-- image -->

<!-- image -->

## ASSESSMENT ASSESSMENT

1. Identify the names of the following instruments:

<!-- image -->

......................................

......................................

......................................

......................................

2. Describe the following instruments used for the accompaniment of Bharata Natyam:

Mridangam

<!-- image -->

<!-- image -->

## ASSESSMENT

Veena

Nattuvangam

3. Classify the following instruments according to their respective categories:

Venu

Mridangam

Veena

Violin

Nattuvangam

Shruti Box

<!-- image -->

<!-- image -->

In this image I can see a paper with some text on it.

<!-- image -->

<!-- image -->

In this image we can see a collage of images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Name the exponents of Bharata Natyam.
-  Write about the contributions of the exponents to the art of Bharata Natyam.
-  Develop respect and gratitude towards the exponents who contributed to the upliftment and propagation of Bharata Natyam.
-  Get inspired through the work and contributions of the exponents.

<!-- image -->

## EXPONENTS

Exponents of Bharata Natyam are persons who have helped and supported the propagation and preservation of this dance form in India and abroad. Some of the famed exponents in Bharata Natyam are: Balasaraswati, Ram Gopal, and Mrinalini Sarabhai.

They will always be remembered as great dancers who brought to the notice of the world the classical grandeur and beauty of Bharata Natyam. They have contributed  immensely  in  popularising  Bharata  Natyam  with  their  superb performances, thus, helping in the preservation of the classical dance form. They  have  even  received  several  honours  in  India  and  abroad  for  their outstanding contribution to Indian classical dance.

## Balasaraswati

<!-- image -->

In this image we can see a person.

<!-- image -->

In this image we can see a woman smiling. She is wearing a gold color saree. She is wearing a necklace and earrings. She is wearing a flower.

<!-- image -->

Balasaraswati  was  a  seventh  generation  representative  of  a  traditional matrilineal family of temple musicians and dancers (Devadasis). She belonged to a family of renowned musicians and dancers.

She learnt Bharata Natyam from early childhood from Kandappa who was the descendant of the famous Tanjore Quartet. Balasaraswati did her Arangetram in Amanakshi Amman  temple  at  Kanchipuram  in  1925  when  she  was  only seven years old.

<!-- image -->

In one of the leading news magazine of India she was  classified  as  one  of  the  hundred  prominent Indians who shaped the destiny of India.

Balasaraswati was not only known as the Queen of Abhinaya (expression) in Bharata Natyam but was also a great singer.

She was honoured with Sangeet Natak Akademi Award in  India  and  also  abroad  for  her unmatched  performances,  especially  in  Padams (Nritya dance compositions).

Balasaraswati performed in the Edinburgh festival and for the East West Encounter at Tokyo.

Balasaraswati established a dance school to train young  aspirants  in  the  purest  form  of  Bharata Natyam.  She  drew  innumerable  students  across India, who  affectionately called her Balamma . Since  1962  she  has  also  been  performing  and teaching in the USA.

Balasaraswati was  born  on  the 13 th   of  May  1918 and died on the 9 th of February 1984.

In this image we can see a poster with some text and images.

<!-- image -->

She passed away on February 9, 1984 in Madras.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Awards and Accolades of Balasaraswati

|   1955 | The President's Award from the Sangeet Natak Akademi                                                           |
|--------|----------------------------------------------------------------------------------------------------------------|
|   1957 | Padma Bhushan Award                                                                                            |
|   1973 | Sangita Kalanidhi from the Madras Music Academy (South India's highest award for musicians)                    |
|   1977 | Padma Vibhushan from the Government of India for distinguished national service                                |
|   1977 | The New York Times critic Anna Kisselgoff described her as one of the Supreme performing artists in the world. |
|   1981 | The Sangeetha Kalasikhamani award from the Indian Fine Arts Society, Chennai.                                  |

## Ram Gopal

<!-- image -->

Ram  Gopal  is  one  of  the  most  popular exponents  of  the  Indian  classical  dances. His mother was Burmese by origin and his father  was  a  barrister.  Despite  parental opposition, he took up dance as a profession.  He  was  motivated  and  was patronized by the prince of Mysore and by the end of his teenage years, Ram Gopal was already the most adored dancer in the region.

In this image we can see a person.

<!-- image -->

Ram Gopal was noticed by an American dancer, La Meri, who made him her dance  partner  in  1936.  He  accompanied  her  for  world  tours.  He  was  a modernist who used to blend Indian classical dance with balletic choreography and was among the first to showcase Indian classical dance in the west.

He started learning Bharata Natyam in the early 40s under Guru Meenakshi Sundaram Pillai of Pandanallur style followed by Muthukumaran Pillai. He was taught Bharata Natyam items which were suited for male dancers.

<!-- image -->

<!-- image -->

He also learnt Kathak , Manipuri , and Kathakali dances. He is famous for his suppleness and vigour in Nritta items.

Ram Gopal took elements from each of these dance forms and created his own unique style, which became extremely popular in the west as 'Oriental dance'. Ram Gopal started an academy in Bangalore where even Mrinalini Sarabhai took training. He gave several dance recitals in international dance festivals and achieved success wherever he performed.

In this image, we can see a logo and text.

<!-- image -->

<!-- image -->

He settled down in London and, in 1962, established the Academy of Indian classical dances.

Ram Gopal was  born  on  the 20 th   of  November 1917  and  died  on the 12 th  of October 2003.

He became the most popular Indian dancer in the west. From London to New York and Hollywood to Japan, Ram Gopal was among the exponents who put India on the world dance map. Ram Gopal wrote a book entitled  'Rhythm  in  Heavens'  which  was  based  upon  his  own  life. A  French director, Madame Claud La Morris, made two documentaries on Ram Gopal. He received the Sangeet Akademi Award and several honours around the world.

## Film on Ram Gopal by a French film Director

1970

Aum Shiva

1973

Nataraj: King of Dance

Awards of Ram Gopal

1984

Sangeet Natak Akademi

1990

Ratna Sadasya award

1999

Queen Elizabeth awarded Order of British Empire

<!-- image -->

<!-- image -->

## Mrinalini Sarabhai

<!-- image -->

Mrinalini  Sarabhai  was  an  Indian  classical dancer, choreographer and instructor. She was born in Kerala in the year 1918. Her father  S.  Swaminathan  was  a  lawyer  who practised criminal law at Madras High Court, and mother A. V. Ammukutty, a social worker and  activist. She  spent  her  childhood  in Switzerland, where she learnt her first dance movements in Dalcroz.

In this image we can see a woman standing and she is wearing a saree.

<!-- image -->

Mrinalini Sarabhai began her training in Bharata Natyam under the guidance of Guru Muthukumar Pillai and learnt Kathakali as well as Mohini Attam on her return to India. She also received training in voice culture and dramatic arts in the United States. Mrinalini Sarabhai started her professional career as  the  partner  of  Ram  Gopal.  Then,  afterwards,  she  began  to  perform as a soloist. She was the lead performer in Rabindranath  Tagore's dance-dramas at Shantiniketan.

She  was  one  of  the  first  women  to  perform  Kathakali  when  only  men used  to  play  all  characters  and  women  were  not  allowed  to  take  part  in this particular dance form.

In  1948,  she  founded  the  dance  academy called Darpana Academy of Performing Arts, an  institute  for  imparting  training  in  dance, drama,  music,  and  puppetry,  in  the  city  of Ahmedabad. She trained over 18,000 students  in  Bharata  Natyam  and  Kathakali. Bharata Natyam was propagated and appreciated in Gujarat due to Mrinalini Sarabhai.

In this image we can see a yellow color background with a white color circle in the middle.

<!-- image -->

She received many awards and citations in recognition for her contribution to the art. Besides choreographing more than three hundred dance-dramas, she has also written many novels, poetry, plays and stories for children. She gave many performances with the students of her Academy, in India and abroad, which helped in projecting the image of independent India.

<!-- image -->

<!-- image -->

## Awards and Accolades of Mrinalini Sarabhai

|   1965 | Padma Shri (India's fourth highest civilian award)                                            |
|--------|-----------------------------------------------------------------------------------------------|
|   1968 | Honoured with gold medal by the Mexican Government                                            |
|   1991 | Pandit Omkarnath Thakur Award by the Gujarat Government                                       |
|   1992 | Padma Bhushan (the third highest National civilian award by the Indian Government)            |
|   1997 | Honoured with the Degree of Doctor of Letters by the University of East Anglia, Norwich, UK.  |
|   2013 | First beneficiary of the Nishagandhi Puraskaram (an annual award by the Government of Kerala) |

## KEYWORDS

Exponents, pioneer, propagation, contribution, awards.

## POINTS TO REMEMBER

- Balasaraswati, Ram Gopal and Mrinalini Sarabhai were among the main exponents of Bharata Natyam.
- These exponents have helped in popularising Bharata Natyam in India and abroad.
- Balasaraswati was known as the queen of expression in Bharata Natyam.
- Ram Gopal toured the world with the American dancer La Meri.
- Ram Gopal used to blend Indian classical dance with western ballet.

<!-- image -->

<!-- image -->

## POINTS TO REMEMBER

- Mrinalini Sarabhai was trained in Bharata Natyam, Kathakali and Mohini Attam.
- Mrinalini Sarabhai founded the Darpana Academy of Performing Arts in Ahmedabad.

## ASSESSMENT

1. Summarise the contributions of  Balasaraswati, Ram Gopal and Mrinalini Sarabhai in propagating Indian classical dances.

2. List two awards received by each of the above mentioned exponents.

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Describe Adi Tala.
-  Recognise the Angas of Adi Tala.
-  State the number of Aksharakalas in Adi Tala.
-  Demonstrate the Kriyas (actions of the hand) of Adi Tala.
-  Count Adi Tala in the three speeds.
-  Notate the Sollukattus of the Adavus in the three speeds of Adi Tala.
-  Recite and count the Sollukattus of the Adavus in the three speeds of Adi Tala .

<!-- image -->

## Notation Form

- Adi Tala is the most common Tala used in Carnatic music.
- The symbol of Adi Tala is; I 4 00
- There are 8 Aksharakalas in one Avartana of Adi Tala .
- Another name for Adi Tala is Chaturasra Jati Triputa Tala .
- Kriyas of Adi tala

<!-- image -->

<!-- image -->

1

<!-- image -->

5

2

<!-- image -->

6

<!-- image -->

3

<!-- image -->

7

<!-- image -->

<!-- image -->

4

<!-- image -->

8

RECAP

<!-- image -->

| 0       | 8            | __         | Tam __     | Dhit Tai Tam __   |
|---------|--------------|------------|------------|-------------------|
|         | 7            | Tam        | Dhit Tai   | Tat Tai Tam __    |
| 0       | 6            | Tai        | Tam __     | Dhit Tai Tam __   |
|         | 5            | Dhit       | Tat Tai    | Tat Tai Tam __    |
|         | 4            | __         | Tam __     | Dhit Tai Tam __   |
| 4       | 3            | Tam        | Dhit Tai   | Tat Tai Tam __    |
| 1       | 2            | Tai        | Tam __     | Dhit Tai Tam __   |
|         | 1            | Tat        | Tat Tai    | Tat Tai Tam __    |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed | 3 rd Speed        |

|         | 8            | Ha         | Ta Ha      | Dhit Tai Ta Ha   |
|---------|--------------|------------|------------|------------------|
|         | 7            | Ta         | Dhit Tai   | Tat Tai Ta Ha    |
| 0       | 6            | Tai        | Ta Ha      | Dhit Tai Ta Ha   |
|         | 5            | Dhit       | Tat Tai    | Tat Tai Ta Ha    |
|         | 4            | Ha         | Ta Ha      | Dhit Tai Ta Ha   |
|         | 3            | Ta         | Dhit Tai   | Tat Tai Ta Ha    |
|         | 2            | Tai        | Ta Ha      | Dhit Tai Ta Ha   |
| Symbols | 1            | Tat        | Tat Tai    | Tat Tai Ta Ha    |
|         | Aksharakalas | 1 st Speed | 2 nd Speed | 3 rd Speed       |

<!-- image -->

<!-- image -->

|         |              |                   | Tai                                        | Tai Tai                                                |
|---------|--------------|-------------------|--------------------------------------------|--------------------------------------------------------|
|         | 8            | Tai               | Ta                                         | Tenda Ta Tenda Ta                                      |
|         |              | Ta                | Tenda                                      |                                                        |
| 0       |              |                   | Ta Tai                                     | Ta Tai                                                 |
|         | 7            | Tenda             | Tenda                                      | Tenda Dhit Tenda Ta Tai                                |
| 0       |              | Dhit              | Dhit                                       | Dhit                                                   |
| 1 4     |              |                   | Tai                                        |                                                        |
|         |              | Tai               | Ta                                         | Ta Tai Ta Tai                                          |
|         |              |                   | Dhit Tenda                                 | Dhit Tenda Dhit Tenda                                  |
|         | 1            |                   |                                            |                                                        |
|         | 6            | Ta                | Tai                                        |                                                        |
|         |              |                   |                                            | Tai Tai                                                |
|         | 5            | Tenda             | Tenda Ta                                   | Tenda Ta Tenda Ta                                      |
|         |              | Dhit              | Dhit                                       |                                                        |
|         |              |                   |                                            | Dhit                                                   |
|         | 4            | Ta Tai            | Tai                                        |                                                        |
|         |              |                   | Dhit Tenda Ta                              | Ta Tai Ta Tai Dhit                                     |
|         |              | Dhit Tenda        |                                            | Dhit Tenda Ta Tai Ta Tai Dhit Tenda Dhit Tenda         |
|         | 2 3          | Speed Dhit Ta Tai | Ta Tai Dhit Tenda Ta Tai Dhit Tenda Ta Tai | Tai Tai Dhit Tenda Dhit Tenda Ta Tai Dhit Tenda Ta Tai |
|         |              | Tenda             | Dhit Tenda                                 | Dhit Tenda Ta Dhit Tenda Ta                            |
|         |              |                   | Speed                                      | Speed                                                  |
|         | Aksharakalas |                   |                                            |                                                        |
|         |              |                   | nd                                         |                                                        |
|         |              |                   | 2                                          |                                                        |
| Symbols |              | st                |                                            |                                                        |
|         | 3 rd         | 3 rd              | 3 rd                                       | 3 rd                                                   |
|         | 1            |                   |                                            |                                                        |

| 0       | 8            | __         | Tom __     | Gi Na Tom __   |
|---------|--------------|------------|------------|----------------|
|         | 7            | Tom        | Gi Na      | Gi Na Tom __   |
|         | 6            | Na         | Tom __     | Gi Na Tom __   |
|         | 5            | Gi         | Gi Na      | Gi Na Tom __   |
|         | 4            | __         | Tom __     | Gi Na Tom __   |
|         | 3            | Tom        | Gi Na      | Gi Na Tom __   |
|         | 2            | Na         | Tom __     | Gi Na Tom __   |
|         | 1            | Gi         | Gi Na      | Gi Na Tom __   |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed | 3 rd Speed     |

<!-- image -->

<!-- image -->

| 0       | 8            | __         | Tom __     | Tadi Gina Tom __   |
|---------|--------------|------------|------------|--------------------|
|         | 7            | Tom        | Tadi Gina  | Tadi Gina Tom __   |
|         | 6            | Gina       | Tom __     | Tadi Gina Tom __   |
|         | 5            | Tadi       | Tadi Gina  | Tadi Gina Tom __   |
|         | 4            | __         | Tom __     | Tadi Gina Tom __   |
|         | 3            | Tom        | Tadi Gina  | Tadi Gina Tom __   |
|         | 2            | Gina       | Tom __     | Tadi Gina Tom __   |
|         | 1            | Tadi       | Tadi Gina  | Tadi Gina Tom __   |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed | 3 rd Speed         |

| 0       | 8            | Tom __     | Gina Tom __   | Taka Tadi Gina Tom __   |
|---------|--------------|------------|---------------|-------------------------|
|         | 7            | Gina       | Taka Tadi     | Taka Tadi Gina Tom __   |
| 0       | 6            | Tadi       | Gina Tom __   | Taka Tadi Gina Tom __   |
|         | 5            | Taka       | Taka Tadi     | Taka Tadi Gina Tom __   |
|         | 4            | Tom __     | Gina Tom __   | Taka Tadi Gina Tom __   |
|         | 3            | Gina       | Taka Tadi     | Taka Tadi Gina Tom __   |
| 1 4     | 2            | Tadi       | Gina Tom __   | Taka Tadi Gina Tom __   |
|         | 1            | Taka       | Taka Tadi     | Taka Tadi Gina Tom __   |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed    | 3 rd Speed              |

<!-- image -->

<!-- image -->

| 0       | 8            | __         | __ __      | Tom __ __ __        |
|---------|--------------|------------|------------|---------------------|
|         | 7            | __         | Tom __     | Taka Diku Tadi Gina |
| 0       | 6            | __         | Tadi Gina  | Tom __ __ __        |
|         | 5            | Tom        | Taka Diku  | Taka Diku Tadi Gina |
|         | 4            | Gina       | __ __      | Tom __ __ __        |
|         | 3            | Tadi       | Tom __     | Taka Diku Tadi Gina |
|         | 2            | Diku       | Tadi Gina  | Tom __ __ __        |
|         | 1            | Taka       | Taka Diku  | Taka Diku Tadi Gina |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed | 3 rd Speed          |

| 0       | 8            | __         | Tom __     | Dhari Kita Tom __   |
|---------|--------------|------------|------------|---------------------|
|         | 7            | Tom        | Dhari Kita | Dhari Kita Tom __   |
|         | 6            | Kita       | Tom __     | Dhari Kita Tom __   |
|         | 5            | Dhira      | Dhari Kita | Dhari Kita Tom __   |
|         | 4            | __         | Tom __     | Dhari Kita Tom __   |
|         | 3            | Tom        | Dhari Kita | Dhari Kita Tom __   |
|         | 2            | Kita       | Tom __     | Dhari Kita Tom __   |
|         | 1            | Dhari      | Dhari Kita | Dhari Kita Tom __   |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed | 3 rd Speed          |

<!-- image -->

| 0       | 8            | __         | Tom __ __          | Kitataka Dharikita Tom __ __   |
|---------|--------------|------------|--------------------|--------------------------------|
|         | 7            | Tom __     | Kitataka Dharikita | Kitataka Dharikita Tom __ __   |
|         | 6            | Dharikita  | Tom __ __          | Kitataka Dharikita Tom __ __   |
|         | 5            | Kitataka   | Kitataka Dharikita | Kitataka Dharikita Tom __ __   |
|         | 4            | __         | Tom __ __          | Kitataka Dharikita Tom __ __   |
|         | 3            | Tom __     | Kitataka Dharikita | Kitataka Dharikita Tom __ __   |
| 1 4     | 2            | Dharikita  | Tom __ __          | Kitataka Dharikita Tom __ __   |
|         | 1            | Kitataka   | Kitataka Dharikita | Kitataka Dharikita Tom __ __   |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed         | 3 rd Speed                     |

| 0       | 8            | Tom __     | Dharikita Tom __   | Taka Kitataka Dharikita Tom __   |
|---------|--------------|------------|--------------------|----------------------------------|
| 0       | 7            | Dharikita  | Taka Kitataka      | Taka Kitataka Dharikita Tom __   |
| 0       | 6            | Kitataka   | Dharikita Tom __   | Taka Kitataka Dharikita Tom __   |
| 0       | 5            | Taka       | Taka Kitataka      | Taka Kitataka Dharikita Tom __   |
|         | 4            | Tom __     | Dharikita Tom __   | Taka Kitataka Dharikita Tom __   |
|         | 3            | Dharikita  | Taka Kitataka      | Taka Kitataka Dharikita Tom __   |
| 1 4     | 2            | Kitataka   | Dharikita Tom __   | Taka Kitataka Dharikita Tom __   |
| 1 4     | 1            | Taka       | Taka Kitataka      | Taka Kitataka Dharikita Tom __   |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed         | 3 rd Speed                       |

<!-- image -->

<!-- image -->

<!-- image -->

In this image there is a table with some text on it.

<!-- image -->

| 0       | 8            | __ __      | __ __              | Tom __ __ __ __              |
|---------|--------------|------------|--------------------|------------------------------|
| 0       | 7            | __ __      | Tom __ __          | Taka Diku Kitataka Dharikita |
| 0       | 6            | __ __      | Kitataka Dharikita | Tom __ __ __ __              |
| 0       | 5            | Tom __     | Taka Diku          | Taka Diku Kitataka Dharikita |
| 1 4     | 4            | Dharikita  | __ __              | Tom __ __ __ __              |
| 1 4     | 3            | Kitataka   | Tom __ __          | Taka Diku Kitataka Dharikita |
| 1 4     | 2            | Diku       | Kitataka Dharikita | Tom __ __ __ __              |
| 1 4     | 1            | Taka       | Taka Diku          | Taka Diku Kitataka Dharikita |
| Symbols | Aksharakalas | 1 st Speed | 2 nd Speed         | 3 rd Speed                   |

<!-- image -->

In this image we can see a diagram.

<!-- image -->

## ASSESSMENT

1. Fill in the blanks in the table given below as appropriate.

In this image, we can see some text and numbers.

<!-- image -->

| 0       | 8            | __             | __ __        | Tom __       | __ __        |
|---------|--------------|----------------|--------------|--------------|--------------|
|         | 7            | __             | Tom __       | Taka ....... | ....... Gina |
|         | 6            | __             | ....... Gina | Tom __       | __ __        |
| 0       | 5            | Tom            | Taka ....... | Taka ....... | ....... Gina |
|         | 4            | Gina           | __ __        | Tom __       | __ __        |
|         | 3            | .............. | Tom __       | Taka ....... | ....... Gina |
| 1       | 2            | .............. | ....... Gina | Tom __       | __ __        |
|         | 1            | Taka           | Taka ....... | Taka ....... | ....... Gina |
| Symbols | Aksharakalas | 1 st Speed     | 2 nd Speed   |              | 3 rd Speed   |

<!-- image -->

<!-- image -->

<!-- image -->

## ASSESSMENT

2. Write into the notation form of Adi Tala the syllables of Dhitenda Tatai Adavu in the three speeds.

3. Write into the notation form of Adi Tala the syllables Dharikita Tom in the three speeds.

<!-- image -->

In this image we can see a person standing and holding a pink color object.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Develop the basic skills of communicating through the medium of Bharata Natyam movements.
-  Communicate through the medium of Bharata Natyam movements.
-  Enact in small groups an idea or a small story in sequences of movements.
-  Develop an appreciation for non-discursive communication.

<!-- image -->

## EXPRESSION THROUGH THE MEDIUM OF BHARATA NATYAM

<!-- image -->

In Indian classical dances there is the use of vocabulary of movements and facial expression to interpret and convey any feeling or experience. The use of bodily movements  to  convey  a  message  is  known  as  non-discursive communication.  In  a  non-discursive  communication  the  dancer  interprets ideas, episodes or a whole dramatic story through the use of body movements, codified hand gestures and facial expressions.

In order to develop the basic skills of communicating through the medium of Bharata Natyam, the learner has to learn how to make independent choices in creating  movements  and  facial  expressions  within  the  scope  and  preset parameters of the dance style.

<!-- image -->

<!-- image -->

<!-- image -->

The learner has to choose appropriate dance movements from among all other possibilities so as to be able to interpret the theme given correctly. Beside the movements, the rhythmic aspect has also to be taken into consideration. All choreography  should  be  created  so  as  to  fit  in  the  structure  of  the  preset rhythm.

<!-- image -->

In this image we can see a woman standing and holding a camera.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Express through the medium of Bharata Natyam the sentences given below: Note that each student will create their own movements individually.

- I am walking in a garden and the sun is shining in the sky.
- I can see beautiful flowers with bees flying around.
- There is a pond in which colourful fishes are swimming.
- Suddenly I hear the sound of thunder and get scared.
- I look up and see dark clouds covering the blue sky.
- It starts raining and I am completely wet.
- My clothes are wet and I try to wring out the water from my dress.
- I walk back home all drenched and sad.

## Usages of some Asamyuta and Samyuta Hastas are given so as to facilitate in the creativity process.

Pataka -  Dark  clouds,  forest,  me,  night,  river,  riding  a  horse,  cutting, waves of the ocean.

Ardhapataka - tree, knife

Arala - Wind, sprinkling of water

Mushti - grasping something, showing firmness

<!-- image -->

<!-- image -->

Kapittha

## - Bird

Katakamukha - picking a flower

Suchi - Showing everywhere, showing you

Chandrakala

- Crescent moon

Sarpshirsha

- serpent

Mrigashirsha

- Deer's head

Simhamukha

- Lion's faces

Alapadma

- Flower

Brahmara

- Bee

Swastika

- crocodile

Pushpaputta

- holding flower

Shakata

- demon

Shankha

- conch

Samputta

- hiding something

Pasha

- enmity

Kilaka

- friendship

Matsya

- fish

Kurma

- tortoise

Garuda

- bird

Nagabandha

- serpent

<!-- image -->

## NOTES TO TEACHER

Demonstrate the usages of the hand gestures (Viniyogas) to the students.

## Hand gestures representing various things:

In this image we can see a flower.

<!-- image -->

In this image we can see a person's hand.

<!-- image -->

In this image we can see a flower. In the background there are flowers.

<!-- image -->

In this image we can see a person holding a red color object.

<!-- image -->

In this image we can see a bird on the branch of a tree.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a person's hand.

<!-- image -->

In this image there are two hands of a person, and there is a black background.

<!-- image -->

In this image we can see a person's hand and the background is in black color.

<!-- image -->

In this image we can see a lion.

<!-- image -->

In this image we can see a tortoise.

<!-- image -->

In this image we can see a snake.

<!-- image -->

<!-- image -->

ACTIVITY

Enact a short story in group while using the medium of Bharata Natyam

<!-- image -->

In this image, we can see a woman dancing. There is a text at the top of the image.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

-  Develop an awareness of the importance of  safe practice.
-  Follow the guidelines for practice of Bharata Natyam.
-  Adhere to a regular practice schedule.
-  Develop a positive attitude towards the practice of dance with full dedication and devotion.

<!-- image -->

## PRACTICE FOR BHARATA NATYAM

## Importance of Practice

<!-- image -->

Practice in Bharata Natyam is of utmost importance in order to develop new skills. Learners need to practise on a regular basis to acquire a certain level of competency.  Repetition  of  movements  enables  the  body  to  memorise  the patterns of movements which are then reproduced without doing much effort.

Studies indicate  that  on  average,  80%  of  everything  newly  learnt  is  quickly forgotten. If practice and memorisation are not done after having learnt new knowledge, learners may forget the majority of it. Studies have shown that with frequent practice, one can retain much more.

In  Bharata  Natyam,  practice  leads  to  better  memorisation  of  patterns  of movement, hence better quality in performance. Practice also helps the body to  develop  flexibility,  agility,  strength  and  endurance  in  dance  performance. Practising the basic dance postures and Anga Shuddham while practising the Adavus help to develop good dancing skills.

## Guidelines for practice

- Start with a few warm-up and pre-dance exercises.
- Focus on proper technique while executing the exercises.
- Revise the Shlokas of the Asamyuta and Samyuta Hastas while demonstrating the gestures.
- Recite the names and demonstrate the Shiro, Drishti and Greeva Bhedas several times so as to facilitate memorisation.

.

- Practise Adavus that have been already learnt in class in the three Kalas
- Recite the Sollukattus while practicing the steps in order to memorise them.
- Practise the Adavus you are unsure about in slow speed at first, then shift to other degrees of speed.
- Count the Sollukattus of Adavus in the three speeds of Adi Tala .
- Maintain regular interval ( Laya ) in between each count.
- Execute some cool-down exercises after the dance practice.
- Practise on a regular basis.

<!-- image -->

## Glossary of Terms

Abhaya Hasta

- the hand gesture of Lord Nataraja depicting protection, reassurance and safety.

Abhinaya

Abhinaya Darpanam

Adavu

Aharya

Alankaradasis

Alarippu

Amanakshi Aman

Anga Angika

- the expression used to convey a theme, mood or idea in Indian classical dances.
- a text on gestures used in Indian classical dances written by Nandikeshwara.
- the basic rhythmic unit of Bharata Natyam.
- the expression through costume, make-up and jewellery.
- the dancing girls who used to perform on festive occasions.
- an invocatory pure dance composition in the repertoire of Bharata Natyam.
- a Hindu temple found in Kancheepuram, T amil Nadu India.
- a constituent of the Tala.
- the expression through body movements.

Arangetram

- the first performance  of Bharata Natyam on stage.

Bhagavata Mela Nataka

- a dance-drama on Bhagavata Purana.

Bharatam Bharata Natyam

Bhava

Brahmins Brihadeeshwara

Brindavan Chidambaram

Chinna Melam Dasi Attam Devadasis

Dalcroz

Damru Danda Hasta Dasavatar

- a prior name for Bharata Natyam.
- a classical dance style from Tamil Nadu in South India.
- an emotion or mood conveyed by the performer in Indian classical dance.
- a socially or culturally superior person in Hinduism.
- a Hindu temple dedicated to Lord Shiva located in T anjavur.
- a holy town in Uttar Pradesh, northern India.
- a Hindu temple dedicated to Nataraja as the Lord of dance, located in Tamil Nadu, India.
- a prior name for Bharata Natyam.
- a prior name for Bharata Natyam.
- the temple dancers, literally translated as servants of God.
- a method to teach music and dance originated in Switzerland.
- a two-headed drum in India.
- the lower left hand gesture of Lord Nataraja.
- the ten incarnations of Lord Vishnu.

<!-- image -->

<!-- image -->

<!-- image -->

Drishti bhedas

Durbars

Gokula

Gopis

Greeva bhedas

Guru

Jatiswaram

Kailash

Kali

Kaliya

Kanchipuram

Karanas

Kathak

Kirtanam

Krishna Kuchipudi

Kuruvanji Lakshmi

Lasya Lord Nataraja Lord Vishnu

Mantra

Maratha

Moghul

Muyalaham

Muzhumandi

Mridangam

Nattuvanars

Nattuvangam

Natya Shastra

- the eye movements in Indian classical dance.
- the court of an Indian ruler.

- a village in India where Krishna spent his childhood.

- a group of cow herd girls.
- the neck movements in Indian classical dance.
- a Sanskrit term for teacher.
- a pure dance composition in the repertoire of Bharata Natyam.
- a mountain which forms part of the Himalayas.
- a Hindu Goddess.
- a hundred-headed serpent in the Hindu mythology.
- a famous temple city in the Indian state of Tamil Nadu.
- the 108 combined movements of hands and feet in Indian classical dance.
- an Indian classical dance originated in the North of India.
- an expressional dance composition in the repertoire of Bharata Natyam.
- the eighth incarnation of Lord Vishnu.
- an Indian classical dance originated in Andhra Pradesh in India
- a dance-drama from the South of India.
- the consort of Lord Vishnu who is known as the Goddess of wealth.
- the feminine aspect in Indian classical dance.
- Lord Shiva as the King of Dance.
- the Hindu God known as the Preserver in the Hindu Trinity.
- a Sanskrit term for sacred verse.
- an Indian Empire in the 18th century.
- a Muslim empire in the Indian subcontinent.
- a black demon dwarf in Hindu mythology.
- a basic dance posture where a full sitting position is taken.
- the main percussion instrument used in Bharata Natyam.
- the dance masters who accompany Bharata Natyam dancers in performances.
- a pair of cymbals used to give rhythm in Bharata Natyam
- a Sanskrit text on Performing Arts written by Bharata Muni.

<!-- image -->

## Natyarambhe

Natwar Navasandhi Nritta

Nritya

Natya

Padam

Parvati Pratyanga Rajadasis

<!-- image -->

- a basic dance posture where the arms are opened in a semi-circular postion at shoulder level.
- another name for the Hindu God Krishna.
- a temple ritual dance of South India.
- the term used for pure dance in Indian classical dance.
- the term used for expressional or emotive dance in Indian classical dance.
- the term used for dramatic element in Indian Classical dance.
- an expressional dance composition in the repertoire of Bharata Natyam.
- the consort of Lord Shiva.
- the intermediate parts of the parts of the body.
- the dancing girls who used to perform in the courts in India.

Sadir Attam Sahitya Salami Samapada

- prior name for Bharata Natyam.
- the lyrics in Indian musical composition.
- a gesture of greeting or respect in Kathak dance.
- a basic dance posture where the feet are kept close together.

Sangeet Natak Akademi

- the national level academy for performing arts set up by the Government of India.

Sattvika Shabdam

Shiro bhedas Sultan

Tandava

Tanjavur

Tanjore Quartet

Taragam

Tillana

Upanga Vachika Varnam

Vishnu Yamuna

- the expression of the inner emotions.
- an expressional dance composition in the repertoire of Bharata Natyam.
- the head movements in Indian classical dance.
- a Muslim ruler.
- the masculine aspect in Indian classical dance.
- a city in South India.
- the four Pillai brothers from Tanjore who shaped the repertoire of Bharata Natyam.
- a forest in India.
- a pure dance composition in the repertoire of Bharata Natyam usually performed at the end of a concert.
- the minor parts of the body.
- expression through speech or language.
- a major dance composition in the repertoire of Bharata Natyam.
- a Hindu God known as the preserver of the universe.
- a river found in North India.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->