In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the Ministry of Education, Tertiary Education,

Science and Technology.

<!-- image -->

In this image we can see a book with some text on it.

<!-- image -->

Based on the National Curriculum Framework 2016

## MAHATMA GANDHI INSTITUTE

<!-- image -->

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology. Republic of Mauritius

202 1

<!-- image -->

## Mahatma Gandhi Institute (2019)

All rights reserved.No part of this publication may be reproduced, stored in a retrieval system, or transmitted in any form or by any means, electronic, mechanical, photo copying, recording or otherwise, without the prior permission of the Copyright owner.

## Printed by:

T- Printers Co Ltd, Industrial Zone, Coromandel, Mauritius. Tel: (230) 233 2500

First published 2020 Reprinted 2021

While every effort  has  been  made to trace the copyright holders for reproductions, we might have not succeeded in some cases.  We offer our sincere apologies and hope that they will take our liberty in good faith.  We would appreciate any information that would enable us to acknowledge the copyright holders in our future editions.All materials should be used strictly for educational purposes.

ISBN: 978-99949-54-29-2

## Performing Arts (Indian Music and Dance) Panel

- Team Leader -  Educator (Tabla) -    MGI -

Mr. K. Mantadin                -

## Project Coordinator

(organisation and development), Senior Lecturer (Tabla),

Head, Department of Curriculum Development,

MGI.

Mr. K. Mantadin                -

## Panel Coordinator

Senior Lecturer (Tabla), MGI. Head, Department of Curriculum Development,

## Writing Team             Tabla

Mr. Y. D Jogeswar

Mr. S. Juggernauth

Mr. J. Luchmun

## Vetters

Mr. D. Deerpaul

-  Former Lecturer (Tabla)- MGI

Mr. P. Deerpaul

## Proof Reading

- Mrs. D. Balaghee              -  Deputy Rector - MGISS

## Graphic Designers - MGI

## Photography

(cover, illustration, layout and photography)

Ms. V.Jatooa

Mr. V.Napaul

Ms. P.Juckhory

## Word Processing Operator

Mrs. N. Mugon

-  Educator (Tabla) -    M.O.E,T.E, Sc &amp; Tech.

-  Educator (Tabla) -    MGI

-  Educator (Tabla) -    M.O.E,T.E, Sc &amp; Tech.

Mr K.G.Moonesawmy - Pro Foto Plus

Mrs  S.  N  Gayan,  GOSK,  Director  General,  Mahatma  Gandhi  Institute and Rabindranath  Tagore  Institute, for  her  continued  advocacy  for music education especially Indian Music and Dance.

Dr (Mrs) V Koonjal, Director, Mahatma Gandhi Institute, for her unwavering support to this project.

## The Performing Arts (Indian Music and Dance) panel is also grateful to the following persons:

Mrs.U.Kowlesser                       Registrar (MGI)

- Dr. D. Ramkalawon                 Senior Lecturer (Sitar), Head School of Performing Arts, MGI

## Quality Vetting Team

Mr. V.N Iyavoo

- Assitant Instructor,(Tabla) - MGSS

Mr. B. Jeewaheer

- Educator, (Tabla) - M.O.E,T.E, Sc &amp; Tech.

Mrs. V.C. Seeneevassen

- Lecturer/Head, Department of Printmaking, MGI

Mr. R.R.Maloo

-     Educator, (English) - MGSS

## Administrative Staff

- Mrs.H.Chudoory                       Administrative Officer -MGI

- Mrs.P.Purmessur                          Word Processing Operator - MGI

- Dr J.Chemen                            Assoc. Prof. Head, Centre for Quality Assurance, MGI (Coordinator)

Mrs.P.Appadoo

- Clerical / Higher Clerical Officer - MGI

- Music Organiser  (Oriental) M.O.E, T.E, Sc &amp; Tech. Dr. D.Pentiah - Appadoo

Dr. Mrs. S.D. Ramful

- Director Schooling - MGI

Mrs.G.G.Cheekhooree

- Clerical Officer / Higher Clerical Officer - MGI

## Photo Courtesy

Mrs. B.Narain Mrs. P. Luchmun Mrs. P. Jamookeeah Mr. A.K Chuttoo Mr. P.Bhunjun Mr. B. Narain

- Ms. V.Cahoolessur                   Office Supervisor - MGI

-  The parents and their wards for giving us the permission to reproduce their photographs and images in the textbook.

'Where the mind is allowed to stumble upon cascades of emotion and where the surprise of creative exchange comes out of tireless striving towards perfection.'

## Rabindranath Tagore

? Should music, dance, arts, drama be taught in schools? Do such subjects matter decision, in the context of the reforms leading to the Nine Year Continuous Basic Education, to include teaching of the performing arts in the secondary school curriculum shows that 'the ayes have it.' At least for the time being. As in the case of all debate, there are those who are for and those who are against. The

Traditionally, music teaching takes place in a one-to-one mode. The piano teacher teaches one student at a time, so does the sitar guru. Dance is more of a group experience. But for each of these disciplines, the context of institutional level teaching introduces opportunities of reaching a broader cross-section of population, thereby giving rise to fresh challenges. Students come from a variety of social and cultural environments which expose them to different types, genres and registers in the arts. Students also come with different levels of aptitude. These are but two of challenges encountered.

From another perspective, it has been repeatedly pointed out that the 'digital natives', while  definitely  coming  to  learning  with  resources  hitherto  not  available,  may,  in  the process, be losing their ability to grasp, decipher and understand emotional language. In short they may be losing empathy.

The ultimate aim of arts education in the curriculum is to provide a pedagogical space where the young will be able to explore their own affective responses to forms of artistic expression, to develop sensibility, while acquiring a whole set of skills, including not only spa -tial  awareness,  pattern  recognition  or  movement  coordination,  but  also  the  benefits  of group and team work, of joint effort, higher level creative thinking and expression, as well as an overall sense of shared pleasure and of achievement. This is what emotional intelligence is all about.

The specialists who prepared the syllabus and the present textbooks for Indian music and dance had all the above in mind while undertaking the task. The teacher training for these disciplines needs to be a continuous process of exchange between curriculum developers, teaching practitioners, textbook-writers and learners.

The MGI is particularly happy to be part of this major development, at a time when the country is looking at new avenues for continued economic development, and more importantly at new avenues to enhance equity, social justice and inclusion. It is our small contribution to the 'grande aventure' of holistic education.

Mrs Sooryakanti Nirsimloo-Gayan, GOSK Director-General (MGI &amp; RTI)

This textbook is the first instructional material in the field of Performing Arts (Indian Music  and  Dance)  written  by  a  team  of  experienced  Mauritian  teachers  and experts in Vocal Music, Instrumental Music and Dance.

It  has  been  designed  on  the  Aims,  Objectives  and  the  Teaching  and  Learning Syllabus  of  the  Performing  Arts  from  the  National  Curriculum  Framework  (2016), under the Nine Year Continuous Basic Education Programme.

The Performing Arts Curriculum is articulated around four strands: Performing, Creating, Responding and Performing Arts and Society. Thus, the textbook takes into  account  the  development  of  key  skills  and  understandings  under  the  four strands.

This  set  of  textbooks  for  grade  7,  8  and  grade  9  lays  the  foundation  in  each discipline and provides learners with the essential knowledge, skills and attitudes needed  to  progress  towards  higher  grades.  It  also  takes  into  consideration  the multicultural nature of our society and its traditions.

This  textbook  is  a  support  material  that  gives  direction  to  the  educators  in  the teaching  and  learning  process  by  linking  the  curricular  components,  curricular expectations, pedagogical principles and assessments.

A textbook is not an end in itself like any other instructional material.It is a means to facilitate learning to take place in a continuous and continual manner.

Learning  objectives  in  each  chapter  of  the  textbook  reflect  the  curricular outcomes.  It will help the teacher to design his/her lesson plans which will further ease the teaching and learning transaction towards achievement.  Teachers will have to plan their work so that learning takes place in an effective and efficient way.  They will have to provide appropriate and enriched experiences and modify the teaching and learning strategies according to the needs of learners.

The practical aspects of the discipline have been integrated under 'practical' with step-by-step technique laying emphasis on the mastery of skills from one level to another.

We  are  aware  that  children  construct  knowledge  in  their  own  way  and  have different learning styles.The textbook has been designed to cater for such needs.

Special features and a generous number of illustrations, pictures, concept maps and activities have been included to promote collaborative learning and other additional skills like team spirit, cooperation and understanding diverse nature of learners.These would help teachers to organise their interactions at classroom level. Teachers may give more activities, depending upon the availability of resources and time.

Assessments in the form of activities, projects and questions are also included at the end of  each  chapter.    These  are  check  points  to  assess  the  learners.    It  will  help teachers gather evidences about the expected level of learning taking place in the learners.

I  would  also  request  all  the  Educators  to  go  through  the  National  Curriculum Framework (2016), the Teaching and Learning Syllabus of the Performing Arts (Indian Music  and  Dance)  documents  and  especially  the  'Important  Note  to  Educators' which has been provided in the textbook to have a thorough understanding of the Philosophy and Perspective behind those documents and their implications in the implementation of the Reform process in the education system.

I hope that this new journey of learning Indian Music and Dance will be an enriching one.

Project Co-ordinator - Performing Arts (Indian Music and Dance),

Mr. K. Mantadin, Senior Lecturer (Tabla), Head Department of Curriculum Development, Mahatma Gandhi Institute.

## IMPORTANT NOTE TO EDUCATORS:

This teaching and learning syllabus of Indian Music and Dance has been designed on the spiral curriculum model in which core components and essential topics are revisited within the three years.  It caters for both the theoretical and practical aspects of each discipline.

It also comprises different blocks of knowledge and skills and each block is supported by specific  learning  outcomes  which  cover  all  the  three  domains  of  learning;  cognitive, psychomotor and affective.

The Listening and Viewing component has been integrated in the syllabus as it is a key factor in the development of music and dance abilities.  Teachers should provide a wide variety of listening and viewing experiences for learners to stimulate active listening and viewing through questioning, prompting and suggestion.

In order to achieve the objectives of the syllabus and to keep a good balance between theory and practical sessions, the teacher will have to plan his / her work and teaching and learning activities according to the topics to be taught as specified in the scheme of studies.  However, educators may modify the sequence of the topics in which they wish to teach for the smooth running of the course.

## Educators should:

1. Ensure that learners use the knowledge, skills and understanding developed from  grades 1 -6 and build upon that prior knowledge to construct new knowledge.
2. Provide learning experiences that include opportunities for hands-on and interactive learning, self-expression and reflection.
3. Find a variety of ways to align their instruction with the Aims, Learning Outcomes and Specific Learning Outcomes by focusing on active learning and critical thinking.
4. Provide learning activities that are appropriate in complexity and pacing.
5. Provide opportunities for individual and multiple groupings.
6. Actively engage and motivate students in the process of Learning Music and Dance.
7. Develop the ability in the learners to use and understand the language of Music and Dance through listening and viewing as well as responding to live and recorded repertoires.
8. Enrich the musical experience of the students by gaining an understanding of the cultural and historical context of music and dance exploring personal connections with them.
9. Technologies(ILT's).  This will facilitate developing their investigative and methodological abilities. 9.Carry out active listening and viewing sessions through the use of Information Learning

10. Model and demonstrate accurate and artistic musical and dance techniques.
11. Differentiate Music and Dance instruction to meet a wide range of students needs.
12. Educators should also ensure that learners:
-  Show proper care and maintenance of classroom instruments.
-  Demonstrate respectful behaviour as performers and listeners.
-  Participate in classroom protocole and traditions for music making and dance.
13. Reinforce effort and provide recognition.
14. Discuss student performances by using peer assessment as a tool.
15. Give opportunities to students to assume various roles in music performances, presentations and collaborations.
16. Motivate students to maintain a musical collection and portfolio of their own work over a period of time.  It can be an individual or group initiative that the learner will undertake under the supervision of the educator.

## TABLE OF CONTENIS

In this image we can see a chart.

<!-- image -->

| Chapter                                      | 1: MUSIC IN MAURITIUS AND AROUND THE GLOBE   | 1   |
|----------------------------------------------|----------------------------------------------|-----|
| Chapter 2: LAYAAND                           | 13 LAYAKARI                                  |     |
| Chapter 3: COMPOSITIONS IN TEENTAAL          | 21                                           |     |
| Chapter 4: THEKA                             | 51                                           |     |
| Chapter 5: COMMON MUSICAL TERMS AND CONCEPTS | 71                                           |     |
| Chapter 6: DADRAAND KAHERWATAAL-S            | 79                                           |     |
| Chapter 7: GHARANA                           | 97                                           |     |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Chapter                                 | 8: VOCALAND INSTRUMENTAL FORMS   | 103   |
|-----------------------------------------|----------------------------------|-------|
| Chapter 9: MUSICAL                      | 115 INSTRUMENTS                  |       |
| Chapter 10: TABLA TUNING                | 125                              |       |
| Chapter 11: MUSICOLOGISTS AND EXPONENTS | 133                              |       |
| Chapter 12: COMPOSITIONS IN ROOPAK TAAL | 149                              |       |
| Chapter 13: MUSIC AND TECHNOLOGY        | 167                              |       |
| Chapter 14: RIYAAZ                      | 177                              |       |
| GLOSSARY OF TERMS                       | 188                              |       |

In this image, we can see a map and a globe.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Distinguish between Western and Arabian music.
- Identify each style of music with its respective culture.
- Describe, in detail, each music style, and its role and importance in Mauritius and in other countries.
- Identify the folk music of the different communities in Mauritius.
- List the instruments used in the folk music of different communities of Mauritius.
- Appreciate the different styles of music.
- Show interest in the different types of instruments.

## 1.0 FOLK MUSIC AND DANCE IN DIFFERENT COMMUNITIES OF MAURITIUS

## 1.1 INTRODUCTION

Mauritius  is  a  multiracial  country  where  its  pride  resides  in  the  unity  in diversity of its population. As the island consists of immigrants from various parts  of  the  world,  this  has  given  rise  to  different  communities  in  the country.  Each  community  practises  its  culture  and  tradition,  which  are mutually respected by each and every one.

There is a panoply of cultural activities which takes place around the island, among which, music and dance are given lot of importance. Besides the famous sega and bhojpuri music,  there  lie  other  types  of  folk  music  and dance which are practised by other communities in Mauritius.

## 1.1.1 KOLLATAM DANCE

In this image we can see a group of people dancing. There are some people standing and some are sitting. There are some objects. There is a statue. There are some plants. There are some trees.

<!-- image -->

The kolattam dance is a popular folk dance mostly practised by the Tamil and Telegu communities in Mauritius. It originates from Tamil Nadu in India.

Kolattam is derived from the words ' kol ' and ' attam ' where ' kol ' means small stick and ' attam '  means dance. Therefore, dancers play with sticks while performing the Kolattam dance.

This  dance  is  usually  performed  by  young  girls  and  women  holding  two sticks  in  their  hands.  Dancers  strike  their  sticks  while  making  various patterns in a big circle by following an appropriate rhythm. They also dance in pairs by striking each other's sticks.

Traditional instruments such as the Tappu and manjira are usually used to accompany the kolattam dance. The kolattam dance is usually performed on various occasions such as religious festivals, processions and cultural events.

## 1.1.2 JHAKRI

In this image we can see a group of women dancing. In the background there is a statue of a person and there are curtains.

<!-- image -->

Jhakri is a popular ritualistic dance form mainly associated with the Marathi community in Mauritius. It originates from the state of Maharashtra in India. This dance is performed during the Ganesh Chaturthi festival and Marathi wedding ceremonies.

Men and women sing and dance by moving in a circle with various step patterns around a drummer. The drummer usually plays a naal or a dholak . Sometimes,  the  drummer  is  also  the  lead  singer.While  dancing,  some dancers  clap  their  hands  and  others  play jhaal , manjira or chimta. An idiophone  known  as  the lezim is  also  used  while  performing  the jhakri dance.

## 1.1.3 RAMABHAJANAM

In this image we can see a group of people standing and holding some objects. In the background there are some objects and lights.

<!-- image -->

Ramabhajanam is  a  ritual  which is practised by the Telegu community in Mauritius.  It  originates  from  the  state  of Andhra  Pradesh in  India.  It  is performed during the Ram Navmi festival.  Prayers are offered to a large brass lamp with smaller lamps attached to it, in the form of a tree. Men play the manjira and women clap their hands while dancing around the lamp. Other musical instruments such as the naal , dholak , chimta and jhaal are also used to accompany the rituals of Rambhajanam .

## 1.1.4 DRAGON AND LION DANCE

In this image we can see a group of people are running and some are holding a banner. In the background we can see a group of people are standing and some are wearing suits.

<!-- image -->

In this image we can see a group of people, some of them are wearing costumes and some of them are standing. In the background we can see the buildings, trees, plants and the sky.

<!-- image -->

The dragon and lion dances are the two most popular traditional  dance forms of the Chinese community. The dragon dance is executed by a team of dancers carrying the different sections of the dragon using poles. The lead dancers lift, dip, thrust and sweep the head of the dragon. A wave-like pattern is achieved by the coordinated swinging of the body of the dragon. The dancers run in spiral formations to make the dragon's body turn and twist.

The  movements  of  a  lion  are  imitated  while  doing  the  lion  dance.  It  is performed by two dancers in a lion costume. The front dancer moves the head and the front limbs and the second one moves the back and the hind legs. The lion dance is performed to bring prosperity and good luck.

Chinese drums, cymbals and gongs are used to accompany both dance styles.

## 1.2 MUSIC AROUND THE GLOBE

## 1.2.1   ARABIAN MUSIC

In this image we can see three men are sitting on the carpet and playing musical instruments.

<!-- image -->

Arabian music is among the oldest music styles in the world. Besides being the  music  of  the Arabs, Arabian  music  has  also  been  influenced  by  the music  of  neighbouring  countries  such  as  Egypt,  Greece,  Persia,  Iraq, Kuwait, etc. Classical, folk and popular music are the different genres found in Arabian music.

The Arabic classical music is based on the maqam system. Each maqam is based  on  a  particular  scale  and  can  be  realised  only  by  vocal  or instrumental music without any rhythm.

The rhythmic cycles used in  Arabic music are known as the iqa'at . Each iqa' has a specific name and a pattern of beats ranging in number from two to  twenty-four  or  even  more.  More  emphasis  is  laid  on  rhythmic  playing rather than maqam in on Arabian folk music.

The music of the western countries has a great influence on the Arabian popular music. New electronic musical instruments, such as the synthetiser and  drums  are  used  to  make  their  performances  more  attractive  and popular.  Nowadays,  rock,  rap  and  heavy  metal  music  are  also  part  of Arabian style.

Takht is  the  term used for an instrumental ensemble in Arabian music. It usually  involves  four  to  five  players  or  sometimes  more.  The  main instruments used in a takht are the Oud , Ganoun and the Nay . With time and evolution, musical instruments from Europe and other cultures have been  added  to  the  musical  ensemble. Takht is also used  for the accompaniment of dance.

In this image we can see a poster with some text and images.

<!-- image -->

## 1.2.2 WESTERN MUSIC

In this image we can see a group of people playing musical instruments.

<!-- image -->

Western music usually refers to a musical style practised by the cowboys in American countries. Sometimes it is also called country music. It is a folk music  which  relates  the  life  style  of  cowboys  and  their  culture.Musical instruments  such  as  the  guitar,  banjo,  mandolin,  harmonica,  fiddle,  bass fiddle are used in such types of music.

In this image we can see a few musical instruments.

<!-- image -->

Western music also refers to the music practised in the western part of the globe  and  in  European  countries.  It  consists  of  different  genres  such  as folk,  pop,  classical,  jazz  and  rock  and  roll.  Western  music  depicts  the various cultures of different countries along with their spoken languages.

Melody, harmony and rhythm are the characteristics upon which western music usually lies. In addition, staff notation is very prominent in western music, mainly when it pertains to the classical genre.

## WESTERN MUSIC HAS GONE THROUGH AN EVOLUTION IN VARIOUS ERAS AS SHOWN IN THE TABLE BELOW:

| PERIOD                     | EVOLUTION                                                                                                                               |
|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| Middle age (450 AD-1450AD) | Dominated by Catholic sacred music.                                                                                                     |
| Renaissance (1450-1600)    | Golden age of vocal music.                                                                                                              |
| Baroque (1600-1750)        | Rise of instrumental music, invention of modern violin, creation of first orchestras.                                                   |
| Classic (1750-1820)        | Classical music became standards, and used as reference. Rise of great composers like Mozart and Beethoven.                             |
| Romantic (1820-1900)       | Rise of superstars, performers and paying concerts aiming at middle class audiences. Chopin was one among the great romantic composers. |
| Modern (1900-present)      | Invasion of popular music and a lot of experimental music.Use of technology in music.                                                   |

A variety of musical instruments, from all the categories, are usually used in  western  music.  The  choice  usually  depends  on  the  composer  or  the musical genre. Nowadays, musical instruments used in Indian music are adapted in Western style in order to enhance the musical flavor.

Pandit Ravi Shankar is among the first Indian artists  to  have  played the sitar  in  a  Western orchestra.

DID YOU KNOW

POINTS TO REMEMBER:

- Kolattam is a pair of small sticks used in kolattam dance. Tappu and manjira are used to accompany the kalattam dance.
- Jhakri is a ritualistic dance practised by the Marathi community. Dholak or naal , manjira and chimta are used to accompany this dance form.
- Rambhajanam is practised by the Telegu community. It is a ritual where dance is performed around a lamp tree accompanied by dholak , manjira , jhaal and chimta .
- Dragon and Lion dances are practised by the Chinese community. Chinese drums, cymbals and gongs are used to accompany the dance styles.
-  Arabian music  is based on the maqam system.
-  Western music is based on melody, harmony and rhythm.

<!-- image -->

Kolattam, jhakri, dance,lamp, dragon, lion, gongs, maqam, iqa, takht, melody, harmony.

1

2

ACTIVITY

ACTIVITY

## Youtube links:

- a. https://youtu.be/YT\_em1MAC0A
- b. https://youtu.be/PsUK76\_TdHA
- c. https://www.youtube.com/watch?v=nTrisxsGQO8
- d. https://www.youtube.com/watch?v=Rt5I3OYcFik
- e. https://www.youtube.com/watch?v=4WUnWPpRslM

## After having viewed the video:

- (i)  Identify each musical and dance style and relate it to a particular community in Mauritius.
- (ii) Name the musical instruments used.

## Youtube links:

- a.  https://www.youtube.com/watch?v=AGK4xkuI1rA
- b.  https://www.youtube.com/watch?v=Scmw4RoM030

## After viewing the video:

- (i)  Differentiate between the two musical styles.
- (ii) Relate each musical styles to its culture.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

1

Match each term in column A to its appropriate music and dance style in column B:

COLUMN A                                       COLUMN B

Gongs and Cymbals

Maqam

Harmony, Melody, Rhythm

Ramabhajanam

Tappu

Lezim

Dancing around a tree of lamps Kolattam Dance Jhakri Dance Arabian music Chinese music Western music

<!-- image -->

Fill in the blanks with the appropriate words given in bracket:

( jazz, lezim, kolattam, gongs, telegu,cymbals, maqam,western, lamp, lion, country)

- (i)  ……………….. dance is performed by holding a pair of sticks in

hand.

- (ii) An idiophone known as the ……………… is also used in jhakri dance.
- (iii) Ramabhajanam is a ritual mostly practised by the …………….. community in Mauritius.
- (iv) ………….and ……………. are usually used to accompany the
- dragon and lion dance.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

- (v) Melody and harmony are the terms mostly associated to …………. music.
- (vi) The ……………… system is the basis of Arabian classical music.
- (vii) ………………music is also associated with the life style and
- culture of cowboys.
- (viii)  …………….. dance is usually performed during rambhajanam.
- (ix) The …………….. dance is performed to bring luck and properity
- in Chinese culture.
- (x)  ……………..  is a musical genre in western music.

Assessment

3

- (i)   List the characteristics of Western and Arabian music.
- (ii)  List the musical instruments used in:
- a. Western music
- b. Arabian music

In this image we can see a paper with a clip and a paper with a note.

<!-- image -->

In this image we can see a poster with some text and numbers.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Define the term laya .
- Distinguish among the different types of laya-s , namely: ekgun , dugun .
- Examine how laya-s and layakari-s influence the compositions in a rhythmic cycle.
- Play specific compositions which have been set in ekgun and dugun ( kaida-s , rela-s , and mukhda-s ).
- Play specific compositions individually or in group without inhibition.
- Appreciate the different types of laya and layakari-s used in tabla .

## 2.0 WHAT IS LAYA?

Laya is:

- the term used for speed in Indian music.
- the regular flow of beats in a rhythmic cycle.
- any action repeated at a regular interval.

## 2.1 TYPES OF LAYA

In this image, we can see a clock, a picture of a turtle, some text, and some other objects.

<!-- image -->

There  are  three  types  of laya : vilambit (slow), madhya (medium)  and drut (fast).The laya is determined by the pace or pause between regular actions.

## VILAMBIT LAYA (SLOW SPEED):

In this image, we can see a poster with some text and images.

<!-- image -->

## DRUT LAYA (FAST SPEED):

In this image we can see a diagram with some text and images.

<!-- image -->

## 2.2 LAYAKARI:

Layakari is a combination of two words, ' laya ' and ' kari '.' Laya ' means speed and ' kari ' means to work on rhythms.

Layakari is  the  action  of  doing  rhythmic  variations  with  respect  to  an established basic laya .

It actually shows the skills of the tabla player in controlling laya in an artistic way.This is done in terms of the ratio of beats actually played to the basic beats.

Various  types  of laya can  be  adjusted  to  the  basic laya ,  which  are  as follows:

Ekgun - Basic laya

Dugun - Double speed

Tigun - Triple speed

Chawgun - Quadruple speed.

## 2.3 EKGUN:

It is the basic laya established by a performer or the basic underlying speed or tempo of the beats in any rhythmic cycle. It may be called single speed.

| MATRA           | 1   | 2    | 3    | 4   |
|-----------------|-----|------|------|-----|
| COUNT           | 1   | 2    | 3    | 4   |
| TABLA SYLLABLES | Dha | Dhin | Dhin | Dha |

CHAPTER 2: LAYA AND LAYAKARI

## 2.4 DUGUN:

It is the double speed of the basic laya (ekgun) set by the performer.

<!-- image -->

| MATRA           | 1       | 2          | 3       | 4          |
|-----------------|---------|------------|---------|------------|
| COUNT           | 1 2     | 3 4        | 1 2     | 3 4        |
| TABLA SYLLABLES | DhaDhin | Dh in Dh a | DhaDhin | Dh i n Dha |

In this image, we can see a picture of a circle. In the picture, we can see a text.

<!-- image -->

2

- Laya is a regular flow of beats in music.
-    There are three types of laya : vilambit (slow), madhya (medium) and drut (fast).
- Ekgun is the basic laya set by the performer.
- Dugun is when a taal or a composition is played two times faster than its basic laya .
- Layakari is the action of doing rhythmic variations with respect to an established basic laya .

## Youtube link:

ACTIVITY

- a. https://www.youtube.com/watch?v=-A9yzEwBR4A

## After viewing the video:

1. Can you distinguish the different laya-s?
2. Show the laya-s by clapping of hands.
3. Name the different laya-s in the video.

POINTS TO REMEMBER:

## Word Search

ACTIVITY 3

## (MADHYA, REGULAR, LAYA, DRUT, VILAMBIT, RHYTHM, SPEED, EKGUN, DUGUN)

| A   | C   | S   | R   | S   | E   | A   | A   | T   | V   | H   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| H   | R   | I   | P   | B   | C   | D   | R   | T   | A   | E   |
| X   | D   | E   | C   | M   | A   | D   | H   | Y   | A   | G   |
| F   | E   | N   | G   | D   | L   | A   | Y   | A   | N   | D   |
| D   | K   | Y   | U   | U   | A   | X   | T   | R   | C   | R   |
| Q   | G   | G   | A   | A   | L   | F   | H   | H   | I   | U   |
| O   | U   | P   | V   | I   | L   | A   | M   | B   | I   | T   |
| N   | N   | R   | T   | H   | C   | E   | R   | E   | A   | F   |

Assessment

## Fill in the blanks:

- (a)  Laya is the term used for
- ………….. in Indian music.
- (b)  Fast speed is referred to ………………………. in Indian Classical music.
- (c)  ………………..is the double speed of the basic laya.
- (d)  The basic laya set by the performer is known as ………………… .
- (e)  A snail moves in …………………..laya.

Assessment

2

- I.     Define the term laya.
- II. List the 3 types of laya.

Assessment

## Define the term layakari.

<!-- image -->

Differentiate between ekgun and dugun.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

In this image we can see a paper with a clip and a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper with a paper

<!-- image -->

In this image, we can see a puzzle with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Explain, in details, the term kaida, stating its dinstinctive features and rules.
- Recite, count and play the kaida of ' Tit ', ' TitKit' , ' DhaTi' in single and double speed with a minimum of 3 palta-s and a tihai at a regular speed and in a systematic way.
- Explain the key terms: Mohara , Mukhda , Palta and Rela .
- Recite, count and play simple mukhda-s , mohara-s at a given regular speed.
- Recite, count and play a rela of Ghida Naga in single and double speed with a minimum of 3 palta-s and a tihai at a regular speed and in a systematic way.
- Explain the term tihai and its types ( damdaar , bedam and chakkrad a ar ).
- List the types of tihai-s .
- Recite, count and play simple damdaar , bedam and chakkradar tihai-s .

## 3.0 DEFINITION OF THE TERM KAIDA

Kaida literally means rule. In Hindustani music, Kaida is a composition which is played on the tabla . It is played in a very systematic and methodical manner. Kaida is  usually played in a solo recital or when accompanying instrumental music. It is played in vilambit laya, though some kaida-s sound good in madhya laya as well, provided they are played with clarity.

The structure of a kaida consists of two parts or segments. The first part or segment starts on the sam and ends on khali , while the second one takes off from  the khali and  ends  on  the sam .  Every kaida is  named  after  the  main alphabet which occurs frequently and prominently in its specific structure, for example, kaida-s of  different  syllables  such  as Tit , Tit-Kit , Dhati etc.  These kaida-s can be set in different taal-s namely teentaal , roopak taal , jhaptal , ektal etc. Kaida is  normally  governed  by  certain  rules  that  are  very  important  to observe while playing a kaida and its  variations.   There are four main rules governing a kaida .

## 3.1 RULES OF KAIDA:

A kaida is always divided into two equal segments namely the bhari segment and the khali segment.

The first segment starts from the sam and ends on khali , while the second one takes off from khali and ends on sam .

The expansion of a kaida should be done in a systematic and in an orderly manner, that is, variations ( palta-s ) have to follow a particular sequence.

The terminal syllables of the two segments have to rhyme without being identical. Thus, if the last word of the first line is TinNa, the terminal bol of the second line has to be DhinNa, and if the first line ends with TinNa KiNa , the second line should end with DhinNa GiNa .

That is, although the ending bol-s are different they should correspond in sound.

No such syllables can be included in the creative variations which are not found in the basic composition. For example, we cannot have syllables such as TitKit , Dhati etc in the variations of a kaida of Tit .

## Kaida:

-  Composition played on the tabla either in solo recital or while doing accompaniment.
-  Played in vilambit or madhya laya .
-  Named after the main tabla bol e.g Tit , TitKit .
-  Can be played in different taal-s .
- Kaida is normally governed by certain rules that are very important to observe while playing a kaida and its variations.
- There are four main rules governing a kaida .

<!-- image -->

## Rules of kaida:

-  A kaida is divided into two equal segments i.e bhari segment and khali segment.
-  The terminal syllables of the two segments have to rhyme without being identical.
-  The expansion of a kaida should be done in a systematic and in an orderly manner.
-  Variations are subject to a clear restriction.

END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

- (i) Define the term kaida.
- (ii) State the four rules governing a kaida.

<!-- image -->

## 3.2 KAIDA OF 'TIT' SET TO TEENTAAL:

In this image I can see the text on the image.

<!-- image -->

| 14 15 16 Dhin Dha   | 3 Tin Na Ki Na   | Dhin Na Gi Na Tit DhaGe DhinNa GiNa   | Tit DhaGe DhinNa GiNa   | Tit DhaGe TinNa KiNa Tit DhaGe TinNa KiNa DhaGe TinNa KiNa Tit DhaGe DhinNa GiNa   | Tit DhaGe DhinNa GiNa Tit DhaGe DhinNa GiNa   | DhaTi tDha Tit DhaDha Tit DhaGe DhinNa GiNa   | 3     |
|---------------------|------------------|---------------------------------------|-------------------------|------------------------------------------------------------------------------------|-----------------------------------------------|-----------------------------------------------|-------|
| 13 Ta Dhin          |                  |                                       |                         | Tit                                                                                |                                               | SS                                            |       |
| 11 12 Tin Ta        | Dha Ge Ge        | Dha Tit DhaDha Tit DhaDha             | Tit DhaDha Tit DhaDha   | Tit DhaDha Tit DhaDha                                                              | Tit DhaDha Tit DhaDha                         | SS Tit DhaDha                                 | 0     |
| 9 10 Dha Dha Tin    | 0 Ti t Ti t      | TaTi tTa TaTi tTa                     | DhaTi tDha DhaTi tDha   | DhaTi tDha DhaTi tDha                                                              | DhaTi tDha DhaTi tDha                         | DhaS SS DhaTi tDha                            |       |
| 6                   | Dha Dha Dha Dha  | TinNa KiNa KiNa                       | Tit DhaDha Tit TaTa     | Tit                                                                                | DhaDha Tit TaTa Tit                           | DhaGe                                         |       |
| 7 8 Dhin            | t t              |                                       | TinNa                   | DhaDha Tit TaTa Tit                                                                | DhaDha TaTa                                   | DhinNa GiNa SS SS                             |       |
| 5 Dha Dhin          | 2 Ti Ti          | Tit DhaGe Tit DhaGe                   | DhaTi tDha TaTi tTa     | Tit Tit Tit                                                                        | Tit Tit                                       | Tit DhaS SS                                   | 2     |
| 4                   | Dha Ta           |                                       | TaTa                    | Tit TaTa                                                                           | tDha Tit tTa Tit                              | tDha Tit                                      |       |
| Dha                 |                  | DhaDha DhaDha                         |                         | DhaDha                                                                             | DhaDha TaTa                                   | DhaDha GiNa                                   | x     |
| 3 Dhin              |                  |                                       | DhaDha                  | Tit                                                                                |                                               | DhinNa                                        |       |
| 2 Dhin              | Ti t t           | Ti tDha Tit tDha Tit                  | tDha Tit tDha Tit       | tDha tTa                                                                           |                                               | DhaGe                                         |       |
| 1 Dha               | x Dha Ta         | DhaTi DhaTi                           | DhaTi TaTi              | DhaTi TaTi                                                                         | DhaTi TaTi                                    | DhaTi Tit                                     | Dha   |
| Matra Theka         | Kaida (Ekgun)    | Kaida (Dugun)                         | Palta 1                 | 2                                                                                  | Palta 3                                       | Tihai                                         | Taal  |
|                     | Taal Signs       |                                       |                         | Palta                                                                              |                                               |                                               | Signs |

In this image we can see a paper with some text written on it.

<!-- image -->

<!-- image -->

## In the previous chapters, students have learnt about:

-   The execution of the syllable ' Tit ' with proper technique.
-   How to recite, count and play exercises in different patterns with the syllable ' Tit '.

<!-- image -->

## Some exercises to be practised before playing the kaida .

| Matra      | 1      | 2   | 3    | 4    | 5      | 6   | 7    | 8    |
|------------|--------|-----|------|------|--------|-----|------|------|
| Exercise 1 | Ti     | t   | Ti   | t    | Ti     | t   | Ti   | t    |
| Exercise 2 | Tit    | Tit | Tit  | Tit  | Tit    | Tit | Tit  | Tit  |
| Exercise 3 | Ge     | Ge  | Ti   | t    | Ge     | Ge  | Na   | Na   |
|            | Ke     | Ke  | Ti   | t    | Ge     | Ge  | Na   | Na   |
| Exercise 4 | GeGe   | Tit | GeGe | NaNa | KeKe   | Tit | GeGe | NaNa |
|            | GeGe   | Tit | GeGe | NaNa | KeKe   | Tit | GeGe | NaNa |
| Exercise 5 | Dha    | Dha | Ti   | t    | Ta     | Ta  | Ti   | t    |
| Exercise 6 | DhaDha | Tit | TaTa | Tit  | DhaDha | Tit | TaTa | Tit  |
| Exercise 7 | DhaDha | Tit | Tit  | Tit  | TaTa   | Tit | Tit  | Tit  |
| Exercise 8 | Tin    | Na  | Ki   | Na   | Dhin   | Na  | Gi   | Na   |

The following steps are to be executed with reference to table shown in 3.2.

<!-- image -->

-   Memorise the kaida .
- Padhant of the kaida in ekgun at a steady rhythm.

<!-- image -->

## Step    4

-  Execution of the kaida in ekgun.
- Padhant of the kaida in ekgun and dugun .

<!-- image -->

## Step    6

-  Execution of the kaida in ekgun and dugun .
- Padhant of each palta .

<!-- image -->

## Step    8

-  Execution of each palta .
- Padhant of the tihai .

<!-- image -->

## Step   10

-  Execution of the tihai .
-  Padhant of the kaida in ekgun and dugun with the given palta-s and tihai .
-  Execution of the kaida in ekgun and dugun with the given palta-s and tihai .

<!-- image -->

<!-- image -->

In this image we can see a circular object.

<!-- image -->

To  work  in  different  groups  where each group will have to do a poster presentation  on  the  different  rules governing a kaida .

<!-- image -->

## Youtube link:

https://www.youtube.com/watch?v=TpmkpdzpNtA

After having watched the video students are required to discuss on the following:

- Type of composition played.
- Laya in which the composition has been played.

END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

1. Write into notation form the kaida of Tit in ekgun and dugun with two paltas and a tihai set to teentaal.
2. Recite,count and play the kaida of Tit in ekgun and dugun with two paltas and a tihai set to teentaal.

## 1 5

| 13 14 15 16 Ta Dhin Dhin Dha   | 3          | Tin Na Ki Na Dhin Na Gi Na   | DhaTi DhaGe DhinNa GiNa DhaTi DhaGe DhinNa GiNa   | DhaTi DhaGe TinNa KiNa DhaTi DhaGe TinNa KiNa DhaTi DhaGe DhinNa GiNa   | DhaTi DhaGe TinNa KiNa DhaTi DhaGeDhinNa GiNa DhaTi DhaGe DhinNa GiNa   | DhaTi DhaGe NaDha TitKit DhaTiDhaGe DhinNa GiNa   |     | 3          |
|--------------------------------|------------|------------------------------|---------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|---------------------------------------------------|-----|------------|
| 12 Ta                          |            | Ge Ge                        |                                                   | TitKit TitKit TitKit                                                    | TitKit TitKit TitKit                                                    | SS TitKit                                         |     |            |
| Tin                            |            |                              | TitKit TitKit                                     | NaDha                                                                   |                                                                         |                                                   |     |            |
| 11                             |            | Dha Dha                      | NaTa NaTa                                         | NaDha NaDha NaDha                                                       | NaDha NaDha                                                             | SS NaDha                                          |     |            |
| 9 10 Dha Tin                   | 0          | Dha Ti Dha Ti                | TaTi TaKe TaTi TaKe                               | DhaTi DhaGe DhaTi DhaGe DhaTi DhaGe                                     | DhaTi DhaGe DhaTi DhaGe DhaTi DhaGe                                     | DhaS SS DhaTi DhaGe                               |     | 0          |
| 8 Dha                          |            | Kit Kit                      | KiNa KiNa                                         | TitKit TitKit TitKit                                                    | GiNa KiNa TitKit                                                        | GiNa SS                                           |     |            |
| 7 Dhin                         |            | Tit Tit                      | TinNa TinNa                                       | NaDha NaDha NaTa NaTa                                                   | DhaTi TaTi                                                              | DhinNa SS                                         |     |            |
| 6 Dhin                         |            | Dha Ta                       | DhaGe DhaGe                                       | DhaGe TitKit TitKit TaKe                                                | GiNa KiNa                                                               | DhaGe SS                                          |     |            |
| 5 Dha                          | 2          | Na Na                        | DhaTi DhaTi                                       | DhaTi NaDha NaTa TaTi                                                   | DhaTi TaTi                                                              | DhaTi DhaS                                        |     | 2          |
| 4                              | Dha        | Ge Ke                        | NaDha TitKit NaDha TitKit                         | NaDha TitKit TitKit NaTa TitKit                                         | NaDha TitKit TitKit TitKit                                              | TitKit GiNa                                       |     |            |
| 3 Dhin                         |            | Dha Ta                       | DhaGe DhaGe                                       | DhaGe DhaGe NaDha TaKe NaTa TaKe                                        | DhaGe TaKe NaTa                                                         | DhaGe NaDha DhaGe DhinNa                          |     |            |
| 1 2 Dha Dhin                   | x          | Dha Ti Ta Ti                 | DhaTi DhaTi                                       | DhaTi DhaTi TaTi TaTi                                                   | DhaTi TaTi                                                              | DhaTi DhaTi                                       | Dha | x          |
| Matra Theka                    | Taal Signs | Kaida (Ekgun)                | Kaida (Dugun)                                     | Palta 1 Palta 2                                                         | Palta 3                                                                 | Tihai                                             |     | Taal Signs |

<!-- image -->

Students should have learnt about:

- The execution of the syllables  ' Tit ', ' TitKit ', ' Dhati ' and ' TaTi '  with proper technique.
-   How to recite, count and play exercises in different patterns with the syllables ' TitKit ' and ' DhaTi '.

<!-- image -->

Some exercises to be played before playing the kaida .

| Matra      | 1          | 2          | 3        | 4          | 5         | 6         | 7        | 8          |
|------------|------------|------------|----------|------------|-----------|-----------|----------|------------|
| Exercise 1 | Ti         | t          | Ki       | t          | Ti        | t         | Ki       | t          |
| Exercise 2 | Tit        | Kit        | Tit      | Kit        | Tit       | Kit       | Tit      | Kit        |
| Exercise 3 | Dha DhaDha | Dha TitKit | Tit TaTa | Kit TitKit | Ta DhaDha | Ta TitKit | Tit TaTa | Kit TitKit |
| Exercise 4 | DhaS       | Tit        | Kit      | TaKa       | TaS       | Tit       | Kit      | TaKa       |
| Exercise 5 | Dha        | Ti         | Dha      | Ge         | Na        | Dha       | Tit      | Kit        |
| Exercise 6 | Ta         | Ti         | Ta       | Ke         | Na        | Ta        | Tit      | Kit        |
| Exercise 7 | Dha        | Ti         | Dha      | Ge         | Tin       | Na        | Ki       | Na         |
| Exercise 8 | Ta         | Ti         | Ta       | Ke         | Dhin      | Na        | Gi       | Na         |

The following steps are to be executed with reference to table shown in 3.3.

<!-- image -->

-   Memorise the kaida .
- Padhant of the kaida in ekgun at a steady rhythm.

<!-- image -->

<!-- image -->

-  Execution of the kaida in ekgun .

## Step    5

- Padhant of the kaida in ekgun and dugun .
-  Execution of the kaida in ekgun and dugun .
- Padhant of each palta .
-  Execution of each palta .
- Padhant of the tihai .
-  Execution of the Tihai .
-  Padhant of the kaida in ekgun and dugun with the given palta-s and tihai .
-  Execution of the kaida in ekgun and dugun with the given palta-s and tihai .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a logo.

<!-- image -->

## Youtube link:

- a.  https://www.youtube.com/watch?v=wVsUSIcFPrA

After having watched the video students are required to discuss on the following:

- Type of composition played.
- Laya in which the composition has been played.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

## Assessment

1

1. Write into notation form the kaida of TitKit in ekgun and dugun with two palta-s and a tihai set to teentaal .
2. Recite,count and play the kaida of TitKit in ekgun and dugun with two palta-s and a tihai set to teentaal .

## 3.4 KAIDA OF 'DHATI' SET TO TEENTAAL

| 16    | Dha   |            | Na            | Na   | GiNa GiNa     | KiNa GiNa    | KiNa GiNa    | KiNa GiNa    | GeNa GiNa    |            |
|-------|-------|------------|---------------|------|---------------|--------------|--------------|--------------|--------------|------------|
| 15    | Dhin  |            | Ki            | Gi   | DhinNa DhinNa | TinNa DhinNa | TinNa DhinNa | TinNa DhinNa | TiDha DhinNa |            |
| 14    | Dhin  |            | Na            | Na   | DhaGe DhaGe   | DhaGe DhaGe  | DhaGe DhaGe  | DhaGe DhaGe  | SDha DhaGe   |            |
| 13    | Ta    | 3          | Tin           | Dhin | DhaTi DhaTi   | DhaTi DhaTi  | DhaTi DhaTi  | DhaTi DhaTi  | DhaS DhaTi   | 3          |
| 12    | Ta    |            | Ge            | Ge   | KeNa KeNa     | GeNa GeNa    | GeNa GeNa    | GeNa GeNa    | SS GeNa      |            |
| 11    | Tin   |            | Dha           | Dha  | TiTa TiTa     | TiDha TiDha  | TiDha TiDha  | TiDha TiDha  | SS TiDha     |            |
| 10    | Tin   |            | Ti            | Ti   | STa STa       | SDha SDha    | SDha SDha    | SDha SDha    | SS SDha      |            |
| 9     | Dha   | 0          | Dha           | Dha  | TaS TaS       | DhaS DhaS    | DhaS DhaS    | DhaS DhaS    | DhaS DhaS    | 0          |
| 8     | Dha   |            | Na            | Na   | KiNa KiNa     | GeNa KeNa    | GiNa KiNa    | GiNa KiNa    | GiNa SS      |            |
| 7     | Dhin  |            | Ge            | Ke   | TinNa TinNa   | TiDha TiTa   | DhaTi TaTi   | DhaTi TaTi   | DhinNa SS    |            |
| 6     | Dhin  |            | Dha           | Ta   | DhaGe DhaGe   | SDha STa     | GiNa KiNa    | GiNa KiNa    | DhaGe SS     |            |
| 5     | Dha   | 2          | Ti            | Ti   | DhaTi DhaTi   | DhaS TaS     | DhaTi TaTi   | DhaS TaS     | DhaTi DhaS   | 2          |
| 4     | Dha   |            | Dha           | Ta   | GeNa GeNa     | GeNa KeNa    | GeNa KeNa    | GeNa KeNa    | GeNa GiNa    |            |
| 3     | Dhin  |            | S             | S    | TiDha TiDha   | TiDha TiTa   | TiDha TiTa   | TiDha TiTa   | TiDha DhinNa |            |
| 2     | Dhin  |            | S             | S    | SDha SDha     | SDha STa     | SDha STa     | SDha STa     | SDha DhaGe   |            |
| 1     | Dha   | x          | Dha           | Ta   | DhaS DhaS     | DhaS TaS     | DhaS TaS     | DhaS TaS     | DhaS DhaTi   | x          |
| Matra | Theka | Taal Signs | Kaida (Ekgun) |      | Kaida (Dugun) | Palta 1      | Palta 2      | Palta 3      | Tihai        | Taal Signs |

<!-- image -->

## Students should have learnt about:

- The execution of the syllable ' DhaTi ' and ' TaTi ' with proper technique.
-    How to recite, count and play exercises in different patterns with the syllable ' DhaTi ' and ' TaTi '.

<!-- image -->

Some exercises to be played before playing the kaida .

| Matra      | 1     | 2     | 3     | 4    | 5     | 6     | 7      | 8    |
|------------|-------|-------|-------|------|-------|-------|--------|------|
| Exercise 1 | Ta    | Ti    | Ta    | Ti   | Ta    | Ti    | Ta     | Ti   |
| Exercise 2 | Dha   | Ti    | Dha   | Ti   | Dha   | Ti    | Dha    | Ti   |
| Exercise 3 | Dha   | Ti    | Ta    | Ti   | Dha   | Ti    | Ta     | Ti   |
| Exercise 4 | DhaTi | TaTi  | DhaTi | TaTi | DhaTi | TaTi  | DhaTi  | TaTi |
| Exercise 5 | DhaTi | GiNa  | TaTi  | KiNa | DhaTi | GiNa  | TaTi   | KiNa |
| Exercise 6 | DhaS  | SDha  | TiDha | GeNa | TaS   | STa   | TiTa   | KeNa |
| Exercise 7 | DhaTi | DhaGe | TinNa | KiNa | DhaTi | DhaGe | DhinNa | GiNa |

The following steps are to be executed with reference to table shown in 3.4.

<!-- image -->

-   Memorise the kaida .
- Padhant of the kaida in ekgun at a steady rhythm.
-  Execution of the kaida in ekgun .

<!-- image -->

<!-- image -->

<!-- image -->

- Padhant of the kaida in ekgun and dugun .

## Step    6

-  Execution of the kaida in ekgun and dugun .
- Padhant of each palta .
-  Execution of each palta .
- Padhant of the tihai .
-  Execution of the Tihai .
-  Padhant of the kaida in ekgun and dugun with the given palta-s and tihai .
-  Execution of the kaida in ekgun and dugun with the given palta-s and tihai .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Listen to the teacher playing the kaida of DhaTi in  ekgun  and  dugun with two palta-s and tihai set to teentaal.

After  listening,  the  students  are  grouped  in different  teams,  and  are  asked  the  following questions.

1.In how many avartan-s is the kaida set? 2.In which laya was the kaida played? 3.Identify the type of tihai played.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

1. Write into notation form the kaida of DhaTi in ekgun and dugun with two palta-s and a tihai set to teentaal.
2. 2.Recite,count and play the kaida of DhaTi in ekgun and dugun with two palta-s and a tihai set to teentaal.

## 3.5 RELA

Rela is  a  composition,  which  was  initially,  and  is  still,  being  played  on  the pakhawaj . Nowadays, rela is also widely played on the tabla .

It is believed that ustad-s and pandit-s from the field of pakhawaj and tabla , got inspired by the movement of the train, ' rel gari ' and composed the rela .

## Characteristics of a rela:

-  It is usually shorter in range compared to a kaida .
-  There is a continuous repetition of a particular syllable in a rela .
- Rela is always played in madhya or drut laya .
-  Same rules which are applied in a kaida are followed in a rela .

A rela can  be  composed in different taal-s such as in teentaal , roopak taal , jhaptal and  others.  It  is  played  in  a  solo  performance  or  while  providing accompaniment to instrumental music.

In this image we can see a pencil, a paper, a paper clip, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a

<!-- image -->

## 3.5.1 RELA OF 'GHIDA NAGA' SET TO TEENTAAL

| 13 14 15 16   | Ta Dhin Dhin Dha   | 3          | Tin Na Kida Naka Dhin Na Ghida Naga   | DhaSTit GhidaNaga DhinNa GhidaNaga DhaSTit GhidaNaga DhinNa GhidaNaga   | DhaSTit GhidaNaga TinNa KidaNaka DhaSTit GhidaNaga DhinNa GhidaNaga   | GhidaNaga DhaSTit GhidaNaga TinNa KidaNaka DhaSTit GhidaNaga DhinNa GhidaNaga   | GhidaNaga DhaSTit GhidaNaga TinNa KidaNaka GhidaNaga DhaSTit GhidaNaga DhinNa GhidaNaga   | DhaSTit GhidaNaga DhaSTit GhidaNaga DhaSTit GhidaNaga DhinNa GhidaNaga   | 3          |
|---------------|--------------------|------------|---------------------------------------|-------------------------------------------------------------------------|-----------------------------------------------------------------------|---------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|--------------------------------------------------------------------------|------------|
| 12            | Ta                 |            | Naga Naga                             | KidaNaka KidaNaka                                                       | GhidaNaga GhidaNaga                                                   | GhidaNaga                                                                       | SSSS                                                                                      | GhidaNaga                                                                |            |
| 11            | Tin                |            | Ghida Ghida                           | TaSTit TaSTit                                                           | DhaSTit DhaSTit DhaSTit                                               | DhaSTit DhaSTit DhaSTit                                                         | SSSS                                                                                      | DhaSTit                                                                  |            |
| 10            | Tin                |            | Tit Tit                               | KidaNaka KidaNaka                                                       | GhidaNaga GhidaNaga GhidaNaga                                         | GhidaNaga GhidaNaga GhidaNaga                                                   | SSSS                                                                                      | GhidaNaga                                                                |            |
| 9             | Dha                | 0          | DhaS DhaS                             | TaSTit TaSTit                                                           | DhaSTit DhaSTit DhaSTit                                               | DhaSTit DhaSTit DhaSTit                                                         | DhaSSS                                                                                    | DhaSTit                                                                  | 0          |
| 8             | Dha                |            | Naga Naka                             | KidaNaka KidaNaka                                                       | GhidaNaga GhidaNaga KidaNaka                                          | GhidaNaga KidaNaka KidaNaka                                                     | GhidaNaga                                                                                 | SSSS                                                                     |            |
| 7             | Dhin               |            | Ghida Kida                            | TinNa TinNa                                                             | SSSDha SSSDha SSSTa                                                   | SSTit SSTit SSSTa                                                               | DhinNa                                                                                    | SSSS                                                                     |            |
| 6             | Dhin               |            | Tit Tit                               | GhidaNaga GhidaNaga                                                     | GhidaNaga GhidaNaga KidaNaka                                          | GhidaNaga KidaNaka KidaNaka                                                     | GhidaNaga                                                                                 | SSSS                                                                     |            |
| 5             | Dha                | 2          | DhaS TaS                              | DhaSTit DhaSTit                                                         | DhaSTit SSSDha TaSTit                                                 | DhaSTit TaSTit SSSTa                                                            | DhaSTit DhaSSS                                                                            |                                                                          | 2          |
| 4             | Dha                |            | Naga Naka                             | GhidaNaga GhidaNaga                                                     | GhidaNaga GhidaNaga KidaNaka                                          | GhidaNaga KidaNaka KidaNaka                                                     | GhidaNaga GhidaNaga                                                                       |                                                                          |            |
| 3             | Dhin               |            | Ghida Kida                            | DhaSTit DhaSTit                                                         | SSSDha SSSDha SSSTa                                                   | SSTit SSTit SSSTa                                                               | DhaSTit DhinNa                                                                            |                                                                          |            |
| 1 2           | Dha Dhin           | x          | DhaS Tit Tas Tit                      | DhaSTit GhidaNaga DhaSTit GhidaNaga                                     | DhaSTit GhidaNaga DhaSTit GhidaNaga TaSTit KidaNaka                   | DhaSTit GhidaNaga TaSTit KidaNaka TaSTit KidaNaka                               | DhaSTit GhidaNaga DhaSTit GhidaNaga                                                       | Dha                                                                      | x          |
| Matra         | Theka              | Taal Signs | Rela (Ekgun)                          | Rela (Dugun)                                                            | Palta 1 Palta 2                                                       | Palta 3                                                                         | Tihai                                                                                     |                                                                          | Taal Signs |

<!-- image -->

Students should have learnt about:

The execution of the syllables ' GhidaNaga ' and ' KidaNaka ' with proper technique.

-   How to recite, count and play exercises in different patterns with the syllables ' GhidaNaga ' and ' KidaNaka '.

<!-- image -->

Some exercises to be played before playing the kaida .

| Matra      | 1    | 2    | 3     | 4    | 5    | 6    | 7     | 8    |
|------------|------|------|-------|------|------|------|-------|------|
| Exercise 1 | Ki   | da   | Na    | ka   | Ki   | da   | Na    | ka   |
| Exercise 2 | Ghi  | da   | Na    | ga   | Ghi  | da   | Na    | ga   |
| Exercise 3 | Kida | Naka | Ghida | Naga | Kida | Naka | Ghida | Naga |
| Exercise 4 | Dha  | Tit  | Ghida | Naga | Ta   | Tit  | Kida  | Naka |
| Exercise 5 | Tin  | Na   | Kida  | Naka | Dhin | Na   | Ghida | Naga |

The following steps are to be executed with reference to table shown in 3.5.1.

<!-- image -->

-   Memorise the rela .
- Padhant of the rela in ekgun at steady rhythm.
-  Execution of the rela in ekgun .
- Padhant of the rela in ekgun and dugun .
-  Execution of the rela in ekgun and dugun.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- Padhant of each palta.
-  Execution of each palta .

<!-- image -->

## Step    9

- Padhant of the tihai .
-  Execution of the Tihai .
- Padhant of the rela in ekgun and dugun with the given palta-s and tihai .
-  Execution of the rela in ekgun and dugun with the given palta-s and tihai .
-  A rela is a composition played on both the tabla and  the pakhawaj .
-  It is usually shorter in range compared to a kaida .
-  A rela has the same structure as a kaida .
-  A rela is usually played in madhya or drut laya .
-  A rela is either played in a tabla solo performance or while providing accompaniment to instrumental music.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a logo and a picture of a person.

<!-- image -->

Listen  to  the  teacher  playing  the rela of GhidaNaga in ekgun and dugun with two palta-s and tihai set to teentaal .

After listening, the students are grouped in different teams and are asked the following questions.

1. In how many avartans is the rela set?
2. In which laya was the rela played?
3. Identify the type of tihai played.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

1. (i) Define the term ' rela '.
2. (ii) Write into notation form a rela of ' GhidaNaga ' in ekgun and dugun with two palta-s and a tihai set to teentaal .

## Practical Assessment

- (iii) Recite, count and play the rela of ' GhidaNaga ' in ekgun and dugun with two palta-s and a tihai set to teentaal .

5 9 2 1 8 9 1 8 ( (

9 5 2 1 ( ( g 1 5 92 2 2 1

## 3.6.1  MOHARA-S SET TO TEENTAAL:

In this image, we can see a poster with some text and images.

<!-- image -->

| 16    | Dha   |            | TitKit   | TitKit   | TitKit   | TitKit   |            |
|-------|-------|------------|----------|----------|----------|----------|------------|
| 15    | Dhin  |            | DhinNa   | DhinNa   | NaDha    | TaKaTas  |            |
| 14    | Dhin  |            | Dhin     | SDha     | DhaGe    | TitKit   |            |
| 13    | Ta    | 3          | Ta       | DhinNa   | TitKit   | KidaNaka | 3          |
| 12    | Ta    |            | Ta       | Ta       | Ta       | Ta       |            |
| 11    | Tin   |            | Tin      | Tin      | Tin      | Tin      |            |
| 10    | Tin   |            | Tin      | Tin      | Tin      | Tin      |            |
| 9     | Dha   | 0          | Dha      | Dha      | Dha      | Dha      | 0          |
| 8     | Dha   |            | Dha      | Dha      | Dha      | Dha      |            |
| 7     | Dhin  |            | Dhin     | Dhin     | Dhin     | Dhin     |            |
| 6     | Dhin  |            | Dhin     | Dhin     | Dhin     | Dhin     |            |
| 5     | Dha   | 2          | Dha      | Dha      | Dha      | Dha      | 2          |
| 4     | Dha   |            | Dha      | Dha      | Dha      | Dha      |            |
| 3     | Dhin  |            | Dhin     | Dhin     | Dhin     | Dhin     |            |
| 2     | Dhin  |            | Dhin     | Dhin     | Dhin     | Dhin     |            |
| 1     | Dha   | x          | Dha      | Dha      | Dha      | Dha Dha  | x          |
| Matra | Theka | Taal Signs | Mohara 1 | Mohara 2 | Mohara 3 | Mohara 4 | Taal Signs |

<!-- image -->

Students should have learnt about:

-   How to recite, count and play the theka of teentaal at a steady rhythm.
-   How to recite, count and play different patterns with different groups of syllables.

The following steps are to be executed with reference to table shown in 3.6.1.

<!-- image -->

Padhant of the theka of teentaal at a steady rhythm.

-   Execution of the theka of teentaal at a steady rhythm.

## Step    2

<!-- image -->

-   Recite , count and play each mohara .

END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

1. (i) Define the term mohara . (ii)  Write into notation form two mohara-s set to teentaal
2. .

## Practical Assessment

1. Recite, count and play one mohara set to teentaal with the following ending syllables.
2. (a)  Tit Kit
3. (b)  TitKit TaKaTas TitKit

## 3.7 MUKHDA

A mukhda is a tabla composition usually played in a solo recital or while doing accompaniment.  It is a short composition , usually consisting of soft bol-s and ending  with a tihai . It is also characterised by a unique rhythmic fluency and form. A mukhda can be set to different taal-s , for example, teentaal , roopak taal , jhaptal . It is usually played in madhya or drut laya .

NOTE

There are some mukhda-s which do not end with a tihai.

Mukhda is also used in vocal hindustani music.It is the starting phrase of a song.

DID YOU KNOW

## 3.7.1 ONE EXAMPLE OF A MUKHDA IS GIVEN BELOW:

In this image we can see a poster with some text and images.

<!-- image -->

<!-- image -->

In the previous chapters, students have learnt about : ·   How to recite, count and play the theka of teentaal at a steady rhythm . ·    How to recite,count and play different patterns with different groups of syllables.

<!-- image -->

·  Playing different sets of syllables before playing the mukhda .

In this image, we can see a table with some text and numbers.

<!-- image -->

| 8     |            | Taka       |            |
|-------|------------|------------|------------|
| 7     |            | Kit        | Kit        |
| 6     | Ti         | Tit        | Tit        |
| 5     | Dha        | Tas        | Dhas       |
| 4     | Ti         | TaK        | Ti         |
| 3     | Dha        | Kit        | Dha        |
| 2     | Ti         | Tit        | Kit        |
| 1     | Dha        | Dhas       | Tit        |
| Matra | Exercise 1 | Exercise 2 | Exercise 3 |

9 1 8 9

## Step    2

- Padhant of the theka of Teentaal at a steady rhythm.
- Play the theka of Teentaal at a steady rhythm.
- Recite, count and play the different groups of syllables of the mukhda.

It can be split into three groups of syllables:

| Matra                   | 1       | 2       | 3      | 4       |
|-------------------------|---------|---------|--------|---------|
| 1 st group of syllables | DhaTi   | StDha   | Tist   | DhaS    |
| 2 nd group of syllables | DhasTit | KitTaka | TasTik | KitTaka |
| 3 rd group of syllables | TitKit  | TakaTaS | TitKit | DhaTi   |
| 4 th group of syllables | DhasTit | KitDhas | TiDha  | TitKit  |

- Recite, count and play the mukhda set to teentaal .

## A Mukhda:

- is a tabla composition which is played in a solo recital  and in accompaniment.
- is played from sam to sam .
- often ends with a tihai .
- can be set to different taal-s .
- is played in madhya and drut laya .

In this image, we can see a picture of a car.

<!-- image -->

To work in different groups where each group  will  recite,count  and  play  the different  phrases  of  the mukhda .Then, afterwards  they  will  do  same  for  the whole mukhda .

POINTS TO REMEMBER:

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

7

1. Write into notation form one mukhda set to teentaal .

## Practical assessment

1. Recite, count and play one mukhda set to teentaal.

## 3.8 PALTA

When slight changes are made in an original composition, it is known as a palta or variation. Palta-s are played in the different theka-s of the different taal-s , kaida-s , rela-s and so on. The variations are done using permutations of some syllables of the main tabla composition. However, the actual ways of permuting bol-s should be done in an orderly manner. Furthermore, when a palta is made, it is likely to be subject to some rules and regulations. For example:

- (i)   Any bol which does not figure in the basic composition should not be used in any palta .
- (ii)  Variations are done by the permutation of the main and other secondary basic bol-s of a composition.
- (iii)  The palta-s should be playable without any difficulty.
- (iv)  A particular bol should not be used too freely or frequently in order to prevent the listener from getting bored.

In this image, there is a poster with some text on it. The poster is in orange color. There is a pencil in the right corner of the image.

<!-- image -->

## Mohara:

-  Group of syllables replacing the main syllables at the end of the theka .
-  Provide a beautiful and shapely drive to the sam .
-  Can be played in different taal-s .

## 3.9  TIHAI

A tihai is the repetition of a rhythmic phrase three times consecutively ending on sam .Each rhythmic phrase is known as ' Palla ', and therefore a tihai consists of three palla-s .

Percussionists as well as other instrumentalists, vocalists and dancers, too,make use of tihai-s . A tihai normally indicates the end of a composition or a musical piece. It is also used to conclude a musical performance.

A tihai can be set to any taal . There are several types of tihai-s namely damdaar tihai , bedam tihai and chakradaar tihai .

## 3.9.1 DAMDAAR TIHAI

A damdaar tihai is one which consists of a pause at the end of each palla . It is punctuated with some moments of quiet or breathing space.

POINTS TO REMEMBER:

## 3.9.1.1  EXAMPLES OF 'DAMDAAR TIHAI' SET TO TEENTAAL

In this image I can see the text on the image.

<!-- image -->

| 13 14 15 16   | Ta Dhin Dhin Dha   | Dha Dha Tit Kit   |     | 3          | DhaDha TitKit DhaDha TitKit   | 3          | DhaTi DhaGe NaDha TitKit   |     | 3          |
|---------------|--------------------|-------------------|-----|------------|-------------------------------|------------|----------------------------|-----|------------|
| 12            | Ta                 | S                 |     |            | SS                            |            | SS                         |     |            |
| 11            | Tin                | Dha               |     |            | DhaS                          |            | DhaS                       |     |            |
| 10            | Tin                | Kit               |     |            | TitKit                        |            | TitKit                     |     |            |
| 9             | Dha                | Tit               |     | 0          | DhaDha                        | 0          | NaDha                      |     | 0          |
| 8             | Dha                | Dha               |     |            | TitKit                        |            | DhaGe                      |     |            |
| 7             | Dhin               | Dha               |     |            | DhaDha                        |            | DhaTi                      |     |            |
| 6             | Dhin               | S                 |     |            | SS                            |            | SS                         |     |            |
| 5             | Dha                | Dha               |     | 2          | DhaS                          | 2          | DhaS                       |     | 2          |
| 4             | Dha                | Kit               |     |            | TitKit                        |            | TitKit                     |     |            |
| 3             | Dhin               | Tit               |     |            | DhaDha                        |            | NaDha                      |     |            |
| 2             | Dhin               | Dha               |     |            | DhaDha TitKit                 |            | DhaGe                      |     |            |
| 1             | Dha                | Dha               | Dha | x          | Dha                           | x          | DhaTi                      | Dha | x          |
| Matra         | Theka              | Example 1         |     | Taal Signs | Example 2                     | Taal Signs | Example 2                  |     | Taal Signs |

In this image we can see a poster with some text and some images.

<!-- image -->

In this image I can see the numbers and text.

<!-- image -->

| 16    | ……   |            |     | ……     |     |            |
|-------|------|------------|-----|--------|-----|------------|
| 15    | …….  |            |     | …….    |     | 3          |
| 14    | …….  |            |     | .……    |     |            |
| 13    | …….. | 3          |     | .…….   |     |            |
| 12    | S    |            |     | ……     |     |            |
| 11    | Dha  |            |     | …….    |     |            |
| 10    | t    |            |     | …….    |     |            |
| 9     | Ti   | 0          |     | ……     |     | 0          |
| 8     | Dha  |            |     | .…..   |     |            |
| 7     | Dha  |            |     | ……     |     |            |
| 6     | S    |            |     | SS     |     |            |
| 5     | Dha  | 2          |     | DhaS   |     | 2          |
| 4     | t    |            |     | Tit    |     |            |
| 3     | Ti   |            |     | Tit    |     |            |
| 2     | Dha  |            |     | Tit    |     |            |
| 1     | Dha  | x          | Dha | DhaDha | Dha | x          |
| Matra | (1)  | Taal Signs |     | (2)    |     | Taal Signs |

3.9.2 BEDAM TIHAI

. It is not punctuated with palla

is one which does not consist of any pause at the end of each bedam tihai

A

.

damdaar tihai some moments of quiet or breathing space compared to

## 3.9.2.1 EXAMPLES OF 'BEDAM TIHAI' SET TO TEENTAAL

| 13 14 15 16   | Ta Dhin Dhin Dha   | 3          | Ti t Ti t   |     | 3          | Tit DhaDhaDhinNa DhaDha   |     | 3          |
|---------------|--------------------|------------|-------------|-----|------------|---------------------------|-----|------------|
| 12            | Ta                 |            | Dha         |     |            | DhaDha                    |     |            |
| 11            | Tin                |            | Dha         |     |            | DhaDha                    |     |            |
| 10            | Tin                |            | t           |     |            | NaDha                     |     |            |
| 9             | Dha                | 0          | Ti          |     | 0          | DhaDhin                   |     | 0          |
| 8             | Dha                |            | t           |     |            | tDha                      |     |            |
| 7             | Dhin               |            | Ti          |     |            | DhaTi                     |     |            |
| 6             | Dhin               |            | Dha         |     |            | DhaDha                    |     |            |
| 5             | Dha                | 2          | Dha         |     | 2          | DhaDha                    |     | 2          |
| 4             | Dha                |            | t           |     |            | DhinNa                    |     |            |
| 3             | Dhin               |            | Ti          |     |            | DhaDha                    |     |            |
| 2             | Dhin               |            | t           |     |            | Tit                       |     |            |
| 1             | Dha                | x          | Ti          | Dha | x          | DhaDha                    | Dha | x          |
| Matra         | Theka              | Taal Signs | Example 1   |     | Taal Signs | Example 2                 |     | Taal Signs |

Complete the following bedam tihai-s with  the appropriate missing syllables  in  the  table given below.

ACTIVITY

1

In this image I can see the numbers and text.

<!-- image -->

| 16    | …..   |            |     | ...…    |     |            |
|-------|-------|------------|-----|---------|-----|------------|
| 15    | …..   |            |     | ..…     |     |            |
| 14    | …..   |            |     | .….     |     |            |
| 13    | …..   | 3          |     | …..     |     | 3          |
| 12    | …..   |            |     | …..     |     |            |
| 11    | …..   |            |     | DhaDha  |     |            |
| 10    | …..   |            |     | NaDha   |     |            |
| 9     | …..   | 0          |     | DhaDhin |     | 0          |
| 8     | …..   |            |     | KitDha  |     |            |
| 7     | …..   |            |     | DhaTit  |     |            |
| 6     | Dha   |            |     | DhaDha  |     |            |
| 5     | Dhati | 2          |     | DhaDha  |     | 2          |
| 4     | TaTa  |            |     | DhinNa  |     |            |
| 3     | GeGe  |            |     | DhaDha  |     |            |
| 2     | TaTa  |            |     | TitKit  |     |            |
| 1     | GeGe  | x          | Dha | DhaDha  | Dha | x          |
| Matra | (1)   | Taal Signs |     | (2)     |     | Taal Signs |

3.9.3  CHAKRADAAR TIHAI

' of the

Dha is repeated three times consecutively and where the last '

tihai is one where a

chakradaar tihai

A

.

damdaar or

bedam first two rounds is omitted. It can be

It is a tihai which is longer in range. As a rule, chakradaar tihai-s are played at fast speed, and they generally provide  a  climactic  finale  to  a  solo  recital. They  are  also  mostly  used  in  the  accompaniment  of  stringed instruments such as the sitar , santoor , sarod and others. They are also used in kathak dance.

## 3.9.2.1 EXAMPLES OF 'CHAKRADAAR TIHAI' SET TO TEENTAAL

| 16 Dha      |            | t         | t   | t   |     |            | Kit       | Kit   | Kit   |     |            |
|-------------|------------|-----------|-----|-----|-----|------------|-----------|-------|-------|-----|------------|
| 15 Dhin     |            | Ti        | Ti  | Ti  |     |            | Tit       | Tit   | Tit   |     |            |
| 14 Dhin     |            | Dha       | Dha | Dha |     |            | Dha       | Dha   | Dha   |     |            |
| 13 Ta       | 3          | Dha       | Dha | Dha |     | 3          | Dha       | Dha   | Dha   |     | 3          |
| 12 Ta       |            | S         | S   | S   |     |            | S         | S     | S     |     |            |
| 11 Tin      |            | Dha       | Dha | Dha |     |            | Dha       | Dha   | Dha   |     |            |
| 10 Tin      |            | t         | t   | t   |     |            | Kit       | Kit   | Kit   |     |            |
| 9 Dha       | 0          | Ti        | Ti  | Ti  |     | 0          | Tit       | Tit   | Tit   |     | 0          |
| 8 Dha       |            | Dha       | Dha | Dha |     |            | Dha       | Dha   | Dha   |     |            |
| 7 Dhin      |            | Dha       | Dha | Dha |     |            | Dha       | Dha   | Dha   |     |            |
| 6 Dhin      |            | S         | S   | S   |     |            | S         | S     | S     |     |            |
| 5 Dha       | 2          | Dha       | Dha | Dha |     | 2          | Dha       | Dha   | Dha   |     | 2          |
| 4 Dha       |            | t         | t   | t   |     |            | Kit       | Kit   | Kit   |     |            |
| 3 Dhin      |            | Ti        | Ti  | Ti  |     |            | Tit       | Tit   | Tit   |     |            |
| 2 Dhin      |            | Dha       | Dha | Dha |     |            | Dha       | Dha   | Dha   |     |            |
| 1 Dha       | x          | Dha       | Dha | Dha | Dha | x          | Dha       | Dha   | Dha   | Dha | x          |
| Matra Theka | Taal Signs | Example 1 |     |     |     | Taal Signs | Example 2 |       |       |     | Taal Signs |

In this image I can see a paper with some text on it.

<!-- image -->

The above Tihai is usually  played  in madhya or drut laya.

NOTE

In this image, we can see a paper with a paper clip and some text on it.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Describe the theka-s prescribed.
- Distinguish among the different types of theka-s and their uses in vocal forms.
- Play the prescribed theka-s in single and double speed.
- Play the prescribed theka-s with variations.
- Play appropriate theka-s with proper technique (Nikaas), relevant to each vocal form.
- Appreciate the theka-s played in vocal forms.
- Practise the different theka-s with vocal and instrumental forms.
- Create and play variations of prescribed theka-s.

## 4.1 DADRA TAAL

Matra:

Vibhaag:

In this image we can see a poster with some text and images.

<!-- image -->

## 4.1.1   NOTATION WRITING OF THE THEKA OF DADRA TAAL IN EKGUN WITH TWO PALTA-S

| Matra             | 1      | 2        | 3    | 4      | 5      | 6    |
|-------------------|--------|----------|------|--------|--------|------|
| Theka (Ekgun)     | Dha    | Dhin     | Na   | Dha    | Tin    | Na   |
| Taal Signs        | X      |          |      | 0      |        |      |
| Palta/Variation 1 | DhaDha | DhinDhin | NaNa | DhaDha | TinTin | NaNa |
| Palta/Variation 2 | DhaGe  | DhinNa   | NaNa | TaKe   | DhinNa | NaNa |
|                   | Dha    |          |      |        |        |      |
| Taal Signs        | X      |          |      | 0      |        |      |

<!-- image -->

## Students should have learnt about:

The execution of the basic syllables ' Ge ', ' Na ', ' Tin ' ' Dha ' and ' Dhin ' individually and in different patterns.

<!-- image -->

The execution of the theka of dadra taal in ekgun .

The action of the hands and fingers while counting the taal .

<!-- image -->

- Padhant of the theka in single speed with palta-s .
- Executing the theka in single speed ( ekgun ).
- Executing the variations.

<!-- image -->

| Beats   | 1   | 2    | 3   | 4   | 5   | 6   |
|---------|-----|------|-----|-----|-----|-----|
|         | Dha | Dhin | Na  | Dha | Tin | Na  |

<!-- image -->

| Beats   | 1 2 3 4 5 6                             |
|---------|-----------------------------------------|
|         | DhaDha DhinDhin NaNa DhaDha TinTin NaNa |
|         | DhaGe DhinNa NaNa TaKe DhinNa NaNa      |

In this image, we can see a picture of a book.

<!-- image -->

## 4.2  ROOPAK TAAL

Matra:

Vibhaag:

In this image we can see a poster with some text and some images.

<!-- image -->

## 4.2.1   NOTATION WRITING OF THE THEKA OF ROOPAK TAAL IN EKGUN WITH TWO PALTA-S

| Matra             | 1   | 2   | 3    | 4       | 5       | 6              | 7    |
|-------------------|-----|-----|------|---------|---------|----------------|------|
| Theka (Ekgun)     | Tin | Tin | Na   | Dhin    | Na      | Dhin           | Na   |
| Taal Signs        | x   |     |      | 2       |         | 3              |      |
| Palta/Variation 1 | Tin | Tin | Na   | DhinNa  | GiNa    | DhinNa         | GiNa |
| Palta/Variation 2 | Tin | Tin | NaNa | DhaDhin | DhinDha | DhaDhinDhinDha |      |
|                   | Tin |     |      |         |         |                |      |
| Taal Signs        | x   |     |      | 2       |         | 3              |      |

<!-- image -->

## Students should have learnt about:

- Execution of the basic syllables ' Na ', ' Tin ' and ' Dhin ' individually and in different patterns.
- Execution of the theka of roopak taal in ekgun .
- Action of the hands and fingers while counting the taal .
- Padhant of the theka in single speed with palta-s .
- Executing the theka in single speed ( ekgun ).
- Executing the palta-s .

<!-- image -->

<!-- image -->

| Beats   | 1   | 2   | 3   | 4    | 5   | 6    | 7   |
|---------|-----|-----|-----|------|-----|------|-----|
|         | Tin | Tin | Na  | Dhin | Na  | Dhin | Na  |

<!-- image -->

| Beats   | 1   | 2   | 3    | 4       | 5       | 6       | 7       |
|---------|-----|-----|------|---------|---------|---------|---------|
|         | Tin | Tin | NaNa | DhinNa  | GiNa    | DhinNa  | GiNa    |
|         | Tin | Tin | NaNa | DhaDhin | DhinDha | DhaDhin | DhinDha |

<!-- image -->

In this image we can see a paper with some text and a picture of a person.

<!-- image -->

## 4.3 KAHERWA TAAL

Matra:

Vibhaag:

In this image we can see a poster with some text and some images.

<!-- image -->

## 4.3.1   NOTATION WRITING OF THE THEKA OF KAHERWA TAAL IN EKGUN WITH TWO PALTA-S

| Matra             | 1      | 2   | 3   | 4   | 5   | 6   | 7     | 8    |
|-------------------|--------|-----|-----|-----|-----|-----|-------|------|
| Theka             | Dha    | Ge  | Na  | Ti  | Na  | Ka  | Dhi   | na   |
| Taal Signs        | X      |     |     |     | 0   |     |       |      |
| Palta/Variation 1 | DhaDha | Ge  | Na  | Ti  | Na  | Ka  | Dhina | Gina |
| Palta/Variation 2 | DhaDha | Ge  | Na  | Ti  | Na  | Ka  | DhaTi | GeNa |
|                   | Dha    |     |     |     |     |     |       |      |
| Taal Signs        | X      |     |     |     | 0   |     |       |      |

<!-- image -->

## Students should have learnt about:

- The execution of the basic syllables ' Ge ', ' Na ', ' Tin ',' Ka '  and
- ' Dha '  individually and in different patterns.
- The execution of the syllable ' na ' (played with the ring finger).
- The execution of the theka of kaherwa taal in ekgun .
- The action of the hands and fingers while counting the taal .
- Padhant of the theka in single speed with palta-s .
- Executing the theka at single speed ( ekgun ).
- Executing the palta-s .

<!-- image -->

<!-- image -->

| Beats   | 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   |
|---------|-----|-----|-----|-----|-----|-----|-----|-----|
|         | Dha | Ge  | Na  | Ti  | Na  | Ka  | Dhi | na  |

<!-- image -->

| Beats   | 1 2 3     |    | 4   | 5   | 6   | 7     | 8    |
|---------|-----------|----|-----|-----|-----|-------|------|
|         | DhaDha Ge | Na | Ti  | Na  | Ka  | Dhina | Gina |
|         | DhaDha Ge | Na | Ti  | Na  | Ka  | DhaTi | Gena |

<!-- image -->

In this image there is a logo and a text.

<!-- image -->

## 4.4 JHAPTAL

Matra:

Vibhaag:

In this image, we can see a poster with some text and some images.

<!-- image -->

## 4.4.1     NOTATION WRITING OF THE THEKA OF JHAPTAL  IN   EKGUN WITH TWO PALTA-S

| Matra              | 1    | 2    | 3      | 4    | 5    | 6   | 7   | 8      | 9    | 10   |
|--------------------|------|------|--------|------|------|-----|-----|--------|------|------|
| Theka (Ekgun)      | Dhin | Na   | Dhin   | Dhin | Na   | Tin | Na  | Dhin   | Dhin | Na   |
| Taal Signs         | X    |      | 2      |      |      | 0   |     | 3      |      |      |
| Palta/ Variation 1 | Dhin | Na   | DhinNa | Dhin | Na   | Tin | Na  | DhinNa | Dhin | Na   |
| Palta/ Variation 2 | Dhin | NaNa | DhinNa | Dhin | NaNa | Tin | Na  | DhinNa | Dhin | NaNa |
|                    | Dhin |      |        |      |      |     |     |        |      |      |
| Taal Signs         | X    |      | 2      |      |      | 0   |     | 3      |      |      |

<!-- image -->

## Students should have learnt about:

- The execution of basic syllables ' Na ', ' Tin ' and ' Dhin ' individually and in different patterns.
- The execution of the theka of Jhaptal in single speed.
- The action of the hands and fingers while counting the taal .
- Padhant of the theka in single speed with palta-s .
- Executing the theka at single speed ( ekgun ).
- Executing the palta-s .

<!-- image -->

<!-- image -->

<!-- image -->

| Beats   | 1    | 2   | 3    | 4    | 5   | 6   | 7   | 8    | 9    | 10   |
|---------|------|-----|------|------|-----|-----|-----|------|------|------|
|         | Dhin | Na  | Dhin | Dhin | Na  | Tin | Na  | Dhin | Dhin | Na   |

<!-- image -->

| Beats   | 1    | 2    | 3      | 4    | 5    | 6   | 7   | 8      | 9    | 10   |
|---------|------|------|--------|------|------|-----|-----|--------|------|------|
|         | Dhin | Na   | DhinNa | Dhin | Na   | Tin | Na  | DhinNa | Dhin | Na   |
|         | Dhin | NaNa | DhinNa | Dhin | NaNa | Tin | Na  | DhinNa | Dhin | NaNa |

In this image, we can see a circular object. In the background, we can see a brown color surface.

<!-- image -->

## 4.5   DIPCHANDI TAAL:

## 4.5.1  DESCRIPTION:

Dipchandi  taal is  a  rhythmic  cycle  consisting  of  14  beats.  There  are  four vibhaag-s divided by three khand-s . Sam is found on the first beat and khali on the eighth beat. It is usually played in folk and light music.

Matra:

Vibhaag:

In this image, we can see a poster with some text and images.

<!-- image -->

## 4.5.1.1   NOTATION WRITING OF THE THEKA OF TAAL DIPCHANDI IN EKGUN WITH TWO PALTA-S

| Matra              | 1        | 2    | 3   | 4   | 5   | 6   | 7   | 8    | 9   | 10   | 11   | 12   | 13   | 14   |
|--------------------|----------|------|-----|-----|-----|-----|-----|------|-----|------|------|------|------|------|
| Theka (Ekgun)      | Dha      | Dhin | S   | Dha | Ge  | Tin | S   | Ta   | Tin | S    | Dha  | Ge   | Dhin | S    |
| Taal Signs         | X        |      |     | 2   |     |     |     | 0    |     |      | 3    |      |      |      |
| Palta/ Variation 1 | Dha      | Dhin | na  | Dha | Ge  | Tin | na  | Ta   | Tin | na   | Dha  | Ge   | Dhin | na   |
| Palta/ Variation   | DhaDha 2 | Dhin | na  | Dha | Ge  | Tin | na  | TaTa | Tin | na   | Dha  | Ge   | Dhin | na   |
|                    | Dha      |      |     |     |     |     |     |      |     |      |      |      |      |      |
| Taal Signs         | X        |      |     | 2   |     |     |     | 0    |     |      | 3    |      |      |      |

<!-- image -->

<!-- image -->

- Padhant of the theka and the palta-s at single speed under the guidance of teacher.
- Executing the theka at single speed ( ekgun ).
- Executing the palta-s .

<!-- image -->

| Beats   | 1   | 2    | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10   | 11   | 12   | 13   | 14   |
|---------|-----|------|-----|-----|-----|-----|-----|-----|-----|------|------|------|------|------|
|         | Dha | Dhin | S   | Dha | Ge  | Tin | S   | Ta  | Tin | S    | Dha  | Ge   | Dhin | S    |

<!-- image -->

<!-- image -->

| Beats   | 1   | 2    | 3   | 4   | 5   | 6      | 7 8    | 9   | 10   | 11 12   |      | 13 14   |
|---------|-----|------|-----|-----|-----|--------|--------|-----|------|---------|------|---------|
|         | Dha | Dhin | na  | Dha | Ge  | Tin na | Ta Tin | na  | Dha  | Ge      | Dhin | na      |

In this image we can see a poster with some text and a logo.

<!-- image -->

## ACTIVITY 1

Create and count one palta set to taal dipchandi .

## ACTIVITY 2

Recite, count and play the theka of taal dipchandi in ekgun with two palta-s.

ACTIVITY

## 4.6   EKTAAL

## 4.6.1 INTRODUCING TABLA SYLLABLES 'KAT'

' KaT ' is played by striking the tips of the four fingers (index, middle, ring and small finger) in the centre of the syahi to create a non - resonant sound.

## 4.6.1.1 DESCRIPTION OF EKTAAL:

<!-- image -->

Ektaal is a rhythmic cycle consisting of twelve beats. There are six vibhaag-s divided by five khand-s .

Sam is found on the first beat and khali on the third and seventh beat. It is usually played in classical and semi classical music.

Matra:

Vibhaag:

In this image, we can see a poster with some text and images.

<!-- image -->

4.6.1.2  NOTATION WRITING OF THE THEKA OF EKTAAL  IN EKGUN AND WITH TWO PALTA-S

| Matra             | 1    | 2        | 3     | 4      | 5   | 6    | 7   | 8   | 9     | 10     | 11   | 12   |
|-------------------|------|----------|-------|--------|-----|------|-----|-----|-------|--------|------|------|
| Theka (Ekgun)     | Dhin | Dhin     | DhaGe | TitKit | Tin | Na   | Kat | Ta  | DhaGe | TitKit | Dhin | Na   |
| Taal Signs        | x    |          | 0     |        | 2   |      | 0   |     | 3     |        | 4    |      |
| Palta/Variation 1 | Dhin | Dhin     | DhaGe | TitKit | Tin | NaNa | Kat | Ta  | DhaGe | TitKit | Dhin | NaNa |
| Palta/Variation 2 | Dhin | DhinDhin | DhaGe | TitKit | Tin | NaNa | Kat | Ta  | DhaGe | TitKit | Dhin | NaNa |
|                   | Dhin |          |       |        |     |      |     |     |       |        |      |      |
| Taal Signs        | x    |          | 0     |        | 2   |      | 0   |     | 3     |        | 4    |      |

<!-- image -->

<!-- image -->

- Padhant of the theka and the palta-s at single speed under the guidance of  the teacher.
- Executing the theka at single speed ( ekgun ).
- Executing the variations.

<!-- image -->

| Beats   | 1    | 2    | 3     | 4      | 5   | 6   | 7   | 8   | 9     | 10 11       | 12   |
|---------|------|------|-------|--------|-----|-----|-----|-----|-------|-------------|------|
|         | Dhin | Dhin | DhaGe | TitKit | Tin | Na  | Kat | Ta  | DhaGe | TitKit Dhin | Na   |

<!-- image -->

| Beats 1 2 3 4 5 6 7 8 9 10 11 12                                  |
|-------------------------------------------------------------------|
| Dhin Dhin DhaGe TitKit Tin NaNa Kat Ta DhaGe TitKit Dhin NaNa     |
| Dhin DhaGe TitKit Tin NaNa Kat Ta DhaGe TitKit Dhin NaNa DhinDhin |

In this image, we can see a picture of a book. On the book, we can see some text.

<!-- image -->

## 4.6.2 EKTAAL IN DUGUN

Matra:

Vibhaag: 2-2-2-2-2-2 Khali:

In this image we can see a logo.

<!-- image -->

12

Tali:

1 st ,5 th ,9 th and 11 th  beat

3 rd and 7 th  beat

## 4.6.2.1    NOTATION WRITING OF THE THEKA OF EKTAAL IN DUGUN

| Matra         | 1                    | 2           | 3 4          | 5      | 6 7                  | 8   | 9 10         | 11          | 12     |
|---------------|----------------------|-------------|--------------|--------|----------------------|-----|--------------|-------------|--------|
| Theka (Ekgun) | Dhin                 | Dhin        | DhaGe TitKit | Tin Na | Kat                  | Ta  | DhaGe TitKit | Dhin        | Na     |
| Taal Signs    | x                    | 0           |              | 2      | 0                    |     | 3            | 4           |        |
| Dugun         | DhinDhin DhaGeTitKit | TitNa KatTa | DhaGeTitKit  | DhinNa | DhinDhin DhaGeTitKit |     | TinNa KatTa  | DhaGeTitKit | DhinNa |
|               | Dhin                 |             |              |        |                      |     |              |             |        |
| Taal Signs    | x                    | 0           |              | 2      | 0                    |     | 3            | 4           |        |

The song ' kaahe cher mohe ' from the film ' Devdas '  is set to ektaal.

DID YOU KNOW

<!-- image -->

## In the previous chapters, students have learnt about:

- The execution of the basic syllables ' Ge ', ' Na ', 'Tin' and ' Dhin individually and different patterns.
- The execution of the syllables ' KaT '.
- The execution of the theka of Ektaal in single speed.
- Action of the hands and fingers while counting the taal .
- Padhant of the theka and the palta-s at single speed under the guidance of teacher.
- Executing the theka at single speed ( ekgun ).
- Executing the theka in dugun

<!-- image -->

<!-- image -->

<!-- image -->

| Beats   | 1    | 2 3        | 4      | 5   | 6   | 7   | 8   | 9     | 10     | 11   | 12   |
|---------|------|------------|--------|-----|-----|-----|-----|-------|--------|------|------|
|         | Dhin | Dhin DhaGe | TitKit | Tin | Na  | Kat | Ta  | DhaGe | TitKit | Dhin | Na   |

<!-- image -->

<!-- image -->

| Beats   | 1 2 3 4 5 6 7 8 9 10 11 12                                                                             |
|---------|--------------------------------------------------------------------------------------------------------|
|         | DhinDhin DhaGeTitKit TinNa KatTa DhaGeTitKitDhinNa DhinDhin DhaGeTitKit TinNa KatTa DhaGeTitKit DhinNa |

## 4.7 TEENTAAL

Matra:

Vibhaag:

In this image we can see a poster with some text and some images.

<!-- image -->

## 4.7.1   NOTATION WRITING OF THE THEKA OF  TEENTAAL IN EKGUN WITH TWO PALTA-S

| Matra              | 1          | 2         | 3    | 4      | 5   | 6    | 7                   | 8   | 9     | 10   | 11       | 12   | 13   | 14                 | 15   | 16   |
|--------------------|------------|-----------|------|--------|-----|------|---------------------|-----|-------|------|----------|------|------|--------------------|------|------|
| Theka              | Dha        | Dhin      | Dhin | Dha    | Dha | Dhin | Dhin                | Dha | Dha   | Tin  | Tin      | Ta   | Ta   | Dhin               | Dhin | Dha  |
| Taal Signs         | X          |           |      |        | 2   |      |                     |     | 0     |      |          |      | 3    |                    |      |      |
| Palta/ Variation 1 | Dhage Dhin | Dhin      |      | Dha    | Dha | Dhin | Dhin                | Dha | Dhage | Tin  | Tin      | Ta   | TaKe | Dhin               | Dhin | Dha  |
| Palta/ Variation 2 | Dhage      | Dhin Dhin |      | DhaDha |     |      | DhageDhinDhinDhaDha |     | Dhage | Tin  | Tin TaTa |      |      | TaKeDhinDhinDhaDha |      |      |
|                    | Dha        |           |      |        |     |      |                     |     |       |      |          |      |      |                    |      |      |
| Taal Signs         | X          |           |      |        | 2   |      |                     |     | 0     |      |          |      | 3    |                    |      |      |

<!-- image -->

## In the previous chapters, students have learnt about:

- The execution of the basic syllables ' Ge ', ' Na ', 'Tin','Dha' and ' Dhin ' individually and different patterns.
- The execution of the theka of teentaal in single speed.
- Action of the hands and fingers while counting the taal .
- Padhant of the theka and the palta-s at single speed under the guidance of teacher.
- Executing the theka at single speed ( ekgun ).
- Executing the palta 1.
- Executing the palta 2.

<!-- image -->

<!-- image -->

<!-- image -->

| Beats   | 1 2 3 4           | 5 6 7 8 9 10 11 12 13 14 15 16                    |
|---------|-------------------|---------------------------------------------------|
|         | Dha Dhin Dhin Dha | Dha Dhin Dhin Dha Dha Tin Tin Ta Ta Dhin Dhin Dha |

<!-- image -->

| Matra   | 1 2 3 4 5       | 6 7 8 9           | 10 11 12   | 13 14 15 16         |                |     |
|---------|-----------------|-------------------|------------|---------------------|----------------|-----|
|         | Dhage Dhin Dhin | Dha Dha Dhin Dhin |            | Dha DhageTin Tin Ta | TaKe Dhin Dhin | Dha |

<!-- image -->

| Matra   | 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16                                                 |
|---------|----------------------------------------------------------------------------------------|
|         | Dhage Dhin Dhin DhaDha Dhage Dhin Dhin DhaDha Dhage Tin Tin TaTa TaKe Dhin Dhin DhaDha |

| Beats   | 1   | 2       | 3   | 4   | 5   | 6       | 7   | 8 9     |     | 10   | 11   | 12   | 13   | 14   |
|---------|-----|---------|-----|-----|-----|---------|-----|---------|-----|------|------|------|------|------|
|         | Dha | ....... | S   | Dha | Ge  | ....... | S   | ....... | Tin | S    | Dha  | Ge   | Dhin | S    |

In this image, we can see a poster with some text and images.

<!-- image -->

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

## Briefly explain the different characteristics of the following taal-s:

- a. Teentaal
- b. Roopak Taal
- c. Keherwa Taal

In this image, we can see a paper with a paper clip and a paper.

<!-- image -->

In this image we can see a woman holding a musical instrument.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Explain briefly the following key terms: sthayi , antara and mukhda .
- List the different characteristics of naad .
- Elaborate on the characteristics of naad .

## 5.1 NAAD

Naad refers to sound in music. There are two types of naad : ahatt naad and anahatt naad . Ahatt  naad is  the  sound  which  can  be  heard  by  anybody, whereas  the anahatt  naad can  only  be  heard  through  high  level  of meditation.

## 5.1.1 CHARACTERISTICS OF NAAD

Naad has three main characteristics,which are pitch, timbre and magnitude.

## 5.1.1.1 PITCH:

It is the number of vibrations per second of a particular sound wave. This is also known as the frequency of the sound measured in terms of Hertz (Hz). Sound  waves  can  be  emitted  through  different  sources,  for  example  a tuning  fork,  a  vibrating  string,  a  musical  instrument,  human  voice  and others. Each musical note has a different pitch.

In this image, we can see a poster with some text and images. We can also see a graph and a line chart.

<!-- image -->

The above graphs represent a number of wave cycles during a particular time.The  more  the  number  of  wave  cycles  during  a  particular  time,  the higher the pitch. A sound with a high  pitch has a high frequency, and that with a low pitch  has a low frequency.

## 5.1.1.2 TIMBRE:

Timbre is known as the quality of a sound. The timbre changes when sound is emitted through different media. For example, the voice of a person can be  recognized  by  its  timbre.  The  sound  produced  by  each  person  while talking is usually different.Moreover, each musical instrument has its own timbre.

In this image we can see some musical instruments.

<!-- image -->

Timber makes a particular musical sound different from another, even if they are at the same pitch and loudness.

## 5.1.1.3 MAGNITUDE:

It is the force or intensity of sound. Magnitude is also the degree of softness or loudness of a particular sound which we usually call the volume. The magnitude of a sound is measured in terms of decibel (dB).

<!-- image -->

In this image we can see a bird, a sound wave, a metal object and a text.

<!-- image -->

The higher the amplitude of a sound wave, the higher is its magnitude or volume and a sound with a low volume has a wave with a lower amplitude.

In this image, we can see a picture of a circle.

<!-- image -->

https://www.youtube.com/watch?v=Cpjs9\_BGedY

## Class presentation

Can you briefly explain the difference between pitch, timbre and magnitude to your classmates after having watched the video?

## 5.2 STHAYI:

Sthayi is  the  first  part  of  a  musical  composition. It is the first stanza in a song. The sthayi is  sung or played repeatedly using the same notes and lyrics. Swara-s from the mandra and madhya saptak are usually used in a sthayi .

## 5.3 ANTARA:

Antara is always sung or played after the sthayi . It is that part of a musical composition that is sung or played only once. There can be more than one antara in  a  particular  composition. Swara-s from  the madhya and taar saptak-s are usually used in an antara .

## 5.4 MUKHDA:

Mukhda is the starting phrase of a musical composition which leads to the sam . It can start from any beat of a taal and is found in the sthayi itself. It is usually the first line of a composition. Mukhda is  mostly used in classical music.

In this image we can see a pencil and a text.

<!-- image -->

- Naad means sound.
- Ahatt naad is sound which can be heard by anybody.
- Ahanatt naad is sound which can only be heard through high level of meditation.
- Pitch is the number of vibrations per second of a particular sound (Frequency).
- Timbre is the quality of the sound.
- Magnitude is the force or intensity of the sound.
- Sthayi is the first part of a song.
- Antara is the other parts after the sthayi in a song.
- Mukhda is the first line in a sthayi. It is usually used in classical music.

<!-- image -->

<!-- image -->

## 1. https://www.youtube.com/watch?v=xipue67yfPQ

Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re Par Dukkhe upkaar kare toye Man abhiman na anne re Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re

Sakal lok maan Sahune Vandhe, Ninda Na kare kainee re Baach kaachh, Man nischal Raakhe, Dhan-Dhan jananee tainee re Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re

Sam-Drishtine trishna tyaagi Par-stree jene maat re Jivha thaki asatya na bole

Par-Dhan nav jhale haath re Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re

Moha-Maaya vyaape nahi jene Dridh vairaagya jena man maan re Ram-naam-shoon taali laagi Sakal tirath tena tan ma re Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re

Van-Lobhi ne kapat rahit chhe Kaam-Krodh nivaarya re Bhane Narsaiyyo tenu darshan karta Kul ekoter taarya re…

Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re Par Dukkhey upkar karey toyey Man abhiman na anne re Vaishnav Jan To, Tene Kahiye Je Peed Paraaye Jaane Re

## Questions:

- (i)   Identify  the sthayi and antara in the above song.
- (ii)  How many antara-s are there in the above song?
- (iii) Can you sing the sthayi ?
- (iv) Name the taal in which the above song has been sung.
2. https://www.youtube.com/watch?v=KVfz7GCp7x8
- (i) Identify the sthayi, antara and mukhda in the above video.

<!-- image -->

'Don't let your voice sound like all the other noises today. Be LOUD, Be CLEAR, and make a Difference!' - Mary Riesberg

## END OF CHAPTER QUESTIONS ASSESSMENT

Assessment

1

## Explain briefly the following key terms:

- (i) sthayi
- (ii) antara
- (iii) mukhda.

Assessment

2

Explain the term naad, and elaborate on its characteristics.

……………………………………………………………………………………...

……………………………………………………………………………………...

……………………………………………………………………………………

………………………………………………………………………………..........

Assessment

3

Fill in the blanks with the appropriate words given in bracket below: (mukhda, antara, sthayi, timbre, magnitude)

- (i)   ………………… is known as the quality of sound.
- (ii)  A song can have only one ……………….. .
- (iii) The amplitude of a sound wave determines its …………………. .
- (iv)  ………………………is that phrase which usually leads to the sam in hindustani classical vocal music.
- (v)  A song can consist of more than one ………………. .

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Memorise the different types of compositions.
- Examine the structure of each rhythmic cycle and its salient features.
- Identify each variety of a theka with specific types of vocal forms.
- Play the theka-s with variations and tihai-s .
- Play a variety of each theka .
- Play laggi-s , laddi-s set in the prescribed rhythmic cycles in single and double speed.
- Play tihai-s set to the prescribed rhythmic cycles.
- Play prescribed compositions individually or in group.
- Appreciate the gait of laggi-s , ladi-s and variety of theka-s .
- Demonstrate their creative skills through improvisations and compositional work.

## 6.1 DADRA TAAL

Matra:

Vibhaag:

In this image we can see a poster with some text and some images.

<!-- image -->

## 6.1.1   NOTATION WRITING OF THE THEKA OF DADRA TAAL WITH TWO PALTA-S:

| Matra             | 1     | 2    | 3    | 4     | 5   | 6    |
|-------------------|-------|------|------|-------|-----|------|
| Theka (Ekgun)     | Dha   | Dhin | Na   | Dha   | Tin | Na   |
| Taal Signs        | X     |      |      | 0     |     |      |
| Palta/Variation 1 | Dha   | Dhin | NaNa | Dha   | Tin | NaNa |
| Palta/Variation 2 | DhaGe | Dhin | NaNa | DhaGe | Tin | NaNa |
|                   | Dha   |      |      |       |     |      |
| Taal Signs        | X     |      |      | 0     |     |      |

## 6.1.2  SOME PRAKAR OF DADRA TAAL ARE GIVEN BELOW:

| Matra             | 1         | 2            | 3    | 4        | 5              | 6         |
|-------------------|-----------|--------------|------|----------|----------------|-----------|
| Theka (Ekgun)     | Dha       | Dhin         | Na   | Dha      | Tin            | Na        |
| Taal Signs        | X         |              |      | 0        |                |           |
| Prakar 1          | Dha       | Tin          | Tin  | Ta       | Dhin           | Dhin      |
| Palta/Variation 1 | Dha       | Tin          | Tin  | Taka     | Dhin           | Dhin      |
| Palta/Variation 2 | Dha       | Tin          | Taka | Taka     | Dhin           | Dhin      |
| Palta/Variation 3 | Dha       | Tin          | Taka | Taka     | DhinNa         | GiNa      |
| Palta/Variation 4 | Dha       | Tin          | Tin  | TaKaTit  | KitTaKa        | TitKit    |
| Palta/Variation 5 | Dha       | Tin          | Tin  | TaT      | aKiNaTaTaKiNaT | aTaKiNa   |
| Tihai             | TaT aKiNa | DhaSSSSSTaTa |      | KiNaDhaS | SSSS           | TaT aKiNa |
| Dha               |           |              |      |          |                |           |
| Prakar 2          | Dha       | Dha          | Ti   | Ta       | Dha            | Ti        |
| Palta/Variation 1 | Dha       | Dha          | Ti   | Kit      | Dha            | Ti        |
| Palta/Variation 2 | Dha       | Dha          | Ti   | TaGe     | Dha            | Ti        |
| Tihai             | DhaTi     | DhaS         | SDha | TiDha    | SS             | DhaTi     |
|                   | Dha       |              |      |          |                |           |
| Taal Signs        | X         |              |      | 0        |                |           |

<!-- image -->

## Students should have learnt about:

- The execution of the theka of dadra taal in ekgun with some variations.
- The execution of the theka of dadra taal in ekgun and dugun .
- The execution of some prakar of dadra taal .
- Padhant of the theka of dadra taal in ekgun.
- Execution of the theka of dadra taal in ekgun .
- Padhant of the theka of dadra taal with palta-s in ekgun.
-  Execution of the theka of dadra taal with palta-s in ekgun .
- Padhant of the different prakar and their palta-s .
-   Execution of the different prakar and their palta-s.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a logo and some text.

<!-- image -->

## https://www.youtube.com/watch?v=2V7OldEeRA0

1.Identify the theka played in the above video. 2.In which laya has the theka and its variations

- been played?

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

## Write into notation form :

- (i) The theka of dadra taal with two palta-s.
- (ii) One prakar of dadra taal with one palta and a tihai.

Assessment

2

## Recite, count and play:

- (i) The theka of dadra taal with two palta-s.
- (ii) One prakar of dadra taal with one palta and a tihai.

<!-- image -->

## 6.2 LAGGI SET TO DADRA TAAL:

| Matra         | 1          | 2        | 3          | 4          | 5        | 6          |
|---------------|------------|----------|------------|------------|----------|------------|
| Theka (Ekgun) | Dha        | Dhin     | Na         | Dha        | Tin      | Na         |
| Taal signs    | X          |          |            | 0          |          |            |
| Laggi         | DhaGe      | TinNa    | KiNa       | TaKe       | DhinNa   | GiNa       |
| Dugun         | DhaGeTinNa | KiNaTaKe | DhinNaGiNa | DhaGeTinNa | KiNaTaKe | DhinNaGiNa |
| Tihai         | DhaGeTinNa | KiNaTake | DhinNaGina | DhaSSS     | SSDhaGe  | TinNaKiNa  |
|               | TakeDhinNa | GinaDhas | SSSS       | DhaGeTinNa | KiNaTaKe | DhinNaGiNa |
|               | Dha        |          |            |            |          |            |
| Taal signs    | X          |          |            | 0          |          |            |

<!-- image -->

## Students should have learnt about:

- How to recite, count and play the theka of dadra taal at a steady rhythm.
- How to recite, count and play simple palta-s , variations and prakar-s .
- How to recite, count and play simple laggi and its tihai .
- Padhant of the theka of dadra taal at a steady rhythm.
- Play the theka of dadra taal at a steady rhythm.
- Recite, count and play the different groups of syllables of the laggi .

<!-- image -->

<!-- image -->

## It can be grouped into two parts:

| MATRA                    | 1     | 2      | 3    |
|--------------------------|-------|--------|------|
| 1 ST GROUP OF SYLLABLES: | DhaGe | TinNa  | KiNa |
| 2 ND GROUP OF SYLLABLES: | TaKe  | DhinNa | GiNa |

- Recite,count and play the laggi set to dadra taal .

In this image we can see a picture of a circle.

<!-- image -->

https://www.youtube.com/watch?v=v\_WkjYP3SxQ

- 1.Identify the first laggi played in the above video.
- 2.In which laya is the laggi played?
- 3.Identify the syllables of the tihai played and write it into notation form.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

1

Write into notation form one laggi in ekgun and dugun with a tihai set to dadra taal.

<!-- image -->

Recite, count and play one laggi in ekgun and dugun with a tihai set to dadra taal.

In this image we can see a poster with some text and a picture of a person holding a book.

<!-- image -->

## 6.3  LADI :

Ladi is a very small composition played on the tabla . It is shorter than a laggi . It is mainly used for the accompaniment of lighter forms of vocal music such as thumri-s , ghazal-s and bhajan-s . Ladi is  also  used  for  accompaniment  of instrumental  music  like  the sitar ,  played  in  very  fast  speed  known  as jhala. Despite being short ranged, it still provides room for a few variations  and a tihai . Ladi-s are generally played in taal-s like dadra , kaherwa , roopak .

## 6.3.1  LADI SET TO DADRA TAAL:

| Matra         | 1       | 2      | 3      | 4       | 5      | 6      |
|---------------|---------|--------|--------|---------|--------|--------|
| Theka (Ekgun) | Dha     | Dhin   | Na     | Dha     | Tin    | Na     |
| Taal Signs    | X       |        |        | 0       |        |        |
| Ladi          | DhaS    | Tit    | Kit    | TaS     | Tit    | Kit    |
| Dugun         | DhaSTit | KitTas | TitKit | DhaSTit | KitTas | TitKit |
| Tihai         | TitKit  | DhaSSS | SSTit  | KitDhaS | SSSS   | TitKit |
|               | Dha     |        |        |         |        |        |
| Taal Signs    | X       |        |        | 0       |        |        |

<!-- image -->

## In  the previous chapters, students should have learnt about:

- How to recite, count and play the theka of dadra taal at a steady rhythm.
- How to recite, count and play simple palta-s , variations and prakar-s .
- How to recite, count and play simple laggi and its tihai .
- Padhant of the theka of dadra taal at a steady rhythm.
- Play the theka of dadra taal at a steady rhythm.
- Recite, count and play the different groups of syllables of the ladi .

<!-- image -->

<!-- image -->

<!-- image -->

## It can be grouped into two parts:

| MATRA                    | 1    | 2   | 3   |
|--------------------------|------|-----|-----|
| 1 ST GROUP OF SYLLABLES: | DhaS | Tit | Kit |
| 2 ND GROUP OF SYLLABLES: | TaS  | Tit | Kit |

- Recite,count and play the ladi set to dadra taal .

In this image we can see a logo and a text.

<!-- image -->

Listen  to  the  teacher  playing  the  ladi  in  ekgun  and dugun with the tihai set to dadra taal.

After listening, the students are grouped in different teams and are asked the following questions:

1. In which laya was the ladi played?
2. Identify the type of tihai played.

## 6.4 KAHERWA TAAL

In this image we can see a poster with some text and some images.

<!-- image -->

## 6.4.1   NOTATION WRITING OF THE THEKA OF KAHERWAL TAAL WITH TWO PALTA-S

| Matra             | 1      | 2   | 3   | 4   | 5   | 6   | 7     | 8    |
|-------------------|--------|-----|-----|-----|-----|-----|-------|------|
| Theka (Ekgun)     | Dha    | Ge  | Na  | Ti  | Na  | Ka  | Dhi   | na   |
| Taal Signs        | X      |     |     |     | 0   |     |       |      |
| Palta/Variation 1 | DhaDha | SGe | Na  | Ti  | Na  | Ka  | Dhi   | na   |
| Palta/Variation 2 | DhaDha | SGe | Na  | Ti  | Na  | Ka  | Dhina | Gina |
|                   | Dha    |     |     |     |     |     |       |      |
| Taal Signs        | X      |     |     |     | 0   |     |       |      |

## 6.4.1.1  SOME PRAKAR -S OF KAHERWA TAAL ARE GIVEN BELOW:

| Matra         | 1     | 2      | 3     | 4    | 5    | 6      | 7     | 8    |
|---------------|-------|--------|-------|------|------|--------|-------|------|
| Theka (Ekgun) | Dha   | Ge     | Na    | Ti   | Na   | Ka     | Dhi   | na   |
| Taal Signs    | X     |        |       |      | 0    |        |       |      |
| Prakar 1      | DhaS  | Tit    | Tin   | Tin  | TaS  | Tit    | Dhin  | Dhin |
| Tihai         | TaTa  | Tit    | DhaS  | TaTa | Tit  | DhaS   | TaTa  | Tit  |
|               | Dha   |        |       |      |      |        |       |      |
| Prakar 2      | DhinS | NaDhin | SDhin | NaS  | TinS | NaDhin | SDhin | NaS  |
| Prakar 3      | Ge    | Ti     | Dha   | Na   | S    | Dhin   | Dha   | Na   |
| Prakar 4      | Dha   | Ti     | Ta    | Ta   | Ta   | Dhi    | Dha   | Ta   |
|               | Dha   |        |       |      |      |        |       |      |
| Taal Signs    | X     |        |       |      | 0    |        |       |      |

In this image we can see a poster with some text and a logo.

<!-- image -->

<!-- image -->

## In  the previous chapters, students should have learnt about:

- The execution of the theka of kaherwa taal in ekgun with some variations.
- The execution of the theka of kaherwa taal in ekgun and dugun .
- The execution of some prakar-s of kaherwa taal .
- Padhant of the theka of kaherwa taal in ekgun.
-   Execution of the theka of kaherwa taal in ekgun .
- Padhant of the theka of kaherwa taal with palta-s in ekgun .
-   Execution of the theka of kaherwa taal with palta-s in ekgun .
- Padhant of the different prakar-s .
-   Execution of the different prakar-s .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

ACTIVITY 4

https://www.youtube.com/watch?v=jUPp79TO3C4

- 1.Identify the first prakar of kaherwa taal played in the above video.
- 2.In which laya is the prakar ?
- 3.What type of tihai is played  after the first prakar ?

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

1

## Write into notation form:

- (i)  the theka of kaherwa taal with two palta-s.
- (ii) one prakar of kaherwa taal with a tihai.

Assessment

2

## Recite, count and play:

- (i)  the theka of kaherwa taal with two palta-s.
- (ii) One prakar of kaherwa taal with a tihai.

## 6.5 LAGGI SET TO KAHERWA TAAL:

| Matra         | 1      | 2      | 3      | 4          | 5      | 6      | 7      | 8      |
|---------------|--------|--------|--------|------------|--------|--------|--------|--------|
| Theka (Ekgun) | Dha    | Ge     | Na     | Ti         | Na     | Ka     | Dhi    | na     |
| Taal signs    | X      |        |        |            | 0      |        |        |        |
| Laggi         | Dha    | Tit    | Kit    | Dha        | Tit    | Kit    | Tin    | S      |
|               | Ta     | Tit    | Kit    | Dha        | Tit    | Kit    | Dhin   | S      |
|               | Dha    |        |        |            |        |        |        |        |
| Dugun         | DhaTit | KitDha | TitKit | TinS       | TaTit  | KitDha | TitKit | DhinS  |
|               | DhaTit | KitDha | TitKit | TinS       | TaTit  | KitDha | TitKit | DhinS  |
| Tihai         | DhaDha | TitKit |        | DhaSDhaDha | TitKit | DhaS   | DhaDha | TitKit |
|               | Dha    |        |        |            |        |        |        |        |
| Taal signs    | X      |        |        |            | 0      |        |        |        |

<!-- image -->

## In  the previous chapters, students should have learnt about:

- How to recite, count and play the theka of kaherwa taal at a steady rhythm.
- How to recite, count and play simple palta-s , variations and prakar-s .
- How to recite, count and play simple laggi and its tihai .

<!-- image -->

## Step    1

- Padhant of the theka of kaherwa taal at a steady rhythm.
- Play the theka of kaherwa taal at a steady rhythm.
- Recite, count and play the different groups of syllables of the laggi.

## It can be grouped into two parts:

| MATRA                    | 1   | 2   | 3   | 4   | 5   | 6   | 7    | 8   |
|--------------------------|-----|-----|-----|-----|-----|-----|------|-----|
| 1 ST GROUP OF SYLLABLES: | Dha | Tit | Kit | Dha | Tit | Kit | Tin  | S   |
| 2 ND GROUP OF SYLLABLES: | Ta  | Tit | Kit | Dha | Tit | Kit | Dhin | S   |

-     Recite,count and play the laggi set to kaherwa taal .

In this image we can see a picture of a circle.

<!-- image -->

https://www.youtube.com/watch?v=jUPp79TO3C4

1. Identify the  laggi played played in the above video.
2. 2.In which laya is the laggi played?
3. 3.Identify the syllables of the tihai played and write it into notation form.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

Write into notation form one laggi in ekgun and dugun with a tihai set to kaherwa taal.

Assessment

2

Recite, count and play one laggi in ekgun and dugun with a tihai set to kaherwa taal.

## 6.6  LADI SET TO KAHERWA  TAAL:

| Matra         | 1     | 2    | 3     | 4    | 5     | 6    | 7     | 8    |
|---------------|-------|------|-------|------|-------|------|-------|------|
| Theka (Ekgun) | Dha   | Ge   | Na    | Ti   | Na    | Ka   | Dhi   | na   |
| Taal signs    | X     |      |       |      | 0     |      |       |      |
| Ladi          | Dha   | Ti   | Gi    | Na   | Dha   | Ti   | ki    | Na   |
|               | Ta    | Ti   | Ki    | Na   | Dha   | Ti   | Gi    | Na   |
|               | Dha   |      |       |      |       |      |       |      |
| Dugun         | DhaTi | GiNa | DhaTi | KiNa | TaTi  | KiNa | DhaTi | GiNa |
|               | DhaTi | GiNa | DhaTi | KiNa | TaTi  | KiNa | DhaTi | GiNa |
| Tihai         | DhaTi | GiNa | DhaTi | GiNa | DhaS  | SS   | DhaTi | GiNa |
|               | DhaTi | GiNa | DhaS  | SS   | DhaTi | GiNa | DhaTi | GiNa |
|               | Dha   |      |       |      |       |      |       |      |
| Taal signs    | X     |      |       |      | 0     |      |       |      |

<!-- image -->

## Students should have learnt about:

- How to recite, count and play the theka of kaherwa taal at a steady rhythm.
- How to recite, count and play simple palta-s , variations and prakar-s.
- How to recite, count and play simple l aggi and its tihai .

<!-- image -->

## Step    1

- Padhant of the theka of kaherwa taal at a steady rhythm.
- Play the theka of kaherwa taal at a steady rhythm.
- Recite, count and play the different groups of syllables of the ladi.

## It can be grouped into two parts:

| MATRA                    | 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   |
|--------------------------|-----|-----|-----|-----|-----|-----|-----|-----|
| 1 ST GROUP OF SYLLABLES: | Dha | Ti  | Gi  | Na  | Dha | Ti  | Gi  | Na  |
| 2 ND GROUP OF SYLLABLES: | Ta  | Ti  | Ki  | Na  | Dha | Ti  | Gi  | Na  |

-     Recite, count and play the ladi set to kaherwa taal .

In this image we can see a picture of a circle.

<!-- image -->

Listen to the teacher playing the ladi in ekgun and dugun with the tihai set to kaherwa taal.

After listening, the students are grouped in different team and are asked the following questions.

1.In which laya was the ladi played?

2.Identify the type of tihai played.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

Write into notation form one ladi in ekgun and dugun with a tihai set to kaherwa taal.

<!-- image -->

Recite, count and play one ladi in ekgun and dugun with a tihai set to kaherwa taal.

In this image, we can see a paper with some text on it.

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Explain briefly the term gharana .
- List the main gharana-s of tabla-playing.
- State the characteristic features of a gharana .

## 7.0 GHARANA

Gharana is  a  combination  of  two  words  ' ghar '  and  ' ana '  which  means  to come at home.Long ago, there was not any school where Indian music and dance were taught. This knowledge was imparted only to family members, that  is,  from  grandfather  to  father,  father  to  son,  son  to  grandson,  from where the concept of gharana emerge d . Gharana can also be qualified as a musical lineage. Later on, the knowledge of music and dance was imparted to  people  outside  the  family  lineage.  Apart  from  family  members,  other people had to go to their teacher's ( Guru's ) place to learn the art. The direct descendants in a gharana are known as khalifa-s .

In this image we can see a painting. In the painting there are people sitting on the chairs. In the background there is a water body.

<!-- image -->

There are different gharana-s in the field of music and dance. The name of each gharana is usually associated to a particular person, village, town or city. For example, in vocal Hindustani there is the Patiala gharana , Seniya gharana in sitar , Lucknow gharana in kathak dance and Delhi gharana in tabla .

There are six main gharana-s in the field of tabla . They are;

In this image, we can see a poster with some text and images.

<!-- image -->

## 7.1 CHARACTERISTIC FEATURES OF A GHARANA:

01

When a  form  or  style  is  carried till  three  generations,  it  can  be claimed as a gharana .

02

03

Each gharana is  represented  by great  maestros  also  known  as the khalifa-s .

Each gharana has its own type of compositions  and  techniques  of playing and dancing.

04

Each gharana must have genuine and  original  compositions  which are  accepted  by  maestros  in  the particular field.

05 Each gharana gives prominence to a particular type of compositon.

<!-- image -->

Musical lineage, traditional.

Students learning with the same guru are known as gurubhai .

DID YOU KNOW

<!-- image -->

The guru is given utmost respect in the gharana system. The student promises to be faithful and loyal towards his guru through a system known as the ganda-bandhan .

## END OF CHAPTER QUESTIONS ASSESSMENT

Assessment

1

## State whether the following are True or False.

- (i)  Gharana is a new system of learning Indian music and dance. (................)
- (ii)  Initially, music and dance education was restricted to only family members in the gharana system. ( ................)
- (iii) There are different gharana-s in the different fields of music and dance. (................)
- (iv) The name of a gharana is usually associated with the name of a person or region. (................)
- (v)  There are seven main gharana-s in the field of tabla. (................)

Assessment

2

- (i) Explain briefly the term gharana.

……………………………………………………………………………………

……………………………….....................................................................

..............................................................................................................

- (ii) List the main gharana-s of tabla-playing.

…………………………………………………………………………………….

…………………………………………………………………………………….

…………………………………………………………………………………….

- (iii) List the characteristic features of a gharana.

…………………………………………………………………………………….

…………………………………………………………………………………….

…………………………………………………………………………………….

…………………………………………………………………………………….

<!-- image -->

In this image, we can see a paper with a paper clip and some text on it.

<!-- image -->

In this image we can see a group of people sitting on the floor. There are some objects in the image.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Explain briefly the following vocal forms: khayal , bada khayal , chota khayal , bhajan , ghazal , geet and lokgeet.
- Distinguish between the different vocal forms.
- Identify the instruments used to accompany each vocal form.
- Relate the different vocal forms to different cultural contexts.
- Explain briefly the following instrumental forms: Maseetkhani/Vilambit gat and Razakhani/Drut gat .
- Distinguish between Maseetkhani and Razakhani gat .
- Appreciate the different vocal and instrumental forms.

## 8.0 KHAYAL:

Khayal is an urdu word literally meaning 'imagination' or 'creative thought'. Khayal is basically a form of singing. It may be defined as a form of hindustani vocal music, is a song composed in a definite raag and to be sung in a taal .

Khayal is  a  vocal  composition  or  bandish,  which  is  comprised  of  two  parts, namely the sthayi and the antara . The sthayi or first part of the bandish covers the  lower  and  middle  scales    ( mandra and madhya saptak ).  The antara or second part of the bandish covers the middle and upper scales ( madhya and taar saptak ) . This form of singing uses lots of improvisations.

There are two types of khayal, namely chota khayal and bada khayal .

## 8.0.1  BADA KHAYAL:

This type of khayal is usually sung in vilambit laya . In bada khayal , importance is  given  to  the  words  of  the  bandish  and  the  use  of swara-s .  The khayal is normally set to taal-s such as ektaal and tilwada .

## 8.0.2 CHOTA KHAYAL:

This type of khayal is sung in madhya and drut laya . It is normally set  to taal-s such as teentaal , ektaal , jhaptal .

In this image we can see a pencil, a poster and a badge.

<!-- image -->

Amir Khusro is believed to be the inventor of this style of singing in the 13 th century.

DID YOU KNOW

## 8.1 BHAJAN:

It  is  a  devotional  song  in  praise  of the Almighty.  In  other  words,  it  is  a popular  religious song,    normally accompanied  by    instruments  such as the harmonium, tabla , dholak and manjira . Bhajan-s are normally sung in mixed raag-s , expressing bhakti or devotion , a warm devotional faith to God.

A bhajan consists of a sthayi and A ntara and  is  sung  in  solo  or in  group.It  is usually sung  in  the following taal-s namely kaherwa taal , dadra taal , roopak taal , jhaptal , teentaal and deepchandi .

MIRA BAI

In this image we can see a painting. In the painting there is a woman. She is wearing a yellow color dress and a red color scarf. She is holding a musical instrument. There is a drum. There are two birds. There is a watermark on the image.

<!-- image -->

## 8.2 GHAZAL:

<!-- image -->

<!-- image -->

Ghazal, which is a vocal form, originally meant 'love song' in Persian language. Later,  the urdu literary  tradition  extended  the  thematic  range  of ghazal-s to subjects other than love. Urdu words are  used in abundance. In this genre, much emphasis is laid on the lyrics rather than on music.

Literary aspects such as metre, end rhyme,line, couplet and number of shers bear  great  importance. Ghazal-s are  mostly  sung  in dadra , kaherwa and roopak taal . Musical instruments such as the harmonium , tabla , dholak , sitar , violin , guitar , sarangi and keyboard are commonly used in the accompaniment of ghazal-s . Some popular ghazal singers are Late Mehdi Hassan, Ghulam Ali, Late Jagjit Singh among others.

In this image, we can see a pencil, a magnifying glass, a paper, and some text.

<!-- image -->

Late Jagjit Singh is considered to be the king of ghazal .

DID YOU KNOW

## 8.3 GEET:

It is a form of singing characterised by tune, metre, rhythm and language. It is a light Indian musical composition with a sthayi and an antara .

The theme of the composition is of varying nature. The composition is usually set  to  popular taal-s such  as dadra , kaherwa , roopak and deepchandi .  The melody of the composition may consist of pure or mixed raag-s .

It  is  not  governed  by  strict  rules  of  the raag-s and  their  characteristics  as compared  to  the  Indian  classical  music.  It  is  a  free  style  of  composition appreciated by people in general.

In this image, we can see a pencil and a badge. In the background, there is a wall.

<!-- image -->

## 8.4 LOKGEET:

It is a light folk Indian form of singing with a sthayi and an antara . The theme of the composition is of varying nature, but most are folk songs based on nature, rituals  such  as haldi songs, lalna , sohar , jhumar . Lokgeet is  also  based  on religious festivals like holi where the holi chawtal is sung. The composition is normally set to taal-s such as dadra , kaherwa , roopak and deepchandi .

This  form  of  singing  does  not  necessarily    need  formal  training.  The  most common instruments used in the accompaniment of lokgeet are dholak , tabla , jhaal , manjira and chimta .

In this image we can see a pencil, a key and a shield. In the background there is a brown color surface.

<!-- image -->

## 8.5 GAT:

It is a classical composition played on the sitar and the sarod . It is described as a pillar  in the presentation of a raag . A gat normally follows the alaap in the sequence of a performance. Gat was introduced in sitar playing during the 18 th century. A gat is identified by its specific strokes pattern and the tempo at which it is played. A gat is divided into three main parts, namely the sthayi , manjha and antara .

There are two types  of gat which are most common in sitar playing, namely Maseetkhani gat and Razakhani gat .

## 8.5.1 MASEETKHANI GAT:

A maseetkhani gat is played in vilambit laya (slow tempo), set to teentaal and is  based  on  a  particular raag .  This  type  of gat was  created  by  the  famous musician, Maseet Khan.

The characteristic features of a maseetkhani gat are:

1. It always starts on the 12 th beat.
2. It is played using a fixed stroke pattern: dir da dir da ra da da ra.

## 8.5.2 RAZAKHANI GAT:

Razakhani gat-s are played in madhya or drut laya (medium or fast tempo), set to teentaal and based on a particular raag . A razakhani gat is usually played with emphasis laid on rhythm and its variations. This style of gat was developed by Raza Khan, a famous musician.

Traditional razakhani gat-s start on the sam (1 st beat), 5 th beat, 7 th beat, khali (9 th beat) or 13 th beat of teentaal .

In  a  classical  performance,  a razakhani  gat is  always  played  after  the maseetkhani gat .

In this image we can see a pencil and a pencil sharpener. In the background there is a brown color surface.

<!-- image -->

In this image there is a text on the right side.

<!-- image -->

## Khayal

- Literally meaning 'imagination' or ' creative thought'.
- Is a form of vocal hindustani music composed in a raag and to be sung in a taal .
- Is also known as bandish consisting of a sthayi and an antara .
- The sthayi covers the mandra and madhya saptak .
- The antara covers the madhya and taar saptak .
- Uses lots of improvisations.
- Two types of khayal, namely bada khayal and chota khayal.
- Chota khayal - sung in madhya and drut laya , -usually set to teentaal , ektaal , jhaptal

Bada khayal

- sung in vilambit laya .
- serious importance given to the words and to the use of swara-s .
- -usually set to ektaal and tilwada .

## Bhajan

- A devotional song in praise of the almighty.
- Normally accompanied by instruments such as the harmonium , tabla , dholak , manjira .

POINTS TO REMEMBER:

- Normally sung in mixed in raag-s .
- Consists of sthayi and antara .
- Sung in taal-s like kaherwa taal , dadra taal , roopak taal , jhaptal , teentaal and deepchandi .

<!-- image -->

## Ghazal

- Form of singing whose original meaning was 'love song' in Persian language.
- Uses urdu words in abundance.
- Great importance lies in their lyrics.
- Literary aspects such as metre, end rhyme,line,couplet and number of shers bear great importance.
- Usually sung in dadra , kaherwa and roopak taal .
- Mostly accompanied by musical instruments such as the harmonium , tabla , dholak , sitar , violin , guitar and keyboard.
- Popular ghazal singers are Late Mehdi Hassan, Ghulam Ali, Late Jagjit Singh among others.

## Geet

- Form of singing characterised by tune, metre, rhythm and language.
- Consists of sthayi and antara.

POINTS TO REMEMBER:

- The theme of the composition is of varying nature.
- Is usually set to dadra taal , kaherwa taal , roopak taal and taal deepchandi .
- The melody may consist of mixed raag-s .
- Is not governed by strict rules of the raag-s as compared to the Indian classical music.

## Lokgeet

- Light folk Indian form of singing with a sthayi and an antara .
- The theme of the composition is of varying nature.
- Folk songs based on nature, rituals, and religious festivals.
- Does not necessarily  need formal training.
- Mostly accompanied with instruments such as the dholak , tabla , jhaal , manjira and chimta .

## Gat

- Is a classical composition played on the sitar and the sarod .
- Is described as a pillar  in the presentation of a raag .
- It usually follows the alaap in the movement of a raag .
- Is identified by its specific strokes pattern, and the tempo at which it is played.

POINTS TO REMEMBER:

- Is divided into three main parts, namely the sthayi , manjha and antara .
- There are two types  of gat, namely the Maseetkhani  gat and Razakhani gat .

## Maseetkhani gat

- Is played in vilambit laya (slow tempo), set to teentaal and is based on a particular raag .
- Was created by a famous musician, Maseet Khan.
- The characteristic features of a maseetkhani gat are:
- (i)  It always starts on the 12 th  beat.
- (ii) It is played using a fixed stroke pattern: dir da, dir da ra, da da ra.

## Razakhani gat

- Compositions are played in madhya or drut laya (medium or fast tempo), set to teentaal and based on a particular raag .
- Is usually played with emphasis laid on rhythm and its variations.
- Was developed by Raza Khan, a famous musician.
- Traditional razakhani gat-s start on the sam (1 st beat), 5 th beat, 7 th beat, khali (9 th beat) or 13 th  beat of teentaal .
- In a classical performance, a razakhani gat is always played after playing the maseetkhani gat .

In this image we can see a picture of a car.

<!-- image -->

## GROUPWORK

Make a poster presentation on the different  vocal  and  instrumental forms you have studied in class.

## GROUPWORK

ACTIVITY

View and listen  to the music in the following videos:

1. https://www.youtube.com/watch?v=OmlD5s8quO4
2. https://www.youtube.com/watch?v=XQeY6rLaIt4
3. https://www.youtube.com/watch?v=Ty86h60vu2Y
4. https://www.youtube.com/watch?v=Py\_FIHwPIZI
5. https://www.youtube.com/watch?v=pX4YfsvXBXU
6. https://www.youtube.com/watch?v=cMKiM2RnG2A
7. https://www.youtube.com/watch?v=PjZoUDd\_luY
1. The first video is a Chota Khayal set in Raag Bhimpalasi and set to a particular taal.
9. (i)  In which Taal is the Chota Khayal set?
10. (ii) In which Laya is the Khayal sung ?
2. The second video is a Bada Khayal set in Ektaal (a cycle of 12 beats) sung in Raag Jaunpuri.
12. (i) In which Laya is the Khayal sung?
3. The third video is a bhajan sung by Late Jagjit Singh in praise to Lord Krishna.
14. (i) In which Taal is the bhajan set?

2

4. The fourth video is a popular ghazal sung by Ghulam Ali. (i) In which Taal is the Ghazal set?
5. The fifth video is an example of a lokgeet. It is a holi chawtal sung in group.
3. (i) Name the two musical instruments which have been used in the accompaniment of the lokgeet.
4. 6.The sixth video is a Maseetkhani Gat played on the sitar and set in Raag Darbari.
5. (i) In which Laya is the Gat being played?
6. 7.The last video is a Razakhani Gat played on sitar and set in Raag Bhupali.
7. (i) In which Taal is the Gat being played? (ii)In which Laya is the Gat being played?

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

7

Fill  in  the  blanks  using  the  appropriate  words  given  in  brackets below:

(vilambit, folk, ghazal, taal, bhajan, madhya, chota, hindustani, drut, manjha)

- (i)     A  ……….....  is a song  mostly sung in praise of  God.
- (ii)    Maseetkhani gat is played in ………… laya.
- (iii)   Urdu language is used in abundance in ………….. .
- (iv)   Khayal is a form of ……….. vocal music sung in a raag and set to a particular ……....... .
- (v)    Lokgeet is a light ……..form of music.
- (vi)   A gat is divided into three main parts, namely the sthayi, …….... and antara.
- (vii)  Razakhani gat  is played in ………..or ……… laya.
- (viii) A …….. khayal is normally sung in madhya and drut laya.

<!-- image -->

Explain briefly the following vocal and instrumental forms.

- (i) Khayal.
- (ii) Bhajan.
- (iii) Lokgeet.
- (iv) Ghazal.
- (v) Gat.

Assessment

3

## Distinguish between the following :

- (i)  Bada khayal and chota khayal.
- (ii) Maseetkhani and razakhani gat.

In this image we can see musical instruments.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Describe the prescribed instruments with reference to their construction and uses.
- Explain briefly the terms chordophone, diophone and membranophone.
- Develop a positive attitude and respect towards each instrument.

## 9.0 IDIOPHONES:

## 9.0.1 MANJIRA:

In this image we can see a person holding a bowl and a bowl with red color threads.

<!-- image -->

The Manjira is a pair of small cymbals used as a side rhythm in Hindustani sangeet . It is made of brass or copper tied together with a lace. Sound is produced  by  friction  between  the  two cymbals .  The  size  of  the manjira varies according to its pitch. A small manjira has a high pitch whereas a big one has a low pitch.

Manjira is widely used in folk music, bhajan-s and kirtan-s . Initially, it was used to provide taal to vocal music.

## 9.0.2  TRIANGLE:

In this image we can see a wooden object, a person's hand holding a stick, a wooden object and a wooden object.

<!-- image -->

The triangle is an idiophone ( ghan vadya )  with  three sides. It is made of steel  or  copper.  The  instrument  is  played  by  holding  the  top  curve  with fingers. A metal beater is used to strike on the sides of the instrument to produce a sound. The resonance of the sound is controlled by using the fingers which hold the triangle. It is mostly used as a side rhythm in folk music. The triangle is one among the main instruments used in sega tipik in Mauritius.

## 9.1 MEMBRANOPHONES:

## 9.1.1 MRIDANGAM :

This image is a collage of two images. The top image is a drum, and the bottom image is a person playing a drum. Both images are in a white color.

<!-- image -->

The mridangam is one among the ancient percussion instruments ( avnadh vadya )  in  India.  It  is  mainly  used  to  provide  rhythm  ( talam )  in Carnatic sangeet .

The body of the instrument is made of wood, jackwood or redwood, with a length  of  about  one  and  a  half  or  two  feet.  It  has  a  barrel-shape  and  is hollow inside. The diameter on the right hand side is smaller than that on the left hand side. Both sides are covered with a skin called ' muttu '. They are held together by passing a leather lace across their circumference and the body of the mridangam .

The skin on the right hand side has a circular layer of a black paste called ' soru '.  The  ' soru '  is  made  of  iron  filings  and  boiled  rice.  It  gives  the instrument its tonal quality. A paste of fine flour ( soojee ) and boiled rice is fixed at the centre of the skin on the left hand side. This enables to have a sound with a low tone.

The application of the paste on the left hand side skin is done each time before the mridangam is being used and is then removed afterwards.

The tuning of the mridangam is done by using a stone called ' kaalu ' and a wooden stick called ' pullu '.

The mridangam is used for solo performances and to provide accompaniment vocal, instrument and dance.

## 9.1.2 DJEMBE:

In this image we can see a musical instrument.

<!-- image -->

The djembe is a very popular percussion instrument ( avnadh vadya ) from Africa.  It  has  a  goblet  shape  with  a  wooden  body-usually  Bois  rouge  or Acajou. Covered with goat skin, the djembe is meant to be played with bare hands.

The body of the djembe has a height of about twelve inches, with an upper surface of about twenty four inches in diameter. The goat skin is tightened by  using  a  metal  ring  and  rope  passed  around  the  circumference  of  the djembe .    The  skin,  the  density  of  wood,  the  internal  carvings  and  the rounded shape, together with the extended tube, enables the djembe to produce a wide range of tones.

The primary notes are generally referred to as bass, tone and slap.The slap has a high and sharp sound. The bass sound is produced by striking the skin with the palm and fingers towards the centre of the drum, and the slap and tone are played by striking near the rim.

Nowadays, the djembe , from traditional African music, has been integrated in  modern music around the world due to its portable size and variety in sound  production.The djembe is  a  very  popular  musical  instrument  in Mauritius.  It  is  widely  used  in  the  different  types  of  music  by  all  the communities on various occasions around the island.

## 9.2 CHORDOPHONES:

## 9.2.1 SITAR:

Mr. M. Goolaup - Educator

In this image we can see a man sitting on the floor and playing a guitar. There are flowers in the background.

<!-- image -->

Known as a tat vadya (chordophone), the sitar is  a  very popular stringed instrument used in Hindustani sangeet . Amir Khusro is believed to be the inventor of sitar .

A sitar has  many  parts  among  which  the  resonator  ( tumba )  and  the fingerboard  ( dandi ),  which  is  about  three  feet  long,  are  the  most  visible ones. The tumba is made of dried gourd ( Kaddu ) and is hollow inside. It is covered with a wooden plate called the tabli . The dandi is also hollow inside and is usually made of Tun wood.

Usually, there are six or seven upper strings and eleven to thirteen lower strings  in  a sitar .  The  lower  strings  are  also  known  as  the  sympathetic strings ( tarab ke taar ). Wooden pegs ( khounti ) are fixed along the dandi to tune the strings. Moreover, there are about twenty one metal frets ( Parda-s ) tied  along  the dandi which  allow  the  player  to  locate  the swara-s while playing the instrument.

The sitar is played by plucking the upper strings using a metallic plectrum called the Mizrab . The types of compositions played on the sitar are known as Gat-s .  The sitar is  played  to  give  solo  performances  and  to  provide accompaniment in semiclassical and light music as well.

Pandit Ravi Shankar style sitar

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Friction, Goblet, talam, tumba, dandi.

There are 2 types of sitar: Pandit Ravi Shankar style and Ustad Vilayat Khan style.

DID YOU KNOW

Ustad Vilayat Khan style sitar

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Some varieties  of sitar also consist of a small resonator known as the tumbi .

DID YOU KNOW

<!-- image -->

Make poster presentations of the following musical instruments, describing their category, make and use:

Manjira, sitar,triangle, djembe

## Youtube link:

2

ACTIVITY

https://www.youtube.com/watch?v=\_gKCkAG304E

https://www.youtube.com/watch?v=tb9quNjTz40

https://www.youtube.com/watch?v=UyX3NyRz\_nM

https://www.youtube.com/watch?v=CZImJLx4XB8

https://www.youtube.com/watch?v=ZPkPTSS7OiI

## After viewing the videos:

- (i)   Identify the musical instruments in each video.
- (ii)  Can you differentiate their timbre?
- (iii) Relate the musical instruments to the different types of music practised in your country.

## TRIANGLE

-  The triangle is an idiophone.
-  It is made of a metal rod, copper or steel.
-  Played with a metal beater.
-  The triangle is mostly used as a side rhythm in sega tipik.

## MRIDANGAM

-  It is a membranophone.
-  It is made of wood and is hollow inside.
-  It covered with skin on both sides.
-  Played with hands.
-  Mridangam is a prominent percussion instrument used to provide rhythm in Carnatic sangeet.
-  Used for solo performances and to provide accompaniment.

POINTS TO REMEMBER:

## DJEMBE

-   The djembe is a percussion instrument initially used in African music.
-   It is made of wood and has a goblet form.
-   Covered with skin.
-   Usually played with hands.

## SITAR

- Very popular chordophone used in Hindustani sangeet.
- Made of dry gourd with a long wooden neck.
- Consists of six or seven upper strings and eleven to thirteen lower strings.
-   Played for solo performances and to provide accompaniment.
- The lower strings are also known as the sympathetic strings(tarab ke taar).
- Sitar is played using a metal plectrum called the Mizrab.
-   Nowadays, the djembe is used in different types of music around the world.
- Played for solo performances and to provide accompaniment.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

## Write down the category of each musical instrument given below: (Avnadh, Tat, Sushir, Ghan)

In this image, we can see a poster with some text and images.

<!-- image -->

Assessment

2

Fill in the blanks with the appropriate words given in bracket below: (Membranophone, pitch, idiophone, kaalu, mizrab, goblet, pullu, tumba, manjira, djembe, frets)

- (a) ………………….is a percussion instrument originating from Africa.
- (b) …………………is that part where the sound of the sitar resonates.
- (c) The triangle is an ………………….mostly used in 'sega tipik' in Mauritius.
- (d) ………………… was initially used to provide taal to vocal music.
- (e) The …………………. along the dandi allows the player to locate
- swara-s in a sitar.
- (f)  The structure of a djembe has a ……………….. form.
- (g) The mridagam is tuned by using a ………………and……………….
- (h) The ……………… of a manjira varies according to its size.
- (i)  The sitar is played by using a plectrum called the ……………………
- (j)  The djembe is a popular ………………….. used in different types of music Mauritius.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

3

Write short notes on the following musical instruments with particular reference to their constructions and uses:

- (i) Djembe
- (ii) Sitar
- (iii) Mridangam
- (iv) Triangle

<!-- image -->

Explain the difference between a chordophone and an idiophone with proper examples.

In this image we can see a person holding a stick and a musical instrument. In the background we can see a cloth.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Discriminate between the musical notes in terms of pitch.
- Distinguish between instruments used for vocal accompaniment in relation to male and female pitch.
- Distinguish between a tuned and an untuned tabla .
- List precautions to be taken while handling the hammer.
- Adjust the gatta-s according to the required pitch for tuning the instrument.
- Appreciate the pleasing sound of a well-tuned tabla .

## 10.0  TABLA TUNING:

Proper sound production through a musical instrument not only depends on the playing techniques but also on how the musical instrument is tuned. It is important to tune a Tabla properly before it is used.

A hathodi (hammer) made of copper or steel is used to tune the instrument. The pointed side is usually used to move the gatta-s up or down while the squared side is used to strike on the gajra for fine tuning.

## 10.1 THE FOLLOWING FACTORS NEED TO BE CONSIDERED BEFORE TUNING A TABLA:

- (i)  A tabla is tuned to a particular swara . Therefore, it is important to have a proper knowledge of the different swara-s ( swara gyan ). One should be able to discriminate among shudh , komal and tivra swara-s .
- (ii) The size of the pudi and the thickness of the syahi usually determine the pitch at which it can be tuned. Consequently, one should use a tabla with the appropriate pudi in order to have the required pitch.
- (iii) For a solo performance, a tabla is tuned at a pitch where the instrument gives the best resonance. C or C sharp is usually the preferred pitch.
- (iv) In Indian classical music performances:
- Male singers usually choose a pitch ranging from C to D sharp.
- Female singers usually choose a pitch ranging from G to B.
- (v) Stringed Instruments such as the sitar or violin are usually tuned in a range from C sharp to D for solo performances.
- (vi) The tabla ( Dayan ) can usually be tuned on the tonic Shadaj ( Sa ) or Pancham ( Pa ) for classical performances. It can also be tuned on Madhyam ( Ma ), depending on the raga .
- (vii) The Dagga is usually tuned on Gandhar (Ga) of the immediate mandra saptak from where the tabla is tuned.
- (viii)  For performances other than classical music, a tabla can be tuned on other swara-s apart from Shadaj ( Sa ) or Pancham ( Pa ) depending on the chords and the melody of the composition.

## 10.2 TECHNIQUES FOR TUNING A TABLA:

- A tanpura , either acoustic or electronic, is used as a reference to tune a tabla . It is set to the required note in order to emit a sound at the pitch upon which the tabla should be tuned.

In this image we can see a musical instrument.

<!-- image -->

Acoustic Tanpura

In this image we can see a musical instrument.

<!-- image -->

Electronic Tanpura

- The syllable ' Ta ' is played around the circumference of the tabla to check the pitch.
- Gatta-s are moved up or down either  to decrease or increase the pitch of the tabla .

<!-- image -->

Other  instruments  such as the pitch pipe or  tuner can be used to tune the Tabla .

Pitch pipe

<!-- image -->

<!-- image -->

Electronic tuner

Increasing the pitch

In this image we can see a person playing a musical instrument.

<!-- image -->

- Fine tuning is done on gajra .

In this image we can see a person playing drums.

<!-- image -->

Decreasing the pitch

In this image we can see a person's hand is holding a screwdriver.

<!-- image -->

Increasing the pitch

In this image we can see a person wearing red color shirt is cutting a hot dog.

<!-- image -->

Decreasing the pitch

In this image we can see a paper with some text on it.

<!-- image -->

## 10.3 SAFETY PRECAUTIONS TO BE TAKEN WHILE TUNING A TABLA

## SAFETY PRECAUTIONS

- One should avoid striking the body of the tabla while moving the gatta-s up or down.
- The hammer should be handled with care to avoid the hand or the body getting hurt.
- The pudi must be avoided while doing fine tuning on the gajra .
- Too much tension should not be put on a pudi while tuning. This can cause the latter to tear.

<!-- image -->

Use a harmonium or a keyboard to play different swara-s on different scales.

Can you differentiate their pitch? Discuss on the pitch of the different swara-s .

In this image we can see a pencil, a paper, a paper clip, a paper, a paper, a paper clip, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper,

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Ladies Tanpura Gents Tanpura

-  It is important to have a proper knowledge of swara-s used in Indian music. (swara gyan)

There are two types of tanpura :

DID YOU KNOW

<!-- image -->

-  The size of the pudi and the thickness of the syahi determines the pitch at which a tabla can be tuned.
-  The tabla is usually tuned on C or C sharp while giving a solo performance.
-  Male singers usually choose a pitch ranging from C to D sharp.
-  Female singers usually choose a pitch ranging from G to B.

<!-- image -->

-  Stringed Instruments such as sitar or violin are usually tuned in a range from C sharp to D for solo performances.
-  The tabla (Dayan) can usually be tuned on the tonic Shadaj(Sa) or Pancham (Pa) for classical performances. It can also be tune on Madhyam (Ma), depending on the raga.
-   Dagga is usually tuned on Gandhar (Ga) of the immediate mandra saptak from where the tabla is tuned.
-  For semiclassical or light music, the tabla can be tuned on other swara-s apart from Shadaj (Sa) or Pancham (Pa) depending on the chords and melody of the composition.
-  A tanpura, either acoustic or electronic, is used as a reference to tune a tabla.
- The syllable 'Ta' is played around the circumference of the tabla to check the pitch.
-  Gatta-s are moved up or down either to decrease or increase the pitch of the tabla.
-  Fine tuning is done on gajra.

In this image, we can see a chart. There is a text on the chart.

<!-- image -->

In this image we can see a collage of different images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Sketch the life history of the above mentioned musicologists and exponents.
- Recognise their contribution in the propagation of music as an art form.

## 11.0 PANDIT BHIMSEN JOSHI

In this image we can see a person. In the background there is a blur image.

<!-- image -->

## FACT SHEET

Birth name

Date of birth / death

Place of birth

Awards

Bhimsen Gururaj Joshi

04/02/1922 --- 24/01/2011

Ron, Bombay Presidency, British India

Padma Shree, 1972 Sangeet Natak Akademi Award, 1976

Padma Bhushan, 1985 National Film Award for Best Male Playback Singer, 1985 (Film 'Ankahee') Sangeet Natak Akademi Feloowship, 1998 Padma Vibhushan, 1999 . Maharashtra Bhushan, 2002 Swathi Sangeetha Puraskaram,

2003

Karnataka Ratna, 2005 Lifetime achievement award, 2009

## 11.1 INTRODUCTION

Pandit Bhimsen Joshi was interested in music since a young age. He was the eldest among 16 children in his family. He lost his mother when he was a kid, and consequently was raised by his father and stepmother. Pandit ji was very much interested in musical instruments such as the Tanpura and the pump organ.

## 11.1.1 STYLE

Pandit Bhimsen Joshi's  music had a unique style. He was inspired by some great  artists such as Begum Akhtar, Smt. Kesarbai Kerkar and Ustad Amir Khan. Though he mainly stuck onto Kirana gharana for most of his career, he  also  incorporated  various  styles  and gharana-s from  each  of  his inspirations. Apart from a classical singer, Bhimsen Joshi was also patriotic and a devotional singer.

## 11.1.2 CONTRIBUTIONS

A  brilliant  exponent  in  the  field  of  Hindustani  classical  music,  Pandit Bhimsen  Joshi  is  a  legend  who  had  not  just  earned  the  respect  and admiration of his fans but that of his critics as well. Famous for perfecting the Khayal , a form of Hindustani classical, Bhimsen Joshi was also known for his presentation of devotional music. His ' bhajan-s ', were usually sung in Kannada, Hindi and Marathi languages. They are widely recognised and appreciated    by  ardent  music  lovers  but  also  by  devotees  all  over  the country. This versatile singer has also recorded Kannada Dasa Krithis in Dasavani,  which are usually sung by Carnatic musicians.

In this image we can see a pencil, a pencil sharpen, a paper, a paper clip, a paper, a paper, a paper, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil, a pencil,

<!-- image -->

## Youtube link:

https://www.youtube.com/watch?v=-jf6pwtPqCs

Pandit Bhimsen Joshi's most memorable performance that is recalled by his fans even today is the song ' Mile Sur Mera Tumhara '.

## 11.2 PANDIT VISHNU NARAYAN BHATKHANDE

<!-- image -->

In this image we can see a poster with a picture of two people.

<!-- image -->

## FACT SHEET

Birth name

Date of birth / death

Place of birth

Contribution

Pandit Vishnu Narayan Bhatkhande

10.08.1860 / 19.09.1936

Walkeshwar , Mumbai

Writing of Notation system in Hindustani Music

## 11.2.1 INTRODUCTION

Pandit Vishnu Narayan Bhatkhande was born in a town called Walkeshwar, in Mumbai on 10 th  August, 1860. Since his very childhood, he was a music lover.  As a child, he was very much gifted and would immediately pick up songs which his mother would sing. At a very age Pandit Vishnu played the sitar and also learnt Vocal music. After finishing his B.A L.L.B studies, he started practicing law and assisted music concerts regularly.

## 11.2.2 HIS STUDIES

He started learning music during his college days. He learnt sitar from Shri Vallabhdas and within a short period. He could play the instrument well. He also  learnt  vocal  music  under  Raojibua,  a  drupad  singer  after  he  joined Gayan  Uttejak  Mandali,  a  well-known  music  circle  in  Mumbai.  Besides learning music, Pandit Vishnu studied ancient texts such as 'Bharat Natya Shashtra' and 'Sangeet Ratnakar'. At the same time he started to study standard  works  on  Western  music.  Thereafter,  he  discovered  that  the definition  of  ' Shruti-s '  and  scales  as  given  in  ancient  texts  differed  very much from the practice prevailing in the musical world of his time.

## 11.2.3 HIS AIMS

After  the  death  of  both  his  wife  and  daughter, Pandit Vishnu  Narayan stopped his legal practice and devoted the rest of his life to systematize the prevailing  form  of Hindustani music.  One  of  his  aim  was  to  devise  a notation  system  based  on  a  set  of  rules  that  would  make  knowledge  of music accessible to all. He organized many music conferences, in order to bring an agreement regarding the prevailing standards and forms of music. While visiting many libraries throughout India, Pandit Bhatkhande acquired much knowledge from texts in Sanskrit , Hindi , Telegu and Tamil and other languages. Furthermore he spent some time in other parts of India such as Gwallior, Baroda and Rampur where he collected important drupad-s .

Having devoted all his life to the cause of music, Panditji passed away on 19 th  September 1936. He was able to accomplish the tasks of discovering and collecting ancient texts, investigating the actual forms and compositions and finally systemizing the whole so that Hindustani music could evolve in a systematic way.

In this image, we can see a pencil and a magnifying glass. We can also see a text on the image.

<!-- image -->

## 11.2.4 HIS PUBLICATIONS AND MANUSCRIPTS

| His publications                           | Manuscripts edited by Him   |
|--------------------------------------------|-----------------------------|
| Swar Mallika (1997)                        | Swara Mela Kelanidhi        |
| Shri Mallakshaya (1909)                    | Chaturdandi Prakashika      |
| Hindustani Sangeet Paddhati (4 vol) (1909) | Raga Lakshanam              |
| Hindustani Sangeet Karmik Pustak Mallika   | Raga Tarangini              |
| Shri Mal Lakshya Sangeetam                 | Raga Tatva Vibodh           |
| Lakshan Geet Sangrah                       | Sadraga Chandrodaya         |
| Geet Malika                                | Raga Manjari                |
| Abhinav Raga Manjari                       | Raga Mala                   |
| Abhinav Tala Manjari                       | Nartan Niranaya             |
|                                            | Sangeet Sudhakar            |
|                                            | Sangeet Kalp Drumankur      |
|                                            | Raga Chandrika              |
|                                            | Raga Chandrika Sar          |

## 11.3 USTAD HABEEBUDDIN KHAN

## FACT SHEET

In this image we can see a person sitting and holding a bowl.

<!-- image -->

Birth name

Date of birth / death

Place of birth

Habibuddin Khan

1899 / 1 st  July 1972

Meerut

## 11.3.1 INTRODUCTION

Born in Meerut, in the year 1899 Ustad Habibuddin Khan started his training in Tabla under the guidance of his father Ustad Shammu Khan. He studied Delhi gharana from his teacher Ustad Nathhu Khan. Thereafter he studied Farrukabad  as  well  as  Lucknow gharana-s .  Ustad  Habibuddin  Khan  had good command over his banya (left drum) wherein he played complex tabla syllables very effectively and efficiently.

## 11.3.2 HIS STYLE OF PLAYING

Ustad  Habeebuddin  Khan  had  a  good  mastery  of  compositions  of  the Ajrada  Gharana .    His  dedication  towards  the  art  and  rigourous  practice helped him acquire the ability to play complex compositions at fast speed.

Ustad Habeebuddin Khan was an expert in both, solo performances and as well as in accompaniment. In fact, he was recognised as Sangat Samrat (king of accompanist).

Some of the well-known and prominent disciples of Ustad Habibuddin Khan are his son Manju Khan (Delhi), late Prof Sudhir Kumar Saxena (Baroda) and his nephew, late Ramzan Khan.

His health deteriorated, and in the year 1969, he suffered a paralytic attack, and after prolonged illness, he passed away on 1 st  July 1972.

In this image there is a picture of a pencil and a key.

<!-- image -->

## 11.4 PANDIT BIRJU MAHARAJ

In this image we can see a person standing and smiling. In the background there is a wall.

<!-- image -->

## FACT SHEET

Birth name

Date of birth

Place of birth

Awards

Brijmohan Mishra

4 th  February 1938

Lucknow

Padma Vibhushan in 1986 , Sangeet Natak Akademi Award Kalidas Samman honorary Doctorate degrees from Banaras Hindu University

Filmfare Award for Best Choreography for song 'Mohe Rang Do Laal' from 'Bajirao Mastani' in 2016 .

Lata Mangeshkar Puraskaar in 2002

Bharat Muni Sammaan 2012 National Film Award for Best Choreography: Vishwaroopam 2016 Filmfare award: Bajirao Mastani (Best choreography) 2017 *Tamil Nadu State Film Award for Best Choreographer- Vishwaroopam

## 11.4.1 INTRODUCTION

Pandit Birju  Maharaj was trained in Kathak dance by his uncles, Lachhu Maharaj  and  Shambhu  Maharaj  and  his  father,  Jagannath  Maharaj.  He gave his first recital at the age of seven. On 20 th  May 1947, at the age of 9 he lost his father. After a few years of struggle, his family moved to Delhi.

Pandit Birju  Maharaj, who is from the lucknow gharana ,  started  teaching the dance form of this particular style at the young age of thirteen, at the Sangeet Bharti in New Delhi. He then taught at the Bharatiya Kala Kendra in  Delhi,  and  the Kathak Kendra  (a  unit  of  the  Sangeet  Natak Akademi) where he was Head of Faculty, and director, retiring in 1998 after which he opened his own dance school, Kalashram, also in Delhi.

## 11.4.2 HIS CONTRIBUTION

He composed music, and sang, for two dance sequences in Satyajit Ray's Shatranj  ke  Khilari .  He  also  choreographed Kathak dance  sequences  in Dedh  Ishqiya as  well  as Umrao  Jaan ,  and Bajirao  Mastani directed  by Sanjay Leela Bhansali.

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

## 11.5 PANDIT RAVI SHANKAR

In this image we can see a person holding a musical instrument.

<!-- image -->

## FACT SHEET

| Birth name     | Rabindra Shankar Chowdhury                                                                                                                                                                                      |
|----------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Date of birth  | 7 th April , 1920 / December 11, 2012                                                                                                                                                                           |
| Place of birth | Benares                                                                                                                                                                                                         |
| Awards         | Sangeet Natak Akademi Award (1962) Padma Bhushan (1967) Sangeet Natak Akademi Fellowship (1975) Padma Vibhushan (1981) Kalidas Samman from the Government of Madhya Pradesh for 1987-88 Bharat Ratna (1999)[82] |

## 11.5.1 INTRODUCTION

Pandit Ravi Shankar was born on 7 th  April 1920 in Benares, in a Bengali family, as the youngest of seven brothers. His father, Shyam Shankar Chowdhury, was a Middle Temple barrister and scholar from  Bangladesh. At the age of 10, after spending his first decade in Benares, Pandit Ravi Shankar went to Paris with the dance group of his brother, choreographer Uday Shankar for a dance performance. By the age of 13, he had become a member of the group, and accompanied  its  members  on  tour,  and  learned  to  dance  and  play  various Indian  musical  instruments.  Uday's  dance  group  travelled  Europe  and  the United  States  in  the  early  to  mid-1930s  and  Shankar  learned  French, discovered Western classical music, jazz, cinema and became acquainted with Western customs.

## 11.5.2 HIS STYLE

Pandit Ravi Shankar developed a style distinct from that of his contemporaries and incorporated influences from rhythm practices of Carnatic music.  He  is from  the maihar  gharana and  his  performances  usually  begin  with alaap , jor-alaap ,  and jor-jhala (introduction  and  performances with pulse and rapid pulse) influenced by the slow and serious dhrupad genre, followed by a section with tabla accompaniment featuring compositions associated with the prevalent khayal style.  Pandit Ravi Shankar has been considered as one of the top sitar players in the 20 th century.

## 15.5.3 HIS CONTRIBUTION

Pandit Ravi Shankar popularised performing on the bass octave of the sitar for the alaap section. He became famous  for his distinctive playing style in the middle and high registers that used quick and short embellishments of the main string.

In this image we can see a pencil, a paper, a paper clip, a paper, a paper, a pencil, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a

<!-- image -->

From 1986 to 1992, Ravi Shankar served as a nominated member of the Rajya Sabha, the upper chamber of the Parliament of India.

DID YOU KNOW

POINTS TO REMEMBER:

## Pandit Vishnu Narayan Bhatkhande

Vishnu Narayan Bhatkhande

10 th  Aug 1860

19 th  Sept 1936 Notation writing

----

Pandit Birju Maharaja

Brijmohan Misra

04 th  Feb 1938

Still alive

Kathak

Lucknow

Musicologist

Birth name

Date of Birth

Date of Death

Field

Gharana

Bhimsen Joshi

Bhimsen Gururaj Joshi

4 th  Feb 1922

24 th  Jan 2011

Vocal Hindustani

Kirana

Musicologist

Birth name

Date of Birth

Date of Death

Field

Ustad Habeebuddin Khan

Habeebuddin Khan

1899

1 st  July 1972

Tabla

POINTS TO REMEMBER:

Pandit Ravi Shankar

Rabindra Shankar Chowdhury

7 th  Apr 1920

11 th  Dec 2012

Sitar

Gharana

Ajara

Maihar

Pandit Birju Maharaja choreographed the song Kaahe Chhed Mohe from the film Devdas (2002).

DID YOU KNOW

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

https://www.youtube.com/watch?v=xE8HmrRP6No https://www.youtube.com/watch?v=qFlaDkW-Rdw

https://youtu.be/UYT-IHNg9AM

https://youtu.be/p-ijCe1xRWQ

Make a poster presentation on any one of the above musicologists / exponents (Photos / life sketch / style).

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

Fill in the blanks with the appropriate words:

(Paris , Pandit Birju Maharaj, Walkeshwar, Pandit Bhimsen Joshi)

- a) …………..……. was trained by his uncles, Lachhu Maharaj and Shambhu Maharaj and his father, Jagannath Maharaj.
- b) At the age of ten, after spending his first decade in Benares, Pandit Ravi Shankar, went to ……………………….with the dance group of his brother.
- c)  A brilliant exponent in the field of Vocal Hindustani classical music, ……………………………is considered as a legend.
- d)  Pandit Vishnu Narayan Bhatkhande was born in a town called …………………….., in Mumbai on 10 th  August, 1860.

<!-- image -->

Name the field to which the following maestros belong to:

- a. Pandit Ravi Shankar

………………….

- b. Pandit Birju Maharaj

………………….

- c. Ustad Habibudin Khan

………………….

- d. Pandit Bhimsen Joshi

………………….

Assessment

List down two awards conferred to:

- a) Pandit Bhimsen Joshi

i.

……………………….

ii.

……………………….

- b) Pandit Ravi Shankar

i.

………………………

ii.

………………………

In this image, we can see a diagram.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Examine the structure of the rhythmic cycle.
- Describe the rhythmic cycle and its features.
- Memorise the compositions learnt.
- Recite,count and play the theka of roopak taal .
- Recite,count and play a kaida of ' DhaTi ' or ' TitKit ' in single and double speed a with minimum of three palta-s and a tihai .
- Recite,count and play simple mukhda-s at a given speed.
- Recite,count and play simple mohara-s at given speed.
- Recite,count and play simple damdaar and bedam tihai-s .
- Play prescribed compositions individually or in group without inhibitions.
- Demonstrate their creative skills through improvisations and compositional work.
- Appreciate the various prescribed compositions.

## 12.0   ROOPAK TAAL

## 12.1 DESCRIPTION:

Roopak taal is a rhythmic pattern consisting of 7 beats in one cycle.  There are three vibhaag-s divided  by  two khand-s .  The  first vibhaag consists  of  three beats, the second and third vibhaag-s consist of two beats each. Roopak taal is an exception among all the taal-s .  Both sam and khali fall on the first beat and is shown by a wave of hand while counting. Roopak taal is usually played to accompany classical, semi-classical and light songs. Tabla solo performances are also given in roopak taal .

## 12.1.1 THEKA OF ROOPAK TAAL

Matra:

Divisions:

In this image we can see a poster with some text and some images.

<!-- image -->

| Matra      | 1 2   | 3 4    |      | 5   | 6    | 7   |
|------------|-------|--------|------|-----|------|-----|
| Theka      | Tin   | Tin Na | Dhin | Na  | Dhin | Na  |
| Taal Signs | x     |        | 2    |     | 3    |     |
|            | Tin   |        |      |     |      |     |

## 12.1.2 KAIDA SET TO ROOPAK TAAL

## 12.1.2.1  KAIDA OF ' DHATI' SET TO ROOPAK TAAL

| Matra         | 1                               | 2                                     | 3                                   | 4                                           | 5                                       | 6                                           | 7                                         |
|---------------|---------------------------------|---------------------------------------|-------------------------------------|---------------------------------------------|-----------------------------------------|---------------------------------------------|-------------------------------------------|
| Theka         | Tin                             | Tin                                   | Na                                  | Dhin                                        | Na                                      | Dhin                                        | Na                                        |
| Taal Signs    | x                               |                                       |                                     | 2                                           |                                         | 3                                           |                                           |
| Kaida (Ekgun) | DhaS SDha TaS SDha              | SDha TiDha STa TiDha                  | TiDha Gena TiTa Gena                | GeNa Dhati KeNa Dhati                       | DhaTi DhaGe TaTi DhaGe                  | DhaS TinNa TaS DhinNa                       | DhinNa KiNa DhinNa GiNa                   |
| Kaida (Dugun) | DhaSSDha DhaSSDha TaSSTa TaSSTa | TiDhaGena TiDhaGena TiTaKeNa TiTaKeNa | DhaTiDhaS DhaTiDhaS TaTiTaS TaTiTaS | DhinNaSDha DhinNaSDha DhinNaSDha DhinNaSDha | TiDhaGeNa TiDhaGeNa TiDhaGeNa TiDhaGeNa | DhaTiDhaGe DhaTiDhaGe DhaTiDhaGe DhaTiDhaGe | TinNaKiNa TinNaKiNa DhinNaGiNa DhinNaGiNa |
| Palta 1       | DhaSSDha TaSSTa                 | TiDhaGena TiTaKeNa                    | DhaTiDhaS TaTiTaS                   | DhaTiGiNa DhaTiGiNa                         | DhaTiGiNa DhaTiGiNa                     | DhaTiDhaGe DhaTiDhaGe                       | TinNaKiNa DhinNaGiNa                      |
| Palta 2       | DhaSSDha TaSSTa                 | TiDhaGena TiTaKeNa                    | DhaTiDhaS TaTiTaS                   | DhaSGiNa DhaSGiNa                           | DhaTiGiNa DhaTiGiNa                     | DhaTiDhaGe DhaTiDhaGe                       | TinNaKiNa DhinNaGiNa                      |
| Palta 3       | DhaSSDha TaSSTa                 | TiDhaGena TiTaKeNa                    | DhaTiDhaS TaTiTaS                   | DhaSGiNa DhaGeNaDha                         | DhaTiGiNa TiDhaGeNa                     | DhaTiDhaGe DhaTiDhaGe                       | TinNaKiNa DhinNaGiNa                      |
| Tihai         | DhaSSDha DhaTiDhaGe             | TiDhaGena DhinNaGina                  | DhaTiDhaGe DhaSSS                   | DhinNaGiNa DhaSSDha                         | DhaSSS TiDhaGeNa                        | DhaSSDha DhaTiDhaGe                         | TiDhaGeNa DhinNaGiNa                      |
| Tin           | Tin                             | Tin                                   | Tin                                 |                                             |                                         |                                             |                                           |
| Taal Signs    | x                               |                                       |                                     | 2                                           |                                         | 3                                           |                                           |

<!-- image -->

## In the previous chapters, students have learnt about:

- The execution of the syllables ' DhaTi' and ' TaTi' with proper technique.
-    How to recite, count and play exercises in different patterns with the syllables ' DhaTi' and ' TaTi '.

<!-- image -->

Some exercises to be played before playing the kaida .

| Matra      | 1     | 2     | 3     | 4    | 5                    | 6    | 7     | 8    |
|------------|-------|-------|-------|------|----------------------|------|-------|------|
| Exercise 1 | Ta    | Ti    | Ta    | Ti   | Ta                   | Ti   | Ta    | Ti   |
| Exercise 2 | Dha   | Ti    | Dha   | Ti   | Dha                  | Ti   | Dha   | Ti   |
| Exercise 3 | Dha   | Ti    | Ta    | Ti   | Dha                  | Ti   | Ta    | Ti   |
| Exercise 4 | DhaTi | TaTi  | DhaTi | TaTi | DhaTi                | TaTi | DhaTi | TaTi |
| Exercise 5 | DhaTi | GiNa  | TaTi  | KiNa | DhaTi                | GiNa | TaTi  | KiNa |
| Exercise 6 | DhaS  | SDha  | TiDha | GeNa | TaS                  | STa  | TiTa  | KeNa |
| Exercise 7 | DhaTi | DhaGe | TinNa | KiNa | DhaTiDhaGeDhinNaGiNa |      |       |      |

<!-- image -->

-  Memorise the kaida .
- Padhant of the kaida in ekgun at a steady rhythm.
-  Execution of the kaida in ekgun .
- Padhant of the kaida in ekgun and dugun .

<!-- image -->

<!-- image -->

<!-- image -->

## Step    6

-   Execution of kaida in ekgun and dugun .
- Padhant of each palta .
-   Execution of each palta .
- Padhant of the tihai .
-   Execution of the tihai .
- Padhant of the kaida in ekgun and dugun with the given palta-s and tihai .
-   Execution of the kaida in ekgun and dugun with the given palta-s and tihai .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

ACTIVITY 1

Listen  to  the  teacher  playing  the  kaida  of  DhaTi  in ekgun  and  dugun  with  two  paltas  and  tihai  set  to roopak taal.

After  listening,  the  students  are  grouped  in  different team and are asked the following questions.

6. In how many avartans is the kaida set?
7. In which laya was the kaida played?
8. Identify the type of tihai played?

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

1

Write into notation form the kaida of DhaTi in ekgun and dugun with two palta-s and a tihai set to roopak taal.

Assessment

Recite,count and play the kaida of DhaTi in ekgun and dugun with two palta-s and a tihai set to roopak taal.

## 12.3.1.2 KAIDA OF TITKIT SET TO ROOPAK TAAL

| Matra         | 1                  | 2                  | 3                  | 4      | 5      | 6      | 7      |
|---------------|--------------------|--------------------|--------------------|--------|--------|--------|--------|
| Theka         | Tin                | Tin                | Na                 | Dhin   | Na     | Dhin   | Na     |
| Taal Signs    | x                  |                    |                    | 2      |        | 3      |        |
| Kaida (Ekgun) | Dha                | Ti                 | Dha                | Dha    | Tit    | Kit    | Dha    |
|               | Ti                 | Dha                | Ge                 | Tin    | Na     | Ki     | Na     |
|               | Ta                 | Ti                 | Ta                 | Ta     | Tit    | Kit    | Dha    |
|               | Ti                 | Dha                | Ge                 | Dhin   | Na     | Gi     | Na     |
| (Dugun)       | DhaTi              |                    | DhaDhaTitKit       | DhaTi  | DhaGe  | TinNa  | KiNa   |
|               | TaTi               | TaTa               | TitKit             | DhaTi  | DhaGe  | DhinNa | GiNa   |
|               | DhaTi              | DhaDhaTitKit       |                    | DhaTi  | DhaGe  | TinNa  | KiNa   |
|               | TaTi               | TaTa               | TitKit             | DhaTi  | DhaGe  | DhinNa | GiNa   |
| Palta 1       | DhaTi              |                    | DhaDhaTitKit       | DhaDha | TitKit | DhaDha | TitKit |
|               | DhaTi              | DhaDhaTitKit       |                    | DhaTi  | DhaGe  | TinNa  | KiNa   |
|               | TaTi               | TaTa               | TitKit             | TaTa   | TitKit | TaTa   | TitKit |
|               | DhaTiDhaDhaTitKit  |                    |                    | DhaTi  | DhaGe  | DhinNa | GiNa   |
| Palta 2       |                    | DhaTiDhaDhaTitKit  |                    | SDha   | TitKit | DhaDha | TitKit |
|               | DhaTi              | DhaDhaTitKit       |                    | DhaTi  | DhaGe  | TinNa  | KiNa   |
|               | TaTi               | TaTa               | TitKit             | STa    | TitKit | TaTa   | TitKit |
|               | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | DhaTi  | DhaGe  | DhinNa | GiNa   |
| Palta 3       | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | SDha   | TitKit | SDha   | TitKit |
|               | DhaTi DhaDhaTitKit | DhaTi DhaDhaTitKit | DhaTi DhaDhaTitKit | DhaTi  | DhaGe  | TinNa  | KiNa   |
|               | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | STa    | TitKit | STa    | TitKit |
|               | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | DhaTiDhaDhaTitKit  | DhaTi  | DhaGe  | DhinNa | GiNa   |

| Tihai      | DhaTi DhaDha TitKit DhaTi TitKit DhaTi DhaS DhaTi DhaDha Tin   |   DhaS |   DhaTi DhaDha TitKit DhaTi |
|------------|----------------------------------------------------------------|--------|-----------------------------|
| Taal Signs | x                                                              |      2 |                           3 |

<!-- image -->

## In the previous chapters, students have learnt about:

-      The execution of the syllables  ' Tit ', ' TitKit ', ' Dhati ' and ' TaTi '  with proper technique.
-      How to recite, count and play exercises in different patterns with the syllables ' TitKit ' and ' DhaTi '.

<!-- image -->

Some exercises to be played before playing the kaida .

| Matra      | 1      | 2      | 3            | 4      | 5                      | 6    | 7          | 8      |
|------------|--------|--------|--------------|--------|------------------------|------|------------|--------|
| Exercise 1 | Ti     | t      | Ki           | t      | Ti                     | t    | Ki         | t      |
| Exercise 2 | Tit    | Kit    | Tit          | Kit    | Tit                    | Kit  | Tit        | Kit    |
| Exercise 3 | Dha    | Dha    | Tit          | Kit    | Ta                     | Ta   | Tit        | Kit    |
|            | DhaDha | TitKit | TaTa         | TitKit | DhaDhaTitKitTaTaTitKit |      |            |        |
| Exercise 4 | DhaS   | Tit    | Kit          | TaKa   | TaS                    | Tit  | Kit        | TaKa   |
| Exercise 5 | DhaTi  | DhaTi  | DhaDhaTitKit |        | TaTi                   | TaTi | TaTa       | TitKit |
| Exercise 6 | DhaTi  | DhaGe  | TinNa        | KiNa   | TaTi                   | TaKe | DhinNaGiNa |        |

<!-- image -->

-  Memorise the kaida .

## Step    3

- Padhant of the kaida in ekgun at a steady rhythm.
-  Execution of kaida in ekgun.
- Padhant of the kaida in ekgun and dugun .

<!-- image -->

<!-- image -->

## Step    6

-  Execution of the kaida in ekgun and dugun.
- Padhant of each palta .

<!-- image -->

## Step    8

<!-- image -->

-  Execution of each palta .
- Padhant of the tihai .
-  Execution of the tihai .
- Padhant of the kaida in ekgun and dugun with the given palta-s and tihai .
-  Execution of the kaida in ekgun and dugun with the given palta-s and tihai .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Padhant should always be carried out before playing exercises and kaida .

Practical exercises should be carried out as per given steps.

Each syllable in the kaida should be executed with force and clarity at a pace convenient to the students.

Additional palta-s can be taught to the students and the tihai can be changed accordingly by the class teacher.

In this image we can see a paper with a pen on it.

<!-- image -->

Listen  to  the  teacher  playing  the  kaida  of  TitKit  in ekgun  and  dugun  with  two  paltas  and  tihai  set  to roopak taal.

After  listening,  the  students  are  grouped  in  different team and are asked the following questions.

1. In how many avartans is the kaida set?
2. In which laya was the kaida played?
3. Identify the type of tihai played?

ACTIVITY 1

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

Write into notation form a kaida of TitKit in ekgun and dugun with two palta-s and a tihai set to roopak taal.

<!-- image -->

Recite,  count  and  play  the  rela  of  kaida  of  TitKit  in  ekgun  and dugun with two palta-s and a tihai set to roopak taal.

## 12.1.4 MUKHDA

One example of a mukhda is given below:

| Matra      | 1 2                 | 3              | 4      | 5       | 6 7            |
|------------|---------------------|----------------|--------|---------|----------------|
| Theka      | Tin Tin             | Na             | Dhin   | Na Dhin | Na             |
| Taal Signs | x                   |                | 2      |         | 3              |
| Mukhda     | DhaDhaTinNaKidaNaKa |                | TitKit | TaKaTaS | TitKit DhaSSS  |
|            | TitKit              | TaKaTaS TitKit | DhaSSS | TitKit  | TaKaTaS TitKit |
|            | Tin                 |                |        |         |                |
| Taal Signs | x                   |                | 2      |         | 3              |

<!-- image -->

## In the previous chapters, students have learnt about:

-  How to recite, count and play the theka of roopak taal at a steady rhythm.
-  How to recite, count and play different patterns with different group of syllables.
- Some exercises to be played before playing the mukhda .
- Padhant of the theka of roopak taal at a steady rhythm.
-  Play the theka of roopak taal at a steady rhythm.

<!-- image -->

| Matra      | 1                           | 2                           | 3                           | 4                           | 5                           | 6   | 7    | 8   | 9 10    |
|------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----|------|-----|---------|
| Exercise 1 | Ki                          | da                          | Na                          | Ka                          |                             |     |      |     |         |
| Exercise 2 | Kida                        | NaKa                        | Kida                        | NaKa                        |                             |     |      |     |         |
| Exercise 3 | Tit                         | Kit                         | TaKa                        | TaS                         | Tit                         | Kit | DhaS | SS  |         |
| Exercise 4 | TitKit TaKaT aSTitKitDhaSSS | TitKit TaKaT aSTitKitDhaSSS | TitKit TaKaT aSTitKitDhaSSS | TitKit TaKaT aSTitKitDhaSSS | TitKit TaKaT aSTitKitDhaSSS |     |      |     |         |
| Exercise 5 | Kida                        | NaKa                        | Tit                         | Kit                         | TaKa                        | TaS | Tit  | Kit | DhaS SS |

<!-- image -->

<!-- image -->

<!-- image -->

.

-  Recite, count and play the different groups of syllables of the mukhda

In this image we can see a paper with some text and a picture of a person holding a pen.

<!-- image -->

ACTIVITY 1

To  work  in  different  groups  where  each group will recite, count and play the different phrases of the mukhda .

Then , afterwards they will do same for the whole mukhda .

## 16.1.5 MOHARA

## EXAMPLES OF MOHARA-S SET TO ROOPAK TAAL

| Matra      | 1   | 2   | 3   | 4    | 5      | 6       | 7      |
|------------|-----|-----|-----|------|--------|---------|--------|
| Theka      | Tin | Tin | Na  | Dhin | Na     | Dhin    | Na     |
| Taal Signs | x   |     |     | 2    |        | 3       |        |
|            | Tin |     |     |      |        |         |        |
| Mohara 1   | Tin | Tin | Na  | Dhin | Na     | DhaDha  | TitKit |
| Mohara 2   | Tin | Tin | Na  | Dhin | Na     | SDha    | TitKit |
| Mohara 3   | Tin | Tin | Na  | Dhin | TitKit | TaKaTaS | TitKit |
|            | Tin |     |     |      |        |         |        |
| Taal Signs | x   |     |     | 2    |        | 3       |        |

<!-- image -->

## In the previous chapters, students have learnt about:

-   How to recite, count and play the theka of roopak taal at a steady rhythm.
-   How to recite, count and play different patterns with different groups of syllables.
- Padhant of the theka of roopak taal at a steady rhythm.
- Execution of the theka of roopak taal at a steady rhythm.
- Recite, count and play each mohara .

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a paper with some text and a pencil.

<!-- image -->

ACTIVITY 1

Work in small groups and compose one mohara set to roopak taal with different group of  syllables starting:

- (i) Last two beats.
- (ii)  Last three beats.
- (iii)  Last four beats.

In this image, we can see a paper with some text written on it.

<!-- image -->

## 16.1.6 TIHAI

## 16.1.6.1 DAMDAAR TIHAI

## EXAMPLES OF DAMDAAR TIHAI SET TO ROOPAK TAAL

| Matra      | 1 2 3            | 4      | 5    | 6      | 7   |
|------------|------------------|--------|------|--------|-----|
| Theka      | Tin Tin Na       | Dhin   | Na   | Dhin   | Na  |
| Taal Signs | x                | 2      |      | 3      |     |
|            | Tin              |        |      |        |     |
| Tihai 1    | DhaDhaTit DhaDha | Tit    | DhaS | DhaDha | Tit |
|            | DhaDhaTit DhaS   | DhaDha | Tit  | DhaDha | Tit |
|            | Tin              |        |      |        |     |
| Tihai 2    | Tit DhaS SS      | Tit    | DhaS | SS     | Tit |
|            | Tin              |        |      |        |     |
| Taal Signs | x                | 2      |      | 3      |     |

## EXAMPLES OF BEDAM TIHAI SET TO ROOPAK TAAL

| Matra      | 1 2 3             | 4     | 5     | 6      | 7    |
|------------|-------------------|-------|-------|--------|------|
| Theka      | Tin Tin Na        | Dhin  | Na    | Dhin   | Na   |
| Taal Signs | x                 | 2     |       | 3      |      |
|            | Tin               |       |       |        |      |
| Tihai 1    | NaNa Gina DhaNa   | NaGi  | naDha | NaNa   | Gina |
|            | Tin               |       |       |        |      |
| Tihai 2    | DhaDha Tit DhaDha | DhaTi | tDha  | DhaDha | Tit  |
|            | Tin               |       |       |        |      |
| Taal Signs | x                 | 2     |       | 3      |      |

In this image we can see a paper with some text and a picture of a person.

<!-- image -->

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

## Complete the following damdaar tihai-s with the appropriate syllables.

| Matra      | 1 2 3              | 4      | 5    | 6    | 7    |
|------------|--------------------|--------|------|------|------|
| Tihai      | DhaTi DhaS SS      | DhaTi  | ………  | …….. | …….. |
|            | Tin                |        |      |      |      |
| Taal Signs | x                  | 2      |      | 3    |      |
| Tihai      | DhaDhaTitKitDhaDha | TitKit | DhaS | ………  | …….. |
|            | ………. …….. ……….     | ……….   | …….. | ………. | ………  |
|            | Tin                |        |      |      |      |
| Taal Signs | x                  | 2      |      | 3    |      |

Assessment

2

Write into notation form a bedam tihai set to roopak taal.

In this image we can see a poster with a design. In the design we can see a mobile phone and some text.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Describe the use and importance of technology in music.
- List the benefits of technology in music.
- Explain briefly the term electrophone.
- List the precautions to be taken while handling the electronic or electric music devices.
- Distinguish between acoustic and electronic instruments.
- Handle electronic and electric musical devices properly.

## 13.0 MUSIC AND TECHNOLOGY

Music has always been a fascinating subject for people around the globe. Some people have been practising music as a heritage, some have shown an interest in learning the subject, and some people just enjoyed listening to  music. Initially,  all  these  were  done in a purely acoustic way, as there were no technological facilities available then.

The advent of technology has given a great boost to the field of music. The use  of  microphones,  amplifiers,  recordings,  radio  and  television  gave  a better aperture of music to the mass. People are more exposed to music through radio and television. The sound of acoustic musical instruments is amplified and broadcasted through loudspeakers. Previously, songs were recorded  on  vinyl  discs  or  magnetic  tapes.  People  used  disc  players or  radio  cassettes  to  listen  to  their  desired  songs.  Though  very  rare, vinyl  disks could be found as an antiquity whereas the cassette tapes are still in use.

In this image, we can see some objects. There is a blue color background.

<!-- image -->

Television  has  made  music  more  visual.  People  started  to  have  an audiovisual education about music. They can see the performers and the different types of musical instruments used.

The  invention  of  the  computer and  the  shift  from  analogue  to digitalisation,  by  the  end  of  the 20 th century,  has  contributed  in enhancing  the  quality  of  music and musical performances. Modern recording studios are available  for  digital  recordings. Consequently, there has been an improvement  in  the quality of sound.

In this image we can see a few electronic instruments. There are some wires and cables.

<!-- image -->

Compact  discs  (CDs)  are  used  to  keep musical recordings instead of vinyl discs or magnetic tapes. The former have a greater storage  capacity  and  have  a  longer  life span compared to vinyl discs and magnetic tapes.

Digitalisation  has  not  only  enhanced  the quality  of  sound  in  music  but,  it  has  also contributed to enhance the image quality of video recordings. Small but very performant video  cameras  can  give  both  high  quality sound and images. Now, people are able to listen  to  surround  sound systems together with 7D video images.

In this image we can see a CD with some text on it.

<!-- image -->

As a result, many music and dance programs are available on the internet. Internet radio is becoming increasingly popular. Sometimes, self-learning of music also takes place through the internet.

Live popular musical concerts are becoming more attractive with the use of sound and light technology. People are using wireless sound systems due to  Bluetooth  technology.  Small  but  powerful  loudspeakers  are  used  in public concerts.

In this image we can see a building with windows and lights. There are some objects on the ground.

<!-- image -->

Electrophones are a new category of musical instruments which use both, electrical  and  electronic  technologies.  They  need  electrical  power  to  be operated. Electronic chips are used to enable the instruments to produce a panoply of sound.

Electronic keyboard is a very popular musical instrument classified as an electrophone. Sounds of different musical instruments can be produced via a  keyboard.  The  latest  keyboards  are  better  equipped  and  are  able  to produce sounds of various Indian musical instruments.

In this image we can see a piano.

<!-- image -->

In this image there is a board with some text on it.

<!-- image -->

Some  electrophones  are  smaller  in  size  compared  to  the  traditional acoustic musical instrument. The drum pad or the electronic tanpura are small electrophones.

In this image we can see a musical instrument. On the right side there is a drum pad.

<!-- image -->

In this image I can see a guitar and a switch board.

<!-- image -->

## 13.1 BENEFITS OF TECHNOLOGY IN MUSIC

|   1 | Acoustic musical instruments can be amplified, and their sound can be properly heard.                                      |
|-----|----------------------------------------------------------------------------------------------------------------------------|
|   2 | The quality of sound has been enhanced .                                                                                   |
|   3 | Musical compositions can be archived for longer periods.                                                                   |
|   4 | Musical concerts are made more appealing through the use of sound and light technologies.                                  |
|   5 | Music can be broadcasted to a wider range of people through radio and television.                                          |
|   6 | People are exposed to a large variety of musical programs around the world through the internet.                           |
|   7 | Electrophones are smaller and easier to be carried.                                                                        |
|   8 | Electrophones can last longer than acoustic musical instruments as they are not affected by climate or temperature change. |
|   9 | Too many musicians might not be needed for a musical program.                                                              |
|  10 | More sophisticated recording studios are available.                                                                        |

## 18.2 SAFETY PRECAUTIONS

SAFETY PRE

- Electric sockets should have proper ground wiring installation.

CAUTIONS

- Avoid using multi plugs as far as possible.
- Always ensure that the electrophone uses the same voltage as  provided by your electric supplier.
- Avoid handling electrophones with wet hands.

<!-- image -->

Analogue, Digitalisation, amplified, broadcasted, bluetooth technology.

In this image we can see a circle.

<!-- image -->

Make  poster  presentations  of  the different types of electrophones used in Indian music.

<!-- image -->

Discuss about the contribution of technology in Indian music.

POINTS TO REMEMBER:

- Technology has made music more accessible to people.
- Technology has contributed to enhance the quality of sound in music.
- People are more exposed to music through radio and television.
- Previously, music was recorded on vinyl discs and cassette tapes.
- Compact discs have a greater storage capacity and it lasts longer.
- Internet radio is becoming more and more popular.
- Light and sound technologies are used to make popular concerts attractive.
- Some electric and electronic musical instruments are smaller and easier to carry.

## END OF CHAPTER QUESTIONS ASSESSMENT

Assessment

7

## State whether the following is True or False.

- (i)   Technology gave a boost to the field of music. (………)
- (ii)  Microphones and amplifiers are used for broadcasting through loudspeakers. (………)
- (iii) Radio and television prevented people from listening to music. (………)
- (iv) Music was initially recorded on vinyl discs and magnetic tapes. (…..….)
- (v) Compact discs have a smaller storage capacity than vinyl discs. (………)
- (vi) The use of sound and light technology have made popular concerts dull. (………)
- (vii) Self-learning of music can be done on the internet. (………)
- (viii)Sound of different musical instruments can be produced on a keyboard. (…………)
- (ix) Long wires are needed while using the Bluetooth technology. (………)
- (x) Sound production varies due to temperature change in electrophones. (………)

<!-- image -->

Write a short essay of 150 words on the benefits of technology in music.

<!-- image -->

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

Assessment

3

Name the following appliances and give one use of each in the field of music.

(i)

(ii)

<!-- image -->

<!-- image -->

Name: ………………………………

Name: ………………………………

Use:    ………………………………

Use:    ………………………………

(iv)

(v)

<!-- image -->

<!-- image -->

Name: ………………………………

Name: ………………………………

Use:    ………………………………

Use:    ………………………………

(vi)

<!-- image -->

Name: ………………………………

Use:    ………………………………

In this image, we can see a paper with a paper clip and some text on it.

<!-- image -->

In this image we can see a poster. On the poster we can see a few things.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

- Execute and adapt advanced integrated movements through the bol-s and phrases prescribed.
- Respond to stimulus in a competent way.
- Practise the prescribed phrases rigorously and vigorously.
- Adhere to a practice schedule.
- Develop a positive attitude towards riyaaz and the Art.

## 14.0 RIYAAZ:

Riyaaz is the technical term used for practice in Indian music.It is the repetition of any activity aiming towards accuracy and perfection. It is an important activity  in  the  field  of  performing  arts.One  can  never  play  properly  with confidence without regular practice.

Riyaaz in music brings self-discipline and self-confidence. Regular practice is a must in the field of performing arts. There are certain principles to follow in order to make the most of one's practice.

In this image, we can see a poster with some text and some images.

<!-- image -->

06

should

Riyaaz always be done in a

In this image, we can see a poster with some text and images.

<!-- image -->

## 14.1 RIYAAZ:

S

## A F E T Y FI R ST

- Always carry out some basic warming up exercises before starting  your practice.
- Pay particular attention to your sitting position to avoid any body strain.
- Stand up for a while whenever any body pain is felt.
- It is recommended to practise as long as it is fruitful.
- Always  clean  your  instrument,  and  keep  it  safely  in  a designated and dignified area in the room.

<!-- image -->

Practice, Perfection, Confidence, Discipline, Principles, Concentration, Conducive, Dedication, Devotion.

<!-- image -->

The different groups of syllables listed below should be practised.

1. Dhikit
2. DhaSna Dhikit
3. DhaTraka Dhikit
4. Dhina Gina
5. Kradhi Tit
6. Ding Dina Gina
7. Tit Kata Gadi Gina

## Step    1

- This compound syllable consists of three syllables, namely ' Dhi ', ' Ki ' and ' t '.
- Execution of the compound syllable ' Dhikit '.

<!-- image -->

<!-- image -->

<!-- image -->

## Dhi

t

## Ki

-  The teacher will demonstrate how to execute these three syllables.
-   The students will then practise each syllable separately at a slow pace with force.

1          2         3

| BEAT       | 1   | 2   |
|------------|-----|-----|
| Exercise 1 | Dhi | ki  |

## Step    2

-  Execution of the compound syllables ' DhaSna Dhikit '.
-  This compound syllable consists of two groups of syllables, namely ' DhaSna ' and ' Dhikit '.

<!-- image -->

<!-- image -->

Dha

na

<!-- image -->

Dhi

<!-- image -->

<!-- image -->

t

Ki

-  The teacher will demonstrate how to execute these two groups of syllables separately.
-  The students will then practise each  group of syllables separately at a slow pace with force.
- Execution of the syllable ' Traka '.

<!-- image -->

<!-- image -->

Tra

<!-- image -->

ka

- To practise the compound syllable ' DhaTraka Dhikit '.

- This compound syllable consists of two groups of syllables, namely ' DhaTraka ' and ' Dhikit '.
- The teacher will demonstrate how to execute these two groups of syllables.
-  The students will then practise each syllable separately at a slow pace with force.
- Execution of the compound syllable  ' Dhina Gina '.
- This compound syllable consists of two groups of syllables, namely ' Dhina '  and ' Gina '.
- The teacher will demonstrate how to execute these two groups of syllables.
- The students will then practise each syllable separately at a slow pace with force.

| BEAT       | 1      | 2     | 3   | 4      | 5     | 6   |
|------------|--------|-------|-----|--------|-------|-----|
| Exercise 1 | Tra    | Tra   | Tra | Tra    |       |     |
| Exercise 2 | Tra    | ka    | Tra | ka     |       |     |
| Exercise 3 | Dha    | Tra   | ka  |        |       |     |
| Exercise 4 | Dhi    | ki    | t   |        |       |     |
| Exercise 5 | Dha    | Tra   | ka  | Dhi    | ki    | t   |
| Exercise 6 | DhaTra | kaDhi | kit | DhaTra | kaDhi | kit |

<!-- image -->

In this image we can see a person playing drums.

<!-- image -->

1          2          3          4

| BEAT       | 1     | 2    | 3     | 4    |
|------------|-------|------|-------|------|
| Exercise 1 | Dhi   | na   | Dhi   | na   |
| Exercise 2 | Gi    | na   | Gi    | na   |
| Exercise 3 | Dhina | Gina | Dhina | Gina |

<!-- image -->

- Execution of the compound syllable ' Kradhi Tit '.

Kra

<!-- image -->

<!-- image -->

<!-- image -->

Ti

t

dhi

<!-- image -->

- This compound syllable consists of two groups of syllables, namely ' Kradhi ' and ' Tit '.
- The teacher will demonstrate how to execute these two groups of syllables.
- The students will then practise each  group of syllable separately at a slow pace with force.

1          2          3          4

| BEAT       | 1      | 2   | 3      | 4   |
|------------|--------|-----|--------|-----|
| Exercise 1 | kra    | kra | kra    | kra |
| Exercise 2 | kra    | dhi | Ti     | t   |
| Exercise 3 | kradhi | Tit | kradhi | Tit |

## Step    6

-  Execution the compound syllable ' Ding DiNa Gina '  or 'Dhina DhinNa Gina'.

<!-- image -->

Dhi

<!-- image -->

<!-- image -->

<!-- image -->

Dhin

<!-- image -->

na

Gi

<!-- image -->

na

- This compound syllable consists of three groups of syllables, namely ' Ding ', ' Dina ' and ' Gina '.
- The teacher will demonstrate how to execute these three groups of syllables.
- The students will then practise each syllable separately at a slow pace with force.

1          2         3

Na

| BEAT       | 1    | 2    | 3    |
|------------|------|------|------|
| Exercise 1 | Ding | Ding | Ding |
| Exercise 2 | Ding | DiNa | Gina |

## Step    7

-  Execution of the compound syllable ' Tit Kata Gadi Gina '.

<!-- image -->

Ti

<!-- image -->

<!-- image -->

<!-- image -->

Ga

<!-- image -->

di

Gi

na

t

Ka

<!-- image -->

ta

<!-- image -->

<!-- image -->

- This compound syllable consists of four groups of syllables namely ' Tit ', ' Kata ', ' Gadi ' and ' Gina '.
- The teacher will demonstrate how to execute these four groups of syllables.
- The students will then practise each syllable separately at a slow pace with force.

1          2          3          4

| BEAT       | 1    | 2    | 3    | 4                              |
|------------|------|------|------|--------------------------------|
| Exercise 1 | Tit  | Kata | Tit  | Kata                           |
| Exercise 2 | Gadi | Gina | Gadi | Gina                           |
| Exercise 3 | Tit  | Kata | Gadi | Gina                           |
| Exercise 4 |      |      |      | TitKataGadiGinaTitKataGadiGina |

NOTE

-  Emphasis should be laid on playing techniques and sound production.
-  The speed and duration of practice can be increased gradually according to the convenience of the student.

## END OF CHAPTER QUESTIONS ASSESSMENT

<!-- image -->

<!-- image -->

List five principles to be followed while doing riyaaz.

| (i)   | ……………………………………………………………….   |
|-------|-----------------------------|
| (ii)  | ………………………………………………………………    |
| (iii) | ……………………………………………………………….   |
| (iv)  | …………………………………………………………….... |
| (v)   | ……………………………………………………………….   |

Assessment

2

## Recite, count and play  the following  exercises:

1          2          3          4

| BEAT       | 1      | 2      | 3        | 4      |
|------------|--------|--------|----------|--------|
| Exercise 1 | Ding   | Dina   | Gina     |        |
| Exercise 2 | DhaSna | Dhikit | DhaTraka | Dhikit |
| Exercise 3 | Tit    | Kata   | Gadi     | Gina   |

Adi laya:

One and a half times the basic speed. musial instruments in which sound is produced

Aerophones:

by air.

Avartan:

Complete cycle.

Avgraha:

Used to show a silent beat in Indian music T erm used for membranophones in Indian

Avnadh:

music.

Bhari:

Part where the tali starts.

Bhojpuri: Language brought to Mauritius by the Indian immigrants in Mauritius.

Bol:

Syllable played on tabla.

Bollywood:

Indian film industry.

Carnatic music:

Music practised in south of India.

Chordophones:

Stringed musical instruments, sound is produced

by the vibration of srtings.

Classical/Art Music:

style based on strict musical rules.

Damdaar tihai:

Consists of a pause after each phrase.

Dragon Dance:

Dance style practised by the Chinese community. Fast speed.

Drut laya:

Dugun:

Double speed of basic laya.

Dusri  :

Accented beat in a taal.

Ekgun:

Single speed.

Electrophones: Musical instruments through which sound is produced either electrically, or electronically. Folk Music: Traditional music inherited from ancestors. Geet Gawai: Ritual performed on the eve of a Hindu wedding in Mauritius.

Genre:

Different types.

Ghan: Term used for idiophones in Indian  music. Guruji: Term usually used to address a spiritual guide or a teacher in Indian culture.

Hindustani music: Music practised in the north of India. Idiophones: Solid instruments through which sound is produced by friction.

Instrumental music:

Playing musical instruments.

Iqa:

Rhythmic cycle in Arabian music.

Jhakri:

Folk dance practised by the Marathi community.

Kaida:

Composition played on the tabla.

Khali:

Unaccented beat in a taal.

Khand:

Vertical bar used to divide a rhythmic cycle.

Khayal:

Vocal style practised in the north of Indian.

Kolattam: Stick usually used in folk dance by the Tamil and T elegu communities.

Kriya: Hand movements done while counting a composition in Indian music.

Laggi:

Small composition played on the tabla.

Laya:

T erm used for speed in Hindustani music.

Layakari: Showing different laya-s with respect to an established basic speed.

Lion Dance:

Dance style practised by the Chinese community.

Madhya laya:

Normal speed.

Madhya saptak:

Middle octave.

Mandra saptak:

Lower octave.

Maqam:

A system upon which Arabian classical music is

based.

Matra:

Unit of measuring time in music.

Membranophones: Musial instruments through which sound is produced by sticking on a membrane either by hand or using

a stick.

Mohara:

Composition played on the tabla.

Mridangam: Percussion instrument used to provide rhythm in South Indian music.

Mukhda:

Composition played on the tabla.

Multi-ethnical:

Different ethnic groups.

Music: Performing Art used to express moods, feelings or emotion by singing or the playing of musical instruments. Naad: Sound.

Padhant:

Action of reciting and counting a composition in Indian

music.

Pakhawaj: Percussion instrument used to provide rhythm in North Indian music.

Palla:

Musical pattern played in a tihai.

Palta:

Variation.

Popular Music:

Musical style performed mainly for entertainment or profit making.

Prakar:

Type.

Ramabhajanam:

Ritual practised by the Telugu commmunity Composition played on the tabla.

Rela:

Rhythm:

An action or group of actions  repeated at a regular speed.

Riyaaz:

## Practice.

Sam:

First, an most accented beat in a taal.

Sangeet:

Indian term consisting of Vocal music, Instrumental music and Dance.

Sangeet Vadya:

Musical instrument.

Sangita Ratnakar:

Indian music treatise written in the 13th century.

Saptak:

Arrangement of seven swara-s from lower to higher notes.

Sega:

Popular folk dance of Mauritius.

Shastriya Sangeet:

Indian classical music.

Shudha swara:

Natural note.

Solo:

Presenting a musical or dance performance individually.

Sushir:

Term used for aerophones in Indian music.

Swara:

Term used for a musical note in Indian music.

Taal:

Rhythmic cylcle in Indian music.

Taar saptak:

Higher octave.

Tabla:

Indian percussion instrument used to provide rhythm.

Takht:

Musical ensemble in Arabian music.

Tali:

Accented beat in a taal.

Tat:

Term used for chordophones in Indian music.

Theka:

Pre-set bols through which a taal is recognised.

Tihai: Musical phrase played three times consecutively to end a composition or a performance in Hindustani music.

Tisri:

Accented beat in a taal.

Tit:

Tabla syllable.

Tit Kit:

Tabla syllable.

Tivra swara:

Sharp note.

Vibhaag:

Section.

Vilambit laya:

Slow speed.

Vocal music:

Singing.

In this image, we can see a poster with some text and images.

<!-- image -->