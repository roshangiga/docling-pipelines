## TECHNOLOGY STUDIES: DESIGN AND TECHNOLOGY

Grade

9

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of Ministry of Education, Tertiary Education and Scientific Research

## DESIGN AND TECHNOLOGY T E C H N O L O G Y S T U D I E S :

Grade

9

Design &amp; Technology

I

Dr Aruna Ankiah-Gangadeen, Head Curriculum Development, Implementation and Evaluation

## TECHNOLOGY STUDIES: DESIGN &amp; TECHNOLOGY PANEL

Robin Ramsamy

- Coordinator, Lecturer, MIE

Navin Hurreeram

- Senior Lecturer, MIE

Aartee Jodheea

- Lecturer, MIE

Ismut Belath

- Lecturer, MIE

Damien Chavry

- Educator

Atish Chatooree

- Educator

Nishal Teelokee

- Educator

Pravind Ujhoodha

- Educator

## Design

Kunal Sumbhoo

- Graphic Designer, MIE

Leveen Nowbotsing

- Graphic Designer, MIE

<!-- image -->

© Mauritius Institute of Education (2023) ISBN: 978-99949-75-25-9

## Acknowledgements

The Technology Studies Panel wishes to acknowledge the contribution of:

- -Helina Hookoomsing , Senior Lecturer, MIE - Proof reading
- -Staff of Design &amp; Technology Departments, MIE
- -Educators of Validation Panels

## Acknowledgment:

Yashnick Auliar, Chundun Munraj, Yoosuf Jeetun

## Rodrigues:

Jean François Umrit

- Educator

Students' contribution:

D.A.V College Morcellement St André

- Leekeshanand Gokool
- Veedoor Thakoor
- Yuvraj Teeluckdharry

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the   NCF, while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the efforts of  the  graphic  artists  who  put  in  much  hard  work  to  maintain  the  quality  of  the  MIE  publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## Preface

In line with the philosophical principles underpinning the Nine Year Schooling educational reform and the National Curriculum Framework, Technology Studies is offered to all secondary school students of Mauritius and Rodrigues irrespective of their ability, level and gender.

The challenges in transforming education for the needs of 21 st  century learners is at our doorstep and Technology Studies promotes a holistic and broad-based education whilst anchoring the development of creative and critical skills.

Technology Studies comprises two strands:

- Design and Technology
- Food and Textiles Studies

Students  studying  Technology  Studies:  Design  &amp;  Technology  will  emerge  through  a  system  which provides them with the opportunity to think critically, develop the ability to create, innovate, adapt, communicate and lead. At the same time, Technology Studies: Design and Technology encourages students to work collaboratively and responsibly in teams. All in all, Technology Studies: Design and Technology  paves the way for students to stimulate their thinking, communication and entrepreneurship skills while nurturing respect for others. It also allows them to be self-disciplined.

This textbook, has taken into account the current trends among adolescents and particular attention has been given to the needs of our Grade 9 students. Illustrations, contextual pictures, graphs and charts support the explanation of concepts throughout the textbook. The content of the textbook is presented in units and topics to gradually guide the students. The learning objectives are clearly indicated at the beginning of each unit for more focused teaching and learning.

Educators are encouraged to act as facilitators and to guide students accordingly. Projects are proposed, which can be adapted according to the schooling context, resources available, students' abilities and interests. The projects aim at helping students to become prepared to take action for the well-being of themselves and others whilst addressing everyday living challenges.

The authors hope that this Grade 9 textbook offers a pleasurable teaching and learning adventure in Technology Studies: Design &amp; Technology.

## Content pages

## Design and Technology

| Unit 1   | Green Design              |   01 |
|----------|---------------------------|------|
| Unit 2   | Pictorial Projection      |   23 |
| Unit 3   | Material Technology       |   57 |
| Unit 4   | Orthographic Projection   |   85 |
| Unit 5   | Mechanisms                |  107 |
| Unit 6   | Pneumatics and Hydraulics |  111 |
| Unit 7   | The Design Process        |  115 |

## Icons are included throughout the units to guide you through the textbook:

Learning Objectives: These  are  found  at  the  beginning  of  each  unit  to  enable  you  to structure, sequence and plan your learning.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Activities:                   | In-built activities are integrated in the units/topics as formative tasks to stimulate thinking and encourage communication in class.   |
|-------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| Did you know? / More to Know: | These will give you facts that will increase your level of interest in the concepts covered.                                            |
| Find out More:                | Weblinks are provided to extend learning outside the classroom.                                                                         |
| Research work:                | To enable you to find interesting information which is relevant to the concepts introduced in the unit.                                 |
| KeyTerms:                     | Terminologies are included to explain the terms properly.                                                                               |
| Exercises:                    | A list of questions is included to reinforce concepts learned.                                                                          |
| Recall                        | Therecall icon reviews ideas andconcepts already covered at primary level.                                                              |

## DESIGN AND TECHNOLOGY

| Unit 1   | Green Design              |   01 |
|----------|---------------------------|------|
| Unit 2   | Pictorial Projection      |   23 |
| Unit 3   | Material Technology       |   57 |
| Unit 4   | Orthographic Projection   |   85 |
| Unit 5   | Mechanisms                |  107 |
| Unit 6   | Pneumatics and Hydraulics |  111 |
| Unit 7   | The Design Process        |  115 |

GRADE

Design and Technology adopts a holistic approach towards developing creative and critical thinking  in  students.  It  forms  part  of  a  broad-based  education  since  it  is  a  project-based subject in the secondary school curriculum, anchoring on design action and the application of knowledge and practical skills.

The lower secondary Design and Technology syllabus aims to enable pupils to:

- develop an awareness of design in the man-made world
- develop an appreciation of function, aesthetics and technology in design
- develop basic design thinking and communication skills
- experience the process of realising designs through making
- think and intervene creatively to become autonomous decision makers

## DESIGN AND TECHNOLOGY

This  Grade  9  text  book  has  been  written  in  line  with  the  National  Curriculum  Framework. It aims at providing a repertoire of basic knowledge on key concepts in Design and Technology. The following areas of study are included:

- Green Design
- Pictorial Projection
- Material Technology
- Orthographic Projection
- Mechanisms
- Pneumatic and Hydraulic
- The Design Process

This textbook encourages learners to get engaged in design activities adapted to their abilities, interests and design context. Special attention has to be given to safe working practices during the realisation stage. For Grade 9, the materials to work with are wood and metal.

The  content  materials  on  the  various  units  are  by  no  means  exhaustive.  Educators  are encouraged to develop additional and appropriate resources wherever applicable to enhance learning. They are also advised to use varied teaching strategies to develop the content of this resource book and to cater for a range of learning abilities and preferences. Educators should be imaginative in implementing the content of this textbook according to the availability of resources and to make learning meaningful and joyful.

## Green Design

## Learning Objectives

## By the end of this unit, you will be able to:

- Explain the importance of Green Design
- Briefly describe life analysis of products
- Explain the importance of recycling, reusing and reducing materials in design
- Describe strategies for adopting Green Design practices

## 1. Introduction

We  consume  many  products  everyday  and  these  products  when  manufactured,  used,  or disposed of, cause pollution to the environment. Consequently, it is important for designers to consider changes in the way products are produced, used, and disposed of.

In this image we can see a factory. In the background there are trees and sky.

<!-- image -->

In this image we can see a garbage bin, a person, a vehicle and some other objects.

<!-- image -->

Figure 1.1: Pollution

<!-- image -->

## DID YOU KNOW?

Pollution level is measured in microgram per cubic metre.  In Mauritius, the air pollution level is of an average of 14.95.

Source: Index Mundi 2015

## 2. Effects of pollution

Table  1  illustrates  some  causes  of  pollution  around  the  world  and  their  effects  on  the environment and living organisms.

## Environmental causes and effects

## Causes

## Effects

Water pollution

<!-- image -->

Liquid wastes from factories contaminate canals, rivers, lakes and ground waters.

<!-- image -->

## Wastage of materials

In  the  manufacturing  sector,  there  is  a considerable  amount  of  wastage  of  raw materials  due  to  excess  use  of  materials and poor planning.

<!-- image -->

## Energy consumption

Electrical energy is mainly produced with non-renewable  resources.  This  form  of energy is often used extravagantly.

<!-- image -->

Many aquatic animals are affected.

<!-- image -->

There is a considerable increase of waste in the land fills which gives rise to a number of landfill sites and more pollution.

<!-- image -->

Using  non-renewable  resources  leads  to pollution problems together with carbon emission.

<!-- image -->

## Consumption of natural resources

Trees  are  cut  down  for  making  wood products and to make space for construction of buildings.

<!-- image -->

## Air pollution

Air pollution occurs when harmful or excessive quantities of substances including gases and particles, are introduced into Earth's atmosphere.

Excessive exploitation of natural resources causes  destruction  of  natural  flora  and fauna, landslides and destruction of natural habitat of animals.

This  causes health problems and climate changes.

<!-- image -->

Table 1.1

If the same trend of product design and manufacture continues, the impact on the environment will be irreversible creating an imbalance in climatic conditions on earth with the following results:

1. green house effects
2. severe droughts (Figure 1.2a)
3. flash rainfalls creating floods in regions where it had not been the case before (Figure 2b)
4. depletion of natural resources

Figure 1.2a

In this image we can see a group of people standing on the ground. In the background there is a sky with clouds.

<!-- image -->

In this image we can see the water and the cars. In the background there are poles and trees.

<!-- image -->

Figure 1.2b

Therefore, it is essential to adopt good eco-friendly design practices.

<!-- image -->

## ACTIVITY 1

Collect information about other types of pollution, their causes and effects in Mauritius. Present the information collected on a poster.

<!-- image -->

## DID YOU KNOW?

The Green Peace Organisation highlights that 8 to 12 millions of tonnes of plastics are found in the sea each year and are almost impossible to clean. Some products such as plastic bags and cups, drinking straws, cotton buds, and food takeaway packagings invade the oceans. This represents 70 percent of the waste present in the oceans and beaches.

## 3. What is Green Design?

Green Design involves designing products and systems considering the impacts that they may have on the environment throughout their life cycles. This also involves making right decisions at all stages of the product's life from design, manufacture and use to its disposal.

## 4. Life cycle analysis of a product

Every  product  has  a  life  cycle. When  there  is  a  need  for  a  new  product,  it  is  designed  and manufactured. After a certain period of time in use, it becomes obsolete i.e. either outdated, old-fashioned or out of use.

Figure 1.3: Life cycle of a product

<!-- image -->

The  life  cycle  analysis  is  a  method  used  to  measure  and  evaluate  the  impact  of  a  product through  its  life  cycle  from  the  extraction  and  processing  of  raw  materials,  manufacturing, distribution, to use and disposal. Life cycle analysis also enables a manufacturer to quantify how much energy and raw materials are used, and how much waste is generated at each stage of the product's life.

## 5. Green design strategies to improve design and manufacture of products

The  resources  and  raw  materials  used  to  manufacture  products  are  in  most  cases  limited and non-renewable. Furthermore, product manufacture involves large energy consumption. Therefore,  designers  must  put  emphasis  on  green  design  strategies  for  the  benefits  of  the world we are living in.

## Green design products

Green design is a way of designing products so as not to cause harm to the environment. When making these products, the focus is on conserving materials, natural resources and energy while avoiding pollution.

## Eco materials

Eco-materials are environmentally friendly materials which do not affect the environment throughout their life cycles. Some examples of eco-materials are:

## Pandamus utIlis leaves

Dried Pandamus leaves (Figure 1.4) are used to  make products such as mats, placemats, lamp  shades,  flower  jars,  slippers  and  the famous  baskets  called  'Tant  Bazar' (Figure 1.5) .

Figure 1.4

In this image we can see a tree. In the background there is a sky.

<!-- image -->

Figure 1.5

In this image we can see a few things.

<!-- image -->

<!-- image -->

In this image we can see a rack with many items on it.

<!-- image -->

## Eco-cement

Eco-cement (Figure  1.6) is  composed  of  cement  and  municipal waste  material  in  the  form  of  ash. It  can  be  used  to  make countertops for residential or commercial applications.

Figure 1.6

<!-- image -->

## Bamboo stem and fibre

Bamboo fibre is made from the starchy pulp of bamboo plants. It is strong, flexible and soft. Bamboo hollow stems (Figure 1.7) are strong,  rigid  and  eco-friendly.  Disposable plates, bowls, cups, spoon, forks and takeaway  packaging  items    can  be  made with bamboo.

<!-- image -->

Figure 1.7

<!-- image -->

## Palm leaves and sheaths

The leaves and sheaths (Figure 1.8a) that fall naturally on the ground are heat pressed in the desired shape and size. Plates and spoons can be made with these materials (Figure 1.8b) .

<!-- image -->

Figure 1.8a: Palm leaves and sheath

<!-- image -->

<!-- image -->

Figure 1.8b: Disposal products

## Biodegradable materials

Biodegradable materials are those which decay naturally and without harming the environment.

## Biodegradable plastic

Figure 1.9: Biodegradable plastic bags and bottles

In this image we can see a poster with some text and images.

<!-- image -->

## Biodegradable carton

<!-- image -->

Figure 1.10: Products of biodegradable carton

<!-- image -->

Biodegradable carton decays rapidly in the environment. It is obtained by collecting waste materials  like  used-up  boxes  and  paper  products.  It  is  used  to  make  paper  bottles,  cups, packaging, stationery items, egg cartons and seed starter pots.

It is plastic that decomposes through break  down  of  its  structure  naturally  in  the environment.

It is used to make plastic bags and bottles.

## Coconut coir and peat

Coconut coir and peat are biodegradable and organic materials which are made of coconut fibre (Figure 1.11). Coir  is  used  for  seed  germination pots in nurseries, green houses and by professional growers. Peats are used in germination pots to have fertile soil where plants can become stronger.

Figure 1.11: Coir and peat products

<!-- image -->

In this image we can see a flower pot. In the flower pot there are some plants.

<!-- image -->

## Eco-houses

An eco-house (Figure 1.12) is an environmentally low-impact house designed and built using materials and technologies that reduce its carbon footprint and lower its energy consumption.

In this image we can see a house, there are some trees, there are some plants, there are some objects, there is a building, there are some lights, there is a fence, there are some objects, there is a tree, there is a sky.

<!-- image -->

Figure 1.12

<!-- image -->

<!-- image -->

## 1. The figure below shows three common types of food packaging.

<!-- image -->

<!-- image -->

B

C

<!-- image -->

Study these types of food packaging and complete the table below.

| Package for    | Type of material used for the packaging   | Is the material biodegradable?   |
|----------------|-------------------------------------------|----------------------------------|
| 1. Dry cereal  | __________________________________        | __________________________       |
| 2. Fast food   | __________________________________        | __________________________       |
| 3. Canned food | __________________________________        | __________________________       |

## 6. The 3 R's strategy

Designers must develop products that use fewer materials, components and energy in their manufacture. Products can be recovered and reused or recycled after their disposal. In short, designers must adopt a 3R strategy:

1. Reduce
2. Reuse
3. Recycle

## 7. Reduce strategies

This  strategy  aims  to  reduce the  amount  of  materials  and energy used in manufacturing. That  is  why  the  Government in Mauritius has passed a new law forbidding the use of certain types of products, for example  plastics  bags.  There are also campaigns aimed to  sensitise  consumers  to  be

Figure 1.13: Poster showing banning plastic bags campaign

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

more  concerned  about  the  environment  so  that  they  choose  greener  products  over  other products which can cause environmental damage.

## Landfill reduction

Landfill is a big problem we face today. As we produce more waste, we need more places to dispose of them. The reuse of non-biodegradable material reduces the number of items that would get deposited in the landfill sites (Figure 1.14).

Figure 1.14: Landfill sites.

<!-- image -->

## Reduction in energy consumption

Energy consumption can be reduced by using energy efficient appliances and systems.

Energy efficient fluorescent tube fittings, bulbs and solar powered lamps (Figure 1.15) are being used in buildings, roads and public places.

Figure 1.15: Efficient bulbs, tubes and solar powered lamps

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 8. Reuse of existing products

Reusing products is about using the products again, whether for its original purpose or to fulfil a different function.

## Reusable bags

These  bags (Figure  1.16) are  more  durable  than  standard  bags, meaning that they can be reused for a longer period of time. The main purpose of using such bags is to encourage the bags to be reused or recycled.

Figure 1.16: Reusable bags

<!-- image -->

There  are  many  other  products  that  are  disposed  of. These  products  can  be  collected  and reused to make green products as shown in Figure 1.17.

In this image we can see a collage of images. In the center of the image there are some plants and flowers. In the background there is a wall.

<!-- image -->

<!-- image -->

<!-- image -->

Figure 1.17: Reuse of products

<!-- image -->

Observe  Figure  1.17  and  identify  the  materials  that  have  been  reused  and  for  what purpose.

## 9. Recycling strategies

There are many examples of recycling strategies, such as:

1. Choosing  non-toxic,  sustainable-produced  or  recycled  materials  which  do  not  need  as much energy to process.
2. Manufacturing products using less energy.
3. Manufacturing products that are long lasting and thus less replacement is required.
4. Designing products using the concept of being able to recycle it when its use is done.
5. Designing products with recyclable materials.

## Recycling materials

Recycling materials means reprocessing used up materials from household or industries into the same materials. The waste  materials  that  we  dispose  of  everyday  are  mainly made-up  of  organic  products,  paper,  glass,  metals  and plastics (Figure 1.18) which can be recycled. Recycling not only reduces energy consumption in processing materials but also diminishes the dependence on raw materials. It also  helps  in  the  conservation  of  the  habitats  of  animals and forest land.

## Recycling organic waste at home

Recycling  of  household  waste  has  proved  to  be  very beneficial.  Kitchen  and  garden  waste  are  recycled  by composting. Inside the composter (Figure 1.19) , the organic waste materials turn into fertile top soil, reinvigorating vital nutrients and organic matter into the soil.

Figure 1.18: Recycling waste materials

In this image we can see a few things.

<!-- image -->

Figure 1.19: Composter

In this image we can see a plant pot, a person's hand, a plant, a plant pot, a plant, a plant pot, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant, a plant,

<!-- image -->

<!-- image -->

1. The pictures below show the use of 3 models of  bags for shopping.

<!-- image -->

Product A

<!-- image -->

<!-- image -->

Product B

Product C

- a. For each bag, state whether it is recyclable, repairable, and/or sustainable?
- b. Which bag will affect the environment when disposed?
- c. What is the difference between product A and product B?
- d. Explain how product C contributes more in conservation of resources than product A and B.
2.  Collect  pictures  and  information  of  products  that  pollute  the  environment  when disposed. State how the products can be reused or recycled.

## 10. Green energy

Sources of energy can be broadly grouped into two types:

1. non-renewable
2. renewable

Energy  consumption  has  been  growing  each  year.    If  we  continue  to  meet  this  increasing demand using non-renewable resources, we will create significant pollution and damage to the environment. One of the most important ways that technology is being used to reduce environmental  impact  is  through  the  development  of  renewable  methods  of  generating electricity. They do not affect the environment, and thus, are considered as green sources of energy.

## Solar water heater

A solar water heater uses a solar collector to convert energy from sunlight into hot water (Figure 1.20).

Figure 1.20: Solar water heater

<!-- image -->

<!-- image -->

## DID YOU KNOW?

Solar water heaters have started to be used extensively in the last few decades. In fact, they have been around commercially since the 1800s. Clarence Kemp patented the Climax solar water heater in 1891. By the next century, more than 1600 homes were using one solar water heater. (Source: Bainbridge,1984).

## Solar panels

Solar panels convert energy from sunlight into electrical energy. The Mauritian Government is providing opportunities for households to produce their own electricity using photovoltaic solar cell technology (Figure 1.21) .  Families can produce electricity for their own use and the excess is sold to the Central Electricity Board (CEB). There are also solar farms set up in different parts of Mauritius. One of them is SARAKO at Bambou as shown in Figure 1.22.

Figure 1.21: Photovoltaic solar cell

<!-- image -->

In this image we can see a water body, there are some buildings, trees, mountains, and the sky.

<!-- image -->

Figure 1.22: Solar farm at SARAKO

There  are  solar  panels  set  on  the  roof  of  Maréchal  College  in Rodrigues.  They  supply  electricity  to  the  school  as  shown  in Figure 1.23.

Figure 1.23: Solar panels in Rodrigues

<!-- image -->

## Wind energy

Energy from wind has been used for many years. Wind energy can be used to turn turbines which generate electrical energy. In Mauritius a wind farm has been set up at Plaines de Roches (Figure 1.24) not far from Bras D'eau to produce green electrical energy.

In Rodrigues, there are two farms, one at Grenade (Figure 1.25) and the other at Trèfles.

## Hydro-electric energy

In  Mauritius, electrical energy is also produced by hydro-electric power stations (Figure 1.26) . They use water flow to turn turbines that generate electricity.

In this image we can see a collage of images. In the center of the image there are poles and trees. In the background there is sky with clouds.

<!-- image -->

Figure 1.24: Wind farm at Plaines des Roches

<!-- image -->

Figure 1.25: Wind farm in Rodrigues

<!-- image -->

Figure 1.26: Hydro power station

In this image we can see the green color poster with some text and images.

<!-- image -->

30 May 2013, the Mauritius Post released two stamps on the theme 'Maurice Ile Durable' Source: Mauritian Philatelic Blog, 2015

<!-- image -->

1. Fill in the table to indicate which  sources of energy are used.
2.  Multiple choice questions

In this image, we can see some text and images.

<!-- image -->

Encircle the correct answer

1. They convert energy from sunlight into electrical energy:
- A.       Solar water heaters
- B.       Wind turbines
- C.       Hydro-power stations
- D.       Solar panels
2. They convert energy from water flow into electrical energy:
- A.       Solar water heaters
- B.       Wind turbines
- C.       Eolians
- D.       Hydro-electric power stations
3. They convert wind energy into electrical energy:
- A.       Solar water heaters
- B.       Wind turbines
- C.       Hydro electric power stations
- D.       Solar panels

4. They convert energy from sunlight into heat energy:
- A.       Hydro electric power stations
- B.       Wind turbines
- C.       Solar water heaters
- D.       Eolians
3.  Collect  information  about  other  examples of renewable sources of energy used in other countries that can be used in Mauritius. Present your information on a poster.
4.  (i)  Research and make a list of all hydro-electric power stations in Mauritius.
8. (ii) Find out the percentage of electrical energy produced by these hydro power stations to meet the electrical energy demand in Mauritius.

## 11. Eco-Green labels

An eco-green label also known as a Green Sticker is designed to encourage manufacturers to market products that are environmentally friendly. It is a form of sustainability measurement targeting consumers, intended to make it easy to take environmental concerns into account when shopping.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Labels            | Meaning                                                                                                                                                                                              |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Recyclable        | Products containing plastics that can be recycled.                                                                                                                                                   |
| Biodegradable     | Products that break down into carbon dioxide, water and biomass in less time in the natural environment.                                                                                             |
| Compostable       | When products break down, they release valuable nutrients into the soil, helping the growth of trees and plants. These products degrade within a few months in a composter without producing toxins. |
| Carbon foot print | The amount of carbon dioxide released into the environment when the products have been manufactured, transported and disposed of.                                                                    |

<!-- image -->

## 1. Multiple choice questions

## Encircle the correct answer.

1. Products that cause harm to people and animals are called:
- A. Bio products
- B. Sweet products
- C. By products
- D. Toxic products
2. Which one of the following is not a renewable source of energy?
- A. Wind
- B. Coal
- C. Water
- D. Solar power
3. Waste materials that are able to decompose easily in the environment are called:
- A. Biodegradable materials
- B. Non-biodegradable materials
- C. Packaging materials
- D. Toxic materials

## 2. True/false

## Tick (      ) true or false for each of the following statements.

| Statement                                                                                                         | True   | False   |
|-------------------------------------------------------------------------------------------------------------------|--------|---------|
| 1. A renewable resource is one that cannot be renewed within 500 years                                            |        |         |
| 2. Metals are non-renewable resources                                                                             |        |         |
| 3. Plastics are renewable resources                                                                               |        |         |
| 4. Manufacturing processes that use plastics tend to use less energy than manufacturing processes that use metals |        |         |
| 5. A thermoplastic product cannot be recycled                                                                     |        |         |

| 3. Give two examples of non-renewable energy sources.                                                                                                                |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1. ................................................................................................................................................................. |
| 2. ................................................................................................................................................................. |
| 4. Give two examples of renewable energy sources.                                                                                                                    |
| 1. ................................................................................................................................................................. |
| 2. ................................................................................................................................................................. |

## Pictorial Projection

## Learning Objectives

## By the end of this unit, you will be able to:

- Develop technical skills in the use of drawing equipment
- Draw objects in oblique projection
- Draw objects in isometric projection
- Apply rendering techniques

## 1. Introduction

There  are  many  softwares  like  Autocad,  google  sketchup  used  to  draw  objects  in  pictorial projection. However, before using these, you need to grasp the right principle and technique of drawing objects. Therefore in this unit, you will develop skills of drawing objects in pictorial projection using drawing equipment and apply rendering techniques to enhance the drawings.

## GRADE 2. Basic drawing instruments

Table 2.1 shows some drawing equipment used to draw accurately.

<!-- image -->

<!-- image -->

<!-- image -->

|    | Name   | Picture   | Basic Use                                          |
|----|--------|-----------|----------------------------------------------------|
|  1 | Pencil |           | To draw and sketch lines and arcs of various tones |
|  2 | Ruler  |           | To draw and measure lines                          |
|  3 | Eraser |           | To clean up and erase surplus lines                |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|   4 | 45 0 set square       |                               | To draw perpendicular lines and inclined lines at 45 0                            |
|-----|-----------------------|-------------------------------|-----------------------------------------------------------------------------------|
|   5 | 30 0 /60 0 set square |                               | To draw perpendicular lines and inclined lines at either 30 0 or 60 0             |
|   6 | Dividers              |                               | To transfer dimensions                                                            |
|   7 | A pair of compasses   |                               | To draw circles and arcs to a given radius or diameter                            |
|   8 | Pencil sharpener      |                               | To sharpen pencils                                                                |
|   9 | Protractor            |                               | To measure angles                                                                 |
|  10 | T-square              | 90 0 Working edge Blade Stock | To align drawing paper on the drawing board and to draw parallel horizontal lines |

<!-- image -->

<!-- image -->

Table 2.1: Drawing equipment

|   11 | Drawing board   | A flat board used to fix drawing paper   |
|------|-----------------|------------------------------------------|
|   12 | Drafting tape   | To fix paper on a drawing board          |

## 3. Fixing an A3 size paper on a drawing board

At this level, you will no longer use isometric or square grids for drawing solids in pictorial projection.  Remember  that  isometric  projection  and  oblique  projection  are  two  types  of pictorial projection. You will first of all need to develop some technical drawing skills using drawing equipment and plain paper.

You will need a T-square, a set square, drafting tape, a drawing board/table and an A3 size plain paper.

## Step 1

Check if the T-square and drawing board are in good and clean condition and have a perfect, straight and flat edge. If need be, use a piece of tissue paper or cloth to clean up any dirt or dust.

<!-- image -->

## Points to remember:

- If needed, use  a backing sheet made of light card such as Bristol paper on the drawing board in order to have a flat and smooth surface.
- Ensure that the working edge of your T-square is perfectly straight and has no dents.

## Step 2

Align the top edge of the A3 size paper with the working edge of the T-square blade. Use either the 30 0 /60 0 or 45 0 set square to check if the A3 plain paper is in a perpendicular position with the T-square. Then, use a piece of drafting tape to fix the A3 plain paper on the drawing board as shown in Figure 2.1.

Figure 2.1: Fixing the A3 plain paper on the drawing board

In this image, we can see a diagram. There are some lines and a paper.

<!-- image -->

## Points to remember:

- Never leave gaps between the stock of the T-square and the straight edge of the  drawing board.
- Always keep your T-square, ruler, set squares and protractor free of dust and dirt.
- Make sure that the drawing paper does not move when lifting up the T-square for fixing with the drafting tape.

<!-- image -->

1. Fix an A3 size plain paper on your drawing board. You will use it for Activity 2.

## 4. Basic line types

Different types of lines are used in technical drawing.  They are used as a means of communication for designers, manufacturers, engineers or other technical people. Each type of line is drawn to a specific standard.

Table 2.2 shows some basic line types.

|    | LineTypes          | Sample   | Tone   | Applications                                       | Pencil Grade   |
|----|--------------------|----------|--------|----------------------------------------------------|----------------|
|  1 | Outlines           |          | Thick  | For all directly visible outlines or edges         | HB             |
|  2 | Construction lines |          | Thin   | For construction purposes, when starting a drawing | 2H             |
|  3 | Centre lines       |          | Medium | To represent centre lines of circles and arcs      | H              |
|  4 | Hidden lines       |          | Medium | To represent hidden edges or details of an object  | H              |

Table 2.2: Basic line types

Margin of 15 mm all round

<!-- image -->

- (a) Reproduce each of the line patterns shown in the grid below on an A3 plain paper.
- (b) Draw the patterns shown below.

The image is a diagram of a square with four different lines and angles labeled. The diagram is divided into four quadrants, each with a specific angle labeled. The lines and angles are labeled in a clockwise direction from top to bottom.

### Diagram Description:

#### Top Left Quadrant:
- **Line 1**: This line is labeled as 10 mm (thick lines).
- **Line 2**: This line is labeled as 10 mm (thin lines).
- **Line 3**: This line is labeled as 10 mm (thin lines).
- **Line 4**: This line is labeled as 10 mm (thin lines).

#### Top Right Quadrant:
- **Line 1**: This line is labeled as 10 mm (thin lines).
- **Line 2**: This line is labeled as 10 mm (thin lines).
- **Line 3**: This line is

<!-- image -->

In this image we can see a diagram. In the diagram we can see a line.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

Draw the following shapes on an A3 size plain paper.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| (i) Square                | (ii) Square               | (iii) Rectangle           | (iv) Rectangle        |
|---------------------------|---------------------------|---------------------------|-----------------------|
| 50x50mm                   | 80x80mm                   | W=120mm H=45mm            | W=100mm H=50mm        |
| (v) Circle                | (vi) Circle               | (vii) Semi-Circle         | (viii) Quarter-Circle |
| Radius=55mm               | Diameter=130mm            | Radius=60mm               | Radius=45mm           |
| (ix) Equilateral Triangle | (x) Right angled Triangle | (xi) Isosceles Triangle C |                       |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## (xii) Regular Hexagon

<!-- image -->

AB = 60 mm long

<!-- image -->

<!-- image -->

## 5. Basic Rendering Techniques

Rendering is a technique used to enhance a final drawing in order to make it look more realistic and appealing. At this level you will explore two basic rendering techniques as shown in Table 2.3:

Table 2.3: Basic rendering techniques

In this image, we can see a box.

<!-- image -->

## Tone shading technique

Tone shading is the process of adding tones to create the illusion of form, space, and most importantly - light in a drawing. At this level you will use both the graphite and coloured pencils to produce the three main tones: dark , medium and light .

The three main tones are produced by adjusting the amount of pressure on the pencils. First it is essential to identify the direction of light striking the object. An arrow will show the direction of light.

The strip below shows the different tones from light to dark produced by a soft graphite pencil (2B or B grade).

The strip below shows the different tones from light to dark produced by a coloured pencil.

## Tone shading of a cuboid

You will use the three layers technique to produce the three tones effect on a cuboid The outline of a cuboid and the direction of light are given in Figure 2.2.

Figure 2.2: A cuboid with an arrow showing direction of light

In this image, we can see a box.

<!-- image -->

## Step 1

## Identify the surfaces

As per the direction of light striking the cuboid, visualise the surfaces to be light, medium and dark.

In this image, we can see a diagram. There is a text on the image.

<!-- image -->

## Step 2

## First layer (Light)

Use the soft pencil (2B). Hold it lightly, applying low pressure and shade the whole cuboid with a first light layer  on  each surface, as shown in Figure 2.3.

## TIP

<!-- image -->

Use a ruler or the straight edge of a piece of light card as a barrier along the straight edge to avoid any surplus shading.

Figure 2.3: Applying first layer

In this image, we can see a box with a light color.

<!-- image -->

Figure 2.4: Applying second layer

In this image, we can see a box with a label.

<!-- image -->

Figure 2.5: Applying third layer

<!-- image -->

1. Draw a strip of 120 mm x 20 mm, divide it into four equal parts. Then use a soft pencil to reproduce the various tones given below.
2. Draw a strip of 120 mm x 20 mm, divide it into four parts. Then use a coloured pencil to reproduce the various tones given below.
3. Trace out each shape given below, on a plain paper, then apply tone shading techniques using a soft pencil or coloured pencil. The arrow shows the direction of light striking each one.

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a box and a cylinder.

<!-- image -->

## Thick and thin line technique

This is a technique used to emphasise a proportion using two types of lines namely: thick and thin lines. It is a quick method for making a drawing stand out and to give a 3D effect of an object. Thick lines are obtained by applying more pressure on the pencil.

## Applying thick and thin line technique to a shaped block

In this example you will learn how to apply thick and thin lines to a shaped block shown in Figure 2.6.

Figure 2.6: Shaped block

In this image, we can see a box.

<!-- image -->

## Step 1

Identify edges where two or more faces/sides are visible adjacent to each other and these edges are to be in thin lines as shown in Figure 2.7.

Figure 2.7: Edges to be in thin lines

In this image, we can see a diagram. There are two lines, which are connected with arrows.

<!-- image -->

## Step 2

Identify all edges where only ONE face/side is visible adjacent to the other, these to be in thick lines as shown in Figure 2.8. Use a soft grade pencil such as 2B to produce thick lines.

Edges to be in thick lines

Figure 2.8: Edges to be in thick lines

In this image, we can see a diagram. There are some lines and boxes.

<!-- image -->

## Step 3

The final drawing as shown in Figure 2.9. You need to be much careful with the corners.

In this image we can see a block.

<!-- image -->

Figure 2.9: Final drawing

<!-- image -->

Trace out each shape given below on a plain paper, then apply the thick and thin lines techniques to enhance them.

In this image we can see a few blocks.

<!-- image -->

In this image we can see a diagram.

<!-- image -->

## 6. Drawing in oblique projection

Oblique projection is used for drawing objects in 3D. At this level, you will develop the skills to use the T-square and the 45 0  Set Square for drawing in Oblique Projection on an A3 size plain paper.

## Points to remember:

- Square grids were used previously to draw objects in oblique projection as shown in
- Figure 2.9a.
- To start drawing objects in oblique projection you need to draw the three oblique axes
- first as a starting point as shown in Figure 2.9b.
- The width can be drawn either on the right or left.

<!-- image -->

Figure 2.9a: Using  square grids

In this image we can see a diagram.

<!-- image -->

Figure 2.9b: The oblique axes

## Oblique axes

The vertical axis for height , the horizontal axis for width and the inclined axis to be at an angle of 45 degrees from the horizontal, for the depth . The width can be drawn either on the right or the left.

## 7. Drawing a cuboid in oblique projection

The front view and top view of a cuboid are shown in Figure 2.10. Let us consider drawing it in Oblique Projection.

Front view

<!-- image -->

Figure 2.10: Front view and Top view of a cuboid.

<!-- image -->

## Step 1

Identify the overall dimensions for the height, width and depth and produce a sketch if possible as shown in Figure 2.11.

For  this example: Overall height = 60 mm, Overall width = 90 mm, Overall depth = 50 mm

Figure 2.11: Sketch of the cuboid in the oblique projection

In this image, we can see a diagram. There is a line in the image.

<!-- image -->

## Step 2

Use the T-square and 45 degree set square to draw the Oblique axes as shown in Figure 2.12. Use thin continuous lines.

Figure 2.12: Drawing the oblique axes

In this image, we can see a metal rod.

<!-- image -->

## Step 3

Use the overall width and height to draw the front view using thin continuous lines as shown in Figure 2.13.

Figure 2.13: Drawing the front view

<!-- image -->

## Step 4

From each corner of the front view, draw the depth lines as shown in Figure 2.14. Use thin lines for construction purpose.

Figure 2.14: Drawing the depth lines

<!-- image -->

## Step 5

Measure the depth and complete the cuboid in oblique projection. You can enhance your final drawing by using thick and thin line rendering techniques as shown in Figure 2.15.

Figure 2.15: Final drawing of cuboid in oblique projection

<!-- image -->

## Point to remember:

- Always start your drawing by using thin lines.

<!-- image -->

Draw each cuboid given in oblique projection. Enhance each drawing as per instruction given.

(i)

(ii)

<!-- image -->

Front view

Top view

<!-- image -->

(Apply Thick and thin line on final drawing)

<!-- image -->

(Apply tone shading technique on final drawing. Choose the direction of light)

<!-- image -->

(Apply tone shading technique on final drawing. Choose direction of light.)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

(Apply thin and thick line on the final drawing)

## 7. Drawing a shaped block in oblique projection

A shaped block can have either flat surfaces or inclined surfaces or a combination of these. It  is  noted  that  circles,  semicircles  and  arcs  given  in  front  view  remain  the  same  in  oblique projection.

The front view and top view of a shaped block are given in Figure 2.16. Let us consider drawing it in Oblique Projection.

Figure 2.16

In this image, we can see a diagram.

<!-- image -->

## Step 1

Identify the overall dimensions of the object given, then use them to visualise how much space will be needed to draw it on your drawing paper. You can make a rough sketch on a piece of paper to assist you.

For  this example: Overall height = 60 mm, Overall width = 120 mm, Overall depth = 50 mm

## Step 2

Draw the oblique axes as shown in Figure 2.17 using thin lines.

Figure 2.17: Oblique axes

<!-- image -->

## Step 3

Draw a crate in oblique projection using thin lines. The overall dimensions are used, and the same principle as that of drawing a cuboid in oblique projection is applied as shown in Figure 2.18.

Figure 2.18: Crate in oblique projection

The image consists of a rectangular shape with a length of 120 units and a width of 50 units. The shape is a square, and its sides are parallel to each other. The length of the sides of the square is 120 units, and the width is 50 units. The image also includes a small arrow pointing from the bottom left corner to the top right corner.

The arrow is labeled with the number "50" and is positioned at the top right corner. The arrow is pointing to the right, indicating that the length of the square is 50 units.

The image does not contain any text, numbers, or other objects that are typically associated with a square. The image is a simple representation of a square shape with a specific length and width.

<!-- image -->

## Step 4

Draw the outline of the front view and locate the centre O , and then draw the semi-circle and circle as per given dimensions, as shown in Figure 2.19. Use thin lines for construction purposes.

<!-- image -->

Figure 2.19: Drawing on the front view of the crate

<!-- image -->

From each corner project parallel oblique lines as shown in Figure 2.20. The same procedure is carried out to obtain O 1  from O.

Figure 2.20: Projecting depth line

<!-- image -->

## Step 6

Complete  the  oblique  view  by  drawing  appropriate  parallel  lines. You  will  need  to  draw  a blending line for the semi circle as shown in Figure 2.21.

Figure 2.21: Completing the oblique view

<!-- image -->

## Step 7

Enhance the final drawing by applying the thick and thin line technique as shown in Figure 2.22. Colouring and shading can also be added.

<!-- image -->

Figure 2.22: Final drawing of shaped block in oblique projection

<!-- image -->

<!-- image -->

Draw each shaped block given below in oblique projection.

In this image, we can see a diagram. There is a line on the diagram. There is a scale on the right side of the diagram.

<!-- image -->

In this image we can see a diagram.

<!-- image -->

## 8. Drawing in isometric projection

Isometric projection is another type of pictorial projection used for drawing objects in 3D. At this level you will develop the skills to use the T-square, the 30 0 / 60 0  Set Square and an A3 size plain paper for drawing in Isometric Projection.

## Points to remember:

- Isometric grids were used previously to draw objects in isometric projection.
- To start drawing objects in isometric projection you need to draw the three isometric axes first as a starting point as shown in Figure 2.23. The point where all the axes meet is known as the lowest or nearest point.

Figure 2.23: The isometric axes

In this image, we can see a diagram. There are two lines, one is a dashed line and the other is a dashed line. There is a text at the bottom of the image.

<!-- image -->

## Points to remember:

- All  vertical  lines  remain  vertical  and  only horizontal lines are inclined at 300 in isometric projection
- All  construction  lines  to  be  thin  and  only the visible edges to be darkened.
- The vertical axis is used for the height .
- The inclined axis on the right is drawn at 30 0 to the horizontal for the depth.
- The inclined axis on the left is drawn at 30 0 to the horizontal for the width .
- The inclined axes can be used alternately for either the width or the depth .

<!-- image -->

45

## 9. Drawing a cuboid in isometric projection

The front view and top view of a cuboid are given in Figure 2.24. Let us consider drawing it in Isometric Projection.

Figure 2.24: Orthographic view of a cuboid

In this image, we can see a diagram.

<!-- image -->

## Step 1

Identify the overall dimensions for the height, width and depth.

For  this example: Overall height = 70mm, Overall width = 100mm, Overall depth = 60mm

## Step 2

Use the T-square and the 30 0 / 60 0 degree set square to draw the isometric axes as shown in Figure 2.25. Use thin lines.

## Step 3

Use the overall width and height to draw the front view using thin continuous lines as shown in Figure 2.26.

Figure 2.25: Drawing the isometric axes

<!-- image -->

Figure 2.26: Drawing the front view

In this image, we can see a diagram. There are two lines, one is a line and the other is a line.

<!-- image -->

## Step 4

Form each corner of the front view draw the depth lines as shown in Figure 2.27. Still using thin lines.

## Step 5

Measure the depth and complete the cuboid in  Isometric  projection.  Enhance  the  final cuboid by applying the thick and thin lines technique as shown in Figure 2.28.

Figure 2.28: Final drawing of cuboid in isometric projection

In this image, we can see a box.

<!-- image -->

Figure 2.27: Drawing depth

In this image, we can see a diagram with a line and a point.

<!-- image -->

<!-- image -->

Draw each shaped block in isometric projection. Enhance each drawing as per instruction given.

(i)

(Apply thick and thin line technique on final drawing)

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

(iii)

(Apply tone shading. Choose the direction of light)

<!-- image -->

<!-- image -->

(iv)

In this image, we can see a diagram.

<!-- image -->

## 10. Drawing a shaped block in isometric projection

The front view and top view of a shaped block are given in Figure 2.29. Let us consider drawing it in Isometric Projection.

It is a good practice to visualize the final drawing and make a quick sketch in order to be aware of the amount of space needed.

Figure 2.29: Orthographic views of a shaped block

In this image, we can see a diagram. There is a graph.

<!-- image -->

## Step 1

Identify the overall dimensions of the object given, then use them to visualise how much space will be needed to draw it on your drawing paper. You can make a rough sketch on a piece of paper to assist you.

For  this example: Overall height = 70mm, Overall width = 95mm, Overall depth = 50mm

## Step 2

Position the isometric axes, using thin lines as shown in Figure 2.30.

<!-- image -->

Figure 2.30: Drawing the isometric axes

<!-- image -->

## Step 3

Draw a crate in isometric projection using thin continuous lines. The overall dimensions are used and same principle as  that  of  drawing  a  cuboid  in  isometric  projection  is applied as shown in Figure 2.31.

Figure 2.31: Drawing an Isometric crate

<!-- image -->

## Step 4

Draw the outline of the front view as per given dimensions as  shown in  Figure  2.32.  Use  continuous  thin  lines. You  can annotate the corners to facilitate your task.

## Step 5

Use the T- square and 60 0  /30 0 set squares for projecting parallel isometric lines from each corner of the front view as shown in Figure 2.33.

## Step 6

Mark off the dimension of the depth on each isometric lines and complete the isometric drawing as shown in Figure 2.34. Colours and shading can also be added

<!-- image -->

Figure 2.32: Drawing the front view

Figure 2.33: Projecting the depth

<!-- image -->

Figure 2.34: Final drawing of shaped block in Isometric projection

<!-- image -->

<!-- image -->

The orthographic views of some shaped blocks are given below. Draw each in isometric projection.

(i)

(ii)

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

In this image we can see a graph.

<!-- image -->

In this image we can see a graph.

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a graph. There is a line on the graph.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

(ix)

In this image, we can see a graph.

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a graph.

<!-- image -->

(xi)

<!-- image -->

<!-- image -->

In this image, we can see a diagram of a triangle.

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

## Material Technology

## Learning Objectives

## By the end of this unit, you will be able to:

- Describe the properties and applications of common softwoods and  hardwoods
- List and describe common manufactured boards and their applications
- Describe the properties and applications of common ferrous and non-ferrous metals
- Differentiate between thermoplastics and thermosetting plastics
- Describe  the  properties  and  application  of  common  thermoplastics  and  thermosetting plastics
- Select appropriate materials and processes in the design and realisation of artefacts

## 1. Introduction

GRADE Any  object  we  use  in  our  everyday  life  is made  from a specific material. According to  the  intended  use  of  the  object,  one  or more materials  can  be  used.  Designers  select materials according to their properties.

Some common materials used by designers are:

- i. Wood
- ii. Metal
- iii. Plastic
- iv. Manufactured boards

<!-- image -->

## RECALL

Some common properties are:

1. Strength: The ability of a material to withstand an applied force.
2. Toughness: The ability of a material to withstand sudden shocks without breaking.
3. Brittleness: A material that breaks easily with a sudden shock.
4. Hardness: The ability of a material to resist wear, abrasion and cuts.
5. Malleability: The ability of a material to be deformed (stretched, bended or flattened into thin sheets) without cracking.
6. Ductility: The ability of a material to be drawn into thin wires or threads.
7. Electrical conductivity: The ability of a material to allow electricity to flow through it.
8. Thermal conductivity: The ability of a material to allow heat transfer.

Figure 3.1: Different materials used in daily activities

<!-- image -->

57

## 2. Wood technology

Wood may be considered as one as the oldest material ever used by human kind. Wood has been used as fuels, for  construction  of  shelters  or  weapons.  Due  to  the different wood species that are available and different properties which they offer, the use of wood has been extended to the manufacture of furniture, ships or even car parts.

Figure 3.2: Different objects made from wood

<!-- image -->

Timber can be classified as: hardwood or softwood .

The diagrams below illustrate the main physical characteristics of hardwood and softwood trees.

## Hardwood trees

Figure 3.3: Physical characteristics of hardwoods

In this image there is a tree. On the right side of the image there are two plants.

<!-- image -->

## Softwood trees

Figure 3.4: Physical characteristics of softwoods

In this image we can see a tree. In the background there are some leaves.

<!-- image -->

Other characteristics of hardwoods and softwoods are illustrated in Table 3.1.

Table 3.1: characteristics of hardwood and softwood trees

| Characteristics of hardwoods                | Characteristics of softwoods                       |
|---------------------------------------------|----------------------------------------------------|
| 1. They have a slow rate of growth          | 1. They have a faster rate of growth               |
| 2. They grow in temperate and warm climates | 2. They grow better in temperate and cold climates |

## Common types of hardwoods and their applications

<!-- image -->

<!-- image -->

| Name   | Sample   | Properties                                                                                                                                     | Use                                                                                |
|--------|----------|------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------|
| Teak   |          | • Teak has good strength properties. • It has very good resistance to decay therefore has very good durability. • Teak is an expensive timber. | • First class furniture • Decorative cabinets • Parquetry flooring • Ship building |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.2: Common types of hardwoods and their applications

| Meranti   | • Meranti is a low- cost timber. • It has a lower strength property as compared to teak. • It has a low resistance to decay and insect attacks therefore providing               | • Light structural framing • Mouldings and trim • Low-cost furniture • Producing veneers and plywood   |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
| Mahogany  | a low durability. • Mahogany is moderately resistant to insect/ borer attacks. • It is moderately durable. • It is quite resistant to decay. • It can be difficult to work with. | • High class furniture like table and chairs • Parquetry • Boat building • Musical instruments         |
| Beech     | • Beech is hard and tough. • It withstands shock and wear. • It polishes well. • It is an expensive timber.                                                                      | • Flooring • Furniture • Veneer plywood • Tool handles and mallets                                     |

<!-- image -->

## Common types of softwoods and their applications

<!-- image -->

<!-- image -->

| Name   | Properties                                                                                                                            | Use                                                                   |
|--------|---------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------|
| Pine   | • Pine has moderate strength properties. • It is fairly soft and it is easy to work with. • Pine has a low durability and a low cost. | • Doors • Furniture like cupboards • Window frames • Panelling Floors |

<!-- image -->

<!-- image -->

<!-- image -->

| Douglas fir   | • Douglas fir has good strength properties and is easy to work with. • It is also resistant to weathering.   | • Plywood manufacture • Veneer • Flooring • Joinery work • Houses                                             |
|---------------|--------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|
| Red cedar     | • Red cedar has good durability. • It forms part of the low-density wood, therefore is easy to work with.    | • Making shingles, for both exterior walls and roofs • Clothing storage • Musical instrument • Roof panelling |

<!-- image -->

Table 3.3: Common types of softwood and their applications

<!-- image -->

1. Fill in each of the blanks using an appropriate word from the given list.

## meranti, resistance, roof panelling, softwood, hard

- i. Teak has very good \_\_\_\_\_\_\_\_\_\_\_\_\_to decay therefore has very good durability.

ii. \_\_\_\_\_\_\_\_\_\_\_\_\_has a low resistance to decay and insect attacks therefore providing it a low

durability.

- iii. Beech is a \_\_\_\_\_\_\_\_\_\_\_and tough timber commonly used to make tools handle.

iv. Pine is a \_\_\_\_\_\_\_\_\_\_\_ commonly used to make furniture.

- v. Red cedar has good durability and is commonly used to make \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

2. Name one timber which may be used to make each of the following products: Give one reason for your answer.

## i. Boats

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ii. Houses

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## iii. High class furniture

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 3. Manufactured boards

Manufactured boards (man-made boards) are made using by-products of wood such as veneers, saw dust, wood strips, wood fibres or wood flakes. Nowadays, manufactured boards are used as a substitute to solid wood due to the different advantages they offer.

## Some of the advantages are:

- They are cheaper compared to solid wood.
- They are available in large sizes with uniform thickness.
- They are available in a wide range of surface finishes and thicknesses

## Some disadvantages of using manufactured boards are:

- Edges must be treated and covered to hide unsightly edges and prevent water getting in.
- Cutting and sanding some types of board generate hazardous dust particles.
- Thin sheets do not stay flat and will bow unless supported.

Figure 3.5: Manufactured boards

<!-- image -->

## Types of manufactured boards

There are different types of manufactured boards which are available on the market and each offering different properties. Here are some common types of manufactured boards:

## Plywood

Plywood is made of a number of layers of veneer glued together. It has good strength properties  and  is  more  resistant  to  water compared to  other  manufactured  boards. But it is harder to get a perfectly smooth cut with plywood. Plywood can be laminated.

## Uses

- Doors
- Furniture
- Floors and walls in home constructions
- Vehicle internal body work
- Packages and boxes

## Medium density fibreboard (MDF)

Medium-density  fibreboard  (MDF)  is  composed  of  wood fibres that are mixed with resin and wax. MDF cuts well and has a smooth surface that is ideal for painting. However, it is not resistant to water.

## Uses

- Wall-panels
- Furniture
- Cabinets and shelves
- Speaker boxes
- Doors and door frames

Different layers of veneers

In this image, we can see a wooden object.

<!-- image -->

Figure 3.6: Plywood

Figure 3.7: Medium density fibre board

<!-- image -->

## Chipboard

Chipboard  is  composed  of  wood  chips  mixed  with  resins. Chipboard is available in different densities: low, medium and high density. Chipboard is a low cost manufactured board. Chipboard does not have good strength properties and has a rough surface if not finished with a veneer.

## Uses

- Countertops
- Low-cost indoor furniture
- Kitchen tops (which are laminated with melamine)

Wood chips visible on edges

<!-- image -->

Figure 3.8: Chipboard

## Blockboard

Block  board  is  composed  of  a  core  of  softwood  strips placed  edge  to  edge  and  sandwiched  between  veneers of  hardwood.  Blockboard  is  stiffer  and  is  less  prone  to bending.  It  is  cheaper  compared  to  good  quality  solid wood.

## Uses

- Book shelves
- Tables and benches
- Blockboard doors and shingles
- Wall panels
- Worktops

Core softwood strips

In this image, we can see a wooden object.

<!-- image -->

Figure 3.9: Block board

<!-- image -->

Complete the table below by naming each manufactured board and giving two properties and two uses.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.4

| Sample   | Name               | Properties                                               | Uses                                                                                           |
|----------|--------------------|----------------------------------------------------------|------------------------------------------------------------------------------------------------|
|          | __________________ | __________________ __________________ __________________ | __________________ __________________ __________________ __________________                    |
|          | __________________ | __________________ __________________ __________________ | __________________ __________________ __________________ __________________                    |
|          | __________________ | __________________ __________________                    | __________________ __________________ __________________ __________________ __________________ |
|          | __________________ | __________________ __________________ __________________ | __________________ __________________ __________________                                       |

## 4. Metal Technology

Metals have wide applications. However, in their pure states, some metals are too soft or brittle to be worked out. Therefore, alloys are used. An alloy is composed of two or more metals aimed to improve its properties.

Metal can be categorised as:

1. Ferrous metals
2. Non-ferrous metals

Figure 3.10: Different types of metals

<!-- image -->

## Ferrous metals

Ferrous metals contain iron. Ferrous metals are likely to rust when not properly protected and they are attracted to magnets.

## Common types of ferrous metals and their uses

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.5: Properties and application of common ferrous metals

| Name              | Properties                                                                                                                                                   | Uses                                                                  |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------|
| Mild steel        | • It is a tough, ductile and malleable metal. • It rusts quickly when exposed to moisture.                                                                   | • Bolts and nuts • Gates • Metal bars                                 |
| Cast iron         | • It has good compressive strength. • It is a brittle metal . • It has a poor resistance to corrosion.                                                       | • Kitchen utensils • Manhole covers • Engineer's vice • Engine blocks |
| Stainless steel   | • It is an alloy of iron and chromium and nickel. • It is resistant to rust and wear. • It has a nice shiny appearance. • It has high strength and hardness. | • Kitchen utensils • Surgical equipment • Handrails                   |
| High carbon steel | • It offers high resistance to wear.                                                                                                                         | • Cutting tools • Ball bearings                                       |

## Non-ferrous metals

Non-ferrous metals do not contain iron. Therefore, they do not rust and are not attracted to magnets.

## Common types of non-ferrous metals and their uses

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Name      | Properties                                                                                                                              | Uses                                                                   |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|
| Copper    | • It is a ductile and malleable metal. • It is also a good conductor of heat and electricity.                                           | • Kitchen utensils • Electric wires • Plumbing components              |
| Aluminium | • It is a ductile and lightweight metal. • It has also good thermal and electrical conductivity. • It has good resistance to corrosion. | • Window and door frames • Ladders • Cooking foils                     |
| Brass     | • It is a good conductor of heat. • It is resistant to corrosion from salt water.                                                       | • Musical instruments • Door knobs • Plumbing fittings                 |
| Tin       | • It is a soft, ductile and malleable metal. • It has a good corrosion resistance.                                                      | • Food cans • Used to coat other metals as a protection from corrosion |

Table 3.6: properties and application of common non-ferrous metals

<!-- image -->

<!-- image -->

## 1. State whether the following statements are True or False .

- i. Mild steel rusts when exposed to moisture.

\_\_\_\_\_\_\_\_\_\_\_

- ii. Aluminium has a low resistance to corrosion and is heavy in weight.

\_\_\_\_\_\_\_\_\_\_\_

- iii.  Tin is a soft, ductile and malleable metal.

\_\_\_\_\_\_\_\_\_\_\_

- iv.  Cast iron is commonly used to make cutting tools.

\_\_\_\_\_\_\_\_\_\_\_

- v. Brass is not resistant to corrosion from salt water.

\_\_\_\_\_\_\_\_\_\_\_

2. Name one metal which may be used to make each of the following products. Give one reason for your answer.

## i. Window frame

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ii. Musical instrument

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## iii. Manhole cover

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## iv. Electric wire

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 5. Plastics

Plastics  are  versatile  materials,  and  have become a universal material used on a daily basis  around  the  world.  Plastic  materials display unique properties when compared to  other  materials  and  have  contributed greatly  to  the  quality  of  our  everyday life.  However,  they  are  potent  sources  of pollution.

Figure 3.11: Different objects made of plastic

In this image, we can see a tire, some objects, a bottle, a cup, a plate, a cup, a spoon, a fork, a knife, a bottle cap, a cup, a plate, a cup, a spoon, a fork, a knife, a bottle, a cup, a spoon, a fork, a knife, a plate, a cup, a spoon, a fork, a knife, a bottle cap, a cup, a plate, a cup, a spoon, a fork, a knife, a bottle, a cup, a spoon, a fork, a knife, a bottle cap, a cup, a plate, a cup, a spoon, a fork, a knife, a bottle cap, a cup, a plate, a cup, a spoon, a fork, a knife, a bottle cap, a cup, a plate, a cup, a spoon, a fork, a knife, a bottle cap, a cup, a plate, a

<!-- image -->

## Plastics can be natural or synthetic.

- Natural plastics come from plants, insects or animal horns; a good example is latex (rubber) which comes from a tree.
- Synthetic plastics are derived from petroleum products, mainly crude oil.

## Types of plastics

Plastics are classified into two groups: thermoplastics or thermoset plastics.

## Thermoplastics

Thermoplastics  can  be  easily  shaped  when  heated.  They  can  be  reheated  and  reshaped numerous times without any significant change in their properties. Thermoplastic products can be recycled easily. However, they cannot be used to make objects which have to resist high temperatures.

## Common types of thermoplastics

## Polyvinyl Chloride (PVC)

PVC has a light weight. It has good chemical, electrical and weather resistance.

PVC can be cut, shaped and joined easily.

- Water pipes
- Windows and doors
- Cable insulations

Figure 3.12: PVC water pipes

<!-- image -->

## Polymethyl methacrylate (Acrylic)

Acrylic is a transparent, rigid and tough material which is widely used as a replacement for glass. It has also good resistance to chemicals but, it has poor wear and abrasion resistance.

- Car rear light covers
- Display signs
- Lenses
- Aquariums

Figure 3.13: Polymethyl methacrylate (acrylic) sheets

In this image we can see a few colors.

<!-- image -->

## Polypropylene

It  is  used  in  a  variety  of  applications  as  it  is  light, hard  and  tough.  It  provides  good  resistance  to chemical, electricity and work fatigue. However, it scratches easily.

- Medical equipment &amp; laboratory equipment
- Kitchen equipment
- Plumbing fittings
- Carpets
- Electric kettles

## Polyamide (Nylon)

Polyamide has a creamy colour. It is tough, fairly hard and resistant to chemicals, wear and friction. Nylon is also mechanically durable and self-lubricating.

- Bearings.
- Gear wheels.
- Fishing lines
- Zip fasteners
- Clothings

## Low density polythene (LDPE)

LDPE is a tough, flexible and fairly soft material. It has good resistance to chemicals and electricity.

- Food containers
- Squeeze bottles
- Carrier bags
- Toys
- Packaging films

<!-- image -->

Figure 3.14: Bottle caps made of polypropylene

Figure 3.15: Gear wheels made of polyamide

<!-- image -->

Figure 3.16: Packaging film made of low density polythene

In this image we can see many rolls of paper.

<!-- image -->

## High density polythene (HDPE)

HDPE  is  a  stiff  and  hard  material.  It  has  good resistance  to  impact,  electricity  and  chemicals.  It can also withstand low temperatures.

- Pipes
- Bleach bottles
- Buckets
- Toys

Figure 3.17: Bleach bottles made of high density

In this image we can see a few bottles.

<!-- image -->

## Thermosetting plastics

Thermosetting plastics can be heated and shaped only once. Any attempt to reheat them will result in damaging or burning them. They are stiffer than thermoplastics. However, they are not ideal for recycling using heat. Thermosetting plastics can resist higher temperatures compared to thermoplastics.

## Common types of thermosetting plastics

## Urea formaldehyde

Urea formaldehyde is a stiff, hard, but brittle material. It has good resistance to heat and electricity.

## Uses

- Adhesives
- Electric components/ fittings
- Kitchenware handles

Figure 3.18: Electric fitting made of urea formaldehyde

<!-- image -->

## Epoxy resins

Epoxy  resin  is  very  durable  and  provides  good  strength properties when reinforced. It has good resistance to chemicals and has very good adhesive qualities.

## Uses

- Adhesives
- Chemical- resistant paints
- Laminates

Figure 3.19: Epoxy resins

<!-- image -->

## Polyester resin

Polyester resin is  tough and strong especially when reinforced with fibre glass. It has good resistance to chemicals and electricity. It can be worked out without pressure or heat and polishes well.

- Boats
- Car body panels
- Playground slides

## Rigid Polyurethane

Rigid polyurethane is resistant to tearing and to climatic conditions,  but  may  change colour with time. It is  also  a  good insulator.

- Insulating materials
- Floats

<!-- image -->

Figure 3.20: Polyester resins

<!-- image -->

Figure 3.21: Polyurethane

<!-- image -->

## Activity 4

1. Fill in each of the blanks using an appropriate word from the given list.

## strong, wear, acrylic, electricity

- i. \_\_\_\_\_\_\_\_\_\_\_\_\_is a transparent, rigid and tough material which is widely used as a replacement for glass.
- ii. Polyester resin is tough and \_\_\_\_\_\_\_\_\_\_\_especially when reinforced with fibre glass for example.
- iii.  Polyamide is tough, fairly hard and resistant to chemicals, \_\_\_\_\_\_\_\_ and friction.
- iv.  Urea formaldehyde is a stiff, hard, and has good resistance to\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

2. Name one plastics which may be used to make each of the following products. Give one reason for your answer.

## i. Car light cover

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ii. Float

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## iii. Bottle cap

Material: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 6. Tools used when working with materials

Each stage of the manufacturing process involves the use of different tools. Each tool has a specific purpose and requires some safety considerations. The diagram below illustrates the different categories of tools used during the manufacturing process.

In this image, we can see a diagram. In the diagram, we can see a circle and a line. We can also see some text.

<!-- image -->

## Measuring and marking out tools.

Measuring and marking out is aimed to transfer required dimensions and shape on a material. It is important to select the appropriate tools accordingly to the task to be accomplished and the material you are working with.

<!-- image -->

## RECALL

During the measuring and marking process, it is always a good practice to:

- Avoid parallax error by placing eye perpendicularly
- Avoid end errors for accurate measurement
- Clamp work securely using scrap wood

Table 3.8 illustrates common measuring and marking tools used on metal, wood or plastic work pieces.

<!-- image -->

<!-- image -->

| Tools          | Uses                                                                                                                                                                                                               | Wood   | Metal   | Plastic   |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|---------|-----------|
| Measuring tape | • A measuring tape is available in different lengths and scales (millimetre, centimetre or inch) . It is used to measure long dimensions.                                                                          |        |         |           |
| Steel rule     | • A steel rule is available in different dimensions; as from 150 mmto1000 mm. It is mainly used to measure short dimensions. It provides better accuracy than a measuring tape. It is also used to check flatness. |        |         |           |
| Pencil         | • A pencil is used to mark on timber.                                                                                                                                                                              |        |         |           |
| Scriber        | • It is used to make fine and semi- permanent markings on metal surfaces.                                                                                                                                          |        |         |           |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Felt-tip pen      | • A felt-tip pen is used to mark on plastic surfaces as it provides a permanent marking but does not leave any scratch on the surface.                                       |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Marking gauge     | • A marking gauge consists of a stock and an adjustable stem. It is used to mark parallel lines to the face side or the face edge.                                           |
| Sliding bevel     | • A sliding bevel is used to draw lines at angles on workpieces.                                                                                                             |
| Try square        | • It is used to draw perpendicular lines during the marking out process. • A try square is also used to check squareness during preparation of timber or assembly processes. |
| Engineer's square | • The engineer's square is used to mark perpendicular lines or lines at an angle of 45°. • It is used to check the squareness during assembly processes.                     |
| Centre punch      | • It is used to make an indentation on metals before the drilling process. • A hammer is then used as a driving tool.                                                        |

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.8: Measuring and marking out tools

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 1. State the use of each of the following tools:

i.  Pencil:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

ii.  Try  square:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

iii. Sliding bevel: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

iv.  Centre  punch: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- v.  Marking  gauge:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Sketch each of the following measuring and marking out tools:

- i. Steel rule

- ii. Engineer's square

- iii. Scriber

- iv. Try square

- v. Marking gauge

## Holding tools

Holding tools are used during different stages of the manufacturing process. They are used to secure work pieces during different processes; such as cutting out planing or drilling. They are also used to clamp work pieces during joining operations. Table 3.9 illustrate common holding tools.

<!-- image -->

## RECALL

When using holding tools, it is always a good practice to use a piece of scrap material so as to protect the surface of the work piece.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Tools           | Uses                                                                                                                                                                                                                                             | Wood   | Metal   | Plastic   |
|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|---------|-----------|
| Bench vice      | • A bench vice has a smooth and flat jaw to prevent the workpieces from damaging. • It is used to clamp wood work piece during different processes; such as cutting, planing or chiselling. This provides secure working conditions to the user. |        |         |           |
| Engineer's vice | • The jaw of the vice is composed of grips for better holding of the material. • It is used to hold work pieces during different processes; such as cutting or filling. • This provides secure working conditions for the user.                  |        |         |           |
| Machine vice    | • A machine vice is used to hold a work piece during different processes, such as drilling. The vice can be fixed to machines (such as a pillar drill) using bolt and nuts.                                                                      |        |         |           |
| G-clamp         | • A G-clamp is used to hold different materials on the work bench. It may be used during different process, such as joining or assembling.                                                                                                       |        |         |           |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.9: Holding tools

| Bench hook   | • A bench hook is used to hold work pieces while sawing and chiselling. • It can be secured in a bench vice.                                        |
|--------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Mitre box    | • A mitre box is used to hold wood work pieces during the cutting process. • It enables the user to make accurate 45° cuts.                         |
| Pliers       | • Pliers are used to hold and grip small work pieces during different processes, such as drilling. • It is available in different sizes and shapes. |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Complete the following table.

<!-- image -->

<!-- image -->

Table 3.10: Holding tools

| Name       | Uses                                                                                             | Sketch   |
|------------|--------------------------------------------------------------------------------------------------|----------|
|            | • It enables the user to make accurate 45° cuts.                                                 |          |
|            | • They are used to hold and grip small work pieces during different processes, such as drilling. |          |
| Bench vice |                                                                                                  |          |

## Cutting tools

Cutting tools are used to cut materials to size, make holes, planing or to make joints after the marking out process.

<!-- image -->

RECALL

When using cutting tools, it is always a good practice to:

- Use appropriate holding tools to clamp the work piece when sawing.
- Use scrap material to protect the workpiece surface.
- Always use full length of the saw blade.
- Wear appropriate safety equipment, such as a goggle and gloves.
- Ensure the drill bit is fastened correctly.
- Punch the position of holes to ease drilling.
- Clean the machine and work bench after working.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The table 3.11 illustrates different cutting tools used for sawing, planing, filing, chiselling and drilling.

| Tools          | Uses                                                                                                                                                     | Wood   | Metal   | Plastic   |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|--------|---------|-----------|
| Hand saw       | • A hand saw is used to cut large-sized wood materials or boards.                                                                                        |        |         |           |
| Tenon saw      | • A tenon saw is used to cut wood materials along straight lines and for cutting tenons.                                                                 |        |         |           |
| Coping saw     | • A coping saw is used to cut along curved lines in thin wood and plastic materials as its blade can be rotated to any angle.                            |        |         |           |
| Hack saw       | • A hack saw is used to make straight cuts in metal or plastic materials.                                                                                |        |         |           |
| Junior hacksaw | • A junior hacksaw is used to cut along lines on both metal and plastic. It is used for light works.                                                     |        |         |           |
| Snips          | • Snips are used to cut sheet metals along straight or curve lines. They are available in different sizes.                                               |        |         |           |
| Chisel         | • Chisels are used to cut and shape wood; such as grooving and paring. It is available in different shapes and sizes. • It is used with a wooden mallet. |        |         |           |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Jack plane           | • A jack plane is used during the preparation of timber. It is used to plane wood materials to correct size and shape.                           |
|----------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| Woodrasps            | • It is used to shape wooden work pieces.                                                                                                        |
| Metal file           | • Metal files are used to file edges and surfaces to remove marks and for a smooth flat finish. • It is available in different shapes and sizes. |
| Hand drill           | • It is used to drill holes in soft materials such as wood or plastic work pieces.                                                               |
| Portable power drill | • A portable electric drill is a power tool used to drill holes in different materials.                                                          |
| Pillar drill         | • A pillar drill is used to drill holes in different materials. It offers more accuracy and safety during the drilling process.                  |

<!-- image -->

1. State the use of each of the following cutting tools:
2. Sketch each of the following cutting tools:
- i. Hand drill
- ii. Jack plane
- iii. Hand saw
- iv. Junior hacksaw

i. Coping saw: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

ii. Tenon saw: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

iii. Hack saw: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- iv. Portable power drill: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

v.  Chisel:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

vi.  Metal file:    \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

vii.  Snips:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Driving tools

Driving tools are basically tools used to drive (insert) another object into the working materials. They may be used to strike on material or other tools. Table 3.12 illustrate common driving tools.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.12: Driving tools

| Tools        | Uses                                                                                                                                            | Wood   | Metal   | Plastic   |
|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------|--------|---------|-----------|
| Hammer       | • A hammer is used to drive nails. It is also used for centre punching, riveting and bending. • It is available in different types and weights. |        |         |           |
| Mallet       | • A mallet is used during the assembly of wooden parts. It is also used to strike on wood chisels.                                              |        |         |           |
| Screw driver | • A screw driver is used to insert and withdraw screws. • It is available in flat blade and cross-blade types and sizes.                        |        |         |           |
| Spanner      | • A spanner is used to tighten and loosen bolts and nuts. • It is available in different types and sizes.                                       |        |         |           |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Complete the table below

| Sketch       | Uses   |
|--------------|--------|
| Screw driver |        |
| Hammer       |        |
| Mallet       |        |
| Spanner      |        |

## Orthographic Projection

## Learning Objectives

## By the end of this unit, you will be able to:

- Draw objects in orthographic projection on plain paper.
- Insert major dimensions on the different orthographic views.

## 1. Introduction

Orthographic projections are a collection of 2D drawings that work together to give an accurate overall presentation of an object. It is widely used by architects, engineers, designers and other technical persons. Orthographic views provide many details and features of an object.

GRADE In order to realise the chosen solution in a design process, the chosen design must contain all the information needed. 3D drawings such as isometric, oblique and perspective can be used to show the chosen solution. While 3D drawings show the overall concept and design, they do not give all the information to realise the product.

This unit is about drawing objects in orthographic projection on plain paper. Plain paper has an advantage over grid paper as more precise dimensions may be given.

## 2. The principal views

Figure 4.1 shows a F-block in isometric projection.

Figure 4.1: Isometric projection

<!-- image -->

Figure 4.2 shows the F-block projected on the vertical and horizontal planes. To get orthographic views of the F-block, three planes are used to project the Front, Top and Side views. The planes are then opened flat.

Figure 4.2: Projection on vertical and horizontal planes

In this image we can see a metal object.

<!-- image -->

Figure 4.3: Planes opened flat

In this image, we can see a diagram. There are two objects in the image.

<!-- image -->

Figure 4.4: Three views

The image is a bar chart. It consists of two vertical bars, one on the left and the other on the right. The leftmost bar is colored red and the rightmost bar is colored yellow. The height of each bar is indicated by the height of the corresponding color.

### Description of the Bar Chart:
1. **Leftmost Bar**:
   - Color: Red
   - Height: 1

2. **Rightmost Bar**:
   - Color: Yellow
   - Height: 1

### Analysis:
- **Leftmost Bar**:
   - The leftmost bar is colored red.
   - The height of this bar is 1.

2. **Rightmost Bar**:
   - The rightmost bar is colored yellow.
   - The height of this bar is 1.

### Additional Information:
- **Side View**:
   - The leftmost bar is colored red.
   - The height of this bar is 1.

2

<!-- image -->

## Note:

Figure 4.5 shows common types of lines used in orthographic projection. These lines provides information on the drawn object.

Figure 4.5: Types of lines

In this image, we can see a table with some text and numbers.

<!-- image -->

| Outline                           |
|-----------------------------------|
| Projection line/Construction line |
| Hidden detail                     |
| Centre line                       |
| Dimension line                    |

## 3. Worked Example

Figure 4.6 shows the F-shaped block. An orthographic projection of the shaped block will be drawn.

Figure 4.6 : F block

In this image, we can see a diagram. There are two lines, one is on the right side and the other is on the left side.

<!-- image -->

## Step 1

Put the F-shaped block in a crate to identify the maximum width, depth and height.

The sizes of the crate are:  W = 70 ; H = 100 and D = 30 as shown in Figure 4.7.

Figure 4.7: F-shaped block in a crate

The image depicts a geometric figure with a specific shape and dimensions. The figure is a square with a side length of 70 units. The side length of the square is 70 units. The side length of the square is also 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length of the square is 70 units. The side length

<!-- image -->

## Step 2

After fixing your paper on drawing board,draw the three views of the crate using thin lines as shown in Figure 4.8. Leave a space of 40 mm between the views.

Figure 4.8: Drawing of the tree views of the crate.

In this image, we can see a diagram.

<!-- image -->

## Step 3

Draw the front view of the F block.

In this image, we can see a diagram.

<!-- image -->

## Step 4

Project lines from the front view to complete the other views. Darken all visible lines. Add hidden lines to show hidden section.

Figure 4.10: Orthographic views

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

Draw the following objects in orthographic projection.

(i)

Figure 4.11: L shaped block

In this image, we can see a diagram.

<!-- image -->

Figure 4.12: Concrete bench

In this image, we can see a diagram.

<!-- image -->

(ii)

In this image, we can see a graph.

<!-- image -->

(iv)

Figure 4.14: Sawing jig

In this image, we can see a diagram. There are four boxes in the image. We can see arrows.

<!-- image -->

## 4. Circles and arcs in orthographic projection

In this image, we can see a diagram. There are two lines and a point.

<!-- image -->

Figure 4.16 shows the lego part on its principal planes of projection.

In this image, we can see a diagram. There are two lines, one is a side view and the other is a front view.

<!-- image -->

Figure 4.17 shows the orthographic projection of the lego part.

You may notice the following:

- Circular parts appear as rectangles in the other two views.
- Different types of lines have been used.

Top view

In this image we can see a diagram.

<!-- image -->

Figure 4.17: Orthographic views of the lego part

## Correct and incorrect dimensioning

In this image, we can see a diagram. There are numbers and text written on the image.

<!-- image -->

In this image, we can see a diagram. There are some lines and symbols.

<!-- image -->

Figure 4.18 below shows the lego part properly dimensioned.

In this image, we can see a diagram. There are two lines, one is on the right side and the other is on the left side.

<!-- image -->

Top view

Figure 4.18: Orthographic views of the lego part with dimensions

<!-- image -->

Draw the orthographic projection of the following objects.

Insert the major dimensions on the different views.

(i)

In this image, we can see a diagram. There are two lines, one is a cylinder and the other is a cylinder. We can see the text on the image.

<!-- image -->

Figure 4.20: Drill Jig

In this image, we can see a diagram. There are two lines, one is labeled as "F" and the other is labeled as "T".

<!-- image -->

<!-- image -->

Draw the following objects in orthographic projection. Insert major dimensions. Any missing dimension should be estimated

Figure 4.22

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a diagram. There are lines, points, and a box.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

Figure 4.27

In this image, we can see a diagram.

<!-- image -->

|   Unit 4 - Orthographic Projection

102

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a diagram. There are arrows, a line, and a box.

<!-- image -->

(xi)

Figure 4.31

In this image, we can see a diagram with a line.

<!-- image -->

(xii)

In this image, we can see a diagram. There are four cubes. We can see the numbers on the right side of the image.

<!-- image -->

Figure 4.33

In this image we can see a diagram.

<!-- image -->

## Mechanisms

## Learning Objectives

## By the end of this unit, you will be able to:

- State the functions of mechanisms
- Identify the different mechanisms used in machines

## 1. Introduction

Mechanisms make our lives easier and more comfortable. Mechanisms bring products to life. Basic domestic items like a pair of scissors, clocks, door handles and kettles, use mechanical systems. Large scale products like bicycles, trains, lifts, gym equipment and escalators depend on  mechanisms to function  effectively.  Mechanisms  consist  of  various  moving  parts  which change the input condition into a desirable state.

Figure 5.1: Mechanisms present in Gym Equipment

In this image we can see a man who is doing exercises on the gym.

<!-- image -->

In this image we can see a metal object.

<!-- image -->

Figure 5.2: Mechanical components in a watch

Mechanisms are used to control or transform movement in a machine.

Input Motion

MECHANISM

Output Motion

Input motion is the result of driver force or driver speed applied, while the output motion or driven motion is the resulting change due to the mechanism used.  Mechanism can transform motion.  There exists basically four different types of motion that mechanisms can convert:

In this image, we can see a diagram. There is a person holding a stick. We can see a clock. There is a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding a stick. We can see a person holding

<!-- image -->

| The motion is in a straight line.                                | Linear Motion:       |
|------------------------------------------------------------------|----------------------|
| The motion follows a circle.                                     | Rotary Motion:       |
| The motion is a linear repetitive up-and-down or back-and-forth. | ReciprocatingMotion: |
| The motion is a rotary repetitive up-and-down or back-and-forth  | Oscillating Motion:  |

## 2. Mechanical Components

A  large  variety  of  mechanical  components  are  present  in  mechanisms  to  perform  different functions.  These components are mostly connected to motors via a shaft (i.e. the connecting rod) to give output force or speed. Figure 5.3 highlights some of the most common components.

Figure 5.3: Mechanical Components

In this image, we can see a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a chain and a

<!-- image -->

<!-- image -->

## 1. State the purpose of a mechanism.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Fill in the table below with products which use mechanisms.

An example has been done.

| HomeLocation         | Products   | Uses         |
|----------------------|------------|--------------|
| Living / Dining Room | 1. Clock   | To read time |
|                      | 2.         |              |
|                      | 3.         |              |
| Kitchen              | 1.         |              |
|                      | 2.         |              |
|                      | 3.         |              |
| My Room              | 1.         |              |
|                      | 2.         |              |
|                      | 3.         |              |

## Pneumatics and Hydraulics

## Learning Objectives

## By the end of this unit, you will be able to:

- Explain the working principles of pneumatic and hydraulics systems
- State the advantages, disadvantages and common applications of pneumatic and hydraulic systems

## 1. Introduction

Pneumatic and hydraulic systems are widely used in manufacturing industries, in the transport sector and in the development of automated systems. They are used to generate, control and transmit forces to perform mechanical work. Pneumatic and hydraulic systems are quite similar in their functioning but differ in the medium used to transmit power.

## 2. Pneumatic system

GRADE In  pneumatics,  mechanical  motion  is  achieved  by  using  pressurised  air  that  is  obtained  by putting air under greater pressure than the air in the natural environment. By compressing air,  stored  energy  is  available  to  produce,  transmit  and  control  movement  for  operation  of pneumatic systems. An air compressor is used to pressurise and store air.

<!-- image -->

## ACTIVITY 1

Figure 6.1 and Figure 6.2 show different types of air compressors.

ORIGIN

Figure 6.1

In this image we can see a vehicle.

<!-- image -->

Figure 6.2

State one application of each of the compressors.

## Uses of pneumatic systems

The wide application of pneumatic systems in our everyday life includes the following:

- Tyre pumps and gauges
- Road drills
- Jackhammers
- Parking brakes of vehicles
- Paint sprayer
- Automatic doors of vehicles
- Nail guns
- Dentistry equipment
- Impact wrench
1. Fill in the blanks with one word from the list given below

Orbital sander

<!-- image -->

Jackhammer

<!-- image -->

Figure 6.3: Pneumatic equipment

<!-- image -->

## noise, energy, free, rotary, pressurised, movement

- a. In pneumatics, mechanical motion is achieved by using \_\_\_\_\_\_\_\_\_\_\_\_\_ air.
- b. In  a  pneumatic  system,  compressed  air  is  used  to  produce,  transmit  and  control
3. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.
4. c.
5. Pneumatic system can generate both linear and \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ movement.
- d. \_\_\_\_\_\_\_\_\_\_ level of exhaust air is loud.
- e. Pneumatic system has a low running cost as air is \_\_\_\_\_\_\_\_\_.
8. 112 2. State three examples of pneumatic devices having rotary motion.
3. Name three reciprocating pneumatic devices.
4. Produce a poster to show the applications of pneumatic systems in the manufacturing and transport sector.

Impact wrench

<!-- image -->

## 3. Hydraulic systems

Hydraulic  systems,  just  like  pneumatic  systems,  are  used  to  generate,  transmit  and  control energy. However, a hydraulic system is a method of transmitting force or motion by applying pressure  on  a  confined  fluid  using  a  pump. The  most  frequently  used  fluid  is  OIL  as  it  has lubricating and anticorrosion properties. Hydraulics finds extensive use due to the following two properties of fluids useful in power transmission.

1. Fluids cannot be compressed.
2. Fluids have the ability to multiply force.

A hydraulic system consists of the following essential elements:

1. An oil reservoir: used to store oil
2. A hydraulic pump: used to pressurise oil
3. Control valves: used to control the speed and direction of oil
4. Piston and cylinder/ hydraulic motor: used to produce a linear movement or
5. a hydraulic motor used to provide rotary motion
5. Pipes or tubing: used to transmit pressurised oil
6. Hydraulic fluid: to transmit power and lubricate the system

## Uses of hydraulic systems

Hydraulics systems are widely used in our everyday life. Some common applications of hydraulic systems are:

- Hydraulic lifts/elevating platforms
- Hydraulic brakes in vehicles
- Hydraulic shock absorbers
- Applications in heavy equipment, e.g. forklifts, cranes and bulldozers.
- Hydraulic jacks
- Presses
- Injection moulding machines

Figure 6.4: Hydraulic shock absorber

<!-- image -->

Figure 6.5: Hydraulic car jack

<!-- image -->

## Hydraulic cylinders controlling movement of arms

In this image we can see a vehicle.

<!-- image -->

Figure 6.6: Hydraulic machinery

<!-- image -->

1. State whether each of the following statements is True or False .
- a. Hydraulic systems use air to generate, transmit and control energy.
- b. Hydraulics find extensive use in power transmission due to the incompressibility of liquids.

\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_

- c. Hydraulic motors produce reciprocating motion in hydraulic machineries.

\_\_\_\_\_\_\_\_\_

2.  State the function of each of the following components in a hydraulic system:
- a. A Hydraulic pump
- b. An oil reservoir
- c. Control valves
3. Describe two functions of oil in a hydraulic system.
4. Produce a poster to show the wide applications of hydraulic systems.

## The Design Process

## Learning Objectives

## By the end of this unit, you will be able to:

- Describe the stages of the design process
- Apply the design process to solve a problem
- Use basic tools and techniques safely to mark, cut, join and finish materials in the realisation of the chosen solution

## 1. Introduction

Designing is a structured activity used to solve a problem found in your immediate environment. You will have good chances of coming up with a solution when you follow the design process.

## The design process

GRADE The design process is a thinking and problem-solving activity. It comprises the various stages as shown in Figure 7.1. The stages would help you work logically and systematically towards finding a solution for an identified problem.

In this image, we can see a diagram. There are some text and numbers on the image.

<!-- image -->

## 2. The Design Process in action

Now that you are familiar with the different stages of the design process, let us work on a design activity. This activity will be based on designing and making an artefact as well as producing a design folio to present the different stages of the design process.

## 1 - Identification of the problem

The first stage of the design process is to identify a problem from a design situation. A situation is an occasion, an event or a daily routine activity that the intended user has experienced. It is also important to mention the intended user and the context within the situation.

## NOTE:

- Intented user can be your family, your friend, you  or any other person. Other aspects related to the intended user can be age group, name of company, gender (if needed) .
- Context is the location or area within which the situation has been described. Examples can be school, home, beach, public garden.

Figure 7.2 shows an example of a situation which has been presented in a portfolio.

In this image, we can see a group of people sitting on chairs and there are some people standing. We can also see some text and images.

<!-- image -->

<!-- image -->

Identify a problem and write a situation.

## Design Brief

The design brief is a statement of intent showing what you are going to do in the project as shown in Figure 7.3.

In this image, we can see a poster with some text and images.

<!-- image -->

Figure 7.3

<!-- image -->

Write down a design brief based on your problem identified.

## 2 - Research and analysis

In this section, you will analyse the design brief carefully and list the important factors to be considered for the possible solutions required for the design brief. A mindmap will help you plan your research as shown in Figure 7.4.

In this image, we can see a paper holder. There are some text and images.

<!-- image -->

Figure 7.4

<!-- image -->

Present a mindmap with all the factors to be considered for your research work based on the design brief of your identified problem.

## Analysis of existing products

During  research,  existing  products  are  analysed  using  various  factors.  Figure  7.5  shows  an example of how the features of an existing tissue paper holder are described and evaluation done on some criteria.

Figure 7.5

In this image, we can see a diagram with some text and images.

<!-- image -->

## The following factors can be considered to describe the tissue paper holder

- What is the function of the tissue paper holder?
- In which sizes is the tissue paper holder available?
- Is the holder comfortable to use?
- What materials are used to make it?
- Is it appealing?
- What realisation methods have been used in making the tissue paper holders?
- Is it safe to use?
- Is the tissue paper holder stable?

## The following checklist can be considered to evaluate the tissue paper holder.

- Does the tissue paper holder function well?
- Are the sizes of the tissue paper holder appropriate?
- Are the users able to take out tissue papers from the holder easily? Are the users able to handle the holder comfortably?
- Is the material safe to use? Is the material non-toxic?
- Does its colour or finish match with its environment?
- What joining methods are used?
- Does it have sharp edges or corners?
- Does the tissue paper holder stay standing in its upright position when in use?

<!-- image -->

## 3 - Specifications

The specifications consist of a list of points that define the key features of the design solution.

## Example:

1. The tissue paper holder must hold tissue papers and is to be used on a table where all family members can use it.
2. The size of the tissue paper holder must not be greater 350 mm in width, 200 mm in height and 150 mm in depth or thickness.
3. It must be made with materials which can be assembled easily.

<!-- image -->

Relating to criteria considered as important, present a list of specifications for your design.

## 4 - Generation of ideas

Generation of ideas involves sketching a range of ideas as possible solutions. An evaluation is  also  done  to  select  the  best  idea.  Figures  7.6,  7.7  and  7.8  show  three  possible  solutions generated for a tissue paper holder.

Figure 7.6

In this image, we can see a poster with some text and images.

<!-- image -->

Figure 7.7

In this image, we can see a diagram, there are some text and a picture of a person.

<!-- image -->

Figure 7.8

In this image, we can see a diagram. There are some text and images on the image.

<!-- image -->

<!-- image -->

Propose 3 possible solutions for your project.

## Selection of idea

After generating ideas, you have to select one idea. Selecting an idea means choosing one which satisfies most of the specifications criteria. Analysing generated ideas are useful in order to select an appropriate idea.

The table below shows how to analyse and compare the ideas. A written analysis has been used to evaluate each specification factor. Based on the evaluation given, one idea can be selected as the best.

| Specificationcriteria   | Idea 1                                | Idea 2                                       | Idea 3                                                |
|-------------------------|---------------------------------------|----------------------------------------------|-------------------------------------------------------|
| Function                | hold tissue with its packaging        | holds some tissue paper                      | holds some tissue paper                               |
| Shape                   | triangular shape is appealing         | typical rectangular shape                    | half moon shape is appealing                          |
| Size                    | will not take much space              | is wide, occupies space                      | occupies much space                                   |
| User comfort            | can use it comfortably                | can use it comfortably                       | can use it comfortably                                |
| Material                | has a good finish                     | can see the tissue easily                    | can be joined easily                                  |
| Appearance              | good design and has three colours     | good cutlery design                          | appealing flower design                               |
| Realisation method      | cut to shape and joined easily        | difficult to cut the cutlery design          | difficult to cut the flower design                    |
| Safety                  | has one sharp apex                    | has rounded corners                          | has no sharp corners                                  |
| Stability               | stable, will not tumble               | stable                                       | very stable                                           |
| User comment            | simple, appealing and easy to realise | appealing, safe to use but difficult to make | safe to use, simple but difficult to make side panels |
| Selected or rejected    | selected                              | rejected                                     | rejected                                              |

<!-- image -->

Using your specification criteria, select your best idea.

## Selection of idea

After analysing and evaluating the three ideas, Idea 1 has been selected.

In this image, we can see a paper with some text and a picture of a paper.

<!-- image -->

Figure 7.9

<!-- image -->

Present your selected idea and give reasons for your choice.

## 5 - Development of selected idea

Developing  the  selected  idea  requires  exploring  some  factors  of  the  idea  in  more  details supported with annotated sketches. The idea can be improved and critical decisions, such as material types and realisation methods, can be taken.

Figure 7.10 shows some of the areas that have been identified for development.

In this image there is a paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder. There is a paper on the paper holder.

<!-- image -->

Figure 7.10

<!-- image -->

Identify possible areas where your selected idea can be developed.

## Developing areas identified.

## Developing shape of the selected idea

Figure 7.11 shows an example of how the shape can be modified.

In this image we can see a paper with a paper holder. In the paper holder there are four pieces of paper.

<!-- image -->

Figure 7.11

<!-- image -->

Develop the shape of your selected idea.

## Developing the base and safety features of the selected idea

The base is an important feature to ensure safety. The base can be modified as shown in Figure 7.12.

Figure 7.12

In this image, we can see a diagram with some text and a picture of a paper.

<!-- image -->

## Further research: selection of materials for the selected idea

Further research will allow us to make decision about the materials and the manufacturing processes to be used as shown in Figure 7.13.

In this image there is a table with some text and images.

<!-- image -->

Figure 7.13

<!-- image -->

Propose and present different materials that may suit your selected idea. Select one or more materials that you find suitable for your selected idea.

## Developing the appearance of the selected idea

In this section, the cut out design that is to be done on the acrylic is developed as shown in Figure 7.14.

The image is a page of a book titled "Developing the decorative features of selected ideas." The page is divided into two main sections: the left side and the right side.

**Left Section:**
- The left side contains a diagram of a flower. The flower is depicted with a stem, petals, and a cluster of leaves. The petals are arranged in a circular pattern, and the leaves are arranged in a triangular pattern.
- The flower is labeled with the text "The stands have a half flower design."
- The right side contains a diagram of a fruit. The fruit is depicted with a stem, petals, and a cluster of leaves. The petals are arranged in a circular pattern, and the leaves are arranged in a triangular pattern.
- The fruit is labeled with the text "The stands have a smile design."
- The right side contains a diagram of a fruit. The fruit is depicted with a stem, petals, and a cluster of leaves. The petals

<!-- image -->

Figure 7.14

<!-- image -->

Develop the appearance of your selected idea.

## Final design

In this section, after development of the selected ideas, a final design is obtained. The final design is presented in a pictorial drawing. It is also drawn in an orthographic projection with some major dimensions. It is known as the working drawing of the final design.

The image is a drawing of a paper with a design. The drawing is of a paper with a design on it. The design is a circle with a line drawing of a person's hand holding a book. The hand is holding a book with a bookmark. The bookmark is a small circle with a line drawing of a person's hand holding a book. The drawing is done in a simple, cartoon style.

The background of the drawing is white. There is a line drawing of a person's hand holding a book with a bookmark. The hand is holding a book with a bookmark. The bookmark is a small circle with a line drawing of a person's hand holding a book. The drawing is done in a simple, cartoon style.

The drawing is of a paper with a design on it. The design is a circle with a line drawing of a person's hand holding a book. The hand is holding a book with a bookmark. The bookmark

<!-- image -->

Figure 7.15

<!-- image -->

Present your final design in pictorial projection and produce a working drawing.

## 6 - Production plan

In order to realise the product, a detailed plan must be made.

## Cutting list for tissue - paper holder

| Partname    | Material          | Dimensions   |   Quantity |
|-------------|-------------------|--------------|------------|
| Base        | 15 mmthick pine   | 280mmx130mm  |          1 |
| Side panels | 4mmthick acrylic  | 200mmx130mm  |          2 |
| Screws      | Brass countersunk | 20 mmlong    |          6 |

<!-- image -->

## ACTIVITY 14

Produce the cutting list for your chosen design.

## Flow chart for realisation

A flow chart is used to show the sequences of the different stages of the realisation process. An example is shown in Figure 7.16.

In this image, we can see a chart with some text and some lines.

<!-- image -->

|   Unit 7 - The Design Process

132

ACTIVITY 15

<!-- image -->

Produce the flow chart to plan how to realise your artefact.

Action Planning

An action plan is prepared to give details about the steps you will follow in order to realise the artefact using the appropriate tools and safety measures. It also indicates an estimated time you will take to complete each stage.

(i) Pine base

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Time (minutes)   | 20                                                                                                                                       | 10                                     | 10                                                                           | 120 drying time                                                                                     |
|------------------|------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------|------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|
| Safety           | Avoid parallax error, check flatness and squareness of workpiece before marking . Hold work piece tightly to avoid hazardous situations. |                                        | Use respiratory mask; hold work piece tightly to avoid hazardous situations. | Apply sealer and varnish carefully on the surface of the pine in a clean and well- ventilated area. |
| Tools            | Pencil, try-square, and a steel rule                                                                                                     | Wood vice, bench hook, tenon saw       | Sand-paper, rasp, smooth plane for levelling of the surface of the pine base | Paint brush, sealer, sand paper and varnish                                                         |
| Illustration     |                                                                                                                                          |                                        |                                                                              |                                                                                                     |
| Details          | Use pencil and try square on clean, prepared wood surface to mark out the work piece.                                                    | Use a tenon saw to cut tapered ends.   | Polish with abrasive paper.                                                  | apply sealer and varnish using paint brush, let workpiece to dry                                    |
| No. Tasks        | 1 Measuring and marking out of pine work piece                                                                                           | 2 Cutting, trimming and taper the ends | 3 Polishing                                                                  | 4 Applying sealer varnish with gloss finish                                                         |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Time                                                                           | 20                                                           | 10                                                                              | 60                                             | 30                                                                                                                                       | 20                              |
|--------------------------------------------------------------------------------|--------------------------------------------------------------|---------------------------------------------------------------------------------|------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------|
| Safety Avoid parallax error when measuring. The pattern should be symmetrical. | Follow the outline carefully.                                | Hold the work piece securely.Then cut out the shape from the acrylic carefully. | Hold the acrylic sheets and the base securely. | Use paper along the edge only to preserve the glossy surface, clean the acrylic sheet, remove protective sheets from acrylic after work. |                                 |
| Tools Pencil, try-square and steel rule                                        | Template for side panels, pencil, eraser                     | Wood vice, coping saw or hacksaw or junior hacksaw                              | Bench drill, hand drill                        | Abrasive paper, small                                                                                                                    | block of wood or smoothing file |
| Illustration                                                                   |                                                              |                                                                                 |                                                |                                                                                                                                          |                                 |
| Mark out and measure different parts of acrylic.                               | Use template, trace the outline of the shape on the acrylic. | Cut the shape with a coping saw from the acrylic sheet.                         | Drill the decorative holes                     | on the side panels. Polish the edge with a little amount of water                                                                        | Details                         |
| Tasks Measure, mark out and draw side                                          | panel on card Transfer patterns on acrylic                   | Cut out the shape of the panel side from acrylic                                | Drill holes                                    | Polish the edges                                                                                                                         |                                 |
| No. 1                                                                          | 2                                                            | 3                                                                               |                                                | 4 5                                                                                                                                      |                                 |

|   Unit 7 - The Design Process

134

## Assembly of pine base with acrylic panels

In this image, we can see a table with some text and images.

<!-- image -->

<!-- image -->

Produce an action plan to realise your artefact.

7 - Realisation of the artefact

## Preparation of material

## Acrylic sheet- side panels

## Step 1

Using a steel rule, the flatness of the workpiece is checked. The surface is marked as datum face. The edge is checked for straightness and is marked as datum edge.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Step 2

A template of the side panel is drawn on a Bristol paper. It is then placed on the acrylic sheet to mark the outline of the side panels. This is done again for the second side panel.

<!-- image -->

<!-- image -->

<!-- image -->

## Step 3

The work piece is held tightly between two pieces of scrap-wood in the bench vice. The acrylic sheet is cut into smaller size sheets.

<!-- image -->

<!-- image -->

In this image we can see a person holding a tool and cutting a piece of wood.

<!-- image -->

135

|   Unit 7 - The Design Process

136

## Step 4

A coping saw is used to cut the irregular shape. The workpiece should be held firmly during cutting.

<!-- image -->

<!-- image -->

<!-- image -->

## Step 5

A file is used to smoothen the edges of the tissue paper holder.

<!-- image -->

<!-- image -->

<!-- image -->

## Step 6

The holes are drilled using a hand drill. Drill bits of 4 different diameters are used to drill holes for decorative design on the side panels.

<!-- image -->

<!-- image -->

<!-- image -->

## NOTE:

- For drilling holes of larger diameters, a power hand drill or bench drill can be used to provide accurate drilling.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a person wearing a white shirt and a mask is working on a table. On the table we can see a drilling machine.

<!-- image -->

## Step 7

Drill bits of 2 different diameters are used to drill holes for screws to fix side panels to the base of the tissue paper holder.

In this image we can see a person standing and holding a tool in his hand.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|   Unit 7 - The Design Process

138

## Step 8

A little amount of water is used on a fine grade silicone carbide paper to polish the workpiece.

<!-- image -->

<!-- image -->

<!-- image -->

## Step 9

For preparing the base of the tissue paper holder,which is a wooden workpiece, it is first held securely in the bench vice. It is then planed to obtain a flat surface using a jack plane.

<!-- image -->

In this image we can see a person is standing and cutting the food with a wooden tool.

<!-- image -->

## Step 10

Using a steel rule, the flatness of the workpiece is checked.

<!-- image -->

<!-- image -->

The face is marked out using a pencil. This face is considered as the face side.

## Step 11

The work piece is held tightly in the bench vice. The edge of the workpiece is planed using a jack plane. The edge is checked for squareness with a try-square. The workpiece is now ready for marking out.

In this image we can see a person wearing a shirt and apron is standing. In the background there is a wall, fan, and some objects.

<!-- image -->

In this image we can see a person wearing apron is working on a table. On the table we can see some food items.

<!-- image -->

<!-- image -->

<!-- image -->

## Step 12

The edge of the wood workpiece is marked out using a pencil. The edge is then considered as a datum edge. The workpiece is now ready for marking out.

<!-- image -->

In this image we can see a wooden plank.

<!-- image -->

The face side and the face edge are marked.

## Step 13

The appropriate thickness of the material is marked out using a marking gauge. It is a line parallel line to the datum edge of base holder.  The timber is of a uniform width, thus it is not planed.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Step 14

The workpiece is then planed to its required thickness.

<!-- image -->

In this image we can see a hand holding a knife. In the background there are clothes and a wall.

<!-- image -->

## Step 15

A try square and a pencil, is used to mark out a straight line

In this image we can see a person is standing and holding a wooden object.

<!-- image -->

## Step 16

Using a marking knife and try-square, the line is marked cutting across the grain of the workpiece.

In this image we can see a person's hand and a measuring tape.

<!-- image -->

## Step 17

The workpiece is held safely on a bench hook and cut across using a tenon saw.

In this image we can see a person cutting a piece of wood with a knife.

<!-- image -->

In this image we can see a person's hands holding a wooden plank. In the background there is a wall.

<!-- image -->

## Step 18

Thin lines are drawn on the acrylic sheet panel to represent the base edge. The panel placed against the edge of the pine workpiece to mark the curve outline on the base.

<!-- image -->

<!-- image -->

<!-- image -->

Note: You can also use the template for side panels to mark the curved outline.

|   Unit 7 - The Design Process

142

## Step 19

A try square and a pencil are used to mark a straight line. Using a marking knife and trysquare, the line is marked cutting across the grain of the workpiece.

<!-- image -->

<!-- image -->

## Step 20

The workpiece is held safely on a bench hook and cut across diagonally using a tenon saw.

<!-- image -->

<!-- image -->

## Step 21

A coping saw is used to cut the curved shape. The workpiece should be held firmly during cutting.

<!-- image -->

In this image we can see a person is working on the wall.

<!-- image -->

## Step 22

A wood rasp is used to round off the edges of the base. A fine grade abrasive paper is used to polish the workpiece.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Step 23

Using a small paint brush, wood sanding sealer is applied along the grain of the base.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Step 24

Allow  the  sealer  to  dry,  then  the  workpiece  is  polished  along  the  grain  using  a  fine  grade abrasive paper.

<!-- image -->

In this image we can see a person is doing something with a wooden object.

<!-- image -->

<!-- image -->

## Step 25

Using a small paint brush, wood varnish is applied along the grain of the base.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Step 26

The workpiece is left to dry. The varnish gives a glossy finish to the surface of the base.

<!-- image -->

<!-- image -->

## Step 27

The template is placed on the edge of the base. Using a bradawl, three centres are mark out on the base. The centres are for holes that will be drilled for assembling the panels with the base.

<!-- image -->

<!-- image -->

## Step 28

The holes are drilled using a hand drill.

<!-- image -->

<!-- image -->

<!-- image -->

## Step 29

The protective sheets are removed from both sides of the acrylic sheet.

In this image we can see a person holding an object.

<!-- image -->

In this image we can see a person's hands holding an object.

<!-- image -->

## Step 30

Using a screw driver, the acrylic sheets are fixed to the base. Here, countersunk head screws have been used.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Final product

After  the  realisation  process,  the  final  product  is  presented  at  two  different  angles.  This  is done to facilitate you, or anyone to observe the appearance and other factors visible from the photographs.

In this image we can see a paper holder and a paper. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder. We can also see a paper and a paper holder.

<!-- image -->

Figure 7.17

<!-- image -->

Present your final product on a sheet. Your photographs must be taken at two different angles.

## 8 - Testing and evaluation

After the realisation process, you must evaluate to make sure that the product is suitable for the intended user. Evaluation can check whether a design needs to be changed or improved further. To test and evaluate a design, the following can be used:

- Testing the final product in its intended by users. (Figure 7.18)
- Using questionnaires to get feedback from users and other persons on the final product.
- Evaluating the product against the specification points (Figure 7.19)

<!-- image -->

In this image we can see a person wearing a white shirt and a blue shirt is holding a hot dog in his hand. There are two chairs and tables in the image.

<!-- image -->

<!-- image -->

<!-- image -->

Figure 7.18

<!-- image -->

## Evaluation against specifications

Figure 7.19

|    | Factors                         | Evaluations                                                                                                                                                                                                          |
|----|---------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Function                        | It is able to hold a maximum 30 tissue papers.                                                                                                                                                                       |
|  2 | Size                            | It is 200 mminwidth, 150 mminheight and 50 mmindepth. It is a bit small to hold the tissue papers.                                                                                                                   |
|  3 | User comfort                    | Tissue papers can be removed without falling. It is not cumbersome.                                                                                                                                                  |
|  4 | Material                        | It is made of acrylic side panels, wooden pine base joined effectively by brass screws. Simple techniques employed to work the materials.                                                                            |
|  5 | Appearance                      | It has triangular side panels with drilled decorative holes of assorted diameters, joined with a pine base tapered on both sides and brass screws. The pine base does not match the acrylic sheets.                  |
|  6 | Cost                            | Not too expensive as only small size materials are required.                                                                                                                                                         |
|  7 | Stability                       | It is stable.                                                                                                                                                                                                        |
|  8 | User's comment (Family members) | It is simple. It is stable. It can hold adequate number of tissue paper. It is not cumbersome and uses space in the task. It is made of simple materials. However, the pine base does not match the acrylic pannels. |

<!-- image -->

Evaluate your artefact by answering the questions, which are your specifications criteria.

## Any further modifications

After testing and evaluation, modifications can be made to the artefact based on the feedback obtained. With the aid of sketches and annotations, you can suggest some further refinements to the design.

In this image I can see a paper, a paper roll, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a paper, a

<!-- image -->

Figure 7.20

<!-- image -->

Present further modifications for your artefact.