## BIOLOGY GRADE 9

In this image we can see a poster with some text and images.

<!-- image -->

## BIOLOGY GRADE 9

In this image, we can see some images and text.

<!-- image -->

i

-Head Curriculum Implementation,Textbook Development and Evaluation

## BIOLOGY TEXTBOOK DEVELOPMENT PANEL

## MAURITIUS INSTITUTE OF EDUCATION

Dr Sarojiny Saddul-Hauzaree

- Coordinator, Associate Professor, MIE

Dr Shakeel M C Atchia

- Lecturer, MIE

Karuna Baguant

- Educator

Maya Mohabeer

- Educator

Nandini Sukhoo-Busawon

- Educator

Design

Kamla Ernest

Leveen Nowbotsing

Rakesh Sookun

- Chief Technician, MIE
- Graphic Designer, MIE
- Graphic Designer, MIE

Acknowledgements

The Grade 9 biology textbook panel wishes to thank:

-   Dr Anwar Bhai Ramjaun (Associate Professor, MIE), Dr Ravhee Bholah (Associate Professor, MIE),
- Mohun Cyparsade (Associate Professor, MIE) and Dr Fawzia Narod (Associate Professor, MIE) for their contribution.
- -Helina Hookoomsing (Senior Lecturer, MIE), Majhegy Murden -Louise (Lecturer, MIE), Suryakanti Anu Fulena (Lecturer, MIE) and Kamini Moteea (Lecturer, MIE) for proofreading.

## GRADE 9 BIOLOGY TEXTBOOK REVIEW PANEL

Mr Mohun Cyparsade

- Overall Coordinator, Associate Professor, MIE

Dr Shakeel M C Atchia

- Biology Coordinator, Lecturer, MIE

Maya Mohabeer

- Educator

Oumée Salmaa Peerbaccus

- Educator

Design

Sanjna Kathapermall

- Graphic Designer, MIE

Vedita Jokhun

- Graphic Designer, MIE

- © Mauritius Institute of Education - 2023

ISBN: 978-99949-75-31-0

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

FOREWORD

The MIE produced a set of new textbooks for Grades 1-9 based on the National Curriculum Framework and Teaching and Learning Syllabus for the implementation of the Nine Year Continuous Basic Education (NYCBE) reform. These have been key to curriculum transaction in the classroom. However, curriculum development is a dynamic enterprise that constitutes constant review and readjustment in relation to the evolving contextual factors and needs of Educators and learners. As such the Grade 9 Science textbook was reviewed taking into consideration the insights and views of stakeholders as well the emerging trends in Science Education. Even though dedicated textbooks are now available for each of the Science subjects, namely Biology, Chemistry and Physics, for ease of use, the guiding philosophy has remained unchanged. The content is contextualized, incremental and founded on basic scientific skills developed in Grades 7 and 8.

As in all curriculum endeavours, a number of contributors have been involved in the review of the Grade 9 textbook. I remain appreciative of the efforts of the panel who, at the inception, gave the textbook its orientation. I thank the review team for finetuning the resource in the light of feedback obtained to enhance teaching and learning experiences. The Educators who were part of the validation process have also played an important role in ensuring that the reviewed Science textbooks are sound. Last, but not the least, the Graphic Designers are to be thanked for their continuous collaboration in the development of apt educational resources.

I wish all users of the Science textbooks an enriching and enjoyable experience.

Dr Hemant Bessoondyal Director

Mauritius Institute of Education

PREFACE

The Grade 9 biology textbook is in compliance with the National Curriculum Framework (NCF, 2017) and the Teaching and Learning Syllabus (TLS, 2017) for science. The textbook ensures a smooth transition from the earlier grades by building upon content learnt up to Grade 8.

The  textbook  is  conceptualised  in  such  a  way  that  it  includes  a  number  of inquiry-based activities and accompanying tasks for learners. In line with the constructivist approach, the activities will enable learners to build and reinforce understanding of science concepts. As such, a conscious effort must be made to  actively  engage  pupils  in  all  activities  and  to  allow  them  to  manipulate specimens,  materials,  simple  equipment  and  apparatus  safely  and  under supervision.

The use of everyday experiences and contexts that students can easily relate to  is  favoured.  Care  is  taken  to  incorporate  learner-centred  strategies  like project-based learning and concept mapping to actively engage the learners in the learning process and to provide for independent learning. Furthermore, whenever relevant, applications of the biological concepts learnt in real life situations are highlighted.

Additionally,  the  activities  seek  to  develop  in  students  the  necessary  skills, attitudes and values for scientific inquiry. Students must be given ample time to actively engage in the activities, communicate their findings and observations in  multiple  ways,  discuss  with  their  friends  and  teachers  and  think  before writing down their answers. Though many questions are incorporated within the  activities,  educators  are  encouraged  to  prompt  learners  with  additional questions while implementing them in the classroom.

The textbook includes important features that support effective assessment. ' Test  yourself '  is  for  formative  purposes  and  are  meant  to  reinforce  and consolidate understanding of the concepts learnt and the inquiry skills that students have developed. At the end of each unit, the questions are scaffolded so that students can apply their knowledge and understanding to solve simple as well as challenging questions.

More  importantly,  for  Grade  9,  the  textbook  seeks  to  provide  relevant  and authentic  assessment  materials  for  the  purpose  of  the  National  Certificate of  Education  (NCE)  assessment  at  the  end  of  the  NYBCE  cycle.  The ' End  of Unit  Exercises '  provides  educators  with  opportunities  to  assess  learners' understanding  of  concepts  addressed  in  the  units  and  to  provide  timely feedback  and  support.  This  section  comprises  a  variety  of  exercises,  such as  fill-in-the-blanks,  matching,  multiple  choice  and  structured  questions, amongst others.  It is recommended to encourage learners to develop higher order thinking skills and to justify their answers as and when appropriate as this promotes critical analysis and deeper conceptual understanding. Using a differentiated approach, educators are expected to develop more assessment exercises or to adapt those provided to assess learners of different abilities.

The ' What  I  have  learnt '  icon  summarises  the  concepts  learnt  through  the inquiry-based activities. The 'Find out' icon aims at encouraging students to look  for  information  beyond  the  scope  of  the  textbook  and  to  develop  the habit and skills of looking for information from various sources. The ' Did you know ?' icon is included to trigger students' interest and curiosity about science. This  section  not  only  provides  them  with  interesting  information  related  to the concepts being addressed but it also helps to stimulate their curiosity and stretch  their  imagination  further.  Suggestions  are  made  for ' Project work '  to promote cooperative learning.

A ' Summary of unit ' and ' Concept map ' are incorporated at the end of each unit to clearly summarise all the key and relevant concepts learnt. With the visual impact that graphic organisers afford, students can make connections among concepts in the hope that learning is aided, consolidated and eventually a high retention rate is ensured.

It  is  sincerely  hoped  that  the  textbook  helps  motivate  learners,  stimulates their interest in science and develops the habits of mind and skills for scientific inquiry.

Dr (Mrs) Sarojiny Saddul-Hauzaree Coordinator The Science Panel

In this image, we can see a poster with some text and some images.

<!-- image -->

## Table of Contents

## Biology: UNITS B1-B4

In this image, we can see a diagram.

<!-- image -->

Blood Circulatory System

Unit

Unit

Unit

B1

1

Measurement in Science

1

Unit

## Blood Circulatory System

## Learning Outcomes

## At the end of this unit, you should be able to:

- State that the human circulatory system consists of the blood, the heart and the blood vessels
- Show an awareness that the heart is a pumping organ distributing blood throughout the body
- List the four main components of blood as blood plasma, red blood cells, white blood cells and platelets
- Outline briefly the function(s) of red blood cells, white blood cells, platelets and blood plasma
- Calculate magnification of drawings of blood cells
- Compare the structure of the different blood vessels: arteries, veins and capillaries
- Relate the functions of different blood vessels to their structures
- Define a pulse and locate a pulse point
- List examples of cardiovascular diseases such as stroke and heart attack
- Show an awareness of the different factors that contribute to cardiovascular diseases and the preventive measures
- Interpret data from graphs related to cardiovascular diseases

In Grade 7 and 8, you learnt about different organ systems in living organisms, such as the respiratory and digestive systems. In this unit, you will learn about the blood circulatory system, which is the main transport system in the human body. The main functions of the blood circulatory system are the transport of substances and protection of our body against diseases caused by germs.

## Blood Circulatory System

The human blood circulatory system consists of three main components, as shown in Figure 1.

In this image, we can see a diagram. In the diagram, we can see a person, a heart, a blood vessel, and a blood.

<!-- image -->

B 1

Unit

Unit

1

B1

You will now learn about each component of the blood circulatory system.

## The Heart

Figure 2: External structure of the human heart

<!-- image -->

The human heart, as shown in Figure 2, is a muscular organ which is approximately the size of a clenched fist. It pumps blood into blood vessels to all parts of the body.

Let's start with this simple activity to locate the position of the heart in the human body.

<!-- image -->

## ACTIVITY 1.1 Locating the position of the heart

By  following  the  instructions  and  answering  the  questions below, you will be able to locate the position of your heart.

1. Observe carefully your teacher who will show the chest region of the body.
2. Place one hand in the middle of your chest.
3. Then move slightly to the left until you feel a movement in your chest. This is the location of your heart.
1. Describe the type of movement you feel in your chest.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Draw the exact location of the heart in Figure 3.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Discuss and predict what are represented by the blue and red structures in Figure 3.

Blue: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Red:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 3: Blood circulatory system in human

In this image, we can see a person.

<!-- image -->

<!-- image -->

## WHAT I HAVE LEARNT

- The  heart is located in the middle of the chest, slightly leaned to the left.
- The heart pumps blood into blood vessels to all parts of the body.

## The Blood

You might have noticed a red fluid coming out of an open wound. This fluid is known as blood .

When blood is observed under a microscope, many different types of cells are seen in a liquid medium, known as plasma .

Figure 4 shows that blood consists of approximately 55% plasma, 41% red blood cells and 4% of white blood cells and platelets.

In this image, we can see two plates. On the left side, we can see a red color object. On the right side, we can see a white color object.

<!-- image -->

## Blood Plasma

Blood plasma is a pale yellowish liquid consisting mainly of water and dissolved substances such  as  glucose,  salts,  gases  (e.g.  oxygen),  proteins  and  waste  substances. These  dissolved substances are transported in the body.

## Blood cells and platelets

Blood  cells  and  platelets  make  up  about  45%  of  the  blood.  Red  blood  cells  are  the  most abundant (41%). There are also white blood cells and fragments of cells known as platelets .

U

n

i

t

U

n

i

t

## Red Blood Cells (RBCs)

Activities 1.2 and 1.3 will allow you to learn about the structure and function of red blood cells.

<!-- image -->

## ACTIVITY 1.2 Examining blood under a microscope

You will now observe human blood under a light microscope with the help of your teacher.

Describe your observation of the human blood smear, as seen under the microscope.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 5 shows how human blood appears under the light microscope and Figure 6 shows the enlarged image of a red blood cell.

In this image, we can see a picture of a cell. There are two arrows in the image.

<!-- image -->

<!-- image -->

## Guidelines for drawing:

1. Referring to Figure 6, draw a red blood cell in the space below. Make sure  that  your  diagram  is  larger  than  the  red  blood  cell labelled  in Figure 6.
1. Use a sharp pencil.
2. Draw clear continuous lines.
3. Do not shade your diagram.
4. Draw a diagram of appropriate size (usually two-third of given space).
5. Keep your diagram to the left of your page and use the right-hand side for labels.
6. Use a ruler for horizontal label lines (not arrows).
7. Draw proportional diagram.

2. Using a ruler, measure and record the diameter of your drawing across its widest part.

Diameter of a red blood cell in your drawing = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ mm

3. Measure and record the diameter of a red blood cell in Figure 6.

Diameter of a red blood cell in Figure 6 = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ mm

4. Given that magnification is  defined as the number of times that an image appears bigger  than  the  real  object,  calculate  the  magnification  of  your  drawing  using  the following formula.  Show your working.

Magnification of the drawing (RBC) =

Diameter of your drawing

Diameter of red blood cell in Figure 6

Magnification of the drawing = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 1.3 Exploring the structure and main function of red blood cells (RBCs)

From the previous activity, you have been able to recognise and draw a simple diagram of a red blood cell. In Activity 1.3, you will learn about the structure and the main function of red blood cells.

Figure 7 is a labelled diagram of a cross section of a RBC and Figure 8 is a labelled diagram of a typical animal cell.

<!-- image -->

Figure 7: Cross section of a red blood cell

<!-- image -->

Unit

Unit

1

B1

Observe the diagrams in Figures 7 and 8 to answer the following questions.

- (a)  Compare a red blood cell and a typical animal cell based on the features given in Table 1. Then fill the table accordingly.

Table 1: Comparison between a RBC and a typical animal cell

| Features      | Typical animal cell   | Red blood cell   |
|---------------|-----------------------|------------------|
| Shape of cell |                       |                  |
| Nucleus       |                       |                  |
| Haemoglobin   |                       |                  |

- (b)  By referring to Figures 7 and 8, state the features that are common to both cells.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  The red pigment (haemoglobin), found in RBCs, binds and carries oxygen throughout the body.
- On the basis of what you learnt in activities 1.2 and 1.3, suggest how the structure of a red blood cell is adapted to its main function of carrying oxygen around the body.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## WHAT I HAVE LEARNT

1. Blood consists of plasma, red blood cells, white blood cells and platelets.
2. Red blood cells have red pigment haemoglobin, which carries oxygen around the body.
3. RBCs are adapted to carry oxygen as follows:
- The cytoplasm has haemoglobin.
- There is no nucleus in RBCs and thus can accomodate more haemoglobin.
- RBCs have a flattened shape with biconcave sides that gives a large surface area, allowing oxygen to diffuse rapidly in and out.

## White Blood Cells (WBCs)

There are fewer white blood cells in the blood compared to red blood cells. They are also larger than  red blood cells and have a nucleus.

Figures 9 and 10 show two different types of WBCs.

Figure 9

<!-- image -->

<!-- image -->

Figure 10

White blood cells are the major components of the body's immune system. WBCs protect the body against diseases by killing pathogenic germs (very small organisms which cause diseases).

## How white blood cells kill germs?

- White blood cells as shown in Figure 9 engulf and digest germs such as bacteria and viruses which enter the body.
- WBCs as shown in Figure 10 produce antibodies which destroy or help in the destruction of germs.

<!-- image -->

Antibodies are proteins that can bind to foreign bodies (e.g bacteria and viruses) to destroy them.

## Platelets

You  have  studied  the  different  types  of  blood  cells  earlier  in  this  unit.  Platelets  are  small  cell fragments found in blood.

In Activity 1.4, you will learn about the importance of platelets in the body.

<!-- image -->

## ACTIVITY 1.4 Exploring the importance of platelets in the body

Read the extract below and answer the questions which follow.

Ronaldo  falls  while  playing  football  and  injures  his  knee. Blood oozes from his wound as shown in Figure 11. After some time, he notices that the bleeding has stopped, and a dark red clot has formed on the surface of the injury.

Figure 11: Ronaldo

<!-- image -->

What do you think will happen to Ronaldo if the bleeding is not stopped?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## What happened to Ronaldo can be explained as follows:

1. While playing, he fell on his knees and was injured.
2. The tiny blood vessels of the damaged skin broke open.
3. Blood started oozing from blood vessels causing bleeding.
4. Platelets gathered at the site of injury cause formation of blood clot.
5. The blood clot stopped the bleeding.

## Importance of blood clotting:

- It prevents excessive blood loss from the body when a blood vessel is damaged or breaks open.
- It also prevents entry of germs or microbes at the site of the wound.

<!-- image -->

## WHAT I HAVE LEARNT

1. White blood cells protect the body against foreign bodies such as germs by:
2. (i) engulfing and digesting the germs.
3. (ii)  producing antibodies that destroy or help to destroy germs.
2. Platelets help in blood clotting that stops blood loss and prevents entry of germs in case of injury.

Table 2 summarises the blood components and their respective function(s).

Table 2: Functions of blood components

| Blood components                       | Function(s)                                                          |
|----------------------------------------|----------------------------------------------------------------------|
| • Transports digested substances (e.g. | Plasma food urea) and                                                |
| •                                      | Red blood cells Have haemoglobin that in the body as oxy-haemoglobin |
| • •                                    | White blood cells Engulf and digest germs Produce antibodies which   |
| Platelets                              | • Help in blood clotting                                             |

## Blood Vessels

As we have seen earlier, blood is transported to all parts of our body through tube-like structures, known as blood vessels . There are three main types of blood vessels, namely (i) arteries , (ii) veins and (iii) capillaries .

All blood vessels form a continuous tubular system that transports blood throughout the body. Figure 12 shows how arteries divide to form tiny vessels known as capillaries which eventually join to form veins.

Figure 12: Blood Vessels

In this image we can see two fingers and a finger joint. On the fingers we can see the fingers are connected with a thread.

<!-- image -->

## Structure of blood vessels

Figures 13, 14 and 15 show sections through an artery, a vein and a capillary respectively.

In this image, we can see a diagram of a human body. We can also see a diagram of a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear, a human ear

<!-- image -->

<!-- image -->

Figure 15: A capillary

<!-- image -->

In Activity 1.5, you will differentiate between an artery, a vein and a capillary.

<!-- image -->

## ACTIVITY 1.5 Comparing the structure of the artery, vein and capillary

By referring to Figures 13, 14 and 15, compare and contrast the structures of the different blood vessels,  based  on  the  features  given  in Table  3  below. Then,  fill  in  the  table  with  appropriate word(s) or phrase, as shown in the example.

Table 3: Comparison of artery, vein and capillary

| Features                          | Artery       | Vein       | Capillary   |
|-----------------------------------|--------------|------------|-------------|
| Size of lumen                     | small/narrow | large/wide | very small  |
| Thickness of wall                 |              |            |             |
| Number of distinct layers of wall |              |            |             |

- (i) Write down one feature common to all the blood vessels.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)  Now complete the Venn diagram to show features that are:
- (1) common
- (2) different among the three types of blood vessels

The image is a diagram consisting of three distinct shapes, each represented by a different color. These shapes are arranged in a triangular formation, with the top shape being green, the middle shape being purple, and the bottom shape being orange. The colors of the shapes are not distinct, and they are arranged in a way that suggests a three-dimensional arrangement.

The image does not contain any text, numbers, or other visual elements, making it easy to understand the relationships between the shapes. The shapes are not connected to each other, and there are no labels or annotations indicating their positions or relationships.

### Analysis and Description:

#### Green Shape:
- **Color**: Green
- **Position**: Top-left
- **Relationship**: The top shape is green, and the middle shape is purple.
- **Position**: The top shape is positioned above the purple shape.
- **Relationship**: The top shape is connected to the purple shape by a straight

<!-- image -->

## Functions of blood vessels

Table 4 summarises the functions of the blood vessels.

Table 4

| Type of blood vessel   | Function              |
|------------------------|-----------------------|
| Artery                 | • away from • rich in |
| Veins                  | • towards • rich in   |
| Capillaries            | oxygen                |

<!-- image -->

DID YOU KNOW…

*   All arteries carry oxygenated blood except the pulmonary artery and all veins carry deoxygenated blood except, the pulmonary vein.

Unit

Unit

1

B1

## Adaptations of the structure of blood vessels to their functions

You have learnt about the different blood vessels, their structure and functions. Now, you will relate the structure of the blood vessels to their respective functions.

## Some features of artery related to its functions:

- -A small lumen maintains a high pressure of blood so that blood reaches all parts of the body.
- -A thick wall, consisting of muscle and elastic fibres, allows stretching and recoiling of arteries to maintain blood flow.
- -A thick wall accomodates blood with high pressure.

## Some features of vein related to its functions:

- -The wall is thinner and less muscular than arteries as veins carry blood at low pressure.
- -Valves, as shown in Figure 16, prevent backflow of blood in veins.
- -The large lumen allows  blood to flow under low pressure.
- -The thin wall allows the vessel to squeeze under the action of adjacent skeletal muscles so that local pressure is set in veins.

Figure 16: Role of valves in veins

In this image, we can see a diagram. There are two vertical lines. At the bottom, we can see a text.

<!-- image -->

## Features of capillary  related to its function

- -The one-cell thick wall of a capillary allows exchange of substances between blood and surrounding cells
- -There are small gaps between cells lining the capillary wall. This allows white blood cells to squeeze through these gaps from blood into infected tissues.

## Pulse

At the beginning of this unit, the heart was introduced as the organ of the circulatory system which pumps blood around the body. When the muscles of the heart contract, blood is pumped out of the heart into arteries to all organs of the body.

A heart beat occurs every time the muscles of the heart contract.

When blood is pumped into an artery, its wall stretches and recoils to maintain the flow of blood under high pressure. The stretching and recoiling of the artery walls is known as a pulse .

Each heart beat gives rise to a pulse.

<!-- image -->

## ACTIVITY 1.6 Locating a pulse

A pulse can be located at few specific sites in the body.

One is on the wrist, as shown in Figure 17. The pulse may be located by placing two fingers (index and middle fingers) at the base of the thumb in the region of the wrist. Then, press the two fingers slightly until a pulse is felt.

Another is at the side of the neck, just under the jaw as shown in Figure 18. The pulse is located by placing two fingers (index and middle fingers) under the angle of the jaw using very light pressure.

<!-- image -->

Figure 17

<!-- image -->

Figure 18

<!-- image -->

## WHAT I HAVE LEARNT

1. A pulse is the result of stretching and recoiling  of an artery every time the heart pumps blood in an artery.
2. A pulse may be felt at the wrist region or the neck region.

<!-- image -->

## Cardiovascular Diseases

We have discussed earlier in this unit about the components of the blood circulatory system. Now you will explore some common diseases related to the blood circulatory system.

A person's lifestyle may affect the proper functioning of both blood vessels and the heart. This can lead to cardiovascular diseases, which are non-communicable diseases.

Some common examples of cardiovascular diseases are:

## · Heart attack

If the artery which supplies blood to heart muscles is partially blocked as shown in Figure 20, it will decrease supply of oxygen and nutrients to heart muscles. This may lead to a heart attack.

## · Stroke

If an artery supplying nutrients and oxygen to the brain is blocked, it may lead to a stroke. This may cause paralysis of parts or whole body.

<!-- image -->

<!-- image -->

Figure 19: Healthy artery

<!-- image -->

## Hypertension

This is a condition when blood pressure increases above the normal range. It can damage the lining of blood vessels.

Figure 20: Blocked artery

## Factors contributing to cardiovascular diseases

In Grade 8, you learnt about some factors that contribute to cardiovascular diseases. The main causes of cardiovascular diseases and the preventive measures are summarised in Table 5.

Table 5

| Cause of Cardiovascular diseases                   | Explanation                                                                            | Preventive measures                                       |
|----------------------------------------------------|----------------------------------------------------------------------------------------|-----------------------------------------------------------|
| 1. High intake of salt in diet                     | • Salts cause hypertension which damages the lining of blood vessels.                  | • Reduce salt in the diet                                 |
| 2. Diet with excess saturated fats and cholesterol | • Fatty deposits block the arteries as shown in Figure 20.                             | • Reduce saturated fats including cholesterol in the diet |
| 3. Obesity                                         | • It puts strain on the heart.                                                         | • Eat healthy diet • Exercise regularly                   |
| 4. Lack of exercise                                | • The heart muscles lose its tone and becomes less efficient in pumping blood.         | • Exercise regularly                                      |
| 5. Smoking cigarettes                              | • Nicotine damages the heart and the arteries.                                         | • Stop cigarette smoking                                  |
| 6. Stress                                          | • It tends to increase the blood pressure that may damage the lining of blood vessels. | • Avoid the causes of stress                              |

<!-- image -->

Blood  donation,  which  has  become  an  important  event  in  several  educational  institutions including MIE, can save lives of people as blood is essential to help patients survive surgeries, cancer treatment, chronic illnesses, and traumatic injuries.

<!-- image -->

Figure 21 shows the number of deaths caused by heart attack in men and women per 100,000 people in a given population.

Figure 21: Variation in the number of deaths by heart attack over time

The image is a line graph. The graph is titled "Men" and is labeled as "Women" in the legend at the bottom right corner. The x-axis is labeled "Number of deaths per 100,000 people" and the y-axis is labeled "Number of deaths per 100,000 people". The graph shows a linear trend with a slight increase in the number of deaths per 100,000 people from 1924 to 1930. The graph then shows a sharp decrease in the number of deaths per 100,000 people from 1930 to 1940. The graph then shows a slight increase in the number of deaths per 100,000 people from 1940 to 1950. The graph then shows a sharp decrease in the number of deaths per 100,0

<!-- image -->

Observe the graphs carefully and then answer the following questions.

- (a)  (i)    What happened to the number of deaths between 1924 and 1936 in both men and women?

Men:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Women:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)    Suggest two reasons to explain your observation in part (a)(i).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  (i)    Which group (men or women) had the highest number of death due to heart attack?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)    Suggest two reasons to explain your answer in part (b)(i).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(c)(i) Referring to Figure 21, identify the number of deaths in men in the year:

1972: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

1987: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)    Using the answers of part (c)(i), calculate the percentage change in death from year 1972 to 1987. Show your working.

- (iii)    Suggest two reasons for the decrease in death from 1972 to 1987.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## WHAT I HAVE LEARNT

1. Cardiovascular diseases are diseases that affect the proper functioning of the heart and the blood vessels (mainly arteries).
2. Two examples of cardiovascular diseases are heart attack and stroke.
3. The main factors that contribute to cardiovascular diseases are unhealthy diets, obesity, lack of exercise, smoking cigarettes and stress.

## Summary of unit

1. The human blood circulatory system consists of the blood, the blood vessels and the heart, where the heart pumps blood into blood vessels to all parts of the body.
2. Blood is composed of liquid plasma, red blood cells, white blood cells and platelets.
- Plasma consisting of water and dissolved substances, is involved in the transport of substances in the body.
- Red blood cells carry oxygen throughout the body.
- White blood cells protect the body against diseases caused by germs.
- Platelets are small fragments of blood cells that help in blood clotting.
3. The 3 main types of blood vessels are the artery, capillary and vein.
- Arteries carry oxygenated blood away from the heart, under high pressure.
- Veins carry deoxygenated blood away from tissues back to the heart, under low pressure.
- Capillaries allow exchange of materials between blood and adjacent tissues.
4. A pulse, caused by stretching and recoiling of the artery wall, may be felt at the wrist or neck region.
5. Cardiovascular diseases are the diseases of the heart and/ or blood vessels. Common examples of cardiovascular diseases are heart attack and stroke.
6. Cardiovascular diseases have been associated with various casual factors, such as: diet with high  level  of  salts  and  saturated  fats  (including  cholesterol),  smoking  cigarettes,  lack  of physical activity and stress.
7. Some preventive measures of cardiovascular diseases are: choosing a healthy lifestyle in order to reduce stress, avoid smoking cigarettes, reducing intake of fats/cholesterol and salt in diet and regular exercise.

In this image, we can see a diagram, which is in the shape of a tree.

<!-- image -->

## 1. Match each term in Column A with its function in Column B .

## Column A

## Column B

Blood

carry blood away from the heart

Heart

pumps blood

Arteries

connect arteries and veins

Veins

transports materials around the body

Capillaries

carry blood back to the heart

2. Read carefully and state whether each statement is true or false .

- (a)  Blood is a red liquid which flows in blood vessels. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Blood is made of plasma and cells only. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Blood plasma represents about 45 % of the blood. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  The solid components of blood comprise red blood cells and platelets only. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Red blood cells are more numerous than white blood cells in the human blood. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f )  There is a large central nucleus in mature red blood cells. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (g)  Haemoglobin carries oxygen in red blood cells. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (h)  White blood cells recognise and kill germs. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (i) Antibodies are produced by red blood cells to kill germs. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (j) Platelets help in blood clotting. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Fill each blank with the appropriate term given below.

## heart,  arteries,  veins,  nutrients,  carbon dioxide,  capillaries,  high,  away,  pumps

- (a)  Veins carry  blood \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ from other organs back to the heart.

- (b)  Blood  flows under \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ pressure in arteries.

(c)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ leaves blood in capillaries to enter cells of adjacent tissues.

- (d)  The \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ , blood vessels and blood make up the blood circulatory system.

- (e)  Blood vessels that carry blood away from the heart are called \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

- (f ) The blood flowing in veins is rich in \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

- (g)  Blood moves from arteries to veins through tiny blood vessels known as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

(h)  Heart \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ blood throughout the body.

- (i) Arteries branch off to form network of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (j) Blood flows away from the heart in \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

4. Fill in the blanks by choosing the appropriate term from the list below.

## valves,    wrist,    glucose,    cells,    ingest,    blood clotting,    exchange

- (a)  Food substances such as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and amino acids are carried in the blood.

- (b)  White blood cells can \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ germs and digest them.

- (c)  Platelets are important in \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (d)  Capillaries are tiny vessels consisting of a single layer of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ allowing

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ of substances between blood and adjacent tissues.

- (e)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ in veins allow blood to flow in one direction only.

- (f )  A pulse can be felt at the base of the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

5. Circle the correct answer.

- (a)  Which of the following is a yellowish solution making about 55 % of blood?

- A. Cytoplasm

- B. Water

C. Plasma

- D. Glucose

- (b)  Blood leaves the heart under \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ through the arteries.

- A. Very low pressure

- B. Low pressure

- C. High pressure

- D. No pressure

- (c)  The red pigment found in red blood cells is known as

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

.

- A. Haemoglobin

- B. Chlorophyll

C. Antibody

- D. Iron

- (d)  Which of the following is involved in the destruction of germs?

- A. Red blood cells

- B. Plasma

- C. White blood cells

- D. Platelets

- (e)  Which of the following statements is true about the type of blood carried in arteries?

- A. Blood rich in oxygen under high pressure

- B. Blood rich in carbon dioxide under high pressure

- C. Blood rich in oxygen under low pressure

- D. Blood rich in carbon dioxide under low pressure

- (f )  Which of the following statements is true about the heart?

- A. It is a muscular organ pumping blood.

- B. It is a hollow organ without any muscle tissue.

- C. It is an organ that does not have right and left sides.

- D. It is an organ that has no connections with any blood vessels.

- (g)  Which of the following statements is true about blood vessels?
- A. The diameter of the lumen of an artery is bigger than that of a vein.
- B. The diameter of the lumen of a vein is bigger than that of an artery.
- C. The diameter of capillaries is the largest compared to arteries.
- D. The diameter of a lumen of capillary is larger than that of a vein.
- (h)  Cardiovascular diseases are the result of:
- A. Regular exercise
- B. Diet rich in salts and fats
- C. A healthy diet
- D. Stress-free lifestyle
6. Figure 1(a) is a section through an artery and Figure 1(b) through a vein.
- (a)  Label the parts A- E.

Figure  1(a)

<!-- image -->

<!-- image -->

A \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

B \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

C \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

D \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

E \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  State two differences in structure between an artery and a vein.

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  State how arteries and veins differ in their functions.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Explain briefly how the structure of an artery helps in its function.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure  1(b)

- (e)  Name a structure present in veins but not visible in Figure 1(b). State one function of the structure.

Structure: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Function: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7. (a) What is the term used for non-communicable diseases related to the blood circulatory system.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Give two examples of the disease you mentioned in part (a).

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) List two factors that contribute to the disease given in part (a).

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  How can you prevent the disease stated in part (a)?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  If an artery supplying blood to the muscles of the heart is partially blocked, how can it affect the functioning of the heart?

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

8. (a) Define a pulse.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Name two areas where you can locate a pulse in your body.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) How is a pulse related to a heart beat?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

9. Figure 2 shows a sample of blood as seen under the microscope. Observe carefully and answer the following questions.
2. (a)  Which of the cells A, B or C is the red blood cell?

Figure 2: Blood Smear

In this image we can see a diagram.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Give two reasons to support your answer in part (a).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  State two functions of white blood cells in our body.

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Suggest when the number of white blood cells may increase beyond normal amount in the blood.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  When blood capillaries are damaged, platelets become active causing the formation of blood clot.  Give  two reasons why blood clotting is important.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f )  On Figure 2, indicate the blood plasma using the letter D.

In this image there is a diagram of a human heart.

<!-- image -->

- (g)  Name three substances present in blood plasma.

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (h)  Name another component of blood not shown in Figure 2 and state its function.

Blood component: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Function: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

10. Figure 3 shows part of the circulatory system.

- (a)  Name the structures A, B and C on Figure 3.

- (b)  How does blood circulation in structure A differ from C?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  (i) State the function of structure B.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) How is structure B adapted to its function?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  How does structure A  allow blood to flow in one direction only?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 3

A

B

C

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Blood coming

from heart

Blood going to

the heart

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Explain why the blood in structure C is under high pressure when it leaves the heart.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

11. Coronary heart disease develops when the coronary artery , shown in Figure 4, is blocked by fatty materials. The coronary artery supplies blood to the heart muscles.
2. (a) Give two ways in which the heart is affected when fats are deposited on the inner wall of coronary artery.
3. (b) Table 2 shows the percentage of people who died of coronary heart disease from 2012 to 2020 in Mauritius and Rodrigues.

Figure 4: External structure of the heart

In this image we can see a heart.

<!-- image -->

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 5 shows a line graph of percentage death caused by coronary heart disease in Mauritius.

| Year   | Percentage death caused by coronary heart disease in   | Percentage death caused by coronary heart disease in   |
|--------|--------------------------------------------------------|--------------------------------------------------------|
|        | Mauritius                                              | Rodrigues                                              |
| 2012   | 19.1                                                   | 12.7                                                   |
| 2014   | 19.8                                                   | 16.9                                                   |
| 2016   | 11.5                                                   | 15.4                                                   |
| 2018   | 16.1                                                   | 11.9                                                   |
| 2020   | 11.5                                                   | 12.1                                                   |

Figure 5: Death rate related to coronary diseases in Mauritius and Rodrigues

The image is a line graph that shows the percentage of people who have been diagnosed with a particular disease over a period of time. The graph is titled "Mauritius" and is sourced from a source that provides data on the percentage of people diagnosed with a particular disease in Mauritius.

The graph is titled "Mauritius" and is sourced from a source that provides data on the percentage of people diagnosed with a particular disease in Mauritius. The graph is titled "2012" and is sourced from a source that provides data on the percentage of people diagnosed with a particular disease in Mauritius.

The graph is labeled "2012" and is sourced from a source that provides data on the percentage of people diagnosed with a particular disease in Mauritius. The graph is labeled "2014" and is sourced from a source that provides data on the percentage of people diagnosed with a particular disease in Mauritius.

The graph is labeled "

<!-- image -->

- (i) Fill in the blank space to label the Y axis on Figure 5.
- (ii) Using the information given in Table 2, complete Figure 5 by drawing a line graph showing the changes in death rate in Rodrigues.
- (c) (i) Calculate the percentage increase in death from year 2012 to 2014 in:

Mauritius.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Rodrigues

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Suggest two reasons that could have caused the increase in death rate by coronary heart diseases in both islands.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

1

Blood Circulatory System

B1

- (d) Explain the change in percentage death from 2018 to 2020 in Mauritius.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

28

Reproduction

Unit

Unit

Unit

B2

1

Food and Nu rients

2

Unit

## Reproduction

## Learning Outcomes

## At the end of this unit, you should be able to:

- Define reproduction as the process of producing new individuals of the same kind or species
- State the importance of reproduction in living things
- Distinguish between the two modes of reproduction: sexual and asexual
- Identify, label and give the main function of the different parts of the male and female reproductive systems in man
- Define sexually transmitted diseases (STDs) as diseases that are spread from an infected to uninfected individual, through sexual contact
- List examples of sexually transmitted diseases such as HIV/AIDS and syphilis
- Interpret data from graphs related to sexually transmitted diseases

In Grade 7, you learnt about a few characteristics of living things. For example, living things grow, move, feed, respire and excrete. Another characteristic of all living things is the ability to reproduce.

Each and every organism can live only for a certain period of time. It may ultimately die of old age, diseases, in accidents or killed for food by other organisms. To ensure the continuity of various organisms on earth, new organisms must be produced. This process is called reproduction .

The pictures below show examples of the parents and their respective offspring(s) /young(s).

Giant Panda

In this image we can see a panda and a baby bear. There is a tree in the background.

<!-- image -->

Mauritian Kestrel

<!-- image -->

B 2

## Reproduction is the production of new individuals of the same

## kind or of the same species.

<!-- image -->

## DICTIONARY CORNER

1.   A species is a group of living organisms which can reproduce among themselves producing fertile offspring(s).
2. Offspring is the young born of living organisms.

Now that you are aware that all organisms reproduce, suggest what may happen if organisms stop reproducing.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 2.1 - Identifying Ways of Reproducing

Through Activity 2.1, you will learn that organisms reproduce in different ways. The  pictures  show  different  species.  Observe  and  predict  how  these  organisms  reproduce. The first example is done for you.

<!-- image -->

Dogs reproduce by giving birth.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Types of Reproduction

The two main types of reproduction through which organisms produce new individuals are:

- (a) Asexual reproduction
- (b) Sexual reproduction

## Asexual reproduction

Asexual reproduction takes place in organisms such as bacteria, fungi (e.g. yeast) and amoeba.

Some plants can also carry out asexual reproduction.

Activities 2.2 and 2.3 will help you explore the process of asexual reproduction.

<!-- image -->

## ACTIVITY 2.2 - Exploring Asexual Reproduction in Amoeba

Figure 1 represents the process of asexual reproduction in amoeba.

Amoeba is a unicellular organism usually found in water bodies such as ponds.

Figure 1: Asexual reproduction in amoeba

In this image there are 4 different types of cells.

<!-- image -->

Study Figure 1 carefully and answer the questions below.

- (a) State the number of parent cell(s) involved to produce new organisms.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Are the new organisms identical to the parent?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Are the new organisms identical to each other?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

1

B2

<!-- image -->

## ACTIVITY 2.3 - Observing Asexual Reproduction in Yeast

Your teacher will show you a slide of living yeast cells under the microscope.

Yeast, sugar, microscope, microscope slide, coverslip, dropper,

Materials needed: thermometer.

## Procedure used in preparing the slide:

1. Pour 125 cm 3  of warm water of approximately 30-35 o C into a beaker.
2. Then add 5 g of sugar and 5 g of yeast into the beaker and mix the content.
3. Using a dropper, transfer a drop of the mixture on a clean microscope slide and place a coverslip over the drop.
4. Observe the mixture under the high power of a microscope.

Figure 2 shows how the yeast cells appear under the high power of a microscope immediately after preparing the slide.

Figure 3 shows the yeast cells one hour later.

In this image, we can see a cell with a cell membrane and a cell wall. We can also see a cell with a nucleus. We can see a cell with a nucleus and a cell membrane. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell membrane. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see a cell with a nucleus and a cell wall. We can see

<!-- image -->

Refer to Figures 2 and 3 to answer the following questions.

- (a) Fill the table below with
- The total number of yeast cells, irrespective of difference in size.
- A description of how the yeast cells appear.

Table 1

|                            | Figure 2   | Figure 3   |
|----------------------------|------------|------------|
| Number of yeast cells      |            |            |
| Description of yeast cells |            |            |

- (b) Based on the observations recorded in Table 1, describe briefly how yeasts carry out asexual reproduction.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Watch the Video on asexual reproduction in yeast https://www.youtube.com/watch?v=GFEgB\_ytDZY

## Asexual Reproduction in Plants

Asexual reproduction in plants occurs when a part of the plant such as the root, stem or leaf (but not seed) grows into a new plant.

One example is the strawberry plant as shown in Figure 4. The parent plant produces runners which extend out of the soil. In contact with soil, a new plant is formed at the end of each runner. The new plant is genetically identical to the parent plant.

Figure 4: Strawberry plants reproducing asexually

In this image, we can see plants and there is a text.

<!-- image -->

Another example of a plant that reproduces by asexual reproduction is the potato plant. In the following activity, we will investigate asexual reproduction in potato plant.

<!-- image -->

<!-- image -->

## ACTIVITY 2.4 - Investigating Asexual Reproduction in Potato Plant

You can work in groups for this experiment.

Materials needed: Fresh and sprouted potatoes, magnifying lens, tile, scalpel, water and a pot with potting soil .

## Instructions:

1. Using a magnifying glass, observe the scars or 'eyes' found on the fresh potato. Describe your observation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- 2.
- Observe the sprouted potato and record your observation. Figure 5 shows an example of a sprouted potato.

In this image we can see a potato.

<!-- image -->

## DICTIONARY CORNER

Tuber: a swollen underground stem

Figure 5: Potato tuber with sprouts

Observation:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Cut the sprouted potato into several portions. Make sure that each potato piece has at least one sprout.
4. Transfer the potato pieces in a pot of soil and water the pot regularly for few days.
5. Observe and record your findings on a daily basis. Describe your observations.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Give two reasons to justify that potato plants reproduce by asexual reproduction.

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## WHAT I HAVE LEARNT

1. A single parent is involved in asexual reproduction.
2. There are different types of asexual reproduction. For example:
- An amoeba divides equally to form two new individuals.
- A parent yeast cell gives rise to small buds that eventually separate and mature into new yeast cells.
- Strawberry plants can reproduce asexually using runners.
- Potato plants reproduce asexually using tubers (stem swellings). A potato tuber has many 'eyes' which form sprouts. Each sprout may then develop into a new plant which is genetically identical to the parent plant.
3. Offsprings produced during asexual reproduction are genetically identical to each other and to the parent.

## DICTIONARY CORNER

Genetically identical means having the same genes and hence the same features.

Unit

Unit

1

B2

## Sexual Reproduction

Now  that  you  understand  the  process  of  asexual  reproduction,  let  us  learn  about  sexual reproduction.

Figure 6 shows a cat family.

In this image there are cats sitting on the floor.

<!-- image -->

Study Figure 6 carefully and answer the following questions.

- (a)  How many parents do you see in Figure 6?   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (b)  Are the offsprings identical to each other?   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (c)  Are the offsprings identical to their parents?   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (d)  Suggest the type of reproduction involved in mammals such as cats.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Two parents are involved in sexual reproduction and offspring(s) produced are neither identical to the parents nor to each other.

<!-- image -->

## WHAT I HAVE LEARNT

1. Two parents are involved in sexual reproduction.
2. Offsprings produced during sexual reproduction are neither genetically identical to the parents nor to each other.

<!-- image -->

## ACTIVITY 2.5 - Comparing Sexual and Asexual Reproduction

Based on what you have learnt earlier in this chapter, complete Table 2 to compare and contrast between asexual and sexual reproduction.

Table 2

|                                                      | Asexual   | Sexual   |
|------------------------------------------------------|-----------|----------|
| Numberofparent(s)involved                            |           |          |
| Are new organisms formed identical to each other?    |           |          |
| Are new organisms formed identical to their parents? |           |          |

## Sexual Reproduction in Humans

The two main stages of sexual reproduction in humans are gamete formation and fertilisation.

## Gamete formation

Gametes are  specialised  sex  cells  produced  by  the  male  and  female  reproductive  systems. Testes  are  the  male  reproductive  organs  which  produce  the  male  sex  cells.  Ovaries  are  the female organs in which the female sex cells are produced. The male sex cells are called sperms and the female sex cells are called eggs or ova (singular: ovum).

You will learn about the reproductive systems in Activities 2.6 and 2.7.

## Fertilisation

During sexual intercourse, the male gametes are released into the female reproductive tract.  A sperm cell then fuses with an egg/ovum by the process of fertilisation producing a fertilised egg called a zygote . The zygote then develops into an embryo which eventually develops into a foetus, as shown in Figure 7.

Figure 7: Sexual reproduction in humans

In this image, we can see a diagram of a human body. There are two persons in the image. We can see the text on the image.

<!-- image -->

WHAT I HAVE LEARNT

Sexual reproduction involves the production and fusion of sex cells called gametes.

<!-- image -->

## The Human Reproductive Systems

In the previous section, you have learnt that in sexual reproduction, gametes are required to form new individuals. Activities 2.6 and 2.7 will help you identify the organs that are responsible for the production of gametes and other related organs that form part of the reproductive systems.

## The Male Reproductive System

<!-- image -->

## ACTIVITY 2.6 - Identifying the parts of the male reproductive system

Figure 8 shows the front view of the male reproductive system. The function of each part of the system is summarised in the same diagram.

Figure 8: Front view of the male reproductive system

In this image there are two persons standing. In the background there is a wall.

<!-- image -->

Study Figure 8 carefully and answer the following questions.

- (a)  Name the organ that produces the male gametes.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Name two other organs that form part of the male reproductive system.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

DID YOU KNOW…

During sexual intercourse, an adult male releases about 250 million sperms.

Unit

Unit

B2

1

- (c)  Figure 9 shows the side view of the male reproductive system. Refer to Figure 8 to label the structures by filling the blank boxes.

Figure 9: Side view of the male reproductive system

The image is a diagram of an anatomical structure called the urinary bladder. This structure is a part of the urinary system and is located in the pelvis. The urinary bladder is a soft, tubular organ that stores urine. It is connected to the kidneys and is responsible for storing and releasing urine. The urinary bladder is attached to the pelvis, which is a muscular structure that supports the pelvis.

The urinary bladder is depicted as a small, round structure with a smooth, slightly curved surface. It has two small, round openings at the top called the urethra, which is a tube that carries urine out of the bladder. The urinary bladder is connected to the kidneys, which are located on either side of the spine. The kidneys are bean-shaped organs that filter waste and excess water from the blood. The urinary bladder is connected to the kidneys by a tube called the ureter, which carries urine from the bladder to the kidneys.

The urinary bladder is a part of the urinary system and is

<!-- image -->

## The Female Reproductive System

<!-- image -->

## ACTIVITY 2.7 - Identifying the parts of the female reproductive system

Figure 10 shows the front view of the female reproductive system with the functions of the different parts.

In this image I can see a girl and a boy. I can see the text on the image.

<!-- image -->

Figure 10: Front view of the female reproductive system

<!-- image -->

Foetus is an unborn baby of a mammal.

Unit

Unit

1

B2

Observe Figure 10 carefully and answer the following questions.

- (a)  Name the organ that produces the female gametes.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Name two other organs that form part of the female reproductive system.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Figure 11 shows the side view of the female reproductive system. Refer to Figure 10 to label the structures by filling the blank boxes.

In this image we can see a human body.

<!-- image -->

Figure 11: Side view of the female reproductive system

<!-- image -->

Girls  are  born  with  approximately  one  million  immature  egg  cells  in  each  ovary, but very few reach maturity. Each cell is about 20 times larger than a sperm.

<!-- image -->

## WHAT I HAVE LEARNT

- Sperm is the male gamete and egg/ovum is the female gamete.
- Male gametes are produced in testes and female gametes in the ovary.
- The male reproductive system consists of testes, sperm duct, seminal vesicles, prostate gland, urethra and penis.
- The female reproductive system consists of ovary, oviduct, uterus, cervix and vagina.

## Sexually Transmitted Diseases (STDs)

In  Grade  8,  you  learnt  about  diseases.  Some  are  communicable  and  others  are  noncommunicable. Use your knowledge acquired in Grade 8 to answer these questions:

- (a)  Distinguish between communicable and non-communicable diseases.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Give three examples of

- (i) Communicable diseases: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Non-communicable diseases:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Name the germs responsible for causing the diseases mentioned in part (b)(i).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Some of the existing communicable diseases are also classified as sexually transmitted diseases  (STDs).  Infectious  diseases  that  are  transmitted  through  sexual  contacts  are called sexually transmitted diseases. Some examples of STDs are HIV/AIDS, syphilis and gonorrhea.

## FURTHER READING

## AIDS

AIDS stands for Acquired Immune Deficiency Syndrome. It is caused by HIV (Human immunodeficiency  Virus) which attacks specific white blood cells in the human body. Consequently, the immune (defense) system becomes weak and is unable to fight other  diseases,  termed  opportunistic  diseases,  caused  by  other  microorganisms. Though an infected person does not show signs and symptoms during the first stage of the infection, they can still transmit the virus to another person.

There is no vaccine available against HIV/AIDS and no known cure so far.

## How is HIV/AIDS transmitted?

-  Through sexual contact with an infected person
-  Through contaminated needles used for ear piercing and tattooing

-  Sharing of contaminated needles among drug users
-  Transfusion of infected blood
-  From infected mother to baby

## How can HIV/AIDS be prevented?

-  Use condom during sexual intercourse
-  Avoid sexual intercourse with several partners
-  Do not use contaminated needles
-  Educate the public about HIV/AIDS transmission and prevention

<!-- image -->

## ACTIVITY 2.8 - Interpreting data on HIV/AIDS

According to UNAIDS, approximately 38.4 million people worldwide were living with HIV/AIDS in 2021. The causative agent is a virus termed HIV.

The annual number of HIV/AIDS cases reported in the Republic of Mauritius among Mauritians aged 15 - 24 for the period of 2009 to 2017 is given in Table 3.

Table 3

|   Year of detection |   Number of cases of HIV/AIDs in the age group 15-24 |
|---------------------|------------------------------------------------------|
|                2009 |                                                   86 |
|                2011 |                                                   59 |
|                2013 |                                                   55 |
|                2015 |                                                   51 |
|                2017 |                                                   80 |

## Study the table carefully and answer the following questions.

- (a)  Using the data given in Table 3, plot a line graph on the grid provided as Figure 12.
- (b)  Describe the trend of reported HIV/ AIDS cases in Mauritius from the year 2009 to 2017.

The image is a line graph titled "Number of HIV/AIDS cases of HIV/AIDS." The x-axis represents the years from 2009 to 2019, while the y-axis shows the number of HIV/AIDS cases. The graph has a linear scale of range 0 to 90 on the x-axis, and the linear scale of range 0 to 90 on the y-axis, with a minimum of 0 and a maximum of 90.

The graph has a title at the top, which reads "Number of HIV/AIDS cases of HIV/AIDS." The title is in a bold, capitalized font, and the x-axis label is in a smaller, italicized font. The y-axis label is in a bold, capitalized font, and the range of the y-axis is also in a bold, capitalized font.

There are two data points on the graph. The

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Table 3 and Figure 12 show that for a particular year, the number of infected cases was low. It has been reported that this was due to appropriate preventive measures taken at national level.
- (i) State the year that recorded the lowest number of HIV/AIDS cases.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Suggest two preventive measures that may have contributed to the low number of infected cases.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

B2

1

Unit

Unit

1

B2

<!-- image -->

## WHAT I HAVE LEARNT

- Sexually transmitted diseases (STDs) are diseases that are transmitted during sexual contact.
- Some examples of STDs include HIV/ AIDS, syphilis and gonorrhea.
- STDs are caused by microorganisms such as viruses, bacteria and fungi. Syphilis is caused by a particular type of bacteria while AIDS is caused by a virus called HIV.
- Some preventive measures regarding spread of HIV/ AIDS are:-
- a) Use protection (e.g. condom) during sexual intercourse
- b) Avoid multiple sex partners
- c) Increase awareness through sex education at school

## Summary of unit

1. Reproduction is the process of producing new individuals of the same kind or species.
2. Reproduction helps in the continuity of the species so that it does not become extinct.
3. There are two main types of reproduction: asexual and sexual.
- In asexual reproduction, a single parent is involved in producing genetically identical offspring(s). There is no fusion of gametes.
- In sexual reproduction, male and female parents are involved in producing genetically dissimilar offsprings. There is fusion of gametes.
4. The testes and the ovaries are the reproductive organs involved in producing male and female gametes respectively.
5. Male and female gametes fuse to form a zygote through the process of fertilisation. The zygote eventually develops into a new individual.
6. Sexually transmitted diseases (STDs) are diseases that are spread from an infected to a noninfected individuals through sexual contact. STDs are caused by microorganisms.
7. Some examples of STDs are HIV/AIDS, syphilis and gonorrhea.

In this image, we can see a chart.

<!-- image -->

## Multiple choice questions

- 1.
- Sperms are produced in the\_\_\_\_\_\_\_\_\_\_\_\_ .
- A. Penis
- B. Testis
- C. Sperm duct
- D. Urethra
2. The diagram shows the side view of the female reproductive system.

In this image, we can see a diagram of a human ear.

<!-- image -->

Which of the following correctly identify the parts of 1, 2, 3 and 4?

|    | 1       | 2       | 3      | 4      |
|----|---------|---------|--------|--------|
| A  | Ovary   | Oviduct | Vagina | Uterus |
| B  | Ovary   | Oviduct | Uterus | Vagina |
| C  | Oviduct | Ovary   | Uterus | Vagina |
| D  | Oviduct | Ovary   | Vagina | Uterus |

3. What is a gamete?
- A. A male or a female sex cell
- B. A baby
- C. The lining of the oviduct
- D. The testis

4. Which of the following is not part of the female reproductive system?
- A. Ovary
- B. Vagina
- C. Sperm duct
- D. Uterus
5. The organ which produces the female gametes is the \_\_\_\_\_\_\_\_\_\_\_\_
- A. Vagina
- B. Ovary
- C. Uterus
- D. Oviduct
6. The female sex cell is known as the \_\_\_\_\_\_\_\_\_\_\_
- A. Ovum
- B. Sperm
- C. Ovary
7. AIDS is best prevented by \_\_\_\_\_\_\_\_\_\_\_\_
- A. Regular exercise
- B. Healthy food
- C. Safe and responsible sexual behaviour
- D. Drinking a lot of water
8. Which statement is true of asexual reproduction?
- A. Two types of gametes are produced
- B. Two parents are required
- C. New organisms are identical to each other
- D. New organisms are different from each other
9. The diagram shows spider plantlets.

Spider Plantlet

In this image we can see a plant pot. In the background there is a blue color.

<!-- image -->

State the type of reproduction shown by the plant and the number of parents needed.

|    | Types of reproduction   |   Number of parent(s) |
|----|-------------------------|-----------------------|
| A  | asexual                 |                     1 |
| B  | asexual                 |                     2 |
| C  | sexual                  |                     1 |
| D  | sexual                  |                     2 |

- D. Uterus

10. Which of the following example is a sexually transmitted disease?
- A. Syphilis
- B. Lung cancer
- C. Fever
5. D Diabetes

## Section B

1. Figure 1 shows the male reproductive system.
2. (a)  Label the parts A to F on Figure 1.
3. (b)  Name the structure that produces sperms.

In this image, we can see a diagram.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. (a)  State two differences between asexual and sexual reproduction.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Give 2 examples of organisms that reproduce asexually.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Write down whether the following statements are True or False .
- a) Syphilis is an example of sexually transmitted disease. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- b) Testes are organs found in the female reproductive system. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- c) Ovary, oviduct, uterus, cervix and vagina form parts of the female reproductive system.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- d)  Asexual reproduction involves only one parent. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- e) Sperm is a motile cell. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
4. Figure 2 shows the female reproductive system. Use the words provided to label the different parts on the diagram.

cervix            ovary            vagina            uterus            oviduct

<!-- image -->

5. Match column A with the appropriate description in column B .
6. Put a tick [        ] or a cross [        ] in each box to show the mode of reproduction of the different organisms given in the table below. An example has been done for you.

| ColumnA              | Column B                                                                |
|----------------------|-------------------------------------------------------------------------|
| Ovary                | the organs which produce sperms in males                                |
| Asexual reproduction | specialised cell for reproduction which can either be an egg or a sperm |
| Gamete               | the organ which produces eggs in females                                |
| Sexual reproduction  | the formation of a new individuals from a single organism               |
| Testes               | formation of new individuals involving parents of different sexes       |

| Organisms    | Mode of Reproduction   | Mode of Reproduction   |
|--------------|------------------------|------------------------|
|              | Asexual                | Sexual                 |
| Humans       |                        |                        |
| Yeast        |                        |                        |
| Spider Plant |                        |                        |
| Dog          |                        |                        |
| Amoeba       |                        |                        |
| Pink pigeon  |                        |                        |

<!-- image -->

7. (a) Figure 3 shows a sprouting potato tuber. Each sprout can develop into a new plant.
2. (i) State the mode of reproduction used by potato.

Figure 3

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)  Referring to Figure 3, give one reason for your answer of (a) (i).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  (i) Make a large drawing of the potato shown in Figure 3. Label one 'eye' .
- (ii)  Measure, in millimetres, the width of the potato tuber in your drawing.

Width of potato tuber drawn = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ mm

- (iii) Measure, in millimetres, the width of the potato tuber in Figure 3.

Width of potato tuber in Figure 3 = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ mm

(iv) Calculate the magnification of your drawing as compared to the potato tuber in Figure 3. Show your working.

Magnification of drawing = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

8. Table 1 shows the number of reported cases of sexually transmitted diseases in Mauritius in the year 2010 and 2016.
2. (a)  What is a sexually transmitted disease?

Table 1

|                               |   Year |   Year |
|-------------------------------|--------|--------|
| Sexually transmitted diseases |   2010 |   2016 |
| Syphilis                      |    132 |   1087 |
| Gonorrhea                     |      5 |     56 |

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Name another example of STDs .

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Draw a bar chart to represent the number of cases of syphilis and gonorrhea for the year 2010 and 2016.
- (d)  Use the data from Table 1 to calculate the increase in the number of syphilis cases from year 2010 to 2016.

The image is a bar graph titled "Number of cases." The graph is divided into two sections: the upper section and the lower section. The upper section is labeled "2010" and the lower section is labeled "2016."

### Description of the Graph:
- **Title:** The title of the graph is "Number of cases."
- **X-Axis:** The X-axis is labeled "Number of cases" and ranges from 0 to 1000.
- **Y-Axis:** The Y-axis is labeled "Number of cases" and ranges from 0 to 1000.
- **Data Points:** There are two data points on the graph. The first data point is located at the value of 0 and the second data point is at the value of 1000.
- **Legend:** The legend at the bottom of the graph is labeled "Number of cases" and

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Suggest one reason for the increase in the number of syphilis cases in the year 2016 among youngsters.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

1

B2

In this image we can see a fish, plants, rocks, water and the sky.

<!-- image -->

- Demonstrate simple understanding of biodiversity and its importance
- Use quadrats to estimate and record the number of species in a given ecosystem
- Show an awareness that biodiversity is affected by natural calamities such as cyclones and droughts
- List the human activities (deforestation, pollution, degradation of habitat, invasive alien species) that affect biodiversity

In Grade 7, you learnt that the ecosystem comprises living and non-living things.

The living organisms interact with each other and with their non-living environment. A few examples of such interactions are (i) animals feeding on plants and other animals, (ii) forests providing habitats for animals and (iii) plants obtaining carbon dioxide from the atmosphere for photosynthesis.

In  this  unit,  you  will  learn  about  biodiversity  and  its  importance. You  will  also  explore  how human activities affect biodiversity and the different ways to reduce its negative effects.

## Biodiversity

Planet Earth comprises a large variety of living organisms such as plants, animals, bacteria, protista (e.g. Amoeba) and fungi (e.g. Mushroom). Mauritius and its other outer islands, though small,  have  a  diverse  flora  and  fauna  due  to  its  location,  age,  origin,  isolation  and  varied topography. Below are examples of some local organisms.

<!-- image -->

<!-- image -->

<!-- image -->

Y ellow Fody

Butterfly fish                                                                  Geckos

<!-- image -->

<!-- image -->

Rodrigues Aldabra Giant Tortoise

<!-- image -->

Rodrigues Café Marron

Trochetia boutoniana

Activities 3.1 and 3.2 will allow you to understand the meaning of biodiversity.

<!-- image -->

## ACTIVITY 3.1 - Defining biodiversity

Figure 1 shows organisms of different species found in a quadrat . In Grade 7, you  learnt  that  quadrats  are  used  to count  and  estimate  the  number  of plants  and  slow-moving  animals  in  a habitat.  A  quadrat  is  usually  a  square made of wire, wood or plastic pipe.

Figure 1: Organisms in a quadrat (not drawn to scale)

In this image we can see a picture of a plant with a snail and a sunflower.

<!-- image -->

Refer to Figure 1 to answer the following questions.

- (a)      How  many different species can you identify in Figure 1?   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Recall from Unit 2

A species is a group of living organisms which can reproduce among themselves producing fertile offspring(s).

- (b)  With the help of your teacher, name the different species identified in Figure 1.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Count the number of each species present in the quadrat and record your answers in Table 1 below. One has been completed for you.

Table 1: Type and number of organisms in a defined area

| Type of organism   | Species name   |   Number |
|--------------------|----------------|----------|
| Flowering plant    | Dandelion      |        8 |

Through Activity 3.1, you have learnt that different types of organisms co-exist in a given area. In fact, biodiversity refers to the variety of species and their respective numbers found in a defined area .

Through Activity 3.2, you will learn how quadrats may be used to count the number of organisms in a defined area.

<!-- image -->

## ACTIVITY 3.2 -   Estimating the number of living organisms in a defined area using a quadrat

The number of organisms present in an ecosystem can be very high and thus difficult to count. Through Activity 3.2, you will learn to estimate the number of organisms found in a defined area by a sampling exercise using quadrats.

Materials you will need (per group):

Four wooden sticks or plastic pipes, adhesive tape, metre rule.

## Procedure:

1. Organise yourselves in groups of five.
2. Use the wooden sticks or plastic pipes and the adhesive tape to construct a quadrat of size 1m x 1m as shown in Figure 2.
3. Use a metre rule to delimit a working area at a selected site with the help of your teacher. The site can be a forest, the seashore, a riverbank or a garden in your schoolyard.
4. Calculate the area of the selected region.
5. Each group will randomly throw a quadrat in the selected area.
6. Observe , identify and count the number of each type of organism present in the quadrat. Record the information in the table below.
7. Compare your table with that of the other groups to verify your observations and calculate the average number of each type of organism present in the 1m x 1m quadrat.
8. Using the answers of step 4 and 7, estimate the number of the different organisms present in the selected area.  Show your working.

Figure 2: Quadrat

In this image we can see a flower garden.

<!-- image -->

In this image there is a white background with a blue color line on the right side.

<!-- image -->

Referring to the table, what can you deduce about the number and types of organisms in the selected area?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## WHAT I HAVE LEARNT

- Biodiversity is the variety of species and their respective numbers found in a defined area.
- Quadrats are used to estimate the number of organisms such as plants, algae and slowmoving organisms like snails and slugs in a defined area.
- It is difficult to count all organisms in an ecosystem as some organisms are present in very large numbers.
- Biologists use samples to estimate the number of organisms in a habitat.

## Importance of Biodiversity

Biodiversity  is  very  important  for  the  well-being  of  planet  Earth.  You  will  now  learn  how biodiversity is important to us and to the environment.

## 1.  Provision of resources

Some examples of resources provided by the biodiversity are given below:

- Biodiversity  provides  food  for  humans  and  animals.  Some  common  examples  are  fruits, cocoa, nuts, spices, meat and fish.
- A wide variety of plants, animals and fungi are used as medicines. For instance, the leaf infusion of Ayapana is used for indigestion, diarrhea, and vomiting. Another example is the Madagascar periwinkle (commonly known as Saponaire), which is used to make anticancer drug.

Ayapana

<!-- image -->

<!-- image -->

Madagascar periwinkle

- Biodiversity also provides us with industrial materials such as oil, fibres, dyes, rubber, timber and paper.

<!-- image -->

<!-- image -->

Latex (rubber) tree                                                                                                                    Timber

## 2.  Ecological Benefits

Biodiversity provides various ecological benefits which maintain the balance of the ecosystem. A few examples are:

- Plants and algae regulate the composition of oxygen and carbon dioxide in the atmosphere.
- Roots of plants help to prevent soil erosion.
- Microorganisms in the soil help to decompose dead organisms and waste matter. This contributes to make the soil fertile.

## 3.  Socio-economic benefits

A few socio-economic benefits of biodiversity are:

- It  enhances recreational activities like bird watching, fishing, trekking etc.
- It provides opportunities for education and research.
- It is used to promote ecotourism.

## Factors Affecting Biodiversity

The Dodo

<!-- image -->

<!-- image -->

The Solitaire

<!-- image -->

As  you  have  learnt  in  the  previous  section, biodiversity  is  important  for  the  balance  of ecosystems.  Unfortunately,  biodiversity  of Earth  is  declining  at  an  alarming  rate  and may lead to the extinction of many species. The Dodo and the Solitaire are well-known examples of extinct birds in Mauritius and Rodrigues Islands respectively. The disruption in biodiversity affects the balance of the whole ecosystem.

You will now learn how biodiversity is affected by natural causes and human activities.

## 1.  Natural calamities

Natural  calamities  negatively  impact  on  biodiversity  by  causing  habitat  loss  and  death  of organisms.

List a few examples of natural disasters that may reduce biodiversity.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

The extinction of the dinosaur was due to natural causes. Scientists think it was due to an impact of an asteroid or a massive volcano.

## 2.  Human activities

Human beings remain one of the major threats to biodiversity on our planet.

In the next section, you will learn about the impact of human activities on biodiversity.

## Pre-session task:

Watch the video on:

https://www.smithsonianmag.com/videos/category/ science/why-should-humans-care-about-biodiversity-loss/

It is an introductory video on the effect of humans on the environment.

## Impact of Human Activities on Biodiversity

Some human activities that negatively affect biodiversity are:

- Deforestation
- Pollution
- Overexploitation of resources
- Introduction of invasive alien species

<!-- image -->

Between the years 1900 to 2022, the world population has increased from 1.5 to 7.97 billion.

e

B

i

o

d

v

r

s

t

y

## Summary of unit

1. Biodiversity is the wide variety and number of organisms found in a defined area.
2. Quadrats are used to estimate the number of plants and slow-moving animals in a habitat.
3. Biodiversity has a variety of important functions such as (i) the provision of resources such as food, medicines and raw materials for industries (ii) maintaining the balance of ecosystems and (iii) providing services for recreation, research and ecotourism.
4. Biodiversity can be affected by natural calamities (e.g. cyclones, drought, and floods) and human activities such as deforestation, pollution and overexploitation of natural resources and introduction of invasive alien species.

## Recommended Web Links:

- http://www.mauritian-wildlife.org/application/
- https://www.wwf.org.uk
- https://www.iucnredlist.org
- http://www.ecofriendlykids.co.uk/biodiversitynature.html
- https://www.youtube.com/watch?v=0nH3SDhcqXo
- https://kids.nationalgeographic.com/explore/science/declincing-biodiversity/

In this image, we can see a graph.

<!-- image -->

## Section A: Multiple choice questions

1. The variety of organisms on Earth is known as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- A. Biodiversity
- B. Ecosystem
- C. Habitat
- D. Population
2. Which of the following is not a resource obtained from biodiversity?
- A. Food
- B. Fibres
- C. Medicines
- D. Plastic
3. Which of the following organism cannot be counted using the quadrat technique?
- A. Butterfly
- B. Slug
- C. Snail
15. D Trochetia
4. One example of human activity that affects biodiversity is
- A. Cyclone
- B. Deforestation
- C. Flood
- D. Volcanic eruptions
5. The diagram below represents a human activity.

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see the ground with some trees and plants. In the background there is a mountain.

<!-- image -->

How does this activity contribute to global warming?

- A. There will be less carbon dioxide absorbed.
- B. There will be less oxygen absorbed.
- C. There will be less shade from trees.
- D. The soil will become dry.
6. Which activity will more likely lead to the extinction of species?
- A. Conservation
- B. Pollution
- C. Captive breeding
- D. Setting up of nature reserves

<!-- image -->

## Section B:

1. State whether the following statements are true or false .
2. (a)  One example of endemic plant in Mauritius is the chinese guava. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
3. (b)  Biodiversity maintains the stability of ecosystems. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
4. (c)  Enforcing laws helps to conserve biodiversity. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
5. (d)  Biodiversity provides resources such as food and medecines. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
6. (e)  Biodiversity is not affected by cyclones. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
7. (f )  Invasive alien species affect the natural biodiversity. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
2. Figure 1 shows the forest status of specific parts of the world in 2013.
9. Observe the figure carefully and answer the questions that follow.

## World Forest Status 2013

In this image, we can see a map.

<!-- image -->

Source: UN FAO (2016)

Figure 1

- (a)  List two reasons why people clear forest.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Identify two countries where the area under forests are declining.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  What are the possible causes of the decline in area under forests?

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Mauritius has a rich biodiversity with many endemic species. One endemic bird of our island is the Mauritius Kestrel. It is the only remaining bird of prey in Mauritius.

Its current population is only 400 individuals. It lives in forests and feeds on insects, geckos and small birds. Figure 2 shows a picture of the Mauritius Kestrel.

Figure 2

<!-- image -->

- (a)  What is meant by the term biodiversity?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Give two human activities, which have caused the population of the Mauritius Kestrel to decline.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Victor, a student of Grade 9 lives near the rocky shore of Albion and wants to explore the biodiversity of this particular ecosystem. He decides to use quadrats to find the different types of organisms and their respective numbers. He randomly lays out five quadrats in a defined area. The following organisms are identified in the rocky shore ecosystem.

Sea urchin

<!-- image -->

<!-- image -->

<!-- image -->

Figure 3 shows the area where the five quadrats were placed.

Sea snails

Figure 3: Quadrat sampling on a rocky shore

In this image we can see some seeds and some leaves.

<!-- image -->

<!-- image -->

- (a)  Suggest why the student used five quadrats for his sampling rather than one.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  (i) Count the number of limpets, sea urchins and sea snails in each quadrat and record in the Table 1 below.

Table 1

| Type of organisms   | Number of organisms in each quadrat   | Number of organisms in each quadrat   | Number of organisms in each quadrat   | Number of organisms in each quadrat   | Number of organisms in each quadrat   | Number of organisms in each quadrat   |
|---------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|
| Type of organisms   | Quadrat 1                             | Quadrat 2                             | Quadrat 3                             | Quadrat 4                             | Quadrat 5                             | Mean                                  |
| Limpet              |                                       |                                       |                                       |                                       |                                       |                                       |
| Sea snail           |                                       |                                       |                                       |                                       |                                       |                                       |
| Sea urchin          |                                       |                                       |                                       |                                       |                                       |                                       |

- (c)  (i) Using the information in Table 1, construct a bar chart of the mean number of each organism per quadrat.
- (ii) State a relevant conclusion about the mean number of limpets, sea snails and sea urchins on the rocky shore.

In this image, we can see a graph.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Give one way the student can improve his investigation to get a better estimation of the number of limpets, sea snails and sea urchins on the rocky shore.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Nutrition in Plants

Measurement in Science

Unit

## Nutrition in Plants

## Learning Outcomes

## At the end of this unit, you should be able to:

- State that photosynthesis is the process through which green plants manufacture their food
- Write down the word equation for photosynthesis
- Describe briefly how a leaf is adapted for photosynthesis
- List the factors that are essential for photosynthesis to take place
- Conduct simple laboratory experiments to show the importance of these factors for photosynthesis

In Grade 7 , you have studied the different characteristics of living organisms. One of them is nutrition. You learnt that animals obtain their food by feeding on other organisms while plants can make their own food through a process known as photosynthesis .

In this unit, you will learn more about photosynthesis.

## The Process of Photosynthesis

Figure 1 represents the process of photosynthesis.

Figure 1: Photosynthesis

In this image, we can see a plant with a stem and leaves. We can also see the sun, water, and some text.

<!-- image -->

Unit

Unit

Unit

B4

1

1

<!-- image -->

Unit

B4

If you observe Figure 1 carefully, you will see that the plant exposed to sunlight is taking carbon dioxide from the atmosphere and water from the soil.

During  photosynthesis,  light  energy  from  the  sun  is  mainly  trapped  by  pigments  known  as chlorophyll .  The light is used to convert carbon dioxide and water into food (glucose) and oxygen.

Based on Figure 1, complete the word equation below to represent the process of photosynthesis.

sunlight

Carbon dioxide +   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

chlorophyll

Glucose   +   \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Photosynthesis is  the  process  through  which  green  plants  make  their  food  using carbon dioxide and water in the presence of sunlight and chlorophyll. Oxygen is also produced in the process.

## Adaptations of a Leaf for Photosynthesis

The leaf is  the main site for photosynthesis in plants. Through Activities 4.1 to 4.3, you will explore how leaves are adapted for the process of photosynthesis.

## Adaptation 1: Surface area

<!-- image -->

ACTIVITY 4.1 Investigating how surface area of leaf is an adaptation for photosynthesis

Figure 2 shows the different parts of a strawberry plant.

In this image we can see a plant with green leaves and strawberries.

<!-- image -->

Figure 2

Observe Figure 2 carefully and answer the following questions:

- (a) Name parts A, B, C and D.

A  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

B  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

C  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

D  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Calculate  the  approximate surface area of parts A and C, enclosed within the yellow boxes in Figure 2.

Approximate Surface Area of part A

Approximate Surface Area of part C

The total leaf area exposed to light may be estimated by multiplying the exposed mean area of a leaf by the number of leaves present in the plant.

- (c)  (i) State which part of the strawberry plant has the largest  surface area exposed to light.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) How can you relate your answer of part (i) to photosynthesis?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Most leaves are broad and flat, providing large surface area to maximise the absorption of sunlight for photosynthesis.

<!-- image -->

Unit

B

4

<!-- image -->

## WHAT I HAVE LEARNT

- Leaves provide large surface area to maximise the absorption of light.
- Thus, leaves are adapted for the process of photosynthesis.

## Adaptation 2: Network of Veins in a Leaf

Cells in leaves need water in order to carry out photosynthesis. Water is absorbed from the soil by roots and transported through stem to the leaves.

Through Activity 4.2, you will observe the network of veins which transports water.

## ACTIVITY 4.2 Observing the network of veins in a leaf

<!-- image -->

## Materials needed:

- Leaves, beaker, sodium carbonate, forceps, paper towel, bunsen burner and brush.

In this activity, you will remove the soft tissues of the leaf in order to observe the veins. This activity can be carried out as follows:

- (a)  Collect a variety of fresh leaves from your school compound or your garden.
- (b)  Place the leaves you want to use into a beaker.
- (c)  Add 500 cm 3  of water to the beaker, followed by 30 g of sodium carbonate.
- (d)  Boil the content for about 30 minutes or until the leaves soften.
- (e)  Remove the leaves from the solution using a pair of forceps.
- (f )  Set the leaves onto a paper towel and gently brush the leaf pulp away.
- (g)  Rinse the leaves in fresh water and allow it to dry.

You will obtain the skeleton of a leaf as shown in Figure 4. It shows the network of veins present in a leaf.

Figure 4

In this image, we can see a leaf.

<!-- image -->

Using the following words, label parts A, B, C and D in Figure 4 above.

## Midrib, leaf apex, leaf margin, network of veins

The midrib is the central large vein which subdivides into tiny veins that run through the leaf. The veins consist of:

- (a) Xylem , and
- (b) Phloem

Xylem vessels carry water and minerals from the roots through the stem to the leaves of the plant. Once in the leaves, water leaves the veins and enters the cells that are carrying out photosynthesis.

Phloem carry food, in the form of sugar (sucrose), from the leaves to all other parts of the plant during the day.

<!-- image -->

## WHAT I HAVE LEARNT

- Another adaptation of leaves for photosynthesis is the presence of a network of small veins which transports water to the cells of leaves which carry out photosynthesis.

## Adaptation 3: Presence of stomata (singular- stoma)

After learning how a leaf is adapted to receive sunlight and water, you will now learn how the leaf obtains carbon dioxide from the atmosphere.

Through Activity 4.3, you will learn about the presence of pores (stomata) in a leaf.

## ACTIVITY 4.3 Identifying the presence of pores in a leaf

<!-- image -->

## Materials needed:

- Freshly plucked dicot leaf, beaker, Bunsen burner, tripods, water, pair of forceps.

## Procedure:

- (a)  Heat a beaker containing water on a Bunsen flame until boiling.
- (b) Remove the beaker from the flame and immediately dip a freshly plucked leaf into the hot water using a pair of forceps, as shown in Figure 5.

Figure 5

<!-- image -->

B

4

<!-- image -->

- (a)  Observe the leaf carefully and write down your observations.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Extending from your observations in part (a), suggest how a leaf obtains CO 2 from the atmosphere.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The pores can open and close. They open in the presence of light, that is during the day, to allow gas exchange, as indicated in Figure 6. Carbon dioxide molecules enter the leaf through the stomata and are used by leaf cells carrying out photosynthesis. The oxygen molecules which are produced during the process of photosynthesis, diffuse out of leaves through the stomata.

In this image there is a picture of a plant. There is a plant in the middle of the image. There is a plant in the top of the image. There is a plant in the bottom of the image.

<!-- image -->

Note: Water  vapour  also diffuses out of leaves through stomata, during the day.

Figure 6: Gas Exchange through Stomata

## Adaptation 4: Presence of Chlorophyll

Figure  7  shows  that  photosynthetic  leaf  cells,  as  seen  under  the  microscope,  consist  of chloroplasts which contain green pigments called chlorophyll.  The green pigment absorbs light energy which is used during photosynthesis to convert carbon dioxide and water into glucose and oxygen.

Figure 7: Photomicrograph of photosynthetic cells

In this image we can see a collage of different trees.

<!-- image -->

<!-- image -->

## WHAT I HAVE LEARNT

- Small air bubbles are formed on the surface of the leaf when placed in hot water. This shows that leaves have small pores.
- As air moves out of the small pores (stomata) when placed in hot water, small bubbles are formed on the surface of the leaf.
- Carbon dioxide moves from the atmosphere into the leaves through the small pores called stomata.
- So far, you have learnt that leaves are adapted for the process of photosynthesis as follows:
-  Leaves have a large surface area to maximise absorption of light.
-    Leaves have a midrib and network of veins comprising xylem which carry water to photosynthetic cells.
-    Leaves have stomata for gaseous exchange, especially allowing carbon dioxide to move into leaves during the day.
-    Leaves have chlorophyll which traps light.

<!-- image -->

## Factors essential for photosynthesis

Carbon dioxide, light and chlorophyll are some of the factors that are essential for photosynthesis to take place. Before investigating the importance of these factors, let's learn how we test if a plant has carried out photosynthesis.

## Testing the presence of starch in a leaf

As you learnt earlier, glucose is produced in the leaves during photosynthesis. Excess glucose is converted into starch for storage. Thus, the presence of starch in a leaf shows that photosynthesis has taken place.

## ACTIVITY 4.4 Testing the presence of starch in a leaf

<!-- image -->

## Materials needed:

- Soft  green  leaves  (such  as  balsam  leaves),  iodine  solution,  dropper,  ethanol,  boiling  tube, beaker, glass rod, forceps, water, white tile, bunsen burner

## Procedure:

1. Place a freshly plucked leaf, which has been exposed to sunlight, into boiling water in a beaker as shown in Fig 8. Leave it for about one minute.
2. Why do we leave the leaf in boiling water for one minute?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Using forceps, remove the leaf and put it in a boiling tube.

Figure 8

In this image we can see a painting on the board. There is a flame and a leaf.

<!-- image -->

3. Add enough ethanol to cover the leaf in the boiling tube as shown in Figure 9. The Bunsen burner flame should be put off.

Let the leaf stand in the water bath for approximately 3 minutes.

## Safety precautions:

Alcohol is very flammable, so it should not be heated directly over a Bunsen flame.

## Complete the questions below based on your observations. Leaf

- (a) Observe and record the colour of the leaf.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) What is the colour of the ethanol?

In this image we can see a glass with liquid and a leaf.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Suggest why the leaf was placed in alcohol.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Remove the leaf from ethanol.

Is the leaf brittle or soft to touch?  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Wash the leaf in warm water to remove ethanol from the surface of the leaf and to soften it.
6. Spread out the leaf on a white tile and cover it with iodine solution as shown in Figure 10.
3. (a) What do you observe?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) What can you conclude from your observation?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

## WHAT I HAVE LEARNT

- Glucose produced during photosynthesis is converted to starch for storage.
- The blue black colour indicates presence of starch in a leaf.

Unit

B4

Now let's investigate through Activities 4.5 to 4.6, how CO 2 , light and chlorophyll are essential for photosynthesis.

<!-- image -->

## Materials needed :

- 2  potted  plants,  beaker  of  water  at  80 0 C  -  100 0 C,  dropper,  forceps,  iodine  solution, ethanol, black hood and a light source.

In this image, we can see a plant and a cover with a black hood.

<!-- image -->

Note :   Plant A is the control experiment as it has all the conditions needed for photosynthesis and is used for comparison.

## Procedure :

1. Destarch the two potted plants by placing them in complete darkness for approximately 48 hours.
2. Remove the potted plant A from darkness and expose it to sunlight for 2 hours. Place the second potted plant B in darkness (under a black hood), as shown in Figure 11.

3. Collect a leaf from each plant and test the leaves for the presence of starch as described in Activity 4.4.
2. (a)  Record your observations for both leaves in Table 1.
3. (b)  What can you conclude from this investigation?

Table 1

| Leaf   | Observations   |
|--------|----------------|
| A      |                |
| B      |                |

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 4.6 Investigating the importance of carbon dioxide for photosynthesis

## Materials needed :

Retort stand, 2 conical flasks fitted with a rubber bung, 1 potted plant (geranium or balsam), 2 boiling tubes, glass marker pen, beaker of water at 80 o C - 100 o C, 2 petridishes, dropper, forceps or glass rod, iodine solution, ethanol, potassium hydroxide solution.

In this image, we can see a plant. There are leaves and stems. We can see a watermark.

<!-- image -->

## Procedure :

1. A potted plant is destarched by placing it in complete darkness for 48 hours.
2. Leaf A, still attached to the plant, is inserted in a conical flask containing potassium hydroxide, as shown in Figure 12.

Unit

B4

3. Leaf B is enclosed within another conical flask containing water as shown in Figure 12.
4. The plant is left in sunlight for 2 hours
5. Then leaves A and B are removed from the plant and tested for the presence of starch as described in Activity 4.4.

## Safety precautions:

Safety Precaution: Care should be taken when handling potassium hydroxide as it is corrosive.

The results obtained by carrying out starch test on both leaves A and B, are shown in Figure 13.

Leaf A

<!-- image -->

Figure 13

<!-- image -->

Based on the above, answer the following questions.

- (a) State the purpose of potassium hydroxide in the conical flask A.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) State the role of leaf B in this investigation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Name one factor, which is absent in the conical flask A.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) Name the factors present in the conical flask B which are needed for photosynthesis.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Why does leaf B become blue black when tested for the presence of starch?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f) What can you conclude from this experiment?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 4.7 -Investigating the importance of chlorophyll for photosynthesis

## Materials needed :

- A variegated potted plant, boiling tube, glass marker pen, beaker of water at 80 0 C - 100 0 C, petridish, dropper, forceps or glass rod, iodine solution, ethanol.

Note: A  variegated  leaf,  as  shown  in  Figure  14,  is  one  which  has  patches  of  green  (where chlorophyll is present) and white or yellow parts (where green chlorophyll is absent).

Figure 14 : A variegated plant

In this image we can see a plant.

<!-- image -->

## Procedure :

1. Place the variegated plant in darkness for 48 hours to destarch it.
2. Remove the potted plant from darkness and expose it to sunlight for 2 hours.
3. Pluck a leaf from the plant and draw the leaf to show the distribution of the green and non-green parts.

Unit

B4

4. Test the leaf for the presence of starch as described in Activity 4.4.

- (a)   Draw the leaf after iodine solution has been added to show the parts that have become blue-black.

- (b) What can you conclude from your observation?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## WHAT I HAVE LEARNT

For photosynthesis to occur:

- Leaves must be exposed to light/sunlight.
- Plants need carbon dioxide.
- Chlorophyll must be present in leaf cells.

<!-- image -->

## Recommended Website links

1. https://www.bbc.com/bitesize/guides/zyk8msg/revision/1
2. https://www.bbc.com/bitesize/guides/z9pjrwx/revision/8
3. https://www.activewild.com/what-is-photosynthesis-for-kids/
4. https://photosynthesiseducation.com/photosynthesis-for-kids/
5. http://people.eku.edu/ritchisong/378\_diffusion.htm

## Summary of unit

- The process through which green plants make their food is called photosynthesis.
- Light, chlorophyll, water and carbon dioxide are the factors needed for photosynthesis to take place.
- Glucose and oxygen are the products of photosynthesis.
- The word equation for photosynthesis is:
- Large surface area, network of veins, presence of chlorophyll and presence of stomata are adaptations of leaves for photosynthesis.
- Carbon dioxide, light and chlorophyll are some of the factors that are essential for photosynthesis to take place.

The image depicts a color gradient with a gradient from green to white. The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent. The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent. The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent. The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent.

The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent. The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent. The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent.

The gradient is represented by a gradient of colors, with the gradient from green to white being the most prominent. The gradient is represented by a

<!-- image -->

The image is a tree diagram with a title at the top labeled "Food + Oxygen" and a subtitle "Glucose (food + oxygen)" at the bottom. The diagram is divided into two main sections: the left section contains the following nodes: "Food + Oxygen" and "Glucose (food + oxygen)". The right section contains the following nodes: "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach", "Stomach

<!-- image -->

## Section A: Multiple choice Questions

Circle the correct answer.

1. The process through which green plants produce glucose is known as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A. Respiration B. Reproduction C. Photosynthesis D. Excretion

2. The pigment responsible for absorption of light in plants is called  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A.

- Chlorophyll B. Stoma

- C. Xylem

- D. Phloem

3. The diagram below shows gas exchange in a plant exposed to sunlight.

In this image, we can see a plant. We can also see a light.

<!-- image -->

## Identify gas A and gas B.

|    | GasA           | Gas B          |
|----|----------------|----------------|
| A. | Oxygen         | Carbon dioxide |
| B. | Carbon dioxide | Oxygen         |
| C. | Water vapour   | Carbon dioxide |
| D. | Water vapour   | Oxygen         |

4. Which option correctly gives the raw materials and the by-product of the process of photosynthesis?

| raw materials   | raw materials                  | by-product     |
|-----------------|--------------------------------|----------------|
| A.              | Carbon dioxide and chlorophyll | Oxygen         |
| B.              | Carbon dioxide and water       | Oxygen         |
| C.              | Oxygen and chlorophyll         | Carbon dioxide |
| D.              | Oxygen and water               | Carbon dioxide |

5. Which one is an adaptation of leaves for photosynthesis?
6. How does oxygen move out of the leaf?
- A. Evaporation
- B. Transpiration
- C. Respiration
- D. Diffusion
7. Glucose produced during photosynthesis is converted into \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ for storage.
- A. Protein
- B. Genes
- C. Starch
- D. Cellulose
8. A  student  carries  out  an  experiment to find out which gas is released during photosynthesis. He sets up the apparatus using an aquatic plant as shown in the diagram.

- A. It has chlorophyll

- B. It is very thick

- C. It has tiny hairs

- D. It has a small surface area

Which gas is collected in the inverted test-tube?

- A. Carbon monoxide
- B. Hydrogen
- C. Oxygen
- D. Sulfur dioxide
5. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ contains the green pigment chlorophyll.
- A. Chloroplast
- B. Vacuole
- C. Nucleus
- D. Cell wall

In this image, we can see a chart. There is a text on the chart.

<!-- image -->

9.

## Section B

1. Fill in the blanks by choosing the appropriate answer from the list below.

## membrane,  iodine,  variegated,  surface area

- (a)  A leaf is tested for starch using \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ solution.
- (b)    A \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ leaf has green regions where there is chlorophyll and white or yellow regions where chlorophyll is absent.
- (c) The leaves have large \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ to trap light.
2. Match each leaf feature given in Column A with the description in Column B.
3. State whether the following is true or false.
- (a) The reactants of photosynthesis are glucose and oxygen. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (b) Photosynthesis occurs in the nucleus of plant cells. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (c ) Photosynthesis uses sunlight to make sugar. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (d) A variegated leaf has unequal distribution of chlorophyll. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (e)   Potassium hydroxide is used to absorb carbon dioxide from the air. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
4. Answer the following questions.
- (a) List the essential factors for photosynthesis to take place.

| COLUMN A           | COLUMNB                                     |
|--------------------|---------------------------------------------|
| Large surface area | Carry water and food                        |
| Chlorophyll        | Main photosynthetic cells in leaf           |
| Veins              | Maximise sunlight absorption                |
| Stomata            | Pigment absorbing light energy              |
| Palisade cells     | Openings in leaf allowing movement of gases |

1\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  2\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  3 \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  4\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) State the function of chlorophyll.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c ) What are the final products of photosynthesis?

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2.  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) Write down a word equation to represent the process of photosynthesis.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e) State the function of stomata.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f) State one importance of the carbohydrate (sugar) formed by photosynthesis to the plant.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. The diagram below illustrates the different steps (A, B, C and D) carried out when testing a leaf for the presence of starch.

In this image, we can see a water tank and a water pipe. There is a watermark on the image.

<!-- image -->

- (a) Referring to Figure 2, describe steps A, B, C and D.

A  …………………………………………………………………………………………

…………………………………………………………………………………………

B  …………………………………………………………………………………………

…………………………………………………………………………………………

C  …………………………………………………………………………………………

…………………………………………………………………………………………

D  …………………………………………………………………………………………

…………………………………………………………………………………………

- (b) Why are the steps A and B carried out?

Step A: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Step B: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) How will the leaf appear after step B?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) What is the purpose of step C?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e) What would you observe after step D if starch is present in the leaf?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. The leaf below has been treated to show that sunlight is necessary for photosynthesis.

<!-- image -->

Figure 2

A plant was left in darkness for 48 hours before placing the black paper strips on the surfaces of one of the leaves, as shown in Figure 2.

Nutrition in Plants

- (a) Explain why the leaf was partly covered with black paper strips?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Why was the plant kept in darkness for 48 hours?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c )   After exposing the plant to sunlight for a few hours, the partly covered leaf was removed and tested for starch. Draw the leaf in the box below to show your observation.

- (d) Write a conclusion based on the drawing given in part (c).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7. A student carried out an experiment to investigate if plants need light to manufacture glucose which is then stored as starch.

The diagram shows what the student did.

In this image there is a diagram, in the diagram there is a plant kept in a cupboard and aluminium foil placed on one of the leaves.

<!-- image -->

- (a) Why was the potted plant kept in a dark cupboard for 2 days?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Why did the student cover part of the leaf with aluminium foil?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Stage 5 of Figure 3 shows three areas on the leaf indicated as: A, B and C. (i) Write down the expected colours of these areas after testing for starch

A \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_   B \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_   C \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) What can you conclude from your answer of part (c)(i)?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

8. An experiment was carried out to investigate the conditions essential for photosynthesis. Three plants of similar size and of the same species were placed in a dark cupboard for 48 hours.

A leaf from each plant was removed and tested for starch.

The plants were then watered and set up as shown in Figure 4.

Each glass container was illuminated for a few hours.

<!-- image -->

In this image we can see a diagram, there are some text and a picture of a plant, there is a text on the right side of the image, there is a text on the left side of the image, there is a text on the right side of the image, there is a text on the top of the image, there is a text on the bottom of the image, there is a text on the right side of the image, there is a text on the left side of the image, there is a text on the top of the image, there is a text on the bottom of the image, there is a text on the right side of the image, there is a text on the left side of the image, there is a text on the top of the image, there is a text on the bottom of the image, there is a text on the right side of the image, there is a text on the left side of the image, there is a text on the

<!-- image -->

- (a)     When the leaves from the plants were tested for starch at the start of the investigation, all gave a yellow-brown colour with iodine solution.
- Explain why.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Why was potassium hydroxide used?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)   What factor(s) necessary for photosynthesis were absent in:
- (i) vessel B?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) vessel C?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

B4

1

- (d)   After leaving the plants for few hours in sunlight, leaves from plants A, B and C were once more tested for starch with iodine solution.
- (i) Write down the observations you would obtain for the following leaves:
- (ii) Account for your observations in part (d) (i)
9. Lisa investigated how light intensity affects photosynthesis in a piece of pondweed. She set up the apparatus as shown in Figure 5.

Leaf A \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Leaf B \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Leaf C \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Leaf A

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Leaf B

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Leaf C

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image, we can see a diagram. There is a text on the image.

<!-- image -->

metre rule

<!-- image -->

Lisa counted the number of bubbles given off from the pondweed in one minute. She then changed the light intensity by varying the distance of the plant from the lamp and repeated her measurement.

The results are shown in Table 1.

Table 1

|   Distance from lamp (cm) |   Number of bubbles evolved in one minute |
|---------------------------|-------------------------------------------|
|                        10 |                                       101 |
|                        20 |                                       100 |
|                        30 |                                        99 |
|                        40 |                                        95 |
|                        50 |                                        85 |
|                        60 |                                       105 |
|                        70 |                                        62 |
|                        80 |                                        50 |
|                        90 |                                        34 |

- (a) Name the gas which bubbled off from the pondweed.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Using Table 1 state the distance, in cm, at which the light intensity was

- (i) Lowest

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Highest

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(c) (i) Circle the result recorded on Table 1 that does not fit the pattern.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

B4

1

- (ii)   Use the grid to draw a line graph of the results recorded in Table 1. Do not plot the result, that you have encircled in Table 1.
- (d) (i)   Use your graph to describe the changes in the number of bubbles released when the distance of pondweed from the lamp was decreased.

In this image, we can see a graph.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)   What  can  you  deduce  about  the  effect  of  the  light  intensity  on  the  rate  of photosynthesis in the pondweed?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image we can see a collage of different images.

<!-- image -->