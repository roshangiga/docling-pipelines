In this image we can see a poster with some text and images.

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of Ministry of Education, Tertiary Education, Science and Technology

In this image, we can see a poster with some text.

<!-- image -->

## Business and Entrepreneurship Education

(BEE)

In this image we can see a blue color shape.

<!-- image -->

Professor Vassen Naëck

- -Head, Curriculum Implementation,Textbook Development and Evaluation

## BUSINESS AND ENTREPRENEURSHIP EDUCATION (BEE) PANEL

Dr Nazeerah Sheik Abbass

- Coordinator, Senior Lecturer, MIE

Dr Vandana Tulsidas-Veeraragoo

- Senior Lecturer, MIE

Dr Roodradeo Beefun

- Senior Lecturer, MIE

Vikram Mootooree

- Educator

Ravimun Gohee

- Educator

Bibi Husna Noor Oozeer-Boodhoo

- Educator

Nayaz M Emamaullee

- Educator

Chandreeka Dreepaul

- Educator

Jeetendra Dutt Narain

- Educator

Marie Ingrid Allet

- Educator

Marie Jocelyne Colin

- Educator

<!-- image -->

Design

Nishi Manic

- Graphic Designer, MIE

- © Mauritius Institute of Education (2021)

ISBN: 978-99949-53-83-7

## Acknowledgement

-  Rajendra Korlapu-Bungaree (Senior Lecturer, MIE) for proof reading.

Consent from copyright owners has been sought. However, we extend our apologies to those we might have overlooked. All materials should be used strictly for educational purposes.

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu.

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the NCF, while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic artists who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

## Dr O Nath Varma

Director

Mauritius Institute of Education

## Preface

Our children and young people are the backbone of the socio-economic development of our country. To progress towards a balanced, active and productive lifestyle, young people must make sense of the importance of their economic wellbeing and recognise that the aim of the BEE Curriculum is  to develop their knowledge and understanding of the dynamic business and economic environment in which they live. The youth must also appreciate that being exposed to Business and Entrepreneurship Education not only allows them to develop the knowledge, skills and values but also gives them the right to shape their future economic wellbeing responsibly.

In line with the educational reform in 2016, we have the pleasure to present the Grade 9 Business and Entrepreneurship Education textbook to the educators and our learners. This BEE textbook is multidisciplinary and integrates three distinct key academic subjects of 21 st   Century Learning, namely, Business &amp; Entrepreneurship Education, Economics, and Accounting.  Using the Framework for 21 st Century Learning, we have strived towards the holistic development of the learner by developing teaching and learning materials that would create dynamic and exciting moments of teaching and learning.

Though the textbook consists of fourteen units, it is purposely brief. Thus, essential concepts have been covered without burdening students and educators with unnecessary detail at Grade 9 level. Most importantly, it prepares learners for the National examinations at the end of the year.

Whether the learner is assisted by the teacher in the classroom or opts for independent learning, both ways can be highly interesting. The concepts are presented in simple and straightforward manner and are all followed by easy to more challenging activities. In every unit, the learners' competency is assessed through MCQs, true/false statements, short-answer questions, matching exercises, fill-inthe-blanks exercises, and short case studies. Additional practice questions are included at the end of each unit.

The array of units in the Grade 9 textbook has been mindfully chosen to ensure that learners are exposed to important concepts before they move to upper secondary classes, either in the same field of study, or any other. At this level, BEE expose learners to knowledge and understanding of business, economics and accounting, and facilitates the development of decision-making and critical thinking skills.

A  sound  knowledge  of  BEE  fundamentals  is  needed  for  success.  We  are  confident  that  the  BEE textbook will enable young learners to acquire and enhance their business skills and develop an entrepreneurial spirit.

Educators are encouraged to use active methods of engaging students to enhance their creativity and innovative skills. We wish both teachers and learners success.

## The Authors

## Table of contents

| Unit 1   | Business organisations       | Business organisations                                     |   1 |
|----------|------------------------------|------------------------------------------------------------|-----|
|          | 1.1                          | Forms of business organisations                            |   2 |
|          | 1.2                          | Company                                                    |   3 |
|          |                              | 1.2.1 Howtoset up a company                                |   3 |
|          |                              | 1.2.2 Features of a company                                |   6 |
|          |                              | 1.2.3 Advantages of a company                              |   7 |
|          |                              | 1.2.4 Disadvantages of a company                           |   7 |
|          | 1.3                          | Cooperatives                                               |   9 |
|          |                              | 1.3.1 Howtoset up a cooperative                            |   9 |
|          |                              | 1.3.2 Features of a cooperative                            |   9 |
|          |                              | 1.3.3 Advantages of a cooperative                          |  10 |
|          |                              | 1.3.4 Disadvantages of a cooperative                       |  10 |
|          | 1.4                          | Franchise                                                  |  11 |
|          |                              | 1.4.1 Howtoset up a franchise                              |  12 |
|          |                              | 1.4.2 Features of a franchise                              |  13 |
|          |                              | 1.4.3 Advantages of a franchise                            |  13 |
|          |                              | 1.4.4 Disadvantages of a franchise                         |  13 |
|          | 1.5                          | Selecting the right business organisation for myenterprise |  16 |
| Unit 2   | The entrepreneur as a leader | The entrepreneur as a leader                               |  19 |
|          | 2.1                          | The entrepreneur                                           |  20 |
|          |                              | 2.1.1 Functions of an entrepreneur                         |  20 |
|          |                              | 2.1.2 Responsibilities of an entrepreneur                  |  21 |
|          |                              | 2.1.3 Qualities of a leader entrepreneur                   |  22 |
|          | 2.2                          | Stakeholders                                               |  23 |
|          |                              | 2.2.1 Roles and objectives of stakeholders                 |  23 |
|          | 2.3                          | Managing risks in myenterprise                             |  24 |
|          |                              | 2.3.1 Types of risk                                        |  24 |
|          |                              | 2.3.2 Dealing with risks                                   |  26 |
| Unit 3   | Entrepreneurial skills       | Entrepreneurial skills                                     |  29 |
|          | 3.1                          | Communication                                              |  30 |
|          |                              | 3.1.1 Communication process                                |  30 |
|          |                              | 3.1.2 Effective communication                              |  32 |
|          | 3.2                          | Importance of effective communication in an enterprise     |  33 |
|          | 3.3                          | Forms of communication in an enterprise                    |  34 |
|          | 3.4                          | Internal and external communication                        |  36 |
|          | 3.5                          | Conflicts in an enterprise                                 |  37 |
|          |                              | 3.5.1 Resolving conflicts in an enterprise                 |  37 |
| Unit 4   | Marketing                    | Marketing                                                  |  41 |
|          | 4.1                          | Marketing                                                  |  42 |
|          |                              | 4.1.1 Selling vs marketing                                 |  42 |

|        | 4.2            | Knowing your market                   |   43 |
|--------|----------------|---------------------------------------|------|
|        |                | 4.2.1 Market research                 |   44 |
|        | 4.3            | Elements of Marketing                 |   45 |
|        |                | 4.3.1 Product                         |   45 |
|        |                | 4.3.2 Price                           |   47 |
|        |                | 4.3.3 Promotion                       |   48 |
|        |                | 4.3.4 Place                           |   50 |
|        | 4.4            | Entrepreneurs and E-marketing         |   52 |
|        |                | 4.4.1 Methods of E-marketing          |   52 |
|        |                | 4.4.2 Importance of E-marketing       |   52 |
| Unit 5 | Business plan  | Business plan                         |   57 |
|        | 5.1            | Business plan                         |   58 |
|        | 5.2            | Uses of a business plan               |   58 |
|        | 5.3            | Components of a business plan         |   60 |
| Unit 6 | Demand&Supply  | Demand&Supply                         |   65 |
|        | 6.1            | The market                            |   66 |
|        | 6.2            | Demand                                |   67 |
|        |                | 6.2.1Lawofdemand                      |   68 |
|        |                | 6.2.2 The demandcurve                 |   69 |
|        |                | 6.2.3 Factors affectingdemand         |   71 |
|        |                | 6.2.4 Movement along the demandcurve  |   72 |
|        |                | 6.2.5 Shift of the demandcurve        |   73 |
|        | 6.3            | Supply                                |   75 |
|        |                | 6.3.1 Lawof supply                    |   75 |
|        |                | 6.3.2 The supply curve                |   76 |
|        |                | 6.3.3 Factors affecting supply        |   78 |
|        |                | 6.3.4 Movement along the supply curve |   79 |
|        |                | 6.3.5 Shift of the supply curve       |   80 |
|        | 6.4            | Equilibrium point                     |   82 |
| Unit 7 | Money &Banking | Money &Banking                        |   87 |
|        | 7.1            | Money                                 |   87 |
|        |                | 7.1.1 Forms ofmoney                   |   88 |
|        |                | 7.1.2 Characteristics ofmoney         |   90 |
|        |                | 7.1.3 Functions ofmoney               |   91 |
|        | 7.2            | Banks                                 |   93 |
|        |                | 7.2.1 Commercial Banks                |   93 |
|        |                | 7.2.1.1 Functions of commercial banks |   93 |
|        | 7.3            | Central Banks                         |   94 |
|        |                | 7.3.1 Functions of Central Banks      |   95 |

| Unit 8   | Spending, Savings and Borrowing               | Spending, Savings and Borrowing               |   97 |
|----------|-----------------------------------------------|-----------------------------------------------|------|
|          | 8.1                                           | Spending                                      |   98 |
|          |                                               | 8.1.1 Factors affecting spending              |  100 |
|          | 8.2                                           | Savings                                       |  102 |
|          |                                               | 8.2.1 Factors affecting savings               |  102 |
|          | 8.3                                           | Borrowing                                     |  103 |
|          |                                               | 8.3.1 Factors affecting borrowing             |  104 |
| Unit 9   | International trade                           | International trade                           |  107 |
|          | 9.1                                           | Trade                                         |  108 |
|          | 9.2                                           | Home trade and International trade            |  109 |
|          |                                               | 9.2.1 Hometrade                               |  109 |
|          |                                               | 9.2.2 International trade                     |  110 |
|          | 9.3                                           | Exports and Imports                           |  110 |
|          |                                               | 9.3.1 Exports                                 |  110 |
|          |                                               | 9.3.2 Imports                                 |  111 |
|          | 9.4 Importance of trade                       | 9.4 Importance of trade                       |  111 |
| Unit 10  | Recording business transactions in the ledger | Recording business transactions in the ledger |  113 |
|          | 10.1                                          | Recording business transactions               |  114 |
|          | 10.2                                          | Recording cash transactions                   |  115 |
|          | 10.3                                          | Recording bank transactions                   |  118 |
|          | 10.4                                          | Recording credit transactions                 |  123 |
| Unit 11  | Balancing of accounts in the ledger           | Balancing of accounts in the ledger           |  133 |
|          | 11.1                                          | Steps to balance ledger accounts              |  134 |
| Unit 12  | Trial Balance                                 | Trial Balance                                 |  141 |
|          | 12.1                                          | Trial Balance                                 |  142 |
|          | 12.2                                          | Format of Trial Balance                       |  143 |
|          | 12.3                                          | Preparing the Trial Balance                   |  144 |
| Unit 13  | Income Statement                              | Income Statement                              |  155 |
|          | 13.1                                          | The Income Statement                          |  156 |
|          | 13.2                                          | Format of Income Statement                    |  156 |
|          |                                               | 13.2.1 Trading Account                        |  157 |
|          |                                               | 13.2.2 Profit and Loss Account                |  160 |
|          | 13.3                                          | Preparing the Income Statement                |  163 |
| Unit 14  | Statement of Financial Position               | Statement of Financial Position               |  169 |
|          | 14.1                                          | Statement of Financial Position               |  170 |
|          | 14.2                                          | Assets and Liabilities                        |  170 |
|          | 14.3                                          | Format of Statement of Financial Position     |  175 |

## Learner's Goal Checklist

Educators may print this Learner's Goal Checklist for their student to evaluate the different levels of learning.

Student's name:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Class:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Topic

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What I know and understand about the above topic?

2. 2

I can describe or apply the above topic giving examples as follows:

I learnt that...

1

3

I evaluate my learning by putting a (      ) in the appropriate box below:

<!-- image -->

<!-- image -->

In this image we can see a group of people standing on the ground. In the background there is a building.

<!-- image -->

Business Organisations

Unit 1 Business Organisations

## Learning Objectives:

## On completing this unit, you will be able to:

- identify  the  features  of  various  types  of  business  organisations, namely, company, cooperative and franchise
- explain advantages and disadvantages of each type of organisation
- discuss the type of organisation entrepreneurs may set up

In this unit, you will learn about various forms of business organisations which are usually set up by entrepreneurs as well as their advantages and disadvantages. You will, then, discuss about selecting a particular form of business organisation to set up an enterprise.

## 1.1 Forms of business organisations

Setting up one's own enterprise requires selecting an appropriate form of business organisation. A business organisation is  an enterprise which provides goods and/or services to consumers, usually with the aim of making profits. There are different forms of business organisations and the common ones are sole trading, partnership, company, cooperative and franchise. Each type of business organisation differs from each other because they have different features in terms of ownership, raising of capital, risks and sharing of profits or losses.

Figure 1: Forms of business organisations

The image depicts a business organization with three main entities: "Soetoro Trading," "Partnership," and "Cooperative." The business organization is represented by a circular shape with a light blue background. The business organization is connected to three main entities: "Soetoro Trading," "Partnership," and "Cooperative."

### Business Organization
- **Soetoro Trading** is represented by a circular shape with a light blue background.
- **Partnership** is represented by a light blue shape with a white background.
- **Cooperative** is represented by a light blue shape with a white background.

### Business Organization Connection
- **Soetoro Trading** is connected to the **Partnership** by a line segment.
- **Soetoro Trading** is connected to the **Cooperative** by a line segment.

### Business Organization Connection
- **Soetoro Trading** is connected to the **Partners

<!-- image -->

## Read the story below.

## Les Hibiscus Pastry Shop

Natasha  is  a  talented  confectioner.  She  set  up  a  small pastry shop, Les Hibiscus, and was the only one to manage her enterprise. Later, she asked her friend Fanny to join her business as a partner. The shop was then known as Hibiscus  Partners.  A  few  years  later,  the  business  was converted into a company, Les Hibiscus Company.

<!-- image -->

Figure 2: Sole trading, Partnership and Company

In this image, we can see a diagram with some text and a few icons.

<!-- image -->

## 1.2 Company

A company is  an incorporated business organisation which is owned by its shareholders.

It  is  a  form  of  business  organisation  which  is  set  up  by  raising capital through issue of shares. Companies are incorporated, i.e, they must be registered at the Registrar of Companies. There are a set of legal rules to follow when setting up a company which are found in the Companies Act.

A company is an incorporated business organisation which is owned by its shareholders.

## 1.2.1  How to set up a company

## Read the following story about setting up a company.

Laura  and  her  business  partner,  Ben,  own  and  manage  a souvenir shop, Le Tresor des Cannoniers , in one of the busiest coastal areas of Mauritius. With an increase in tourist arrivals in the  country,  their  business  required  more  capital  to  expand. Friends  advised  them  to  consider  converting  their  business into  a  company  to  enjoy  further  advantages. Therefore,  they planned to set up their company.

<!-- image -->

Setting up a company involves a number of steps to follow. Entrepreneurs usually ask some basic questions before setting up a company.

<!-- image -->

What  is  the  legal  procedure  in  setting  up  a company?

<!-- image -->

Note: Companies are easily recognised as the name of the enterprise must be followed by 'Company Limited' . Often, it is shortened by 'Co Ltd' .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Who would be the owners of a company?

Who would manage and control the company?

What are the risks involved in setting up a company?

How to register a company?

Which documents are required to register a company?

Laura and Ben had to understand the following terms before setting up a company.

|    | Terms                        | Explanation of terms                                                                                                                                                                    |
|----|------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1  | Companies Act                | The Companies Act is a legal document that outlines the laws and regulations to set up a company.                                                                                       |
| 2  | Share                        | A share is a voucher that represents a unit of capital.                                                                                                                                 |
|    | Shareholder                  | A shareholder is the one who invest in a company by buying its shares.                                                                                                                  |
| 3  | Share certificate Dividend   | A share certificate is an official document stating the number of shares that the shareholders have in the company.                                                                     |
|    |                              | Dividend is the part of company's profits that is distributed to shareholders.                                                                                                          |
| 4  | Board of Directors           | Board of Directors are those who have been elected by shareholders to manage the company.                                                                                               |
| 5  | Limited liability            | Limited liability means that shareholders will lose only the initial amount invested in case the company goes bankrupt.                                                                 |
| 6  | Registrar of Companies       | Registrar of Companies is the authority that registers companies and issues the certificate of incorporation to allow the business to start its operation.                              |
| 7  | Memorandumof Association     | MemorandumofAssociation is a legal document which provides details such as company's name, physical address of registered office, names of shareholders and the distribution of shares. |
| 8  | Articles of Association      | Articles of Association is a document that specifies the internal rules of a company.                                                                                                   |
| 9  | Certificate of Incorporation | Certificate of Incorporation is a legal document showing the official date a company can start operating.                                                                               |
| 10 | Annual General Meeting       | Annual General Meeting (AGM) is a yearly meeting where shareholders elect the directors of a company and the annual report about the performance of business is presented and approved. |

There are two types of companies, as shown below.

Figure 4: Types of company

|   1 | Types of company Private Limited Company A business that raises capital from a small number of shareholders such friends and/or relatives.                     |
|-----|----------------------------------------------------------------------------------------------------------------------------------------------------------------|
|   2 | Public Limited Company A business that raises capital by issuing shares to members of the general public. It is usually larger than a private limited company. |

The following steps should be followed when setting up a company.

The image is a circular diagram with five main components. The diagram is divided into five sections, each representing a different part of the process. Here is a detailed description of each component:

1. **Application**:
   - **Application**: This is the central component of the diagram. It is represented by a circle with a white background.
   - **Application**: This is the process that is being described. It is represented by a blue circle.

2. **Certificate of Incorporation**:
   - **Certificate of Incorporation**: This is the second component of the diagram. It is represented by a blue circle with a white background.
   - **Certificate of Incorporation**: This is the process that is being described. It is represented by a green circle.

3. **Registrar of Companies**:
   - **Registrar of Companies**: This is the third component of the diagram. It is represented by a blue circle with a white background.
   - **Reg

<!-- image -->

Figure 5: Steps for registration of a company

|   Steps | Requirements                 | Requirements                                                                                                                                                                                                                                                                     | Requirements                                                                                                                                                                                                          |
|---------|------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|       1 | Application forms            | To set up a company, owners must fill up application forms which are available at the Registrar of Companies.                                                                                                                                                                    | To set up a company, owners must fill up application forms which are available at the Registrar of Companies.                                                                                                         |
|       2 | Registration                 | Two important documents, namely Memorandum and Articles of Association must be submitted Companies. MemorandumofAssociation • Name of the company • Office address • Names of shareholders andthenumberofshares held by each of them • Share capital • Objectives of the company | of Association to the Registrar of Articles of Association • Rules and regulations in the company • Names of the directors • Procedurestobefollowedat meetings • Rights, duties and responsibilities of the directors |
|       3 | Certificate of Incorporation | The Registrar of Companies issues a Certificate of Incorporation. The business can, then, start its activities.                                                                                                                                                                  | The Registrar of Companies issues a Certificate of Incorporation. The business can, then, start its activities.                                                                                                       |

<!-- image -->

State two documents that should be prepared by a company for its registration. Use the table below to present your answer.

| Registration of a company   |
|-----------------------------|
| Documents required          |
| 2                           |

## 1.2.2 Features of a company

The features of a company are explained below.

Table 3 : Features of a company

|    |              | Features of a company                                                                                                                                                    |
|----|--------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Registration | A company must be incorporated at the Registrar of Companies . It, then, gets a separate legal identity from the owners'identity.                                        |
|  2 | Ownership    | Shareholders are the owners of a company. They buy shares of a company. Each share has one voting right .                                                                |
|  3 | Control      | A company is managed by a Board of Directors . They are appointed to make decisions and control the business. The accounts are presented to the shareholders in an AGM . |
|  4 | Risk         | Shareholders have limited liability .                                                                                                                                    |
|  5 | Profits      | The company's profit is distributed to shareholders as dividend .                                                                                                        |

## 1.2.3 Advantages of a company

There are several advantages that entrepreneurs may enjoy by setting up companies. They are explained in the table below.

Table 4 : Advantages of a company

|    | Advantages of a company   | Advantages of a company                                                                                                              |
|----|---------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Limited liability         | In case of bankruptcy, shareholders lose only the amount invested as capital.                                                        |
|  2 | Separate legal identity   | Companies have a distinct identity from the shareholders.                                                                            |
|  3 | Continuity                | A company continues to exist even if shareholders leave the company. The shares must be sold to someone else.                        |
|  4 | Capital                   | More capital can be raised through issue of shares.                                                                                  |
|  5 | Management                | The company is managed by a Board of Directors, who are usually experts, to take effective decisions to run and control the company. |

## 1.2.4 Disadvantages of a company

Setting up companies may have certain disadvantages. They are explained below.

Table 5: Disadvantages of a company

|    | Disadvantages of a company   | Disadvantages of a company                                                                                                                |
|----|------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Registration                 | Registration of a company can take a lot of time.                                                                                         |
|  2 | Disclosure of accounts       | Companies must disclose details of its accounts to the Registrar of Companies and shareholders. Business privacy is no longer maintained. |

<!-- image -->

Tico  works  as  a  fisherman  since  he  was  a  teenager.  Along with other fishermen in his locality, he decided to open a fish shop, known as Fishies Foods. After few years of trading, they incorporated the enterprise as Fishies Co Ltd.

<!-- image -->

## State whether the following statements are True or False.

| (a)   | Fishies Co Ltd is a sole trading business.                                                   |
|-------|----------------------------------------------------------------------------------------------|
| (b)   | Fishies Co Ltd may raise a larger amount of capital when incorpo- rated as a company.        |
| (c)   | Shareholders of Fishies Co Ltd have unlimited liability.                                     |
| (d)   | Fishies Co Ltd would enjoy continuity even if one of the share- holders leaves the business. |

## Activity 3

Match each term in column A with the corresponding definition in column B. Write your answers in the table which follows.

| ColumnA                  |    | Column B                                                                                                                            |
|--------------------------|----|-------------------------------------------------------------------------------------------------------------------------------------|
| Memorandumof Association |  1 | A A voucher that represents a unit of capital.                                                                                      |
| Board of Directors       |  2 | B A legal document which provides details such as the names of a company and its shareholders.                                      |
| Share                    |  3 | C They are elected by shareholders to manage the company.                                                                           |
| Dividend                 |  4 | D The authority that registers companies and issues the certificate of incorporation to allow the business to start its activities. |
| Registrar of Companies   |  5 | E Part of company's profits that is distributed to shareholders.                                                                    |

| ColumnA   | A   | B   | C   | D   | E   |
|-----------|-----|-----|-----|-----|-----|
| Column B  |     |     |     |     |     |

## 1.3 Cooperatives

Cooperatives are a popular form of organisation for small businesses.  A cooperative is  a  business  organisation  which  is owned and run jointly by its members, who share the profits or benefits. Each member contributes capital by buying a share. He/ she is allowed one vote when taking business decisions.

Cooperative is  a  business organisation which is owned  and  run  jointly  by its members, who share the profits or benefits.

A number of cooperatives exist in Mauritius, for example, in the agricultural sector. It has helped several small entrepreneurs to improve their business activities.

## 1.3.1 How to set up a cooperative

A number of steps should be followed when setting up a cooperative.

In this image, we can see a diagram with some text and numbers.

<!-- image -->

## 1.3.2 Features of cooperatives

A cooperative has the following features. They are explained in the table below.

|    | Features of a cooperative   | Features of a cooperative                                                                                            |
|----|-----------------------------|----------------------------------------------------------------------------------------------------------------------|
|  1 | Registration                | The cooperative must be registered at the Cooperatives Division.                                                     |
|  2 |                             | Ownership Owners of a cooperative are known as members. Shares are bought to raise capital required in the business. |
|  3 | Control                     | Each member has one voting right to participate in decision making.                                                  |
|  4 | Risk                        | Members have limited liability.                                                                                      |
|  5 | Profit                      | The gains are termed as surplus and members share it among themselves as dividend.                                   |

Read  the  story  below  about  advantages  and  disadvantages  of  setting  up  a cooperative.

## Cooperative de L'Ouest

Jacques,  a  potato  cultivator,  decides  to  form  a  local  cooperative, Cooperative  de  L'Ouest.  He  convinced  other  farmers  to  join  the cooperative. They pooled up resources and bought modern farming equipment which increased productivity and helped them out of poverty.  Unfortunately,  they  are  sometimes  discouraged  by  the slow decision-making process.

## 1.3.3 Advantages of a cooperative

The advantages of setting up cooperatives are explained below.

Table 7: Advantages of a cooperative

|   1 | Employment            | Members of a cooperative create their own jobs and provide employment to others.      |
|-----|-----------------------|---------------------------------------------------------------------------------------|
|   2 | Ownership and control | Members join together to share ideas and help each other to manage the cooperative.   |
|   3 | Profits               | The gains are termed as surplus and members share it among themselves as dividends.   |
|   4 | Government support    | The Government offers grants, loans and financial assistance to support cooperatives. |

## 1.3.4 Disadvantages of a cooperative

Joining cooperatives may have certain disadvantages. They are described below.

|   1 | Consultation   | Members must necessarily consult each other before a final decision is taken. It slows down decision making.   |
|-----|----------------|----------------------------------------------------------------------------------------------------------------|
|   2 | Low profits    | Profits are usually low because prices charged are usually low.                                                |

Table 8: Disadvantages of a cooperative

<!-- image -->

<!-- image -->

## State whether the following statements are True or False.

- (a) Members in a cooperative have unlimited liability.

- (b) Cooperatives group many small producers to benefit from larger amount of capital.

- (c) Profits earned in a cooperative are distributed to members as dividend.

<!-- image -->

The small farmers of La Savanne decided to join in together to grow their small enterprises.

I need to identify and explain two advantages of setting up a cooperative.

Here is the text in markdown format:

## Identify and explain two advantages of setting up a cooperative.

Advantage 1:
Advantage 2:

Here is the text in markdown format:

## Identify and explain two advantages of setting up a cooperative.

Advantage 1:
Advantage 2:

## Identify and explain two advantages of setting up a cooperative.

Advantage 1:
Advantage 2:

## Identify and explain two advantages of setting up a cooperative.

Advantage 1:
Advantage 2:

## Identify and explain two advantages of setting up a cooperative.

Advantage 1:
Advantage 2:

## Identify and explain two advantages of setting up a cooperative.

Advantage 1:
Advantage 2:

<!-- image -->

## 1.4 Franchise

A franchise business is usually a well-established and famous enterprise. They are found in different parts of the world and are known worldwide.

Figure 7: Franchise business in different countries

In this image, we can see a chart. On the chart, we can see the text.

<!-- image -->

There are a number of franchise businesses in different sectors in Mauritius. For example, KFC is a franchise business.

## 1.4.1 How to set up a franchise

A franchise is  a  type  of  enterprise  that  bought  a  license  from  a franchisor  to  sell  its  products  and  services.  A franchisee is  the enterprise  that  buys  the  license  from  a  franchisor. The franchisor sells a license of operation before the latter can start to operate.

<!-- image -->

Sells  to

A license

A franchise is an enterprise that has a license from a franchisor to sell its products or services.

Franchisee

Buyer

Figure 8: Setting up a franchise

## Read  the  story  below  about  advantages  and  disadvantages  of  setting  up  a franchise.

Two friends, June and Koy, who had some capital were discussing about setting up an enterprise. On one hand, they wanted to start up a clothing boutique and create their own strong brand. On the other hand, they thought of starting up an enterprise that sells world-renowned branded fashion clothing store that would be run as a franchise business.

Activity 6

In the space provided, write down one example of a franchise business that exists in Mauritius in the following sectors.

Food retail business

Clothing and fashion

## 1.4.2 Features of a franchise

A franchise has the following features. They are explained below.

Table 9: Features of a franchise

|    | Features of a franchise   | Features of a franchise                                         |
|----|---------------------------|-----------------------------------------------------------------|
|  1 | Ownership                 | The franchisee buys a license of operation from the franchisor. |
|  2 | Control                   | The franchisee runs and controls the enterprise.                |

## 1.4.3 Advantages of a franchise

Franchise businesses offer several advantages. They are explained below.

Table 10: Advantages of a franchise

|    | Advantages of franchise businesses   | Advantages of franchise businesses                                                        |
|----|--------------------------------------|-------------------------------------------------------------------------------------------|
|  1 | Strong reputation                    | Fewer chances of new business failing as an established brand and product are being used. |
|  2 | Support and training                 | Advice, management support and training to personnel are offered by franchisor.           |
|  3 | Existing product                     | Most supplies are purchased directly from the franchisor.                                 |

## 1.4.4 Disadvantages of a franchise

Franchise businesses may also have some disadvantages. They are explained below.

Table 11: Disadvantages of a franchise

|    | Disadvantages of franchise businesses   | Disadvantages of franchise businesses                                                          |
|----|-----------------------------------------|------------------------------------------------------------------------------------------------|
|  1 | Huge investment                         | The franchise license fee can be expensive.                                                    |
|  2 | Control by franchisor                   | Strict rules over pricing and layout of outlet reduce owner's control over one's own business. |
|  3 | Profits to franchisor                   | Part of the profits has to be paid to the franchisor each year.                                |

<!-- image -->

## Read the case study below and answer the following questions.

## Aryaan Pizza Shop or a Pizza Franchise

For five years, Aryaan worked in a restaurant as a manager, selling pizzas. He developed an interest to set up his own pizza shop with his own brand name but he was also aware that he could set up a franchise. He thought about the capital that he would require, the risks involved and the benefits of  an  already  existing  renowned  brand  name.  Aryaan searched  for  more  information  on  existing  franchise businesses  around  the  world.  He  was  attracted  by  the benefits of a franchise business but was held back by the investment required and the interference of the franchisor in his business matters.

<!-- image -->

|          | Identifytworeasonsforsettingupafranchiseratherthanone'sownenterprise.   |
|----------|-------------------------------------------------------------------------|
| Reason 1 |                                                                         |
| Reason 2 |                                                                         |

## Activity 8

State two advantages and two disadvantages of setting up the following types of business organisations.

## Company

## Advantages

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Disadvantages

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Franchise

## Advantages

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Disadvantages

1. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## Multinationals

Multinationals  (MNCs)  have  grown  very  popular  in recent years as it is easier to move from one place in the  world  to  another  country.  Thus,  products  which were, once produced in a foreign country can now be produced anywhere in the world.

<!-- image -->

The image depicts a chart titled "Enterprise based in USA" with a header that reads "Headquarters" and a subheading that reads "Enterprise based in USA." The chart is designed to show the distribution of a specific company's business in the United States.

The chart is divided into two main sections:
1. **Country**: The first section is labeled "Country A" and contains four sub-sections:
   - **Country A**: This section contains the first three sub-sections: "Country A," "Country B," and "Country C."
   - **Country B**: This section contains the fourth sub-section: "Country C."
   - **Country C**: This section contains the last sub-section: "Country D."

2. **Country B**: This section is labeled "Country B" and contains the fourth sub-section: "Country D."

The chart also includes a sub-section labeled "Country F," which is the final

<!-- image -->

There are a number of multinational businesses in different sectors in Mauritius.

A multinational company (MNC) is an enterprise that produces goods  or  provides  services  in  foreign  countries.  Thus,  MNCs usually  carry  their  business  operations  in  several  countries. However, the main office (headquarters) is usually located in the country of origin, usually known as the home country. MNCs are enterprises that manufacture products with same features, logo or product names in different parts of the world.

Multinational company is an enterprise that has production or service facilities outside the country in which it is based.

## 1.5 Selecting the right business organisation for my enterprise

Choosing  the  right  business  organisation  is  one  of  the  most  important  decisions  an entrepreneur  has  to  make  before  setting  up  an  enterprise.  The  factors  that  influence entrepreneurs' decisions are found in the diagram below.

Figure 9: Factors affecting decisions to set up an enterprise

The image is a circular diagram with five main components. The diagram is divided into five sections, each representing a different aspect of the business organization. Here is a detailed description of each component:

1. **Center**:
   - **Title**: "Ownership and Control"
   - **Text**: "Right business organization for my enterprise"
   - **Icon**: A blue circle with the word "Ownership" written inside.

2. **Left Section**:
   - **Title**: "Continuity"
   - **Text**: "Right business organization for my organization"
   - **Icon**: A green circle with the word "Continuity" written inside.

3. **Center Section**:
   - **Title**: "Risk"
   - **Text**: "Right business organization for my risk"
   - **Icon**: A blue circle with the word "Risk" written inside.

4. **Right Section**:
   - **Title**: "Registration and Procedures"
   - **Text

<!-- image -->

Entrepreneurs are usually influenced by a number of factors in selecting the appropriate type of business organisation. The entrepreneur should ask the following questions before taking a decision.

Figure 10: Questions to consider before setting up an enterprise

In this image, we can see a question paper with some text written on it.

<!-- image -->

Some entrepreneurs enjoy taking risks but others may be unwilling to do so. Some entrepreneurs change their type of organisation because they must raise more capital to grow their enterprise. Others  might  be  discouraged  because  registration  is  complicated  and  registration  fees  are expensive.

<!-- image -->

## Question 1

## Multiple Choice Questions

## Choose the correct answer for each of the questions below and write it in the space provided.

1. Shareholders in a company are the ……………………… of the  business organisation.

- A customers

B owners

C leaders

D suppliers

Answer \_\_\_\_\_\_\_\_

2. Documents required to register a company at the Registrar of Companies are

- A Partnership Deed and Article of Association

- B Share certificate and Article of Association

C Memorandum of Association and Article of Association

D Memorandum of Association and Partnership Deed

Answer \_\_\_\_\_\_\_\_

3. A   ……………………………….. issues shares to members of the general public.

- A cooperative

B public limited company

C franchisee

D government

Answer \_\_\_\_\_\_\_\_

4. A …………………………………is where a group of individuals join together to achieve

a common purpose.

- A public limited company

- B cooperative

C private limited company

D stock exchange

Answer \_\_\_\_\_\_\_\_

5. A franchisee is an individual or business that

- A buys a patent to operate a franchise business

- B sells a patent to operate a franchise business

- C borrows a patent to operate a franchise business

- D lends a patent to operate a franchise business

Answer \_\_\_\_\_\_\_\_

## Question 2

Read the case study below and carry out the activity that follows in the space provided.

## The Story of HS Co. Ltd

Harris and Saaran set up a private company limited, H &amp; S Co Ltd, to launch a  line  of  fashion  clothes.  Supported  by  a    strong  team  of  employees,  the enterprise grew successful. One of its best T-shirts, branded as 'San Smith' , became  very  popular  in  several  foreign  countries.  The  company  received several proposals to franchise the popular designer clothes.

<!-- image -->

<!-- image -->

- (a) Explain the following terms:

Private limited company

Franchise

- (b) State one difference between a private limited company and a public limited company.

….…………………………………………………………………………………………

….…………………………………………………………………………………………

- (c) Some entrepreneurs have showed interest in setting up a franchise to sell 'San Smith' T-shirts produced by H &amp; S Co Ltd.  Identify and explain two reasons an entrepreneur would prefer a franchise business rather setting up his own enterprise.

Reason 1

Reason 2

KEY TERMS

Company is an incorporated business organisation which is owned by its shareholders.

Cooperative is a business organisation which is owned and managed jointly by its members who share the profits or benefits.

Franchise is an enterprise that has a license from a franchisor to sell its products or services.

In this image we can see a person with a suit and tie is standing and holding a hand of a person with a suit and tie.

<!-- image -->

The entrepreneur as a leader

Unit 2 The entrepreneur as a leader

## Learning Objectives:

## On completing this unit, you will be able to:

- outline functions of an entrepreneur
- recognise the responsibilities of an entrepreneur
- explain the qualities of a leader entrepreneur
- explain the role of stakeholders in the enterprise
- describe how to manage risks in an enterprise

In  this  unit,  you  will  learn  the  functions,  responsibilities  and  qualities of an entrepreneur. You will also discover the role of stakeholders in an enterprise and how entrepreneurs manage risks in an organisation.

## 2.1 The entrepreneur

An entrepreneur is  an  individual  who  sets  up  an  enterprise  by taking risks and who aims at making profit. The entrepreneur has a business idea and works towards making the enterprise successful.

## 2.1.1 Functions of an entrepreneur

An entrepreneur is an individual  who  sets  up  an enterprise by taking risks and who aims at making profit.

Entrepreneurs, as managers of enterprises, undertake several tasks to run their businesses effectively. Being an entrepreneur is challenging as he is the leader of the enterprise and he fulfills a number of functions.The main functions of someone who manages an enterprise are illustrated below.

The image is a diagrammatic representation of a planning and staffing system for an organization. The diagram is divided into five main sections, each representing a different aspect of the planning and staffing system. Here is a detailed description of each section:

1. **Planning Section**:
   - **Title**: "Planning"
   - **Description**: The section is titled "Planning" and lists the following tasks:
     - "Controlling"
     - "Organising"
     - "Staffing"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"
     - "Controlling"

<!-- image -->

Figure 1: Functions of an entrepreneur

| Functions   | Explanation                                                                                 |
|-------------|---------------------------------------------------------------------------------------------|
| Planning    | The process of choosing a business idea , setting objectives and anticipating risks .       |
| Organising  | Bringing in resources into the organisation to meet the objectives set by the entrepreneur. |
| Staffing    | Hiring people to work in the enterprise.                                                    |
| Leading     | Directing employees towards the objectives of the enterprise.                               |
| Controlling | Ensuring that tasks are being done according to the expectations of the entrepreneur.       |

<!-- image -->

Fill in the blanks with the appropriate words given below.

| motivates resources controlling planning objectives manager                                                                                                                                                                                                                |                                                                                                                                                                                                                                                                            |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Fanny is the owner of Sunrise Enterprise. She is also the ………………… of the business. Shesetsthe…………………………..ofthebusiness.………………………. and …………………are two functions that Fanny undertakes in the enterprise. She organisesthe…………………………….sothatproductioncantakeplaceontime.She | Fanny is the owner of Sunrise Enterprise. She is also the ………………… of the business. Shesetsthe…………………………..ofthebusiness.………………………. and …………………are two functions that Fanny undertakes in the enterprise. She organisesthe…………………………….sothatproductioncantakeplaceontime.She |

## 2.1.2 Responsibilities of an entrepreneur

Below are the main responsibilities of an entrepreneur.

Figure 2: Responsibilities of an entrepreneur

In this image there is a diagram with five different shapes and text.

<!-- image -->

<!-- image -->

## Read the case study below and answer the questions which follow.

Jasveen  is  the  owner  of  a  successful  textile  factory.  He  shoulders  a  number  of responsibilities daily. Below is an extract of his diary.

## A day in Jasveen's life

08.00

Meeting with factory supervisors

08.30

Visit factory

10.30

Call suppliers to order raw materials

11.30

Discuss with the marketing department to

advertise the products

12.00

Attend meetings with customers

14.00

Conduct interviews with applicants

15.45

Discuss with finance managers

18.00

Solve issues related to machinery

19.00

Plan for tomorrow

In this image we can see a paper with some text written on it.

<!-- image -->

- (a) List three responsibilities of Jasveen as the entrepreneur.

Responsibility 1

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Responsibility 2

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Responsibility 3

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 2.1.3 Qualities of a leader entrepreneur

Successful entrepreneurs have a number of qualities. One distinct quality is the ability to lead the enterprise. The following are the qualities that make the entrepreneur successful.

|   1 | Innovative - The entrepreneur comes up with new ways of doing things.                             |
|-----|---------------------------------------------------------------------------------------------------|
|   2 | Skilful - The entrepreneur develops a number of abilities to operate.                             |
|   3 | Intelligent - The entrepreneur is able to take right decisions.                                   |
|   4 | Risk taker - The entrepreneur takes calculated risks when operating the business.                 |
|   5 | Self-confident -Theentrepreneur believes in his abilities to achieve the goals of the enterprise. |
|   6 | Passionate -Theentrepreneurismotivatedandhasastrongdrivetomakethebusinesssuccessful.              |

## 2.2  Stakeholders

Stakeholders are  people,  groups  or  organisations  that take interest in activities and decisions taken by a business.

Stakeholders are people, groups or organisations that take interest in activities and decisions taken by a business.

## 2.2.1 Roles and objectives of stakeholders

The table below describes stakeholders, their roles and their objectives.

|    | Role of stakeholders                                                                                                       | Objectives of stakeholders                                                       |
|----|----------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
|  1 | Owners set up enterprise.                                                                                                  | • To maximise profits • To expand the business                                   |
|  2 | Managers organise and run the business. • •                                                                                | To drive the enterprise to success To earn high salaries • To have a secured job |
|  3 | Employees are the workers and they spend significant time in the organisation. • To earn a and • To ensure secured         | fair pay (wages salaries) their jobs are                                         |
|  4 | Suppliers provide raw materials and other input to the enterprise. • To have a for goods                                   | timely payment supplied to the enterprise                                        |
|  5 | Consumers are the buyers of the goods and services that the enterprise provides on the market. • To ensure safe, value for | reliable and money products                                                      |
|  6 | Government regulates and monitors the running of businesses.                                                               | • To ensure that jobs are created • To ensure that the enterprise abides by laws |
|  7 | The society includes people or groups whoaredirectlyorindirectlyinfluenced by the activities of the enterprise. •          | To ensure that the activities of the enterprises do not harm the society         |

<!-- image -->

Match each term in column A with the corresponding explanation in column B. Write your answers in the table which follows.

|              |   ColumnA |                                                                                                                            | Column B   |
|--------------|-----------|----------------------------------------------------------------------------------------------------------------------------|------------|
| Society      |         1 | Peoplewhoworkinanenterpriseandareinterestedinearninghighwages.                                                             | A          |
| Owners       |         2 | Peoplewhomanageandorganisetheactivitiesofanenterprise.                                                                     | B          |
| Employees    |         3 | Authority and institutions that regulate the operations of an enterprise through legislations.                             | C          |
| Stakeholders |         4 | Pressure groups and members of the public who are interested in the operations of the business anditsimpactonthecommunity. | D          |
| Managers     |         5 | People or firms who provide materials, components and services to the business.                                            | E          |
| Government   |         6 | People who have put their money as capital in the enterprise.                                                              | F          |
| Suppliers    |         7 | Buyerofgoodsandservicesprovidedbyenterpriseonthemarket.                                                                    | G          |
| Consumers    |         8 | Individuals or groups that have an interest in the success and progress of a company.                                      | H          |

| ColumnA   | A   | B   | C   | D   | E   | F   | G   | H   |
|-----------|-----|-----|-----|-----|-----|-----|-----|-----|
| Column B  |     |     |     |     |     |     |     |     |

## 2.3 Managing risks in an enterprise

Businesses  are  usually  exposed  to  risks.  Any  factor  that threatens an enterprise's ability to achieve its goals is called business risk .

Business risk refers to any factor that represents a threat to an enterprise's ability to achieve its goals.

## 2.3.1  Types of risk

There are many types of risks that a business might face. These can be grouped into four types as explained below:

| Types of risk     | Explanation                                                                         |
|-------------------|-------------------------------------------------------------------------------------|
| Strategic risks   | Chances of business failure due to poor business objectives , causing heavy losses. |
| Operational risks | Chances of business failure due to the poor running of the daily activities .       |
| Financial risks   | Chances of business failure due to poorly managedfinance .                          |
| Compliance risks  | Chancesofbusinessfailureasenterprises failtofollowlawsandregulations .              |

<!-- image -->

For each of the following situations, match Column A with the Types of risks faced by Trois Soleils pastry shop.

| Trois Soleils Enterprise   | Trois Soleils Enterprise                                                            | Trois Soleils Enterprise   | Trois Soleils Enterprise   |
|----------------------------|-------------------------------------------------------------------------------------|----------------------------|----------------------------|
|                            | ColumnA                                                                             |                            | Type of risks              |
| 1                          | Trois Soleils was selling its products at lower prices and earning low profits.     | A                          | Operational risk           |
| 2                          | Trois Soleils wasted its resources due to its poorly managed day-to-day activities. | B                          | Strategic risk             |
| 3                          | Trois Soleils set the wrong business objectives for the year ahead.                 | C                          | Compliance risk            |
| 4                          | Trois Soleils did not follow the laws that apply to hygiene in food production.     | D                          | Financial risk             |

| ColumnA       | 1   | 2   | 3   | 4   |
|---------------|-----|-----|-----|-----|
| Type of risks |     |     |     |     |

Managing risks is an important task to every entrepreneur. Five steps of risks management are:

Identify potential risk(s)

Assess the impact of loss

Develop a plan to mitigate the risk(s)

Implement the plan

Review and evaluate the plan

STEP 1

STEP 2

STEP 4

STEP 3

STEP 5

Figure 4: Steps of risk management

In this image, we can see a table with some text and numbers.

<!-- image -->

## 2.3.2  Dealing with risks

Business risks can occur at any time. It can be at the start of a business or even when launching a new product on the market. Entrepreneurs who have the ability to bear any kind of risk and who react positively to risky situations are better prepared entrepreneurs.

The table below analyses how to deal with some business risks.

|                                                              | Situation                                     | Decision taken                 | Negative effects                                               | Mistake                                                    | Right decision                                       |
|--------------------------------------------------------------|-----------------------------------------------|--------------------------------|----------------------------------------------------------------|------------------------------------------------------------|------------------------------------------------------|
| 1 Anentrepreneur has to decide about the location of hisshop | Thelocation is in anisolated area             | •Fewcustomers • Lowsales       | Wrongchoice of location                                        |                                                            | To choose a better location in a busy area.          |
| 2 Preparation of financial records                           | To record financial information manually from | piles of papers                | Timeconsuming exerciseand difficult to collect all information | Poor record keeping                                        | To use a computerised recording of data              |
| 3 To improve quality the product                             | of                                            | Addnew ingredients             | Productwas foundwithmore harmful additives                     | Laboratory testswere not carried out                       | To use quality ingredientsand carry laboratory tests |
| 4 To increase                                                | revenue                                       | Price of the product increased | Sales fellandso revenue fell                                   | Setting high price without anticipating customer behaviour | To makeprior calculation before setting price        |

Table 4: Dealing with risks

<!-- image -->

Complete the table below using the given statements.

| Decrease price        | Locatefactoryinaremotearea   | Pollutionlevelnotmeasured   |
|-----------------------|------------------------------|-----------------------------|
| Further fall in sales | Buycheaprawmaterials         | Control cost                |

|    | Situation                       | Decision taken                | Negative effects              | Mistake                       | Right decision                |
|----|---------------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|
|  1 | Choosing a site for a factory   | Close to a residential area   | Protests by pressure groups   | ............................. | ............................. |
|  2 | Fall in sales                   | Increase price                | ............................. | Wrong pricing                 | ............................. |
|  3 | Increase in costs of production | ............................. | Poor quality of products      | Inferior raw materials        | ............................. |

<!-- image -->

1. Multiple Choice Questions

Choose the correct answer for each of the questions below and write it in the space provided.

1. The function of an entrepreneur when setting objectives is

- A   planning

B   organising

C   leading

D   controlling

Answer \_\_\_\_\_\_\_\_

- 2.

- A person who organises, manages and assumes the risks of starting and operating a business to make a profit is called a(n)

A  entrepreneur

B  investor

C  trader

D  shareholder

Answer \_\_\_\_\_\_\_\_

3. Ensuring that tasks are done according to the expectations of the entrepreneur is

- known as

A  planning

B  controlling            C  organising

D  staffing

Answer \_\_\_\_\_\_\_\_

4. Which of the following is not considered as an essential quality of an entrepreneur?

- A   passion

B   creativity

C   luck

D  perseverance

Answer \_\_\_\_\_\_\_\_

5. Which one of the following statements about stakeholder groups is accurate?

- A   Stakeholders are people who are not interested in the business

- B   Stakeholder groups have direct interest in the business

- C   Shareholders of a company do not form part of a stakeholder group

- D   Stakeholders are people who are only interested in profits of the enterprise

Answer \_\_\_\_\_\_\_\_

<!-- image -->

6. The community, as a stakeholder, is concerned about

- A   Wage levels, costs and prices

- B   Profit levels, dividend payments and share price

- C   Job creation, job security and level of pollution

- D   Level of pollution, tax payment and profit

Answer \_\_\_\_\_\_\_\_

7. Risks related to the safety of employees in the workplace are associated with

- A   strategic risks

- B   operational risks

- C   compliance risks

- D   financial risks

Answer \_\_\_\_\_\_\_\_

8. Which of the following stakeholder is most interested in profit?

- A   Staff

- B    Customers

C   Owners

D   Society

Answer \_\_\_\_\_\_\_\_

9. Employees are mostly interested in

- A   safe products and good conditions of work

- B   good conditions of work and reasonable pay

- C   profit and reasonable pay

- D   poor conditions of work and low pay

Answer \_\_\_\_\_\_\_\_

KEY TERMS

Business risks refer to any factor that represent a threat to an enterprise's ability to achieve its goals.

Entrepreneur is an individual who sets up an enterprise by taking risks and aims at making profit.

Stakeholders are people, groups or organisations that take interest in activities and decisions taken by a business.

Entrepreneurial skills

Entrepreneurial

## Unit 3 skills

## Learning Objectives:

## On completing this unit, you will be able to:

- understand the terms 'communication' and 'communication process'
- explain the importance of effective communication in an enterprise
- describe the forms of communication in an enterprise
- explain how to resolve conflicts in an enterprise

In this unit, you will learn about communication, effective communication and the importance of communication in an enterprise. You will explore different forms of effective communication and understand that communication is a key entrepreneurial skill. You will also discover how to resolve conflicts in an enterprise.

## 3.1 Communication

Communication is  the  exchange  and  flow  of  information, ideas,  thoughts  and  feelings  from  one  person  to  another. Entrepreneurs  communicate  with  various  stakeholders  in order to convey messages during their business activities.

Communication is  the  exchange and flow of information, ideas, thoughts  and  feelings  from  one person to another.

## 3.1.1   Communication process

The communication process shows the flow of information from the sender (the transmitter) to the receiver (the recipient). It is illustrated below.

The image depicts a circular diagram with two main components: a person and a receiver. The person is positioned at the top of the diagram, and the receiver is positioned at the bottom.

**Person:**
- The person is depicted with a simple, cartoonish face.
- The person has short, dark hair and is wearing a light-colored shirt.
- The person is smiling and has a friendly expression.

**Receiver:**
- The receiver is depicted with a more detailed and detailed face.
- The receiver has light-colored hair and is wearing a light-colored shirt.
- The receiver is also smiling and has a friendly expression.

**Circular Diagram:**
- The diagram is circular, with a single person at the top and a single receiver at the bottom.
- The person is positioned at the top of the diagram, and the receiver is positioned at the bottom.
- The person is positioned at the top of the

<!-- image -->

## Feedback

Figure 1: The communication process

There are five important features in the communication process.

Message: The information being passed on.

3

In this image, we can see two people. One person is wearing a pink shirt and the other person is wearing a blue shirt. We can also see a red arrow.

<!-- image -->

Medium of communication is a means used to send a message for examples, letters, emails, phone calls or meetings.

on information to others. 1

<!-- image -->

Sender: the person who passes

Receiver: the person to whom the message is sent.

Feedback: the reply from the receiver to confirm receipt and understanding of the message.

<!-- image -->

## Read the short case study below and answer the questions which follow.

New Stationery Ltd is a manufacturer of stationery products. Ali, the  marketing  manager  phoned  Aryan,  his  sales  manager,  to discuss and seek his support about the launching of a new multicoloured pen. The latter gave a positive reply on Ali's views on the launch and agreed to extend his support to Ali.

<!-- image -->

- (a) What do you understand by the term 'communication'?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Identify the sender and the receiver.

Sender:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Receiver:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) What is the medium of communication used?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) What is the importance of feedback when people communicate with each other?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 3.1.2 Effective communication

An entrepreneur needs to communicate effectively with employees, customers, suppliers and other organisations for the smooth running of an enterprise.

Effective  communication is  a  twoway process between the sender and the receiver, where a feedback is provided.

Effective communication is a two-way process between the sender and the receiver, where a feedback is provided.

Figure 3: Effective communication

<!-- image -->

However, there are different circumstances where communication tends to be ineffective. This occurs when there are disruptions or failures in the communication process.

Figure 4: Ineffective communication

<!-- image -->

Ineffective  communication can have serious consequences for enterprises. Below are some common causes of ineffective communication.

Figure 5: Causes of ineffective communication

| Language: a sender speaks in a language which the receiver does not understand   |
|----------------------------------------------------------------------------------|
| Medium: writing a message to a person whohas difficulties to read                |
| Technical problems: computer failure can prevent a message from being sent       |
| Distractions: noise or bad reception causing the message to be poorly exchanged  |

<!-- image -->

For each of the following, tick (     ) the appropriate column to indicate whether it is an example of effective or ineffective communication.

|    |                                                                                                         | Effective communication   | Ineffective communication   |
|----|---------------------------------------------------------------------------------------------------------|---------------------------|-----------------------------|
|  1 | Chan, the entrepreneur, while discussing about a new product in a meeting, receives immediate feedback. |                           |                             |
|  2 | Eric has sent an email to a supplier but receives no reply.                                             |                           |                             |
|  3 | Agoodlistener usually hears, understands andresponds to a message.                                      |                           |                             |
|  4 | Sandra, the owner, is using technical terms in her conversation which the employees cannot understand.  |                           |                             |
|  5 | Writing a message on the noticeboard which is difficult to read by the employees.                       |                           |                             |

## 3.2  Importance of effective communication in an enterprise

Effective communication is vital for an enterprise for the following reasons.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Effective communication leads to orders placed on time

Employees know about job expectations

The enterprise is able to meet customers' orders on time

It leads to quicker decisions taken by the entrepreneur

## 3.3 Forms of communication in an enterprise

Entrepreneurs use different forms of communication to pass on information effectively. These are outlined below.

| Verbal communication                                                                                                    | Examples                 | Examples           |
|-------------------------------------------------------------------------------------------------------------------------|--------------------------|--------------------|
| Verbal communication is the oral exchange of information through spoken words.                                          | A telephone conversation | Meeting            |
| Non-verbal communication                                                                                                |                          |                    |
| Non-verbal communication is the exchange of information through body language without using any spoken or written word. | A handshake              | Facial expressions |
| Written communication                                                                                                   |                          |                    |
| Written communication is the exchange of information through the use of written words.                                  | A business letter        | A business plan    |
| Visual communication                                                                                                    |                          |                    |
| Visual communication is done through visual aids to represent information.                                              | A chart                  | A logo             |

Table 1: Common forms of communication

In this image, we can see a chart and some text.

<!-- image -->

In  choosing an appropriate communication method, factors such as speed, cost, the target audience, importance of a written record, importance of feedback are taken into consideration.

<!-- image -->

## Write down each of the following forms of communication under the correct heading in the table below.

Face-to-face conversation

Noticeboard                      Logo

Letter

Social media                      Newsletter

Email

Diagram                              Telephone conversation

Reports

Meeting                               Fax

Chart

Graph

Text message

<!-- image -->

In groups of  4, discuss the importance of effective communication to both the entrepreneur and his employees when an important order has been placed by a customer.

## 3.4 Internal and external communication

Entrepreneurs communicate with stakeholders both inside and outside the business. Therefore, communication can be classified as internal and external .

## Communication

Internal communication takes place among people within the enterprise itself.

External communication takes place when enterprises communicate with stakeholders outside the business.

Stakeholders involved:

1. The entrepreneur
2. Managers
3. Employees

Stakeholders involved:

1. Suppliers
2. Customers
3. Banks
4. Government

Figure 8: Internal and external communication

| Examples of internal communication                              | Examples of external communication                                     |
|-----------------------------------------------------------------|------------------------------------------------------------------------|
| Manager gives instructions to employees about tasks to perform. | The entrepreneur communicates with the bank while applying for a loan. |
| Employees send emails to their colleagues about teamwork.       | The sales manager communicates with suppliers.                         |

Table 2: Examples of internal and external communication

<!-- image -->

For each of the following, tick (   ) the appropriate column to indicate whether internal or external communication is taking place.

|      |                                                                                 | Internal communication   | External communication   |
|------|---------------------------------------------------------------------------------|--------------------------|--------------------------|
| (a)  | Ria, the owner is holding a conversation with the machine operator.             |                          |                          |
| (b)  | Advertisement for a new product in the newspaper.                               |                          |                          |
| (c)  | An entrepreneur sends a quotation to a customer.                                |                          |                          |
| (d)  | Meeting employees to discuss safety issues at work.                             |                          |                          |
| (e)  | Informing customers about a promotional offer on the website of the enterprise. |                          |                          |
| (f ) | Asking an employee to pass on a message to his colleague.                       |                          |                          |

## 3.5 Conflicts in an enterprise

People  working  in  an  enterprise  may  have  different  opinions  and  perceptions  leading  to conflicts.

Conflict is  a  situation  in  which  there  is  a  disagreement  or disapproval with another person, or within a group.

If conflict is not settled, it can lead to inappropriate behaviour of employees that prevent them from working towards a common goal.

Conflict is a situation in which there is a disagreement or  disapproval  with  another person, or within a group.

Entrepreneurs should be aware of types of conflicts that may arise during business activities.

| Reasons conflicts mayarise                                           |
|----------------------------------------------------------------------|
| > due to disagreements on the goals and objectives of the enterprise |
| > on the attitudes and behaviours of people working together         |
| > over the process of getting tasks done                             |

Table 3: Reasons of conflicts in an enterprise

Table 4: Examples of conflicts in an enterprise

| Somecommonexamplesof conflicts are stated below.            |
|-------------------------------------------------------------|
| > Disagreement on allocation of work and responsibilities   |
| > Ineffective communication between the owner and employees |
| > Rivalry among staff members                               |

## 3.5.1 Resolving conflicts in an enterprise

Conflicts allow to identify problems that need to be solved and help to strengthen the enterprise. There is no one solution which fits everyone.  Each  conflict  has  different  causes and they can be resolved in different ways as shown in Figure 9.

In this image, we can see a diagram with some text and icons.

<!-- image -->

<!-- image -->

## State whether the following statements are True or False.

| (a)   | Whendiscussing an issue, communication should be effective.                                                     |
|-------|-----------------------------------------------------------------------------------------------------------------|
| (b)   | The entrepreneur should try to solve a problem only when he is angry.                                           |
| (c)   | The entrepreneur should listen to the views of employees when making decisions.                                 |
| (d)   | The goal of resolving conflict is to work towards a solution where all parties are satisfied with the solution. |

<!-- image -->

## Read the case study below and answer the questions which follow.

Mira is the owner of a florist shop. She has been operating her small enterprise for three years and has loyal customers. Mira decided to form a partnership with her friend Jenny in order to expand the enterprise.

Later on, disagreements started to arise on the following issues.

- Jenny complained that her responsibilities were too bulky.
- Mira complained that Jenny was taking extra holidays.
- Mira felt like Jenny started to exert more power and influence.

<!-- image -->

- (a) Define the term 'conflict'.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Identify two conflicts that Mira is feeling concerned about.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) State three ways Mira could use to reduce the conflicts in her enterprise.

(1)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(2)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(3)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## Question 1

## Identify which form of communication  (verbal, written or visual) is being used in the table below.

|      |                                                                                            | Form of communication   |
|------|--------------------------------------------------------------------------------------------|-------------------------|
| (a)  | Two employees are talking about a lost order.                                              |                         |
| (b)  | A report about last month sales figures.                                                   |                         |
| (c)  | A poster displaying a health warning.                                                      |                         |
| (d)  | An email sent to employees informing them about a fun day to be organised by the business. |                         |
| (e)  | The owner receiving an application letter for a job.                                       |                         |
| (f ) | Abusiness advertises a price cut of 10%onallproducts in the newspaper.                     |                         |

## Question 2

Match each term in column A with the corresponding definition in column B. Write your answers in the table which follows.

|               | ColumnA                |    | Column B                                                                                           |
|---------------|------------------------|----|----------------------------------------------------------------------------------------------------|
| Communication | 1                      |    | A When enterprises communicate with stakeholders outside the business.                             |
| B Effective   | communication          | 2  | A situation in which there is a disagreement or disapproval with another person or within a group. |
| C Internal    | communication          | 3  | The exchange and flow of information, ideas, thoughts and feelings from one person to another.     |
| D             | External communication | 4  | Exchange of information takes place among people within the enterprise itself.                     |
| E             | Conflict               | 5  | A two-way process between the sender and the receiver, where a feedback is provided.               |

| ColumnA   | A   | B   | C   | D   | E   |
|-----------|-----|-----|-----|-----|-----|
| Column B  |     |     |     |     |     |

## Question 3

## Read the case study below and answer the questions which follow.

## Jeremy Car Garage

Jeremy, the owner of a small car garage, needs additional spare parts for cars. On Monday, he called the supplier to place an order and was told that, after three days, he would receive  the  delivery.  However,  the  correct  items  were not delivered and Jeremy was worried about having inadequate and wrong spare parts in his stock.

<!-- image -->

- (a) Identify the communication method used by Jeremy.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) What went wrong with the delivery of spare parts?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Did Jeremy choose the right communication method to place the order from the supplier? Explain your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) Suggest a more effective communication method that Jeremy could have used in this case.

- Give reasons for your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

KEY TERMS

Communication is the exchange and flow of information, ideas, thoughts and feelings from one person to another.

Conflict is a situation in which there is a disagreement or disapproval with another person or within a group.

Effective communication is a two-way process between the sender and the receiver where a feedback is provided.

In this image, we can see some text and some icons.

<!-- image -->

Marketing

Unit 4 Marketing

## Learning Objectives:

## On completing this unit, you will be able to:

- differentiate between selling and marketing
- explain market research
- describe the key elements of marketing
- understand methods of e-marketing and its importance

In  this  unit,  you  will  learn  about  marketing  and  the  difference  between selling and marketing. You will be exposed to the importance of market and market research. You will, also, discover the key elements of marketing. The opportunities offered by e-marketing are also addressed in this unit.

## 4.1 Marketing

Marketing is  the process of identifying the needs of customers and attempting to satisfy them. Businesses carry out marketing in one form or another as it is an important business activity.

Marketing is the process of identifying the needs of customers and attempting to satisfy them.

The role of marketing is to ensure that the product of a business meets customers' needs and wants. Effective marketing is essential to the success of an enterprise.

## 4.1.1 Selling versus marketing

Kate is an entrepreneur who makes pickles. Her friend, Davis, comes to visit her and they have the following conversation.

<!-- image -->

Hello Kate. What are you doing?

Hello Davis, I am preparing some pickles which I am going to sell to customers.

Why don't you do some marketing for your products?

<!-- image -->

I usually do the selling of my products, but what do you mean by marketing?

<!-- image -->

Selling is concerned with exchanging a product for cash whereas marketing is the process of identifying the needs of customers and attempting to satisfy them.

Selling is concerned with exchanging a product for cash.

<!-- image -->

The figure below illustrates some of the main differences between selling and marketing.

<!-- image -->

## Selling

- Emphasis is on the product.
- Product first, then customer - first, the business makes the product and then tries to sell it.

<!-- image -->

## Marketing

- Emphasis is on the customer's needs.
- Customer first, then the product - first the business identifies the customer's needs and wants and then produces them.

Figure 1: Differences between selling and marketing

## 4.2 Knowing your market

Entrepreneurs usually ask several questions before launching a product on the market. Below are some common questions.

In this image we can see a diagram. In the diagram we can see a question mark. There are arrows.

<!-- image -->

## Target market:

To which group of customers will the product be sold? Example: teenagers, youngsters, adults.

## Customers' tastes and preferences:

What are  customers' expectations regarding design and quality?

## Pricing of the products:

At what price should the product be sold?

## Competitors:

Who are my competitors and what should I do to compete with them?

## Channel of distribution:

How will the products be sold?

Example, through sales agents, in shops or the internet.

## Advertising media:

How will the products be advertised?

Example, in newspapers, billboards or social media.

<!-- image -->

Joshua has set up an enterprise to manufacture paper bags.

State whether the following statements are True or False.

<!-- image -->

- (a) Marketing involves identifying and satisfying needs and wants of customers.

- (b) Joshua does not need to identify a target market before starting to produce paper bags.

- (c) Joshua believes that marketing is only about selling products to customers.

- (d) Through proper marketing activities, Joshua's enterprise is more likely to be successful.

## 4.2.1 Market research

Customers' needs and wants are identified and anticipated through market  research. Market  research is  the  process  of  collecting and analysing data about customers and the market. Thereafter, an  entrepreneur  can  decide  about  the  product  design,  pricing, advertising and how to make the product available to customers.

Market research is the process  of  collecting  and analysing data about customers and the market.

Market research is important for the following reasons.

Market research helps to identify the needs and wants of customers

It  allows  an  enterprise  to  respond  quickly  to  changes  in  customers'  preferences

Market research helps a business to plan its marketing activities

It helps an entrepreneur to launch new products with greater confidence

<!-- image -->

## Answer the following questions.

1. Define the term 'market research'.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Explain three reasons why market research is important.

Reason 1

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason 2

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason 3

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 4.3 Elements of marketing

When  an  entrepreneur  starts  an  enterprise,  the  following  elements  of  marketing  must  be considered. They are also known as the 4 Ps . These are as follows.

## THE 4 Ps OF MARKETING

Figure 4: Elements of marketing - 4 Ps

In this image we can see a diagram. In the diagram we can see four circles. In the circles we can see the text and numbers.

<!-- image -->

## 4.3.1 Product

Product refers  to  the  goods  and  services  produced  by an  enterprise  to  satisfy  customers'  needs  or  wants.  The entrepreneur should make his product marketable.

A marketable  product is  a  product  which  consumers need and will be ready to buy.

Product refers  to  the  goods  and services  produced  by  an  enterprise to satisfy customers' needs or wants.

A marketable product is  a  product which  consumers  need  and  will  be ready to buy.

The diagram below shows some important characteristics of a marketable product.

In this image there is a diagram with some text and a logo.

<!-- image -->

Figure 5: Characteristics of a marketable product

<!-- image -->

## Answer the following questions.

1. Identify four elements of marketing.

Element 1:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Element 2:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Element 3:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Element 4:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Distinguish between a product and a marketable product.

A product is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

whereas a marketable product is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Hema makes party snacks which she sells to her neighbours and nearby shops.

State three characteristics that you consider will make the party snacks a marketable product.

Characteristic 1:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Characteristic 2:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Characteristic 3:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 4.3.2 Price

Entrepreneurs  should  sell  their  products  at  convenient  prices. Price refers to the amount of money paid by the customer when buying a good or service.

<!-- image -->

The entrepreneur should consider some factors when setting the price.

<!-- image -->

Cost of production Prices  of  commodities are usually set to cover the cost of production.

<!-- image -->

<!-- image -->

Ability to pay Low prices are charged for low income groups and higher prices to high income groups.

Price competition Prices are lowered to attract more customers from the existing competitors.

Figure 6: Factors to consider when setting the price

There are a range of pricing methods. Below are some common pricing methods an entrepreneur can adopt.

<!-- image -->

Setting a low price to attract customers to buy a new product. This is known as penetration pricing.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Setting a high price for a high quality product that is unique on the market. This is known as premium pricing.

Setting the price by adding up cost per unit to % of profits. This is known as cost plus pricing.

Reducing the price of a product or service for a short period of time. This is known as promotional pricing.

Setting  the  price  to  similar  products  in  the  market.  This  is  known  as competitive pricing.

Price refers to the amount of money paid by the customer  when  buying  a good or service.

<!-- image -->

Match each pricing method in column A with the corresponding situation in column B. Write your answers in the table which follows.

|    | ColumnA             |    | Column B                                                                                                                                 |
|----|---------------------|----|------------------------------------------------------------------------------------------------------------------------------------------|
| A  | Cost-plus pricing 1 |    | Miguel has recently opened a stall selling fresh juice. He set a low price to attract customers.                                         |
| B  | Penetration pricing | 2  | The owner of'Celo Bags'adds a 50% profit to the cost of a bag to set the selling price.                                                  |
| C  | Competitive pricing | 3  | A hairdresser improved his services by using high quality products for hair treatment. He, now, charges a very high price for a haircut. |
| D  | Premium pricing     | 4  | 'Future Fashion'is offering the sale of pullovers at a lower price because the winter season is coming to an end.                        |
| E  | Promotional pricing | 5  | 'Good furniture'has set the price of furniture to be similar to other furniture shops.                                                   |

| ColumnA   | A   | B   | C   | D   | E   |
|-----------|-----|-----|-----|-----|-----|
| Column B  |     |     |     |     |     |

## 4.3.3 Promotion

Promotion is about communicating with customers so as to encourage them to buy the products of an enterprise.

Promotion helps to raise awareness of the product, increases sales and improves the image of the business.

Promotion is about communicating with customers so as to encourage them  to  buy  the  products  of  an enterprise.

There are several ways to promote a product. The entrepreneur needs to decide about effective ways to do so. They are explained in the table below.

<!-- image -->

<!-- image -->

In this image we can see a person standing and holding a mobile phone. In the background there is a screen and a map.

<!-- image -->

| EXAMPLES                                                                                                                                                                                        | PROMOTION EXPLANATION   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------|
| Advertising is about informing or persuading consumers of products by using media such as newspapers or radio.                                                                                  | Advertising             |
| Sales promotion is r educing price or giving gifts to achieve short- term increases in sales.                                                                                                   | Sales promotion         |
| Personal selling is about the entrepreneur making face-to-face selling with a consumer with the aim of convincing him to buy the product. It usually helps to establish long-term relationship. | Personal selling        |
| Public relations is the use of free publicity through newspapers, TV and other media to improve image of the enterprise.                                                                        | Public relations        |
| Direct marketing involves making direct contact with consumers, for example, through telephone selling to present the products of the enterprise.                                               | Direct marketing        |

<!-- image -->

Table 1: Types of promotion

<!-- image -->

Fill in the blanks with the appropriate words given below.

public relations          personal selling         direct marketing

advertising          sales promotion

- (a) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is used to inform and persuade consumers to buy the products of

an enterprise.

- (b) A short term measure used to increase sales is known as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.
- (c)

By using press releases, \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is used to improve the image of the enterprise.

- (d) To obtain quick response, \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is used to make direct contact with consumers.

## 4.3.4 Place

An entrepreneur needs to find ways to distribute his/her products to  customers.  This  is  known  as  place. Place, as  an  element  of marketing, is about selecting an appropriate channel of distribution for products to reach customers.

Place is about selecting an  appropriate  channel  of distribution for products to reach customers.

A  channel  of  distribution  refers  to  the  link  a  product  passes  through  before  it  reaches  the consumer.

Entrepreneurs need to deliver products to consumers at the right time and in the right place. This will make products available to customers convieniently, that is, whenever and wherever it is suitable to them.

Below are some common distribution channels that enterprises usually adopt.

1. The producer (Enterprise) sells directly to the consumer.
2. The producer (Enterprise) sells to the retailer who sells to the consumer.
3. The producer (Enterprise) sells to the wholesaler who supplies to the retailer who sells to the consumer.

<!-- image -->

In this image, we can see a building, a person, a bag, a bag, a person, a bag, a person, a bag, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a

<!-- image -->

Producer                          Wholesaler

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Retailer

<!-- image -->

Consumer

In choosing a channel of distribution, entrepreneurs might consider the following factors.

In this image, we can see a table with some text and numbers.

<!-- image -->

Figure 9: Factors influencing choice of a distribution channel

<!-- image -->

For each of the following, identify the missing term in the distribution channel that could be used by the enterprise.

In this image, we can see a diagram with some text and a few lines.

<!-- image -->

## 4.4 Entrepreneurs and E-marketing

With the advent of technology, entrepreneurs are making use of internet as a tool to market their products and services. This is known as electronic marketing (e-marketing) or online marketing .

E-marketing refers  to  the process of marketing a product using internet.

## 4.4.1 Methods of E-Marketing

The following are methods of e-marketing usually used by enterprises to promote their products.

<!-- image -->

Web  marketing refers  to  promoting  products  or enterprises on the internet through websites.

<!-- image -->

Email  marketing refers  to  promoting  products through the use of email to customers.

<!-- image -->

Social  media marketing involves  the  use  of  social network like Facebook and Twitter to market products.

Figure 10: Methods of e-marketing

## 4.4.2 Importance of E-marketing

E-marketing is important to enterprises for the following reasons.

<!-- image -->

E-marketing is less costly because a large number of customers can be reached through electronic means.

It  allows buying and selling at odd hours, for instance, even when shops are closed.

<!-- image -->

With  the  use  of  technology,  businesses  can  communicate  more frequently  with customers and provide the latest information.

Entrepreneurs can gather information about how well their products are doing on the market through mini online feedback forms.

<!-- image -->

<!-- image -->

## State whether the following statements are True or False.

- (a) Marketing done via the internet is called online marketing or web marketing.

- (b) Email marketing allows subscribers to have specialised discounts and personalised offers.

- (c) Social media platforms can be accessed only during business hours.

- (d) E-marketing is not a quick method to reach customers.

<!-- image -->

## Read the case study below and answer the questions which follow.

## NewPaint

NewPaint is a business that sells paint products through its  website. In order to keep up with customers, Albert, the  owner  of  NewPaint,  shares  information  through various social media such as Facebook and YouTube. The enterprise also provides discount coupons on its website. NewPaint has a Facebook account which allow comments to show up on its wall. Albert considers e-marketing to be important for the growth of his enterprise.

<!-- image -->

- (a) Explain the term 'e-marketing'.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Identify two benefits to NewPaint of having a website.

Benefit 1

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Benefit 2

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Explain two ways e-marketing is important to Albert.

Importance 1

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Importance 2

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## Question 1

## Multiple Choice Questions Choose the correct answer for each of the questions below and write it in the space provided.

1. Marketing is a process which aims at \_\_\_\_\_\_\_\_\_\_\_\_.

- A delivery of goods to customers

C

satisfaction of customers' needs/wants

- B selling products only                                D

production

Answer:\_\_\_\_\_\_

2. In marketing, the term 'product' refers to

- A intangible items only

- B goods and services produced by an enterprise to satisfy a customers' needs/wants

C goods, services and ideas only

D advertising and promotions used

Answer:\_\_\_\_\_\_

3. Newsletters, catalogues and leaflets are most closely associated with \_\_\_\_\_\_\_\_\_\_\_\_.

- A pricing

C market research

- B distribution

D promotion

Answer:\_\_\_\_\_\_

4. Direct marketing refers to a communication between

A enterprise and employees directly

B price and services directly

C enterprise and customers directly

D government and society directly

Answer:\_\_\_\_\_\_

5. Rohan is a chef in a local restaurant. He has given a press release to the local media and has also invited press reporters for a lunch in his restaurant.

Rohan is engaging in \_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A

public relations

C

personal selling

- B advertising

D

sales promotion

Answer:\_\_\_\_\_\_\_

6. Price is important because

- A it is a cost to business

- C it brings revenue to the business

B it is a method of advertising

- D it is easy to calculate

Answer:\_\_\_\_\_\_\_\_

7. Place as an element of marketing is about

- A pricing decisions

C

offering discounts on products

- B packaging

D

choosing a channel of distribution

Answer:\_\_\_\_\_\_\_\_\_

## Question 2

## Read the case study below and answer the questions which follow.

## Mike's business

After working for several years in a prestigious hotel, Mike decided to start his own business. He made sauces and vinaigrettes that he sold at the local market.

Originally selling just a few flavours, Mike now offers a range of new products. He has developed a brand name for his products known as MSV sauces and has set a low price to attract more customers. Posters are found in shops where Mike's products are sold. His products are mostly sold through local shops, market fairs and online. He does not use any artificial ingredients. Mike buys his ingredients, such as chili peppers, locally. He believes in supporting local farmers to help the economy.

<!-- image -->

- (a) Identify the product that Mike is offering for sale.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) What are the unique features about Mike's products?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Explain why Mike has set a low price for his products.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) According to you, what other two methods of promotion Mike could have used to increase sales?

Method 1:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Method 2:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e) Identify and explain two factors that might have influenced the choice of the distribution channel used to sell MSV products.

Factor 1:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Factor 2:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Question 3

Match each term in column A with the corresponding definition in column B. Write your answers in the table which follows.

|                   | ColumnA   |                                                                                   | Column B                                                                          |
|-------------------|-----------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| Marketing         | 1         | Communicating with customers to encourage them buy the products of an enterprise. | A                                                                                 |
| B Market research | 2         |                                                                                   | The process of marketing a product using internet.                                |
| C Product         |           | 3 moneypaidbythecustomer for a goodorservice.                                     | The amountof                                                                      |
| D                 | Price     | 4 needs of customers and attempting to                                            | The process of identifying satisfy them.                                          |
| E Promotion       | 5         | produced by an enterprise to satisfy                                              | The goods and services customers' needs or wants.                                 |
| F Place           |           | 6 customers                                                                       | The process of collecting and analysing data about and the market.                |
| G E-              | marketing | 7                                                                                 | Selecting an appropriate channel of distribution for products to reach customers. |

| ColumnA   | A   | B   | C   | D   | E   | F   | G   |
|-----------|-----|-----|-----|-----|-----|-----|-----|
| Column B  |     |     |     |     |     |     |     |

<!-- image -->

## KEY TERMS

- E- marketing refers to the process of marketing a product using internet.

Marketable product is a product which consumers need and will be ready to buy.

Marketing is the process of identifying needs of customers and attempting to satisfy them.

Market research is the process of collecting and analysing data about customers and the market.

Place is about selecting an appropriate channel of distribution for products to reach customers.

Price refers to the amount of money paid by the customer when buying a good or service.

Product refers to the goods and services produced by an enterprise to satisfy a customers' needs or wants.

Promotion is about communicating with customers so as to encourage them to buy the products of an enterprise.

Selling is concerned with exchanging a product for cash.

In this image we can see a person sitting and holding a pen in his hand. There are some papers and a book on the table.

<!-- image -->

Business Plan

Unit 5 Business Plan

## Learning Objectives:

## On completing this unit, you will be able to:

- describe the term business plan
- outline the reasons for preparing a business plan
- write up a simple business plan

In  this  unit,  you  will  learn  about  the  importance  of  a  business  plan  to entrepreneurs and the different components of the document. You will also be involved in writing a simple business plan for an enterprise.

## 5.1 Business plan

## Read the story below.

Kevin's friend, Ruben, strongly advised him to prepare a business plan if he was to start up his enterprise. Ruben explained to him that a well-prepared business plan was the key to the success of an enterprise. The latter wanted to own and manage a supermarket that would sell a  variety  of farm and home-made products. Kevin wanted to know about the importance of a business plan.

In this image we can see a building with windows and a person standing in front of it. We can also see a street with a pole and a building with a roof. We can also see a few buildings and a sky with clouds.

<!-- image -->

A business plan is a document that contains a detailed plan to set up and develop an enterprise. The exercise of preparing a business plan encourages entrepreneurs to think through their business idea. While doing so, entrepreneurs will have to present maximum information about the enterprise.

A business plan is a document  that  contains  a detailed plan to set up and develop an enterprise.

There are likely to be several users of the business plan.

## Entrepreneurs themselves

Figure 1: Users of business plan

In this image, we can see a circle with some text and numbers.

<!-- image -->

## 5.2 Uses of business plan

A business plan has several uses.

A business plan can be used as a guide, as well as a decision-making tool for the entrepreneur.  The business ideas of the entrepreneur can be written down in detail. The reasons are explained in the table below.

## Reasons entrepreneurs prepare business plan

## A guide

Business ideas are presented clearly. Having clear ideas will avoid mistakes and reduce risks of failure. The estimates of costs and revenues can be calculated and profits or losses could be forecasted. Losses could be avoided.

To measure progress made by the business.

## A decision-making tool

To attract potential investors to the enterprise.

To apply for a bank loan.

Table1 : Uses of business plan

<!-- image -->

## Read the following mini story and state whether the following statements are True or False.

Bella is planning to open a shop to sell honey and home-made jam. A friend advised her to write a business plan.

<!-- image -->

| (a)   | A business plan provides information about the name of the enterprise and its location only.   |
|-------|------------------------------------------------------------------------------------------------|
| (b)   | Bella should prepare a business plan only if she applied for a bank loan.                      |
| (c)   | Bella could use a business plan to measure the progress of her enterprise.                     |
| (d)   | Small businesses do not need to prepare business plans.                                        |

## 5.3 Components of a business plan

The business plan consists of different components. They are shown below.

## 1. Information about the enterprise

Figure 2: Components of a business plan

In this image, we can see a diagram. There are four circles in the image. There are text written on the circles.

<!-- image -->

Benny was quite hesitant to write down his business plan as he did not know how to start doing it. He was advised by his friend, Mita, an experienced businesswoman, to ask a set of key questions. The questions are always related to the content of the business plan. The questions are found below.

## Questions that should be considered before preparing a business plan

What are the  business aim and objectives of the enterprise ?

Who will be the customers?

What prices should be charged for the products ?

Which resources would be required to start up the enterprise?

- What are customers' taste and preferences ?

Where should the products be sold?

- Who are the competitors?

What are the expected profits?

What type of enterprise should be set up?

The table below shows the type of information that is usually found in different components of the business plan.

Table 2 : Details of business plan

|   1 | Information about the enterprise   | Name of the enterprise Location of the business Contact details Type of business enterprise Incorporation date of the enterprise Start-up capital required Business idea Description of the product or service   |
|-----|------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|   2 | Humanresources                     | The number of workers required (if any)                                                                                                                                                                          |
|   3 | Operations                         | Units of goods to be produced by the enterprise                                                                                                                                                                  |
|   4 | Marketing                          | Strengths of the products Prices to be charged Advertising to be done Channels of distribution                                                                                                                   |
|   5 | Finances                           | Start-up capital required Expected expenses/revenue Profits or losses to be made                                                                                                                                 |

<!-- image -->

## Tick (     ) the appropriate column in which the details of the business plan should be found.

|      | Details                     | Informationabout theenterprise   | Human resources   | Operations   | Marketing   | Finances   |
|------|-----------------------------|----------------------------------|-------------------|--------------|-------------|------------|
| (a)  | Advertising                 |                                  |                   |              |             |            |
| (b)  | Business aim and objectives |                                  |                   |              |             |            |
| (c)  | Channels of distribution    |                                  |                   |              |             |            |
| (d)  | Description of the product  |                                  |                   |              |             |            |
| (e)  | Expected expenses/ revenue  |                                  |                   |              |             |            |
| (f ) | Name of the enterprise      |                                  |                   |              |             |            |

<!-- image -->

For each of the information in column 1, write down the component in which it should be explained in detail.

|      | Column 1                                        | Component of business plan   |
|------|-------------------------------------------------|------------------------------|
| (a)  | Prices to be charged                            |                              |
| (b)  | Profits or lossestobemade                       |                              |
| (c)  | Start-up capital required                       |                              |
| (d)  | Strengths of the products                       |                              |
| (e)  | The number of workers required (if any)         |                              |
| (f ) | Type of business enterprise                     |                              |
| (g)  | Units of goods to be produced by the enterprise |                              |

<!-- image -->

Why would a bank refuse to give a loan despite having the business plan of an enterprise?

## Presentation of a simple business plan

Below is a business plan of an entrepreneur, Zaha, who started a Fashion boutique. Zaha prepared this business plan to apply for bank loan. The information in a business plan was presented in an orderly manner and for two consecutive years to show her progress.

| Zaha Business Plan                   | Zaha Business Plan                                                                                       | Zaha Business Plan                                                                                       |
|--------------------------------------|----------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
| Details                              | Year 1                                                                                                   | Year 2                                                                                                   |
| Name of the enterprise               | Zaha Fashion Boutique                                                                                    | Zaha Fashion Boutique                                                                                    |
| Location of the business             | Ville des fleurs                                                                                         | Ville des fleurs                                                                                         |
| Contact details                      | zaha@enterprise.mu                                                                                       | zaha@enterprise.mu                                                                                       |
| Type of business enterprise          | Partnership                                                                                              | Partnership                                                                                              |
| Incorporation date of the enterprise | 13 May 2018                                                                                              | 13 May 2018                                                                                              |
| Start-up capital required            | Rs 2 million                                                                                             | Rs 2 million                                                                                             |
| Business aim and objectives          | To provide a high-class clothing for working men and women. To make a 10 %profit by the end of the year. | To provide a high-class clothing for working men and women. To make a 15 %profit by the end of the year. |
| Description of the products          | High quality fabrics for formal wear.                                                                    | High quality fabrics for formal wear.                                                                    |
| Number of workers                    | 2 machinists                                                                                             | 4 machinists                                                                                             |
| Strengths of the products            | Unique designs                                                                                           | Unique designs and high quality                                                                          |
| Prices to be charged                 | 10 %cost plus pricing                                                                                    | 12 %cost plus pricing                                                                                    |
| Advertising                          | Use of social media                                                                                      | Use of social media                                                                                      |
| Production                           | 6 000 outfits                                                                                            | 9 000 outfits                                                                                            |
| Expected expenses                    | Rs 500 000 per year                                                                                      | Rs 700 000 per year                                                                                      |
| Expected revenue                     | Rs 1 200 000 per year                                                                                    | Rs 1 800 000 per year                                                                                    |
| Profits or losses to be made         | Rs 700 000                                                                                               | Rs 1 100 000 per year                                                                                    |

<!-- image -->

## Question 1

In March 2020, Jean Ping is planning to set up a company, North West Company Ltd, to produce and sell hand-made miniature ships. Below are some details provided by Jean Ping about the enterprise.

| Details                              | Year 1                    |
|--------------------------------------|---------------------------|
| Name of the enterprise               | North West Company Ltd    |
| Contact details                      | bato@intnet.mu            |
| Incorporation date of the enterprise | 01 March 2020             |
| Description of the products          | Hand made miniature ships |
| Start-up capital required            | Rs 3 million              |
| Expected expenses                    | Rs 1 million per year     |
| Expected revenue                     | Rs 3 million per year     |

You have been requested to assist Jean Ping to prepare a business plan.

- (a) Identify five pieces of information that you would find important to include in a business plan.

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

- define the terms 'demand' and 'supply'
- analyse factors affecting demand and supply
- draw demand curve and supply curves
- show  an  understanding  of  movement  and  shift  in  demand  and  supply curves
- show and interpret equilibrium position

In  this  unit  you  will  learn  about  demand  and  supply  as  well  as  the  factors affecting them.  You will also read demand and supply diagrams and identify the equilibrium position.

## 6.1 The market

People usually satisfy their needs and wants by buying goods and services found in markets .  A  market is where buyers and sellers meet to exchange goods and services against a payment. Some examples of markets are shopping malls, vegetable market fairs, supermarkets as well as shopping websites like Ebay, AliExpress and Amazon.

A market is a where buyers and sellers meet to exchange goods and services against a payment.

In this image, we can see a picture of a market stall. There are people selling different things. We can see a person standing and holding a basket. We can see a cart with some objects. We can see a table with some objects. We can see a board with some text. We can see a pole with a board. We can see a tree. We can see the sky.

<!-- image -->

A seller (or  supplier)  is one  who  offers  goods and services,  usually  to make profits.

Figure 1: A market

There are markets for all types of goods and services. A few examples are given below.

<!-- image -->

Table 1: Examples of markets for goods and services

| Market   | Market       | Market   | Market   |
|----------|--------------|----------|----------|
| Goods    | Goods        | Services | Services |
| Shops    | Supermarkets | Clinic   | Cinema   |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## State whether the following statements are True or False.

| (a)   | A market is where buyers and sellers meet to exchange goods and services against a payment.   |
|-------|-----------------------------------------------------------------------------------------------|
| (b)   | A buyer purchases goods and services to satisfy his needs only.                               |
| (c)   | A seller usually aims at making profits.                                                      |
| (d)   | A market can only exist in a physical location.                                               |

## 6.2 Demand

When  people  express  their  willingness  to  buy  commodities,  it represents a demand for a commodity. For example, if people want to buy coconut water, there will be a demand for it.

However, effective demand takes place only when buyers have both the willingness  and  ability  to  buy  a  commodity  at  a  given price  over  a  given  period  of  time.  If  buyers  are  willing  but  not able to purchase coconut water, there will be no demand for the commodity.

<!-- image -->

Effective  demand is  the willingness and ability to buy a commodity at a given price over a given period of time.

Note: Commodities, also known as products, consist of goods and services.

## Tick (     ) the appropriate columns and state whether demand is effective or not.

|     |                                                                                      | Willingness   | Ability   | Effective / NoDemand   |
|-----|--------------------------------------------------------------------------------------|---------------|-----------|------------------------|
| (a) | Sara has Rs 20. She is willing to buy a pair of dholl-puri at Rs 12.                 |               |           |                        |
| (b) | Jeremie has Rs 200. T-shirts are being sold for Rs 150. He does not want to buy any. |               |           |                        |
| (c) | Ricardo is willing to buy a plot of land but he is short of Rs 150 000.              |               |           |                        |
| (d) | Julia has Rs 400. She is willing to buy a dress costing Rs 375.                      |               |           |                        |

## 6.2.1  Law of demand

When  prices  fall,  consumers  usually  increase  their  demand  and when prices rise, the demand is reduced. This is known as the law of demand which states that more is bought when prices are low and vice versa. Thus, there is an inverse relationship between price and the quantity demanded.

The law of demand states that more  is  bought  at  a  lower  price than higher price and vice-versa.

<!-- image -->

| Law ofdemand   | Law ofdemand   |
|----------------|----------------|
| P              | Qd             |
| P              | Qd             |

Table 2: Law of demand

<!-- image -->

(a) Use arrows (      ) or (      ) to illustrate the law of demand in the table below.

| Price (P)   | Quantity demanded (Qd)   |
|-------------|--------------------------|
| P           | Qd ……………………              |
| P ……………………  | Qd                       |

(b) Hence, the law of demand states that there is ……………………. (a direct / an inverse) relationship between price and quantity demanded.

<!-- image -->

## Turn and Talk Activity

Turn to a partner in the classroom.  One student should act as a seller and the other as a buyer (with limited income). Discuss about situations where price  increases  and  decreases  and  how  does  the  buyer  reacts  in  each situation.

## 6.2.2  The demand curve

The  demand  curve  is  drawn  from  the  demand  schedule.  The demand schedule is a table which shows the quantity demanded of commodities at given prices.

A demand schedule is  a  table which shows the quantity demanded  of  commodities  at given prices.

Below is a demand schedule and its demand curve.

Table 3: Demand schedule

|   Price (Rs) |   Quantity demanded (units) |
|--------------|-----------------------------|
|           10 |                           4 |
|           15 |                           3 |
|           20 |                           2 |
|           25 |                           1 |

The demand curve is  a  diagram that shows the quantity demanded of a commodity at each price.  The demand curve slopes downwards from left to right as illustrated below.

The demand curve is a diagram that shows the quantity demanded  of  a  commodity  at each price.

Quantity demanded (units)

Figure 2: A demand curve

In this image, we can see a graph.

<!-- image -->

## Labelling the DEMAND curve diagram

The diagram is labelled as follows:

-  0 - the point of origin
- X-axis as Quantity demanded (units)
- Y- axis as Price (Rs)
- The demand curve as DD

<!-- image -->

Below is the demand schedule of  'Maxim Mervei' , a business selling a mauritian snack. The quantity demanded of 'Maxim Mervei' at different prices are presented in a demand schedule as follows.

|   Price per unit (Rs) |   Quantity demanded of'Maxim Mervei'per day (units) |
|-----------------------|-----------------------------------------------------|
|                     5 |                                                  80 |
|                    10 |                                                  60 |
|                    15 |                                                  40 |
|                    20 |                                                  20 |

## Draw and label the demand curve of 'Maxim Mervei' on the graph below.

In this image, we can see a table with some text and numbers.

<!-- image -->

## 6.2.3 Factors affecting demand

Demand for a commodity can be affected by a set of factors, namely, price of the product itself and other factors (income of the consumer, population, tastes and preferences, as well as climate). These are summarised below.

Figure 3: Factors affecting demand

In this image, we can see a diagram. There are two circles in the image. There are some text written on the circles.

<!-- image -->

## Each factor is explained below.

|    | Factors affectingdemand     | Explanation                                                                                                               |
|----|-----------------------------|---------------------------------------------------------------------------------------------------------------------------|
|  1 | Price of the product itself | A fall in price of the product will increase the quantity demanded, and vice versa.                                       |
|  2 | Income of consumer          | More is bought when income increases.                                                                                     |
|  3 | Population                  | An increase in population would cause an increase in the demand for commodities, for e.g, food, education and healthcare. |
|  4 | Tastes and preferences      | Fashionable items are trendy and usually high in demand, for example, slim fit jeans.                                     |
|  5 | Climate                     | People buy some specific commodities in particular climate, for example, demand of warm clothes will increase in winter.  |

<!-- image -->

## State two factors that affect the demand of the following commodities.

|             |             | Factors affectingdemand   | Factors affectingdemand   |
|-------------|-------------|---------------------------|---------------------------|
| Commodities | Commodities | (1)                       | (2)                       |
| (a)         | Fast food   |                           |                           |
| (b)         | Ice cream   |                           |                           |
| (c)         | Cars        |                           |                           |

## 6.2.4  Movement along the demand curve

A change in price of a commodity causes a movement along its demand curve. The table below illustrates movements along a demand curve.

## Price increase

## Price decrease

In this image, we can see a graph.

<!-- image -->

|   Price (Rs) |   Quantity demanded(units) |
|--------------|----------------------------|
|           10 |                         60 |
|           15 |                         40 |

A  rise  in  price  from  Rs  10  to  Rs  15  causes an upward movement along the demand curve  from  points  A  to  B.  The  quantity demanded falls from 60 units to 40 units.

fall in price

A

causes a downward movement along the demand curve.

In this image, we can see a graph. There are two lines on the graph. There is a number on the right side of the graph.

<!-- image -->

|   Price (Rs) |   Quantity demanded(units) |
|--------------|----------------------------|
|           10 |                         80 |
|            5 |                         60 |

A  fall  in  price  from  Rs  10  to  Rs  5  causes  a downward  movement along  the  demand curve from points A to C. The quantity demanded rises  from 60 units to 80 units.

<!-- image -->

## State whether the following statements are True or False.

| (a)   | A change in price affects the quantity demanded of a commodity.          |
|-------|--------------------------------------------------------------------------|
| (b)   | An upward movement along the demand curve is due to a fall in price.     |
| (c)   | A downward movement along the demand curve is due to a fall in price.    |
| (d)   | A movement along the demand curve does not affect the quantity demanded. |

## 6.2.5 Shift of the demand curve

A change in 'other factors' affect demand and causes shifts of the demand curve either to its right or to its left. (Shifts are not caused by changes in price of the commodity). Below are examples of shifts in demand curve.

The image is a diagram titled "Diagram." The diagram consists of a horizontal line labeled "D" and a vertical line labeled "A." The line D is drawn from point D to point A, while the line A is drawn from point A to point B.

### Description of the Diagram:
1. **Horizontal Line D**:
   - The line D is drawn from point D to point A.
   - Point D is located on the horizontal line.
   - Point A is located on the horizontal line.

2. **Vertical Line A**:
   - The line A is drawn from point A to point B.
   - Point A is located on the vertical line.

3. **Line Segments**:
   - Point D is connected to point A by a line segment labeled "D."
   - Point A is connected to point B by a line segment labeled "A."
   - Point D is connected to point B by a line segment labeled "D."

<!-- image -->

The image depicts a graph with two lines. The x-axis is labeled as "Quantity (Units)" and the y-axis is labeled as "Price (Rs)." The line on the graph is labeled "D1" and the line on the graph is labeled "D2." The line D1 is a straight line that starts at point D1 and extends to point D2. The line D2 is a line that starts at point D2 and extends to point D1.

### Description of the Graph:
- **Line D1:**
  - The line D1 starts at point D1 and extends to point D2.
  - The line D1 is a straight line with a minimum value of 0.
- **Line D2:**
  - The line D2 starts at point D2 and extends to point D1.
  - The line D2 is a line that starts at point D1 and extends to point D2.

###

<!-- image -->

|    | Example                                                                                                            | Shift of the demandcurve              | Diagram                                                 |
|----|--------------------------------------------------------------------------------------------------------------------|---------------------------------------|---------------------------------------------------------|
|  1 | An increase in income of the consumer may encourage people to buy more clothes                                     | The demand curve shifts to its right. | 10 Price(Rs) A B D 1 D Note that price does not change. |
|  2 | Climate More fans are demanded in summer                                                                           |                                       | 40 60 Quantity (Units) D 1 D o                          |
|  3 | People's tastes and preferences change from fast foods to healthy foods. This would decrease demand of fast foods. | The demand curve shifts to its left.  | Price (Rs) A B D 1 D Note that price does not change.   |
|  4 | A fall in population would decrease the demand for housing                                                         |                                       | 40 60 Quantity (Units) D 1 D o                          |

## Activity 7

The diagrams below show shifts of the demand curve. Tick (     ) the column that represents the shift of the demand curve for each change in demand.

The image is a diagram titled "Price (Rs.)" with a line diagram. The diagram consists of three lines, labeled A, B, and D. Line A is the downward-sloping line, line B is the upward-sloping line, and line D is the upward-sloping line. The line A is the downward-sloping line, and the line B is the upward-sloping line.

### Description of the Diagram:
- **Line A**: The downward-sloping line represents the demand curve. It is labeled as "D" and is represented by a dashed line.
- **Line B**: The upward-sloping line represents the supply curve. It is labeled as "D" and is represented by a dashed line.
- **Line D**: The upward-sloping line represents the supply curve. It is labeled as "D" and is represented by a dashed line.

### Analysis:
- **Line A

<!-- image -->

In this image, we can see a graph. There is a line on the graph. There is a text on the graph.

<!-- image -->

|     | Factor influencingdemand                                                       | DiagramA   | Diagram B   |
|-----|--------------------------------------------------------------------------------|------------|-------------|
| (a) | A fall in income of the consumer reducing demand for cars.                     |            |             |
| (b) | A rise in population causing an increase in demand for food.                   |            |             |
| (c) | An advertising campaign attracts more people to consume fruits and vegetables. |            |             |
| (d) | Severe winter on the demand of ice creams.                                     |            |             |

## 6.3 Supply

Supply is the quantity of a commodity offered for sale by sellers on the market at a given price and time.

## 6.3.1  Law of Supply

Sellers are motivated  to  earn  profits.  Therefore,  more commodities are offered for sale when prices are high and less are offered when prices are low. This is known as the law of supply .

The law of supply states that a rise in the price  of  a  commodity  will  raise  quantity supplied, and vice versa.

The table below summarises the law of supply.  It shows a direct relationship between price and quantity supplied.

In this image we can see a table with some text on it.

<!-- image -->

| Law of supply   | Law of supply   | Law of supply   | Law of supply   |
|-----------------|-----------------|-----------------|-----------------|
|                 | P               | Qs              |                 |
|                 | P               | Qs              |                 |

Table 7: Law of Supply

<!-- image -->

## Answer the following questions.

(a) Use arrows (      ) or (      ) to illustrate the law of supply in the table below.

| Price (P)   | Quantity Supplied (Qs)   |
|-------------|--------------------------|
| P           | Qs ……………………              |
| P ……………………  | Qs                       |

- (b) Hence, the law of supply states that there is ……………………. (a direct / an inverse) relationship between price and quantity supplied.

Supply is the quantity of a  commodity offered for sale by sellers on the market at a given price and time.

## 6.3.2 The supply curve

The supply curve is drawn from the supply schedule. The supply schedule is  a  table  which  shows  the  quantity  supplied  of commodities at given prices.

A supply schedule is a table which shows the quantity supplied of commodities at each price.

Below is a supply schedule and its supply curve.

|   Price (Rs) |   Quantity supplied (units) |
|--------------|-----------------------------|
|            5 |                          20 |
|           10 |                          40 |
|           15 |                          60 |
|           20 |                          80 |

Table 8: Supply schedule

The supply curve is a diagram that shows the quantity supplied at each price. The supply curve slopes upward from the left to the right as illustrated below.

Quantity supplied (units)

In this image, we can see a graph.

<!-- image -->

Figure 4 : A supply curve

## Labelling the SUPPLY diagram

The diagram is labelled as follows:

-  0 - the point of origin
-  X-axis as Quantity supplied (units)
-  Y- axis as Price (Rs)
-  The supply curve as SS

The supply curve is  a  diagram that shows the quantity supplied at each price.

<!-- image -->

The quantity supplied of T-shirts at different prices are presented in a supply schedule as follows:

|   Price per unit (Rs) |   Quantity supplied of ZumiT-shirts (units) |
|-----------------------|---------------------------------------------|
|                     5 |                                          20 |
|                    10 |                                          40 |
|                    15 |                                          60 |
|                    20 |                                          80 |

## Draw and label the supply curve of 'Zumi T-shirts' .

In this image, we can see a graph.

<!-- image -->

## 6.3.3  Factors affecting supply

The  supply  of  commodities  is  also  affected  by  factors  other  than  price,  such  as  costs  of production, technology, climate as well as tax.

Below is a classification of some factors affecting supply.

In this image, we can see a diagram. There are two lines in the image. We can see the text on the image.

<!-- image -->

Each factor is explained below.

|    | Somefactors affecting supply              | Explanation                                                                                                                                     |
|----|-------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Price of the product itself (main factor) | A rise in price of the product will raise the quantity supplied and vice versa.                                                                 |
|  2 | Cost of production                        | A rise in costs of production due to expensive raw materials or higher labour costs will discourage suppliers to supply more at the same price. |
|  3 | Technology                                | Use of advanced technology makes production more efficient. Therefore, more can be supplied on the market.                                      |
|  4 | Climate                                   | During winter, more cardigans will be supplied.                                                                                                 |
|  5 | Taxes                                     | A rise in tax such as Value AddedTax (VAT) will discourage more production.                                                                     |

Table 9: Description of factors affecting supply

<!-- image -->

Activity 10

Pritish grows cauliflowers, which he offers for sale. Due to heavy rains, half of his crops was destroyed.

Tick (       ) the factor(s) that affect the supply of cauliflowers.

Price of the cauliflowers were too high

Bad weather conditions

The cauliflowers were not yet ready for sale

## 6.4.4 Movement along the supply curve

A change in price of a commodity causes a movement along its supply curve. The table below illustrates movements along a supply curve.

## Price increase

## Price decrease

A rise in price causes an upward movement along the supply curve

In this image, we can see a graph. On the graph, we can see numbers.

<!-- image -->

|   Price (Rs) |   Quantity supplied (units) |
|--------------|-----------------------------|
|           10 |                          40 |
|           15 |                          60 |

A fall in price causes a downward movement along the supply curve

In this image, we can see a graph. On the graph, we can see numbers.

<!-- image -->

|   Price (Rs) |   Quantity supplied (units) |
|--------------|-----------------------------|
|           10 |                          40 |
|            5 |                          20 |

A rise in price from Rs 10 to Rs 15 causes an upward movement along the supply curve from points A to B. Quantity supplied rises from 40 units to 60 units.

A fall in price from Rs 10 to Rs 5 causes a downward movement along  the  supply curve from points C to D. Quantity supplied falls from 40 units to 20 units.

Table 10: Movements along the supply curve

## 6.3.4 Shift of the supply curve

A shift  of  the  supply  curve  is  caused  by  changes  in  'other  factors'  affecting  supply. The  supply curve can either shift to its right or to its left. (Shifts are not caused by changes in price of the commodity). Examples are given below.

In this image, we can see a graph. There is a line on the graph. There is a text at the top of the image.

<!-- image -->

In this image, we can see a graph. There is a line on the graph. There is a text on the graph.

<!-- image -->

|    | Example                                                                                                                     | Shift of the supply curve            | Diagram                                               |
|----|-----------------------------------------------------------------------------------------------------------------------------|--------------------------------------|-------------------------------------------------------|
|  1 | Cost of production A fall in cost of production would encourage suppliers to produce more. Therefore, supply will increase. | The supply curve shifts to its right | Price (Rs) S 1 A B S Note that price does not change. |
|  2 | Technology Use of better technology to produce cars would facilitate the production process. This would increase supply.    | The supply curve shifts to its right | 10 40 60 Quantity (Units) S 1 S O                     |
|  3 | Climate Supply of litchis falls in winter, because it is a seasonal fruit.                                                  | supply curve its left 10 D C         | Price (Rs) S 1 S Note that price does not change.     |
|  4 | Taxes A rise in taxes on furniture would decrease supply.                                                                   | supply curve its left 10 D C         | 40 60 Quantity (Units) S 1 S O                        |

<!-- image -->

## Group discussion

## Think-Pair-Share

If there is a high supply and low demand for a certain good, will the price likely be high or low?

If there is a low supply and high demand for a certain good, will the price likely be high or low? Justify your answer(s).

<!-- image -->

The diagrams below show shifts of the supply curve. Tick (      ) the column that represents the shift of the supply curve for each change in supply.

In this image, we can see a graph. There is a line on the graph. There is a point on the graph. There is a text on the graph.

<!-- image -->

Diagram A: Rightward shift of the supply curve

In this image, we can see a graph. There is a line on the graph. There is a point on the graph. There is a text on the graph.

<!-- image -->

Diagram B: Leftward shift of the supply curve

|     | Factor influencing supply                                     | DiagramA   | Diagram B   |
|-----|---------------------------------------------------------------|------------|-------------|
| (a) | A rise in cost of production reducing supply of coffee beans. |            |             |
| (b) | Use of modern production techniques in car manufacturing.     |            |             |
| (c) | Drought causing a poor harvest of crops.                      |            |             |
| (d) | A fall in Value AddedTax on electronic products.              |            |             |

## 6.4 Equilibrium point

The demand and supply curves can be drawn on the same diagram. They are drawn from the following demand and supply schedules.

|   Price (Rs) |   Quantity demanded (units) |   Quantity supplied (units) |
|--------------|-----------------------------|-----------------------------|
|            5 |                          90 |                          10 |
|           25 |                          50 |                          50 |
|           30 |                          40 |                          60 |
|           50 |                          20 |                          85 |

The  demand  and  supply  diagrams  have  been  drawn  from  the  above  demand  and  supply schedules.

In this image, we can see a graph. There is a line on the graph. There is a point on the graph. There is a text on the graph.

<!-- image -->

## Labelling the DEMAND and SUPPLY diagram

The diagram is labelled as follows:

- 0 - the point of origin
- X-axis as Quantity traded (units)
- Y- axis as Price (Rs)
-  The demand curve as DD
-  The supply curve as SS

Figure 6: Demand and supply curves

Equilibrium is a state of balance. At this point, quantity demanded and quantity supplied are equal.

The equlibrium price is Rs 25 and the quantity traded is 50 units The equilibrium point (E) shows

- the equilibrium price also known as market price
- quantity traded of commodities on the market

.

Equilibrium point is where  the  demand  and supply curves meet each other.

<!-- image -->

(a) Using the given demand and supply schedules, draw a demand and supply diagram on the graph below.

- (b) Identify the equilibrium point and label it as E.
- (c) Explain what is meant by market equilibrium.

|   Price (Rs) |   Quantity demanded (units) |   Quantity supplied (units) |
|--------------|-----------------------------|-----------------------------|
|           10 |                         160 |                          20 |
|           45 |                         100 |                         100 |
|           70 |                          60 |                         160 |
|           80 |                          40 |                         180 |

In this image, we can see a table with some text and numbers.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## Question 1

## Multiple Choice Questions

## Choose the correct answer for each of the questions below and write it in the space provided.

- 1.

- The law of demand states that there is …………………..relationship between price and quantity demanded.

- A direct

- B inverse

C any

D few

Answer…………

2. The demand curve is drawn from the………………….

- A demand schedule

B

supply schedule

C equilibrium point

D market

Answer…………

3. An increase in the level of income will

- A shift the demand curve to the right

- B shift the supply curve to the right

C cause an upward movement along the demand curve

D cause a downward movement along the demand curve

Answer…………

4. Which of the following factor influences supply of a commodity?

- A Level of income

- B Advanced methods of production

C Population

- D Tastes and preferences

Answer…………

5. Equilibrium occurs when

- A demand is greater than supply

- B demand is equal to supply

C supply is greater demand

- D supply is less than demand

Answer…………

## Question 2

Kiriko Enterprise manufactures boxing shoes. The demand and supply schedules are below.

| Price (Rs)   |   Quantity demanded (pairs) |   Quantity supplied (pairs) |
|--------------|-----------------------------|-----------------------------|
| 1 000        |                          60 |                          20 |
| 1 500        |                          40 |                          25 |
| 2 000        |                          30 |                          30 |
| 2 500        |                          20 |                          40 |
| 3 000        |                          10 |                          50 |

## (a) Draw and label the demand and the supply curves.

In this image, we can see a table with some text and numbers.

<!-- image -->

- (b) Identify
- (i) the equilibrium price: \_\_\_\_\_\_\_\_\_   (ii) the equilibrium quantity: \_\_\_\_\_\_\_\_\_\_\_
- (c) State one factor that might influence
- (i) the demand for boxing shoes

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) the supply of boxing shoes

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## KEY TERMS

Buyer is one who purchases goods and services.

Demand curve is a diagram that shows the quantity demanded of commodity at each price.

Demand schedule is a table which shows the quantity demanded of commodities at given prices.

Effective demand is the willingness and ability to buy a commodity at a given price over a given time period.

Equilibrium point is where the demand and supply curves meet each other.

Law of demand states that more is bought at lower prices than at higher prices and vice versa.

Law of supply states that a rise in price of a product will raise quantity supplied and vice versa.

Market is  where buyers and sellers meet to exchange goods and services against a payment.

Seller (or supplier) is one who offers goods and services, usually, to make profits.

Supply curve is a diagram that shows the quantity supplied an entrepreneur is willing to sell at each price.

Supply is  the quantity of a commodity offered for sale by sellers on the market at a given price and time.

Supply schedule is a table which shows the quantity supplied of commodities at each price.

Money and Banking

Unit 7 Money and Banking

## Learning Objectives:

## On completing this unit, you will be able to:

- explain the term 'money'
- outline the characteristics and functions of money
- distinguish between the functions of central and commercial banks

In  this  unit,  you  will  learn  about  money  and  its  characteristics  as  well  as functions. You will also be introduced to commercial banks and central banks as well as learn their functions.

## 7.1 Money

Money is anything which is generally acceptable as a medium of exchange against  goods  and  services.  It  is  highly  important  for enterprises as it is involved in every business activity. All expenses and incomes of a business are measured in terms of money.

Money is  anything  which is  generally  acceptable  as a medium of exchange against goods and services.

## 7.1.1 Forms of money

The forms of money that have been used in trade have changed tremendously over time. In ancient civilisations, trade took place through the barter system . This  involves  direct  exchange  of  commodities  without  using money. For barter to take place there should be double coincidence of  wants. This involves two individuals who should agree to sell and buy each other's commodity i.e. what a person desires to sell should be exactly what the other person wishes to buy.

The barter system involves the direct exchange of commodities  where  there is double coincidence of wants.

<!-- image -->

## BARTER

ILI

Figure 1: Example of barter system

<!-- image -->

Gradually,  money  evolved  into  commodity  money,  metallic  money,  notes  and  coins,  and eventually into a plastic to cashless society.

The different forms of money are as follows:

Figure 2: Forms of money

In this image, we can see a chart. There are some text and numbers on the chart.

<!-- image -->

<!-- image -->

## State whether the following statements are True or False.

| (a)   | Money is a commodity which is generally accepted by everyone.                          |
|-------|----------------------------------------------------------------------------------------|
| (b)   | The expenses and incomes in a business are not necessarily measured in terms of money. |
| (c)   | Gold and silver coins are the only forms of commodity money.                           |
| (d)   | The direct exchange of products refers to the barter system.                           |

<!-- image -->

## Answer the following questions.

Shrina and Yeshu wish to trade fresh fruits against manure. Shrina has three tons of fresh fruits and Yeshu has one ton of manure.  However, they did not agree about the quantities to be exchanged.

- (a)  Identify one reason why the barter system could not take place.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Tick (      ) the medium that would help to trade the exact quantities of fruits and manure.

| (i)   | Use cattle as money    |
|-------|------------------------|
| (ii)  | Use of notes and coins |

## 7.1.2  Characteristics of money

The forms of money used in the past had several inconveniences. Every commodity which was used as money had its limitations.  Therefore, for anything to be used as money, it must have the following characteristics.

Acceptable

Money must be generally acceptable and / or recognised by those who use it.

Durable

## Divisible

Scarce

Uniform

Portable

Money must be able to last for a period of time to enable people to use it again and again.

Money should be made available in smaller units for smaller transactions.  For  example,  a  Rs  100  note  can  be  divided into four Rs 25 notes, as well as ten Rs10 coins.

Money must be limited in supply to retain its value.

The items used as money should be standardised in  size and weight.

Money must be light and easy to be conveniently carried around.

Figure 3: Characteristics of money

## 7.1.3  Functions of money

Commodities used as money should fulfill four distinct functions.

## Read the case below about the functions of money.

Kelly has saved Rs 50 000 over two years to buy a laptop. Recently, she visited a local store to buy one.

## Options for mode of payment:

1. Cash
2. Hire purchase: Monthly installment of Rs 1 800 ( 36 months)

The functions of money are explained below:

| Functions ofmoney                                                                                                          | Explanation                                                                                                                                 | Example from the case        |
|----------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|------------------------------|
| • Money is paid to obtain goods and services. • It enables trade to take place easily and quickly.                         | If Kelly chose to pay for the laptop in cash, money would be used as a mediumof exchange .                                                  | Mediumof exchange            |
| • Money is used to measure and assign a monetary value to products. • It allows to plan for expenses from available money. | Kelly compared the price of laptops with her budget. She then paid the exactamountofRs44890using notes and coins for the one she purchased. | Unit of account              |
| • Money can be saved and invested at a later date as it retains its value over time.                                       | Kelly used her savings to buy the laptop.                                                                                                   | Store of value               |
| • Money allows people to buy on credit, that is, buying now and paying later.                                              | If Kelly chose to buy the laptop on hire purchase, she would have paid the total amount over 36 months .                                    | Standard of deferred payment |

<!-- image -->

<!-- image -->

## From the list below, identify the function of money for each example given below.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Examples                                                 | Function ofmoney   |
|----------------------------------------------------------|--------------------|
| Buy food at the school canteen                           |                    |
| Save at the bank for further studies                     |                    |
| Compare the value of goods in a shop                     |                    |
| Buy a mobile phone on credit and pay after 2 months      |                    |
| Keep records of income and expenses                      |                    |
| Repay a loan at the bank                                 |                    |
| Buy accessories on the internet and pay with credit card |                    |

## 7.2 Banks

Banks  assist  people  and  enterprises  to  carry  out  their  financial  transactions.  A  bank  is  an institution which accepts deposits, provides loans and offers other financial services. There are two main types of banks, namely commercial bank and central bank.

## 7.2.1  Commercial banks

Commercial banks play a very important role in helping enterprises in Mauritius to carry out their business transactions. A commercial bank accepts  deposits,  give  loans  and  provides  other  financial services to private individuals and firms.

A c ommercial bank accepts deposits, give loans and provides other financial  services  to  private individuals and firms.

Examples of some commercial banks in Mauritius are:

<!-- image -->

The Mauritius Commercial Bank Ltd.                               State Bank of Mauritius (SBM)

<!-- image -->

Figure 4: Examples of commercial banks

## 7.2.1.1 Functions of the commercial banks

Commercial banks carry out several functions and offer a wide range of services to its customers. Their functions are outlined below.

Figure 5: Functions of commercial banks

The image is a flowchart diagram that represents a series of interconnected steps. The flowchart is divided into three main sections, each with a distinct color. The colors of the sections are blue, green, and purple.

### Flowchart Sections:
1. **Blue Section**:
   - **Given Loans**: This section is represented by a blue arrow pointing from the blue section to the green section. The arrow indicates that the given loans are being provided to the customers.

2. **Green Section**:
   - **Accept Loans**: This section is represented by a green arrow pointing from the green section to the purple section. The arrow indicates that the acceptance of the loans is being made by the customers.

3. **Purple Section**:
   - **Assist Customers in Making Payments**: This section is represented by a purple arrow pointing from the purple section to the green section. The arrow indicates that the assistance provided to customers is being made by the customers.

<!-- image -->

<!-- image -->

## State whether the following statements are True or False.

| (a)   | Banks help enterprises to carry out financial transactions.   |
|-------|---------------------------------------------------------------|
| (b)   | The only function of a commercial bank is to accept deposits. |
| (c)   | Commercial banks provide their services to businesses only.   |
| (d)   | Commercial banks offer loans to private individuals.          |

## 7.2.2  Central Bank

The central  bank is  an  institution  established  by the  government  to  control  financial  activities  of  a country.  Every  country  has  only  one  central  bank which supervises and regulates the banking system of the country.

The  central  bank  of  Mauritius  is  called The  Bank  of Mauritius . It is situated in Port Louis.

The central  bank is an institution established by the government to control financial activities of a country.

<!-- image -->

Fill in the blanks with the appropriate words given below.

issue

country

controls

policies

commercial

system

The central bank \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ the financial institutions of a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

including  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ banks. It has the responsibility to \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

notes and coins and it also  implements \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ set by the government.

Figure 5: Bank of Mauritius

<!-- image -->

## 7.2.2.1 Functions of Central Bank

The central bank carries out numerous functions, some of which are explained below.

|    | Functions of central bank          | Explanation                                                                                                   |
|----|------------------------------------|---------------------------------------------------------------------------------------------------------------|
|  1 | Setting rules and regulations      | The central bank sets rules and regulations that banks should strictly follow.                                |
|  2 | Monitoring the banking system      | Thecentralbankensuresthatgovernmentdecisionsand/or policies about financial activities are being implemented. |
|  3 | Acting as Government's banker      | The central bank manages the funds of the government.                                                         |
|  4 | Issuing notes and coins            | The central bank issues and controls notes and coins that circulate in a country.                             |
|  5 | Acting as a bankers'bank           | Commercial banks usually seek help and advice from central bank.                                              |
|  6 | Keeping gold and currency reserves | Centralbanksafeguardsandcontrolsthegoldandcurrency reserves of a country.                                     |

Table 2: Functions of a central bank

<!-- image -->

## State whether the following statements are True or False.

| (a)   | Central bank accepts deposits from individuals.                |
|-------|----------------------------------------------------------------|
| (b)   | A central bank is owned by private enterprises.                |
| (c)   | Central banks issue and control the supply of notes and coins. |
| (d)   | The Bank of Mauritius is owned by the government.              |

<!-- image -->

1. To each of the functions below, draw arrows to match the respective functions that central and commercial banks undertake.

<!-- image -->

| Functions of bank                      |
|----------------------------------------|
| Acting as Government's banker          |
| Giving loans to the public             |
| Controlling gold and currency reserves |
| Accepting deposits from the public     |
| Issuing of notes and coins             |
| Accepting deposits from the government |
| Offering safekeeping vault services    |

<!-- image -->

<!-- image -->

## KEY TERMS

Barter system involves the direct exchange of commodities where there is double coincidence of wants.

Central bank is an institution established by the government to control the financial activities of a country.

Commercial bank accepts deposits, give loans and provides other financial services to private individuals and firms.

Money is anything which is generally acceptable as a medium of exchange against goods and services.

Spending, Savings and Borrowing

In this image we can see a person holding a coin in his hand and there are coins in the jar.

<!-- image -->

Unit 8 Savings and

Spending, Borrowing

## Learning Objectives:

## On completing this unit, you will be able to:

- define the terms 'spending', 'savings' and 'borrowing'
- identify the factors that influence an individual to spend, save or borrow

In  this  unit,  you  will  learn  about  how  people  use  their  income  either  on spending and/or savings. People also borrow money to satisfy their needs and wants.  The unit also presents the factors that influence an individual's spending, savings or borrowing.

## 8.1 Spending

## Read the story of 'Madhav the architect' to understand the nature of spending, saving and borrowing.

Madhav  runs  his  own  business  as  an  architect.  His  household consists of his wife, two children and retired parents. His monthly income is quite high but a large amount is spent on food, rent, fuel costs and other household expenses. He also tries to save part of his income, in case some unexpected expenses arise. From those savings, he also planned to buy a family car. To make this happen, Madhav intends to take a bank loan.

<!-- image -->

People  work  to  earn  the  means  to  spend  on  goods  and  services. Money  earned  is  known  as income .  Usually,  people  have  to  pay taxes from their incomes to the government. Income after payment of tax is known as disposable income which is the amount left for spending. Some people also save part of their income.

Disposable income is amount of income available for  spending  after  taxes  are paid.

Figure 1: Income, spending and savings

In this image, we can see a chart. There are two categories in the chart, which are "Spending" and "Savings".

<!-- image -->

Figure 2: Disposable income

<!-- image -->

Spending refers  to  paying  out  money  to  buy  goods  and  hire services. People with high income are usually able to spend more. Incomes are usually spent on the following:

Spending refers  to  paying out  money  to  buy  goods  or hire services.

In this image, we can see a person wearing clothes and holding a book. We can also see a house, a basket, a person, a flag, a flag, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person, a person,

<!-- image -->

Figure 3: Spending

In this image, we can see a circle with a number and a text.

<!-- image -->

Figure 4: Income

<!-- image -->

Assume Ying earns Rs 15 000 monthly. The table below shows the spending and saving for the months of May to September.

## Complete the table below by finding the savings of Ying for each month.

|           | Income (Rs)   | Spending (Rs)   | Saving (Rs)                        |
|-----------|---------------|-----------------|------------------------------------|
| May       | 15 000        | 15 000          | .................................. |
| June      | 15 000        | 14 000          | .................................. |
| July      | 15 000        | 13 000          | .................................. |
| August    | 15 000        | 12 000          | .................................. |
| September | 15 000        | 15 100          | .................................. |

When people's earnings and/or past savings are not enough to meet their expenses, they have the options of either borrowing money to spend in the present or postponing their expenses for the future.

## 8.1.1 Factors affecting spending

The amount of money that a consumer spends depends on several factors. These are explained below.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 1: Factors affecting consumer spending

|    | Factors affecting spending   | Explanation                                                                                                                                                                |
|----|------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Prices of goods and services | Spending will increase if prices of goods and services rise. Ontheother hand, spending will decrease if prices of goods and services fall.                                 |
|  2 | Rate of interest             | When banks offer higher interest rate on savings, people would usually save more rather than spend. Thus, spending would fall.                                             |
|  3 | Wealth                       | Spending by rich people tends to be higher than poor people because they are wealthier.                                                                                    |
|  4 | Expectations                 | Peopletendtoincreasetheircurrentspending if they expect prices to rise in the future. On the other hand, if prices are expected to fall, current spending will be reduced. |

<!-- image -->

## Tax Information

The Mauritius Revenue Authority (MRA) charges 15% (as at 2019) tax on incomes of householders. It usually charges tax on those whose income is above Rs 305 000 per annum.

Income tax is a compulsory payment charged by the government on income.

The table below shows four individuals with different incomes and the tax paid by them.

|            | Income per year (Rs)   | Tax exempt (Rs)   | Taxable income (Rs)   | Income tax per annum(Rs) 15%tax on income   |
|------------|------------------------|-------------------|-----------------------|---------------------------------------------|
| Mr D'souza | 130 000                | Rs 305 000        | Nil                   | Nil                                         |
| Ms Bina    | 195 000                | Rs 305 000        | Nil                   | Nil                                         |
| Mrs Grace  | 390 000                | Rs 305 000        | 85 000                | 12 750                                      |
| Mr Bhurtun | 500 000                | Rs 305 000        | 195 000               | 29 250                                      |

Table 2: Income and tax payment

Mr D'Souza and Ms Bina did not pay any tax for the year. Mrs Grace and Mr Bhurtun paid taxes on their taxable income .

<!-- image -->

## State whether the following statements are True or False.

| (a)   | People spend to satisfy their needs and wants.                       |
|-------|----------------------------------------------------------------------|
| (b)   | People with low income tend to spend more.                           |
| (c)   | Possessing gold is an example of wealth.                             |
| (d)   | People with high income tend to save more.                           |
| (e)   | A banker will retire soon. He can spend more now than in the future. |
| (f )  | People save more when banks offer a low rate of interest.            |

## 8.2 Savings

Savings  occur  when  people  keep  money  aside  by  sacrificing  the purchase or consumption of certain goods and services. Therefore, savings is that part of income that is kept to be spent in the future. People  usually  save  their  income  for  different  purposes.  They  are explained below.

Savings refers to part of income that is  kept    for future use.

## Purpose of savings

Figure 5: Purpose of savings

In this image we can see a chart. In the chart we can see the numbers.

<!-- image -->

## 8.1.2 Factors affecting savings

The amount of money that a consumer saves depends on several factors. These are:

|    | Factors affecting savings   | Explanation                                                                                                                                                                                                               |
|----|-----------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Disposable income           | People with higher disposable income usually save more.                                                                                                                                                                   |
|  2 | Rate of interest            | High interest rates offered by banks encourage people to save more of their incomes rather than spend.                                                                                                                    |
|  3 | Age groups                  | Youngsters and the elderly tend to save less than the middle aged people.                                                                                                                                                 |
|  4 | Expectations                | If people expect prices of goods and services to increase in the future, they will tend to save more now for their purchases in the future. For example, an individual who fears unemployment ahead will save more today. |

<!-- image -->

## Fill in the blanks with the appropriate words given below.

|     | less unexpected consumption retirement future income                             |
|-----|----------------------------------------------------------------------------------|
| (a) | Savings refer to money kept for ___________ use.                                 |
| (b) | To save money, current __________________ has to be sacrificed.                  |
| (c) | People save money for different reasons like future projects, _________________, |
| (d) | A fall in the rate of interest will cause people to save _____________.          |

## 8.3 Borrowing

Borrowing money is one way for individuals to spend more than their current disposable income. Borrowing refers to taking money from a person or financial institution which must be repaid in the future. The money borrowed is usually called a loan .  It  is  usually charged with an interest which is a payment over and above the initial amount borrowed.

Borrowing refers  to  taking money  from a person or financial institution which must be repaid in the  future.

Pedro wants to buy his first car which costs Rs 750,000. He has Rs 200,000 from his savings. A friend will lend him Rs 200 000 but he has yet to find the remaining Rs 350 000. He decides to take a car loan from a bank. He will, then, have to repay back the loan with interest to the bank.

Interest is  a  payment  over and above the initial amount borrowed.

A loan is  money  borrowed which has to be repaid with interest  over  a  given  period of time.

Figure 6: Forms of borrowings

In this image, we can see three circles. The circles are connected with lines.

<!-- image -->

## 8.3.1 Factors affecting borrowing

Individuals are motivated to borrow money for several reasons. These are explained below.

Availability of loans

<!-- image -->

<!-- image -->

<!-- image -->

Banks offer different loan schemes that attract more people to borrow from them.

Rate of Interest

In this image, we can see a picture of a person. We can see a text on the image.

<!-- image -->

The cost of borrowing money is known as the rate of interest. The higher the interest rate on loans, the lesser people will borrow.

Social attitudes

Countries or societies which are more debtaverse will tend to borrow less.

Figure 7: Factors influencing borrowing

<!-- image -->

## TAX INFORMATION

An  individual  is  exempt  of  paying  taxes  when  taking  a  loan  to purchase or build a first house.

<!-- image -->

Tick (      ) the factors which will cause an individual to borrow more.

| (a)   | Banks offer loans at low interest rates.                                                     |
|-------|----------------------------------------------------------------------------------------------|
| (b)   | An individual earns a high income and has high savings.                                      |
| (c)   | An individual has a low income and intends to construct a house.                             |
| (d)   | An individual wants to go for a world tour soon and expects to get a promotion a year later. |

<!-- image -->

## Question 1

- (a) Distinguish between spending and savings .

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Identify two common factors which influence both spending and saving.

Factor 1:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Factor 2:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Define the term 'borrowing'.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) An entrepreneur is planning to borrow a bank loan. Describe two factors which could influence his decision.

Factor 1:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Factor 2:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Question 2

Mr Ming has the following spending patterns, saving and borrowing in the table below.

Complete the table below to find Mr Ming's savings for months November and December.

| Monthly income is Rs 50 000.   | Monthly income is Rs 50 000.   | Monthly income is Rs 50 000.   |
|--------------------------------|--------------------------------|--------------------------------|
|                                | Spending                       | Savings                        |
|                                | Rs                             | Rs                             |
| October                        | 30 000                         | 20 000                         |
| November                       | 50 000                         |                                |
| December                       | 55 000                         |                                |

- (a) Give two reasons an individual would save his/her income.

Reason 1

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason 2

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Give two reasons an individual would borrow from friends or a bank.

Reason 1

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reason 2

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Question 3

## Encircle the words given below in the crossword.

<!-- image -->

## KEY TERMS

Borrowing refers to taking money from a person or financial institution which must be repaid in the future.

Disposable income is amount of income available for spending after taxes are paid.

Interest is a payment over and above the initial amount borrowed.

Income tax is a compulsory payment charged by the government on income.

Spending refers to paying out money to buy goods or hire services.

Savings refers to part of income that is kept for future use.

International Trade

## Unit 9 International Trade

## Learning Objectives:

## On completing this unit, you will be able to:

- explain the importance of trade
- distinguish between home trade and international trade
- explain the importance of trading with other countries

In this unit, you will learn the basis of trade while discovering about home and international trade. You will also learn about the importance of trading with other countries.

## 9.1 Trade

Trade is  the  exchange  of  goods  and  services  between  buyers  and sellers involving money. Buyers, known as consumers usually trade to satisfy their needs and wants. The buyers could be also be firms that engage in trade with the aim of making profits.

Trade is the buying and selling of products.

In this image, we can see a woman standing and holding a box. There are some objects in the image.

<!-- image -->

Figure 1: The basis of trade

<!-- image -->

## Fill in the blanks with the appropriate words given below.

| sellers   | wants selling profits buying buyers satisfying money                          |
|-----------|-------------------------------------------------------------------------------|
| (a)       | Trade refers to the ______________ and ______________ of goods and services.  |
| (b)       | Sellers trade in products with the aim of making ________________.            |
| (c)       | Firms can be both _______________ and ________________ of goods and services. |
| (d)       | Consumers buy products with the aim of _________________ needs and            |
| (e)       | Trade usually occurs in exchange of ______________ .                          |

## 9.2 Home trade and international trade

Entrepreneurs often aim to have a maximum of customers. Some of them target not only local customers, but also foreign ones. Thus, trade can take two forms: home trade and international trade.

## Read the story below.

Li Wang runs a factory selling biodegradable takeaways, cutlery and straws made from sugarcane pulp. He buys raw materials from local suppliers.  However, all  the  machinery and equipment used in the production process have been imported from Germany.

## 9.2.1  Home trade

Home trade takes place when goods and services are bought and sold within the country itself. It is also known as local trade. For instance, Li Wang  carries out home trade when he buys raw materials from local suppliers and sells the finished products to local customers.

Home trade is  the  buying and selling  of  goods  and  services within the country itself.

<!-- image -->

<!-- image -->

Figure 2 : Home trade

In this image, we can see a map with different colors. There are two people in the image. One person is standing and the other person is sitting.

<!-- image -->

Other examples of home trade in a country are:

<!-- image -->

A supermarket

<!-- image -->

<!-- image -->

A beauty salon                                 A hawker selling fruits

Figure 3: Examples of home trade

<!-- image -->

## 9.2.2 International trade

International trade takes place when two or more countries buy and  sell  products  with  each  other.  Trade  with  foreign  countries is  usually  classified  as  imports  and  exports. When  Li Wang  buys machinery  and  equipment  from  Germany,  international  trade takes place.

International trade takes place  when  two  or  more countries buy and sell products with each other.

Figure 4: International trade

<!-- image -->

<!-- image -->

## 9.3 Exports  and Imports

Enterprises are usually actively involved in business activities such as exports and imports of goods and services.

## 9.3.1  Exports

Export refers to the sale of goods and services to foreign countries. Exports  are  usually  highly  desirable  for  enterprises  and  the government because it brings money inflows into the country.

Export refers  to  the  sale  of goods and services to foreign countries.

For instance, Mauritius (seller) exports ready-made clothes to France (buyer) .

Figure 5: Exports from Mauritius

The image is a map of the United States, specifically focusing on the state of Pennsylvania. The map is divided into two main sections: the left and the right. 

The left section includes the states of Pennsylvania, which are colored in various shades of green, yellow, and blue. The states are labeled with their names in bold, and there are icons representing each state. The icons are of people, clothing, and other objects.

The right section includes the states of New Jersey, which are colored in a combination of red, yellow, and blue. The states are labeled with their names in bold, and there are icons representing each state. The icons are of people, clothing, and other objects.

There are also several icons representing different types of money, such as a coin, a dollar bill, and a check. The icons are arranged in a way that suggests a flow of money, with arrows indicating the direction of money flow.

The map is labeled with

<!-- image -->

## 9.3.2  Imports

The  purchase  of  goods  and  services  from  foreign  countries  is termed  as import .    Enterprises  usually  import  what  is  required as  raw  materials  or  any  other  goods  to  carry  out  their  business activities. Imports represent expenses to enterprises as they cause (buyer)

money to flow out of the country. For instance, Mauritius imports cars from Japan (seller) .

The image is a map of a country, specifically a part of the United States. The map includes the states of Maryland, Virginia, West Virginia, Ohio, Michigan, Indiana, Alabama, Tennessee, Illinois, Missouri, Kansas, Oklahoma, Texas, and Florida. The states are colored in different shades of blue, green, yellow, and red.

At the top of the image, there is a large orange arrow pointing from the state of Maryland to the state of Florida. This arrow is labeled with the text "IMPORT" in white font.

The map also includes a small section of text labeled "Money Outflows" in blue font. This text is located at the bottom right corner of the image.

The map is surrounded by a white background, which makes the colors of the states and the arrows stand out clearly.

The image does not contain any people, animals, or other objects, just the map of the United States.

<!-- image -->

<!-- image -->

Figure 6: Mauritian imports

<!-- image -->

## State whether the following statement is True or False.

| (a)   | Home trade is the buying and selling of goods and services locally.                         |
|-------|---------------------------------------------------------------------------------------------|
| (b)   | Businesses can only sell their products locally.                                            |
| (c)   | International trade is the buying and selling of goods and services from foreign countries. |
| (d)   | Exports lead to an outflow of money from the country.                                       |
| (e)   | Goods and services bought from another country are known as imports.                        |

## 9.4 Importance of international trade

International trade is an important economic activity in a country for the following reasons:

Trade is important  to countries because

- Money generated promotes economic development

- It allows sharing of technology and ideas

Consumers enjoy a variety of products

- Quality of life is enhanced

- Jobs are created

Import refers to the purchase of  goods  and  services  from foreign countries.

<!-- image -->

## Question 1

## Answer the following questions.

- (a) Tick ( ) to indicate which of the following is an export and an import for Mauritius.
- (b) Mauritius decides to increase the selling of ready-made clothes to France.

|     |                                                  | Export   | Import   |
|-----|--------------------------------------------------|----------|----------|
| (a) | Tourists visite Mauritius for holidays           |          |          |
| (b) | Purchase of oil from Nigeria                     |          |          |
| (c) | Selling sugar to Europe                          |          |          |
| (d) | Purchase of vehicles from Germany                |          |          |
| (e) | Mauritians travelling to Switzerland as tourists |          |          |

Explain one effect when a country increases its trade with another country.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Question 2

<!-- image -->

## Group discussion

Japan decides to limit the selling of cars to Mauritius.

Discuss the effects of Japan's decision on the economy of Mauritius.

<!-- image -->

## KEY TERMS

Export refers to the sale of goods and services to foreign countries.

Home trade is the buying and selling of goods and services within the country itself.

International trade takes place when two or more countries buy and sell products with each other.

Import refers to the purchase of goods and services from foreign countries.

Export refers to the sale of goods and services to foreign countries.

Trade is the buying and selling of products.

3

ACCOUNTING

28

14

## Learning Objectives:

## On completing this unit, you will be able to:

- explain the double entry principle
- record cash, bank and credit transactions in the ledger

In this unit, you will record business transactions (cash, bank and credit) in the ledger while following the double entry principle.

Business Organisations

Unit 10

Recording transactions in the ledger

## 10.1 Recording business transactions

Business  transactions  can  be  in  the  form  of  cash,  bank  and  credit.  These  transactions  are recorded using the double entry system.

Double entry system implies that each transaction affects two accounts: one account has a debit entry and the other account has a credit entry . This is also known as the dual aspect principle.

All accounts are kept in a book called the ledger . It is a book which consist of different accounts.

A ledger is  a  book  which consists of different accounts.

An account in the ledger is drawn below.

| Dr   | ................ Account   | ................ Account   | ................ Account   | ................ Account   | Cr     |
|------|----------------------------|----------------------------|----------------------------|----------------------------|--------|
| Date | Details                    | Amount                     | Date                       | Details                    | Amount |
|      |                            | Rs                         |                            |                            | Rs     |

Figure 1: An account in the ledger

## 10.2 Recording cash transactions

A cash transaction is a transaction that occurs when money is received or paid in cash immediately.

A cash transaction is a transaction  that  occurs  when money  is  received  or  paid  in cash immediately.

To record cash transactions, the following steps must be followed:

| Step 1   | Identify whether the cash transaction is a receipt of cash into the business or a payment in cash by the business.   |
|----------|----------------------------------------------------------------------------------------------------------------------|
| Step 2   | Identify the account to be debited and the account to be credited .                                                  |
| Step 3   | Posting in the ledger accounts.                                                                                      |

## Worked Example

## Step 1

Step 2

(a)

| Year 20X8   | Transaction                          | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|--------------------------------------|-------------------|-------------------|-------------------|--------------------|
| Jan 01      | Started business with cash Rs 30 000 |                   |                   | Cash              | Capital            |

| Dr     | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|--------|----------------|----------------|----------------|----------------|--------|
| Date   | Details        | Amount         | Date           | Details        | Amount |
| 20X8   |                | Rs             | 20X8           |                | Rs     |
| Jan 01 | Capital        | 30 000         |                |                |        |

| Dr   | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr     |
|------|-------------------|-------------------|-------------------|-------------------|--------|
| Date | Details           | Amount            | Date              | Details           | Amount |
| 20X8 |                   | Rs                | 20X8              |                   | Rs     |
|      |                   |                   | Jan 01            | Cash              | 30 000 |

Step 3 Posting in the ledger accounts.

| Year 20X8   | Transaction                     | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|---------------------------------|-------------------|-------------------|-------------------|--------------------|
| Jan 09      | Bought goods for cash Rs 10 000 |                   |                   | Purchases         | Cash               |

| Dr   | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |
|      |                |                | Jan 09         | Purchases      | 10 000 |

| Dr     | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr     |
|--------|---------------------|---------------------|---------------------|---------------------|--------|
| Date   | Details             | Amount              | Date                | Details             | Amount |
| 20X8   |                     | Rs                  | 20X8                |                     | Rs     |
| Jan 09 | Cash                | 10 000              |                     |                     |        |

(b)

(c)

(d)

| Year 20X8   | Transaction                          | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|--------------------------------------|-------------------|-------------------|-------------------|--------------------|
| Jan 20      | Paid electricity bills Rs 1 500 cash |                   |                   | Electricity       | Cash               |

| Dr   | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |
|      |                |                | Jan 20         | Electricity    | 1 500  |

| Dr     | Electricity Account   | Electricity Account   | Electricity Account   | Electricity Account   | Cr     |
|--------|-----------------------|-----------------------|-----------------------|-----------------------|--------|
| Date   | Details               | Amount                | Date                  | Details               | Amount |
| 20X8   |                       | Rs                    | 20X8                  |                       | Rs     |
| Jan 20 | Cash                  | 1 500                 |                       |                       |        |

| Year 20X8   | Transaction                         | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|-------------------------------------|-------------------|-------------------|-------------------|--------------------|
| Jan 24      | Bought furniture for cash Rs 10 000 |                   |                   | Furniture         | Cash               |

| Dr   | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |
|      |                |                | Jan 24         | Furniture      | 10 000 |

| Dr     | Furniture Account   | Furniture Account   | Furniture Account   | Furniture Account   | Cr     |
|--------|---------------------|---------------------|---------------------|---------------------|--------|
| Date   | Details             | Amount              | Date                | Details             | Amount |
| 20X8   |                     | Rs                  | 20X8                |                     | Rs     |
| Jan 24 | Cash                | 10 000              |                     |                     |        |

| Dr     | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|--------|----------------|----------------|----------------|----------------|--------|
| Date   | Details        | Amount         | Date           | Details        | Amount |
| 20X8   |                | Rs             | 20X8           |                | Rs     |
| Jan 01 | Capital        | 30 000         | Jan 09         | Purchases      | 10 000 |
|        |                |                | Jan 20         | Electricity    | 1 500  |
|        |                |                | Jan 24         | Furniture      | 10 000 |

Note: All transactions that include cash should be recorded in one same cash account.

<!-- image -->

Record each of the following transactions using the double entry system.

(a)

| Year 20X8   | Transaction                          | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|--------------------------------------|-------------------|-------------------|-------------------|--------------------|
| Mar 01      | Started business with cash Rs 50 000 |                   |                   | Cash              | Capital            |

| Dr   | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |

| Dr   | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr     |
|------|-------------------|-------------------|-------------------|-------------------|--------|
| Date | Details           | Amount            | Date              | Details           | Amount |
| 20X8 |                   | Rs                | 20X8              |                   | Rs     |

| Year 20X8   | Transaction                   | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|-------------------------------|-------------------|-------------------|-------------------|--------------------|
| Mar 08      | Sold goods for cash Rs 20 000 |                   |                   | Cash              | Sales              |

| Dr   | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |

| Dr   | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr     |
|------|-----------------|-----------------|-----------------|-----------------|--------|
| Date | Details         | Amount          | Date            | Details         | Amount |
| 20X8 |                 | Rs              | 20X8            |                 | Rs     |

(b)

(c)

(d)

| Year 20X8   | Transaction                  | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|------------------------------|-------------------|-------------------|-------------------|--------------------|
| Mar 12      | Paid wages in cash Rs 15 000 |                   |                   |                   |                    |

| Dr   | ........................... Account   | ........................... Account   | ........................... Account   | ........................... Account   | Cr     |
|------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|--------|
| Date | Details                               | Amount                                | Date                                  | Details                               | Amount |
| 20X8 |                                       | Rs                                    | 20X8                                  |                                       | Rs     |

| Dr   | ........................... Account   | ........................... Account   | ........................... Account   | ........................... Account   | Cr     |
|------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|--------|
| Date | Details                               | Amount                                | Date                                  | Details                               | Amount |
| 20X8 |                                       | Rs                                    | 20X8                                  |                                       | Rs     |

| Year 20X8   | Transaction                         | Receipt of cash   | Payment in cash   | Account debited   | Account credited   |
|-------------|-------------------------------------|-------------------|-------------------|-------------------|--------------------|
| Jan 09      | Bought equipment for cash Rs 16 000 |                   |                   |                   |                    |

| Dr   | ........................... Account   | ........................... Account   | ........................... Account   | ........................... Account   | Cr     |
|------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|--------|
| Date | Details                               | Amount                                | Date                                  | Details                               | Amount |
| 20X8 |                                       | Rs                                    | 20X8                                  |                                       | Rs     |

| Dr   | ........................... Account   | ........................... Account   | ........................... Account   | ........................... Account   | Cr     |
|------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|--------|
| Date | Details                               | Amount                                | Date                                  | Details                               | Amount |
| 20X8 |                                       | Rs                                    | 20X8                                  |                                       | Rs     |

## 10.3  Recording bank transactions

A bank transaction is a transaction that occurs when money is received or paid by cheque.

A bank transaction is a transaction that occurs when money is received or paid by cheque.

To record bank transactions, the following steps must be followed:

| Step 1   | Identifywhetherthebanktransactionisa receipt intothebusinessora payment by the business.   |
|----------|--------------------------------------------------------------------------------------------|
| Step 2   | Identify the account to be debited and the account to be credited .                        |
| Step 3   | Posting in the ledger accounts.                                                            |

## Worked Example

## Step 1

| Year 20X8 (a)   | Transaction                                  | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-----------------|----------------------------------------------|---------------------|--------------------|-------------------|--------------------|
| Feb 01          | Started business with cash at bank Rs 50 000 |                     |                    | Bank              | Capital            |

Step 2

| Dr     | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|--------|----------------|----------------|----------------|----------------|--------|
| Date   | Details        | Amount         | Date           | Details        | Amount |
| 20X8   |                | Rs             | 20X8           |                | Rs     |
| Feb 01 | Capital        | 50 000         |                |                |        |

| Dr   | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr     |
|------|-------------------|-------------------|-------------------|-------------------|--------|
| Date | Details           | Amount            | Date              | Details           | Amount |
| 20X8 |                   | Rs                | 20X8              |                   | Rs     |
|      |                   |                   | Feb 01            | Bank              | 50 000 |

Step 3 Posting in the ledger accounts.

(b)

| Year 20X8   | Transaction                             | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|-----------------------------------------|---------------------|--------------------|-------------------|--------------------|
| Feb 13      | Bought goods paying by cheque Rs 25 000 |                     |                    | Purchases         | Bank               |

| Dr   | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |
|      |                |                | Feb 13         | Purchases      | 25 000 |

| Dr     | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr     |
|--------|---------------------|---------------------|---------------------|---------------------|--------|
| Date   | Details             | Amount              | Date                | Details             | Amount |
| 20X8   |                     | Rs                  | 20X8                |                     | Rs     |
| Feb 13 | Bank                | 25 000              |                     |                     |        |

(c)

(d)

<!-- image -->

| Year 20X8   | Transaction                          | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|--------------------------------------|---------------------|--------------------|-------------------|--------------------|
| Feb 17      | Bought furniture Rs 20 000 by cheque |                     |                    | Furniture         | Bank               |

| Dr   | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |
|      |                |                | Feb 17         | Furniture      | 20 000 |

Dr

Furniture Account

Cr

| Date   | Details   | Amount   | Date   | Details   | Amount   |
|--------|-----------|----------|--------|-----------|----------|
| 20X8   |           | Rs       | 20X8   |           | Rs       |
| Feb 17 | Bank      | 20 000   |        |           |          |

<!-- image -->

| Year 20X8   | Transaction                        | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|------------------------------------|---------------------|--------------------|-------------------|--------------------|
| Feb 24      | Paid insurance Rs 12 000 by cheque |                     |                    | Insurance         | Bank               |

| Dr   | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |
|      |                |                | Feb 24         | Insurance      | 12 000 |

Dr

## Insurance Account

Cr

| Date   | Details   | Amount   | Date   | Details   | Amount   |
|--------|-----------|----------|--------|-----------|----------|
| 20X8   |           | Rs       | 20X8   |           | Rs       |
| Feb 24 | Bank      | 12 000   |        |           |          |

| Dr     | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|--------|----------------|----------------|----------------|----------------|--------|
| Date   | Details        | Amount         | Date           | Details        | Amount |
| 20X8   |                | Rs             | 20X8           |                | Rs     |
| Feb 01 | Capital        | 50 000         | Feb 13         | Purchases      | 25 000 |
|        |                |                | Feb 17         | Furniture      | 20 000 |
|        |                |                | Feb 24         | Insurance      | 12 000 |

Note: All transactions that are done through the bank should be recorded in one same bank account.

<!-- image -->

Record each of the following transactions using the double entry system.

(a)

| Year 20X8   | Transaction                                  | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|----------------------------------------------|---------------------|--------------------|-------------------|--------------------|
| May 01      | Started business with cash at bank Rs 45 000 |                     |                    | Bank              | Capital            |

| Dr   | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |

| Dr   | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr     |
|------|-------------------|-------------------|-------------------|-------------------|--------|
| Date | Details           | Amount            | Date              | Details           | Amount |
| 20X8 |                   | Rs                | 20X8              |                   | Rs     |

| Year 20X8   | Transaction                         | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|-------------------------------------|---------------------|--------------------|-------------------|--------------------|
| May 07      | Paid advertising Rs 7 000 by cheque |                     |                    | Advertising       | Bank               |

| Dr   | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |

| Dr   | Advertising Account   | Advertising Account   | Advertising Account   | Advertising Account   | Cr     |
|------|-----------------------|-----------------------|-----------------------|-----------------------|--------|
| Date | Details               | Amount                | Date                  | Details               | Amount |
| 20X8 |                       | Rs                    | 20X8                  |                       | Rs     |

(b)

(c)

(d)

| Year 20X8   | Transaction                                | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|--------------------------------------------|---------------------|--------------------|-------------------|--------------------|
| May 12      | Sold goods and received cheque of Rs 5 000 |                     |                    | ................. | .................  |

| Dr   | .................... Account   | .................... Account   | .................... Account   | .................... Account   | Cr     |
|------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------|
| Date | Details                        | Amount                         | Date                           | Details                        | Amount |
| 20X8 |                                | Rs                             | 20X8                           |                                | Rs     |

| Dr   | .................... Account   | .................... Account   | .................... Account   | .................... Account   | Cr     |
|------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------|
| Date | Details                        | Amount                         | Date                           | Details                        | Amount |
| 20X8 |                                | Rs                             | 20X8                           |                                | Rs     |

<!-- image -->

| Year 20X8   | Transaction                                   | Receipt of cheque   | Payment bycheque   | Account debited   | Account credited   |
|-------------|-----------------------------------------------|---------------------|--------------------|-------------------|--------------------|
| May 18      | Bought Motor Vehicles for Rs 75 000 by cheque |                     |                    | ................. | .................  |

| Dr   | .................... Account   | .................... Account   | .................... Account   | .................... Account   | Cr     |
|------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------|
| Date | Details                        | Amount                         | Date                           | Details                        | Amount |
| 20X8 |                                | Rs                             | 20X8                           |                                | Rs     |

| Dr   | .................... Account   | .................... Account   | .................... Account   | .................... Account   | Cr     |
|------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------|
| Date | Details                        | Amount                         | Date                           | Details                        | Amount |
| 20X8 |                                | Rs                             | 20X8                           |                                | Rs     |

## 10.4 Recording credit transactions

Some business transactions do not involve an immediate change in cash in hand or cash at bank. They are known as credit transactions. A credit transaction is  a  business transaction that is paid at later date. Businesses usually have credit purchases as well as credit sales.

Credit purchases are  goods  bought by a business but for which payment  is  done  later  to  the  supplier.  The  amount  owed  to  the supplier is known as trade payable.

Credit transaction is a business  transaction  that  is paid at later date.

Credit  purchases are  goods bought by a business but for which payment is done later.

Credit sales are goods sold by a business, but receipts are obtained later  from  the  customer.  The  amount  the  customer  owes  the business is known as trade receivable.

Credit sales are the sale of  goods  by  a  business  but receipts are obtained later.

Credit  purchases will  affect two  accounts :  One  is  the purchases  account and  the  other account goes by the name of the credit supplier.

Credit sales will affect two accounts : One is the sales account and the other account goes by the name of the credit customer.

## I      Recording of credit purchases

Credit purchases will affect two accounts: one is Purchases Account and the other is known by the name of the credit supplier (trade payable) .

| Purchases Account                                     | 1st Account   | to be debited   |
|-------------------------------------------------------|---------------|-----------------|
| [Name of the credit supplier] Account (trade payable) | 2nd Account   | to be credited  |

## Example 1

On 02 June, goods were bought on credit for Rs 50 000 from a supplier, Paul et Virginie Store.

Credit purchases will affect two accounts:

| Purchases Account                                  | 1st Account (Rs 50 000)   | to be debited   |
|----------------------------------------------------|---------------------------|-----------------|
| [ Paul et Virginie Store ] Account (trade payable) | 2nd Account (Rs 50 000)   | to be credited  |

Postings in the ledger accounts.

## Purchases Account is debited (left side)

| Dr     | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr     |
|--------|---------------------|---------------------|---------------------|---------------------|--------|
| Date   | Details             | Amount              | Date                | Details             | Amount |
| 20X8   |                     | Rs                  | 20X8                |                     | Rs     |
| Jun 02 | Paul et Virginie    | 50 000              |                     |                     |        |

## Paul et Virginie Account (Trade payable) is credited (right side)

| Dr   | Paul et Virginie Account   | Paul et Virginie Account   | Paul et Virginie Account   | Paul et Virginie Account   | Cr     |
|------|----------------------------|----------------------------|----------------------------|----------------------------|--------|
| Date | Details                    | Amount                     | Date                       | Details                    | Amount |
| 20X8 |                            | Rs                         | 20X8                       |                            | Rs     |
|      |                            |                            | Jun 02                     | Purchases                  | 50 000 |

## Activity 3

On 08 June, goods were bought on credit for Rs 60 000 from a supplier, 'Kari Mélanz' .

Record the transaction in the account provided below.

| Purchases Account                         | 1st Account (Rs 60 000)   | to be debited   |
|-------------------------------------------|---------------------------|-----------------|
| [ ' Kari Mélanz'] Account (trade payable) | 2nd Account (Rs 60 000)   | to be credited  |

Postings in the ledger accounts.

## Purchases Account is debited (left side)

| Dr   | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr     |
|------|---------------------|---------------------|---------------------|---------------------|--------|
| Date | Details             | Amount              | Date                | Details             | Amount |
| 20X8 |                     | Rs                  | 20X8                |                     | Rs     |

## 'Kari Mélanz' Account (Trade payable) is credited (right side)

| Dr   | Kari Mélanz Account   | Kari Mélanz Account   | Kari Mélanz Account   | Kari Mélanz Account   | Cr     |
|------|-----------------------|-----------------------|-----------------------|-----------------------|--------|
| Date | Details               | Amount                | Date                  | Details               | Amount |
| 20X8 |                       | Rs                    | 20X8                  |                       | Rs     |

<!-- image -->

On 11 June, goods were bought on credit for Rs 35 000 from a supplier, Kitchen Planet Company Ltd.

Record the transaction in the account provided below.

| Purchases Account                                    | 1st Account (Rs 35 000)   | to be debited   |
|------------------------------------------------------|---------------------------|-----------------|
| [Kitchen Planet Company Ltd] Account (trade payable) | 2nd Account (Rs 35 000)   | to be credited  |

Postings in the ledger accounts.

## Purchases Account is debited (left side)

| Dr   | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr     |
|------|---------------------|---------------------|---------------------|---------------------|--------|
| Date | Details             | Amount              | Date                | Details             | Amount |
| 20X8 |                     | Rs                  | 20X8                |                     | Rs     |

## Kitchen Planet Company Ltd Account (Trade payable) is credited (right side)

| Dr   | ......................... Account   | ......................... Account   | ......................... Account   | ......................... Account   | Cr     |
|------|-------------------------------------|-------------------------------------|-------------------------------------|-------------------------------------|--------|
| Date | Details                             | Amount                              | Date                                | Details                             | Amount |
| 20X8 |                                     | Rs                                  | 20X8                                |                                     | Rs     |

<!-- image -->

## Fill in the blanks with the appropriate words.

## cash transaction       business transaction        bank transaction         credit transaction

- (a) A ……………………………. is an activity or an event that takes place in an enterprise and that involves money.
- (b)

A ……………………………… transaction occurs when money is received or paid in cash immediately.

- A ………………………….. transaction occurs when money is received or paid by
- (c) cheque or cards.

## II   Recording of credit sales

Credit sales will affect two accounts: one is Sales Account and the other is known by the name of the credit customer who owes the business (trade receivable) .

## Credit sales will affect two accounts:

| [Name of the credit customer] Account (trade receivable)   | 1st Account   | to be debited   |
|------------------------------------------------------------|---------------|-----------------|
| Sales Account                                              | 2nd Account   | to be credited  |

## Example 1

On 03 September, business sold goods on credit to a customer, Neel, for Rs 75 000.

Credit sales will affect two accounts:

| [Neel] Account (trade receivable)   | 1st Account (Rs 75 000)   | to be debited   |
|-------------------------------------|---------------------------|-----------------|
| Sales Account                       | 2nd Account (Rs 75 000)   | to be credited  |

Postings in the ledger accounts.

## Neel Account (Trade receivable) is debited (left side)

| Dr      | Neel Account   | Neel Account   | Neel Account   | Neel Account   | Cr     |
|---------|----------------|----------------|----------------|----------------|--------|
| Date    | Details        | Amount         | Date           | Details        | Amount |
| 20X8    |                | Rs             | 20X8           |                | Rs     |
| Sept 03 | Sales          | 75 000         |                |                |        |

| Dr   | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr     |
|------|-----------------|-----------------|-----------------|-----------------|--------|
| Date | Details         | Amount          | Date            | Details         | Amount |
| 20X8 |                 | Rs              | 20X8            |                 | Rs     |
|      |                 |                 | Sept 03         | Neel            | 75 000 |

<!-- image -->

On 12 September 20X8, goods were sold on credit for Rs 25 000 to a customer, Kiran.

Record the transaction in the account provided below.

| [Kiran] Account (trade receivable)   | 1st Account (Rs 25 000)   | to be debited   |
|--------------------------------------|---------------------------|-----------------|
| Sales Account                        | 2nd Account (Rs 25 000)   | to be credited  |

| Dr   | Kiran Account   | Kiran Account   | Kiran Account   | Kiran Account   | Cr     |
|------|-----------------|-----------------|-----------------|-----------------|--------|
| Date | Details         | Amount          | Date            | Details         | Amount |
| 20X8 |                 | Rs              | 20X8            |                 | Rs     |

| Dr   | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr     |
|------|-----------------|-----------------|-----------------|-----------------|--------|
| Date | Details         | Amount          | Date            | Details         | Amount |
| 20X8 |                 | Rs              | 20X8            |                 | Rs     |

## Activity 7

On 02 February 20X8, goods were sold on credit for Rs 58 000 to a customer, Kesto Company Ltd.

Record the transaction in the account provided below.

| [Kesto Company Ltd] Account (trade receivable)   | 1st Account (Rs 58 000)   | to be debited   |
|--------------------------------------------------|---------------------------|-----------------|
| Sales Account                                    | 2nd Account (Rs 58 000)   | to be credited  |

| Dr   | Kesto Company Ltd Account   | Kesto Company Ltd Account   | Kesto Company Ltd Account   | Kesto Company Ltd Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr     |
|------|-----------------|-----------------|-----------------|-----------------|--------|
| Date | Details         | Amount          | Date            | Details         | Amount |
| 20X8 |                 | Rs              | 20X8            |                 | Rs     |

<!-- image -->

Record the following transactions in the ledger accounts of Kim for the month of April 20X9. (a) April 01 - Started business with cash in hand Rs 40 000.

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

- (b) April 03 -Bought goods Rs 5 000 by cash.
- (c) April 05 - Sold goods on credit to Jessica Rs 8 000.

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

## (d) April 08 - Purchased Motor Vehicles Rs 20 000 by cash.

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

## (e) April 12 - Paid stationery in cash Rs 1 000.

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

## (f ) April 13 - Bought goods on credit from Eric Rs 24 000.

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
| 20X8 |                             | Rs                          | 20X8                        |                             | Rs     |

<!-- image -->

## Question 1

## Multiple Choice Questions

Choose the correct answer for each of the questions below and write it in the space provided.

1. A transaction can be in the form of ………………………………...

1. Cash

2. Bank

3. Credit

A 1 Only

B 1 and 2

C 2 and 3

D 1, 2 and 3

Answer \_\_\_\_\_\_\_\_

2. 'There is a debit entry in one account (left side) and a corresponding credit entry in another account (right side)' . Which one best describe the above statement?

A Ledger

B Account

C Double entry system

D Transaction

Answer \_\_\_\_\_\_\_\_

3. The enterprise gets credit facilities from its suppliers. It buys goods now and pays later.

This is known as …………..

A Capital

B Drawings

C Credit Sales

D Credit Purchases

Answer \_\_\_\_\_\_\_\_

4. Nazira sold goods for cash Rs 10 000.

How is this transaction recorded in the books of Nazira?

- A Debit Cash

Credit Sales

- B Debit Sales

Credit Cash

- C Debit Purchases

Credit Cash

- D Debit Cash

Credit Purchases

Answer \_\_\_\_\_\_\_\_

5. Money needed to start up a business is called …………….

A Cash transaction

B Credit transaction

C Capital

D Drawings

Answer \_\_\_\_\_\_\_\_

## Question 2

Record the following transactions in the ledger accounts below.

- (a) April 01 - Started business with cash at bank Rs 90 000.
- (b) April 03 - Purchased goods on credit from a supplier, Hema, Rs 15 000.
- (c) April 05 - Credit sales Rs 75 000 to customer, Melina.

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
|      |                             | Rs                          |                             |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
|      |                             | Rs                          |                             |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
|      |                             | Rs                          |                             |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
|      |                             | Rs                          |                             |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
|      |                             | Rs                          |                             |                             | Rs     |

| Dr   | ................. Account   | ................. Account   | ................. Account   | ................. Account   | Cr     |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|--------|
| Date | Details                     | Amount                      | Date                        | Details                     | Amount |
|      |                             | Rs                          |                             |                             | Rs     |

## Question 3

## For each of the transaction below, state which of the accounts are to be debited or credited.

|      |                                                  | Account to be debited   | Account to be credited   |
|------|--------------------------------------------------|-------------------------|--------------------------|
| (a)  | Started business with cash Rs 40 000             |                         |                          |
| (b)  | Paid rent by cheque Rs 7 000                     |                         |                          |
| (c)  | Bought a motor vehicle Rs 50 000                 |                         |                          |
| (d)  | Sold goods on credit to Aishah Rs 30 000         |                         |                          |
| (e)  | Purchased goods for cash Rs 20 000               |                         |                          |
| (f ) | Bought goods on credit from Plaza Bros Rs 50 000 |                         |                          |
| (g)  | Bought goods Rs 10 000 from Kamla, a supplier    |                         |                          |
| (h)  | Purchased furniture Rs 8 000 in cash             |                         |                          |
| (i)  | Cash Sales Rs 46 000                             |                         |                          |

<!-- image -->

Bank transaction is a transaction that occurs when money is received or paid by cheque.

Cash transaction is a transaction that occurs when money is received or paid in cash immediately.

Credit transaction is a transaction where payment is not made immediately but at a later date.

Credit purchases are goods bought by a business but for which payment is done later.

Credit sales are the sale of goods by a business but receipts are obtained later.

Ledger is a book which consists of different accounts.

In this image we can see a paper with numbers and numbers written on it.

<!-- image -->

Balancing of accounts

Unit 11

Balancing of accounts in the ledger

## Learning Objectives:

## On completing this unit, you will be able to:

- balance individual accounts
- identify balance carried down and balance brought down

In this unit, you will calculate the balances of ledger accounts.

## 11.1 Steps to balance ledger accounts

After the bookkeeper records all business transactions in ledger accounts, each of the accounts must be balanced. The exercise of balancing an account consists of several steps.

To balance an account, the following steps must be followed:

| Step 1   | Calculate the totals of both sides, namely, Dr and Cr.                      |
|----------|-----------------------------------------------------------------------------|
| Step 2   | The difference between both is known as balance c/d.                        |
| Step 3   | Record the same amount as balance b/d on the opposite side below the total. |

An example has been done below.

## Worked example 1. Follow the steps.

| Dr     | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr     |
|--------|----------------|----------------|----------------|----------------|--------|
| Date   | Details        | Rs             | Date           | Details        | Rs     |
| Mar 01 | Capital        | 25 000         | Mar 02         | Furniture      | 10 000 |
| Mar 09 | Sales          | 14 000         | Mar 05         | Purchases      | 7 000  |
|        |                |                | Mar 12         | Rent           | 2 000  |
|        |                |                | Mar 31         | Balance c/d    | 20 000 |
|        |                | 39 000         |                |                | 39 000 |
| Apr 01 | Balance b/d    | 20 000         |                |                |        |

The balance brought down (b/d) of the above cash account is on the debit side This means the above cash account has a debit balance .

.

## Worked example 2. Follow the steps.

| Dr     | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr            |
|--------|-------------------|-------------------|-------------------|-------------------|---------------|
| Date   | Details           | Rs                | Date              | Details           | Rs            |
| Jan 31 | Balance c/d       | 80 000            | Mar 01 Mar 28     | Cash Bank         | 30 000 50 000 |
|        |                   | 80 000            |                   |                   | 80 000        |
|        |                   |                   | Feb 01            | Balance b/d       | 80 000        |

## Worked example 3. Follow the steps.

| Dr     | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr     |
|--------|---------------------|---------------------|---------------------|---------------------|--------|
| Date   | Details             | Rs                  | Date                | Details             | Rs     |
| Jun 04 | Cash                | 25 600              |                     |                     |        |
| Jun 20 | Reena               | 5 400               |                     |                     |        |
| Jun 23 | Sarah               | 2 000               | Jun 30              | Balance c/d         | 33 000 |
|        |                     | 33 000              |                     |                     | 33 000 |
| Jul 01 | Balance b/d         | 33 000              |                     |                     |        |

## Worked example 4. Follow the steps.

| Dr     | Sales Account   | Sales Account   | Sales Account        | Sales Account         | Cr                  |
|--------|-----------------|-----------------|----------------------|-----------------------|---------------------|
| Date   | Details         | Rs              | Date                 | Details               | Rs                  |
| Sep 30 | Balance c/d     | 53 000          | Sep 05 Sep 17 Sep 24 | Bank Roland Catherine | 28 000 20 000 5 000 |
| Sep 30 |                 | 53 000          |                      |                       | 53 000              |
| Sep 30 |                 |                 | Oct 01               | Balance b/d           | 53 000              |

<!-- image -->

## Activity 1

Work out the balances (balance c/d and balance b/d) of the following accounts for the month of January.

| Dr     | Reena Account   | Reena Account   | Reena Account   | Reena Account   | Cr    |
|--------|-----------------|-----------------|-----------------|-----------------|-------|
| Date   | Details         | Rs              | Date            | Details         | Rs    |
| Jan 10 | Cash            | 100             | Jan 03          | Purchases       | 2 000 |
| Jan 15 | Cash            | 900             | Jan 21          | Purchases       | 3 300 |
| Jan 30 | Bank            | 1 300           |                 |                 |       |

| Dr     | Sarah Account   | Sarah Account   | Sarah Account   | Sarah Account   | Cr    |
|--------|-----------------|-----------------|-----------------|-----------------|-------|
| Date   | Details         | Rs              | Date            | Details         | Rs    |
| Jan 06 | Sales           | 5 400           | Jan 10          | Cash            | 250   |
| Jan 19 | Sales           | 1 200           | Jan 15          | Bank            | 2 650 |
|        |                 |                 | Jan 30          | Bank            | 3 100 |

<!-- image -->

Work out the balances of the following accounts for the month of February 20X8.

| Dr     | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr    |
|--------|----------------|----------------|----------------|----------------|-------|
| Date   | Details        | Rs             | Date           | Details        | Rs    |
| Feb 01 | Capital        | 15 000         | Feb 05         | Purchases      | 9 500 |
| Feb 12 | Sales          | 2 600          | Feb 17         | Rent           | 2 000 |
|        |                |                | Feb 28         | Drawings       | 1 000 |

| Dr     | Bank Account   | Bank Account   | Bank Account   | Bank Account          | Cr     |
|--------|----------------|----------------|----------------|-----------------------|--------|
| Date   | Details        | Rs             | Date           | Details               | Rs     |
| Feb 01 | Capital        | 25 000         | Feb 04         | Fixtures and fittings | 11 000 |
| Feb 28 | Girish         | 750            |                |                       |        |

## Activity 3

Work out the balances of the following accounts for the month of February 20X8.

| Dr   | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr            |
|------|-------------------|-------------------|-------------------|-------------------|---------------|
| Date | Details           | Rs                | Date              | Details           | Rs            |
|      |                   |                   | Feb 01 Feb 02     | Cash Bank         | 15 000 25 000 |

| Dr     | Fixtures and Fittings Account   | Fixtures and Fittings Account   | Fixtures and Fittings Account   | Fixtures and Fittings Account   | Cr   |
|--------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|------|
| Date   | Details                         | Rs                              | Date                            | Details                         | Rs   |
| Feb 04 | Bank                            | 11 000                          |                                 |                                 |      |

| Dr     | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr   |
|--------|---------------------|---------------------|---------------------|---------------------|------|
| Date   | Details             | Rs                  | Date                | Details             | Rs   |
| Feb 05 | Cash                | 9 500               |                     |                     |      |

| Dr   | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr    |
|------|-----------------|-----------------|-----------------|-----------------|-------|
| Date | Details         | Rs              | Date            | Details         | Rs    |
|      |                 |                 | Feb 12          | Cash            | 2 600 |
|      |                 |                 | Feb 19          | Girish          | 1 500 |

| Dr     | Rent Account   | Rent Account   | Rent Account   | Rent Account   | Cr   |
|--------|----------------|----------------|----------------|----------------|------|
| Date   | Details        | Rs             | Date           | Details        | Rs   |
| Feb 17 | Cash           | 2 000          |                |                |      |

<!-- image -->

Note: Have you noticed that some accounts have their balance b/d on the debit side while others have their balance b/d on the credit side?

Accounts having debit balances

When balance b/d of an account is on the credit side, it is said that the account has a credit balance. (e.g, loan, sales, interest received and capital)

When balance b/d of an account is on the debit side, it is said that the account has a debit balance. (e.g, land and building, furniture, vehicles, cash)

<!-- image -->

## Question 1

## Multiple Choice Questions

Choose the correct answer for each of the questions below and write it in the space provided.

1. The balance of an account is calculated as

- A the total of the debit side

- B the total of the credit side

- C the difference between the totals of the debit and credit sides

- D the sum of all entries

Answer \_\_\_\_\_\_\_\_

2. The total on the debit side of an account is greater than its total on the credit side.

What does this mean?

- A the account has a debit balance

- B the account has a credit balance

- C the account cannot be balanced

- D the account has no balance

Answer \_\_\_\_\_\_\_\_

3. A credit balance occurs in a ledger account when

- A the total on its debit side is greater than the total on its credit side

- B the total on its debit side is less than the total on its credit side

- C the total on its debit side is equal to the total on its credit side

- D the total is zero in the ledger account

Answer \_\_\_\_\_\_\_\_

## Question 2

## Fill in the blanks using the words given below.

balance c/d

greater                        less

- (a)

The \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ of account is the difference between the total of debit

entries and the total of credit entries.

- (b) An  account  is  said  to  have  a  debit  balance  when  the  total  of  debit  entries  is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ than total of credit entries.

- (c) An  account  is  said  to  have  a  credit  balance  when  the  total  of  debit  entries  is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ than total of credit entries.

## Question 3

## Balance the following ledger accounts.

1.

| Dr     | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr   |
|--------|---------------------|---------------------|---------------------|---------------------|------|
| Date   | Details             | Rs                  | Date                | Details             | Rs   |
| Jan 07 | Cash                | 2 500               |                     |                     |      |
| Jan 17 | Ming                | 3 000               |                     |                     |      |
| Jan 28 | Bank                | 3 400               |                     |                     |      |

2.

| Dr   | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr     |
|------|-------------------|-------------------|-------------------|-------------------|--------|
| Date | Details           | Rs                | Date              | Details           | Rs     |
|      |                   |                   | Jan 01            | Cash              | 10 000 |

3.

| Dr   | Meera Account   | Meera Account   | Meera Account   | Meera Account   | Cr    |
|------|-----------------|-----------------|-----------------|-----------------|-------|
| Date | Details         | Rs              | Date            | Details         | Rs    |
|      |                 |                 | Jan 15          | Cash            | 1 000 |

4.

| Dr     | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr    |
|--------|----------------|----------------|----------------|----------------|-------|
| Date   | Details        | Rs             | Date           | Details        | Rs    |
| Jan 03 | Ali            | 2 000          | Jan 04         | Equipment      | 4 000 |
| Jan 06 | Sales          | 3 000          |                |                |       |

## Question 4

An inexperienced bookkeeper prepared the following bank account. It contains several errors. You are required to rework it in the blank bank account given below.

| Dr     | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr      |
|--------|----------------|----------------|----------------|----------------|---------|
| Date   | Details        | Amount         | Date           | Details        | Amount  |
| 20X8   |                | Rs             | 20X8           |                | Rs      |
| Feb 01 | Capital        | 50 000         | Feb 13         | Purchases      | 25 000  |
| Feb 07 | Sales          | 30 000         | Feb 20         | Furniture      | 20 000  |
|        |                |                | Feb 24         | Insurance      | 12 000  |
|        |                |                |                | Balance c/d    | 75 000  |
|        |                | 100 000        |                |                | 100 000 |
|        | Balance b/d    | 85 000         |                |                |         |

| Dr   | Bank Account   | Bank Account   | Bank Account   | Bank Account   | Cr     |
|------|----------------|----------------|----------------|----------------|--------|
| Date | Details        | Amount         | Date           | Details        | Amount |
| 20X8 |                | Rs             | 20X8           |                | Rs     |

4

## Learning Objectives:

## On completing this unit, you will be able to:

- -Identify debit and credit items
- -Draw the trial balance
- -Prepare a trial balance from ledger balances
- -Prepare a trial balance from independent figures

In this unit, you will identify debit and credit items in the ledger. Using these items, you will then learn and practise how to prepare a trial balance.

Unit 12 Trial Balance

## 12.1 Trial Balance

Read the following conversation between Anil, the entrepreneur, and Rita, the bookkeeper.

Hello Anil.

It is nice to see that you have recorded your transactions and balanced your ledger accounts.

Thank you, Rita. Did I do it correctly?

Precisely, this is what you need to check. For that you need to prepare a Trial Balance.

<!-- image -->

A trial  balance is  list  of  ledger  accounts  and  their  respective balances at a particular date. They are usually prepared at the end of each month or year.

A trial balance is list of ledger accounts and their respective balances at a particular date.

When transactions have been correctly recorded in  the  ledger using the double entry system and accounts correctly balanced, the trial balance should always agree . That is, the total of debit balances should always be equal to the total of credit balances.

The trial  balance should always balance.

Total of debit balances  =  Total of credit balances

## Purpose of preparing the trial balance

The trial balance is prepared for the following reasons:

- To check the mathematical accuracy of the double entry recording of business transactions.
- It also helps in the preparation of financial statements (the income statement and the statement of financial position).

## 12.2 Format of trial balance

The format of a trial balance is presented below. It consists of the debit and credit transactions recorded in the appropriate column.

## Mobicom Enterprise Trial Balance as at 30 September 20X9

## List of ledger accounts

| Title of Account   | Debit (Rs)   | Credit (Rs)   |
|--------------------|--------------|---------------|
| Capital            |              | 50 000        |
| Cash               | 6 300        | Cr Balances   |
| Bank               | 13 500       |               |
| Equipment          | 20 000       |               |
| Purchases          | 25 600       |               |
| Sales              | Balances     | 35 800        |
| Jane (Supplier)    |              | 1 100         |
| Chong (Customer)   | 3 700        |               |
| Wages              | 5 500        |               |
| Rent               | 4 500        |               |
| General expenses   | 7 800        |               |
|                    | 86 900       | 86 900        |

Total of debit balances = Total of credit balances

## 12.3 Preparing the Trial Balance

## Preparing Trial Balance from Ledger Balances

The trial balance can be extracted from a list of ledger balances. It can be obtained by following the steps below.

| Step 1   | Identify the ledger balances (balance b/d) of each account.                              |
|----------|------------------------------------------------------------------------------------------|
| Step 2   | Recordthemas debit item or credit item in their respective columns in the trial balance. |
| Step 3   | Add each column and check if the debit side agrees with the credit side.                 |

1 1

## What does debit balances represent?

Debit balances are recorded in the debit column of the trial balance. The balance b/d is found on their debit side of the ledger account.

## An expense and an asset have a debit balance.

Examples of accounts with a debit balance are as follows:

Expenses: Purchases, Rent, Drawings, Inventory, Salaries, Electricity, etc...

Assets: Furniture, Trade receivables, Cash, Bank, etc...

2 2

## What does credit balances represent?

Credit balances are recorded in the credit column of the trial balance. The balance b/d is found on their credit side of the ledger account.

## An income and a liability have a credit balance.

Examples of accounts with a credit balance are as follows:

Income: Interest received, Commission received, etc...

Liability: Loan, Trade payables, bank overdraft, etc...

## The trial balance below has been extracted from the ledger accounts found below numbered 1 to 6.

## Trial Balance

| Title of Account   | Title of Account   | Debit (Rs)   | Credit (Rs)   |
|--------------------|--------------------|--------------|---------------|
|                    | Cash               | 5 100        |               |
|                    | Capital            |              | 15 000        |
|                    | Purchases          | 9 500        |               |
|                    | Sales              |              | 2 600         |
|                    | Rent               | 2 000        |               |
|                    | Drawings           | 1 000        |               |
|                    |                    | 17 600       | 17 600        |

## Ledger accounts

<!-- image -->

| Dr     | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr     |
|--------|-------------------|-------------------|-------------------|-------------------|--------|
| Date   | Details           | Rs                | Date              | Details           | Rs     |
| Feb 28 | Balance c/d       | 15 000            | Feb 01            | Cash              | 15 000 |
|        |                   | 15 000            |                   |                   | 15 000 |
|        |                   |                   | Mar 01            | Balance b/d       | 15 000 |

| Dr     | Cash Account 1   | Cash Account 1   | Cash Account 1   | Cash Account 1   | Cr     |
|--------|------------------|------------------|------------------|------------------|--------|
| Date   | Details          | Rs               | Date             | Details          | Rs     |
| Feb 01 | Capital          | 15 000           | Feb 01           | Purchases        | 9 500  |
| Feb 12 | Sales            | 2 600            | Feb 17           | Sales            | 2 000  |
|        |                  |                  | Feb 17           | Drawings         | 1 000  |
|        |                  |                  | Feb 28           | Balance c/d      | 5 100  |
|        |                  | 17 600           |                  |                  | 17 600 |
| Feb 28 | Balance b/d      | 5 100            |                  |                  |        |

3

| Dr     | Purchase Account   | Purchase Account   | Purchase Account   | Purchase Account   | Cr    |
|--------|--------------------|--------------------|--------------------|--------------------|-------|
| Date   | Details            | Rs                 | Date               | Details            | Rs    |
| Feb 05 | Cash               | 9 500              | Feb 28             | Balance c/d        | 9 500 |
|        |                    | 9 500              |                    |                    | 9 500 |
| Mar 01 | Balance b/d        | 9 500              |                    |                    |       |

<!-- image -->

| Dr     | Rent Account 5   | Rent Account 5   | Rent Account 5   | Rent Account 5   | Cr    |
|--------|------------------|------------------|------------------|------------------|-------|
| Date   | Details          | Rs               | Date             | Details          | Rs    |
| Feb 17 | Cash             | 2 000            | Feb 28           | Balance c/d      | 2 000 |
|        |                  | 2 000            |                  |                  | 2 000 |
| Mar 01 | Balance b/d      | 2 000            |                  |                  |       |

<!-- image -->

<!-- image -->

| Dr     | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr    |
|--------|-----------------|-----------------|-----------------|-----------------|-------|
| Date   | Details         | Rs              | Date            | Details         | Rs    |
| Feb 28 | Balance c/d     | 2 600           | Feb 12          | Cash            | 2 600 |
|        |                 | 2 600           |                 |                 | 2 600 |
|        |                 |                 | Mar 01          | Balance b/d     | 2 600 |

6

| Dr     | Drawings    | Drawings   | Account   | Account     | Cr    |
|--------|-------------|------------|-----------|-------------|-------|
| Date   | Details     | Rs         | Date      | Details     | Rs    |
| Feb 28 | Cash        | 1 000      | Feb 28    | Balance c/d | 1 000 |
|        |             | 1 000      |           |             | 1 000 |
| Mar 01 | Balance b/d | 1 000      |           |             |       |

<!-- image -->

## Activity 1

A list of ledger accounts is given in the following table. State whether each of the account has a debit or a credit balance. Write your answer in the second column. The first item has been done for you as an example.

| Account           | Debit or Credit   |
|-------------------|-------------------|
| Capital           | Credit            |
| Cash              |                   |
| Bank              |                   |
| Purchases         |                   |
| Sales             |                   |
| John (supplier)   |                   |
| Rajen (Customer)  |                   |
| Advertising       |                   |
| Interest received |                   |
| Rent and rates    |                   |
| Drawings          |                   |

## Worked example

## The following balances are available from the ledger of Surya, an entrepreneur who buys and sells potted plants, as at 30 June 20X9.

Surya's trial balance is prepared as follows:

| Account                | Balance (Rs)   |
|------------------------|----------------|
| Cash                   | 2 750          |
| Capital                | 20 000         |
| Vehicles               | 15 000         |
| Purchases              | 9 300          |
| Rent                   | 5 100          |
| Ravi (Trade payable)   | 7 800          |
| Sales                  | 10 450         |
| Raj (Trade receivable) | 1 500          |
| Utilities              | 750            |
| Wages                  | 2 300          |
| Interest received      | 250            |
| Drawings               | 1 800          |

## Surya Enterprise

## Trial Balance as at  30 June 20X9

| Account                | Debit (Rs)   | Credit (Rs)   |
|------------------------|--------------|---------------|
| Cash                   | 2 750        |               |
| Capital                |              | 20 000        |
| Vehicles               | 15 000       |               |
| Purchases              | 9 300        |               |
| Rent                   | 5 100        |               |
| Ravi (Trade payable)   |              | 7 800         |
| Sales                  |              | 10 450        |
| Raj (Trade receivable) | 1 500        |               |
| Utilities              | 750          |               |
| Wages                  | 2 300        |               |
| Interest received      |              | 250           |
| Drawings               | 1 800        |               |
|                        | 38 500       | 38 500        |

<!-- image -->

From the following list of balances, prepare the trial balance of Jerry's enterprise, dealing in craft products, as at 31 August 20X9.

## Jerry Enterprise

## Trial Balance as at 31 August 20X9

| Account             | Balance (Rs)   |
|---------------------|----------------|
| Bank overdraft      | 1 600          |
| Capital             | 25 000         |
| Sales               | 38 700         |
| Purchases           | 32 400         |
| Jim (Trade payable) | 3 500          |
| Salaries and wages  | 12 800         |
| Rent                | 8 500          |
| Drawings            | 2 100          |
| Vehicle             | 13 000         |

## Activity 3

From the following list of balances taken from the books of Milka, an entrepreneur dealing in dairy products, prepare the trial balance as at 30 September 20X9.

## Milka Enterprise

Trial Balance as at 30 September 20X9

Account

Bank overdraft

Capital

Furniture and fittings

Sales

Purchases

Jim (Trade receivable)

Sam (Trade payable)

Rent and rates

Salaries

Drawings

Balance (Rs)

800

22 200

16 400

61 000

42 600

1 600

1 100

6 900

8 200

9 400

<!-- image -->

From the following list of balances taken from the books of Eddie, an entrepreneur dealing in cosmetics, prepare the trial balance as at 30 September 20X9.

## Eddie Enterprise Trial Balance as at 30 September 20X9

Account

Capital

Cash

Vehicle

Sales

Purchases

Trade receivables

Trade payables

Wages

Insurance

Motor expenses

Drawings

Balance (Rs)

40 000

11 700

27 000

82 200

51 600

4 300

1 900

6 500

1 700

8 900

12 400

<!-- image -->

## Turn and Talk Activity

Both the debit and the credit sides of the trial balance should always be equal to each other. Do you agree?

<!-- image -->

## Question 1

## Multiple Choice Questions

Choose the correct answer for each of the questions below and write it in the space provided.

1. A trial balance is

- A a list of ledger accounts having debit balances

- B a list of ledger accounts having credit balances

- C a list of ledger accounts and their respective balances

D a list of ledger accounts having no balances

Answer \_\_\_\_\_\_\_\_

2. A trial balance is prepared to

- A verify the accuracy of the double entry recording in the ledger

B calculate the total of assets and liabilities

C count the number of ledger accounts

D balance the ledger accounts

Answer \_\_\_\_\_\_\_\_

3. Where are debit balances entered in the trial balance?

A in the debit column

B in the credit column

C outside the trial balance

D not entered at all

Answer \_\_\_\_\_\_\_\_

3. Where are credit balances entered in the trial balance?

A in the debit column

B in the credit column

C outside the trial balance

D not entered at all

Answer \_\_\_\_\_\_\_\_

5. If ledger accounts are correctly prepared using the double entry system, what should be the result of the trial balance?

- A total of debit balances should exceed the total of credit balances

B total of debit balances should be less than the total of credit balances

- C total of debit balances should be equal to the total of credit balances

D trial balance should not agree

Answer \_\_\_\_\_\_\_\_

## Question 2

## Fill in the blanks with the words given below.

debit

agree

accounts

bank

credit

- (a)

- The trial balance is a list of ledger \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and their respective balances at a given date.

- (b) At the end, the trial balance should \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (c) Balances of assets are entered in the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ column of the trial balance.

- (d)

- Balances of income are entered in the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ column of the trial balance.

- (e) The \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ account may have either a debit balance or a credit balance.

## Question 3

From the following ledger accounts of Sammy is an entrepreneur buying and selling garden furniture made from recycled plastic, extract a trial balance as at 31 July 20X9.

| Dr      | Cash Account   | Cash Account   | Cash Account   | Cash Account   | Cr      |
|---------|----------------|----------------|----------------|----------------|---------|
| Date    | Details        | Rs             | Date           | Details        | Rs      |
| July 01 | Capital        | 100 000        | July 02        | Furniture      | 32 000  |
| July 17 | Chan           | 14 000         | July12         | Purchases      | 41 000  |
|         |                |                | July 31        | Balance c/d    | 41 000  |
|         |                | 114 000        |                |                | 114 000 |
| Aug 01  | Balance b/d    | 41 000         |                |                |         |

| Dr      | Capital Account   | Capital Account   | Capital Account   | Capital Account   | Cr      |
|---------|-------------------|-------------------|-------------------|-------------------|---------|
| Date    | Details           | Rs                | Date              | Details           | Rs      |
| July 31 | Balance c/d       | 100 000           | July 01           | Cash              | 100 000 |
|         |                   | 100 000           |                   |                   | 100 000 |
|         |                   |                   | Aug 01            | Balance b/d       | 100 000 |

| Dr      | Furniture Account   | Furniture Account   | Furniture Account   | Furniture Account   | Cr     |
|---------|---------------------|---------------------|---------------------|---------------------|--------|
| Date    | Details             | Rs                  | Date                | Details             | Rs     |
| July 02 | Cash                | 32 000              | July 31             | Balance c/d         | 32 000 |
|         |                     | 32 000              |                     |                     | 32 000 |
| Aug 01  | Balance b/d         | 32 000              |                     |                     |        |

| Dr (In)   | Purchases Account   | Purchases Account   | Purchases Account   | Purchases Account   | Cr (Out)   |
|-----------|---------------------|---------------------|---------------------|---------------------|------------|
| Date      | Details             | Rs                  | Date                | Details             | Rs         |
| July 12   | Cash                | 41 000              | July 31             | Balance c/d         | 41 000     |
|           |                     | 41 000              |                     |                     | 41 000     |
| Aug 01    | Balance b/d         | 41 000              |                     |                     |            |

| Dr (In)   | Sales Account   | Sales Account   | Sales Account   | Sales Account   | Cr (Out)   |
|-----------|-----------------|-----------------|-----------------|-----------------|------------|
| Date      | Details         | Rs              | Date            | Details         | Rs         |
| July 18   | Balance c/d     | 28 000          | July 18         | Chan            | 28 000     |
|           |                 | 28 000          |                 |                 | 28 000     |
|           |                 |                 | Aug 01          | Balance b/d     | 28 000     |

| Dr (In)   | Chan Account   | Chan Account   | Chan Account   | Chan Account   | Cr (Out)   |
|-----------|----------------|----------------|----------------|----------------|------------|
| Date      | Details        | Rs             | Date           | Details        | Rs         |
| July 18   | Sales          | 28 000         | July 28        | Cash           | 14 000     |
|           |                |                | July 31        | Balance c/d    | 14 000     |
|           |                | 28 000         |                |                | 28 000     |
| Aug 01    | Balance b/d    | 14 000         |                |                |            |

Sammy Furniture Trial Balance as at 31 July  20X9

## Question 4

Avi, an entrepreneur, prepared the following trial balance as at 30 September 20X9 for his paper recycling business. The trial balance did not agree. You are required to rewrite the trial balance correctly.

Avi

## Trial Balance as at  30 September 20X9

Avi

| Title of Account   | Debit (Rs)   | Credit (Rs)   |
|--------------------|--------------|---------------|
| Cash               | 800          |               |
| Capital            | 10 000       |               |
| Purchases          | 5 800        |               |
| Sales              |              | 8 000         |
| Carlos (Customer)  |              | 900           |
| Salaries and wages | 4 500        |               |
| Drawings           |              | 6 000         |
|                    | 21 100       | 14 900        |

## Trial Balance as at  30 September 20X9

## Question 5

Rico, an entrepreneur, prepared the following trial balance as at 30 November 20X9 for his organic fertilisers business. The trial balance did not agree. You are required to rewrite the trial balance correctly.

Rico Trial Balance as at  30 November 20X9

Rico

| Title of Account   | Debit Rs   | Credit Rs   |
|--------------------|------------|-------------|
| Bank overdraft     | 1 200      |             |
| Capital            |            | 75 000      |
| Equipment          |            | 90 000      |
| Purchases          |            | 54 600      |
| Cleanne (Supplier) |            | 12 900      |
| Sales              | 76 400     |             |
| Rent               | 11 200     |             |
| Drawings           |            | 9 700       |
|                    | 88 800     | 242 400     |

## Trial Balance as at  30 November 20X9

In this image we can see a person's hand is typing on a table. On the table we can see a calculator.

<!-- image -->

Income Statement

Unit 13 Income Statement

## Learning Objectives:

## On completing this unit, you will be able to:

- outline the different parts of an income statement
- distinguish items of trading account and profit and loss account
- draw the format of an income statement
- prepare an income statement

In this unit, you will learn about the meaning of an income statement and its different parts. You will then have the opportunity to practise recording in the income statement to find whether the enterprise has made profits or incurred losses.

## 13.1 The Income Statement

At  the  end  of  every  year,  entrepreneurs  would  be  interested  to know whether their business has made profits. For this purpose, the  bookkeeper  prepares  an  income  statement.  The income statement is a classification of income and expenses from which profits or losses are calculated at the end of the accounting year expenses.

The time line below shows an accounting year usually consisting of 12 months for which an income statement is prepared.

An income  statement is  a classification  of  income  and expenses  from  which  profits or losses are calculated at the end of the accounting year.

Note: An accounting year is any period of 12 months for which records are kept and profit is calculated.

## Accounting Year: A period of 12 months

Figure 1: Accounting year

The image is a line graph that shows the changes in the number of people in different years. The graph has a yellow background and a white horizontal axis labeled "1 October 2018" and "Dec 2018." The vertical axis is labeled "Jan 2019" and "Aug 2019." The x-axis is labeled "Jan 2019" and "Aug 2019."

The graph has a series of horizontal lines, each representing a different year. The lines are colored orange and white, and they are connected to each other. The lines are labeled with the years "1 October 2018," "Dec 2018," "Feb 2019," and "Aug 2019."

The graph shows a trend of increasing the number of people in each year. The number of people in the year 1 October 2018

<!-- image -->

## 13.2 Format of income statement

The income statement is divided into two parts namely the trading account and the profit and loss account.

The image depicts two main categories of financial data: "Income Statement" and "Trading account."

### Income Statement:
- **Income Statement**: This is the primary focus of the image. It is represented by a pink box with a white line. The line indicates that the income statement is related to the "Trading account."
- **Trading account**: This is the secondary focus of the image. It is represented by a purple box with a white line. The line indicates that the trading account is related to the income statement.

### Analysis:
- **Income Statement**:
  - The income statement is connected to the "Trading account" by a pink box. This indicates that the income statement is related to the "Trading account."
  - The line "Profit and loss account" is also present, indicating that the income statement is related to the profit and loss account.

- **Trading Account**:
  - The trading

<!-- image -->

## 13.2.1 Trading Account

The trading account records  items  which  deal  with  the  trading activities of an enterprise. It is prepared to find out whether the enterprise is making a gross profit or a gross loss.

The trading account records  items  which  deal with  the  trading  activities of an enterprise.

In preparing this part of the income statement, you will use the following important terms:

Figure 3: Items in trading account

In this image, we can see a circle with some text and a line. There are some arrows in the circle. We can see some text and numbers.

<!-- image -->

## I Gross Profit/Loss

Gross profit is the difference between revenue and costs of sales.

## Gross Profit/Loss = Revenue  -  Cost of sales

<!-- image -->

Note: If revenue is greater than cost of sales, gross profit is obtained. If cost of sales is greater than  revenue,  gross  loss  is obtained.

## Worked example 1

The following information is extracted from the books of Jemma, an entrepreneur. An income statement (trading account section) is prepared for the year ended 30 September 20X9.

Revenue

Rs 10 000

Cost of sales

Rs   7 500

Income Statement (trading account section) for the year ending 30 September 20X9

|                      | Rs      |
|----------------------|---------|
| Revenue              | 10 000  |
| Less Cost of sales * | (7 500) |
| Gross Profit         | 2 500   |

Cost  of  sales  Rs  7  500  is  deducted from revenue Rs 10 000 to obtain a gross profit of Rs 2 500.

- *Figures within brackets denote that they must be deducted from the above amount.

<!-- image -->

The following information is extracted from the books of Jemila, an entrepreneur making eco-friendly bags. Prepare the income statement (trading account section) for the year ended 28 February 20X0:

Revenue

Rs 143 000

Cost of sales

Rs 101 000

Jemila Income Statement for the year ending 28 February 20X0

|                    | Rs   |
|--------------------|------|
| Revenue            |      |
| Less Cost of sales |      |

## II Cost of sales

Cost of sales refers to the amount spent to obtain the goods that have been sold during the accounting year.

Cost of sales is calculated as follows:

<!-- image -->

Cost of sales  =  Opening inventory    +    Purchases    -    Closing inventory for resale

Figure 4: Cost of sales

## III Inventory

Bookkeepers usually consider inventory on two specific dates, namely, at the beginning and the end of the accounting year.

Opening inventory is  the amount of goods that enterprises usually hold at the start of the accounting year. It is added in the calculation of cost of sales.

<!-- image -->

Closing inventory is  the  amount  of  goods  that  enterprises  usually  hold  at  the  end  of  the accounting year. It is deducted from the calculation of cost of sales.

<!-- image -->

## Worked example 2

Below is a calculation of cost of sales involving inventory. Carla had the following information:

Rs

Purchases

4 000

Opening inventory

1 000

Closing inventory

2 000

Carla's cost of sales would be:

| Cost of sales:         | Rs      |
|------------------------|---------|
| Opening inventory      | 1 000   |
| Add Purchases          | 4 000   |
|                        | 5 000   |
| Less Closing inventory | (2 000) |
|                        | 3 000   |

Below is the format of the income statement (trading account section) , including inventories:

## Income Statement for the year ending 31 January 20X1

|                        | Rs      | Rs      |
|------------------------|---------|---------|
| Revenue                |         | 9 500   |
| Less Cost of sales:    |         |         |
| Opening inventory      | 1 000   |         |
| Add Purchases          | 4 000   |         |
|                        | 5 000   |         |
| Less Closing inventory | (2 000) | (3 000) |
| Gross profit           |         | 6 500   |

## Activity 2

Suzy Chu

## Income Statement for the year ending 30 April 20X2

|                                  | Rs   | Rs               | Rs                      |
|----------------------------------|------|------------------|-------------------------|
| Revenue                          |      |                  | 10 000                  |
| Less Cost of sales:              |      |                  |                         |
| Opening inventory                | (i)  | ................ |                         |
| Add Purchases                    |      | 7 200            |                         |
| Less Closing inventory           |      | (6 000)          | (ii) (..............)   |
| Gross........................... |      |                  | (iii) ................. |

From the information provided, find the missing figures the of income statement of Suzy Chu for the year ended 30 April 20X2.

|                   | Rs     |
|-------------------|--------|
| Revenue           | 10 000 |
| Purchases         | 7 200  |
| Opening inventory | 2 000  |
| Closing inventory | 6 000  |

<!-- image -->

From  the information provided, prepare  the  income  statement  of Rose, an entrepreneur selling solar panels, for the year ended 31 May 20X3:

|                   | Rs     |
|-------------------|--------|
| Revenue           | 56 200 |
| Purchases         | 44 600 |
| Opening inventory | 5 600  |
| Closing inventory | 5 800  |

Rose Income Statement for the year ending 31 May 20X3

|                     | Rs   | Rs   |
|---------------------|------|------|
| Less Cost of sales: |      |      |

## 13.2.2  The Profit and Loss Account

The profit and loss account part of the income statement calculates the profit for the year or the loss for the year that an enterprise makes. It takes into account income and expenses of the business.

Profit and loss account part of income statement calculates profit for the year.

Profit or loss for the year is calculated as:

<!-- image -->

Profit/loss   =  [  Gross profit/Gross loss     +     Other Income    ]   -     Less Expenses

Figure 6: Profit/loss of the year

## i. Other income and expenses

Other income and expenses are explained below.

## Other Income

## Expenses

Other  than  sales,  there  are items which are income into the business.

Items as  'other income': interest received commission received

Expenses are  payments made by a business for the day to day running of the business.

## Items as expenses:

Rent, salaries &amp; wages, repairs &amp; maintenance, stationery, electricity, water, telephone, motor vehicle expenses, fuel and insurance.

Other income is added to Gross profit/loss

Expenses are deducted from gross profit

Figure 7: Incomes and expenses

A simple format of the income statement (profit and loss section) is as follows:

Claudio

## Income Statement for the year ending 31 January 20X4

|                       | Rs     | Rs       |
|-----------------------|--------|----------|
| Gross profit          |        | 60 000   |
| Add Other income:     |        |          |
| Commission received   | 1 200  |          |
| Interest received     | 300    | 1 500    |
|                       |        | 61 500   |
| Less Expenses:        |        |          |
| Rent and insurance    | 11 000 |          |
| Salaries              | 16 000 |          |
| Fuel                  | 7 600  |          |
| Stationery            | 1 400  |          |
| Electricity and water | 4 100  | (40 100) |
| Profit for the year   |        | 21 400   |

## Activity 4

From the information provided, prepare the income statement (profit and loss section) of Jean, an entrepreneur, for the year ended 31 May 20X5:

## Jean

|                   | Rs     |
|-------------------|--------|
| Gross Profit      | 19 600 |
| Commission        |        |
| received          | 1 200  |
| Interest received | 300    |
| Wages             | 3 500  |
| Rent              | 4 000  |
| Insurance         | 1 600  |
| Motor expenses    | 2 100  |

## Income Statement for the year ending 31 May 20X5

|                                         | Rs   | Rs   |
|-----------------------------------------|------|------|
| Gross Profit                            |      |      |
| Add Other income                        |      |      |
| Less Expenses                           |      |      |
| .......................... for the year |      |      |

## Activity 5

From the information provided, prepare the income statement (profit and loss section) for Pierre, an entrepreneur, for the year ended 30 June 20X6:

## Pierre

|                     | Rs     |
|---------------------|--------|
| Gross Profit        | 21 700 |
| Interest received   | 100    |
| Commission received | 900    |
| Salaries & wages    | 6 000  |
| Rent                | 8 500  |
| Insurance           | 2 400  |
| Fuel                | 2 100  |
| Stationery          | 900    |

## Income Statement for the year ending 30 June 20X6

|                                         | Rs   | Rs   |
|-----------------------------------------|------|------|
| Gross Profit                            |      |      |
| Add Other income                        |      |      |
| Less Expenses                           |      |      |
| .......................... for the year |      |      |

## 13.3 Preparing the Income Statement

Below is the format of a complete income statement.

Observe the two different parts: Trading Account and Profit and Loss Account .

Hema

## Income Statement for the year ended 31 January 20X9

|                                | Rs      | Rs       |
|--------------------------------|---------|----------|
| Revenue                        |         | 42 200   |
| Less Cost of sales             |         |          |
| Opening inventory              | 5 690   |          |
| Add Purchases                  | 22 640  |          |
|                                | 28 330  |          |
| Less Closing inventory         | (4 990) | (23 340) |
| Gross Profit                   |         | 18 860   |
| Add Other Income               |         |          |
| Interest received              |         | 140      |
|                                |         | 19 000   |
| Less Expenses                  |         |          |
| Rent                           | 3 000   |          |
| Salaries & wages               | 5 500   |          |
| Stationery                     | 200     |          |
| Telephone, water & electricity | 300     |          |
| Repairs & maintenance          | 500     |          |
| Motor vehicles expenses        | 1 000   | (10 500) |
| Profit for the year            |         | 8 500    |

## Trading Account

## Profit and Loss Account

Figure 1: Income statement

The above income statement shows that Hema has earned Rs 8 500 as net profit for the year.

## Worked Example 3

Marie's trial balance of, a trader, as at 30 June 20X9 is provided below.

Marie Trial Balance as at 30 June 20X9

|                          | Debit   | Credit   |
|--------------------------|---------|----------|
|                          | Rs      | Rs       |
| Capital                  |         | 38 000   |
| Equipment                | 25 000  |          |
| Trade receivables        | 28 000  |          |
| Trade payables           |         | 2 700    |
| Cash in hand             | 2 300   |          |
| Inventory at 1 July 20X8 | 2 600   |          |
| Revenue                  |         | 68 900   |
| Purchases                | 31 800  |          |
| Commission received      |         | 3 600    |
| Rent                     | 9 300   |          |
| Salaries & wages         | 14 200  |          |
|                          | 113 200 | 113 200  |

<!-- image -->

Appropriate items have been selected from the above trial balance and the income statement of Marie has been prepared for the year ended 30 June 20X9.

Marie

## Income Statement for the year ending 30 June 20X9

|                        | Rs      | Rs       |
|------------------------|---------|----------|
| Revenue                |         | 68 900   |
| Less Cost of sales     |         |          |
| Opening inventory      | 2 600   |          |
| Add Purchases          | 31 800  |          |
|                        | 34 400  |          |
| Less Closing inventory | (3 200) | (31 200) |
| Gross Profit           |         | 37 700   |
| Add Other income       |         |          |
| Commission received    |         | 3 600    |
|                        |         | 41 300   |
| Less Expenses          |         |          |
| Rent                   | 9 300   |          |
| Salaries & wages       | 14 200  | (23 500) |
| Profit for the year    |         | 17 800   |

Note: Assets (equipment, trade receivables and cash in hand), liabilities (trade payables), capital and drawings are not entered in the income statement.

<!-- image -->

Sam is in the business of buying and selling shoes for school kids. The trial balance as at 30 April 20X9 is provided as follows.

Sam Trial Balance as at 30 April 20X9

|                          | Debit   | Credit   |
|--------------------------|---------|----------|
|                          | Rs      | Rs       |
| Capital                  |         | 30 000   |
| Vehicles                 | 16 000  |          |
| Trade receivables        | 14 500  |          |
| Trade payables           |         | 2 100    |
| Cash in hand             | 1 900   |          |
| Inventory at 01 May 20X8 | 3 100   |          |
| Revenue                  |         | 37 800   |
| Purchases                | 22 100  |          |
| Interest received        |         | 200      |
| Salaries                 | 9 000   |          |
| Fuel                     | 3 500   |          |
|                          | 70 100  | 70 100   |

Prepare the Sam's income statement for the year ended 30 April 20X9.

Sam

## Income Statement for the year ending 30 April 20X9

|                                         | Rs   | Rs     |
|-----------------------------------------|------|--------|
| Revenue                                 |      | 37 800 |
| Less Cost of sales                      |      |        |
| Gross Profit                            |      |        |
| Add Other income                        |      |        |
| Interest received                       |      | 200    |
| Less Expenses                           |      |        |
| .......................... for the year |      |        |

<!-- image -->

<!-- image -->

## Question 1

## Multiple Choice Questions

Choose the correct answer for each of the questions below and write it in the space provided.

1. An income statement is

- A a statement that shows financial position

- B a classification of receipts and payments to calculate profits or losses

C a list of ledger accounts and their respective balances

D a statement of liabilities at a given date

Answer \_\_\_\_\_\_\_\_

2. Gross profit is earned when

A assets exceed liabilities

B revenue exceed total expenses

C revenue exceed cost of sales

D capital exceed assets

Answer \_\_\_\_\_\_\_\_

3. Which of the following occurs when gross profit falls less than total expenses?

- A loss for the year

B profit for the year

C gross loss

D income statement balances

Answer \_\_\_\_\_\_\_\_

4. In the calculation of gross profit, closing inventory is

- A added to revenue

B entered as an expense

C deducted in the calculation of cost of sales

D added to profit for the year

Answer \_\_\_\_\_\_\_\_

## Question 2

Fill in the blanks using the words given below.

income statement

revenue

gross profit        expenses

- (a) Gross profit is the difference between \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and cost of sales.

- (b)

Expenses are deducted from \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ to obtain profit/loss for the year.

- (c) Rent, salaries and insurance are \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ to the business.

- (d)

The \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is prepared to calculate the profit or loss for the year.

## Question 3

Mary Jane is an entrepreneur. She buys and sells compost and other organic gardening materials. She provided the following information for the year ended 31 August 20X9:

Mary Jane Trial Balance as at 31 August 20X9

|                           | Debit Rs   | Credit Rs   |
|---------------------------|------------|-------------|
| Capital                   |            | 100 000     |
| Motor vehicles            | 35 000     |             |
| Trade receivables         | 24 600     |             |
| Trade payables            |            | 3 100       |
| Cash in hand              | 11 500     |             |
| Inventory at 01 July 20X8 | 15 400     |             |
| Revenue                   |            | 119 000     |
| Purchases                 | 89 200     |             |
| Commission received       |            | 2 800       |
| Rent & insurance          | 4 300      |             |
| Salaries & wages          | 26 600     |             |
| Motor expenses            | 2 300      |             |
| Drawings                  | 16 000     |             |
|                           | 224 900    | 224 900     |

<!-- image -->

Prepare the income statement of Mary Jane for the year ended 31 August 20X9.

Mary Jane

## Income Statement for the year ending 31 August 20X9

|                                         | Rs   | Rs   |
|-----------------------------------------|------|------|
| Revenue                                 |      |      |
| Less Cost of sales                      |      |      |
| Gross Profit                            |      |      |
| Add Other income                        |      |      |
| Comission received                      |      |      |
| Less Expenses                           |      |      |
| .......................... for the year |      |      |

## Question4

Ashok holds a canteen in a secondary school. His trial balance as at 30 June 20X8 is provided as follows. Ashok

## Trial Balance as at 30 June 20X8

|                           | Debit   | Credit   |
|---------------------------|---------|----------|
|                           | Rs      | Rs       |
| Capital                   |         | 10 000   |
| Furniture and fittings    | 11 000  |          |
| Trade receivables         | 3200    |          |
| Trade payables            |         | 1 900    |
| Inventory at 01 July 20X7 | 1 900   |          |
| Revenue                   |         | 63 800   |
| Purchases                 | 42 000  |          |
| Interest received         |         | 100      |
| Electricity and water     | 2 600   |          |
| Rent                      | 7 800   |          |
| Advertising               | 5 000   |          |
| Drawings                  | 2 300   |          |
|                           | 75 800  | 75 800   |

Prepare the income statement of Ashok for the year ended 30 June 20X8.

## Ashok

## Income Statement for the year ending 30 June 20X8

|                                         | Rs   | Rs   |
|-----------------------------------------|------|------|
| Revenue                                 |      |      |
| Less Cost of sales                      |      |      |
| Gross Profit                            |      |      |
| Add Other income                        |      |      |
| Interest received                       |      |      |
| Less Expenses                           |      |      |
| .......................... for the year |      |      |

Note: Inventory at 30 June 20X8 was valued at Rs 1 300.

<!-- image -->

Income statement is a classification of income and expenses from which profits or  losses  are  calculated  at the  end  of  the  accounting year.

Trading  account records items  which  deal  with  the trading activities of an enterprise.

Profit and  loss  account part  of  income  statement calculates profit for the year.

In this image we can see a table with a laptop and a cup of coffee on it.

<!-- image -->

Statement of Financial Position

Unit 14 Statement of Financial Position

## Learning Objectives:

## On completing this unit, you will be able to:

- classify items as assets and liabilities
- prepare simple statement of financial position

In this unit, you will discover the statement of financial position in which enterprises record their assets, liabilities and capital. Then, you will use a list of assets and liabilities to prepare the statement of financial position.

## 14.1 Statement of Financial Position

The Statement of financial position presents all the assets, liabilities and owner's capital in an enterprise at a particular date.

The statement of financial position presents  all  the  assets,  liabilities  and owner's  capital  in  an  enterprise  at  a particular date.

Below is a simple layout of a statement of financial position.

Anil enterprise Statement of Financial Position as at 31 December 20X0

|             | Rs   | Rs      |
|-------------|------|---------|
| Assets      |      | 200 000 |
|             |      | 200 000 |
| Capital     |      | 120 000 |
| Liabilities |      | 80 000  |
|             |      | 200 000 |

Note: Assets = Capital + Liabilities

## 14.2 Assets and Liabilities

## I    Assets

Assets are items owned by an enterprise. These items are important because they allow enterprises to carry out their activities effectively. An asset always has a debit balance.

Assets are items owned by an enterprise.

Assets are classified as follows.

The image depicts two sets of data: "Non-Current Assets" and "Current Assets". The "Non-Current Assets" set is represented by a yellow color box, and the "Current Assets" set is represented by a green color box.

- **Non-Current Assets:**
  - The "Non-Current Assets" set contains the values "1000000" and "1000000".
  - The "Current Assets" set contains the values "1000000" and "1000000".

- **Current Assets:**
  - The "Current Assets" set contains the values "1000000" and "1000000".
  - The "Non-Current Assets" set contains the values "1000000" and "1000000".

### Analysis and Description

- **

<!-- image -->

## Non-current assets and current assets are explained below.

<!-- image -->

| Assets   | Non-current assets Non-current assets are items owned and used by the enterprise for more than a year.   | Examples: • Land • Buildings • Machinery • Furniture • Motor vehicles • Equipment   |
|----------|----------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| Assets   | Current assets Current assets are items held by the business for the day-to-day activities.              | Examples: • Inventory • Trade receivables • Cash at bank • Cash in hand             |

<!-- image -->

## For each of the following item, tick (      ) to indicate which of the following is a noncurrent or current asset for a school canteen.

|    |                    | Non-Current Assets   | Current Assets   |
|----|--------------------|----------------------|------------------|
| a  | Delivery van       | √                    |                  |
| b  | Furniture          |                      |                  |
| c  | Inventory          |                      |                  |
| d  | Cash in the drawer |                      |                  |
| e  | Cash at Bank       |                      |                  |
| f  | Trade receivables  |                      |                  |
| g  | Premises           |                      |                  |

Assets are presented in the Statement of Financial Position, as follows.

## Kari Mélanz enterprise Statement of Financial Position

## Kari Mélanz enterprise

|                       | Rs     |
|-----------------------|--------|
| Furniture             | 35 000 |
| Motor vehicles        | 80 000 |
| Inventory 31 Dec 20X0 | 15 000 |
| Trade receivables     | 35 000 |
| Cash at bank          | 30 000 |
| Cash in hand          | 5 000  |

## Assets are presented as

Total  assets = Non-current assets + Current assets

as at 31 December 20X0 (Extract)

| Non-Current Assets       | Rs     | Rs      |
|--------------------------|--------|---------|
| Furniture                |        | 35 000  |
| Motor Vehicles           |        | 80 000  |
| Total Non-Current Assets |        | 115 000 |
| Current Assets           |        |         |
| Inventory                | 15 000 |         |
| Trade receivables        | 35 000 |         |
| Cash at bank             | 30 000 |         |
| Cash in hand             | 5 000  |         |
| Total Current Assets     |        | 85 000  |
| Total Assets             |        | 200 000 |

<!-- image -->

Sophie, an entrepreneur, deals in hydroponic vegetables.  Present her assets in the statement of financial position as at 31 December 20X0.

## Sophie enterprise (Extract)

|                       | Rs      |
|-----------------------|---------|
| Furniture             | 50 000  |
| Property              | 180 000 |
| Equipment             | 46 000  |
| Inventory 31 Dec 20X0 | 25 000  |
| Trade receivables     | 75 000  |
| Cash at bank          | 23 250  |
| Cash in hand          | 750     |

## Statement of Financial Position as at 31 December 20X0

| Non-Current Assets                                                                               | Rs                                                          | Rs             |
|--------------------------------------------------------------------------------------------------|-------------------------------------------------------------|----------------|
| .....................................                                                            |                                                             | .............. |
| Total Non-Current Assets                                                                         |                                                             | .............. |
| Current Assets ..................................... .....................................       |                                                             |                |
| ..................................... ..................................... Total Current Assets | .............. .............. .............. .............. | .............. |
| Total Assets                                                                                     |                                                             | .............. |

## II   Liabilities

Liabilities are amounts owed by the enterprise to others outside the  business.  These  amounts  consist  of  borrowings  and  credit facilities. A liability always has a credit balance.

A liability is an item that represents what the enterprise owes.

Liabilities are classified as follows.

Table 2: Non-Current Liabilities and Current Liabilities

In this image, we can see a diagram with some text and numbers.

<!-- image -->

Liabilities are presented in the Statement of Financial Position as follows.

| Non-Current Liability   | Rs   | Rs     |
|-------------------------|------|--------|
| Bank loan               |      | 50 000 |
| Current Liability       |      |        |
| Trade payables          |      | 30 000 |

<!-- image -->

## Turn and Talk Activity

Hans, a carpenter, buys timber from a supplier. The supplier has a good relationship with Hans and allows him to buy on credit. The supplier gives, Hans, an invoice that he must pay within 45 days.

Discuss with your friend what does this transaction is represented in the accounts of Hans.

## III   Capital

Capital is  an  amount  of  money  invested  by  an  entrepreneur  to start his enterprise. It is also referred to as owner's equity . These funds are used to purchase assets and finance business activities.

Capital is presented in the Statement of Financial Position, as follows.

## Statement of Financial Position (Extract)

| Capital             | Rs       |
|---------------------|----------|
| Capital at start    | 110 000  |
| Profit for the year | 25 000   |
| Less Drawings       | (15 000) |
| Owner's equity      | 120 000  |

Drawings are cash or goods that  the  owner  takes  from his enterprise for his private use.

The entrepreneur does business to earn profit which belongs to him. It, therefore, increases his capital. On the other hand, a loss decreases capital.

When the entrepreneur takes part of his profit from the business for his personal use, it is known as drawings and it decreases his capital.

<!-- image -->

Present Sophie's capital and liabilities in the statement of financial position as at 31 December 20X0. Sophie enterprise

Statement of Financial Position as at 31 December 20X0

|                        | Rs      |
|------------------------|---------|
| Capital at 01 Jan 20X0 | 200 000 |
| Drawings               | 25 000  |
| Profit for the year    | 55 000  |
| Bank loan              | 40 000  |
| Trade payables         | 30 000  |

| Capital and Liabilities                                                   | Rs   | Rs                            |
|---------------------------------------------------------------------------|------|-------------------------------|
| .....................................                                     |      | ..............                |
| ..................................... Less .............................. |      | .............. .............. |
| Owner's Equity                                                            |      | ..............                |
| Non-Current Liabilities .....................................             |      | ..............                |
| Current Liabilities .....................................                 |      | ..............                |
| Total Capital and Liabilities                                             |      | ..............                |

Capital is an amount  of money invested by an entrepreneur to start his enterprise.

## 14.3 Format of  Statement of Financial Position

The format of a complete statement of financial position is presented below.

## Statement of financial position as at .........................

In this image, we can see a chart. There are some numbers on the chart.

<!-- image -->

|                         | Non-Current Assets                                                | Rs   | Rs   |
|-------------------------|-------------------------------------------------------------------|------|------|
|                         | Furniture MotorVehicles                                           |      |      |
|                         | Total Non-Current Assets Assets                                   |      |      |
| Assets                  | Current                                                           |      |      |
|                         | Total Current Assets                                              |      |      |
|                         | Total Assets                                                      |      |      |
|                         | Capital and Liabilities Capital Profit for the year Less Drawings |      |      |
| Capital and Liabilities | Owner's Equity Non-Current Liabilities                            |      |      |
|                         | Bank Loan                                                         |      |      |
|                         | Current                                                           |      |      |
|                         | Trade payables                                                    |      |      |
|                         | Total Capital and                                                 |      |      |
|                         | Liabilities                                                       |      |      |
|                         | Liabilities                                                       |      |      |

Note the following formulas in the Statement of Financial Position.

In this image, we can see a table with some text and numbers.

<!-- image -->

## 14.4 Preparing a Statement of Financial Position

Anil, a trader's statement of financial position for the year ended 31 December 20X0 has been prepared from the given balances.

|                            | Rs      |    |
|----------------------------|---------|----|
| Trade payables             | 30 000  | L  |
| Furniture                  | 35 000  | A  |
| Motor vehicles             | 80 000  | A  |
| Trade receivables          | 35 000  | A  |
| Inventory 31 December 20X0 | 15 000  | A  |
| Cash at bank               | 30 000  | A  |
| Cash in hand               | 5 000   | A  |
| Profit for the year        | 25 000  | C  |
| Drawings                   | 15 000  | C  |
| Capital                    | 110 000 | C  |
| Bank loan                  | 50 000  | L  |

- A - is recorded as an asset
- L - is recorded as a liability
- C - is recorded as a Owners' equity

## Anil

## Statement of Financial position as at 31 December 20X0

| Non-Current Assets            | Rs                         | Rs            |
|-------------------------------|----------------------------|---------------|
| Furniture                     |                            | 35 000 80 000 |
| MotorVehicles                 |                            | 115 000       |
| Total Non-Current Assets      |                            |               |
| Current Assets                |                            |               |
| Inventory Trade Cash at       | 15 000 35 000 30 000 5 000 |               |
| receivables                   |                            |               |
| bank                          |                            |               |
| Cash in hand                  |                            |               |
| Total Current Assets          |                            | 85 000        |
| Total Assets                  |                            | 200 000       |
| Capital and Liabilities       |                            |               |
| Capital at 01 Jan 20X0        |                            | 110 000       |
| Profit for the year           |                            | 25 000        |
| Less Drawings                 |                            | (15 000)      |
| Owner's Equity                |                            | 120 000       |
| Non-Current Liabilities       |                            |               |
| Bank Loan                     |                            | 50 000        |
| Current Liabilities           |                            |               |
| Trade payables                |                            | 30 000        |
| Total Capital and Liabilities |                            | 200 000       |

The image is a diagram that shows the relationship between two variables, Assets and Capital. The diagram is labeled as Assets and it is connected with a horizontal line. The horizontal line is labeled as Capital.

The diagram shows two main components:
1. **Assets**: There are two main components:
   - **Capital**: This is represented by a blue box.
   - **Capital and Liabilities**: This is represented by a red box.

2. **Relationship between Assets and Capital**:
   - **Capital and Liabilities**: The blue box shows a relationship between assets and capital. It states that assets are connected to capital, and capital is connected to liabilities.

### Analysis:

- **Capital and Liabilities**:
  - **Capital and Liabilities**: This is a relationship between assets and capital. Assets are connected to capital, and capital is connected to liabilities.
  - **Capital and Liabilities**: This is a relationship between assets and capital. Assets are

<!-- image -->

<!-- image -->

Karim, is an entrepreneur selling 'Briyani' . Prepare the statement of financial position for the year ended 31 December 20X0.

|                             | Rs      |
|-----------------------------|---------|
| Equipment                   | 50 000  |
| Premises                    | 250 000 |
| Inventory as at 31 Dec 20X0 | 58 000  |
| Trade receivable            | 22 200  |
| Cash at bank                | 19 000  |
| Cash in hand                | 800     |
| Capital at 01 Jan 20X0      | 300 000 |
| Drawings                    | 95 000  |
| Profit for the year         | 115 000 |
| Bank loan                   | 30 000  |
| Trade payables              | 50 000  |

## Karim enterprise

## Statement of Financial Position for the year ended 31 December 20X0

Non-Current Assets

Rs

Rs

.....................................

.....................................

.....................................

.....................................

.....................................

.....................................

Total Non-Current Assets

.....................................

Current Assets

……………………..

.....................................

…………………….

.....................................

……………………..

.....................................

Total Current Assets

.....................................

Total Assets

.....................................

Capital and Liabilities

……………………..

.....................................

……………………..

.....................................

Less …………………..

(.....................................)

……………………..

.....................................

Non-Current Liabilities

…………………….

.....................................

Current Liabilities

……………………

……………………

.....................................

.....................................

Total Liabilities

.....................................

## Activity 5

Sandra, an entrepreneur, prepares and sells pickles. Prepare her statement of financial position from the given balances for the year ended 31 December 20X0.

|                            | Rs      |
|----------------------------|---------|
| Profit for the year        | 38 000  |
| Trade receivables          | 47 500  |
| Trade payables             | 60 500  |
| Equipment                  | 180 000 |
| Land and buildings         | 230 000 |
| Inventory 31 December 20X0 | 38 000  |
| Cash in hand               | 4 500   |
| Drawings                   | 18 500  |
| Capital at 01 Jan 20X0     | 360 000 |
| Bank loan                  | 60 000  |

## Sandra Pickles

## Statement of Financial Position as at 31 December 20X0

| Non-Current Assets ..................................... ..................................... ..................................... Total Non-Current Assets Current Assets …………………….. ……………………. …………………….. Total Current Assets   | Rs ..................................... ..................................... .....................................   | Rs ..................................... ..................................... ..................................... ..................................... .....................................   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Total Assets                                                                                                                                                                                                                        |                                                                                                                        |                                                                                                                                                                                                    |
| Capital and Liabilities …………………….. …………………….. Less………………….. …………………….. Non-Current Liabilities ……………………. Current Liabilities …………………… ……………………                                                                                      |                                                                                                                        | ..................................... ..................................... ..................................... (.....................................) .....................................    |
|                                                                                                                                                                                                                                     |                                                                                                                        | ..................................... ..................................... .....................................                                                                                  |
| Total Liabilities                                                                                                                                                                                                                   |                                                                                                                        | .....................................                                                                                                                                                              |

<!-- image -->

Nina is an entrepreneur, who makes bags. Prepare her statement of financial position for the year ended 31 December 20X0.

|                        | Rs      |
|------------------------|---------|
| Machinery              | 350 000 |
| Fixtures and fittings  | 200 000 |
| Inventory 31 Dec 20X0  | 27 000  |
| Trade receivables      | 32 900  |
| Cash at bank           | 13 100  |
| Capital at 01 Jan 20X0 | 400 000 |
| Drawings               | 20 000  |
| Profit for the year    | 123 000 |
| Bank loan              | 50 000  |
| Trade payables         | 70 000  |

## Nina enterprise

## Statement of Financial Position for the year ended 31 December 20X0

| Non-Current Assets ..................................... ..................................... ..................................... Total Non-Current Assets Current Assets …………………….. ……………………. …………………….. Total Current Assets   | Rs ..................................... ..................................... .....................................   | Rs ..................................... ..................................... ..................................... .....................................                                                                            |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Total Assets                                                                                                                                                                                                                        |                                                                                                                        | .....................................                                                                                                                                                                                                 |
| Capital and Liabilities …………………….. …………………….. Less………………….. …………………….. Non-Current Liabilities ……………………. Current Liabilities …………………… ……………………                                                                                      |                                                                                                                        | ..................................... ..................................... ..................................... (.....................................) ..................................... ..................................... |
|                                                                                                                                                                                                                                     |                                                                                                                        | ..................................... .....................................                                                                                                                                                           |
| Total Liabilities                                                                                                                                                                                                                   |                                                                                                                        | .....................................                                                                                                                                                                                                 |

<!-- image -->

## Question 1

## Multiple Choice Questions

Choose the correct answer for each of the questions below and write it in the space provided.

1. Which of the following is a non-current asset?
2. A    Inventory

B     Furniture

C     Cash at bank

D      Bank loan

Answer \_\_\_\_\_\_\_\_

2. A statement of financial position is prepared to
2. A show trade receivables and trade payables at a given date.
3. B show the ledger balances b/d at a  given date.

C show the profit for the year.

- D show the financial position of the enterprise at a given date.

Answer \_\_\_\_\_\_\_\_

3. Which of the following is a current liability?

A     Motor vehicles             B     Trade payables

C    Cash in hand

D    Capital

Answer \_\_\_\_\_\_\_\_

4. Which of the following formula is correct?
2. A Non-Current Assets - Current Assets = Total Assets
3. B Non-Current Liabilities + Current Liabilities = Total Liabilities

C Current Assets - Current Liabilities = Total Assets

D Capital at start - Profit for the year + Drawings = Owner's equity

Answer \_\_\_\_\_\_\_\_

## Question 2

## Classify the items in the table below.

Motor vehicles

Bank loan

Inventory

Trade receivables

Cash in hand

Furniture

Trade payables

## Question 3

## Fill in the blanks with the appropriate words given below.

|         | drawings non-current asset liabilities debit credit equity current asset                                                                 |
|---------|------------------------------------------------------------------------------------------------------------------------------------------|
| (a)     | An asset always has a ……………balancewhereas a liability always has a …………….balance.                                                        |
| (b)     | Capitalisalsoknownas………………………..                                                                                                          |
| (c)     | 'Motor vehicles' is an example of………………………whileinventoryisan exampleof……………….                                                            |
| (d) (e) | Amounts that an enterprise owes are known as ………………………. …………………arecashorgoodsthattheowner takes from his enterprise for his private use. |

## Question 4

Simon is an entrepreneur selling a variety of seafoods. The following balances were  extracted from the books on 31 December 20X0.

Prepare Simon's statement of financial position as at 31 December 20X0.

|                            | Rs      |
|----------------------------|---------|
| Property                   | 165 000 |
| Furniture                  | 49 000  |
| Capital at 01 Jan 20X0     | 220 000 |
| Drawings                   | 8 200   |
| Net profit for the year    | 14 000  |
| Bank                       | 25 800  |
| Trade payables             | 33 000  |
| Bank loan                  | 35 000  |
| Trade receivables          | 28 000  |
| Inventory 31 December 20X0 | 26 000  |

## Simon enterprise Statement of Financial Position for the year ended 31 December 20X0

Non-Current Assets

Rs

Rs

.....................................

.....................................

.....................................

.....................................

Total Non-Current Assets

.....................................

Current Assets

.....................................

.....................................

……………………..

.....................................

…………………….

.....................................

.....................................

……………………..

Total Current Assets

.....................................

Total Assets

.....................................

Capital and Liabilities

……………………..

.....................................

……………………..

.....................................

Less …………………..

(......................................)

Owner's Equity

.....................................

Non-Current Liabilities

…………………….

.....................................

Current Liabilities

……………………

.....................................

Total Capital and Liabilities

.....................................

<!-- image -->

## KEY TERMS

An asset is an item owned by an enterprise.

Capital is an amount of money invested by an entrepreneur to start his enterprise.

Drawings are cash or goods that the owner draws from his enterprise for his private use.

A liability is an item that represents what the enterprise owes.

The statement of financial position presents all the assets, liabilities and owner's capital in an enterprise at a particular date.

The diagram below summarises the steps in the preparation of the Statement of Financial position.

## Business transactions

## Ledger

## Balancing of accounts

- Cash
- Bank
- Credit

## Trial Balance

- A list of ledger balances
- Total Debits = Total Credits
- Debit/Credit
- Double-entry system

## Income Statement

- Revenue
- Cost of sales
- Gross profit
- Incomes
- Expenses
- Profit for the year
- Balance c/d
- Balance b/d

## Statement of Financial position

- Non-Current Assets
- Current Assets
- Capital
- Non-Current Liabilities
- Current Liabilities

<!-- image -->

<!-- image -->

## Additional Notes