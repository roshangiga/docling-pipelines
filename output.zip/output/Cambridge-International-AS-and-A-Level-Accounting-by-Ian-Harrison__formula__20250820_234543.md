<!-- image -->

In this image we can see a group of people, some of them are standing, some are sitting, some are holding objects, some are looking at the monitors, some are standing, some are holding objects, some are looking at the monitors, some are holding objects, some are looking at the monitors, some are holding objects, some are looking at the monitors, some are holding objects, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking at the monitors, some are looking

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers.

<!-- image -->

In this image, we can see a table with some numbers.

<!-- image -->

<!-- image -->

<!-- image -->

The image is a circular diagram with a central point labeled "The double-entry system." This point is connected to four other points, each representing a different category or category of items. The diagram is circular, with a line connecting each of these points.

### Description of the Diagram:
1. **Central Point**:
   - The central point is labeled "The double-entry system."
   - It is connected to four other points, each representing a different category or category of items.

2. **Cash Book**:
   - The Cash Book is located at the top of the diagram.
   - It is connected to the "Purchases journal" at the bottom.

3. **General Journal**:
   - The General Journal is located at the bottom of the diagram.
   - It is connected to the "Purchases journal" at the top.

4. **Purchases Journal**:
   - The Purchases Journal is located at the top of the diagram

<!-- image -->

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

<!-- image -->

In this image, we can see a diagram. In the diagram, we can see a table, some text, and a few objects.

<!-- image -->

<!-- image -->

In this image, we can see a diagram, there is a text, there is a box, there is a line, there is a box, there is a box, there is a text, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box, there is a box,

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\begin{smallmatrix} & & \quad \quad \quad$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers and some text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers and some text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a woman standing and holding a glass. In the background we can see a glass window and a few people.

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

In this image, we can see a document with some text and numbers.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image I can see a paper with some text and numbers.

<!-- image -->

In this image, we can see a table with some numbers and text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some data.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In the image there is a scale with two pans. On the left side of the image there are two pans. On the right side of the image there is a scale.

<!-- image -->

<!-- image -->

In this image we can see a tree. In the background there is a sky.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a chart. In the chart we can see numbers and text.

<!-- image -->

In this image, we can see a chart. On the chart, we can see some numbers.

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table. In the table, we can see numbers and text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers and some text.

<!-- image -->

<!-- image -->

<!-- image -->

This image is an edited image. In this image there are some objects. In the foreground there are some objects. In the background there are some objects.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$= $6 0 0 0$$

$$<_ObjectiveC_> Goodwill valued = \frac { Total profits for five$$

$$= \frac { \text{$60\,0\,0$$

$$= $2 4 0 0 0$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The image is a diagrammatic representation of a financial statement. It is divided into three main sections: "Employees," "Financial Statement," and "Teachers." Each section is connected to the others, and the diagram visually represents the relationships between these components.

### Employees Section
- **Title**: "Employees"
- **Description**: The employees are listed in the "Employees" section.
- **Details**:
  - The employees are listed in a structured format, with columns for "Name," "Position," "Date of Birth," and "Sex."
  - The columns are labeled "Name," "Position," "Date of Birth," and "Sex."

### Financial Statement Section
- **Title**: "Financial Statement"
- **Description**: The financial statement is presented in a structured format, with columns for "Date of Issue," "Date of Issue," and "Amount."
  - The date of issue is labeled "Date of Issue."
  - The

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a scale. On the scale, we can see the numbers.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers and text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a group of people sitting on the chairs and there are laptops on the chairs.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The image is a diagrammatic representation of a financial statement. The diagram is divided into three main sections: "Employees," "Financial Statement," and "Suppliers." Each section is represented by a different type of entity.

1. **Employees**:
   - The first section is labeled "Employees" and contains a table with the following columns: "Name," "Date," "Amount," and "Date."
   - The second section is labeled "Students" and contains a table with the following columns: "Name," "Date," "Amount," and "Date."
   - The third section is labeled "Financial Statement" and contains a table with the following columns: "Date," "Amount," and "Date."
   - The fourth section is labeled "Suppliers" and contains a table with the following columns: "Name," "Date," "Amount," and "Date."

2. **Financial Statement**:
   - The "Financial Statement" section is labeled "Financial Statement

<!-- image -->

In this image we can see a person holding a paper and a pen. In the background there is a table. On the table there is a mobile phone, a pen, a glass, a glass, a paper, a pen stand, a paper, a pen and a paper.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a table. In the table we can see the numbers.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\frac { 1 6 9 } { 1 4 6 0 } \times 3 6 5 = 4 3 \, d a y s$$

$$\frac { 1 5 4 } { 1 2 4 0 } \times 3 6 5 = 4 6 \, d a y s$$

<!-- image -->

$$\frac { 1 1 5 \times 3 6 5 } { 1 4 5 0 } = 2 9 \, days \, ( 2 8. 9 5 )$$

<!-- image -->

$$\frac { 1 4 5 0 } { 1 5 } = 1 2. 6 1 \text{ times}$$

$$\frac { 1 2 0 } { 1 0 0 } = 1 2. 2 \text{ times}$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph. There are two lines on the graph.

<!-- image -->

In this image, we can see a graph. There is a line on the graph. There is a text on the graph.

<!-- image -->

In this image, we can see a graph. There are two lines on the graph. There is a text at the bottom of the image.

<!-- image -->

<!-- image -->

In this image, we can see a graph. There is a line on the graph. There is a text on the graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\text{Overhead recovery rate} = \frac { $283992 } { $151060 } = $1.88 per $1 of direct labour cost.$$

$$<_Perl_>                                                                                                                                                                                                        
                                                                                                                                                                                                       

                                                                                                                                                                                                        <$1954170                                                                                                                                                                                                        </$502350                                                                                                                                                                                                        >
                                                                                                                                                                                                       <S3.89                                                                                                                                                                                                        +$$

<!-- image -->

$$<_Bash_> Overhead recovery rate = ${355500} = $3.29 per $1 of prime cost$$

$$\text{Overhead recovery rate} = \frac { \text{15500} } { \text{14500} } = \text{$1.07 per unit}$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\text{Break-even} = \frac { \text{Total fixed costs} } { \text{Contribution per unit} } = \frac { \text{$1120$} } { \text{$19$} } = 593 \text{docs (actually 592.105)}$$

<!-- image -->

<!-- image -->

<!-- image -->

$$<_SQL_> Contribution to sales ratio = \frac { \frac { \frac { \frac { \sqrt { 1 0 0 0 } } { \sqrt { 4 0 0 0 0 } } } \times 1 0 0 = 5 2. 5 \% (0. 5 2 5 ) }$$

In this image, we can see a graph. There is a text at the bottom of the image.

<!-- image -->

In this image, we can see a graph. There is a text at the top of the image.

<!-- image -->

In this image, we can see a graph. There is a text at the bottom of the image.

<!-- image -->

<!-- image -->

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph. On the graph, we can see the numbers.

<!-- image -->

In this image, we can see a graph. On the graph, we can see the numbers.

<!-- image -->

In this image, we can see a diagram. There are some lines and text.

<!-- image -->

<!-- image -->

$$\text{Break-even point} = \frac { \text{Total fixed cost} } { \text{Contribution per unit} } = \frac { 52000 } { \text{$15} } = 3 4 6 7 \text{ units}$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\text{Machine shop: } \frac { $18000 } { 4000 } = $4.50 per machine hour$$

<!-- image -->

$$\text{Cost per unit} = \frac { \text{$29$440} } { 1 2 0 0 0 + 800} = \text{$2.30$}$$

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a machine, there are some machines, there are some people sitting on chairs, there are some objects, there are some objects on the floor, there are some objects on the table, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the table, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on the wall, there are some objects on the floor, there are some objects on

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image there is a paper with some text on it.

<!-- image -->

<!-- image -->

In this image, we can see a graph.

<!-- image -->

<!-- image -->

In this image there is a table with some numbers on it.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a table with some numbers and text.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\frac { 1 2 0 + 2 4 0 - 1 6 9 } { 2 6 0 0 } \times 1 0 0 = 7. 3 5 %$$

<!-- image -->

<!-- image -->

<!-- image -->

$$\frac { 3 9 0 0 0 0 } { 1 5 0 0 0 0 } = 2 0. 6 \, cents$$

$$\frac { 2 8 7 0 0 0 0 } { 1 5 0 0 0 0 } = 1 9. 1 \, cents$$

$$\begin{matrix} & \text{Market price per share} \\ \text{Price earnings ratio} = \frac { \text{Market price per share} \\ \text{Earnings per share} \end{matrix}$$

$$\frac { \text{$3.70$} } { 2 0. 6 $ cents} = 8. 2 5$$

$$\frac { $ 1. 5 0 } { 1 9. 1 \, \text{cents} } = 7. 8 5$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image there is a diagram, in the diagram there is a circle, in the circle there is a text, there is a text box, there is a text, there is a text box, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text, there is a text

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$\begin{array} { c c c } \alpha \times \rho \\ 7 2 0 \times \frac { 3 } { 3 } & = \frac { \sin } { \sin } \\ \alpha \times \frac { \sin } { \sin } \\ 7 3 0 \times \frac { 3 } { 3 } & = \frac { \sin } { \sin } \\ \alpha \times \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 } \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \\ \rho \times \frac { 3 } { 3 }. 5 0 = \frac { \sin } { \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \cos } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } ) \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \tan } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin }
 \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \in } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin }\sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin} \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \bin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \\ \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \end{ \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \begin{array} \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin }
\sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \cos} \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin }\cos } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin}
 \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin }\begin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \sin } \$$

<!-- image -->

<!-- image -->

$$\begin{smallmatrix} s q \times s p \\ A q \times s p \end{smallmatrix}$$

$$<_Perl_>                                                                                                                                                                                                        
                                                                                                                                                                                                       

                                                                                                                                                                                                        <?                                                                                                                                                                                                        </?$$

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image there is a diagram, in the diagram there is a circle, in the circle there is a text, there is a person, there is a arrow, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there is a person, there is a text, there

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

$$<_Python_> Average investment = \frac { \frac { \frac { \frac { \sqrt { 2 } } } { \sqrt { 3 } } } + \frac { \sqrt { 3 } } { \sqrt { 4 } } }$$

<!-- image -->

<!-- image -->

<!-- image -->

$$= \frac { 1 5 8 0 0 0 } { 2 0 0 0 0 0 } = 7. 9 9 6$$

<!-- image -->

<!-- image -->

$$\text{ formula} \\ \text{ Internal rate of return} = P + \left [ ( N - P ) \times \frac { p } { p + n } \right ]$$

$$\text{Workings} \\ \text{IRR} & = P + \left [ ( N - P ) \times \frac { p } { p + n } \right ] \\ & = 1 0 + \left [ ( 1 5 - 1 0 ) \times \frac { 8 7 1. 8 0 } { 8 7 1. 8 0 + 3 7 8. 9 0 } \right ]$$

$$\text{Workings} \\ \text{Internal rate of return} = 10 + \left [ (40 - 10) \times \frac { 5408 } { 5408 + 52242} \right ] \\ & = 10 + (30 \times 0.0938) \\ & = 10 + 2.814 \\ & = 12.814% \\ \text{Note}$$

<!-- image -->

<!-- image -->

$$\frac { \text{$2$3$} \times \text{100} } { \text{$4$} \text{ }0\text{0} } = 5.6%$$