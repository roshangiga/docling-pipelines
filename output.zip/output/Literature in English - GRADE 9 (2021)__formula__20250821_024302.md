In this image we can see a cartoon image of a car and a woman.

<!-- image -->

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of Ministry of Education, Tertiary Education, Science and Technology

In this image we can see a car on the road. In the background there are trees.

<!-- image -->

- Head, Curriculum Implementation, Textbook Development and Evaluation

## ENGLISH PANEL

Dr Yesha Mahadeo-Doorgakant

- Panel Coordinator, Lecturer, MIE

Rajendra Korlapu - Bungaree

- Senior Lecturer, MIE

Mangala Jawaheer

- Lecturer, MIE

Iqrah Azam

- Educator

Gianysha Beehuspoteea

- Educator

Yasvina Ghoora-Gopalsing

- Educator

Nipti Rajni Kamal Gopaul

- Educator

Bhavna Gayatri Mohaband-Duljeet

- Educator

Mary Jane Raboude

- Educator

Westley Puven Valaydon

- Educator

<!-- image -->

Design

Isstiac Gooljar

Kunal Sumbhoo

© Mauritius Institute of Education (2021)

ISBN : 978-99949-53-79-0

Acknowledgements

The English textbook panel wishes to thank:

For coordinating the work on the literature textbook

- Mr Rajendra Korlapu-Bungaree  (Senior Lecturer, MIE)

For proof reading and vetting:

- Miss Kamini Moteea (Lecturer MIE)

For permission to reprint adapted versions of :

- Harold Ober Associates, Inc for "Mother to Son"
- Michael Kozubek for "The Cover"
- Brinda Runghsawmee for "My Pen"
- Joseph Tsang Mang Kin for "Ah Ti Le, Oh La La"
- Lindsey Collen for "Boy"
- Shawkat M. Toorawa for "Guavas and Khaandaan"

Consent from copyright owners has been sought. However, we extend our apologies to those we might have overlooked. All materials should be used strictly for educational purposes.

- Graphic Designer
- Graphic Designer

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development  and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the  NCF, while  ascertaining  that  the  instruction  designs  are  appropriate  for  the  age  group  targeted.  I  also acknowledge the efforts of the graphic artists who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## Preface

"Discovering Literature in English, Grade 9" seeks to promote the joy of reading literary texts as well as develop students'  language and literary skills.

The texts that have been chosen cater for a variety of interests whereby students are introduced to writers from different periods and contexts. They are exposed to the three main literary genres: poetry, prose and drama.

The activity-based approach to the study of Literature in English encourages students to explore texts from different literary perspectives in order to develop their understanding and appreciation of the text. It is hoped that the guiding principles of this textbook will help students to grow more confident in the subject.

## To the Teacher

"Discovering Literature in English, Grade 9" adheres to the goals stipulated in the National Curriculum Framework: Nine Year Continuous Basic Education, Grades 7, 8 &amp; 9 (2016).

This  textbook  has  been  conceptualised  bearing  in  mind  the  profile  of  Mauritian  learners.  An overarching process approach is adopted with the pre-, while- and post- reading stages to scaffold the development of high-order skills.  Students are further encouraged to produce informed personal responses to the texts and extracts studied. It is important to note that the teaching activities and tips  are  indicative  and  that  educators  can  supplement,  further  scaffold  or  re-adapt  the  proposed activities as per the needs of their students.

The textbook also comprises a revision section which has been included to encourage students to consolidate their understanding of concepts, texts and extracts studied. It further aims to develop their metacognitive awareness of literary terms. Thus, a glossary is included for students to refer to while they are engaged in self-study.

"Discovering Literature in English, Grade 9" also proposes a section entitled Let's Enjoy . In this section, additional  texts  and  extracts  from  both  local  and  international  writers  have  been  added.  Students are encouraged to discover, at their leisure, other texts and read for their own personal appreciation.

## Contents page

In this image, we can see a diagram.

<!-- image -->

## The Road Not Taken

Poem by Robert Frost

This image consists of a road in the center. On the left side, there are trees and plants. On the right side, there are trees and plants. At the bottom, there is grass.

<!-- image -->

<!-- image -->

## Activity 1 - Exploring the Theme

<!-- image -->

Did you know?

<!-- image -->

Robert Lee Frost was a renowned American poet of the 20th century.

He has won four Pulitzer Prizes for his poetry.

## Discuss the following in pairs.

- i. Imagine there are two roads that lead to your house. Which one do you take, and why?
- ii. Imagine you are walking down the road you have chosen. Describe what you see on your way.
- iii. Have you ever regretted that you took a particular road one day? Why?
- iv. If  you  had  to  take  a  decision,  would  you  follow  others  or  make  your  own  choice? Explain your answer.

<!-- image -->

Discuss the title of the poem with your friends and suggest what the poem could be about.

## Activity 3 - Analysing the Poem

Read the poem carefully and answer the questions next to each stanza.

## Stanza 1

Why  does  the  poet  describe  the wood as 'yellow'?

What  does  the  word  'sorry'  say about the narrator's thoughts and feelings?

According to you, why is it difficult for  the  traveller  to  choose  one road?

## Stanza 2

What reasons does the narrator give for choosing one road?

## Stanza 3

How does the narrator feel after making his choice?

## Stanza 4

Do  you  think  the  choice  he made was a good or bad one? Why?

Two roads diverged in a yellow wood, And sorry I could not travel both And be one traveler, long I stood And looked down one as far as I could To where it bent in the undergrowth ;

Then took the other, as just as fair, And having perhaps the better claim, Because it was grassy and wanted wear ; Though as for that the passing there Had worn them really about the same,

And both that morning equally lay In leaves no step had trodden black. Oh, I kept the first for another day! Yet knowing how way leads on to way, I doubted if I should ever come back.

I shall be telling this with a sigh Somewhere ages and ages hence : Two roads diverged in a wood, and II took the one less traveled by, And that has made all the difference.

<!-- image -->

## GLOSSARY

- Diverged: went separate ways
- Undergrowth: thick bushes and shrubs
- Wanted wear: a road that invited one to use it
- Trodden: crushed
- Hence: from now

## Activity 4 - Exploring Metaphor

In this poem, the poet refers to different roads to represent different choices in life. The road is used as a metaphor.

## Answer the following questions:

- i. Why do you think the poet chose the road as metaphor?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- ii. What other metaphors could you use to describe the choices you make in life? Find pictures for your choice of metaphor and stick them in the boxes below.

<!-- image -->

Teaching Tip : Consider exploring the use of other literary devices in the poem.

<!-- image -->

## Mother to Son

Poem by Langston Hughes (an adapted version)

<!-- image -->

Activity 1 - Exploring the topic

## Observe the two images and answer the questions below.

In this image we can see a painting. In the painting there are stairs.

<!-- image -->

Figure 1

In this image we can see a staircase with steps and railing. We can also see a frame on the wall.

<!-- image -->

Figure 2

- i. In what ways are the two staircases different?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- ii. Which staircase would you prefer to climb? Why?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ Teaching Tip: Encourage students to explain their choice.

Did you know?

<!-- image -->

Langston Hughes (1926-1964) was a successful American poet and novelist. He wrote about the hardships and the joys of the working-class during the 1920s.

<!-- image -->

<!-- image -->

- a. Which staircase could represent difficulties in life?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image we can see a painting. In the painting there are some wooden planks.

<!-- image -->

Figure 1 Figure 2

In this image we can see a staircase with steps and railing. At the top of the image we can see a frame.

<!-- image -->

b(i). These two lines are from the poem that you will be reading on page 9.

'Well, son, I'll tell you:

Life for me ain't been no crystal stair.'

Who do you think is giving advice?

1.   A parent
2.   A sibling
3.   A friend
4.   A teacher

b(ii). Which word from the quote above makes you think so?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

<!-- image -->

## Activity 3 - Analysing the Poem

## Read the poem carefully and answer the questions.

Well, son, I'll tell you:

Life for me ain't been no crystal stair.

It's had tacks in it,

And splinters ,

And boards torn up ,

And places with no carpet on the floorBare.

But all the time

I have been climbin' on,

And reachin' landings ,

And turnin' corners,

And sometimes goin' in the dark

Where there ain't been no light.

So boy, don't you turn back.

Don't you go down the steps

'Cause you find it's harder.

Don't you fall now-

For I'll still be goin' , honey,

I'll still be climbin' ,

And life for me ain't been no crystal stair.

- a. Whose life has been hard?
- b. What advice is being given?
- c. Where do you think the mother and the son are standing on the staircase? Why?
- d. Why is ' Life for me ain't been no crystal stair " repeated twice ?
- e. What do you think the mother means  when  she  says, 'Don't you  go  down  the  steps  'Cause you find it's harder.' ?

<!-- image -->

Teaching Tip: Read the poem aloud before analysing it.

## PICTURE GLOSSARY

<!-- image -->

Tacks

In this image we can see a building.

<!-- image -->

Splinters

Landings

In this image we can see a painting. In the painting there is a chair.

<!-- image -->

## GLOSSARY

- Ain't been - informal way of saying "hasn't been"
- Torn up - damaged

## Activity 4 - Interpreting quotations

Interpretation is  the  reader's  way  of  understanding  a  text.  There  can  be  many interpretations  of  a  text.  We  can  use  short  and  direct  quotations  to  support  our interpretations.

## Example

## Interpretation(s)

"And sometimes goin' in the dark Where there ain't been no light. "

It could mean that climbing the stairs in the dark is dangerous because you can hurt yourself.

It could also  mean  that  because  it is  dark,  you  can  feel scared of  the unknown.

- i. Quote five examples from the poem to show that it is hard to climb this staircase. Interpret the four quotations. One example has been done for you.

Example 1: "tacks in it"

Interpretation: It can hurt your feet.

Example 2: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Interpretation: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

<!-- image -->

Example 3: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Interpretation: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Example 4: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Interpretation: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Example 5: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Interpretation: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Teaching Tip:

Encourage students to think why the poet

has used so many examples in a short poem.

## Complete this paragraph.

The poet uses a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ of a staircase to show the difficulties in life. He

uses different examples to show how this staircase is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ to climb. The

quotation, 'And sometimes goin' in the dark / Where there ain't no light' could mean

that climbing the stairs can be scary and dangerous when it is dark.

Another example in the poem is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

## Activity 5 - Writing an interpretation

<!-- image -->

Teaching Tip: A simple explanation of interpretation has been given. Adapt as per the needs of the learners. Encourage learners to use words like: suggest, imply and convey to explain their interpretations.

<!-- image -->

Activity 6 - Consolidating understanding of the metaphor

Observe the following picture and explain how this vegetable is used as a metaphor in the local context to represent the difficulties in life.

In this image we can see some vegetables and some objects.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ Teaching Tip: Encourage students to give other metaphors used in the local context.

## The Cover

Short story by Michael Kozubek (an adapted version)

In this image, we can see a person wearing a jacket and spectacles. We can also see a number on the image. We can see a text on the image.

<!-- image -->

- ii. On a scale of 1 to 5, how important are the following when you first meet someone?

|                            | 1   | 2   | 3   | 4   | 5   |
|----------------------------|-----|-----|-----|-----|-----|
| The way they dress         |     |     |     |     |     |
| The way they speak         |     |     |     |     |     |
| The way they behave        |     |     |     |     |     |
| What others say about them |     |     |     |     |     |

<!-- image -->

<!-- image -->

## Read and fill the tables with the appropriate information.

Laughing loudly, the four teenagers of different heights, stood menacingly inside the small drug store. Their roar interrupted the graveyard silence of the cold January night. Outside the store, a light beamed GIUSEPPE'S through the darkness.

The shop owner, Giuseppe, a frail, grey-haired man, knelt picking up and rearranging paperback books on a rack one of the boys had just toppled. As he did so, the man looked over his shoulder and cried: 'Get out of my shop, you rowdies .  Get out and don't ever come back!'

The leader of the group, Frank, was a tall, beefy teenager wearing a leather jacket and dirty jeans. It was apparent by the scars on his rough face that he had been in a number of street fights. The other boys had tough-looking faces, too, and tattered clothes.

Rising painfully, Giuseppe shook his fist at the boys and thundered again, 'Get out now.'

<!-- image -->

In this image we can see a cartoon image of a person.

<!-- image -->

All  of  the  boys,  except  Frank,  dashed  out  the  door.  As  he sauntered  slowly  in  defiance  of  the  old  man,  the  shop owner rushed toward him like a wounded bear. Giuseppe grabbed  a  broom,  standing  against  the  ice  cream  freezer, and swung it hard at him. It swept through the air as the youth  lunged  back.  Frank,  quickly  removing  an  egg  from his jacket pocket, heaved it at Giuseppe, who was hit in the stomach by the missile.

Surprised, the proprietor stopped momentarily, then roared, 'Why,  you  brat!'  Missing  Frank  again  in  a  final  swing,  he slammed the door and sat down in exhaustion.

## GLOSSARY

-  tattered torn
-  menacingly dangerously
-  rowdies troublemakers
-  beefy strong and powerful

<!-- image -->

Placing  his  hands  into  his  pockets  as  he  strolled  into  the  frozen  night  air  to  join  his shivering gang, Frank laughed and said: 'I knew that egg would find a good use.  Boy, wasn't that guy mad after I toppled his rack! You guys will have plenty of laughs sticking with me.'

One of the boys, George, a thin fellow with a pale face, replied, 'Sure, it was funny then, Frank. Now, I'm not so sure.'

'What? Don't tell me you pity the old man,' said Frank sharply.

'No, of course not, it's just…' answered the younger boy.

The gang remained talking across the street from the store. Several minutes later, two policemen in a squad car, answering Giuseppe's call, stopped on the street. They warned the boys about trespassing and ordered them to go home.

## How does Frank react or behave?

## Short and direct quotes as evidence.

## GLOSSARY

-  trespassing entering someone's land or property without permission.

One week later at night, a beige Ford rumbled down a dark country road, covered with snow and ice. Giuseppe was returning from a visit to his daughter. The ten-mile drive had been slow and tedious because of the ice and the fallen white flakes, but the old man was just minutes from home now. As he made a slow turn on the narrow road, however, the back wheels of his car began to spin in the ice hidden beneath the snow. Giuseppe climbed slowly out of the car and moved toward the back to take a closer look. After a few steps, he slid on a patch of ice and tumbled hard to the cold ground. Groaning, he lay there in pain. It felt as if an ankle had been broken.

For twenty minutes he lay there, though it seemed nearly forever, shivering and unable even to sit up. Finally, the lights of a car appeared in the dark. It crept down the narrow highway toward him. Giuseppe wept for joy.

An old red Chevrolet stopped before him. The first person to exit was the driver, Frank, hatless, followed by his three friends. Because of the slippery condition of the snow and ice, they walked cautiously toward the injured man.

'Please help me,' pleaded Giuseppe, in a weak voice. 'I think my ankle is broken."

'Don't worry, old man, we will,' replied George, assuring the man.

'Why  should  I  help him ?'  shouted  Frank  in  angry. 'Because  of  him,  the  cops  will  be watching us forever now.'

'Have you no heart?' asked George sharply.

<!-- image -->

'No. C'mon. I'm freezing. Let's go,' said Frank scornfully .

Teaching Tip: Focus on what Frank says and does. Discuss what this reveals about his character (motives and traits).

Frank's  words  had  been  so  unexpected  that  the  three  remaining  youths  remained  in the  road,  speechless.  Not  hearing  any  response  from  his  friends,  Frank  shouted, 'Suit yourselves. I'm leaving. So long, chumps.'

## GLOSSARY

-  rumbled -

made a low sound

-  scornfully with displeasure
-  tedious: tiring

## What could be Frank's motives?

## Short and direct quotes as evidence.

The  three  boys  watched  the  tail  lights  of  the  Chevy  as  it  crept  away.  But  they  soon remembered the suffering man needed their attention.

The boys tried to make Giuseppe as comfortable as possible. One of the boys took off his jacket and wrapped it around him. They offered him the only food they had, a Snickers bar, and some water, and tried to reassure him that he would be all right though their own  hearts  were  pounding.  One  boy  pulled  out  his  smartphone,  but,  out  in  the wilderness, he couldn't connect even for an emergency call. They looked out into the cold dark and were not sure what to do.

Then George said, 'Giuseppe needs a doctor, but I think the nearest phone is a few miles from here. Someone should start walking to get an ambulance.'

Two  boys  immediately  started  walking.  The  harsh  wind  whistled  past  them  and  bit their cheeks as they trudged silently along the road a mile, scared and anxious. For the first  time,  they  thought of their leader, leaving an old man to die in the cold, as cruel and pathetic ,  his  soul  as  harsh as the cover of the person he revealed to others. They worried about getting help in time. They worried about frostbite and  becoming  lost themselves.

## GLOSSARY

-  trudged walked slowly ·  pathetic useless / worthless
-  frostbite injury caused by severe cold

When  they  spotted  flashing  red  lights  in  the  distance  approaching,  however,  they stopped.  As  the  lights  finally  crept  nearer,  they  were  able  to  see  two  vehicles:  an ambulance, followed by an old, red Chevrolet. There were never any happier nor more thankful boys.

## How do other characters view Frank?

## Short and direct quotes as evidence.

<!-- image -->

## Activity 3 - Exploring Characterisation

## i. Write down the traits and motives when analysing Frank's character.

<!-- image -->

Teaching Tip: Familiarise students with these literary terms as they analyse the characters. The definition of the terms can be found in the glossary.

| Character   | Character Traits                                                              | Character Motives                                                                                                                                                               |
|-------------|-------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|             | A quality or aspect of personality. It is often described using an adjective. | The reason that drives a character to think, behave and speak in a particular way. It is often understood by looking at what he does, says and what others think/say about him. |
| Frank       | At the start:                                                                 |                                                                                                                                                                                 |
| Frank       | At the end:                                                                   |                                                                                                                                                                                 |

<!-- image -->

Teaching Tip: Encourage  students  to  select  appropriate quotes to support their answers.

<!-- image -->

- ii. Frank is in his car after having left the two boys behind to help Giuseppe. What is he thinking as he drives away? Fill the thought bubble.

In this image we can see a cartoon image of a car on the road. In the background there is a fence and trees.

<!-- image -->

## Marilla Cuthbert Is Surprised

Extract from Anne of Green Gables by Lucy Maud Montgomery (an adapted version)

In this image we can see a cartoon image of a girl.

<!-- image -->

I  am  so  scared  to  meet these new people. What am  I  supposed  to  say anyway? Leaving my friends behind … Going to a new place … I feel so scared.

## Activity 1 - Building Empathy

Imagine  that  you  are  an  orphan  who  is  meeting his/her new family for the first time. Jot down your feelings and expectations.

Did you know?

<!-- image -->

Lucy Maud Montgomery was a Canadian author.

When she was a baby, her mother died and her father left her with her grandparents. She was a lonely child and found comfort in her imagination, nature, books and writing.

She is famous for her novel, 'Anne of Green Gables.'

<!-- image -->

<!-- image -->

Read the text carefully and answer the questions.

## Marilla Cuthbert  is Surprised

'You don't want me!' she cried. 'You don't want me because I'm not a boy! I might have expected it. Nobody ever did want me. I might have known it was all too beautiful to last. I might have known nobody really did want me. Oh, what shall I do? I'm going to burst into tears!'

Burst  into  tears  she  did.  Sitting  down  on  a  chair  by  the  table,  flinging  her  arms  out upon it, and burying her face in them, she cried stormily . Marilla and Matthew looked at each other. Neither of them knew what to say or do. Finally, Marilla stepped forward.

'Well, well, there's no need to cry so about it.'

'Yes,  there is need!'  The  child  raised  her  head  quickly,  revealing  a tear-stained face and trembling lips. ' You would cry, too, if you were an orphan and had come to a place you thought was going to be home and found that they didn't want you because you weren't a boy. Oh, this is the most tragical thing that ever happened to me!'

## GLOSSARY

-  stormily making a lot of noise
-  tear-stained dried with tears

<!-- image -->

<!-- image -->

## Stop and React: The Outburst

According to you, who is telling the story? Is it the child, Marilla  or  the author?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Describe how the child is feeling at this moment.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

How would you react if you were in the place of Marilla or Matthew?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

Teaching Tip: Introduce the concept of first person and third person narration.

Something like a reluctant smile softened Marilla's grim expression.

'Well, don't cry any more. We're not going to turn you out-of-doors tonight. You'll have to stay here until we look into this affair. What's your name?'

The child hesitated for a moment.

'Will you please call me Cordelia?' she said eagerly. ' Call you Cordelia? Is that your name?' Marilla asked.

'No-o-o, it's not exactly my name, but I would love to be called Cordelia. It's such a perfectly elegant name.'

## GLOSSARY

-  reluctant - hesitant

·  grim - serious

"Anne Shirley" the child whispered, "but oh, please do call me Cordelia".

<!-- image -->

## Stop and React: Changing names

Why do you think the child wants to be called Cordelia?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What impression do you have of the child so far?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What can we infer from her wish to use another name?

KEY TERMS: Infer: to guess the meaning of a statement.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

'Very well, then, Anne, can you tell us how this mistake came to be made? We sent word to Mrs. Spencer to bring us a boy. Were there no boys at the orphanage?'

'Oh, yes, there was an abundance of them. But Mrs. Spencer said that you wanted a girl of about eleven years old. And the matron said she thought I would do. You don't know how delighted I was. I couldn't sleep all last night for joy. Oh,' she added reproachfully , turning to Matthew, 'why didn't you tell me at the station that you didn't want me and leave me there?

Matthew hastily added, 'I'm going out to put the mare in, Marilla. Have tea ready when I come back.'

## GLOSSARY

-  matron - lady responsible of an orphanage
-  reproachfully - in a way that shows that she doesn't approve

'Did Mrs. Spencer bring anybody over besides you?' continued Marilla when Matthew had gone out.

'She brought Lily Jones for herself. Lily is only five years old and she is very beautiful and has brown hair. If I were very beautiful and had brown hair would you keep me?'

'No. We want a boy to help Matthew on the farm. A girl would be of no use to us. Take off your hat. I'll lay it and your bag on the hall table.'

<!-- image -->

## Stop and React: Anne's feelings about herself

Anne says, 'If I were very beautiful and had brown hair would you keep me?'

What does this quote show about Anne's feelings?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

"A girl would be of no use to us. " How would you react to this statement if you were Anne?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Anne took off her hat meekly . Matthew came back presently and they sat down to eat dinner. But Anne could not eat. In vain, she nibbled at the bread and butter.

'You're not eating anything,' said Marilla sharply, eyeing her as if it were a serious weakness. Anne sighed.

## GLOSSARY

-  meekly - in a quiet manner
-  nibbled - took small quick bites

<!-- image -->

## Stop and React: The change in Anne's behaviour

This is what Anne did at the beginning: 'Anne took off her hat meekly.'

Anne now says, 'I'm in the depths of despair. Can you eat when you are in the depths of despair?'

Compare Anne's behaviour at the beginning and now.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

'I can't. I'm in the depths of despair. Can you eat when you are in the depths of despair?' 'I've never been in the depths of despair, so I can't say,' responded Marilla.

'Weren't you? Well, did you ever try to imagine you were in the depths of despair?'

'No, I didn't.'

'Then I don't think you can understand what it's like. It's a very uncomfortable feeling indeed.  When  you  try  to  eat  you  can't  swallow  anything.    I  do  hope  you  won't  be offended because I can't eat. Everything is extremely nice, but still I cannot eat.'

'I  guess  she's  tired, '  said  Matthew,  who  hadn't  spoken  since  his  return  from  the  barn. 'Best put her to bed, Marilla.'

## KEY TERMS:

Compare: to look for similarities and differences

Marilla  had  been  wondering  where  Anne  should  be  put  to  bed.  She  had  prepared  a couch in the kitchen for the desired and expected boy. But, although it was neat and clean, it did not seem quite the thing to put a girl there somehow. There remained only a  small  bedroom.  Marilla  lighted  a  candle  and  told  Anne  to  follow  her,  which  Anne unwillingly did, taking her hat and carpet-bag from the hall table as she passed.

Marilla set the candle on a three-legged table and turned down the bedclothes.

'I suppose you have a nightgown?' she questioned.

Anne nodded and answered, 'Yes'

'Well, undress as quick as you can and go to bed. I'll come back in a few minutes for the candle. I daren't trust you to put it out yourself. You'd likely set the place on fire.'

With  a  sob,  she  hastily discarded her  garments,  put  on  the skimpy nightgown  and sprang into bed where she buried her face into the pillow and pulled the clothes over her head. When Marilla came up, Anne's clothes were thrown most untidily over the floor.

She deliberately  picked  up  Anne's  clothes,  placed  them  neatly  on  a  yellow  chair,  and then, taking up the candle, went over to the bed.

'Good night,' she said, a little awkwardly, but not unkindly.

Anne's white face and big eyes appeared over the bedclothes.

'How can you call it a good night when you know it must be the very worst night I've ever had?' she said reproachfully.

Then she dived down under the bedcover again.

## GLOSSARY

-  discarded - removed
-  skimpy - thin

<!-- image -->

## Stop and React: Marilla's polite goodnight

At this  point,  a  contrast  can  be  made  between Marilla's first  reaction  to Anne and her polite goodnight now.

Why do you think Marilla is being kind to Anne now?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Marilla  went  slowly  down  to  the  kitchen  and  started  to  wash  the  supper  dishes. Matthew was smoking-a sure sign of worry.

'Well,  this  is  a  big  mess, '  she  said  angrily. 'One  of  us  will  have  to  drive  over  and  see Mrs. Spencer tomorrow, that's certain. This girl will have to be sent back to the orphanage.'

'Yes, I suppose so,' said Matthew reluctantly.

'You suppose so! Don't you know it?'

'Well now, she's a real nice little thing, Marilla. It's kind of a pity to send her back when she's so set on staying here.'

'Matthew Cuthbert, you don't mean to say you think we ought to keep her!'

Marilla shook her head in astonishment.

'Well, now, no, I suppose not-not exactly,' stammered Matthew.  'I suppose-we could hardly be expected to keep her.'

'I should say not. What good would she be to us?'

'We might be some good to her,' said Matthew suddenly and unexpectedly.

'Matthew Cuthbert, I believe that  child  has  charmed  you!  I  can  see  as  plain  that  you want to keep her.'

<!-- image -->

<!-- image -->

## Stop and React: The Ending

Write down two reasons why Matthew would want Anne to stay.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

'Well  now,  she's  a  real  interesting  little  thing,'  persisted  Matthew.  'You  should  have heard her talk coming from the station.'

'Oh, she can talk fast enough. I saw that at once. It's nothing in her favour, either. I don't like children who have so much to say. I don't want an orphan girl and if I did she isn't the style I'd pick out. There's something I don't understand about her. No, she's got to be sent back to where she came from.'

'I could hire a French boy to help me,' said Matthew, 'and she'd be company for you.'

'I'm not suffering for company,' said Marilla shortly. 'And I'm not going to keep her.'

'Well now, it's just as you say, of course, Marilla,' said Matthew rising and putting his pipe away. 'I'm going to bed.'

To bed went Matthew. And to bed, when she had put her dishes away, went Marilla in a determined way. And up-stairs, in the east gable, a lonely, heart-hungry, friendless child cried herself to sleep.

<!-- image -->

## Imagine you are Marilla. What will you do when you wake up the next day?

<!-- image -->

Teaching  Tip: Get  the  students  to  come  up  with  different scenarios. They can either enact the scenarios or draw them.

## The Tempest

Extract from Act1 scene1 By William Shakespeare (an adapted version)

## Activity 1 - Imagining the scene

Imagine you are on a ship in the middle of the sea when there is a storm. Use your five senses to describe your experience.

In this image we can see a ship on the water.

<!-- image -->

<!-- image -->

see?

Teaching Tip: Refer to local weather conditions.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The image is a diagram with five main components. The components are labeled as follows:

1. **What do you**
   - This is a question that asks the user to identify the main theme or concept of the diagram.

2. **Smell**
   - This is a question that asks the user to identify the smell associated with the main theme of the diagram.

3. **Taste**
   - This is a question that asks the user to identify the taste associated with the main theme of the diagram.

4. **Smell**
   - This is a question that asks the user to identify the smell associated with the main theme of the diagram.

5. **Smell**
   - This is a question that asks the user to identify the smell associated with the main theme of the diagram.

The diagram is divided into five sections, each labeled with a different word or phrase. The labels are:
- **What do you**
- **Sm

<!-- image -->

<!-- image -->

William Shakespeare , is one of the most famous English playwrights. He wrote 38 plays and 154 poems. His plays were enjoyed by royalty as well as the general public. 400 years later, his writings are still studied and enjoyed all around the world.

<!-- image -->

## Activity 2 - Discovering characters in a play (Dramatis Personae)

## Observe the characters below and guess their roles in the play.

Shipmaster Captain of the ship

<!-- image -->

<!-- image -->

<!-- image -->

Antonio Brother to Prospero, who is the main character in the play

In this image we can see a person standing.

<!-- image -->

Boatswain Second in command on the ship

Sebastian Brother of the King of Naples, Alonso

<!-- image -->

Gonzalo An old and honest Lord

Mariners Sailors on the ship

In this image we can see a group of people standing.

<!-- image -->

<!-- image -->

Read the following extract carefully and answer the questions.

## The Tempest- Act 1, Scene 1

## Setting the scene

It  is  in  the  middle  of  the  night.  There  is  a  violent  storm at  sea.  Loud  claps  of  thunder  can  be  heard.  Flashes  of lightning  can  be  seen.  A  ship  is  caught  in  the  storm. The  crew  members  are  struggling  to  keep  the  ship afloat  against  the  crashing  waves.  An  island  can  be seen faraway.

The Shipmaster and the Boatswain are desperately trying to navigate the ship despite the storming weather.

Shipmaster: Boatswain!

Boatswain: Here, Shipmaster! What cheer?

[Heavy rain, loud claps of thunder, howling wind]

Enter Mariners with tools and ropes.

Boatswain: Take in the topsail. Tend to the Shipmaster's whistle .

Enter Antonio and Gonzalo.

Boatswain: I pray now keep below.

Antonio: Where is the Shipmaster, boatswain?

<!-- image -->

Boatswain: Do you not hear me? You mar our labour. Stay in your cabins. Silence! Trouble us not!

Gonzalo: Good, yet remember whom thou hast aboard.

Boatswain, desperately steering the wheel:

## Questions

1. Describe the atmosphere at the beginning of the play.

Teaching Tip: Encourage students to read aloud to feel the mood.

<!-- image -->

## The Tempest- Act 1, Scene 1

Boatswain: None that I more love than myself. You are a councillor ;  if  you  can  command  these  elements  to silence,  use  your  authority.  If  you  cannot,  out  of  our way, I say.

Gonzalo: I have great comfort from this fellow.

Exit Gonzalo &amp; Antonio.

Boatswain: Down with the topmast!  Yare! Lower! Lower! Bring her to try with main course. [A cry within]

Enter Sebastian. Re-enter Gonzalo &amp; Antonio.

Boatswain: What are you doing here? Shall we give over and drown? Have you a mind to sink?

Sebastian: A pox on your throat, you bawling , incharitable dog!

Boatswain: Work you then.

Antonio: Hang, cur ! Hang, you insolent noisemaker! We are less afraid to be drowned than thou art.

Enter  mariners,  with  ropes  and  broken  pieces  of  wood. They are wet and terrified.

Mariners: All lost! To prayer, to prayers! All lost!

<!-- image -->

## Questions

2. What does the conversation between the Boatswain and Gonzalo reveal about their relationship?
3. How does Sebastian treat the Boatswain here?

## The Tempest- Act 1, Scene 1

Gonzalo: The King and Prince are at prayers, let's assist them.

Sebastian: I am out of patience.

Antonio: We are merely cheated of our lives because of drunk mariners.

[A confused noise within]

[Big waves are crashing on the deck which has tilted. Loud screams can be heard. The mast cracks and starts falling]

- All: Mercy on us! -We split , we split! - Farewell, my wife and children! - Farewell, brother! - We split! we split! we split!

Exit Boatswain.

Antonio: Let's all sink with the King.

Sebastian: Let's take leave.

Exit Sebastian &amp; Antonio

Gonzalo:  Now  would  I  give  a  thousand furlongs of sea for an acre of barren ground, long heath ,  brown furze ,  anything. The wills above be done! But I would die a dry death.

Exit Gonzalo.

<!-- image -->

<!-- image -->

## Questions

4. If you were one of the characters on board, how would you react at this point?
5. How is Gonzalo feeling here?
6. What do you think will happen to the people on the ship?

Teaching Tip: Give the opportunity for students to enact the scene.

## GLOSSARY

- Whistle a clear, high-pitched sound
- Councillor an elected member of the council that governs a city/ country
- Pox a viral disease
- Bawling to shout in a very loud voice
- Incharitable unfeeling
- Insolent ill- mannered
- Cur an unattractive dog. This is used as an insult
- Split break apart
- Furlongs a unit of measurement
- Barren infertile
- Heath a wild piece of land with some vegetation
- Furze a wild bush with sharp thorns and small, yellow flowers

<!-- image -->

## Activity 3 - In the shoes of the Director

## Look closely at the following picture of the Globe Theatre.

In this image we can see a group of people sitting on the floor. In the background there is a building.

<!-- image -->

## Did you know?

In  the  1600s, most of Shakespearean  plays were performed at the Globe Theatre. There was neither modern technology nor electricity. The props were handoperated.

<!-- image -->

Imagine  you  are  a  theatre  director.  You  have  to  stage  Act  1  Scene  1  as  it  was performed during Shakespeare's time.

- What props would you use to show that there is a storm? (e.g for rain, waves, lighting, thunder)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- How would you recreate those effects now if you had to stage it with modern tools and technology?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

Teaching Tip: Students may watch modern versions of the play to get more ideas.

<!-- image -->

In the center of the image there is a circle. Inside the circle there are two quotation marks.

<!-- image -->

<!-- image -->

## Revision Questions

This section helps you to revise the texts and literary concepts you have studied.

## THE ROAD NOT TAKEN

## Exercise 1:

## Read the poem again and circle the right answer.

1. From stanza 2, which word suggests that the narrator is uncertain about his choice of road?
- a. "grassy"
- b. "perhaps"
2. Which phrase suggests that the road the poet had taken was not a common one?
- a. "Two roads diverged in a yellow wood"
- b. "I took the one less travelled"
3. We know that nobody took the road when the poet says
- a.  "In leaves no step had trodden black"
- b.  "Yet knowing how way leads on to way"
4. Which phrase shows that the narrator was being careful when choosing which road to take?
- a. "Because it was grassy and wanted wear"
- b. "And looked down one as far as I could"

## Exercise 2:

Below is  a  list  of  metaphors.  Fill  in  the  blanks.  Use  the  pictures  as  clues  for  the missing words.

1. A child is an angel for his/her parents.
2. Shakespeare said, 'All the world's a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_. And all the men and
2. women merely players' .
3. We have to fight for what we believe. Life is a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.
4. When we are sick, we realise that health is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

MA'

<!-- image -->

## Exercise 3

Think about a decision you have to take (eg. choice of subjects at Grade 10, buying a new mobile phone, etc). Describe at least two options you could take. Explain how you would finally decide which option to take and why.

<!-- image -->

Teaching Tip: Encourage students to use graphic organisers to represent their decision-making process.

## Mother to Son

## Exercise 1

1. In Mother to Son , Hughes uses the metaphor of a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A. crystal staircase

- B. dangerous staircase

- C. lift

2. The overall message of the poem is to \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A. climb the staircase

- B. return to the bottom of the staircase

- C. persevere in life despite difficulties

3. In the poem, a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is giving advice.

- A.  mother

- B. son

- C. brother

4. 'And places with no carpet on the floor-' implies that \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A. sometimes life can be very difficult

- B. sometimes life can be normal

- C. sometimes life can be easy

5. The type of language used in this poem is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- A. informal and conversational

- B. formal and conversational

- C. professional

## Choose the correct answer.

<!-- image -->

## Exercise 2

Imagine that you are the son who is receiving advice from the mother in this poem. Explain how you feel after listening to her.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Exercise 3

Ram and Adilah had to write whether they liked this poem or not as part of their homework.

Read the two personal responses and decide which one is better. Justify your choice.

## Ram

I  liked  this  poem  because  of  the  way  that  the  poet  uses  the  metaphor  of  a  dangerous staircase to show difficulties. It was enjoyable to read.

## Adilah

I found this poem interesting because the poet uses the metaphor of a dangerous staircase to show the importance of persevering in life despite difficulties. For example, my favourite part  in  the  poem  is  when  the  mother  says  'But  all  the  time/I  have  been  climbin'  on,  / And reachin' landings' . I like this part because it makes me realise that when we persevere, in the end, we will overcome our difficulties.

- i. Write your own personal response to the poem.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## The Cover

## Exercise 1

Reorder the sentences [using the numbers in the right-hand column] to describe what happens in the story. The first and last ones have already been done for you.

| A week later, while driving home in the snow, Giuseppe's car tyre gets in a ditch.                                                            |    |
|-----------------------------------------------------------------------------------------------------------------------------------------------|----|
| A gang of rowdy boys causes trouble in a shop for fun and the angry owner calls the police.                                                   | 1  |
| Two of them start walking to the nearest telephone booth to call an ambulance and one stays back with Giuseppe.                               |    |
| When he comes out to check his tyre, Giuseppe falls and breaks his ankle.                                                                     |    |
| Then they see Frank's car. He has come back to help and brought an ambulance for them.                                                        | 8  |
| Seeing the situation, Frank refuses to help the injured man. The others, wanting to help, are surprised. Frank abandons them and drives away. |    |
| Giuseppe stays lying on the icy ground for 20 mins in pain when he finally sees a car approaching. The car belongs to the gang.               |    |
| The two boys feel disappointed in their leader who abandoned them and worry about how the night would end.                                    |    |

<!-- image -->

GRADE 9

## Exercise 2

Pick out the words that can describe Frank's character traits at the start of the story and provide some evidence to support your answer.

In this image, we can see some text.

<!-- image -->

## Exercise 3

Does the story have a good ending? Write 3-4 sentences to explain your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

'Bullies are often those who were themselves bullied before.'

- a. Give reasons why this is the case.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b. Imagine and describe what could have turned Frank into a bully.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Exercise 4

44

## Marilla Cuthbert is Surprised

Exercise 1

Fill in the blank spaces with the different parts of the story.

In this image, we can see a diagram with different sections. There are some text written on the image.

<!-- image -->

## Exercise 2

Why do you think Matthew Cuthbert wants to keep Anne? Tick the correct answers.

## Exercise 3

In  the  extract,  Matthew  tries  to  persuade  Marilla  to  keep  the  little  girl.  Suggest other ways he can use to persuade Marilla.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

1. From the very beginning, he had wanted to have a girl from the orphanage.

2. He feels sorry for the little girl.

3. He likes children in general.

4. He wants to help Anne.

5. He finds the little girl interesting.

6. Anne will be able to help him on the farm.

<!-- image -->

## The Tempest

## Characters

1. Who is Prospero's brother? \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

2. What is the relationship between Sebastian and the King of Naples, Alonso?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Plot

3. Describe the situation on the ship at the beginning of the scene.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Describe the Boatswain's tone when talking to Antonio.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. According to you, why is he using this tone?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Exercise 1

## Exercise 2

## Stage direction

1. You have the following props at your disposal. Explain how you would use each one to direct the extract given below.

<!-- image -->

Drum

<!-- image -->

<!-- image -->

<!-- image -->

Giant fan

Iron sheet

Water hose

Enter mariners, with ropes and broken pieces of wood. They are wet and terrified.

Mariners: All lost! To prayer, to prayers! All lost!

Exit all mariners

Gonzalo: The King and Prince are at prayers, let's assist them.

Sebastian: I am out of patience.

Antonio: We are merely cheated of our lives because of drunk mariners

[A confused noise within]

[Big waves crashing on the deck which has tilted, loud screams can be heard, the mast is breaking.]

In the center of the image there is a circle. Inside the circle there is a text.

<!-- image -->

In this image we can see a book with some text on it.

<!-- image -->

<!-- image -->

In this image we can see a paper with some text written on it.

<!-- image -->

In this image we can see a paper with some text written on it.

<!-- image -->

## Boy

Extract from Boy  by Lindsey Collen

When the road turns in at the junction and goes towards Montayn Long, the bus itself relaxes its muscles. You can't believe it. A sort of slowness, and deep breathing sets in. The vehicle calms down. Stops hooting for nothing. It doesn't even rev up for nothing any more either, nor brake sharply after accelerating too much. Nor is there much traffic left on the Branch Road anyway.

Passengers begin to talk to the person who has been sitting next to them in silence all the way so far. 'Water's going up, I don't know how I'm going to manage,' and 'I hear the Minister had a hard time at the meeting in your street,' and 'Your niece from Lalmati, the fair one with the short hair, I happen to know a boy from a very nice family.'

No more hurry. No more bustle. Life settles down to the rhythm of the countryside. Over just those few miles? Peace, tranquillity.

'Don't sentimentalize, Krish,' I say to myself, 'Only rural idiocy you're seeing.'

But the mountain draws nearer, too.

It's a fact.

Slowly but surely, bus stop by bus stop. Giving me its different faces as the road winds this way and that. The caring aunt mountain, the fierce mother mountain, the flippant young girl mountain, the scary devil mountain, the hesitant boy mountain, the cold indifferent father  mountain,  the  cross  goddess  mountain,  the  innocent  bystander  mountain,  the embracing lover mountain. The sky here, it's so clear it hurts. The sun passes overhead so low here, I should have brought a cap. Sugar cane gives way to ginger plants, whose pointed leaves coil around into a fine point. Flat lands give way to the foothills of the mountain.

<!-- image -->

<!-- image -->

So I pull the string and ring the bell. Get off the bus, cross the road, and watch all the airborne seeds flying across the road in the air just next to my face. Multiplying. And two yellow and brown queen-of-the-oceans giant butterflies hide their colours, then show them, hide their colours, then show them.

Is this side, the other side of the road, better?

How would I know?

As I'm bending over like that to tie the laces of one of Baya's navy-blue running shoes, and as I'm leaning over to put my denim bag down on a big rock next to the return bus stop, my eye gets caught by a ladybird. A tiny ladybird sitting on the rock. I stop in midair. All on its own. A self-contained, self-possessed, dignified creature. Shiny black with red spots. Could I be like that? Whole? Is the world like this every day? Are there butterflies and ladybirds and flying seeds? Do I only see these things now? I bend over and look at the ladybird. I love that ladybird, such a calm creature, so you know what I do? I wish it  a  pleasant day, and instead of putting my bag down next to it - it would be such a big thing to have next to her - I just flip the bag over my shoulder, and sit down on my haunches to tie my shoelace. Then I turn away from the ladybird and go straight towards Mamu Dip and Renuka Mami's house. Full stride.

So, maybe. Or, maybe.

Maybe I have got a life ahead of me.

Out there. Like a road opening out towards something. A future. I don't know how it comes about, but when I get there, as I am crossing that road, even before I saw that ladybird, I earned a kind of calm. I feel I earned it. It's that that made me see the ladybird. The mountain smiles at me then. I see it.

I say to myself, 'What a load of rubbish, Boy!'

But.  But  it's  as  if  I  have  broken  some  chain.  And  a  rich  swelling  outwards  of  pleasure comes with being alive. Is this a beginning? Can I take the risk? Beginning of what I can't tell you. I don't know myself. But a beginning?

## 'Guavas and Khaandaan'

Extract by Shawkat M. Toorawa (An Adapted version)

'He's a good lad from a good family, that's all I'm saying,' Rafik's father emphasised, looking now at Razia. But that was not all he was saying.

'What is that supposed to mean?' said Rafik in a low, urgent tone, almost in desperation. 'Don't swear at your father!' his mother said.

'I'm not swearing. I am asking a simple question. Good family, my foot! That's what he said about Hameed Balbodan and look where that led: with some German woman now. I wonder if he beats her too... Where's the good family now? What about khaandaan *?'

'He  did  not  beat  anyone,'  Rafik's  mother  said  firmly,  her  eyes  pleading  for  a  rapid conclusion to this conversation and this affair.

'Everyone knows he beat his wife, Ma. Hell, even Papa knew but did nothing about it.'

Although the sensation in the back of his neck was still palpable, Rafik felt calmer. Maybe it was the effect of his own words, or of the tea that Razia had wordlessly brought him. He looked at Razia.

' Just because one person does something stupid doesn't change the fact that the person is from a good family,' persisted Rafik's father.

Why  did  Razia  not  say  anything,  not  protest?  Rafik  knew  that  this  boy,  like  the  two previous ones, did not enchant her in the least. She could not bear their almost obligatory pretention.

<!-- image -->

<!-- image -->

Rafik  returned  from  the  sunset  prayer,  whistling  quietly.  His  more  orthodox  friends would have found the behaviour disrespectful, in spite of the fact that it was the melody of a famous qawwali chanted at the shrine of Salim Chisti - or perhaps because of it.

When he got home, Rafik went straight to the dinner table. The family sat down to a hushed meal, each person rehearsing the earlier conversation.

They were still  savouring  the  fish  curry  when  they  heard  the  front  gate  scrape  open. Someone walked up the cobblestone path. Razia was the first to recognise the stranger and smiled. Serene though it was, her smile revealed her emotions. It had been five years since she had seen Zubayr and he still had the same effect on her.

'Salam-alaykum, Auntie,' he said, addressing Razia's mother, 'you're looking great.'

Still  the  charmer, thought Razia. Her mother answered the greeting but did not know quite what to say next.

'When did you get back, Zoob?' asked Rafik as he bear-hugged his childhood friend.

'Zubayr, not Zoob!' exclaimed Razia. She had never approved of the nickname.

' Just this minute. My luggage is in the taxi outside.'

'But what about university,' queried Rafik's father, 'are you done?' University was for Rafik's father and his generation something you finished, like a meal or a painting or a book, not a process.

Zubayr sat down, took a sip of grape juice from Rafik's glass and explained that he was now doing a Phd and that he had reached the proposal stage. The word 'proposal' had an inexplicable effect for Zubayr, on the family members. Razia dropped the AMC pot she was carrying to the kitchen, her mother gulped, and her father fumbled with his tobacco pouch. Only Rafik was silent. Zubayr looked at him questioningly.

<!-- image -->

'They're trying to marry off Razia, Zoob,' Rafik explained, 'to a decent boy from a good family, khaandaan and all.'

'Rafik!' shouted Rafik's mother, 'really!'

Zubayr looked at Razia. She said nothing and did nothing. The brède that had spilled out of the pot was still on the floor. He then looked at each family member in turn.

'That's a problem, Auntie,' said Zubayr, 'a big problem.'

'Why?' wondered Rafik aloud, before his mother could react.

'Well, because I'm, well... interested,' he replied.

'You're what?' Razia said, her voice shrill.

'I'm interested, well, ...in marrying you.' Zubayr was in absolute earnest.

'But you never told me. You haven't even written to me in six years.'

'Five years -'

'Five years, then,' interrupted Razia.

'Five years, three months, and three days,' continued Zubayr.

Notes Khaandaan: lineage

Qawwali: devotional song.

<!-- image -->

## Two young women meet for the first time

Extract from The Importance of Being Earnest by Oscar Wilde (An Adapted version)

List of characters Merriman: The butler Miss Fairfax: A lady Gwendolen: A lady

[Enter Merriman .] Merriman .  Miss Fairfax. [Enter Gwendolen .] [Exit Merriman .]

Cecily. [Advancing to meet her.] Pray let me introduce myself to you. My name is Cecily Cardew.

Gwendolen. Cecily  Cardew?    [Moving  to  her  and  shaking  hands.] What  a  very  sweet name!  Something tells me that we are going to be great friends.  I like you already more than I can say.  My first impressions of people are never wrong.

Cecily. How  nice  of  you  to  like  me  so  much  after  we  have  known  each  other  such  a comparatively short time. Pray sit down.

Gwendolen. [Still standing up.] I may call you Cecily, may I not?

Cecily. With pleasure!

Gwendolen. And you will always call me Gwendolen, won't you?

Cecily. If you wish.

Gwendolen. Then that is all quite settled, is it not?

Cecily. I hope so.  [A pause.  They both sit down together.]

Gwendolen. Perhaps this might be a favourable opportunity for my mentioning who I am. My father is Lord Bracknell. You have never heard of papa, I suppose? Cecily. I don't think so.

Gwendolen. Outside  the  family  circle,  papa,  I  am  glad  to  say,  is  entirely  unknown. Cecily, mamma, whose views on education are remarkably strict, has brought me up to be extremely short-sighted; it is part of her system; so do you mind my looking at you through my glasses?

Cecily. Oh! not at all, Gwendolen.  I am very fond of being looked at.

Gwendolen. [After examining Cecily carefully through a lorgnette .]   You are here on a short visit, I suppose.

Cecily. Oh no!  I live here.

Gwendolen. [Severely.]  Really?    Your  mother,  no  doubt,  or  some  female  relative  of advanced years, resides here also?

Cecily. Oh no! I have no mother, nor, in fact, any relations.

Gwendolen. Indeed?

Cecily. My  dear  guardian,  with  the  assistance  of  Miss  Prism,  has  the arduous task  of looking after me.

Gwendolen. Your guardian?

Cecily. Yes, I am Mr. Worthing's ward.

Gwendolen. Oh!  It  is  strange  he  never  mentioned  to  me  that  he  had  a  ward.  How secretive of him!  He grows more interesting hourly. [Rising and going to her.] I am very

<!-- image -->

fond of you, Cecily; I have liked you ever since I met you!  But now that I know that you are Mr. Worthing's ward, I wish you were-well, just a little older than you seem to beand not quite so very alluring in appearance.  In fact, if I may speak candidly -Cecily. Pray do! I think that whenever one has anything unpleasant to say, one should always be quite candid.

Gwendolen. Well, to speak with perfect sincerity, Cecily, I wish that you were fully fortytwo, and more than usually plain for your age.  Ernest has a strong upright nature. He is the very soul of truth and honour. He would never dream of being disloyal.  But even men of the noblest possible moral character can be influenced by the physical charms of others.

Cecily. I beg your pardon, Gwendolen, did you say Ernest?

Gwendolen. Yes.

Cecily. Oh, but it is not Mr. Ernest Worthing who is my guardian. It is his brother-his elder brother.

Gwendolen. [Sitting down again.]  Ernest never mentioned to me that he had a brother.

Cecily. I am sorry to say they have not been on good terms for a long time.

Gwendolen. Ah!  that  accounts  for  it.  Cecily,  you  have  lifted  a  load  from  my  mind.  I was growing almost anxious. It would have been terrible if anything came to spoil our friendship, don't you think? Of course you are quite, quite sure that it is not Mr. Ernest Worthing who is your guardian?

Cecily. Quite sure.  [A pause.]  In fact, I am going to be his.

Gwendolen. [Inquiringly.]  I beg your pardon?

Cecily. [Rather shy and confidingly.]  Dearest Gwendolen, there is no reason why I should make a secret of it to you. It will be published in our local newspaper soon. Mr. Ernest Worthing and I are engaged to be married.

Gwendolen. [Quite politely, rising.]  My darling Cecily, I think there must be some slight error.  Mr.  Ernest  Worthing  is  engaged  to  me.  The  announcement  will  appear  in  the Morning Post on Saturday at the latest.

<!-- image -->

Cecily. [Very politely, rising.] I am afraid you must be under some misconception.  Ernest proposed to me exactly ten minutes ago.  [Shows diary.]

Gwendolen. [Examines diary through her lorgnettte carefully.]  It is certainly very curious, for he asked me to be his wife yesterday afternoon at 5.30.  If you would care to verify the incident, pray do so. [Produces diary of her own.] I never travel without my diary. One should always have something sensational to read in the train.  I am so sorry, dear Cecily, if this comes as a disappointment to you, but I am afraid I have the prior claim.

Cecily. It  would  distress  me  greatly,  dear  Gwendolen,  if  it  caused  you  any  mental  or physical anguish ,  but  I  feel  bound  to  point  out  that  since  Ernest  proposed  to  you,  he clearly has changed his mind.

Gwendolen. [Meditatively.] If the poor fellow has been trapped by a foolish promise, it is my duty to rescue him at once.

Cecily. [Thoughtfully and sadly.]  Whatever unfortunate mess my dear boy may have got into, I will never reproach him with it after we are married.

Gwendolen. Are  you  calling  me  a  mess,  Miss  Cardew?  On  an  occasion  of  this  kind  it becomes more than a moral duty to speak one's mind.  It becomes a pleasure.

Cecily. How dare you suggest that I trapped Ernest into proposing to me?  This is no time for wearing the shallow mask of manners.  When I see a spade I call it a spade.

Gwendolen. [Satirically.]  I am glad to say that I have never seen a spade.  It is obvious that our social spheres have been widely different.

[Enter Merriman ,  followed  by  the  footman.  He  carries  a salver ,  table  cloth,  and  plate stand. Cecily is  about  to  retort.  The  presence  of  the  servants  exercises  a  restraining influence, under which both girls chafe .]

Merriman. Shall I lay tea here as usual, Miss?

Cecily. [Sternly, in a calm voice.]  Yes, as usual. [ Merriman begins to clear table and lay cloth. A long pause. Cecily and Gwendolen glare at each other.]

Cecily. May I offer you some tea, Miss Fairfax?

Gwendolen. [With  elaborate  politeness.]   Thank  you.    [Aside.]    Detestable  girl!    But  I require tea!

Cecily. [Sweetly.] Sugar?

Gwendolen. [Arrogantly.]    No,  thank  you.    Sugar  is  not  fashionable  any  more.  [ Cecily looks angrily at her, takes up the tongs and puts four lumps of sugar into the cup.]

Cecily. [Severely.]  Cake or bread and butter?

Gwendolen. [In a bored manner.]  Bread and butter, please. Cake is rarely seen at the best houses nowadays.

Cecily. [Cuts a very large slice of cake, and puts it on the tray.]  Hand that to Miss Fairfax.

[ Merriman does so, and goes out with footman. Gwendolen drinks the tea and makes a grimace. Puts down cup at once, reaches out her hand to the bread and butter, looks at it, and finds it is cake.  Rises in indignation.]

Gwendolen. You have filled my tea with lumps of sugar, and though I asked most clearly for bread and butter, you have given me cake. I am known for my gentle character and sweet nature, but I think you are going too far.

Cecily. [Rising.] I will do anything to save my poor, innocent, trusting boy from another girl's tricks

Gwendolen. From the moment I saw you I distrusted you. I felt that you were false and deceitful. I am never deceived in such matters. My first impressions of people are always right.

In the center of the image there is a white box. Inside the white box there is text. On the left side of the image there is a pink color box. On the right side of the image there is a black color box.

<!-- image -->

## Glossary

Alliteration: words that come after one another in a phrase or sentence and that start with the same sound.

Example: 'Betty bought a bit of butter to make the batter but the butter was bitter, so she bought better butter.'

Appreciation: Being able to understand and recognise the beauty and value of a piece of writing.

Atmosphere/Mood: the feelings created by specific descriptions.

Example: 'It was a stormy night, with angry clouds shrouding the moon' .

Beat: a regular sound or pattern in a line or sentence to create a musical effect. Example: 'Faster than fairies, faster than witches, Bridges and houses, edges and ditches.'

Character: a person or object whose story is being told or who appears in a story.

Character trait: A quality or aspect of personality; often described using an adjective. Example: 'jealous' , 'ambitious' , 'generous' , 'helpful' , 'considerate'

Characterisation: the way a character is shown in a text.

Characterisation can happen through:

- The way the person looks. Example: 'Drako was always dressed in black.'
- The way the person acts. Example: 'Drako only stepped out of his mansion at night.'
- The way the person speaks. Example: 'I need something to drink,' Drako hoarsely whispered to himself.
- The way the person thinks. Example: 'Drako wondered how it would feel to have other people living in his mansion.'
- What others say or think about that character. Example: 'The villagers called it the cursed mansion, and warned their children not to approach Drako.'

Form: how a text is organised in terms of layout, shape and structure

Imagery: the mental images created through descriptive words Example: 'the lush green mountains dotted with tiny flowers'

Informed personal response: To  be  able  to  explain  why  you  like  or  dislike  a  piece  of writing, using short direct quotes to support your answer.

Metaphor: a direct comparison of two things, without using 'like' and 'as' . Example: 'Westley was a lion on the battlefield.'

Motive: The reason that drives a character to think, behave and speak in a particular way; often understood by looking at what he does, says and what others think/say about him.

Narrator: The voice which is telling you the story.

Some stories are told by a first-person narrator ('I shuddered when I noticed a silhouette behind the curtain.') and some are told by a third-person narrator ('He shuddered when he noticed a silhouette behind the curtain.')

Onomatopoeia: a word that represents a sound.

Example: 'crash' , 'buzz' , 'rumble' , 'bang'

Personification: Giving human qualities to objects and animals.

Example: 'the dancing flame'; 'the battery died'

Plot: the sequence of events happening in a story.

Event 1: The jealous queen gives Snow White a poisoned apple.

Event 2: Snow White eats the apple and falls in a deep sleep.

Event 3: The Prince brings Snow White back to life.

Rhyming couplets: Two consecutive lines that contain the same sound at the end.

Example:

'I can't go away,

I am here to stay'

Setting: place and time in which a story is set.

'It was the year 2157. Mahebourg was now a sprawling floating city.'

Simile: a comparison between two things, using words such as 'like' and 'as' .

Example: 'as beautiful as a rose'

Stage directions: Information given in the play by the playwright.

It can include:

- Instructions to actors ('Enter the Witches with brooms')
- Description of setting and props
- Use of sound and lighting effects ('Thunder and lightning')

Stanza: a group of line in a poem, forming a unit.

Example:

I wandered lonely as a cloud

That floats on high o'er vales and hills,

When all at once I saw a crowd,

A host, of golden daffodils;

Beside the lake, beneath the trees, Fluttering and dancing in the breeze.

Continuous as the stars that shine And twinkle on the milky way, They stretched in never-ending line Along the margin of a bay: Ten thousand saw I at a glance, Tossing their heads in sprightly dance.

(from Daffodils , by William Wordsworth)

Structure: the arrangement of the different parts of a text.

Symbolism: Using a person, animal, object or event to represent an idea.

Example: a flying bird can be a symbol of freedom.

Theme: Main idea in a piece of text.

Tone: is the author's attitude or viewpoint toward a subject, theme or an audience, and is  shown in literature through his or her choice of words. We can describe the tone as being formal, informal, humorous, sad, serious, ironic, melancholic, angry, and so on.

Verse: A single line of poetry.