In this image we can see a poster with some text and images.

<!-- image -->

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the

Ministry of Education, Tertiary Education,

Science and Technology.

<!-- image -->

In this image we can see a yellow color background with some text and a blue and green color.

<!-- image -->

## MAHATMA GANDHI INSTITUTE

<!-- image -->

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology. Republic of Mauritius 202 1

<!-- image -->

## Mahatma Gandhi Institute (2019)

All  rights  reserved.No part of this publication may be reproduced, stored in a retrieval system,  or  transmitted  in  any  form  or  by  any  means,  electronic,  mechanical,  photo copying, recording or otherwise, without the prior permission of the Copyright owner.

## Printed by:

T-Printers Co. LTD Industrial Zone, Coromandel. Tel: (230) 233 2500

First published 2020 Reprinted 2021

While every effort  has  been  made to trace the copyright holders for reproductions, we might have not succeeded in some cases.  We offer our sincere apologies and hope that they will take our liberty in good faith.  We would appreciate any information that would enable us to acknowledge the copyright holders in our future editions.All materials should be used strictly for educational purposes.

ISBN: 978-99949-54-33-9

<!-- image -->

## Performing Arts (Indian Music and Dance) Panel

Grade 7 Senior Lecturer (Bharata Natyam), Head, Department of Decentralisation of Music &amp; Dance, Distance Education &amp; E-Learning, MGI

Mr. K. Mantadin

## - Project Coordinator

(organisation and development),

Senior Lecturer (Tabla), Head, Department of Curriculum Development,

MGI

Ms. S. Dabee

- Panel Coordinator

Mrs.A.D.Dwarka- Bania

## Photography

Dr. D.Pentiah - Appadoo

## Contributors

Mrs.P.D Luchmun

Mrs.S.Jootun

## Vetter

Ms. N.Totiah

-    Lecturer (Kuchipudi)- MGI

## Proof Reading

- Mrs D.Balaghee                   -  Deputy Rector - MGISS

Mrs S.Bundhoo                     -    Educator          - MGISS

## Graphic Designers - MGI

(cover, illustration and layout)

Ms. V.Jatooa

Ms. P.Juckhory

Mr. V.Napaul

## Word Processing Operator

-Music Organiser - M.O.E,T.E, Sc &amp; Tech.

-  Educator  (Bharata Natyam) - Tech. M.O.E,T.E, Sc &amp;

- -Educator (Bharata Natyam) - MGI

- -Educator (Kathak) - M.O.E,T.E, Sc &amp; Tech.

## Team Leader

## Writing Team               Kuchipudi

Mr G.Moonesawmy

Mr T.K.Mantadin

## Cartoonist

- Pro Foto Plus

- School of Fine Arts( student of MGI)

M.O.E,T.E, Sc &amp; Mrs. K.Mahadoo Coonlic  -Educator (Bharata Natyam) - Tech.

Mrs. N. Mugon

<!-- image -->

Mrs S. N Gayan, GOSK, Director General, Mahatma Gandhi Institute and Rabindranath Tagore Institute, for her continued advocacy for music education especially Indian Music and Dance.

Dr (Mrs) V Koonjal, Director, Mahatma Gandhi Institute, for her unwavering support to this project.

## The Performing Arts (Indian Music and Dance) panel is also grateful to the following persons:

Dr. Mrs. S.D. Ramful

- Ag. Director Schooling - MGI
- Mrs.U.Kowlesser                         Registrar (MGI) -
- Dr. D. Ramkalawon                  Senior Lecturer (Sitar), Head School of Performing Arts, MGI -

Dr. D.Pentiah - Appadoo

- Music Organiser (Oriental) M.O.E, T.E, Sc &amp; Tech. -

## Quality Vetting Team

- Dr J.Chemen                            Assoc. Prof. Head, Centre for Quality Assurance, MGI (Coordinator) -

Dr (Ms)S.D.Ramdoo

- Lecturer (Bharata Natyam) - MGI -
- Ms. T.Gopaloodoo Art Officer, Ministry of Arts &amp; Culture (Representative from M.O.E, T.E, Sc &amp; Tech.) -
- Communication - MGI Ms. N.Lallmamode                   Lecturer, Head Department of Design and -
- Mrs. D.R.Maloo                         Educator(English)-MGSS -

## Administrative Staff

- Mrs.H.Chudoory                       Administrative Officer - MGI -

Mrs.G.G.Cheekhooree Mrs.P.Appadoo

- Ms. V.Cahoolessur                   Office Supervisor - MGI -

- Clerical Officer / Higher Clerical Officer - MGI -

- Clerical Officer / Higher Clerical Officer - MGI -

Mrs.P.Purmessur

- Word Processing Operator - MGI -

## Photo Courtesy

Mr. &amp; Mrs. M. Kishore Ms. P.Kashi Ms. S.Appadu Ms. Y.K.Hazareesing Mr. M.Javhalee Mrs. P. Mahadea Ms. M.Runglall Ms. P. Auree

- The parents and their wards for giving us the permission to reproduce their photographs and images in the textbook.

<!-- image -->

'Where the mind is allowed to stumble upon cascades of emotion and where the surprise of creative exchange comes out of tireless striving towards perfection.'

## Rabindranath Tagore

? Should music, dance, arts, drama be taught in schools? Do such subjects matter decision, in the context of the reforms leading to the Nine Year Continuous Basic Education, to include teaching of the performing arts in the secondary school curriculum shows that 'the ayes have it.' At least for the time being. As in the case of all debate, there are those who are for and those who are against. The

Traditionally, music teaching takes place in a one-to-one mode. The piano teacher teaches one student at a time, so does the sitar guru. Dance is more of a group experience. But for each of these disciplines, the context of institutional level teaching introduces opportunities of reaching a broader cross-section of population, thereby giving rise to fresh challenges. Students come from a variety of social and cultural environments which expose them to different types, genres and registers in the arts. Students also come with different levels of aptitude. These are but two of challenges encountered.

From another perspective, it has been repeatedly pointed out that the 'digital natives', while  definitely  coming  to  learning  with  resources  hitherto  not  available,  may,  in  the process, be losing their ability to grasp, decipher and understand emotional language. In short they may be losing empathy.

The ultimate aim of arts education in the curriculum is to provide a pedagogical space where the young will be able to explore their own affective responses to forms of artistic expression, to develop sensibility, while acquiring a whole set of skills, including not only spa tial  awareness,  pattern  recognition  or  movement  coordination,  but  also  the  benefits  of group and team work, of joint effort, higher level creative thinking and expression, as well as an overall sense of shared pleasure and of achievement. This is what emotional intelligence is all about.

The specialists who prepared the syllabus and the present textbooks for Indian music and dance had all the above in mind while undertaking the task. The teacher training for these disciplines needs to be a continuous process of exchange between curriculum developers, teaching practitioners, textbook-writers and learners.

The MGI is particularly happy to be part of this major development, at a time when the country is looking at new avenues for continued economic development, and more importantly at new avenues to enhance equity, social justice and inclusion. It is our small contribution to the 'grande aventure' of holistic education.

Mrs Sooryakanti Nirsimloo-Gayan, GOSK Director-General (MGI &amp; RTI)

<!-- image -->

This textbook is the first instructional material in the field of Performing Arts (Indian Music  and  Dance)  written  by  a  team  of  experienced  Mauritian  teachers  and experts in Vocal Music, Instrumental Music and Dance.

It  has  been  designed  on  the  Aims,  Objectives  and  the  Teaching  and  Learning Syllabus  of  the  Performing  Arts  from  the  National  Curriculum  Framework  (2016), under the Nine Year Continuous Basic Education Programme.

The Performing Arts Curriculum is articulated around four strands: Performing, Creating, Responding and Performing Arts and Society. Thus, the textbook takes into  account  the  development  of  key  skills  and  understandings  under  the  four strands.

This  set  of  textbooks  for  grade  7,  8  and  grade  9  lays  the  foundation  in  each discipline and provides learners with the essential knowledge, skills and attitudes needed  to  progress  towards  higher  grades.  It  also  takes  into  consideration  the multicultural nature of our society and its traditions.

This  textbook  is  a  support  material  that  gives  direction  to  the  educators  in  the teaching  and  learning  process  by  linking  the  curricular  components,  curricular expectations, pedagogical principles and assessments.

A textbook is not an end in itself like any other instructional material.It is a means to facilitate learning to take place in a continuous and continual manner.

Learning  objectives  in  each  chapter  of  the  textbook  reflect  the  curricular outcomes.  It will help the teacher to design his/her lesson plans which will further ease the teaching and learning transaction towards achievement.  Teachers will have to plan their work so that learning takes place in an effective and efficient way.  They will have to provide appropriate and enriched experiences and modify the teaching and learning strategies according to the needs of learners.

The practical aspects of the discipline have been integrated under 'practical' with step-by-step technique laying emphasis on the mastery of skills from one level to another.

We  are  aware  that  children  construct  knowledge  in  their  own  way  and  have different learning styles.The textbook has been designed to cater for such needs.

<!-- image -->

Special features and a generous number of illustrations, pictures, concept maps and activities have been included to promote collaborative learning and other additional skills like team spirit, cooperation and understanding diverse nature of learners.These would help teachers to organise their interactions at classroom level. Teachers may give more activities, depending upon the availability of resources and time.

Assessments in the form of activities, projects and questions are also included at the end of  each  chapter.    These  are  check  points  to  assess  the  learners.    It  will  help teachers gather evidences about the expected level of learning taking place in the learners.

I  would  also  request  all  the  Educators  to  go  through  the  National  Curriculum Framework (2016), the Teaching and Learning Syllabus of the Performing Arts (Indian Music  and  Dance)  documents  and  especially  the  'Important  Note  to  Educators' which has been provided in the textbook to have a thorough understanding of the Philosophy and Perspective behind those documents and their implications in the implementation of the Reform process in the education system.

I hope that this new journey of learning Indian Music and Dance will be an enriching one.

Project Co-ordinator - Performing Arts (Indian Music and Dance),

Mr. K. Mantadin, Senior Lecturer (Tabla), Head Department of Curriculum Development, Mahatma Gandhi Institute.

<!-- image -->

## IMPORTANT NOTE TO EDUCATORS:

This teaching and learning syllabus of Indian Music and Dance has been designed on the spiral curriculum model in which core components and essential topics are revisited within the three years.  It caters for both the theoretical and practical aspects of each discipline.

It also comprises different blocks of knowledge and skills and each block is supported by specific  learning  outcomes  which  cover  all  the  three  domains  of  learning;  cognitive, psychomotor and affective.

The Listening and Viewing component has been integrated in the syllabus as it is a key factor in the development of music and dance abilities.  Teachers should provide a wide variety of listening and viewing experiences for learners to stimulate active listening and viewing through questioning, prompting and suggestion.

In order to achieve the objectives of the syllabus and to keep a good balance between theory and practical sessions, the teacher will have to plan his / her work and teaching and learning activities according to the topics to be taught as specified in the scheme of studies.  However, educators may modify the sequence of the topics in which they wish to teach for the smooth running of the course.

## Educators should:

1. Ensure that learners use the knowledge, skills and understanding developed from grades 1 -6 and build upon that prior knowledge to construct new knowledge.
2. Provide learning experiences that include opportunities for hands-on and interactive learning, self-expression and reflection.
3. Find a variety of ways to align their instruction with the Aims, Learning Outcomes and Specific Learning Outcomes by focusing on active learning and critical thinking.
4. Provide learning activities that are appropriate in complexity and pacing.
5. Provide opportunities for individual and multiple groupings.
6. Actively engage and motivate students in the process of Learning Music and Dance.
7. Develop the ability in the learners to use and understand the language of Music and Dance through listening and viewing as well as responding to live and recorded repertoires.
8. Enrich the musical experience of the students by gaining an understanding of the cultural and historical context of music and dance exploring personal connections with them.
9. Technologies(ILT's).  This will facilitate developing their investigative and methodological abilities. 9.Carry out active listening and viewing sessions through the use of Information Learning
10. Model and demonstrate accurate and artistic musical and dance techniques.
11. Differentiate Music and Dance instruction to meet a wide range of students needs.
12. Educators should also ensure that learners:
-  Show proper care and maintenance of classroom instruments.
-  Demonstrate respectful behaviour as performers and listeners.
-  Participate in classroom protocole and traditions for music making and dance.
13. Reinforce effort and provide recognition.
14. Discuss student performances by using peer assessment as a tool.
15. Give opportunities to students to assume various roles in music performances, presentations and collaborations.
16. Motivate students to maintain a musical collection and portfolio of their own work over a period of time.  It can be an individual or group initiative that the learner will undertake under the supervision of the educator.

<!-- image -->

<!-- image -->

In this image, we can see some text and images.

<!-- image -->

| Saraswati Varade Kaama Vidyaarambham Siddhir Bhavatu Mey Sadaa || Karishyaami Roopini | Namastubhyam   | 1 INVOCATION                               |
|--------------------------------------------------------------------------------------------------------|--------------------------------------------|
|                                                                                                        | 7 BODYCONDITIONING EXERCISES FOR DANCE     |
|                                                                                                        | 21 INDIANCLASSICALMUSICANDDANCEINMAURITIUS |
|                                                                                                        | 29 HEAD,EYESANDNECKMOVEMENTS               |
|                                                                                                        | 39 BASICSERIESOFADAVUS                     |
|                                                                                                        | 67 INDIANCLASSICALDANCETERMINOLOGIES       |
|                                                                                                        | 77 DANCESTORIESOFINDIANGODS                |
|                                                                                                        | 95 HISTORICALDEVELOPMENTOFKUCHIPUDI        |

In this image I can see the text and pictures.

<!-- image -->

The image is a colorful and intricate design, likely from a religious or cultural context. The background is a vivid yellow, which contrasts sharply with the vibrant colors of the design. The central focus is a large, intricate, and detailed design that appears to be a religious or cultural symbol.

The central figure in the design is a person with a long, flowing hair and a crown. The crown is adorned with intricate patterns and designs, which are likely symbolic of the person's status or role in the religious or cultural context. The person is holding a musical instrument, which is a traditional instrument in many cultures, and is playing it.

The background of the design is a swirling pattern of colors, including shades of yellow, red, green, and blue. This pattern is reminiscent of traditional Indian designs, which often feature floral and leaf motifs. The colors are vibrant and add to the overall aesthetic of the design.

The text at the top of the image reads "Invocation,"

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

Memorise the Sanskrit shlokas.

<!-- image -->

Recite and write the Sanskrit shlokas.

<!-- image -->

Translate the Sanskrit shlokas in English.

<!-- image -->

Goddess Saraswati is known as the Goddess of knowledge, music, art and wisdom.

In this image we can see a person holding a guitar and playing it. There are bubbles in the image.

<!-- image -->

## SHLOKA ON GODDESS SARASWATI:

In this image, we can see a blue color frame. Inside the frame, we can see some text.

<!-- image -->

## Meaning of the above shloka:

Oh Goddess Saraswati, I offer my salutations to you You are the giver of boons and the fulfiller of wishes Oh Devi, as I begin my studies, May there be accomplishments always.

<!-- image -->

Lord Shiva is the third God of the Hindu Trinity and is the God of destruction.

In this image we can see a person standing and holding a candle.

<!-- image -->

SHLOKA ON LORD SHIVA:

In this image we can see a blue color frame. Inside the frame there is a text.

<!-- image -->

Lord Shiva who is also known as shekaraya is worshipped by sages like Vashistha, Kumbodbhava, Gautama, other Gods and sages.His eyes are like the moon, sun and fire. I offer my salutations to Lord Shiva who is the embodiment of the letter 'va'.

<!-- image -->

POINTS TO REMEMBER

- Goddess Saraswati is known as the Goddess of knowledge, music, art and wisdom.
- Lord Shiva is the third God of the Hindu Trinity and is the God of destruction.

In this image we can see a yellow color box. In the box there is some text.

<!-- image -->

<!-- image -->

## ASSESSMENT

1. Fill in the blanks with the appropriate words.

Saraswati ………………………..

………………… Kaama Roopini

Vidyaarambham …………………

Siddhir ……………………….. Mey Sadaa

2.  Write down the shloka in praise of Lord Shiva and explain its meaning.

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

<!-- image -->

NOTES

<!-- image -->

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

Demonstrate an understanding of warm-up, pre-dance and cool-down exercises for safe and effective dance practice.

- Condition the body through warm-up, pre-dance and cool-down exercises for safe and effective practice.

Execute the warm-up, pre-dance and cool-down exercises with accuracy.

Practise the exercises to develop flexibility, agility and endurance.

- Adhere to the practice of warm-up, pre-dance and cool-down exercises for safe and effective practice.

## BODY CONDITIONING EXERCISES FOR DANCE

Body conditioning consists of warm-up, pre-dance and cool-down exercises. Body conditioning exercises are important for the safe and effective practice of dance.A good body conditioning routine will increase the endurance, agility, flexibility and self- confidence of the dancer.

## WARM-UP EXERCISES

## LEG EXERCISES

In this image we can see a woman standing and doing a pose.

<!-- image -->

<!-- image -->

## LATERAL LEG SWINGS

<!-- image -->

Stand straight and hold onto a wall.

Shift one's weight to the right leg and swing the left leg to the left and then across the body to the right.

Repeat the movement with the right leg several times.

<!-- image -->

## THIGH EXERCISES

In this image we can see a woman standing and doing a pose.

<!-- image -->

## SQUAT SIDE KICK

<!-- image -->

Start in a squat position with the hips back and the feet apart.

As one stands up, switch the weight to the right leg and lift the left leg out to the side.

<!-- image -->

Return to the squat position and repeat the movement with the right leg.

<!-- image -->

## ABDOMINAL EXERCISES

In this image we can see a woman standing and doing a pose.

<!-- image -->

## BASKETBALL SHOTS

<!-- image -->

Stand with the feet apart and the toes pointing slightly outward.

Bend the knees, press your hips back and bring both hands close to the right foot.

<!-- image -->

Jump upwards.Lift the arms above the head and move them to the left.

Land with the knees slightly bent and go back to the squat position.

Repeat the exercise on each side.

<!-- image -->

<!-- image -->

## CALF EXERCISES

In this image we can see a woman standing and doing a pose.

<!-- image -->

<!-- image -->

<!-- image -->

Jump with both feet  pointing to the right and then to the left in a quick repetitive movement.

Repeat this exercise 5 to 10 times.

## INNER THIGH EXERCISES

In this image we can see a woman standing and posing for a photo.

<!-- image -->

<!-- image -->

<!-- image -->

Start in a sumo squat position with the feet in a wide stance, the toes pointing out to the sides and the thighs parallel to the floor.

<!-- image -->

Raise the heels off the floor and stiffen the calves.

Lower the heels and return to the starting position.

Repeat this exercise several times.

## BACK EXERCISES

In this image we can see a woman wearing a blue and pink color dress.

<!-- image -->

## SUPERMAN TWIST

<!-- image -->

Lie on the stomach with the legs fully extended, arms bent and hands behind the ears.

<!-- image -->

Lift and twist the upper torso to one side and pause for 2 seconds.

Return to the starting position and repeat while twisting the torso to the opposite side.

<!-- image -->

## PRE-DANCE EXERCISES

After the body is warm, dancers can execute certain movements within their routine during the dance class.

## TRIANGULAR POSE

In this image we can see a woman standing and doing a yoga pose.

<!-- image -->

Stand with the feet wide apart and the arms extended on the sides.

Bring the right hand to the floor on the inside or outside the right foot and extend left arm towards the ceiling.

<!-- image -->

Hold the pose for 30seconds and then repeat on the left side.

<!-- image -->

## HAMSTRING STRETCH 1ST EXERCISE

In this image we can see a woman standing and wearing a blue and pink color dress.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Start in the Vaishnava sthanaka posture.

Bend the right knee and stretch the left leg at the back on the toe.

Press the knees with both hands and hold the posture for 30 seconds.

<!-- image -->

Repeat the same movements on the opposite side.

## 2ND EXERCISE

In this image we can see a woman standing and doing a pose.

<!-- image -->

<!-- image -->

Start in the Vaishnava sthanaka posture.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Stamp the right foot and sit down completely with the right leg while stretching the left leg with the foot placed on the heel.

- For the left side, raise the body in half sitting posture and shift the body weight on the left leg.

Sit down completely while stretching the right leg with the foot placed on the heel.

Hold the movement for 30 seconds.

Repeat the same movement on the opposite side.

<!-- image -->

## CALF STRETCH

In this image we can see a woman standing and wearing a blue color dress.

<!-- image -->

Start in the Vaishnava sthanaka posture.

Lift the right foot and press on the toes.

Keep the position for 30 seconds.

Repeat the movements 5 to 10 times on each side.

<!-- image -->

<!-- image -->

## COOL DOWN EXERCISES CHEST STRETCH

<!-- image -->

With the side of the body facing a wall, place the left palm on the wall.

<!-- image -->

Slowly rotate the torso to the right until you feel the stretch in the chest and in the left shoulder. Hold for 15 to 20 seconds and repeat on the right side.

In this image we can see a girl standing and she is wearing a blue jacket and pink pant.

<!-- image -->

## GLUTE STRETCH

In this image we can see a woman is doing yoga.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Lie flat on the back and bend both knees.

Cross the right leg over the left and bring both knees towards the chest.

Gently pull the left leg until one can feel a stretch in the glute.

<!-- image -->

Hold the stretch for 30 seconds and repeat with the other leg.

## EASY POSE

In this image we can see a woman sitting on the chair and holding a ring in her hand.

<!-- image -->

<!-- image -->

Sit on the floor and cross the legs by placing each foot under the opposite knee and lengthen the spine.

<!-- image -->

Concentrate on one's breathing and stay in this relaxing posture.

<!-- image -->

<!-- image -->

<!-- image -->

## KEEP A YOUTHFUL GLOW THROUGH DANCING

Dancing increases the blood flow to the body carrying more oxygen and nutrients to the skin cells.This promotes skin cell renewal process and keeps the skin looking young.

Dancing makes one sweat.Sweat helps to unlock oils and dirt trapped in the skin.The skin becomes clearer inside and outside, and one can better handle acne problems.

<!-- image -->

POINTS TO REMEMBER

1.  Warm-up before any dance activity is important in order to prepare the body for longer and safe training.
2.  A warm-up gradually increases the body temperature to an optimal working level and helps to avoid injuries.
3.  Pre-dance exercises are intended to warm-up the core muscles that are to be used during the dance class.
4.  Cool-down exercises are important after dancing as they help to reduce muscle soreness.
5.  Cool-down exercises speed up the recovery process after intense activity.

## YOUTUBE LINK:

<!-- image -->

https://www.youtube.com/watch?v=jmdusPNrjgQ&amp;t=1350s

## KEYWORDS

Warm-up exercise, Pre-dance, Cool-down, Safe practice.

<!-- image -->

## ASSESSMENT

1. Name any two warm-up exercises.

..........................................................................................................................

..........................................................................................................................

2.  Describe any pre-dance exercise.

..........................................................................................................................

..........................................................................................................................

..........................................................................................................................

..........................................................................................................................

3.  Describe the Glute stretch.

..........................................................................................................................

..........................................................................................................................

..........................................................................................................................

..........................................................................................................................

4.  Explain the importance of body conditioning.

..........................................................................................................................

..........................................................................................................................

..........................................................................................................................

..........................................................................................................................

<!-- image -->

In this image we can see a poster with some designs and text.

<!-- image -->

## LEARNING OBJECTIVES

## At the end of this chapter, learners should be able to:

<!-- image -->

Identify the Indian classical dances practised in Mauritius.

<!-- image -->

<!-- image -->

<!-- image -->

Describe how the Indian classical dances were introduced in Mauritius.

Describe the propagation of Indian classical dances in Mauritius.

Develop gratitude and respect towards the pioneers of Indian classical music and dance in Mauritius.

## INDIAN CLASSICAL DANCE FORMS IN MAURITIUS

In Mauritius, only three Indian classical dance forms are practised. The three classical dance forms are Bharata Natyam , Kathak and Kuchipudi .

In this image we can see a poster. On the poster we can see a woman dancing.

<!-- image -->

Ancestors who came from India had their roots from the South, South-East, South-West and the Northern regions of India. As Bharata Natyam originated from Tamil Nadu, Kuchipudi from Andhra Pradesh and Kathak from the North regions, these classical dance forms had an influence on the people of Mauritius and got established in the island.

In this image, we can see a map. There are some text on the map.

<!-- image -->

In this image I can see the paper. On the paper I can see the text. In the top right I can see the logo.

<!-- image -->

<!-- image -->

## HOW THE INDIAN CLASSICAL DANCES WERE INTRODUCED IN MAURITIUS?

India became Independent in 1947, and the diplomatic relations were established between India and Mauritius. The Indian Embassy was set up in Mauritius in 1948. Since then, various Indian classical music and dance experts visited Mauritius for performances, concerts and awareness programmes.

The image is a digital poster with a blue background. The poster is divided into two main sections. The top section contains the text "DID YOU KNOW" in white font, with the words "Before the setting up of the Indian Embassy in Mauritius, Indian labourers were only adept in folk music and dance." This text is in a larger font size compared to the bottom section which contains the text "Before the setting up of the Indian Embassy in Mauritius, Indian labourers were only adept in folk music and dance." The text is in white font and is in a larger size compared to the bottom section.

The bottom section of the poster contains a blue background with white text. The text reads:

"Before the setting up of the Indian Embassy in Mauritius, Indian labourers were only adept in folk music and dance."

This text is in a smaller font size compared to the top section.

### Analysis and Description:

The image is a digital poster with

<!-- image -->

In  1962, Pandit Ram  Gopal  and  his  troupe  left  a  remarkable  impact  on  the people of Mauritius. They presented dance performances in Bharata Natyam , Kathakali and Kathak which  led  to  an  increase  of  interest  for  learning  the classical dance forms in the country.

As there was a significant growth in the interest of Mauritians about Indian music and dance, Sir Veerasamy Ringadoo, the then Minister of Education set up the School of Indian Music and Dance at Beau-Bassin in 1964. The school was established with the collaboration of the Indian High Commission and the British government as Mauritius was still a British colony. It was inaugurated by Lady Rennnie, wife of the then Governor, Sir John Shaw Rennie, on 11 th  April 1964.

The Indian Government sent Mr. and Mrs. Nandkishore to Mauritius to teach Indian  music  and  dance.  They  were  experts  in  Indian  classical  music and  dance  and  taught  the  following  disciplines:  Vocal Hindustani music, Sitar,  Harmonium,  Tabla,  Bharata  Natyam,  Kathak,  Kathakali,  Manipuri and folk dances.

There  was  such  a  growing  demand  amongst  the  Mauritian  people  to  learn Indian  classical  music  and  dance,  that  a  larger  complex  was  required  to accomodate  the  students.  Thus,  the  School  of  Indian  Music  and  Dance integrated the Mahatma Gandhi Institute with the mission to promote education and Indian culture including Indian music and dance. As a matter of fact, the foundation stone of the Mahatma Gandhi Institute at Moka was laid on the 3rd June 1970 and the Mahatma Gandhi Institute was inaugurated in 1975 by late Shrimati Indira Gandhi, the then Prime Minister of India.

<!-- image -->

## PIONEERS OF INDIAN CLASSICAL MUSIC AND DANCE IN MAURITIUS

The  High  Commission  of  India  annually  granted  scholarships  to  Mauritian students to study Indian classical music and dance in India. In 1950, the first Mauritian,  Mr  Ishwarduth  Nundlall  was  offered  a  scholarship  by  the  Indian Government to study Indian classical music in India. Dr Ishwarduth Nundlall came back to Mauritius in 1958 with degrees in Vocal Hindustani, Sitar and Violin from the National Academy of Music, Lucknow.

Dr. I. Nundlall started performing all over the island arousing interest in many Mauritians to learn the art of music. He is considered to be the first Mauritian to teach, train and propagate Indian classical music in Mauritius.

In this image we can see a person wearing a cap. In the background there is a musical instrument.

<!-- image -->

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

Furthermore, Indians and Mauritians who got training in eminent Institutions from  India  contributed  enormously  in  the  propagation  of  Indian  classical dances in Mauritius.

Some of them are: Mrs. Padma Naidu-Ghurbhurun, Mrs. Sandhya Mungur and Mrs. Rekha Deerpaul in Bharata Natyam; Mr Ramesh Nundoo and Mrs Nirmala Gobin in Kathak; Mrs Damayantee Algoo in Manipuri and Mrs Premila Balakrishna Uppamah in Kuchipudi.

Many Mauritians who were initiated in the classical art  forms  by  the  above named mentors, went  to India to pursue further studies in the field of Tabla, Kathak, Violin, Vocal Hindustani, Vocal Carnatic, Sitar, Bharata Natyam, Mridangam, Kuchipudi, Mohini Attam and Veena.

<!-- image -->

Since 1964 onwards, there has been a continuous effort of the Mahatma Gandhi Institute staff to  propagate  Indian  classical  music  and  dance.  Regional Centres  were  set  up  in  1982  throughout  the  island  by  the  Mahatma  Gandhi Institute so that these art forms could reach out the population at large.

The Ministry of Education, Ministry of Arts and Culture, Indira Gandhi Centre for  Indian  Culture,  Indian  socio-cultural  associations,  and  private  dance schools have  all played important roles in preserving,  promoting  and propagating the Indian classical dance and music in Mauritius.

Indian classical dance has been part of the secondary schools curriculum for more than 40 years. Today, Indian classical music and dance have attained such  a  standard  that  they  are  being  taught  up  to  tertiary  level  at  the Mahatma Gandhi Institute in collaboration with the University of Mauritius.

The Mahatma Gandhi Institute through its various initiatives, in the domains  of  music  and  dance  education,  performance  and  production, have contibuted immensely to enrich the cultural landscape of the nation.

<!-- image -->

## INDIAN CLASSICAL MUSIC AND DANCE IN MAURITIUS

<!-- image -->

- Only Bharata Natyam, Kathak and Kuchipudi are practised in Mauritius.
- Due to the fact that Bharata Natyam originates from Tamil Nadu, Kuchipudi from Andhra Pradesh and Kathak from the regions of Lucknow and Jaipur, these classical dance forms have established themselves in Mauritius.
- It is only after the setting up of the Indian Embassy in Mauritius in 1948 that Indian classical dances were introduced in Mauritius.
- The School of Music and Dance was inaugurated in 1964.
- Ishwarduth Nundlall is known as the first pioneer of Indian classical music in Mauritius.
- The three Indian classical dance forms; Bharata Natyam, Kathak and Kuchipudi are part of the cultural panorama of Mauritius.

In this image, we can see a yellow color object.

<!-- image -->

<!-- image -->

<!-- image -->

1.  State whether the following statements are TRUE or FALSE.
2. Name the three Indian classical dance forms commonly practised in Mauritius.

|       | STATEMENTS                                                                                                       | TRUE / FALSE   |
|-------|------------------------------------------------------------------------------------------------------------------|----------------|
| (I)   | Bharata Natyam, Kathakali and Odissi are the three Indian classical dance forms commonly practised in Mauritius. |                |
| (II)  | Dr Ishwarduth Nundlall is known as the first pioneer of Indian classical music in Mauritius.                     |                |
| (III) | Indian classical dances were introduced in Mauritius before the Independence of India.                           |                |
| (IV)  | The School of Music and Dance was inaugurated in 1964.                                                           |                |
| (V)   | Bharata Natyam, Kathak and Kuchipudi are part of all major socio-cultural occasions in Mauritius.                |                |

.............................................................................................................................

.............................................................................................................................

.............................................................................................................................

3. Write a summary on how Indian classical dances were introduced in Mauritius.

.............................................................................................................................

.............................................................................................................................

.............................................................................................................................

.............................................................................................................................

.............................................................................................................................

<!-- image -->

NOTES

<!-- image -->

<!-- image -->

The image is a colorful poster with a yellow background. The poster features a central image of a woman, likely a goddess, with her hair tied back. The woman is wearing a traditional Indian outfit, which includes a dhoti, a saree, and a headscarf. She is also wearing jewelry, including a necklace and earrings. Her face is serene and serene, with a slight smile.

The background of the image is decorated with colorful patterns and designs, which include spirals, leaves, and other geometric shapes. These patterns are arranged in a circular pattern, creating a visually appealing and eye-catching design.

The text on the poster is in a bold, colorful font, which contrasts with the background and adds a dynamic element to the image. The text reads "HEAD, EYES AND NEEDLE MOVEMENTS" in red, which is a common color used in the Indian design style.

The overall design of the poster is

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

List the names of the nine Shiro Bhedas, eight Drishti Bhedas and the four Greeva Bhedas.

Identify the nine Shiro Bhedas, eight Drishti Bhedas and the four Greeva Bhedas.

<!-- image -->

## DANCE

Dance is considered as a non-verbal form of communication through which an emotion, a message or a story can be conveyed. In dance, one uses the arms, hands, head and the face to express an idea or emotion.In fact, the whole body is used.

According to Abhinaya Darpanam, we have nine Shiro Bhedas, eight Drishti Bhedas and four Greeva Bhedas.

## SHIRO BHEDAS

Head movements are called Shiro Bhedas.  'Shiro' means head in Sanskrit. The head movements refer to the head positions while expressing a particular emotion.

According to Abhinaya Darpanam, there are nine head movements.

## NAMES OF THE NINE SHIRO BHEDAS:

1. Samam: Head is straight and motionless
2. Udvahitam: Head is raised up
3. Adhomukham: Face bent down
4. Alolitam: Circular movement of the head
5. Dhutam: Head is turned to and fro
6. Kampitam: Up and down movement of the head
7. Paravrittam: Head is turned to the right or left briskly
8. Utkshiptam: Head is turned to a side and raised
9. Parivahitam: Head moving from side to side like and arc

## NAMES AND PICTURES OF THE SHIRO BHEDAS

In this image we can see a collage of images of a woman.

<!-- image -->

<!-- image -->

In this image, we can see a person. We can also see some text.

<!-- image -->

<!-- image -->

## SHLOKA FORM OF THE NINE SHIRO BHEDAS

In this image, we can see a logo.

<!-- image -->

## The meaning of the last line of the shlokas is:

Thus the head is said to be nine- fold by the experts on Natya Shastra.

## DRISHTI BHEDAS

Drishti in Sanskrit means vision. The eye movements are based on how we move the eyeballs. There are eight different types of eye movements.

## NAMES OF THE EIGHT DRISHTI BHEDAS

1. Samam:

Eyes are still

2. Alokita: Roll eye balls in a circular manner

3. Sachi: Look at one corner of the eyes

4. Pralokita: Move eyes from side to side

5. Nimilite:

Looking with eyes half opened

6. Ullokita:

Look up

7. Anuvritta:

Move eyes up and down rapidly

8. Avalokita:

Look down

<!-- image -->

## NAMES AND PICTURES OF THE DRISHTI BHEDAS

In this image we can see a collage of pictures of a woman.

<!-- image -->

<!-- image -->

## SHLOKA FORM OF THE DRISHTI BHEDAS

In this image there is a blue color frame. In the center of the image there is text.

<!-- image -->

## The meaning of the last line of the shlokas is:

These are the eight eye movements according to ancient scholars.

## GREEVA BHEDAS

Greeva Bhedas are known as the neck movements. There are four Greeva Bhedas.

## NAMES OF THE GREEVA BHEDAS

- 1.Sundari: Move neck side to side. It is also called  Attami

- 2.Tirashchina:

Move neck in a V-shape

- 3.Parivartita: Move neck in a semi-circle or moon-like shape

- 4.Prakampita: Move neck forward and backward

## NAMES AND PICTURES OF THE GREEVA BHEDAS

In this image we can see a poster with a woman wearing a saree and a headdress.

<!-- image -->

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

<!-- image -->

## SHLOKA FORM OF THE GREEVA BHEDAS

Sundarischa Tirashchina tathaiva Parivartita// Prakampitam cha bhavagney gneya Greeva chaturvidha//

## The meaning of the last line is:

Scholars on bhavas know that Greeva Bhedas are fourfold.

DID YOU KNOW

Sundari is also referred as 'Attami'.

<!-- image -->

1.  Gestures are non- verbal movements which are used to convey a message.
2.  According to Abhinaya Darpanam, there are nine head movements, eight eye movements and four neck movements in dance.
3.  Head movements are termed as Shiro Bhedas.
4.  Eye movements are termed as Drishti Bhedas.
5.  Neck movements are termed as Greeva Bhedas.

KEYWORDS

Non-verbal, emotion, head movements, eye movements, neck movements.

<!-- image -->

## ASSESSMENT

1.  Look at the pictures carefully and write down the appropriate name.

<!-- image -->

<!-- image -->

<!-- image -->

..................................

........................................

...................................

## 2. State whether the following statements are True or False.

|    | STATEMENTS                                                                                              | TRUE / FALSE   |
|----|---------------------------------------------------------------------------------------------------------|----------------|
|  1 | Gestures are non- verbal movements which are used to convey a message.                                  |                |
|  2 | According to Abhinaya Darpanam, we have eight Shiro Bhedas, nine Drishti Bhedas and five Greeva Bhedas. |                |
|  3 | Greeva Bheda is also known as neck movement.                                                            |                |
|  4 | Kampitam is an eye movement.                                                                            |                |
|  5 | Samam is when the head is kept straight.                                                                |                |

## 3. List the four Greeva Bhedas.

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

4. Name and describe any five Shiro Bhedas.

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

...........................................................................................................................

<!-- image -->

## NOTES

<!-- image -->

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Memorise the sequence of prescribed adavus and their pataksharas.
- List the names of the prescribed adavus.
- Execute the prescribed adavus in the various kalas while maintaining anga shuddham.
- Identify the hand gestures, basic dance postures and Pada Bhedas as performed in the Adavus.
- Develop space awareness and use of space in terms of floor patterns and spatial design.

## QUICK RECAP OF TECHNICAL TERMS USED IN KUCHIPUDI

Adavu: An adavu is a fundamental dance unit where the hands, feet, head, eyes and other parts of the body move in a coordinated manner.

Patakshara: It is a rhythmic syllable or a phrase of rhythmic syllables recited when executing an adavu.

Anga shuddham: It is the clarity of body movements while dancing.

Vaishnava sthanaka: It is the half- sitting position in Kuchipudi dance.

Sausthava: The  standing position with the feet held together and the chest is slightly bent forward.

Natyarambhe: The semi- circular position of the arms.

Pada bhedas: Pada bhedas are the positions of the feet and are seen in the various adavus. There are six Pada bhedas and they are as follows: Udghattita, Sama, Agratalasanchara, Anchita, Kunchita, Suchipada.

Usi: Usi is referred to as the dipping movement in Kuchipudi.

## MANDI ADAVUS

This adavu consists of a slight hop while sitting down completely on the toes and springing back to a standing posture.

In this image we can see a woman standing and doing a dance.

<!-- image -->

The pataksharas are TAM TATTA DHINDHA I TATTA DHINDHA II

<!-- image -->

## ADAVU 1- 1 st  VARIATION

A: Sit in Vaishnava Sthanaka first with the hands holding katakamukha hasta.

- B: On 'Tam Tatta Dhindha' sit down completely on the toes with knees outwards (Hands in katakamukha), and get up so that the left leg is in half sitting posture and the right leg is stretched on the sides on the tips of the toes.

The left hand holding katakamukha is stretched in the Natyarambhe position and the right hand holding katakamukha hasta is placed on the wrist of the left hand.

On ' Tatta Dhinda', the same movement is repeated on the left side.

In this image we can see a woman standing and doing a dance.

<!-- image -->

## ADAVU 1- 2ND VARIATION

Adavu 1 is repeated, and is executed twice on the right and twice on the left.

<!-- image -->

## ADAVU 1- 3RD VARIATION

In this image we can see a woman standing and doing different poses.

<!-- image -->

- Adavu 1 (A&amp; B) is executed first.
- On 'Tattat', the right leg is then placed on the toes behind the left leg. Both the hands hold pataka hasta with the left hand stretched out  the Natyarambhe position and the right hand placed in front of the chest level.
- On 'Dhindha', jump to the right side by assuming a half sitting posture on the right leg and the left leg is placed behind the right leg on the toes.
- Both the hands hold pataka hasta; the right hand is stretched out in the Natyarambhe position, and the left hand is placed in front of the chest.

<!-- image -->

## ADAVU 1- 4TH VARIATION

In this image we can see a woman standing and doing a dance.

<!-- image -->

- Adavu 1 (A &amp; B) is executed first.
- On 'Tattat Dhindha', strike the right leg to the side and put the left leg on the toes behind the right leg. This is repeated twice.

## ADAVU 1- 5TH VARIATION

In this image we can see a woman standing and doing a dance.

<!-- image -->

<!-- image -->

- Adavu 1 (A &amp; B) is executed first.
- On 'Tattat Dhindha', jump to the right side on the toes and move in agaratalasanchara bheda.

## ADAVU 2 -1ST VARIATION

In this image we can see a woman standing and doing a pose.

<!-- image -->

- Sit in vaishnava sthanaka first.
- On 'Tam', sit down completely on the toes. The left hand holds katakamukha hasta and the right hand holding alapadma hasta is stretched downwards.
- On 'Tattat Dhindha', get up by assuming half sitting position on the left leg and the right leg is stretched backwards on the toes.
- The left hand holds katakamukha hasta at the chest level. The right hand holding katakamukha hasta is stretched above the head.
- The same movement is repeated on the left.

<!-- image -->

## ADAVU 2 - 2ND VARIATION

In this image we can see a group of women dancing.

<!-- image -->

<!-- image -->

- Sit in vaishnava sthanaka first.
- On 'Tam', sit down completely on the toes. The left hand holds katakamukha hasta and the right hand holding alapadma hasta is stretched downwards.
- On 'Tattat Dhindha', get up by assuming half sitting position on the left leg and the right leg is stretched backwards on the toes.
- The left hand holds katakamukha hasta at the chest level. The right hand holding katakamukha hasta is stretched above the head.
- On 'Tattat', jump on both feet in vaishnava sthanaka. Left hand holds katakamukha hasta at the chest and the right hand holding katakamukha hasta is stretched out in natyarambhe position on the right side.
- On 'Dhindha', strike the left leg and simultaneously the right leg is lifted and stretched in front of the body. The left hand holds katakamukha hasta and the right hand holding alapadma hasta is placed in front of the head.

## ADAVU 3

In this image we can see a woman standing and doing a pose.

<!-- image -->

<!-- image -->

- Sit in vaishnava sthanaka first.
- A: On 'Tam', sit down completely on the toes with both the hands holding katakamukha hasta.
- B: On 'Tatta Dhindha', stretch the right leg on the heel to the right side. The left hand holds katakamukha hasta at the chest level and the right hand holding alapadma hasta is stretched down near the right toes.
- A &amp; B is repeated on the left side as well.
- The whole series is done twice on the right and twice on the left.

## ADAVU 3 - 1ST VARIATION

ADAVU 3 + DHA KITA KITA TAKA JHE KITA KITA TAKA DHALANGU TAKA DHIMI TAKA TADHI GINATOM

In this image we can see a woman standing and dancing.

<!-- image -->

<!-- image -->

- On ' Dha kita kita taka', stretch the right leg out and pull it on one beat on the heel. Then strike the left leg, pull the right leg a second time and strike the left leg again, pull a third time and strike the left leg once more and, finally, strike the right leg flat to vaishnava sthanaka position.
- Both the hands holding pataka hasta are stretched out in natyarambhe position.
- When doing the step, the right hand moves above the head, passes in front of the face, and is again stretched out in natyarambhe position.
- This movement is repeated on the Left, right and left sides.

## ADAVU 3- 2ND VARIATION

ADAVU 3 + TAJHAM TAKITA DHANAM TAKITA TARUM TAKITA TAT TADHI GINATOM

In this image we can see a woman standing and doing a dance.

<!-- image -->

<!-- image -->

In this image we can see a woman in the front and behind her there are two images of her.

<!-- image -->

- On 'Tajham Takita', jump to the right side with the left leg placed on the toes behind the right leg. The left hand holds katakamukha hasta and the right hand holding alapadma hasta is stretched on the sides.
- On 'Dhanam Takita', jump to the left side with the right leg placed on the toes behind the left leg. The right hand holds katakamukha hasta and the left hand holding alapadma hasta is stretched on the sides.
- On 'Tarum Takita', jump with the right leg laterally in front side and the left leg placed on the toes behind the right leg. The left hand holds katakamukha hasta and the right hand holding alapadma hasta is stretched out in front.
- On 'Tat Tadhi Ginatom', make a turn of 360 o .

<!-- image -->

## ADAVU 3- 3RD VARIATION ADAVU 3 + TAJHAM TAKITA DHANAM TAKITA TARUM TAKITA TAT TADHI GINATOM

In this image we can see a woman standing and doing a dance.

<!-- image -->

- On 'Tajham Takita', jump to the right side with the left leg placed on the toes behind the right leg. The left hand holds katakamukha hasta and the right hand holds alapadma hasta is stretched on the sides.
- On 'Dhanam Takita', jump to the left side with the right leg placed on the toes behind the left leg. The right hand holds katakamukha hasta and the left hand holding alapadma hasta is stretched on the sides.
- On 'Tarum Takita', sit down completely on the toes. The left hand holding katakamukha hasta is stretched above the head and the right hand holding alapadma hasta is stretched downwards.
- On 'Tat Tadhi Ginatom', bring the right hand to the chest level to katakamukha hasta and bring the left hand from the top of the head to take a turn of 360 o .

<!-- image -->

ADAVU 3- 4 th  VARIATION ADAVU 3 + TAJHAM TAKITA DHANAM TAKITA TARUM TAKITA TAT TADHI GINATOM

In this image we can see a group of women.

<!-- image -->

<!-- image -->

- On 'Tajaham Takita', strike the right leg and lift the left leg towards the inside of the right knee. The left hand holds katakamukha hasta at the chest level and the right hand holds alapadma hasta which is stretched upwards on the right diagonal.
- On 'Tarum Takita', strike the left leg and lift the right leg towards the inside of the left knee. The right hand holds katakamukha hasta at the chest level and the left hand holds alapadma hasta which is stretched upwards on the left diagonal.
- On 'Tarum Takita', sit down completely on the toes. The left hand holding katakamukha hasta is stretched above the head and the right hand holding alapadma hasta is stretched downwards.
- On 'Tat Tadhi Ginatom', bring the right hand to the chest level to katakamukha hasta and bring the left hand from the top of the head to take a turn of 360 o .

## ADAVU 4 - 1 st  VARIATION

In this image we can see a woman standing and doing some exercise.

<!-- image -->

- Assume vaishnava sthanaka first.
- Sit down completely on the toes with the hands holding katakamukha hasta.
- Spring back to hold the body on both heels and both hands holding alapadma hasta are stretched in front of the chest level.

<!-- image -->

ADAVU 4- 2ND VARIATION

ADAVU 4- 1ST VARIATION IS EXECUTED 4 TIMES FOLLOWED BY TAJHAM TAKITA DHANAM TAKITA TARUM TAKITA TAT TADHI GINATOM

In this image we can see a group of women dancing.

<!-- image -->

<!-- image -->

- On 'Tajham Takita', jump to the right side with the left leg placed on the toes behind the right leg. The left hand holding katakamukha hasta and the right hand holding alapadma hasta is stretched on the sides.
- On 'Dhanam Takita', jump to the left side with the right leg placed on the toes behind the left leg. The right hand holding katakamukha hasta and the left hand holding alapadma hasta is stretched on the sides.
- On 'Tarum Takita', jump with the right leg laterally in front side and the left leg placed on the toes behind the right leg. The left hand holding katakamukha hasta and the right hand holding alapadma hasta is stretched in front.
- On 'Tat Tadhi Ginatom', make a turn of 360 o .

## MISRA JATI ADAVUS

The pataksharas are: TOM TOM TADHA I TOM TOM TADHI II

## ADAVU 1

- Assume vaishnava sthanaka first.
- On 'Tom Tom', jump on both toes two times with the hands holding katakamukha hasta at the chest level.
- On 'Tadha', jump with the right leg on the side and place the left leg on the toes behind the left leg.
- The left hand holds katakamukha hasta while the right hand is stretched on the right side in alapadma hasta.
- The same movement is repeated on the left side.

<!-- image -->

## ADAVU 2

- Assume vaishnava sthanaka first.
- On  'Tom  Tom',  jump  on  both  toes  two  times  with  the  hands  holding katakamukha hasta at the chest level.
- On 'Tadha', strike the left leg and stretch the right leg on the toes on the right side. The left hand holds katakamukha hasta above the head and the right hand holding alapadma hasta is stretched on the left diagonal.
- The same movement is repeated on the left side.

## ADAVU 3

- Assume vaishnava sthanaka first.
- On 'Tom Tom', jump on both toes two times with the hands holding in katakamukha hasta at the chest level.
- On 'Ta', strike the left leg and stretch the right leg on the toes on the right side. The left hand holding katakamukha hasta above the head and the right hand holding alapadma hasta is stretched on the left diagonal.
- On 'dha', strike the right leg and stretch the left leg on the toes on the left side. The right hand holds katakamukha hasta above the head and the left hand holding alapadma hasta is stretched on the right diagonal.

<!-- image -->

## TAT TAI HITTA ADAVUS

The pataksharas are TAT TAI HITTA I TAI HITTA II

## ADAVU 1

In this image we can see a group of people. We can also see a blue color cloth.

<!-- image -->

- Sit in vaishnava sthanaka with the left hand holding pataka hasta in front at chest level and the right hand holding pataka hasta is stretched out in the natyarambhe position on the right side.
- On 'Tat Tai', jump on both feet flat.
- On 'Hitta', strike the left leg and simultaneously lift the right leg up till the inside of the knee of the left leg. The pataka hasta on both hands are tilted slightly.

<!-- image -->

## ADAVU 2

## The Pataksharas are: TAT TAI HITTA, TAI HITTA I TAT TAI HITTA, TAM TAM II

In this image we can see a woman in a blue color dress and red color dress. She is doing a dance.

<!-- image -->

- Sit in vaishnava sthanaka with the left hand holding pataka hasta in front at chest level and the right hand holding pataka hasta is stretched out in the natyarambhe position on the right side.
- On 'Tat Tai', jump on both feet flat.
- On 'Hitta', strike the left leg and simultaneously lift the right leg up till the inside of the knee of the left leg. The pataka hasta on both hands are tilted slightly.
- On 'Tam Tam', strike both feet flat in vaishnava sthanaka.

<!-- image -->

## ADAVU 3

The Pataksharas are: TAT TAI HITTA, TAI HITTA I TAT TAI HITTA, TAM TAM II

In this image we can see a woman standing and doing a dance.

<!-- image -->

- Sit in vaishnava sthanaka with the left hand holding pataka hasta in front at chest level and the right hand holding pataka hasta is stretched out in the natyarambhe position on the right side.
- On 'Tat Tai', jump on both feet flat.
- On 'Hitta', strike the left leg and simultaneously lift the right leg up till the inside of the knee of the left leg. The pataka hasta on both hands are tilted slightly.
- On 'Tam', strike the right leg and lift the left leg up till the inside of the right knee.The right hand changes to alapadma hasta and is stretched upwards on the right diagonal while the left hand holds katakamukha hasta in front at chest level.
- On the next 'Tam', strike the left leg and lift the right leg up till the inside of the left knee. The left hand changes to alapadma hasta and is stretched upwards on the left diagonal while the right hand holds katakamukha hasta in front at chest level.

<!-- image -->

## MUKTAIS

Muktai is an adavu which is repeated thrice or in multiples of three both at the beginning and the end of a dance sequence.

## ADAVU 1

In this image we can see a woman standing and dancing.

<!-- image -->

- Pataksharas: Tadhi Ginatom
- Stretch the right leg out and pull it on one beat on the heel. Then, strike the left leg, pull the right leg a second time and strike the left leg again, pull a third time and strike left leg once more and finally strike the right leg flat to vaishnava sthanaka position.
- Both the hands holding pataka hasta are stretched out in the natyarambhe position.  When  doing  the  step,  the  right  hand  moves  above  the  head, passes in front of the face and is again stretched out in the natyarambhe position.

<!-- image -->

## ADAVU 2

In this image we can see a woman standing and dancing.

<!-- image -->

- Pataksharas: Tadhi Ginatom
- Strike the right leg, then place the right leg on the heel by stretching it on the right side. Then strike the left leg flat and strike back the right leg in its initial place.
- Both  hands  assume  pataka  hasta  in  the  natyarambhe  position.  When doing the step, the right hand moves above the head, passes in front of the face and is again stretched out in the natyarambhe position.

<!-- image -->

## ADAVU 3

In this image we can see a woman standing and doing a dance.

<!-- image -->

- Assume the vaishnava sthanaka first with both hands holding alapadma hasta crossed at the wrists.
- Strike the right leg, then place the right leg on the heel by stretching it on the right side.Then strike the left leg flat, and strike back the right leg in its initial place.
- Both hands, then, open up to hold katakamukha hasta in the natyarambhe position.

<!-- image -->

## ADAVU 4

In this image we can see a woman standing and dancing.

<!-- image -->

- The pataksharas are: Tadi Gina Tom
- Assume vaishnava sthanaka first.
- The right leg is placed on the toes behind the left leg and strikes the left leg flat. Strike the right leg, and place the right leg on the heel by stretching it on the right side. Then strike the left leg flat and strike back the right leg in its initial place.
- The  right  katakamukha  hasta  changes  to  alapadma  hasta  and  travels down  first  and,  then  up,  till  above  the  head,  where  it  again  assumes katakamukha hasta.

<!-- image -->

## ADAVU 5

In this image we can see a woman in blue color dress and she is doing a dance.

<!-- image -->

- Assume vaishnava sthanaka first.
- The right leg is placed on the toes behind the left leg and strikes the left leg flat. Strike the right leg, and place the right leg on the heel by stretching it on the right side. Then strike the left leg flat and strike back the right leg in its initial place.
- Both  hands  holding  pataka  hasta  are  stretched  out  in  natyarambhe position.  When  doing  the  step,  the  right  hand  moves  above  the  head, passes in front of the face and is again stretched out in the natyarambhe position.

<!-- image -->

## ADAVU 6

In this image we can see a group of people dancing.

<!-- image -->

- Jump with both the right and left leg first. Strike the right leg, and place the right leg on the heel by stretching it on the right side. Then strike the left leg flat and strike back the right leg in its initial place.
- Both the hand holding pataka hasta are stretched out in the natyarambhe position.  When  doing  the  step,  the  right  hand  moves  above  the  head, passes in front of the face and is again stretched out in the natyarambhe position.

<!-- image -->

## ADAVU 7

In this image we can see a woman in blue color dress and she is wearing a belt and a bracelet. She is standing and she is smiling.

<!-- image -->

- The pataksharas are: Tadhi Ginatom
- The right leg is placed on the toes behind the left leg. The right leg is placed on the heel, then strike the left leg followed by striking the right leg flat.
- This step is done while moving in front laterally.
- The  hands  hold  alapadma  hasta  crossed  at  the  wrists  and  open  up  to assume katakamukha hasta in the natyarambhe position. The hands also move in a lateral forward position.

<!-- image -->

NOTES

<!-- image -->

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

<!-- image -->

Explain the following dance terminologies:

Nritta, Nritya, Natya, Tandava, Lasya and Abhinaya

<!-- image -->

Differentiate between Nritta and Nritya.

<!-- image -->

<!-- image -->

<!-- image -->

Differentiate between Tandava and Lasya.

- Explain Abhinaya.

Appreciate the different types of dances.

## DANCE TERMINOLOGIES

According to Natya Shastra and Abhinaya Darpanam, all Indian classical dances are comprised of the following components: Nritta, Nritya, Natya, Tandava, Lasya and Abhinaya.

In this image, we can see a logo and some text.

<!-- image -->

TANDAVA

<!-- image -->

## NRITTA

Nritta  usually  refers  to  pure  dance movements consisting of dance steps performed rhythmically by the various limbs of the body. The body movements do not convey any specific meaning or emotion.

The main purpose in nritta is to create a  beautiful  sequence  in  space  and time through the various body movements.

Nritta  does  not  lay  emphasis  on  the facial expressions. In nritta, the synchronisation of tala and laya is of utmost importance. Adavus are examples of the nritta aspect of dance.

## NRITYA

Nritya  refers  to  expressional  dance where the meaning of the lyrics of the song/ poem is conveyed through body movements and facial expressions.

Nritya  consists  of  both  footwork  and expressions. Kauthvams, Shabdams, Keerthanams, Javalis, Padams are all examples of Nritya.

<!-- image -->

In this image we can see a woman dancing.

<!-- image -->

In this image we can see a woman standing and dancing.

<!-- image -->

## NATYA

Natya refers to drama. It is narrating a story through dance, music and speech. In natya, the dancers assume the roles of characters and narrate a story through speech, mime and dance. Bhama  Kalapam  is  a  famous  dance drama in Kuchipudi.

In this image we can see a person standing and dancing. There is a person in the middle of the image. There is a person in the right corner of the image. There is a person in the left corner of the image.

<!-- image -->

## TANDAVA AND LASYA

In this image there is a diagram.

<!-- image -->

<!-- image -->

## TANDAVA

Tandava  is  the  masculine  form  of  dance.  Tandava  is  comprised  of movements which are full of vigour,strength and speed. Lord Shiva is the God  of  Dance  and  the  dance  he  performs  is  known  as  Tandava.  Lord Shiva's  tandava  dance  is  a  vigorous  dance.There  are  seven  types  of Tandava dance.

In this image we can see two people dancing. The background of the image is in a collage format.

<!-- image -->

## LASYA

Lasya is the feminine aspect of dance. It is believed to have been introduced by Goddess Parvati.

Lasya  consists  of  delicate,  soft  and  graceful body  movements.  Lasya  is  the  opposite  of Tandava.

In this image we can see a woman standing and smiling. She is wearing a yellow color dress.

<!-- image -->

<!-- image -->

## ABHINAYA

Abhinaya is  a  Sanskrit  word  which  is  made  of  the  prefix  'Abhi'  meaning 'towards' and the root 'ni' meaning 'to carry' or 'to represent'.It means to enact a play before an audience.Abhinaya is of four kinds;

In this image we can see a poster with some text and images.

<!-- image -->

Abhinaya  is  meant  to  make  the  audience  experience  the  pleasureable aspects of the play by means of the movements of the body, the words, the costumes and the emotions portrayed in the play/ dance.

<!-- image -->

## ANGIKA ABHINAYA

In this image we can see two women standing on the stage. The woman on the left is wearing a purple color dress and the woman on the right is wearing a pink color dress.

<!-- image -->

This form of abhinaya is expressed by the use of the various limbs of the body. The body is divided into three parts:

- (i)   Angam
- (ii)  Pratyangam
- (iii) Upangam

## VACHIKA ABHINAYA

This  is  expression  conveyed  through speech or words from dialogues, poetry, recitation  and  songs.Vachika  abhinaya brings out the lyrical qualities of a play.

<!-- image -->

In this image we can see a woman standing and smiling. In the background there is a wall and sculptures.

<!-- image -->

## AHARYA ABHINAYA

Aharya abhinaya is the immediate identifying factor of the dance style when the dancer comes on stage.

In this image we can see a group of people standing on the stage. In the background there is a curtain.

<!-- image -->

Aharya  abhinaya  is  the  expression  which  is  shown  through  the  use  of make-up, costumes, ornaments and stage props and stage décor.

## SATTVIKA ABHINAYA

Sattvika  abhinaya  is  conveyed  through  the  expression  of  sentiments  to create Rasa. Bhava is the emotional and existing condition of the dancer while rasa is the aesthetic experience felt by the spectator while he enjoys the  meaning  or  idea  conveyed  to  him  through  the  gestures  and  facial expressions.

## KEYWORDS

Pure dance, expressional dance, masculine, feminine, limbs, dialogues, poetry, costumes, make-up, stage props and sentiments.

In this image we can see a woman is sitting on the floor. She is wearing a red and green color dress. She is wearing a red and green color necklace. She is wearing a red and green color headpiece. She is wearing a red color belt. She is wearing a red color bracelet. She is wearing a red color saree. She is smiling.

<!-- image -->

<!-- image -->

<!-- image -->

- Nritta  refers  to  pure  dance  movements  consisting  of  dance  steps performed rhythmically by the various limbs of the body. 1.
- Nritya refers to expressional dance where the meaning of the lyrics of the  song/  poem  is  conveyed  through  body  movements  and  facial expressions. 2.
- Natya  refers  to  drama.  It  is  narrating  a  story  through  dance,  music, speech. 3.
- Tandava  is  the  masculine  form  of  dance.  Tandava  is  comprised  of movements which are full of vigour,strength and speed. 4.
- Lasya is the feminine form of dance.Lasya consists of delicate, soft and graceful body movements. 5.
- Abhinaya is a Sanskrit word which is made of the prefix 'abhi' meaning 'towards' and the root 'ni' meaning 'to carry' or 'to represent'. In dance it means to enact a play before an audience. 6.
- Abhinaya is divided into four categories namely angika, vachika, aharya and sattvika. 7.
- Angika abhinaya is expressed by the use of the various limbs of the body. 8.
- Vachika  abhinaya  is  expression  conveyed  through  speech  or  words from dialogues, poetry, recitation and songs. 9.
- Aharya abhinaya is the expression which is shown through the use of make-up, costumes, ornaments and stage props and stage décor. 10.
- Sattvika abhinaya is conveyed through the expression of sentiments to create Rasa. 11.

<!-- image -->

<!-- image -->

1. State whether the following statements are True or False.
2. Explain the following terms:
3. (i)  Nritta
4. (ii)  Nritya
5. (iii) Natya
3. Explain the four types of abhinaya.
4. Differentiate between Tandava and Lasya.

|    | STATEMENTS                                                                 | TRUE / FALSE   |
|----|----------------------------------------------------------------------------|----------------|
|  1 | Tandava is the delicate aspect of dance.                                   |                |
|  2 | Nritya refers to expressional dance.                                       |                |
|  3 | Angika abhinaya is expressed by the use of the various limbs of the body.  |                |
|  4 | Natya is referred to as pure dance form.                                   |                |
|  5 | Aharya abhinaya is the expression through the use of speech and dialogues. |                |

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

<!-- image -->

Interprete the hand gestures and feet movements in the posture of Lord Nataraja.

- Name the seven types of Tandavas.

<!-- image -->

Describe Ananda Tandava and Urdhva Tandava.

<!-- image -->

- Describe the dance stories Kaliya Mardana and Rasa Leela.

<!-- image -->

<!-- image -->

Explain the moral teachings underlying the dance stories of Lord Shiva and Krishna.

Identify the various Indian Gods and Goddesses.

<!-- image -->

Value the virtues of good over evil.

<!-- image -->

## NATARAJA, SHIVA - THE KING OF DANCE.

In the image there is a statue of a deity. The deity is depicted with the hands on the ground and the legs are in the air. The deity is wearing a crown. The background of the image is white.

<!-- image -->

Lord Shiva is also known as Lord Nataraja more prominently in the south of India. In this form He is worshipped as the king of dance.

Lord Nataraja, in His dance posture, represents the spiritual cosmic dance of Lord Shiva known as the Nadanta or Ananda Tandava. The Tandava dances of Lord Nataraja represent the masculine aspect of dance, which is the forceful and vigorous style.

He performed this dance in the golden temple of Chidambaram in Tillai.

In this image we can see a temple with a roof and there are some buildings and trees.

<!-- image -->

<!-- image -->

In the Ananda Tandava, Lord Shiva dances with four hands. The upper right hand sounds the Damru, sound representing the very first creating force and the intervals of beat in time process.

In this image we can see a sculpture.

<!-- image -->

Damru

In this image we can see a musical instrument.

<!-- image -->

The lower right hand in the pose of Abhaya Hasta, gives protection to his devotees.

In this image we can see a sculpture.

<!-- image -->

<!-- image -->

The  upper  left  hand  holds  the  sacred  flame  which  represents  the  fire  of sacrifice.

Sacred flame

In this image we can see a statue.

<!-- image -->

The lower left hand in the Danda Hasta pose is stretched across his body and is pointing to the upraised left foot ( Kunchita Pada ) signifying blissful refuge to those who seek his love and grace.

In this image we can see a picture of a statue. There is a text at the bottom of the image.

<!-- image -->

<!-- image -->

The right foot tramples down the dwarf Muyalaham , signifying the destruction of the evil; the left foot raised in the Kanchita Pada showers grace on all those who seek it.

Muyalaham

In this image we can see a sculpture.

<!-- image -->

The  face  of  Lord Nataraja has  a  blissful  expression,  with  his  radiant  eyes showing and spreading love and abundant mercy. He spreads his glory over the entire world, graciously granting release to the countless souls that seek him.

In this image we can see a statue.

<!-- image -->

<!-- image -->

## SEVEN TYPES OF TANDAVA

Tandava dance is the dance of Lord Nataraja. Lord Shiva passed on this art of dancing to human beings on earth through his disciple Tandu.

1. Ananda Tandava

- which expresses joy

2. Sandhya Tandava

- the evening Tandava

3. Uma Tandava

- the Tandava in which Shiva danced with his consort Uma

4. Gauri Tandava

- the Tandava in which Shiva danced with his consort Gauri

5. Kalika Tandava

- the Tandava danced by Lord Shiva when he killed Kalika, the demon of evil and ignorance

6. Tripura Tandava

- the Tandava danced by Lord Shiva when he killed the demon Tripura

7. Samhara Tandava

- Shiva's Tandava dance of death, symbolising the release of the soul from the 'maya' or illusion

## ANANDA TANDAVA OR NADANTA DANCE

One day, Lord Vishnu went to Mount Kailash in the Himalayas to visit Lord Shiva.

In this image we can see a mountain. At the bottom of the image there is a hill. At the top of the image there is sky.

<!-- image -->

Lord  Shiva  told  Lord  Vishnu  that  a  group  of  sages,  living  in  the  forest  of Taragam,  were  very  arrogant  and  ill-behaved  and  refused  to  accept  the existence of God.

<!-- image -->

In this image we can see a group of people. In the background there are trees.

<!-- image -->

To teach them a lesson, Lord Shiva disguised himself as a handsome beggar and Lord Vishnu disguised himself as a beautiful woman, Mohini , the wife of the beggar.

The image is a collage of two different religious paintings. The left side of the image shows a man and a woman, both dressed in traditional Indian attire. The man is holding a mace in his right hand and a bowl in his left hand. The woman is holding a bowl in her left hand and a mace in her right hand. Both are wearing traditional Indian clothing. The background of the left side image is a plain, light-colored background with a few colorful patterns. The background of the right side image is a colorful, vibrant background with a few colorful patterns.

The right side of the image shows a woman and a man, both dressed in traditional Indian clothing. The woman is holding a bowl in her left hand and a mace in her right hand. The background of the right side image is a colorful, vibrant background with a few colorful patterns.

The left side of the image shows a man and a woman, both dressed in traditional Indian clothing. The man

<!-- image -->

On seeing Mohini , the sages fell in love with her. The sages started quarrelling among themselves as each one wanted to have Mohini for himself.

In this image we can see a group of people. In the background there are trees and a shed.

<!-- image -->

<!-- image -->

On  the  other  hand,  the  wives  of the sages  got attracted with the handsome  beggar  which  made  the sages angry. They decided to make a big sacrificial fire and recited verses ( Mantras ) which created ferocious animals in order to destroy the beggar.

They created a ferocious tiger, with one  of  the Mantras ,  which  rushed to attack the beggar.  The latter caught  it,  killed  it  and  wore  its  skin around his waist.

The sages continued with their sacrificial  fire  and  created  a  huge poisonous serpent. Lord Shiva seized it and coiled it around his neck and began his mystic dance.

The sages were not discouraged by the  failure  of  their  attempts.  They continued  with  the  rituals  and,  this time, the black demon dwarf, Muyalaham ,  came  out  from  the  fire and  rushed  upon  Lord Shiva .  The Lord  pulled  the  demon  down  and placed His sacred foot on the demon's back, thus breaking its spine.

Lord Shiva continued his dance. The sages recognized Lord Shiva's true form and they fell at his feet.

In this image we can see a group of people sitting on the floor. In the background there is a pillar.

<!-- image -->

In this image we can see a snake.

<!-- image -->

In this image we can see a painting.

<!-- image -->

The philosophical meaning of this story is that God always protects and grants release from worldly attachment to all those who seek Him. He destroys evil in men and leads them to the path of righteousness.

<!-- image -->

## URDHVA TANDAVA

Once upon a time in the city of Chidambaram in the forest of Tillai, there lived Queen Kali who governed the city. One day, Lord Shiva was invited by his devotees to visit the city of Chidambaram, which he accepted.

Unfortunately, when Lord Shiva came down to visit Chidambaram, the gate-keepers and soldiers of Kali did not allow him to enter the city. Lord Shiva was disappointed and felt insulted.

He then made a plan to challenge Queen Kali. He  proposed  to  her  to  take  part  in  a  dance competition with him. The condition was that the winner of this dance competition would rule the city of Chidambaram whereas the loser would have to leave the city for ever. Kali accepted the challenge of this dance competition.

In this image we can see two persons standing and holding a sword.

<!-- image -->

In this image we can see a person standing and holding an object.

<!-- image -->

All the Gods were invited to witness the competition and to be the judges also. During the performance, both Kali and Shiva danced with enthusiasm.

Each dancer tried to imitate the movements of the other and each one tried to do better than the other. For a long time, they were both able to imitate each other.

<!-- image -->

In this image we can see a collage of different images.

<!-- image -->

At  last,  Lord  Shiva  got  impatient  and  he lifted  his  leg  above  his  head and touched his crown with his foot. Out of modesty and in respect for the audience, Queen Kali did not imitate Lord Shiva. So, Lord Shiva was declared the winner of the competition.

This dance came to be known as Urdhva Tandava because Lord Shiva danced with his foot raised upwards to touch his crown. The word 'Urdhva' means upward.

As  per  the  condition  of  the  competition, the loser, Queen  Kali, left the city of Chidambaram  forever.  The  devotees  of Shiva built a temple at the place where the competition  took  place  and  later  it  was developed as the huge temple of Nataraja at Chidambaram.

In this image we can see a painting. In the painting we can see a woman and a man.

<!-- image -->

The  followers  of  Kali  also  built  a  small shrine  for  Kali  near  Chidambaram  where she settled down.

In this image we can see a temple. In the background there are trees and sky.

<!-- image -->

The philosophical aspect of this dance is that God shows the path towards freeing the self from ego and arrogance.

<!-- image -->

## DANCES OF KRISHNA

## LORD KRISHNA AS NATWAR

Krishna, as the dancer, is known as Natwar in the North of India. In Vaishnavite literature  Krishna  is  named  as  Natwar  the  supreme  dancer  as  he  is said  to  have  danced  on  several  occasions  and  he  is  often  represented as the divine dancer.

## KALIYA MARDANA

Krishna, in his boyhood, was living in Gokula with his foster parents, Nanda and Yashoda. In the river Yamuna, which flowed through the village, lived a hundred-headed serpent called Kaliya. Kaliya, being a wicked serpent, was a menace to the herdsmen and their cattle.

In this image we can see a painting. In the painting there are many objects. At the bottom of the image there is water. In the background there are trees and sky.

<!-- image -->

The village  people  approached  Lord Krishna to  help  them  to  get  rid  of  this wicked creature.

In this image we can see a group of people, animals, plants, grass, water, and a few objects.

<!-- image -->

<!-- image -->

Krishna recognised the forces of evil, which the serpent Kaliya represented, through his divine power.

One day Krishna was playing a game of ball together with his friends near the Yamuna river. While they were playing, suddenly the ball fell into the river and Krishna, without hesitating, jumped into the water to get back the ball.

In this image we can see a cartoon image of a person running on the ground. There are many people standing on the ground. There are many animals on the ground. There are rocks and trees in the background. There is a watermark on the image.

<!-- image -->

His  friends  and  the  villagers  got  scared  for  Krishna  as  they  knew  that  the serpent Kaliya resided in the deep water of the river.

In this image we can see a group of people. We can also see a white color animal. We can also see trees and the sky.

<!-- image -->

As soon as Kaliya saw Krishna he rushed to attack Him.

In this image we can see a cartoon image of a person and a person is drowning in the water. In the background we can see trees, grass, water and the sky.

<!-- image -->

<!-- image -->

Krishna jumped on the serpent and with one foot upraised, danced his famous Tandava dance. He moved with force and determination. He jumped on the monster from one head to the other and subdued it.

In this image we can see a painting of a person.

<!-- image -->

The villagers were happy to see Krishna emerge victoriously out of the river.

In this image we can see a collage of different people.

<!-- image -->

In this youthful dance, Krishna symbolises that aspect of God which destroys evil and subjugates the enemies of the innocent.

In this image we can see a person standing and holding an object. In the background there are flowers and leaves.

<!-- image -->

<!-- image -->

## ACTIVITY

Enact the dance story Kalya Mardana with the help of the teacher.

## THE 'RASA LILA DANCE'

The Rasa Lila dances of Krishna cover almost the entire episodes of Krishna's life from his childhood to his adulthood.

There are four main Rasa Lila dances, namely Vasanta Rasa, Maha Rasa, Kunja  Rasa and Nitya  Rasa. The  main  apparent  form  that  recurs  in  every aspect of Rasa dances is the circle.

The Maha-Rasa is  performed on the full moon night of Kartik in  November. On  this night, Lord Krishna performs the Rasa-Lila with the Gopis . Charmed by the music of his flute, Radha and the Gopis abandon their work and set out to meet him.

The  intensity  of  their  love  is  satisfied only when they meet Lord Krishna and dance with him in joy. As soon as the Gopis become conscious of their good fortune  and  are  overcome  with  pride, Lord Krishna senses this and disappears  with Radha .  When Radha considers  herself  more  fortunate  than the Gopis Lord Krishna disappears from  her  as  well.  The Gopis become restless  and  pray  ardently  for Krishna to appear before them.

In this image we can see a group of people standing and playing a musical instrument.

<!-- image -->

<!-- image -->

In their relentless search they woefully implore the trees, birds and animals to help  them  find  their  beloved.  Instead,  they  find Radha, also  weeping  and wandering in search of her Lord.

This separation melts their pride and Lord Krishna appears again, not as one person but in multiple forms. There are as many Krishna as there are Gopis and all of them dance in ecstasy, performing the Rasa . At the end of the Rasa dance, Krishna suggests to Radha and the Gopis that they should return to their homes.

In this image we can see a group of people. There are trees and a lake in the background.

<!-- image -->

## The moral teachings underlying the Maha-Rasa are:

Krishna's beautiful dances with the Gopis at Brindavan , on the banks of the Yamuna river, are symbolic.

Lord Krishna is  the  divine  lover,  dancer  and  musician.  The Gopis represent human beings in search of the Divine. This represents the freedom  of  man  from  earthly  attachments  and  taking  the  path  of renunciation of the self.

<!-- image -->

POINTS TO REMEMBER

- Lord Shiva is also known as Lord Nataraja more prominently in the South of India. 1.
- The dances of Lord Shiva are known as the Tandava. 2.
- Tandava is the masculine aspect of dance. 3.
- Ananda Tandava is the dance where Lord Shiva subdues the demon dwarf Muyalaham. 4.
- The Urdhava Tandava is the dance where Lord Shiva lifts his leg to his crown and wins the dance competition over Queen Kali. 5.
- Lord Krishna is known as Natwar in the North of India. 6.
- Kaliya Mardana is the dance story where Lord Krishna subdues the demon serpent Kaliya. 7.
- Rasa Leela is the dance of Lord Krishna where he dances with the Gopis on the full moon night of Kartik. 8.

## KEYWORDS

Cosmic dance, masculine, blissful, sacrificial fire, subjugate, ecstasy, renunciation.

<!-- image -->

<!-- image -->

1. Interpret the image of Lord Nataraja.
2. Label the image of Lord Nataraja given below:
3. Name the seven types of Tandava.
4. Narrate one dance story of Lord Shiva and of Lord Krishna.

In this image we can see a statue.

<!-- image -->

<!-- image -->

NOTES

<!-- image -->

<!-- image -->

In this image I can see the yellow color background. In the center of the image I can see the image of a person. I can see the text written on the image.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

Describe the origin, growth, decline, rehabilitation and propagation of Kuchipudi.

<!-- image -->

Kuchipudi is a village from the Krishna district of Andhra Pradesh. The dance form derives its name from the village of Kuchipudi.

## ORIGIN OF THE DANCE FORM

Temples  of Andhra  Pradesh  nurtured  dancing  traditions  and  dancers.  The dancers  were  known  as  devadasis. The  devadasis,  also  referred  to  as  the 'servants of Gods' were women who were employed to offer worship to the temple deity through dance. At the beginning, the devadasis were restricted to dancing in the hall in front of the sanctum sanctorum (the sacred place where the  deity  is  found).  Later,  when  the  deities  were  taken  to  procession  in  the villages,  the  devadasis  were directed to dance during these processions as well.  The  people  who  followed  the  procession  compelled  the  devadasis  to dance particular items to their taste. This led to the decline of the devotional aspect of the dance. This led the rulers and the noble class of the country to invite the devadasis to dance on important occasions in their premises, and the form of 'kelika' came into existence.

'Kelika'  is  a  graceful  dance  based  on  the  compositions  in  praise  of  their patrons.  The  devadasis  were  highly  remunerated,  and  discontinued  their service in the temples and accepted to be court dancers.

Another dance tradition that existed in Andhra Pradesh was the Yakshagana. The origin of Yakshagana is presumed to lie in the ballads sung by members of the  Jakkulu  tribe.  Yakshaganas  were  originally  in  the  form  of  a  description where only one artiste danced and narrated the story. Later on, two charactersa man and a woman-participated. Eventually, characters like the clown and fortune  teller  were  introduced  depending  on  the  story,  and  the  Sutradhara became  the  main  person  to  assume  the  role  of  the  director,  singing  the prologues of the scenes.

In this image we can see a group of people are standing on the stage. In the background there is a wall.

<!-- image -->

<!-- image -->

In this way, the solo type of Yakshagana developed into a full dramatic form combining music, dance, dialogues and verses. Thus the Brahmin gurus of the art of Brahmana Mela shaped the Yakshagana into a more stylized form based on the principles of Natya Shastra to give it a classical form. This new form of Yakshagana came to be known as Kalapam.

## DID YOU KNOW

With the deterioration of the prevailing system of dance by the devadasis, the Brahmin Gurus of the Kuchipudi village formed groups that came to be known as Brahmana Melas. These 'melas' travelled from place to place performing dance dramas on mythological themes.

The earliest reference to these 'melas' can be found in the book Machupalli Kaifiat in 1502 AD which throws light on how the common man got relief from the  tyranny  of  Sammeta Guruva Raju when the theme was presented as a dance drama before the local ruler Immadi Narasa Nayak (ruler of Vijaynagara), who understood the message of the play.

Over a period of time, the practitioners of this art form came to be known as 'bhagvatulus'. Bhagvatulus were the Brahmin men who were well versed in the vedas, dance and music. The most famous of the Bhagvatulus was Siddhendra Yogi who composed various dance dramas in the Kuchipudi style of dance. He composed the famous dance drama Parijata Paharanam which was renamed as Bhama Kalapam.

<!-- image -->

## TEMPLE  RECORDS

During The Vijayanagara Empire (1336  AD-  1640AD),  a  number  of temples were built, which were ornamented  with  dance  sculptures. The  kings  ruling  during  that  period were connoisseurs of arts and great patrons of the arts. Krishnadeva Raya III (1510-1530 AD) built dance halls (narthanasala) in the temples at Hampi,  Lepakshi,  Penugonda  and Gutti. The sculptures of these temples reflect the dance and music forms prevailing during that period.

The  Ramappa  temple  in  Warangal was constructed by Recharla Rudra Deva  in  1213  AD,  and  is  sculpted with dancing figures.

The dance sculptures of the Svayambhulingeshwara temple also show evidence of dance forms.

In this image we can see a wall with carvings.

<!-- image -->

## GROWTH OF KUCHIPUDI DANCE VIJAYNAGAR DYNASTY

In this image there is a picture of a temple and there is a map of India and there is a sky.

<!-- image -->

The dance form flourished in the 16 th  century under the patronage of the rulers of the medieval era. The great rulers of the Vijaynagar Empire were lovers of arts and during their reign, temples were built which were sculpted with dancing figures  and  which  had  dancing  halls.  Krishnadeva  Raya  III  arranged  the construction of a school for dance where he got women trained in the art of dance.

<!-- image -->

## TANJORE KING ACHYUTAPPA NAYAKA

In this image we can see a person wearing a crown.

<!-- image -->

After the decline of the Vijayanagar Empire, many of  the  artists,  poets,  dancers  and  musicians moved to the court of Tanjore in Tamil Nadu where they  received  princely  patronage  of  the  Nayaka Kings.  In  the  mid-sixteenth  century,  the  Nayaka Kings started ruling Tamil Nadu. The Achyutappa Nayaka  (1561-  1614)  who  ruled  Tanjore  was  a great patron of arts, and many  artists and scholars received the patronage of the King. It is believed that the King Achyutappa Nayaka gifted a village  to  the  Brahmin  families  who  were practising the Kuchipudi dance form. The village was named after the king as Achyutapuram and later came to be known as Melattur.

## NAWAB OF GOLCONDA

In this image we can see a collage of images. In the center of the image we can see a tower. In the background of the image we can see the sky, clouds and some other objects.

<!-- image -->

Few  Kuchipudi  artists  stayed  back  in  their  ancestral  village  in  the Andhra region.  Since  they  lacked  patronage,  they  cultivated  lands.  The  districts  of Andhra were taken by the Golconda Nawabs, and Kuchipudi village fell under their rule. The last of the Nawabs was Abul Hasan Tanisha. He was known to be very generous and would shower gifts on those he favoured. In 1678, as he was on a visit to Machilipatnam, he stopped at the Kuchipudi village along with his Commander Pingali Madanna.

Some of the village boys were at that time presenting Bhamakalapam before the temple Rajagopalaswami. The Nawab heard the songs and invited them to perform  in  his  camp.  He  enjoyed  the  performance  immensely,  and  was surprised that his kingdom had such great artistes and felt proud of it. He felt that his name should be eternally associated with Kuchipudi dance drama.

<!-- image -->

On the advice of his Commander, he agreed to gift away the 600 acres of the village as an endowment for Kuchipudi dance and its troupes with hereditary rights in the name of the nine families who existed at that time in the Kuchipudi village. An order was issued in the name of Bhagavatula Narasanna, the oldest member of the Kuchipudi village.

The entire village was indebted to King Tanisha for his generous gesture. This may  be  the  reason  why  in  Kuchipudi  Shabdams,  we  find  part  of  the  lyrics concluding with the words 'Salam' or 'Paraku', meaning salutation, thus offering their salutation through dance.

## DECLINE

When  the  Mughal  Emperor  Aurangzeb  took  over  the  rule  in  1687,  all non-Muslim  practices  were  ceased  leading  to  a  ban  of  music  and  dance performances in public. The art form somewhat revived following the demise of Aurangzeb in 1707.

In this image we can see a painting. In the painting there are people standing and sitting. In the background there is a wall.

<!-- image -->

However, under the British colonial rule in the 18 th and 19 th centuries, various classical  dance  forms  declined.  Furthermore,  the  Christian  missionaries launched an anti-dance movement in 1892 to stop the devadasi practice. The Madras Presidency under the British colonial government banned the custom of dancing in Hindu temples in 1910. With this, Kuchipudi, that was performed conventionally during night time on a stage associated with a Hindu temple, also saw its decline.

<!-- image -->

## REHABILITATION AND PROPAGATION

The Indian community disapproved of such a ban, worrying that the rich and ancient custom of Hindu temple dancing was being persecuted on the pretext of social reform. As the Indian freedom movement progressed during the early 20th century, efforts were made to revive the Indian art forms. Many classical art  scholars  joined  hands  between  1920  and  1950  to  revive  the  ancient classical  dance  forms.  Among  them,  Vedantam  Lakshminarayana  Sastri played an instrumental role in reviving and reconstructing Kuchipudi and also initiated  women  to  this  dance  form.  Vempati  Venkatanarayana  Sastri  and Chinta Venkataramayya popularised the dance form through public performances.  Many  Western  artistes  who  came  to  learn  Indian  classical dance forms became a part of the revival movement.

In 1959, Kuchipudi received recognition as a major classical dance form.

In this image we can see a person.

<!-- image -->

Vedantam Lakshminarayana Sastri

In this image we can see a person's face.

<!-- image -->

Vempati Venkatanarayana Sastri

<!-- image -->

<!-- image -->

-  Kuchipudi is a village in the Krishna district of Andhra Pradesh.
-  The dance form derives its name from the village of Kuchipudi.
- The devadasis, also referred to as the 'servants of Gods' were women who were employed to offer worship to the temple deity through dance. Devadasis were attached to the temples in Andhra Pradesh.
-  Later, the devadasis discontinued their service in the temples and accepted to be court- dancers.
-  'Kelika' is a graceful dance based on the compositions in praise of their patrons.
-   Another dance tradition that existed in Andhra Pradesh was the Yakshagana.
- The Brahmin gurus of the art of Brahmana Mela shaped the Yakshagana into a more stylized form based on the principles of Natya Shastra to give it a classical form. This new form of Yakshagana came to be known as Kalapam.
-  The earliest reference to these 'melas' can be found in the book Machupalli Kaifiat in 1502 AD.
-  The most famous of the Bhagvatulus was Siddhendra Yogi who composed various dance dramas in the Kuchipudi style of dance.
-  The great rulers of the Vijaynagar Empire were lovers of arts and during their reign, temples were built which were sculpted with dancing figures.
- The Achyutappa Nayaka (1561- 1614) who ruled Tanjore was a great patron of arts and gifted a village to the Brahmin families who were practising the Kuchipudi dance form.

<!-- image -->

POINTS TO REMEMBER

-   Abul Hasan Tanisha gifted away the 600 acres of the village as an endowment for Kuchipudi dance.
-  During the British colonial rule in the 18 th and 19 th centuries, various classical dance forms declined.
-  Many classical art scholars joined hands between 1920 and 1950 to revive the ancient classical dance forms.
-  In 1959, Kuchipudi received recognition as a major classical dance form.

## KEYWORDS

Patrons, rehabilitation, patronage, propagation, sculptures, dance-drama, court dancers.

<!-- image -->

<!-- image -->

1. State whether the following statements are True or False.
2. Give a brief description of the patronage of the Nawab of Golconda.
3. Name two temples in Andhra Pradesh which have dancing sculptures.
4. 4.Give a brief description of the Yakshagana tradition.

|       | STATEMENTS                                                                              | TRUE / FALSE   |
|-------|-----------------------------------------------------------------------------------------|----------------|
| (I)   | Kuchipudi was recognized as classical dance form in 1959.                               |                |
| (II)  | Both devadasi and Yakshagana tradition existed in Andhra Pradesh.                       |                |
| (III) | The Mughal EmperorAurangzeb was a great patron of Kuchipudi dance.                      |                |
| (IV)  | King Tanisha gifted 600 acres of Kuchipudi village as an endowment for Kuchipudi dance. |                |
| (V)   | KrishnaDevaraya III initiated women to learn Kuchipudi dance form.                      |                |

<!-- image -->

In this image, we can see a poster with some text and designs.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Describe the ancient and modern costumes of Kuchipudi.

- List the jewelleries used in Kuchipudi.

- Describe the Ghungroos used in Kuchipudi.

- List the accessories for a Kuchipudi dance make-up.

- Describe the procedure of applying make-up for a Kuchipudi dance performance.

- Describe the hair-do for Kuchipudi.

## AHARYA ABHINAYA

Aharya  abhinaya  is  one  of  the  4  forms  of  abhinaya. Aharya  reveals  the identity of a dance style belonging to a particular region, and is reflected in the material design of the costume, ornaments and other accessories.

## COSTUMES OF KUCHIPUDI IN OLDEN TIMES

Kuchipudi was originally a dance drama practised only by men. The dance dramas were categorised as Yakshaganam, Veedhi Natakam and Kalapam.

The themes of the Yakshaganam were mythological in nature. The male dancers would dress up in the characters they are portraying. For example, for portraying a king, a dancer would wear a silk dhoti, a shawl, decorated crown, earrings, necklace and shoulder ornaments.

## VEEDHI NATAKAM

In this image we can see a person standing on the stage.

<!-- image -->

Veedhi Natakam is a street theatre form based on humorous, entertaining and educational themes. The dancer would portray one 'vesham'- costume role.

<!-- image -->

## ARDHANARESHWARA VESHAM

In this image we can see a person standing and doing some action.

<!-- image -->

In Kalapams, namely Bhama Kalapam, the role of Satyabhama was played by a male dancer who was dressed in a sari that was not stitched.

In this image we can see a woman standing and holding a bag.

<!-- image -->

In  these  dance  dramas,  the  dancer  used  ornaments  made  of  wood  and where shiny coloured papers were stuck over to make the ornaments shine.

<!-- image -->

## COSTUMES OF KUCHIPUDI IN MODERN TIMES

Nowadays, Kuchipudi is both a dance drama as  well  as  a  solo  dance  form.  It  is  also practised by women. This necessitated changes in the costumes of the dance form.

For the dance dramas, the dancer will dress up in the character itself.

For the solo dance form, the traditional sari was replaced by a tailored five piece costume consisting  of  a  full  length  pleated,  fan-like front piece attached to the pajama  like costume,  a  gochi  (a  long pleated piece attached to the bottom of the pajama and the other  kaccham  end  tucked  behind  at  the waist), a blouse and a pleated vodni across the blouse.

In this image we can see two women are standing on the stage. In the background there is a wall.

<!-- image -->

In this image we can see a person standing and dancing. There is a dark background.

<!-- image -->

Kanjeevaram,  Dharmavaram  and  China  silks  are  used  for  stitching  the Kuchipudi dance costumes.

<!-- image -->

## JEWELLERY USED IN KUCHIPUDI

In this image, we can see a poster with some text and images.

<!-- image -->

Surya-prabha

The  jewellery  used  for  the  solo  performances  of  Kuchipudi  consists  of  the Temple  Jewellery  set.  Earlier,  Kuchipudi  artistes  used  to  wear  ornaments generally made up of lightweight wood known as Boorugu.Each jewellery has a specific name. They are:

-   The Chandra-prabha (moon) and the surya-prabaha (sun) are fixed on the left and right sides of the hair parting.
-   The Talai samaan emphasises the line of the forehead and hair parting.
-   The Maatal (pendants) are fixed to the ear lobes and hair.
-    A long necklace called Maanga Malai or Mutyala Haram (pearl chain).
-    A short necklace called addikai.
-    A belt around the waist known as Oddiyanam.
- A set of three nose rings-a clip for the right Bulaki, a ring decorated with jewels for the left nostril called Mukkera and a pendant that is fixed on the lower part of the nasal septum-Mukkupudaku.
-   Jimmiki or kundalu earrings.
-   Rakodi/Ragadi, an ornamentation for the false hair. Jewellery for the dance dramas is specific to the character that is being portrayed.

<!-- image -->

## GHUNGROOS USED IN KUCHIPUDI

The ghungroo used in Kuchipudi consists of small bells tied in rows on a padded  leather  strap.  The  bells  are made of brass which are about 2 cm in diameter  and  having  small  iron  balls inside  it.  Dancers  wear  them  around their  ankles.The  ghungroo  enhances the rhythm and beat of the footsteps of the dancer.Ghungroo is also known as Gajjalu.

In this image we can see a bag with some metal objects.

<!-- image -->

## MAKE-UP FOR KUCHIPUDI

In this image we can see two women dancing.

<!-- image -->

## Accessories for Make-up:

-  Panstick foundation
-  Pancake
-  Red pancake for the cheeks
-  Dark Egyptian pancake
-  Kajal
-  Eye shadows
-  Lipstick
-  Alta

## PROCEDURE FOR APPLYING MAKE-UP:

Appropriate panstick and pancake colour is applied on the face. This is followed by applying red pancake on the sides of the cheeks. The shape of the nose is emphasised using dark Egyptian pancake.

Heavy lines are drawn around the eyes, extending outwards. The eyebrows are darkened  and  elongated.  Red  and  golden  eye  shadows  are  applied  on  the upper lid.

Lipstick and long bindi complete the make-up. A red dye (Alta) is applied to the soles of the feet and the tips of the toes as well as the tips of the fingertips.

This  decoration  on  the  hands  and  feet  emphasises  the  movements  of  the hands and feet.

During  dance  dramas,  appropriate  make-up  is  applied  to  suit  the  various characters complemented with wigs, head gears, and other accessories.

<!-- image -->

## HAIR -DO

In Kuchipudi, the 'Jada' (long plaited hair)  has  an  important  role  and  is symbolical  of  the  female  pride  and grace. A full bun and a half bun are pinned at the back of the head. This is  decorated  with  orange  and  white flowers.

A Rakodi (ornament) is placed in the middle of the full bun. At the end of the  long  plaited  hair,  a  kuchulu  is attached. The kuchulu is a hair decoration  with  pompons  or  tassels on the edges.

In this image we can see a doughnut.

<!-- image -->

<!-- image -->

-   Aharya abhinaya is one of the 4 forms of abhinaya.
-   In Yakshaganam and Veedhi Natakam, the dancers would dress up in the characters they are portraying.
-   Previously, in the Kalapam, the male dancer would impersonate the female character and would dress up in a sari that was not stitched.
-   The modern costume of Kuchipudi is a five-piece tailored costume.
-   The jewellery used by the Kuchipudi dancers is known as the Temple Jewellery.
-   The Ghungroo used for Kuchipudi dance consists of bells stitched on a padded leather strap.
-   Appropriate make-up is done for the solo dancers as well as the characters to be portrayed in the dance dramas.
-   The jada- plaited hair is of symbolical importance in Kuchipudi.

<!-- image -->

<!-- image -->

1.  State whether the following statements are true or false.
2. Explain the procedure for applying make-up in Kuchipudi.
3. List three pieces of jewellery that are worn by a Kuchipudi dancer.
4. Describe the modern Kuchipudi dance costume.

|    | STATEMENTS                                                              | TRUE / FALSE   |
|----|-------------------------------------------------------------------------|----------------|
|  1 | Kajal is applied first while doing the dance make-up.                   |                |
|  2 | The modern Kuchipudi costume consists of a five-piece tailored costume. |                |
|  3 | The nose ring is an important part of the dancer's jewellery.           |                |
|  4 | The School of Music and Dance was inaugurated in 1964.                  |                |
|  5 | The Jada is the long plaited hair.                                      |                |

<!-- image -->

In this image, we can see a painting. There are musical instruments. At the bottom, there is a text.

<!-- image -->

## LEARNING OBJECTIVES

Mr M.Javhalee Forest Side SSS Boys

At the end of this chapter, learners should be able to:

<!-- image -->

Identify and name the musical instruments used in a kuchipudi dance performance.

Describe the musical instruments.

<!-- image -->

Kuchipudi dance is from the Southern part of India, and it is accompanied by traditional Carnatic music. Besides the singer rendering the songs for the Kuchipudi dance performance, the main musical instruments that are used are the mridangam, veena, flute, violin, shruti box and the nattuvangam.

In this image, we can see some text and images.

<!-- image -->

<!-- image -->

## MRIDANGAM

Mridangam is one of the main percussion instruments used in a Kuchipudi dance  performance.  It  is  an  ancient  double-headed  drum  which  was originally made of clay hence the meaning of the word Mridangam. (mrid meaning clay and angam meaning body).

In this image we can see a drum.

<!-- image -->

The Mridangam consists of a barrel-shaped shell  carved  out  of  single  piece  of  jackfruit wood or redwood. Normally, the length of a Mridangam  is  22-23  inches,  but  there  is  a specific type of Mridangam known as; Maha-Mridangam,  which  is  26  inches  in length.

The two heads of the instrument are covered with either goat skin or calf hide. The heads are connected to each other with the help of leather lacing which are tightened enough to produce resonance.

The left head (Thoppi) contains a temporary paste made from a mixture of semolina and water, and it is larger in size. This paste has to  be  removed  after  each  use  so  as  to protect the instrument from damage caused from  insects.  The  smaller  head  contains  a permanent black spot which is a mixture of boiled rice, manganese and iron filings and is  responsible  for  producing  the  various harmonics.

<!-- image -->

In this image there is a poster with some text on it.

<!-- image -->

The pitch of the Mridangam varies with its size. Larger ones produce a bass sound  whereas  smaller  one  generates  a  high  frequency  sound.  The Mridangam contains only one resonator which helps in matching the sound between both the heads.

MRIDANGAM PLAYING

In this image we can see a person is holding a drum.

<!-- image -->

The tuning of Mridangam is performed with the help of a pitch pipe, a small wooden stick (Pallu) and a small stone called (Kalu).

## VEENA

In this image we can see a musical instrument.

<!-- image -->

The Veena is a traditional string instrument used in Carnatic music. It is also  known  as  the  Saraswati  veena.  The  veena  is  about  4  feet  (nearly 120cm) in length and consists of a big round resonator that is carved out of a hollow log and Jackwood.

<!-- image -->

It has a hollow neck that is lined with 24 brass frets. At the end of the neck is a tuning box that concludes in a downward curve and a beautifully carved dragon's head.

In this image we can see a sculpture.

<!-- image -->

A gourd, which is smaller than the rounded part of the body of the Veena is fixed underneath the neck.

In this image we can see a musical instrument.

<!-- image -->

The Veena has seven strings including four main strings that pass over the frets  and are attached to the end of the resonator. The other strings are used  as  side  strings  for  rhythmic  accompaniment.  The  three  secondary strings cross the curving side bridge.

<!-- image -->

## Main strings

Secondary strings

In this image, we can see a musical instrument.

<!-- image -->

FLUTE SOUTH INDIAN FLUTE (VENU)

In this image we can see a pipe. In the background there is a watermark.

<!-- image -->

The Venu is one of the ancient transverse flutes used in Carnatic music and is made entirely of bamboo. It is classified as an aerophone, and is known as a side blown wind instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

This  flute  has  one  open  end  where  the  sound  comes  out  and  a  knotted closed end. The blow hole is set down from the closed end and followed by eight or nine finger holes that are placed closely together. Both ends of the Venu are bound near the opening and closing with various materials such as decorative tape. The tape is used to prevent the ends of the instrument from splitting or being altered by temperature.

The Venu player holds the flute horizontally from the mouth with the open end tilted slightly towards the ground while both hands are used to cover the sound holes.

## NATTUVANGAM

In this image we can see a few objects.

<!-- image -->

Nattuvangam is  the  main  instrument  in  a  Kuchipudi  dance  performance. 'Natta' means dancer and 'Anga' means body. Nattuvangam is derived from natta  and Anga.  Thus,  Nattuvangam  is  the  instrument  that  controls  the angas of the dancer.

<!-- image -->

The Nattuvangam is a pair of cymbals consisting of two round metal plates. The small metal one held in the right hand is made up of brass and the one held in the left hand is made up of iron. A thick thread made of cotton is tied to the two metals plates. The person who plays it is called the Nattuvannar.

The  Nattuvangam  reproduces  the  alternate  hard  and  soft  beats  of  the dancer's feet by striking the metal piece held in the right hand on the metal piece held in the left hand.

The Nattuvanar plays an important  role  in  a  Kuchipudi dance performance.

The Nattuvangam keeps the rhythm and enhances the intricate foot work of the dancer. In the practice class, the Talapeeta  is  used  to  keep  the rhythm of the dance.

In this image we can see a person holding a metal object.

<!-- image -->

## VIOLIN

The violin is a wooden string instrument . The violin typically has four strings and is most commonly played by drawing a bow across its strings.

In this image, we can see a violin. There is a text at the bottom of the image.

<!-- image -->

Violins are important instruments in a wide variety of musical genres. They are most prominent in the Western classical tradition and in many varieties of folk music.

<!-- image -->

The violin was first known in the 16 th century in Italy. The parts of a violin are usually made from different types of wood.

Violin was introduced in India around 1790 by the Military bandsmen of the East India Company. Balaswami Dikshitar (1789-1859) learned the instrument  from  the  army  bandmaster  and  developed  new  techniques  to suit Carnatic Music.

In the western classical tradition, the violin is supported between the chin and shoulder.

In this image we can see a person playing violin.

<!-- image -->

In India, the violin is played sitting cross-legged. The instrument points to the ground with scroll resting firmly on the ankle of the right foot. This allows the left hand to slide freely up and down the neck, without any need for the instrument to be supported by hand or chin.

In this image we can see a person sitting on the floor and playing a violin.

<!-- image -->

<!-- image -->

## SHRUTI BOX

In this image there are two wooden objects. On the left there is a wooden object and on the right there is a wooden object.

<!-- image -->

A Shruti box or Surpeti is a wind instrument. It is similar to a Harmonium and is  used  to  provide  a  drone  in  a  practice  session  or  concert  of  Indian classical music.

It  is  also  used  as  an  accompaniment  to  provide  a  drone  for  other instruments as well as vocalists.

Nowadays, electronic Shruti Boxes are commonly used.

In this image we can see a black color object.

<!-- image -->

ELECTRONIC SHRUTI BOX

<!-- image -->

POINTS TO REMEMBER

-   Mridangam is the main percussion instrument for a Kuchipudi dance performance.
-   Mridangam is an ancient double-headed drum.
-   Veena is a stringed instrument used in Carnatic music.
-   The flute of Carnatic music is known as the Venu.
-   The Nattuvangam is the main accompanying instrument for a Kuchipudi recital.
-   The Violin was first known in Italy.
-   The Violin is a stringed instrument used in the accompaniment of Kuchipudi.
-   The Shruti Box provides the drone as an accompaniment instrument for Kuchipudi.

## KEYWORDS

Percussion instrument, Accompaniment, Stringed instrument, Wind instrument, reasonance and harmonics .

<!-- image -->

<!-- image -->

1. Identify the name of the following musical instruments:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

.............................................

.............................................

.............................................

.............................................

2. Give a brief description of the following instruments:
2. (i)   Mridangam
3. (ii)  Veena
4. (iii) Nattuvangam
3. Label the various parts of the violin with the appropriate words given below:

(string, scroll, chin rest, tip, bow grip)

In this image we can see a violin.

<!-- image -->

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

Name the pioneers of Kuchipudi.

<!-- image -->

<!-- image -->

Write about the contributions of the pioneers (Trio) to the development of Kuchipudi dance.

According to the legend, Siddhendra Yogi, the founder of Kuchipudi dance, had taken a vow from the male members of the Brahmin families that they would practise the Kuchipudi art form and pass it on to other male members of their families. Many families have kept the art form alive. Amongst them are  those  who  have  preserved  and  popularised  the  art  form  with  their thorough knowledge of the dance treatises.

The three pioneers of Kuchipudi dance are known as the Kuchipudi Trio or the Kuchipudi Murthi Trayam. They are:

1. Sri Chinta Venkataramayya
2. Sri Vempati Venkata Narayana
3. Sri Vedantam Lakshmi Narayana Sastry

<!-- image -->

Chinta Venkataramayya, the creator of Kuchipudi Yakshaganas (an entire story from the Puranas told with an amalgamation of music, dance and theatrics, including a large cast of artistes).

<!-- image -->

Vempati Venkatanarayana was known for his expertise in the Kalapas, adaptation of a small episode/incident from the Bhagavatam and performed by two or three artistes.

<!-- image -->

Vedantam Lakshminarayana Sastry popularised the solo dance tradition in Kuchipudi dance.

<!-- image -->

## SRI CHINTA VENKATARAMAYYA

Sri Chinta Venkataramayya (1860-1949) is the descendent of the Chinta family group. He learnt the art from his elder brother Sri Venkataratnam who was well versed  in  dance  dramas.  He  is known to perform both male and female roles in the various dance dramas.

In this image we can see a person.

<!-- image -->

<!-- image -->

He kept the art  form  alive  by  bringing  different  family  groups  to  perform together.  These  groups  would  tour  various  regions  of  India  to  perform various  dance  dramas.  He  produced  many  dance  dramas  like  Prahlada Charitram, Usha Parinayam, Shashirekha Parinayam, Ramanatakam etc..

Sri Chinta Venkataramayya developed a systematic way of presenting the Yakshaganas and also propagated them. Since then, he came to be known as the father of the Kuchipudi Yakshaganam (Yakshagana Pitamaha).

## SRI VEMPATI VENKATANARAYANA

Sri Vempati Venkatanarayana ((1871- 1935) was known for propagating the Kalapas. He was famous for his role as Satyabhama as he  had  a  physique  much  suited  for  female roles.  He  was  also  known  for  his  role  in Gollakalapam. Another of his speciality was his role of 'Dadinnamma' in which he excelled. It is believed that when he passed away, the 'Dadinamma' role also vanished.

<!-- image -->

In this image we can see a person's face. In the background there is a wall.

<!-- image -->

## SRI VEDANTAM LAKSHMI NARAYANA SASTRY

Sri Vedantam Lakshmi Narayana Sastry (1886-1956) learnt dance from Sri Vempati  Venkatanarayana.  He  was  knowledgeable  in  both  theory  and practical aspects of dance. He is known to have popularised the solo dance tradition.

In this image we can see a person wearing a white color shirt and a white color tie.

<!-- image -->

In this image we can see a person holding a cloth.

<!-- image -->

He was the first to train female dancers and made them perform solo. He designed the first ever costume a female Kuchipudi dancer should wear. He introduced the practice of presenting individual items in Kuchipudi and built up a huge collection of solo items.He devised a performance manual for each one of the compositions that he choreographed. It was almost like a word-to-word description of the performance.

He is also known to have introduced the plate dancing in the Tarangams.

<!-- image -->

POINTS TO REMEMBER

1.  Sri Chinta Venkataramayya is known as the father of Kuchipudi Yakshaganas and is known to have popularised them.
2.  Sri Vempati Venkatanarayana was known for his expertise of female roles in the Kalapas.
3. Sri Vedantam Lakshminarayana Sastry popularised the solo dance tradition in Kuchipudi dance and introduced female dancers to Kuchipudi dance. He also introduced the plate dancing in the Tarangam.

In this image we can see a yellow color box.

<!-- image -->

<!-- image -->

<!-- image -->

1. State whether the following statements are True or False.
2. Name the Kuchipudi Trio.
3. State two contributions of Sri Vendantam Lakshmi Narayana Sastry.
4. Why is Sri Chinta Venkatanarayana known as the father of Yakshaganas?

|    | STATEMENTS                                                                        | TRUE / FALSE   |
|----|-----------------------------------------------------------------------------------|----------------|
|  1 | Sri Vempati Venkatanarayana introduced female dancers to Kuchipudi.               |                |
|  2 | Sri Chinta Venkataramayya is known as the father of Kuchipudi Yakshaganas.        |                |
|  3 | Sri Vedantam Lakshmi Narayana Sastry introduced the plate dance in the Tarangams. |                |
|  4 | Sri Vempati Venkatanarayana popularised the Kalapas.                              |                |

<!-- image -->

In this image we can see a poster with some text and designs.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Notate the pataksharas of the adavus in the notation form of Adi Tala.
- Recite and count the syllables of the prescribed series of Adavus in the three speeds of Adi Tala.

In this image I can see a box in the middle. On the left side of the box I can see few papers.

<!-- image -->

## NOTATION FORM OF ADI TALA

│ 4

o

o

| 1                                                                                          | 2                                                                                          | 3                                                                                          | 4                                                                                          | 5                                                                                          | 6                                                                                          | 7                                                                                          | 8                                                                                          |
|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
| 1 st speed                                                                                 |                                                                                            |                                                                                            |                                                                                            |                                                                                            |                                                                                            |                                                                                            |                                                                                            |
| Ta                                                                                         | Ka                                                                                         | Dhi                                                                                        | Mi                                                                                         | Ta                                                                                         | Ka                                                                                         | Jha                                                                                        | Nu                                                                                         |
| 2 nd speed                                                                                 |                                                                                            |                                                                                            |                                                                                            |                                                                                            |                                                                                            |                                                                                            |                                                                                            |
| TaKa                                                                                       | Dhimi                                                                                      | TaKa                                                                                       | Jhanu                                                                                      | TaKa                                                                                       | DhiMi                                                                                      | TaKa                                                                                       | Jhanu                                                                                      |
| 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu | 3 rd speed TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu TaKaDhiMi TaKaJhanu |

<!-- image -->

- (i)   Notation form of the Katteranattadavus having the pataksharas Tai Ta kitataka Tattai Hitta Tom - , Ta- Ta kitataka Tattai Hitta Tom -
- (ii)  Notation form of the adavus having the pataksharas Tat Tai Hitta, Tai Hitta

| SYMBOL       | | 4             | | 4                | | 4            | | 4                 | o               | o                  | o               | o                  |
|--------------|-----------------|--------------------|----------------|---------------------|-----------------|--------------------|-----------------|--------------------|
| AKSHARAKALAS | 1               | 2                  | 3              | 4                   | 5               | 6                  | 7               | 8                  |
| 1 st SPEED   | Tai             | Ta                 | Kita           | Taka                | Tat Tai         | Hitta              | Tom             | -                  |
|              | Ta-             | Ta                 | Kita           | Taka                | Tat Tai         | Hitta              | Tom             | -                  |
| 2 nd SPEED   | Tai Ta          | kitataka           | Hitta Tat Tai  | _Tom                | Ta-Ta           | kitataka           | Tat Tai Hitta   | Tom -              |
| 3 rd SPEED   | Tai Ta kitataka | Tat Tai Hitta Tom_ | Ta Ta kitataka | Tat Tai Hitta Tom _ | Tai Ta kitataka | Tat Tai Hitta Tom_ | Tai Ta kitataka | Tat Tai Hitta Tom_ |

| SYMBOL       | | 4                     | | 4                     | | 4                     | | 4                     | o                       | o                       | o                       | o                       |
|--------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|
| AKSHARAKALAS | 1                       | 2                       | 3                       | 4                       | 5                       | 6                       | 7                       | 8                       |
| 1 st SPEED   | Tattai                  | Hitta                   | Tai                     | Hitta                   | Tat tai                 | Hitta                   | Tai                     | Hitta                   |
| 2 nd SPEED   | Tattai Hitta            | Tai Hitta               | Tattai Hitta            | Tai Hitta               | Tattai Hitta            | Tai Hitta               | Tattai Hitta            | Tai Hitta               |
| 3 rd SPEED   | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tat Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta |

<!-- image -->

## (iii)   Notation form of the Muktais having the pataksharas Tadhi Gina Tom

| SYMBOL       | | 4              | | 4            | | 4            | | 4            | o              | o              | o              | o              |
|--------------|------------------|----------------|----------------|----------------|----------------|----------------|----------------|----------------|
| AKSHARAKALAS | 1                | 2              | 3              | 4              | 5              | 6              | 7              | 8              |
| 1 st SPEED   | Tadhi            | Gina           | Tom            | -              | Tadhi          | Gina           | Tom            | -              |
| 2 nd SPEED   |                  | Tom -          | Gina Tadhi     | Tom -          | Tadhi Gina     | Tom -          | Tadhi Gina     | Tom -          |
| 3 rd SPEED   | Tadhi Gina Tom - | Tadhi Gina Tom | Tadhi Gina Tom | Tadhi Gina Tom | Tadhi Gina Tom | Tadhi Gina Tom | Tadhi Gina Tom | Tadhi Gina Tom |

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

<!-- image -->

-   Notation is a way of writing Talas in a systematic way with letter, signs and symbols.
- The notation system is applied to Kuchipudi dance to notate the pataksharas of the prescribed adavus.
1.  Complete the table below with the appropriate syllables. Notation form of the adavus having the pataksharas Tat Tai Hitta, Tai Hitta.
2. Write in notation the Muktais with the syllables: Dhit Ta Tadhi Gina Tom.
3. Write in notation the pataksharas of any Chaturara Jati Adavus.

<!-- image -->

| SYMBOL       | | 4                              | | 4                     | | 4                     | | 4                     | o                       | o                       | o                                                      | o                       |
|--------------|----------------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|--------------------------------------------------------|-------------------------|
| AKSHARAKALAS | 1                                | 2                       | 3                       | 4                       | 5                       | 6                       | 7                                                      | 8                       |
| 1 st SPEED   | ..........                       | Hitta                   | Tai                     | ..........              | Tat tai                 | Hitta                   | Tai                                                    | ..........              |
| 2 nd SPEED   | Tattai Hitta                     | ..........              | Tattai Hitta            | Tai Hitta               | Tattai Hitta            | Tai Hitta               | .......... ..........                                  | Tai Hitta               |
| 3 rd SPEED   | .......... .......... .......... | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tat Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | Tat Tai Hitta Tai Hitta | .......... .......... .......... .......... .......... | Tat Tai Hitta Tai Hitta |

<!-- image -->

NOTES

<!-- image -->

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

<!-- image -->

Develop the basic skills of communicating through the medium of Kuchipudi movements.

<!-- image -->

Enact in small groups an idea or story in the sequences of movements.

Respond by reflecting on one's performance as well as that of peers.

Dance is considered a non-verbal way of communication through which an emotion, a message or a story can be conveyed. In dance, one uses the body, arms, hands, head and the face to express an idea or emotion.

Kuchipudi  is  one  of  the  dance  forms  which  combines  Natya,  Nritta  and Nritya aspects of dance.

In this image we can see a paper with some text and images.

<!-- image -->

<!-- image -->

## ACTIVITY 1

## Activity on the Nritta aspect of Kuchipudi Dance

-  Choose any instrumental music and choose a series of adavus to compose a sequence of movements.

## ACTIVITY 2

## Activity on the Nritya Aspect of Kuchipudi Dance

The link below is an Indian version of the famous song ' Do a deer, a female deer' from the movie  ' The Sound of Music' The lyrics are: Doe, a deer, a female deer Ray, a drop of golden sun Me, a name I call myself Far, a long, long way to run Sew, a needle pulling thread La, a note to follow Sew Tea, a drink with jam and bread That will bring us back to Do (oh-oh-oh) Do-re-mi-fa-so-la-ti-do So-do!

https://www.youtube.com/watch?v=YN09Vkb4x-c

- Download the above song and with the use of hand gestures, eye , head, neck movements and the various foot movements, compose this dance sequence.

<!-- image -->

## ACTIVITY 3

Activity on the Natya Aspect of Kuchipudi dance · Brainstorm childhood games.

- Enact them
- Choose a suitable music and let students enact the games based on the rhythm of the music.

## ACTIVITY 4

- Allow the students to choose a topic and let them write a script on it.
- The topic should be one where students can enact, speak, dance or even dress up in specific characters.

<!-- image -->

Guide students through the process of exploring and depicting various things.

Help students to develop their imagination and do not impose on them any idea.

<!-- image -->

In this image we can see a poster with a picture of two women dancing.

<!-- image -->

## LEARNING OBJECTIVES

At the end of this chapter, learners should be able to:

- Develop an awareness of the importance of practice.

<!-- image -->

Follow the guidelines for the practice of Kuchipudi.

<!-- image -->

- Adhere to a regular practice schedule.

<!-- image -->

Develop a positive attitude towards the practice of dance.

<!-- image -->

## PRACTICE FOR KUCHIPUDI:

Practice in dance is used as a reinforcement tool for memorisation, and it enables learners to assimilate and master new knowledge at one's own pace. By now, learners  should  have  understood  the  importance  of  practice  for  dance.  Home practice is vital, and one should adhere to a regular practice schedule.

## BENEFITS OF REGULAR PRACTICE:

In this image, we can see three circles. The circles are in different colors.

<!-- image -->

## 1. CONFIDENCE:

Regular practice leads to confidence in the way of executing the steps.

## 2. ENDURANCE:

Dancers who practice on a regular basis build on their endurance. The repetition of dance movements helps the dancer to gain more endurance.

## 3. QUALITY:

With regular practice, the quality of the dance movements is improved.

<!-- image -->

## GUIDELINES FOR DANCE PRACTICE:

- Start with a few warm-up and pre-dance exercises.
- Recapitulate the Asamyuta and Samyuta hastas.
- Recapitulate the basic dance postures namely the Vaishnava sthanaka, full- sitting position, and the Natyarambhe.
- Recite and execute the shiro bhedas, Dhristi bhedas and the Greeva bhedas.
- Ensure correct basic dance postures and body alignment.
- Recapitulate the six Pada Bhedas.
- Recite the pataksharas of the prescribed adavus for grade7,8 and 9 in the three kalas.
- Practise each adavu in the three kalas.
- Recapitulate adavus taught in grade 7, 8 and 9.
- Practise the counting of the pataksharas of the adavus of both grade 7, 8 and 9 in the three speeds of Adi T ala.
- Execute some cool- down exercises after the dance practice.

<!-- image -->

Abhinaya Darpanam:

dance treatise written by Nandikeshwara. expression.

Abhinaya:

Adi Tala:

one of the oldest Talam in Carnatic Music

system.

Ananda Tandava:

cosmic dance of Lord Shiva.

Apasmara:

dwarf demon.

Bharata Natyam:

Indian classical dance from Tamil Nadu.

Carnatic Music:

South Indian music system.

Drishti Bhedas:

eye movements.

Goddess Saraswati:

Goddess of Knowledge, music, art and

wisdom.

Greeva Bhedas:

Neck movements.

Kathak: Indian classical dance from Uttar Pradesh. Krishna: a major deity in Hinduism worshipped as the reincarnation of Hinduism.

Kuchipudi:

Indian classical dance from Andhra Pradesh. feminine aspect of dance.

Lasya:

Lord Shiva:

Hindu God,third of the Hindu Trinity. God

Lord:

Mount Kailash: famous mountain in the Himalayas, India. Mridangam: a two- headed percussion instrument used in South India.

Nataraja:

the Lord of dance.

Nattuvangam: a pair of cymbals used to give rhythm in Kuchipudi.

Natya:

dance drama.

Nritta:

pure dance movements.

Nritya:

expressional dance.

Sages:

saints.

Shiro Bhedas:

Head Movements.

Shruti Box: an instrument which works on a system of bellows.

Tandava:

masculine aspect of dance.

Veena:

an Indian string instrument.

Venu:

a South Indian flute.

Violin:

a stringed instrument played with a bow. Hindu God, the second of the Hindu Trinity. stole.

Vishnu:

Vodni:

Yamuna:

famous river in India.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->