## Information and Communications Technology

GRADE 9

<!-- image -->

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of

Ministry of Education, Tertiary Education, Science and Technology

In this image, we can see a poster with some text and some images.

<!-- image -->

## INFORMATION AND COMMUNICATIONS TECHNOLOGY PANEL

- Kaviraj Goodoory

- Coordinator, Associate Professor, MIE

- Marday Pyneandee

- Senior Lecturer, MIE

- Dr Vikash Kumar Jhurree

- Senior Lecturer, MIE

- Abdullah Mohammud Ismail Buxoo

- Educator

- Louis Daniel Clarel Berry

- Educator

- Jameel Foondun -

Educator

- Minta Hurryman

- Educator

- Mohammad Arshaad Khodabocus

- Educator

- Shunno Devi Nenduradu

- Educator

- Sarita Raggoo-Lollbeharee

- Educator

Acknowledgement

Christian Li Luen Ching

- -

Senior Lecturer, MIE

Paramaseeven Sooben

- Senior Lecturer, MIE

<!-- image -->

Design

Rakesh Sookun

- Graphic Designer

© Mauritius Institute of Education -202 1 ISBN: 978-99949-53-87-5

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources,  Tertiary  Education  and  Scientific  Research.  The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head Curriculum Implementation and Textbook Development and Evaluation provided guidance with respect to the objectives of the NCF, while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic artists who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director

Mauritius Institute of Education

## Preface

Technological advancements, particularly digital technologies such as Artificial Intelligence and Robotics are opening new opportunities in various fields. The number of appliances coming with embedded devices is constantly increasing. Digital literacy, therefore, is gaining importance as a fundamental skill. At the same time, concepts like programming and coding are now being recognized as the new literacy. The Grade 9 workbook has been developed with due consideration being given to these.

The workbook has been written with the National Curriculum Framework in mind. We have also taken into account that National Examination will be held at the end of Grade 9. The workbook has, thus, been designed to provide the knowledge, practical skills and understanding that learners will assimilate through studying Information and Communication Technology. The ICT workbook prepares the learners with ICT skills and competencies for the emerging knowledge society, helping them develop capacity to solve problems in digital environments.

The workbook consist of 9 units which are as follows:

1. Health, Safety and Ethics
2. Computer Operation and Fundamentals Internet
3. Word Processing
4. Spreadsheet
5. Internet
6. Presentation
7. Multimedia
8. Practical Problem Solving and Programming
9. Database

The workbook is learner oriented and consists of the following:

- Activities in the form of games and practical
- Suggested activities can be done by the teacher to consolidate learning
- Quick test at the end of each topic
- Summative exercise after each unit.

We believe  that  learners  should  be  engaging  in  practical  activities  not  only  one  or  two  terms  but throughout the year along with the theoretical aspects of ICT. We have, therefore, designed a workbook that will  allow  learners  to  blend  theory  and  practical. The  various  activities  ensure  that  learners  are actively involved and create learning experiences that will help them be actively engaged in the process of learning.

Throughout the workbook there are a number of colours, boxes and symbols used to facilitate learning. We had created an avatar named Tipiyu that was introduced in Grade 7. Tipiyu guided across the Grade 8 workbook. Tipiyu continues to feature in the Grade 9 workbook as well.

The Information and Communication Technology Panel

## Introduction

Hello Friends,

Tipiyu is back again!

I will guide you through the ICT Grade 9 book.

What is your name?

....................................................................................

In this image we can see a robot.

<!-- image -->

In this image, we can see a diagram. In the diagram, we can see a person, a table, a laptop, a keyboard, a mouse, a pen, a paper, a pen, a paper, a pencil, a book, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper,

<!-- image -->

Computer Operations and Fundamentals atte

ot be charged.

Plug in the AC adaptec turp on the laptop

unresponsive you

Or close applications; oraaccess shui

time Then, startthe programs name; and click the

Google Chrome

Microsoft Word (32 bit)e

Mere details

End tas

Perform hard reboot by simnply pressing the on/

offbutton to turn off the computer manually. Press and hold the power batton for 5 to 10 seconds This

actionshould onh be done as a last resort if you

have an unresponsive program

Ora

This process could cause dats

If the computer still

Sk adult to unplug the power caole from theelectrical

outlets laptop is being used

mo the ôattery

to force the system to turn off.

not be able to click down options.

keys tthe

Same hig

Night the

a

the screen are

id

UNIT 1

Computer  operations and fundamentals

## Computer Operations and Fundamentals

1

Unit

## Learning Objectives

## By the end of Unit 1, learners should be able to:

- Discuss the functions of an operating system
- List the different types of operating systems
- Demonstrate an understanding of basic troubleshooting techniques

## RECAP: Operating System (OS)

<!-- image -->

An operating system is system software that controls the hardware and allows communication between the user and the computer system.

It is the most important software in a computer system. It consists of the essential files that the computer needs to function.

## Examples of OS

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|   1 | Microsoft Windows   | Most common and used operating system in personal computers.               |
|-----|---------------------|----------------------------------------------------------------------------|
|   2 | MACOSX              | Operating system used in computers manufactured by Apple Inc.              |
|   3 | Linux               | Free operating system which can be installed on personal computers.        |
|   4 | Android             | Operating system used with Android compatible smart phones and PC tablets. |

## 1.1   Functions of an operating system

## 1. It provides a user interface.

- Modern computers have a graphical user interface (GUI) which allows the user to interact with the computer system through icons and menus.

In this image I can see the screen of a computer. On the screen I can see few icons and few text boxes.

<!-- image -->

## 2. Memory management

- It deals with the loading and running of application programs.
- It allocates memory space to programs and data.
- It keeps track of which parts of the memory are in use and which parts are free.

The image depicts a diagram illustrating the relationship between a computer system and its memory. The diagram is divided into two main sections: "Operating System" and "Data."

**Operating System:**
- The central node in the diagram is labeled "Operating System." This is the primary component of the system, which is responsible for managing the system's resources and functions.
- The "Data" section is represented by a blue circle with a white border. This indicates that the "Data" section is the part of the system that stores and manages the system's data.

**Memory:**
- The "Memory" section is represented by a yellow circle with a white border. This indicates that the "Memory" section is the part of the system that stores and manages the system's memory.

**Relationship between the two sections:**
- The "Operating System" is connected to the "Memory" by a line that runs from the "Operating System" to the "Memory

<!-- image -->

UNIT 1

Computer  operations and fundamentals

## 3. Processor management

- It allocates processor time (CPU time) to the different tasks being performed simultaneously by the computer.
- A time slice is given to each job that needs to be processed.

In this image, we can see a graph.

<!-- image -->

## 4. File management

- It manages the transfer of data and files.
- It helps us to save our work, organise our files, find files that we have saved and load files.

<!-- image -->

## 5. Hardware management (peripheral management)

- It controls all attached devices.
- It accepts and transfers data from input devices to the computer's memory.
- It makes sure that any output is sent to the correct output device.
- It manages the transfer of data between the computer's memory and backing storage devices.

## 6. System security management

- It monitors and restricts access to programs and data.
- It prevents unauthorised access to the computer system by checking usernames and passwords.

<!-- image -->

<!-- image -->

## 7. Error handling

- It deals with errors that occur when a program is being run, or when data is being transferred somewhere, and informs the user if necessary.

<!-- image -->

## Quick Test

## Fill in the blanks by selecting appropriate words from the list:

| transfer   | errors   | attached      |
|------------|----------|---------------|
| processor  | memory   | communication |

## An operating system performs the following functions:

- (a) It allows \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ between the user and the computer system.

- (b)

It allocates \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ space for programs.

- (c)

It handles \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and informs the user accordingly.

- (d)

It allocates \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ time to different tasks being carried out

by the computer.

- (e) It manages the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ of data and files.

- (f) It controls all \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ devices.

## 1.2   Types of operating systems

## (i) Single-user system

- An operating system that supports only one user at a time.

In this image we can see a person sitting on the chair and working on a laptop. On the table we can see a mobile phone, a pen and a cup. In the background we can see a wall and a plant.

<!-- image -->

UNIT 1

Computer  operations and fundamentals

## (ii)  Multi-user system

- An operating system that allows multiple users to access a computer's resources at the same time. In such a system a server and terminals are used. In the diagram below, USER 1 acts as the server.

In this image, we can see a diagram. There are two computers and a person. We can see the text on the image.

<!-- image -->

## (iii) Multi-processing system

- An operating system capable of supporting and utilising more than one computer processor.

<!-- image -->

## (iv) Multi-tasking system

- An operating system capable of allowing several programs to run at the same time.

### Image Description

The image depicts a hierarchical structure of a software application, specifically a web application. The application is named "Browser" and is part of a larger web application. The application is divided into three main sections: "Browser," "Excel," and "Process."

#### Browser:
- **Browser** is the topmost section of the application. It is represented by a rectangular box with rounded edges.
- **Excel** is located below the Browser, and it is represented by a rectangular box with rounded edges.
- **Process** is the next section of the application, and it is represented by a rectangular box with rounded edges.

#### Process:
- **Process** is the final section of the application. It is represented by a rectangular box with rounded edges.
- **Process** is connected to the "Browser" section, which is represented by a rectangular box with rounded edges.

#### Browser:

<!-- image -->

Note: A is a computer that  provides  data  to server other computers.

A terminal is a personal computer connected to a network.

<!-- image -->

## Quick Test

## Match the following:

Multi-tasking

Multi-user

Single-user

Multi-processing

## 1.3   Basic troubleshooting techniques

Troubleshooting is  the  process  of  identifying  and resolving a problem in a computer system. It is used to solve problems with hardware and software.

There  are  many  different  things  that  may  cause  a problem in your computer. Troubleshooting will always be a process of 'trial and error' . Some problems may be easy  to  fix,  while  others  may  require  several  attempts before a solution can be found.

## 1.3.1   Simple solutions to common problems

## 1.   Problem: The computer does not start

Solution 1: Check that the power cord is plugged securely into the back of the system unit and the power outlet.

One user at a time.

Several programs run at the same time.

Several users at the same time.

Several computer processors are used.

<!-- image -->

<!-- image -->

Solution 2: If the power cord is correctly plugged in, make sure that the power outlet is working. You can plug in another electrical device such as a lamp to check whether the power outlet is functioning properly.

Seek the help of an adult to try the above solutions.

<!-- image -->

<!-- image -->

UNIT 1

Computer  operations and fundamentals

Solution 3: If you are using a laptop, the battery may not be charged. Plug in the AC adapter, wait for a few minutes and then try to turn on the laptop.

## 2.   Problem: The computer freezes (becomes unresponsive)

If the computer is unresponsive, you will not be able to click anywhere on the screen, open or close applications, or access shut-down options.

Solution 1: Push the Ctrl , Alt ,  and Delete keys  at  the  same time. Then, start the Task Manager , highlight the program's name, and click the End Task button .

In this image, we can see a screenshot of a screen.

<!-- image -->

Solution 2: Perform a hard reboot by simply pressing the on/ off button to turn off the computer manually. Press and hold the power button for 5 to 10 seconds. This action should only be done as a last resort if you have an unresponsive program or a critical error. This process could cause data loss or corruption.

Solution 3: If  the  computer  still  will  not  shut  down,  ask  an adult to unplug the power cable from the electrical outlet. If a laptop is being used, remove the battery to force the system to turn off.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 3.   Problem: The printer is not working

Solution 1: Check if the printer is turned on. If not, turn it on and try again.

<!-- image -->

Solution 2 :   Ensure that all cables are properly connected. Try again.

<!-- image -->

Solution 3: Check if the printer has a paper jam. If so, remove jammed paper, close the printer and try printing again.

<!-- image -->

Note : A printer requires ink and paper to produce printouts. Therefore, before printing, check ink/toner levels and load paper in the sheet feeder.

## 4.   Problem: The mouse or keyboard has stopped working

Solution 1: If  you  are  using  a  wired  mouse  or  keyboard, make sure it is correctly plugged into the system unit. If not, plug it in properly.

<!-- image -->

Solution 2: If you are using a wireless mouse or keyboard, try changing the batteries.

<!-- image -->

## 5.   Problem: The sound is not working

Solution 1: Check the volume level. Click the audio button in the bottom-right corner of the screen to make sure that the sound is turned on and that the volume is up.

<!-- image -->

Solution 2: Check  the  cables.  Make  sure  external  speakers are plugged in, turned on and connected to the correct audio port or a USB port.

<!-- image -->

UNIT 1

Computer  operations and fundamentals

## 6.   Problem: The screen is blank

Solution 1: The computer may be in the 'Sleep' mode. Click the mouse or press any key on the keyboard to wake it up.

<!-- image -->

Solution 2: Make sure the computer is plugged in and turned on.

Solution 3: If  you are using a desktop computer, make sure the monitor cable is properly connected to the system unit and the monitor.

<!-- image -->

## 7.   Problem: All programs on the computer run slowly

Solution 1: Run a virus scanner. There may be a malware running in the background that is slowing down the computer system.

<!-- image -->

Solution 2: Your computer may be running out of hard drive space.

Try deleting any files or programs you don't need.

<!-- image -->

Run Disk Defragmenter which is a utility software designed to increase access speed by rearranging files stored on a disk.

## 8.   Problem: Accidental deletion of a file

Solution 1: Open the Recycle Bin. Right-click on the file and click on Restore .

<!-- image -->

<!-- image -->

Solution 2: Press Ctrl + Z on the keyboard to retrieve the file back.

Solution 3: Right-click where file was located. In the pop-up menu, select ' Undo Delete ' .

## Quick Test

## 1.   Match each problem to its solution:

| PROBLEM   | PROBLEM                                              |
|-----------|------------------------------------------------------|
| (a)       | No sound.                                            |
| (b)       | The printer has a paper jam.                         |
| (c)       | The computer is unresponsive and will not shut down. |
| (d)       | Wireless mouse is not working.                       |
| (e)       | Computer runs slowly.                                |
| (f)       | Screen is blank.                                     |

<!-- image -->

<!-- image -->

## SOLUTION

| (i)   | Unplug the power cable from the power outlet.        |
|-------|------------------------------------------------------|
| (ii)  | Change batteries.                                    |
| (iii) | Make sure external speakers are properly plugged in. |
| (iv)  | Press a key on the keyboard to wake up the computer. |
| (v)   | Remove paper, close printer and try printing.        |
| (vi)  | Scan your computer for viruses.                      |

UNIT 1

Computer  operations and fundamentals

## 2.   Fill in the blanks with the following words:

wired

rearranges

sound

unresponsive

troubleshooting

- (a) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is the process of identifying and resolving a problem.

- (b)

If you cannot hear\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ check the volume level.

- (c) A \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ keyboard must be correctly plugged into the system unit.

- (d) Disk Defragmenter \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ files stored on disk.

- (e)

- If a laptop becomes \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_, remove the battery to force it to turn off.

3.   Which keys should be pressed on the keyboard to start the Task Manager?

4.   Give two possible causes of a slow computer.

(1)

(2)

6.   Give 2 ways to wake up a computer which is in the sleep mode.

(1)

(2)

<!-- image -->

## 1. Fill in the blanks with the following words:

memory

Android

time

graphical

troubleshooting

Linux

processor

deletion

security

programs

- (a) A multi-processing system can support more than one computer \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (b) Modern computers have a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ user interface.

- (c) The operating system keeps track of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ usage.

- (d) In a multi-tasking system, several \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ can run at the same time.

- (e) The process of solving hardware or software problems is known as \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (f) The operating system manages system \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (g)

In processor management, a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ slice is given to each job that needs

to be processed.

- (h) An example of a free operating system for PCs is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- (i) In case of accidental \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ of a file, press Ctrl + Z to retrieve the file.

- (j) A common operating system used with smart phones is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

2. Explain three functions of an operating system.

1)

2)

3)

3. List four types of operating systems.

## END OF UNIT QUESTIONS

## 4. Complete the crossword puzzle below:

## Across

2. A popular operating system for personal computers.
5. Is the most important software in a computer system.

## Down

1. Identifying and solving a computer related problem.
3. Operating system for smart phones
4. Free operating system for personal computers

In this image we can see a chess board.

<!-- image -->

UNIT 1

Computer  operations and fundamentals

<!-- image -->

## 5. Indicate whether the following statements are True or False.

- (a) A virus scanner rearranges files stored on a disk.

[…………]

- (b) To wake up a computer from the 'sleep mode' , press a key on the keyboard.

[…………]

- (c) A graphical user interface displays icons and menus.

[…………]

- (d) Linux is an expensive operating system.

[…………]

- (e) When a computer freezes, it becomes unresponsive.

[…………]

- (f) A multi-user system supports only one user at a time.

[…………]

- (g) An operating system performs file management.

[…………]

- (h) Several users can use a single-user system at the same time.

[…………]

- (i) A paper jam prevents the printer from working properly.

[…………]

- (j) The OS allows communication between the user and the computer system.  […………]

## 6. Select the correct answer. Encircle A, B, C or D.

- (a) An example of an operating system is …………………………………

- A. MAC OS X

- B. Antivirus

- C. Paint

- D. MS Excel

- (b) If the computer does not start, …………………………………

- A. press Ctrl + Z.

- B. check whether the keyboard is properly plugged in.

- C. remove jammed paper from printer.

- D. check whether the power cord is properly plugged in.

## END OF UNIT QUESTIONS

UNIT 1

Computer  operations and fundamentals

<!-- image -->

- (c) A virus scanner …………………………………

- A. rearranges files on a disk.

- B. detects and removes malware.

- C. deletes files.

- D. checks user names and passwords.

- (d) Select one way to retrieve a deleted file.

- A. Press Alt + Ctrl + Del.

- B. Run an antivirus software.

- C. Open the Recycle Bin, select file and click on Restore.

- D. Run the Disk Defragmenter software.

- (e) Which keys should be pressed to start the Task Manager?

- A. Ctrl + Z

- B. Alt + F4

- C. Alt + Ctrl + Del

- D. Shift + Ctrl + Alt

7. Explain how you would troubleshoot the following problems.

- (a) The keyboard has stopped working.

•

•

•

•

•

- (b) The computer has become unresponsive.

•

•

•

•

•

<!-- image -->

- (c) No sound can be heard from the speakers.

•

•

•

•

•

- (d) You have deleted an important file by accident.

•

•

•

•

•

UNIT 1

Computer  operations and fundamentals

## Additional Notes

4.

lickthe Formolas Tas

File

Home

Insert fx

Insert

Function

Page Layout

AutoSum Recently Financial Logical

Text

Used

Function Library

Select Statisticalrand then click

NTIF \_

Review

View

Help

Math &amp;

[Trig

More

Name

Functions

Manager

Statistical

Engineering

Cube

Information

Compatibility

Web

0

Search

Define Name

Usein Formula

Create from Selection

COUNT

COUNTA

COUNTBLANK

COUNTIF

COVARI

COVARI

DEVSQ

EXPON[

COUNTIF(range criteria)

Counts the number cf cells within a rangethat meet the given

Tell me more

Time

Date &amp; | Lookup &amp;

Reference

Le

## Word Processing

Formulas

Data

Review

View

0

Math &amp;

More

He

Nar

Trig

Functions

Man

ETrace Precedents

Trace Dependents

FxRemove Arrows

For

## Word Processing

## Learning Objectives

## By the end of Unit 2, learners should be able to:

- Automatically generate a table of content and list of figures/tables
- Automatically generate multiple copies of the same document adapted for different recipients

## Automatically generate a table of contents and list of figures/tables

A table of contents is a list found at the start of a document with titles and subtitles with their corresponding page number. It allows the reader to go directly to a specific chapter by referring to the table of contents.

We will be using the Styles ribbon in word.

In this image I can see a page of a book.

<!-- image -->

Click on the more button as shown below to check the different styles available.

In this image there is a text box in the middle.

<!-- image -->

UNIT 2

Word Processing

Unit

2

## The following will be displayed.

In this image, we can see a table with some text and images.

<!-- image -->

- Heading 1 for main titles
- Heading 2 for subtitles

## Activity 1 - Exploring the different 'Styles'

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| STYLES RIBBON           | STEP 1                                     | STEP 2                                                          | OUTPUT   |
|-------------------------|--------------------------------------------|-----------------------------------------------------------------|----------|
| Normal Styles button    | Type the sentence 'WORD PROCESSING IS FUN' | Highlight the sentence and click on the Normal Styles button    |          |
| Nospacing Styles button | Type the sentence 'WORD PROCESSING IS FUN' | Highlight the sentence and click on the NoSpacing Styles button |          |
| Heading 1 Styles button | Type the sentence 'WORD PROCESSING IS FUN' | Highlight the sentence and click on the Heading 1 Styles button |          |

UNIT 2

Word Processing

In this image there is a text on the right side of the image.

<!-- image -->

## Creating a Table of Contents

We will create a document of 4 pages and create a table of contents as shown below

The table shows the contents of a table.

<!-- image -->

## GO THROUGH THE FOLLOWING STEPS TO GENERATE A TABLE OF CONTENTS.

STEP 1: Type the following on FOUR different pages.

Highlight the text and click on heading 1

HARDWARE

HARDWARE DEFINITION:

Highlight the text and click on heading 2

Hardware is the collective name given to the physical parts of a computer system that can be seen and touched.

## Hardware can be:

- Input devices
- Output devices
- Storage devices

## STEP 2: Type the following on page 2 of your document.

INPUT DEVICES

Highlight the text and click on heading 1

Highlight the text and click on heading 2

DEFINITION:

Input devices are those hardware devices that are used to feed data to the computer. Some common input devices are:

- Keyboard
- Mouse
- Joystick
- Scanner

STEP 3: Type the following on page 3 of your document.

OUTPUT DEVICES

DEFINITION:

Highlight the text and click on heading 1

Highlight the text and click on heading 2

Output devices are those hardware devices that display information in the form of softcopy or hardcopy.

Some common output devices are:

- Monitor
- Printer
- Speaker

STEP 4: Type the following on page 4 of your document.

STORAGE DEVICES

DEFINITION:

Highlight the text and click on heading 1

Highlight the text and click on heading 2

Storage devices are those hardware devices that are used to store {data temporarily or permanently to the computer files}.

Some common storage devices are:

- Hard disk
- Pen drive
- CD, DVD and Blu ray

<!-- image -->

## The four pages will appear as shown below.

In this image there is a table with some text on it.

<!-- image -->

STEP 5: Place the cursor at the start of the document as shown below.

In this image, we can see a table with some text.

<!-- image -->

STEP 7: Clicking on the Table of Contents button will display the options below. Select the second option ' Automatic Table 2 '

In this image, we can see a screenshot of a web page. There are some icons and text present on the image.

<!-- image -->

Check your document you will notice the Table of content (TOC) has appeared at the top of the document as shown below.

STEP 8: Save your document as ' Table of content ' .

In this image there is a table.

<!-- image -->

With the help of your teacher insert page number in the document.

<!-- image -->

## Inserting a Table of Figures

Open the document you saved as 'Table of content' . We will insert a table of figure.

STEP 1: Add a table in a new page (that is page 5) as follows.

| TYPES OF HARDWARE   | DEFINITION                                                                                    |
|---------------------|-----------------------------------------------------------------------------------------------|
| INPUT DEVICES       | Hardware devices used to feed data to the computer                                            |
| OUTPUT DEVICES      | Hardware devices that display information in the form of softcopy or hardcopy                 |
| STORAGE DEVICES     | Hardware devices that are used to store data temporarily or permanently to the computer files |

## PAGE 5

STEP 2: Add a caption to the table you just created. But first place the cursor just below the table you created as shown below.

| TYPES OF HARDWARE   | DEFINITION                                                                                    |
|---------------------|-----------------------------------------------------------------------------------------------|
| INPUT DEVICES       | Hardware devices used to feed data to the computer                                            |
| OUTPUT DEVICES      | Hardware devices that display information in the form of sohcopy or hardcopy                  |
| STORAGE DEVICES     | Hardware devices that are used to store data temporarily or permanently to the computer files |

Place cursor here

## STEP 3: Click on the Insert Caption button .

In this image, we can see a page with some text and images.

<!-- image -->

## STEP 4: Type ' hardware summary table ' as shown below.

| TYPES OF HARDWARE   | DEFINITION                                                                                    |
|---------------------|-----------------------------------------------------------------------------------------------|
| INPUT DEVICES       | Hardware devices used to feed data t0 the computer                                            |
| OUTPUT DEVICES      | Hardware devices that display information in the form of softcopy or hardcopy                 |
| STORAGE DEVICES     | Hardware devices that are used t0 store data temporarily or permanently to the computer files |

<!-- image -->

## STEP 5: Now place your cursor just after the table of content.

In this image there is a table. On the table there is a text.

<!-- image -->

| Table of Contents HARDWARE   |
|------------------------------|
| HARDWARE DEFINITION:         |
| INPUT HARDWARE               |
| DEFINITION:                  |
| OUTPUT HARDWARE              |
| DEFINITION:                  |
| STORAGE HARDWARE             |
| DEFINITION:                  |
| Place cursor here            |

## STEP 6: Click on the Insert Table of Figures button.

In this image, we can see a page with some text and images.

<!-- image -->

<!-- image -->

STEP 7: The window below will be displayed. Click on OK to insert the table of figures.

In this image, we can see a screenshot of a page.

<!-- image -->

The table of figures will be added just after the table of content on the first page of your document as shown below.

In this image there is a table.

<!-- image -->

STEP 8: Click on save button to save the necessary changes you made to the document.

## Automatically generate multiple copies of the same document adapted for different recipients

## What is mail merge?

A mail merge can be useful when a document needs to be sent to many people when needed.

A single letter (template) can be drafted and sent automatically to many people.

Note: A template is a sample document that has been pre-formatted.

For example, you could write a single letter and send it to all your friends to inform them about an event like a birthday party or a picnic.

At school, the school secretary can write a single letter and send it to all students to inform them about the annual general meeting of the PTA.

## Steps in mail merge

Performing a mail merge involves the following three main steps.

## Create a mailing list

It  contains  information  like  name,  address,  phone  number  etc...  that  you  will  use  to  fill information in the letter. An example is given below

| Surname   | FirstName   |   Grade | Section   | Address   |
|-----------|-------------|---------|-----------|-----------|
| Dulloo    | Neil        |       7 | Red       | Triolet   |
| Coowar    | Kamila      |       8 | Blue      | Vacoas    |
| August    | Mikael      |       8 | Yellow    | Melrose   |

## Create a template

The template will be the main document. It contains the text and graphics to be used. An example is given below.

Dear parent,

Responsible party of

We have great pleasure to invite you to our annual prize giving ceremony on Thursday 27 th June 2019 in the school hall. This event will celebrate the exceptional performance of our students and we are delighted to inform you that your child will be receiving a prize in acknowledgement of his hard work and achievement.

<!-- image -->

## Insert Fields to merge the two documents.

Template (main document) and mailing list combined resulting in a personalised letter for each person.

## ‹ ‹Address››

Dear parent,

Responsible party of ‹ ‹Surname›› ‹ ‹First\_Name››

We have great pleasure to invite you to our annual prize giving ceremony on Thursday 27 th June 2019 in the school hall. This  event  will  celebrate  the  exceptional  performance  of  our  students  and  we  are  delighted  to inform you that your child ‹ ‹Surname›› ‹ ‹First\_Name›› of  ‹ ‹Grade›› ‹ ‹section›› will  be  receiving  a  prize in acknowledgement of his hard work and achievement.

## Create a mail merge using WIZARD

## Part 1: Creating the mailing list

## STEP 1: Open a blank document

In this image, we can see a screenshot of a website.

<!-- image -->

STEP 2: Click on the Mailings tab and select Start Mail Merge option as shown below.

In this image, we can see a screenshot of a document.

<!-- image -->

## STEP 3: Click on the Step-by-step Mail Merge Wizard.

This is a screenshot of a web page.

<!-- image -->

STEP 4: Check that the Letters option is selected and Click on the Next: Starting document option.

In this image, we can see a screenshot of a website.

<!-- image -->

<!-- image -->

<!-- image -->

STEP 5: Check that the Use the current document option is selected and click on the Next:

In this image, we can see a screenshot of a website.

<!-- image -->

STEP 6:

Select the

Type a new list option and click on

create

.

In this image, we can see a screenshot of a website.

<!-- image -->

## STEP 7: You will obtain an address list as shown below that you can edit.

In this image, we can see a screenshot of a page. On the page, we can see a text box, a button, a list, and some other objects.

<!-- image -->

## WE WILL CUSTOMISE THE TABLE THAT WE WILL BE USING IN THE LETTER.

The table will include the following fields.

STEP 8: Click on the Customize Columns button to adapt the table to our letter.

The table can be customised by clicking on the different buttons as shown below.

In this image, we can see a table with some text and images.

<!-- image -->

1

STEP 9:

Click on

Rename button type

2

Surname and

click on

OK

<!-- image -->

button to change the field name from title to Surname.

3

In this image there is a table with some text and a few buttons.

<!-- image -->

STEP 10: Click on Last Name and click on Delete to delete the Last Name field.

In this image I can see a text box and a text box.

<!-- image -->

## STEP 11: Click on the Yes button to confirm the deletion.

The image displays a screenshot of a document titled "When you delete field 'Last Name"', any information in this field will also be deleted." The document is opened in Microsoft Word. The text is in a bold font, and the background is white. The text is in a paragraph format, and it is structured in a way that it is easy to read.

The main body of the text is written in a smaller font size, and it is aligned to the left. The text is structured in a way that it is clear and easy to understand.

Below the main body of text, there is a hyperlink that reads "YES" in bold, followed by a question mark. The hyperlink is underlined.

The document is opened in Microsoft Word, and the text is displayed in a tabular format. The table is divided into two columns, with the first column labeled "Last Name" and the second column labeled "Name". The first row of the table contains

<!-- image -->

STEP 12: Repeat steps 10 and 11 to delete all the other fields {Company Name, Address Line 1 etc.} by selecting each one in turn and deleting the fields as we will not use these fields.

STEP 13: Click on the add button, type Grade and click Ok button. 1 2 3

In this image, we can see a screenshot of a web page.

<!-- image -->

STEP 14: Repeat step 13 to add the following fields {That is, Section and Address }.

When you have added the necessary fields, they will appear as shown below, click on the Ok button

In this image, we can see a screenshot of a computer screen. On the screen, we can see a text box, a button, a list, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box, a button, a text box, a text box,

<!-- image -->

<!-- image -->

STEP 15: The table you created will look similar to the one shown below.

In this image I can see a screenshot of a page.

<!-- image -->

STEP 16: We will add some records to the database we just created that will be used in the

In this image, we can see a screenshot of a document.

<!-- image -->

STEP 17: If you want to add a record, click on the New Entry button. The final database will look as the one shown below. Click on Ok button.

In this image, we can see a table with some text and some numbers.

<!-- image -->

STEP 18: In the File name box, save the document as Students details . Then click on the Save button.

In this image I can see the screen. On the screen I can see few files and folders.

<!-- image -->

STEP 19: The database you created will look like the one shown below. Click on the Ok button.

Word will automatically save the document as a {.mdb} file, that is in Access.

In this image I can see the text on the top and bottom. I can see the text on the left side and the right side. I can see the text on the top and bottom. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the left side and the right side. I can see the text on the

<!-- image -->

<!-- image -->

## Part 2: Writing the letter

Click on the Next: Write your letter button. The table is now ready to be merged with the letter that we will write in the next step.

In this image I can see the screen of a computer. In the screen I can see the text, numbers, icons and some other things.

<!-- image -->

We will write a letter to invite parents for the prize giving ceremony of their children which will be used to merge with the database of students details that we created above:

Dear parent,

Responsible party of

We have great pleasure to invite you to our annual prize giving ceremony on Thursday 27 th June 2019 in the school hall. This event will celebrate the exceptional performance of our students and we are delighted to inform you that your child will be receiving a prize in acknowledgement of his hard work and achievement.

The event will start at 10 in the morning and guest will be seated by 9.30. We rely on your presence on that day and congratulate your child for his success.

Faithfully yours

Rector

XYZ college

## Part 3: Insert fields to merge the two documents

STEP 1: Position your cursor as shown below and click on More items button.

This image is a screenshot of a page on a website. The page is titled "Write your letter". The page has a header with the words "Write your letter" at the top. Below the header, there is a footer with the words "Write your letter".

The page contains two sections:
1. **Header Section**:
   - The header section contains the words "Write your letter" followed by a placeholder for the recipient's name.
   - The placeholder text reads "Dear parent".

2. **Footer Section**:
   - The footer section contains the words "Write your letter" followed by a placeholder for the recipient's name.
   - The placeholder text reads "Please fill in the name".

The page is structured in a way that is easy to read and understand. The header and footer sections are clearly marked with a red square and a white square, respectively. The footer section is also marked with a red square

<!-- image -->

STEP 2:

Select the

Address field and

click on

Insert button

. The address field will be inserted

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

The address field is successfully added on top as shown below.

STEP 3: To reposition the cursor, click on the close button.

In this image I can see the text on the page.

<!-- image -->

<!-- image -->

STEP 4: Reposition cursor as shown below and click on More items again. This time select the Surname field followed by the First name field.

In this image, we can see a poster with some text and images. We can also see some text and images on the poster.

<!-- image -->

Surname and First name fields successfully added as shown below.

## STEP 5: Click on the Close button to reposition the cursor.

In this image I can see the text on the page. I can also see the text on the top of the image. I can also see the text on the bottom of the image.

<!-- image -->

STEP 6: Reposition cursor as shown below and follow the previous step to add Surname and First name again.

Responsible party of

We have great pleasure to invite you to our annual prize giving ceremony on Thursday 27 th  June 2019 in the school hall. This event will celebrate the exceptional performance of our students and we are delighted to inform you that your child | will be receiving a prize in acknowledgement of his hard work and achievement. Place cursor here

<!-- image -->

STEP 7: Reposition cursor as shown below for the last time and follow the previous step to add Grade and Section .

« Address»

Dear parent,

Responsible party of « Surname» « First\_Name»

We have great pleasure to invite you to our annual prize giving ceremony on Thursday 27 th June 2019 in the school hall. This event will celebrate the exceptional performance of our students and we are delighted to inform you that your child « Surname» « First\_Name» of | will be receiving a prize in acknowledgement of his hard work and achievement. Place cursor here

## YOUR LETTER WILL LOOK SIMILAR TO THE ONE SHOWN BELOW. PAY SPECIAL ATTENTION TO THE FIELDS IN RED COLOUR. THE CONTENT FROM THE TABLE HAS BEEN MERGED INTO THE LETTER.

STEP 8: Click on the Next: Preview your letters button .

The image is an email addressed to a parent. The email is from the school and is addressed to the parent. The email is written in a formal and professional tone. The email is written in a structured format with a header, body, and footer.

The header of the email contains the parent's name, address, and email address. The body of the email is a formal letter addressed to the parent. The letter is written in a professional and formal tone, and it is addressed to the parent. The letter is written in a structured format with a header, body, and footer.

The email is written in a formal and professional tone. The letter is written in a structured format with a header, body, and footer. The header contains the parent's name, address, and email address. The body of the letter is a formal letter addressed to the parent. The letter is written in a professional and formal tone, and it is addressed to the parent.

<!-- image -->

STEP 9: You will get a preview of the letter you created. Click on Next: complete the merge .

Allows viewing different recipients of the mail merge

Triolet

Dear parent,

Characters in red are those from the table merged to the letter ]

Responsible party of

Dulloo Neil

We have great pleasure to invite you to our annual prize giving ceremony on Thursday 27 th June 2019 in the school hall. This event will celebrate the exceptional performance of our students and we are delighted to inform you that your child Dulloo Neil of 7 Red will be receiving a prize in acknowledgement of his hard work and achievement.

The event will start at 10 in the morning and guess will be seated by 9.30. We rely on your presence on that day and congratulate your child for his success.

Faithfully your

Rector

Reopient

Make changcs

<!-- image -->

## THE MAIL MERGE IS COMPLETE AND YOU WILL GET A RESULT SIMILAR TO THE ONE SHOWN BELOW.

STEP 10: Save your document as mail merge .

In this image, we can see a text and a picture of a person.

<!-- image -->

## END OF UNIT QUESTIONS

## Question 1

## Multiple choice

- (a) What tab will we use in MS-Word to access mail merge option?

- A. Home tab

- B. References tab

- C. Mailings tab

- D. Insert tab

- (b) Which of the following enables us to send the same letter to different persons?

- A. macros

- B. template

- C. mail merge

D. none

- (c) in a document?

- What Word feature indicates the number of pages, words, and characters

- A. Styles tab

- B. Table of contents

C. Font style

- D. Editing

- (d) Which of the following is not an essential component to perform a mail merge operation?

- A. Main document

- B. Data source

- C. Merge fields

- D. Power point slide

- (e) How is the information in a data source organized?

- A. Chart

- B. Matrix

C. Table

- D. Paragraphs

- (f) What feature in Word allows us to combine name and addresses with a template?

- A. document formatting

- B. database management

- C. mail merge

- D. form letters

- (g) What tab in Word allows us to create a table of contents or table of figures?

- A. Home tab

- B. References tab

- C. Mailings tab

- D. Insert tab

<!-- image -->

## END OF UNIT QUESTIONS

## Question 2

- (a) Fill in the blanks using the following words given below.

Data source Main - document - Table multiple Word - Processing - Merge Field

Mail merge is a software function describing the production of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ (and  potentially  large  numbers  of)  documents  once  that  contain  identical  formatting, layout, text, graphics, etc., and where only certain portions of each document varies.

Two files need to be created before you can merge them. The information that does not change  is  stored  in  the\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  file,  and  is  typically  created  in

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

On the other hand, the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_contains all the variable/changing

information,  in  the  form  of  fields.  The  data  that  changes  is  normally  created  in  a

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

When the Main Document and Data Source are merged, Microsoft Word replaces each \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ in the Main Document with the data from the respective field contained in the Data Source.

- (b) Give an example of how the school administration can use mail merge.

## Question 3

Mail Merge is another useful facility provided by a word processing program.

- (a) Explain the use of the mail merge feature.

- (b) List the three things needed in order to complete the mail merge process.

i.

ii.

iii.

UNIT 2

Word Processing

## Question 4

## The following question is based on the table of contents from a textbook.

| TABLE OF CONTENTS   | TABLE OF CONTENTS                         | TABLE OF CONTENTS                         | TABLE OF CONTENTS   |
|---------------------|-------------------------------------------|-------------------------------------------|---------------------|
| Section1            | ICT Theory                                | ICT Theory                                | 1                   |
| Chapter 1           | Types and components of a computer system | Types and components of a computer system | 2                   |
|                     | 1.1                                       | Hardware software and                     | 3                   |
|                     | 1.2                                       | Main components of a computer system      | 5                   |
|                     | 1.3                                       | Operating systems                         |                     |
|                     | 1.4                                       | Types of computer                         | 9                   |
|                     |                                           | Impact of emerging technologies           | 12                  |
| Chapter 2           | Input and Output devices                  | Input and Output devices                  | 13                  |
|                     |                                           | Input devices and their uses              | 14                  |
|                     | 2.2                                       | Automated capture devices                 | 19                  |
|                     | 2.3 Output devices and their uses         | 2.3 Output devices and their uses         | 23                  |
| Chapter 3           | Storage devices and media                 | Storage devices and media                 | 26                  |
|                     | 3.1                                       | Primary storage devices                   | 27                  |
|                     | 3.2                                       | Secondary storage devices                 | 30                  |
|                     | 3.3                                       | Online storage devices                    | 34                  |
| Chapter 4           | Networks and the internet                 | Networks and the internet                 |                     |
|                     | 4.1                                       | Network definition and types of network   | 38                  |
|                     | 4.2                                       | The internet                              | 41                  |
| Chapter 5           | The effects of ICT on society             | The effects of ICT on society             | 45                  |
|                     | 5.1                                       | Benefits of ICT on society                | 46                  |
|                     | 5.2                                       | Drawbacks of ICT on society               | 48                  |

- (a) On which page Chapter 3 starts?
- (b) How many chapters are there in the textbook?
- (c) What is the name of the chapter that starts on page 19?
- (d) What is the topic of sub-chapter 4.1?

## Additional Notes

UNIT 2

Word Processing

## Spreadsheet

In this image, we can see a table with some text and images.

<!-- image -->

## Spreadsheet

## Learning Objectives

## By the end of Unit 3, learners should be able to:

- Use advanced Formatting
- Use advanced Formulae
- Use advanced Functions

## 3.1  Advanced Formatting

While basic formatting enhances the way, a table looks in excel, users may require different formatting based on some conditions. Use of advanced formatting will make the table more readable. Users can easily look for required information from a formatted table.

## 3.1.1 Applying Conditional Formatting

Conditional formatting is a feature in Excel which allows you to apply formatting to a cell or a range of cells based on certain criteria.

## Example:

Worksheets A and B contain marks obtained by students in an ICT examination. The pass mark is 35. In worksheet A, a Conditional formatting feature is applied to the range of cells B3:B12. A conditional formatting rule is created to determine how many students scored less than 35 marks. If a cell value is less than 35, then the cell is formatted with a light red fill and dark red text. Worksheet B shows the formatted values after that the conditional formatting rule has been applied to it.

<!-- image -->

<!-- image -->

3

## Worksheet A

|    | A                     | B     |
|----|-----------------------|-------|
| 2  | Name                  | Marks |
| 3  | CLARISSE Jean         | 76    |
|    | ABDOOL Faiz           | 72    |
| 5  | SINGH Bobby           | 19    |
| 6  | JAIN Adi              | 95    |
|    | WONG Cindy            | 88    |
| 8  | ROSE Diana            | 34    |
| 9  | KHAN Ali              | 79    |
|    |                       | 35    |
|    | 11 [SHARMA Ayusb      | 76    |
|    | 12 |CHAN LAM Elodie   | 65    |
|    | 13   Number of Passes |       |
|    | 14 |Number of Fahures |       |

Before	formatting

<!-- image -->

## Activity 1: Creating a worksheet

1. Open Microsoft Excel .
2. Create a blank workbook .
3. Type the following data.

|    |                       | B        |           |
|----|-----------------------|----------|-----------|
|    | ICT Eraw              | ICT Eraw | ICT Eraw  |
| 2  | Name                  | Marks    | Pass/Fail |
| 3  | CLARISSE Jean         | 76       |           |
|    | ABDOOL Faiz           | 72       |           |
| 5  | SINGH Bobby           | 19       |           |
| 6  | JAIN Adi              | 95       |           |
|    | WONG Cindy            | 88       |           |
| 8  | ROSE Diana            | 34       |           |
| 9  | KHAN Ali              | 79       |           |
|    | 1o LIMHON Jason       | 35       |           |
|    | SHARMA Ayush          | 76       |           |
|    | 12  CHAN LAM Elodie   | 65       |           |
|    | 13 Number of Passes   |          |           |
|    | 14 Number of Failures |          |           |

4.

Save the workbook as 'Marks' .

## Worksheet B

|                      | B        |
|----------------------|----------|
| ICT Eram             | ICT Eram |
| 2 Name               | Marks    |
| 3 CLARISSE Jean      | 76       |
| 4 ABDOOL Faiz        | 72       |
| 5 SINGH Bobby        | 19       |
| JAIN Adi             | 95       |
| WONG Cindy           | 88       |
| 8 ROSE Diana         | 34       |
| 9 KHAN Ali           | 79       |
| 10 LIMHON Jason      | 35       |
|                      | 76       |
| 12 [CHAN LAM Elodie  | 65       |
| 13 Number of Passes  |          |
| 14 Number of Falures |          |

After	formatting

<!-- image -->

1. Open workbook 'Marks' .

The pass mark in the ICT Exam is 35 or above. Find out how many students fail the exam.

To  be  able  to  do  that,  create  a conditional  formatting  rule  for the  range  of  cells  B3:B12  that contains values less than 35.

<!-- image -->

|    | A                 | B        |           |
|----|-------------------|----------|-----------|
|    | ICT Eran          | ICT Eran | ICT Eran  |
| 2  | Nane              | Marks    | Pass/Fail |
| 3  | CLARISSE Jean     | 76       |           |
|    | ABDOOL Faiz       | 72       |           |
| 5  | SINGH Bobby       | 19       |           |
| 6  | JAIN Adi          | 95       |           |
|    | WONG Cindy        | 88       |           |
| 8  | ROSE Diana        |          |           |
|    | KHAN Ali          | 79       |           |
|    | 10 LIMHON Jason   | 35       |           |
| 11 | SHARMA Ayush      | 76       |           |
| 12 | CHAN LAM Elodie   | 65       |           |
| 13 | Number of Passes  |          |           |
| 14 | Number of Faihres |          |           |

## 2. Select range of cells B3:B12.

|                     | B        | C         |
|---------------------|----------|-----------|
| ICT Eran            | ICT Eran | ICT Eran  |
| 2 Name              | Marks    | Pass/Fail |
| 3 [CLARISSE Jean    | 76       |           |
| ABDOOL Faiz         | 72       |           |
| 5 SINGH Bobby       | 19       |           |
| 6 JAIN Adi          | 95       |           |
| 7 WONG Cindy        | 88       |           |
| 8 ROSE Diana        | 34       |           |
| KHAN Ali            | 79       |           |
|                     | 35       |           |
| 11 SHARMA Ayush     | 76       |           |
|                     | 65       |           |
| 13 Number of Passes |          |           |

Cell range B3:B12

<!-- image -->

3. In the Home tab, click the Conditional Formatting command.

In this image we can see a screenshot of a web page.

<!-- image -->

In this image, we can see a table with some text and images.

<!-- image -->

5.

A menu will appear with several rules.

Select the

Less Than rule.

In this image, we can see a table with some text and numbers.

<!-- image -->

<!-- image -->

6. A dialog box will appear. Enter 35 into the blank field.
7. Click the drop-down menu and select a formatting. In our example,
3. we will choose Light Red Fill with Dark Red Text .

In this image we can see a screenshot of a screen. In the screen we can see a text box and a button.

<!-- image -->

In this image, we can see a screenshot of a page.

<!-- image -->

In this image there is a screenshot of a web page.

<!-- image -->

9. The conditional formatting will be applied to the selected cells.

In this example, only 2 students have obtained less than 35 marks in the ICT exam.

| 4                   | B        |           |
|---------------------|----------|-----------|
| ICT Eraw            | ICT Eraw | ICT Eraw  |
| 2 Nane              | Marks    | Pass Fail |
| 3 CLARISSE Jean     | 76       |           |
| ABDOOL Faiz         | 72       |           |
| 5 SINGH Bobby_      | 19       |           |
| 6 JAIN Adi          | 95       |           |
| WONG Cindy          | 88       |           |
| 8 ROSE Diana        | 34       |           |
| 9 KHAN Ali          | 79       |           |
|                     | 35       |           |
| 11 SHARMA Ayush     | 76       |           |
| 12 CHAN LAM Elodie  | 65       |           |
| 13 Number of Passes |          |           |

10. Save the workbook as 'ConditionalMarks' .

<!-- image -->

## 1. Open workbook 'ConditionalMarks' .

|    | A                      | B        |          |
|----|------------------------|----------|----------|
|    | ICT Eram               | ICT Eram |          |
| 2  |                        | Marks    | PassFail |
| 3  | CLARISSE Jean          | 76       |          |
|    | ABDOOL Faiz            | 72       |          |
| 5  | SINGH Bobby            | 19       |          |
| 6  | JAIN Adi               | 95       |          |
|    | WONG Cindy             | 88       |          |
|    | ROSE Diana             | 34       |          |
|    | KHAN Ali               | 79       |          |
|    |                        | 35       |          |
|    | SHARMA Ayush           | 76       |          |
|    | 12 [CHAN LAM Elodie    | 65       |          |
|    | 13 [Number of Passes   |          |          |
|    | 14 |Number of Failures |          |          |

<!-- image -->

In this image, we can see a table with some text and images.

<!-- image -->

4. The conditional formatting will be removed.
5. Save the workbook as 'RemoveConditionalMarks' .

|                        | B        |           |
|------------------------|----------|-----------|
| ICT Eraw               | ICT Eraw | ICT Eraw  |
| Nane                   | Marks    | Pass/Fail |
| CLARISSE Jean          | 76       |           |
| ABDOOL Faiz            | 72       |           |
| 5 SINGH Bobby          | 19       |           |
| JAIN Adi               | 95       |           |
| WONG Cindy             | 8S       |           |
| ROSE Diana             | 34       |           |
| KHAN Ali               | 79       |           |
| 10 LIMHON Jason        | 35       |           |
| SHARMA Ayush           | 76       |           |
| 12 CHAN LAM Elodie     | 65       |           |
| 13 Number of Passes    |          |           |
| 14 |Number of Failures |          |           |

## Suggested Activity: Applying conditional formatting

Use workbook 'Marks' .

The pass mark has changed and is now 50 or above. Find out how many students have passed the exam. Follow the steps below to create a new conditional formatting rule.

1. Open 'Marks' workbook for this lesson.
2. Select B3:B12 .
3. On the Home tab, in the Styles group, click Conditional Formatting , then select Highlight Cells Rules &gt; Greater Than .
4. In the Format cells that are GREATER THAN box, type 49.
5. Change the formatting and select Green Fill with Dark Green Text.
6. Click OK .
7. Save the workbook as 'ConditionalMarks2' .
8. Close the file.

How many students have passed the exam?

## 3.1.2  Working with Styles

If  you want to keep the formatting of your worksheet consistent, then styles can be applied to a cell or a range of cells .

To apply a cell style to an active cell or range, click Cell Styles in the Styles group on the Home tab, then choose the cell style that you want to apply. You can apply more than one style to a cell or a range of cells.

<!-- image -->

## STEP BY STEP

1. Open the 'ConditionalMarks' workbook.
2. Click in cell A1 to make the cell active.

|                      | B        | C         |
|----------------------|----------|-----------|
| ICT Eram             | ICT Eram | ICT Eram  |
| 2 Name               | Marks    | Pass Fail |
| 3 CLARISSE Jean      | 76       |           |
| ABDOOL Faiz          | 72       |           |
| 5 SINGH Bobby        | 19       |           |
| 6 JAIN Adi           | 95       |           |
| WONG Cindy           | 88       |           |
| 8 ROSE Diana         | 34       |           |
| 9 KHAN Ali           | 79       |           |
| 10 LIMHON Jason      | 35       |           |
| 11 SHARMA Ayush      | 76       |           |
| 12  CHAN LAM Elodie  | 65       |           |
| 13 [Number of Passes |          |           |
| 14 Number of Faiures |          |           |
| 15                   |          |           |

In this image there is a table with some text on it.

<!-- image -->

<!-- image -->

In this image, we can see a screenshot of a page. On the page, we can see some text and images.

<!-- image -->

4. In the Titles and Headings section, select the Heading 1 style to apply it to cell A1.

In this image, we can see a chart.

<!-- image -->

<!-- image -->

Font Calibri with a bold style and a blue bottom border are applied to cell A1 .

|                       | B        |           |
|-----------------------|----------|-----------|
|                       | ICT Exam | ICT Exam  |
| 2 Name                | Marks    | Pass Fail |
| 3 CLARISSE Jean       | 76       |           |
| ABDOOL Faiz           | 72       |           |
| 5 SINGH Bobby         | 19       |           |
| 6 JAIN Adi            | 95       |           |
| WONG Cindy            | 88       |           |
| 8 ROSE Diana          | 34       |           |
| KHAN Ali              | 79       |           |
| 10 LIMHON Jason       | 35       |           |
| SHARVA Ayush          | 76       |           |
| 12 CHAN LAM Elodie    | 65       |           |
| 13 Number of Passes   |          |           |
| 14 Number of Failures |          |           |

## 5. Select cell range

A2:C2

.

|                       | B        | C         |
|-----------------------|----------|-----------|
| ICT Exam              | ICT Exam | ICT Exam  |
| 2 Name                | Marks    | Pass Fail |
| 3 CLARISSE Jean       | 76       |           |
| ABDOOL Faiz           | 72       |           |
| 5 SINGH Bobby         | 19       |           |
| 6 JAIN Adi            | 95       |           |
| WVONG Cindy           | 88       |           |
| 8 ROSE Diana          | 34       |           |
| 9 KHAN Ali            | 79       |           |
| 10 [LIMHON Jason      | 35       |           |
| 11 |SHARMA Aush       | 76       |           |
| 12 |CHAN LAM Elodie   | 65       |           |
| 13 [Number of Passes  |          |           |
| 14 Number of Failures |          |           |

In this image, we can see a table with some text and numbers.

<!-- image -->

7. A blue background with white text is applied to range of cells A2:C2 .
8. Save the workbook as 'CellsStyleMarks' .

In this image, we can see a table with some numbers and some text.

<!-- image -->

|                       | B        |          |
|-----------------------|----------|----------|
| ICT Exam              | ICT Exam | ICT Exam |
| 2 Name                | Marks    |          |
| 3 CLARISSE Jean       | 76       |          |
| ABDOOL Faiz           | 72       |          |
| 5 SINGH Bobby         | 19       |          |
| JAIN Adi              |          |          |
| WONG Cindy            | 8S       |          |
| 8                     | 34       |          |
| 9 KHAN Ali            | 79       |          |
| 10 LIMHON Jason       | 35       |          |
|                       | 76       |          |
| 12 CHAN LAM Elodie    | 63       |          |
| 13 Number of Passes   |          |          |
| 14 Number of Failures |          |          |

<!-- image -->

## 3.1.3  Formatting tables

Tables can be formatted to help organise your content and make it easier for you to locate the information you need. Excel provides many predefined (built-in) table styles that you can use to quickly format a table.

<!-- image -->

## Activity 5: Format a Table with a Quick Style

1. Open the 'CellsStyleMarks' workbook.
2. Select the cells you want to format as a table. Select cell range A2:B12 .
3. Click the Format as Table command in the Styles group on the Home tab.

In this image, we can see a table with some numbers and text.

<!-- image -->

|                      | B        |          |
|----------------------|----------|----------|
| ICT Exam             | ICT Exam | ICT Exam |
| 2 Name               | Marks    |          |
| 3 [CLARISSE Jean     | 76       |          |
| ABDOOL Faiz          | 72       |          |
| 5 [SINGH Bobby       | 19       |          |
| JAIN Adi             | 95       |          |
| WONG Cindy           | 88       |          |
| 8 ROSE Diana         | 34       |          |
| 9 KHAN Ali           | 79       |          |
| 10 ILIMHON Jason     | 35       |          |
| 11 ISHARMA Ayush     | 76       |          |
| 12 (CHAN LAMElodie   | 65       |          |
| 13 [Number of Passes |          |          |
| 14 Number of Faiures |          |          |

The image is a screenshot of a web page. The page is titled "Home" and has a placeholder text "Home" in the top left corner. Below the placeholder text, there is a search bar with the option to search for a specific term. The search bar is surrounded by a red square with a white checkmark icon.

Below the search bar, there is a list of options, which are listed in a table format. The table is divided into two columns: "Format" and "Number". The "Format" column lists the options, while the "Number" column lists the numbers.

The table is structured with the following columns:
1. "Format"
2. "Number"

The table is formatted with a white background and black text.

The table is structured with the following columns:
1. "Format"
2. "Number"

The table is formatted with a white background and black text.

<!-- image -->

4. A list of predefined table styles will appear. Click a table style to select it.
5. A dialog box will appear, confirming the range of cells you have selected for your table. The cells will appear selected in the spreadsheet, and the range will appear in the dialog box.

In this image we can see a table with some text and some images.

<!-- image -->

If necessary, change the range by selecting a new range of cells directly on your spreadsheet.

6. If your table has headers, check that the box next to My table has headers.

<!-- image -->

<!-- image -->

7. Click OK . The data will be formatted as a table in the style you chose.
8. Save the workbook as 'FormatMarks' .

In this image, we can see a table with some numbers and text.

<!-- image -->

|                       | B        |           |
|-----------------------|----------|-----------|
| ICT Exam              | ICT Exam | ICT Exam  |
| 2 Name                | Mark     | Pass/Fail |
| 3 [CLARISSE Jean      | 76       |           |
| 4 ABDOOL Faiz         | 72       |           |
| 5 [SINGH Bobby        | 19       |           |
| 6 IJAIN Adi           | 95       |           |
| 7 WONG Cindy          | 88       |           |
| 8 IROSE Diana         | 34       |           |
| 9 [KHAN Ali           | 79       |           |
| 1LIMHON Jason         | 35       |           |
| 11 ISHARMA Ayush      | 76       |           |
| 12 CHAN LAM Elodie    | 65       |           |
| 13 Number of Passes   |          |           |
| 14 Number of Failures |          |           |

## 3.2  Advanced formulae and functions

## 3.2.1  Using the IF statement to perform simple conditional calculations.

An Excel IF Statement tests a given condition and returns one value for a TRUE result,  and another value for a FALSE result.

Let's take as an example what someone should do if it is cold outside he/she should wear a jacket, if it is not cold he/she should leave the jacket at home.

The IF function in Excel is made up of 3 parts:

1. The test. ( Condition )
2. What to do if the result is yes. ( TRUE Result)
3. What to do if the result is no. ( FALSE Result)

|   1 | The test (Condition)              | Cold?                 |
|-----|-----------------------------------|-----------------------|
|   2 | What to do if the result isTRUE   | Wear jacket.          |
|   3 | What to do if the result is FALSE | Leave jacket at home. |

In Excel, it is represented as follows:

The image shows a code snippet that demonstrates how to calculate the value of a given object. The code is written in a programming language that uses a function called "Cold?" which takes in an object and returns the value of the object. The "Cold?" function is then connected to a method called "Leave jacket at home" which is connected to a method called "Wear jacket" which is connected to a method called "Leave jacket at home".

<!-- image -->

## Example:

In the flowchart below, if the answer to the question is 'TRUE' , then it tells the user to wear a jacket. If the answer is 'FALSE' , then leave the jacket at home.

The image depicts a scenario where a question is asked to the user. The question is: "Which option should I choose?" The user is asked to provide the answer to this question.

The image is structured as follows:

- **Title:** "Start"
- **Description:** "The condition is "Cold"
- **Answer:** "Leave the jacket at home"

The image is structured as follows:

- **Title:** "Start"
- **Description:** "The condition is "Cold"
- **Answer:** "Leave the jacket at home"

The image is structured as follows:

- **Title:** "Start"
- **Description:** "The condition is "Cold"
- **Answer:** "Leave the jacket at home"

The image is structured as follows:

- **Title:** "Start"
- **Description:** "The condition is "Cold"
- **Answer:** "Leave

<!-- image -->

<!-- image -->

Use workbook ' Marks '  to find who obtained a 'PASS' or a 'FAIL' .

The pass mark is 35. Those students who scored 35 or above, will obtain a 'PASS' , otherwise they will get a 'FAIL' .

1. Open the workbook ' Marks ' .

|                      | B   | C   |
|----------------------|-----|-----|
| 2 Nawe               |     |     |
| 3 CLARISSE Jean      | 76  |     |
| ABDOOL Faiz          | 72  |     |
| 5 SINGH Bobby        | 19  |     |
| 6 JAIN Adi           | 95  |     |
| 7 WONG Cindy         | 88  |     |
| 8 ROSE Diana         | 34  |     |
| 9 KHAN Ali           | 79  |     |
|                      | 35  |     |
| 11 SHARMA Ayush      | 76  |     |
| 12 CHAN LAM Elodie   | 65  |     |
| 13 Number of Passes  |     |     |
| 14 Number of Falures |     |     |

2.

Click cell C3

.

<!-- image -->

|                     | B   |                 |
|---------------------|-----|-----------------|
| 2 Nawe              |     | Marks [PassFail |
|                     | 76  |                 |
| ABDOOL Faiz         | 72  |                 |
| 5 SINGH Bobby       | 19  |                 |
| JAIN Adi            | 95  |                 |
| WONG Cindy          | 88  |                 |
| 8 ROSE Diana        | 34  |                 |
| KHAN Ali            | 79  |                 |
| 10 LIMHON Jason     | 35  |                 |
| 11 SHARMA Ayush     | 76  |                 |
| 12 CHAN LAM Elodie  | 65  |                 |
| 13 Number of Passes |     |                 |

The image is a screenshot of a web page that contains a list of various functions. The page is titled "Formulas Tab." The page is divided into two main sections: the left side and the right side.

### Left Section
- **Title:** "Formulas Tab"
- **Content:**
  - The title is highlighted in a red color.
  - Below the title, there is a text that reads "Insert Function."
  - Below this, there is a button that reads "Insert Function."
  - The button is highlighted in red.
  - The button is labeled "Formulas."
  - Below the "Insert Function" button, there is a list of functions.

### Right Section
- **Title:** "Function Library"
- **Content:**
  - The title is highlighted in a green color.
  - Below the title, there is a text that reads "Click Logical."
  - Below this, there is a button that reads "Click

<!-- image -->

In this image, we can see a page. On the page, we can see some text.

<!-- image -->

## 5. The Function Arguments dialog box opens .

In this image, we can see a screen. On the screen, we can see some text.

<!-- image -->

In the image there is a table with a table in it.

<!-- image -->

In this image, we can see a text box.

<!-- image -->

8.

In this image, we can see a table with some text.

<!-- image -->

<!-- image -->

9. Excel returns the result ' PASS ' in cell C3. In the formula bar , the function is displayed.

In this image, we can see a table with some text and numbers.

<!-- image -->

10.

|                       | B   |                  |
|-----------------------|-----|------------------|
| 2 Nane                |     | Marks  Pass/Fail |
| 3 [CLARISSE Jean      | 76  | PASS             |
| ABDOOL Faiz           | 72  |                  |
| 5 SINGH Bobby         | 19  |                  |
| JAIN Adi              | 95  |                  |
| WVONG Cindy           | 88  |                  |
| 8 ROSE Diana          | 34  |                  |
| KHAN Ali              | 79  |                  |
| 10 LIM HON Jason      | 35  |                  |
| 11 SHARMA Ayush       | 76  |                  |
| 12  CHAN LAM Elodie   | 65  |                  |
| 13                    |     |                  |
| 14 Number of Failures |     |                  |

Copy  formulae  in cell  C3  and  paste it  in  range  of  cell C4:C12.

you can also replicate the formula by using fill handle . The fill handle duplicates a cell's contents or fills a series.

<!-- image -->

<!-- image -->

11.    The  following  results  appear  in  the  remaining  cells. We  can  see  that  only  two  students obtain FAIL .

In this image, we can see a table with some text and numbers.

<!-- image -->

| A                     | B        |          |
|-----------------------|----------|----------|
| ICT Eram              | ICT Eram | ICT Eram |
| 2 Name                |          |          |
| 3 CLARISSE Jean       | 76       | PASS     |
| ABDOOL Faiz           | 72       | PASS     |
| (INGH Bobby           | 19       | FAIL     |
| JAIN Adi              | 95       | PASS     |
| WONG Cindy            |          | PASS     |
| ROSE Diana            | 34       | FAIL     |
| KHAN Ali              | 79       | PASS     |
| 10 LIMHON Jason       | 35       | PASS     |
| SHARMA Ayush          | 76       | PASS     |
| 12 CHAN LAM Elodie    | 65       | PASS     |
| 13 [Number of Passes  |          |          |
| 14 Number of Faihures |          |          |

12. SAVE the workbook as ' MarksIF ' .

## 3.2.2 Using COUNTIF

- The COUNTIF function counts the number of cells in a given range that meet a specific condition.
- The syntax for the COUNTIF function is:

## =COUNTIF( Range, Criteria )

- The Range refers to the range of cells to be counted by the formula.
- The Criteria refers to the conditions that must be met in order for the cells to be counted.
- The condition can be a number, expression, or text entry.

## For example:

Calculate how many students have passed or failed their exam.

- The range in  this  formula is the mark for each student and the criteria is  to  select  who passed and failed their exam.

<!-- image -->

## Use workbook 'MarksIF' to find how many students obtain a 'PASS' .

1. OPEN the workbook 'MarksIF' .

|                       | B        |                  |
|-----------------------|----------|------------------|
| ICT Exan              | ICT Exan | ICT Exan         |
| 2 Nane                |          | Marks  Pass Fail |
| 3 CLARISSE Jean       | 76       | PASS             |
| ABDOOL Faiz           | 72       | PASS             |
| 5 SINGH Bobby         | 19       | FAIL             |
| 6 JAIN Adi            | 95       | PASS             |
| WONG Cindy            | 88       | PASS             |
| ROSE Diana            | 34       | FAIL             |
| KHAN Ali              | 79       | PASS             |
| 10 LIM HON Jason      | 35       | PASS             |
| 11 SHARMA Ayush       | 76       | PASS             |
| 12 CHAN LAM Elodie    | 65       | PASS             |
| 13 Number of Passes   |          |                  |
| 14 Number of Failures |          |                  |

| A                      | B        |                 |
|------------------------|----------|-----------------|
| ICI Eraw               | ICI Eraw | ICI Eraw        |
| 2 Nane                 |          | Marks Pass/Fail |
| 3 CLARISSE Jean        | 76       | PASS            |
| ABDOOL Faiz            | 72       | PASS            |
| 5 SINGH Bobby          | 19       | FAIL            |
| 6 JAIN Adi             | 95       | PASS            |
| WONG Cindy             | 88       | PASS            |
| 8 ROSE Diana           | 34       | FAIL            |
| 9 KHAN Ali             | 79       | PASS            |
| 10 [LIM HON Jason      | 35       | PASS            |
| 11 SHARMA Ayush        | 76       | PASS            |
| 12 CHAN LAM Elodie     | 65       | PASS            |
| 14 [Number of Failures |          |                 |

In this image, we can see a person and some text.

<!-- image -->

<!-- image -->

## 3. Click the Formulas Tab .

The image is a screenshot of a web page that is titled "Function Library." Below is the detailed description of the image:

### Description of the Image:

#### Header:
- The header contains a title "Function Library" in a large, orange font.
- Below the title, there is a subheading that reads "Click More Functions."

#### Content:
- The main content of the page is a list of functions.
- The list includes various functions such as "File," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "Home," "

<!-- image -->

4.

Select

In this image, we can see a screenshot of a page. On the page, we can see some text and some icons.

<!-- image -->

5. In the Function Arguments dialog box, in the Range box, type range of cells C3:C12 .

In this image there is a question mark and a number.

<!-- image -->

6.

In this image, we can see a text box.

<!-- image -->

7.

In this image, we can see a screenshot of a page. On the page, we can see a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a number, a text box, a button, a text box, a

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

<!-- image -->

<!-- image -->

Using the COUNTIF function, calculate how many students scored below 35 marks. Display the result in cell C14.

1. OPEN the workbook 'MarksCountIF ' .
2. Select C14 .
3. Click the Formulas Tab. In the Function Library group, click More Functions.
4. Select  Statistical,  and  then click COUNTIF. In  the  Function  Arguments dialog box, in the Range box, select cells C3:C12. In the Criteria box, type FAIL.
5. Click OK .
6. SAVE the worksheet.

## END OF UNIT QUESTIONS

<!-- image -->

- 1 Below is a list of statements, state whether these are TRUE or FALSE. Put a tick (  ) in the appropriate column.

| Statements                                                                                                     | TRUE   | FALSE   |
|----------------------------------------------------------------------------------------------------------------|--------|---------|
| Conditional formatting allows you to apply formatting to a cell or a range of cells based on certain criteria. |        |         |
| A conditional formatting rule cannot be removed.                                                               |        |         |
| A style is a set of formatting features that can be applied only to a cell.                                    |        |         |
| The IF function in Excel is made up of 3 parts.                                                                |        |         |
| A condition can be a number, expression, or text entry.                                                        |        |         |

## 2 Multiple Choice Questions

## Select the best response for the following statements.

- (a) Which of the following functions automatically counts the number of cells in a given range that meet a specific condition?
- A. COUNTIF
- B. COUNT
- C. SUM
- D. AVERAGE
- (b) Which of the following can you use to duplicate a cell's contents or fills a series?
- A. Format Painter
- B. Font
- C. Fill handle
- D. cell range
- (c) The Cell Styles in the Styles group is found on which of the following tabs?
- A. Insert
- B. View
- C. Formulas
- D. Home
- (d) A formula that uses the COUNTIF function has 2 parts. What are they?
- A. If and Count
- B. Range and Criteria
- C. Operators and Symbols
- D. Functions and Calculations
- (e) To search for cookie in the range D4:D10, which formula would be correct?
- A. =COUNTIF (D4:D10, cookie)
- B. =COUNTIF (D4:D10, &amp;cookie)
- C. =COUNTIF (D4:D10=cookie)
- D. =COUNTIF (D4:D10,' cookie')

## END OF UNIT QUESTIONS

<!-- image -->

- 3 Open the 'SRL Charity Club' worksheet.
- (a) Type =IF(C3&gt;=900,'Free Gift' ,'') in cell D3.

|    |                  | B                |                  | 0                |
|----|------------------|------------------|------------------|------------------|
|    | SRL_Charity Club | SRL_Charity Club | SRL_Charity Club | SRL_Charity Club |
| 2  | NAME             | TOWNIILLAGE      | DONATION (RS)    | FREE GIFT?       |
| 3  | Dan Li           | Curepipe         | 1500             |                  |
|    | Kara Roberts     | Port-Louis       | 500              |                  |
| 5  | Sarah Ali        | Rose-Hill        | 800              |                  |
| 0  | Pranav Hurry     | Flacq            | 600              |                  |
|    | Michel Jonas     | Mare Dálbert     | 1200             |                  |
| 8  | Pierre Dupre     | Elacq            | 500              |                  |
| 9  | Brianna Wong     | Rose-Belle       | 600              |                  |
| 10 | Amin Sheik       | La Gaulette      | 500              |                  |
| 11 | Julia Leroy      | New-Grove        | 950              |                  |
|    | 12 Isha Parsad   | Mont-Ida         | 750              |                  |

Copy the function in cell D3 and paste it to the range of cells D4:D12.

- (b) Write the results in the worksheet above after applying the IF function in the cell range D3:D12.
- (c) Using the COUNTIF function, write a formula to find how many persons live in Flacq.

## Additional Notes

<!-- image -->

## Additional Notes

UNIT 3

Spreadsheet

Slide Master

Shde Master

Home

Rename

Master

Layout aster Layout

Layout Masters

Slide Master tal

Inser

Transtions

Animations

Aa

Themes

Review

View

Colors

Fonts effects

## Presentation

Placeholders for Title and Su

Slide

Close

Back ground

Close

Click to edit Master title style

Click to edit Master subtitle style

Placeholders for date; footer and slide number

Programs designed to help user perform specific tasks .

Help

Background Styles

Hide Background Graphics

## Presentation

## Learning Objectives

## By the end of Unit 4, learners should be able to:

- Use title and slide master to create a presentation
- Apply design templates
- Apply multiple slide masters

If you want to create a consistent professional presentation with all the slides to contain same fonts, images, colour, background, that can be formatted in one feature: The Slide Master view and they will be applied to all your slides.

## 4.1  What is Slide Master view?

Slide Master view is  a  special  feature  in  PowerPoint  that  is  used  to  format  all  slides  in  the presentation consistently and quickly. Any change made in the Slide Master affects all other slides.

In PowerPoint, when the Slide Master tab is selected, the Slide Master is the top slide. It stores formatting information about the theme, layout, background, colour, fonts, placeholders and positioning of all slides.

The Slide Master tab contains all the commands to change Slide Master and slide layouts.

Below the Slide Master are several smaller slide thumbnails. These represent individual Layout Masters like the Title slide and the Title and Content slide. Any change made to a layout master, only changes any slides using that particular layout.

Placeholders allow to add, remove or edit title and content placeholders or make formatting changes.

<!-- image -->

## 4 Unit

In this image, we can see a screenshot of a page.

<!-- image -->

## 4.2  Using Slide Master View to create a presentation

<!-- image -->

Note: In this example, we are going to use Slide Master View to create a presentation:

- to include a title and text in the slides
- to add a theme
- to use calibri font

<!-- image -->

In this image we can see a screenshot of a page.

<!-- image -->

The presentation switches into the Slide Master view. You can see the Slide Master and layout masters in the left navigation pane and a slides window on the right.

In this image we can see a screenshot of a page.

<!-- image -->

4. In the left navigation pane, Select the first slide, that is the Slide Master .

4. Click the Master Layout to choose which elements to include in the slides.
5. Click OK button. Only the Title and Text placeholders will appear in the Slide Master.

In this image, we can see a screenshot of a webpage.

<!-- image -->

In this image, we can see a screenshot of a page. On the page, we can see a list of options and a button.

<!-- image -->

<!-- image -->

6. The new Master layout will be as below:
7. Click on Themes button.

Next, to add a theme to the Master Slide and corresponding slide layouts, do the following:

In this image I can see the text on the page.

<!-- image -->

This brings up the Themes drop-down gallery.

In this image I can see a screen. On the screen I can see few images.

<!-- image -->

8. Choose on the Facet Theme in this example. This theme is applied to the Slide Master and all the slide layouts, as shown below:

In this image, we can see a screenshot of a page.

<!-- image -->

In this image we can see a robot. In the background there is a text.

<!-- image -->

<!-- image -->

9. Next, Click the Fonts command in the Background group, then select the Calibri Font.
10.    This will apply the Calibri font type to the Slide Master and the Slide layouts , as shown below:

In this image I can see the picture of a book.

<!-- image -->

In this image I can see the page of a computer. On the page I can see the text.

<!-- image -->

In this image I can see a page of a website.

<!-- image -->

12.    Save the file as 'Creating\_presentation\_with\_Slide\_Master' and of type 'PowerPoint Template'

In this image, we can see a robot. In the background, there is a text.

<!-- image -->

<!-- image -->

## 13.  Finally, Click Save .

14. Click the Close Master View button. This will get you back to Normal view .
15.  The facet theme and Calibri font type are applied to all the slides.

In this image, we can see a screenshot of a webpage. In the screenshot, we can see a page with some text and images.

<!-- image -->

In this image I can see a picture of a paper.

<!-- image -->

Every new slide added to this presentation will take on the same theme and font type as in the Slide Master .

## Tip:

It is a good idea to make any changes to your slide master and layout masters before you add slides to create your presentation.

## 4.3  Applying design templates

A  Powerpoint template is a design scheme that can contain layouts, colours, fonts, effects, background styles and content. It is saved as a potx file.

Templates can be saved and reused in future presentations.

<!-- image -->

## Activity 2: Applying a design template

1. To apply a template to a presentation, open a blank presentation.

In this image I can see a page in the web browser.

<!-- image -->

<!-- image -->

In this image, we can see a screenshot of a webpage.

<!-- image -->

3. Locate the PowerPoint template saved earlier (at step 12 of Activity 1).
4. Click Apply button.

In this image I can see the windows.

<!-- image -->

5. The template is applied to the new presentation. New slides and content can be added to the presentation.

In this image we can see a graphical image.

<!-- image -->

## Presentation task 1

Using the Master Slide that you have created and saved above in Activity 1, add

- (i) one title slide
- (ii) two Title and Content Layouts (as shown below) to create this presentation as below: You will notice that the Facet theme and Calibri font are applied to all the slides.
- (iii) Save it as Presentation Task 1

In this image, we can see a logo.

<!-- image -->

UNIT 4

Presentation

In this image, we can see a poster with some text and some images.

<!-- image -->

<!-- image -->

## To change font colour in a presentation using the Slide Master.

1. Open the Presentation Task 1
2. Click on the View tab.
3. Click the Slide Master tab . The Slide master tab will appear active but you can still access commands on different tabs of the Ribbon like Home , Insert , File as normal.
4. Select the text you want to change on the slide as below:
5. Select Home tab.

In this image I can see the text on the image.

<!-- image -->

In this image, we can see a page. On the left side, we can see a text box. On the right side, we can see a text box.

<!-- image -->

The Slide Master and the slide layouts will remain in the left navigation pane because Slide Master View is the current view.

<!-- image -->

6. Click the font color command in the font group. Choose font color Red from the menu options.
7. The change in colour will appear on all the slides in the left navigation pane.
8. Select the Slide Master tab . Close the Slide Master View

In this image, we can see a web page. On the left side, we can see a text box. On the right side, we can see a picture.

<!-- image -->

In this image, we can see a web page. On the web page, we can see some text boxes.

<!-- image -->

9. The changes in font colour are applied in all the slides in the presentation.

In this image, we can see a screenshot of a document. There are some text boxes and images in the image.

<!-- image -->

In the image there is a robot which is in white and black color. The robot is smiling and giving a pose to the camera. The background is white.

<!-- image -->

<!-- image -->

## 4.4  Applying multiple slide masters

PowerPoint allows you to create two or more Slide Masters and then choose which Master to choose for each slide in a presentation.

When  you  want  to  use  multiple  themes  in  one  presentation,  you  will  need  multiple  slide masters. Each slide master may represent a theme.

For example, in the image below, there are two slide masters with associated layouts as you would see them in the Slide Master view.

In this image we can see a paper with some text and images on it.

<!-- image -->

<!-- image -->

## Activity 3: Adding another Slide Master to a presentation

We will add a new slide master to the presentation worked out in Presentation Task 1 .

1. On the view tab, click slide master .

In this image we can see a screenshot of a file. In the file there is a text.

<!-- image -->

The new slide master appears below the existing slide master without theme, colours or effects.

Notice that this new Slide Master is numbered 2 ; since this is the second Slide Master of your presentation.

In this image we can see a paper with some text on it.

<!-- image -->

<!-- image -->

3. Repeat the steps 1 to 8 in Activity 1 to add the following to the second slide master:
2. (i) to include a title and text in the slides
3. (ii) to add a theme ' slice '
4. To use Arial Font

Note: Make sure you have selected the Slide Master 2 in the left navigation pane

5. To use a background style 11

From the Background group of the Slide Master tab

In this image, we can see a page with some text and images.

<!-- image -->

<!-- image -->

6. To add an image of ' application program ' (Access the Insert tab of the Ribbon, Choose Online Pictures )
2. The new slide master gets added along the selected format applied as shown below:

In this image I can see the page of a web page. On the page I can see the text.

<!-- image -->

7. Click Save .
8. Click the Close Master View button. This would get you back to the Normal view.
9. Access the Home Tab of the Ribbon and click New Slide button. This brings up the drop down gallery as shown below.

In this image, we can see a screenshot of a webpage.

<!-- image -->

You will notice that there are now two Slide Masters within the drop-down gallery with two different themes (Facet and Slice). When you are adding slides to your presentation, it allows you to choose any of these two themes.

<!-- image -->

## Presentation task 2

Using the second Master Slide that you have created and saved in Activity 3, add

- (i) one Title slide
- (ii) two Title and Content layouts to the existing presentation as follows:
- (iii) Save it as Presentation task 2 .

In this image we can see a poster with some text and a logo.

<!-- image -->

In this image, we can see a screen with some text and icons.

<!-- image -->

In this image, we can see a picture of a tablet. There are some icons and text on the image.

<!-- image -->

The presentation with two different themes and layouts are used in one presentation (using two sets of slide masters). It will appear as below:

In this image, we can see a picture of a paper with some text and images.

<!-- image -->

## END OF UNIT QUESTIONS

UNIT 4

Presentation

<!-- image -->

## 1. Choose the correct answer by encircling the appropriate answer.

- (a)

- The Slide Master feature is found in the tab.

- A. Transitions

- B. Animations

- C. View

- D. Home

- (b) If a logo needs to be inserted in the same position on every slide, it can be inserted

- in the

feature.

- A. Handout Master

- B. Slide Master

- C. Notes Master

- D. Animation

- (c) To be able to reuse a design scheme  in future, it can be saved as  a

- .

- A. Presentation

- B. Template

- C. PDF

- D. Slideshow

## 2. Tick (  ) True or False next to each of these statements.

|                                                                               | TRUE   | FALSE   |
|-------------------------------------------------------------------------------|--------|---------|
| The Slide Master view is used to format all slides in a presentation quickly. |        |         |
| Changes made in the Slide Master will not be updated in other slides.         |        |         |
| Only one Slide Master can be used in a presentation.                          |        |         |
| The Slide Master is found on top of all the slides in the Slide Master view.  |        |         |
| The layout masters are controlled by the Slide Master.                        |        |         |

<!-- image -->

## 3. Complete each sentence below using one item from the list given at the bottom.

tab

below

above

left themes

Slide Master

Master Layout

right

- (a) The

view is a special feature that is used to format

- all slides consistently.

- (b) The  Slide  Master

contains  all  the  commands  to

- change slide master and layouts.

- (c) In  the command, we choose the elements to

include in the slide.

- (d)

- Layout masters are found the Slide Master.

- (e) The Slide Master is found in the navigation pane.

- (f) Two  Slide  Masters  can  be  available  in  a  presentation  with  two  different

.

## END OF UNIT QUESTIONS

<!-- image -->

<!-- image -->

4. Label the different parts of the Slide Master View with the words below:

In this image, we can see a table with some text and images.

<!-- image -->

<!-- image -->

5. What is the Slide Master View?

6. (a) What is a PowerPoint template?

- (b) State how a template is useful to create PowerPoint presentations.

## Additional Notes

UNIT 4

Presentation

YAHOOI

lon

Don uners

Internet

## Internet

## Learning Objectives

## By the end of Unit 5, learners should be able to:

- Distinguish between different types of network, e.g. based on size and purpose
- Distinguish between different network topologies
- Differentiate between Intranet and Extranet
- List various network components and explain their importance
- Propose network components for a particular network
- Engage in e-discussions using the internet
- Create a website

## 5.1  Network Components

<!-- image -->

## Network Interface Card (NIC)

The Network Interface Card (NIC) is a component that takes information from the computer and sends it out onto the network. It may be integrated into the computer's motherboard or may be a separate card.

Recall

A computer network is a set of two or more computers connected together for the purpose of sharing resources..

## Internet Service Provider (ISP)

An Internet Service Provider (ISP) is a company that provides access to the Internet.

In this image we can see a part of a computer.

<!-- image -->

UNIT 5

Internet

Unit

5

<!-- image -->

## WiFi

It  is  the  name  of  the  most  popular  wireless  networking  technology that allows devices such as computers (laptops and desktops), mobile devices (smart phones and tablet PCs), and other equipment (printers and video cameras) to interface with the Internet. It uses radio waves to provide wireless high-speed Internet.

## Modem

A modem is a hardware that allows a computer to send and receive data over a communication link or a cable.

## Router

A router is  a  hardware  that  allows  two  or  more networks  to  be  connected.  For  example,  the  router allows  communication  between  your  local  home network  -  i.e.  your  personal  computers  and  other connected devices - and the Internet.

<!-- image -->

To  access  to  the  internet,  the  router  must  be  connected  to  a  MODEM.  Today  a  combined modem/router unit performs both these functions in one device.

## Firewall

A firewall is a software or  a  hardware that  prevents  unauthorised  access  to  or from  a  private  network  by  monitoring  and controlling all incoming and outgoing network traffic.

<!-- image -->

<!-- image -->

## Quick Test

## Match the following network components with their appropriate definitions.

NIC

It  is  a  software  or  a  hardware  that  prevents unauthorised access to or from a private network.

ISP

WiFi

MODEM

Router

Firewall

## 5.2 Types of Networks

## 5.2.1  Personal Area Network

PAN (Personal  Area  Network)  -  A Personal Area Network is  a  connection of devices for an individual person within a small office or room.  A  typical  PAN  would  include  one  or more  computers,  smart  phones,  tablets  and other peripheral devices.

It  is  a  hardware  that  allows  a  computer  to  send and receive data over a communication a cable.

It is a hardware that allows two or more networks to be connected.

It  is  the  company that provides you with access to the Internet.

It is a component that takes information from the computer and sends it out onto the network.

It uses radio waves to provide wireless high-speed Internet.

In this image we can see a projector, a laptop, a pen and a camera.

<!-- image -->

## Proposed network component(s) for PAN

Wireless PAN is most commonly achieved by using Bluetooth (wireless technology used over short distances) which provides a range of a few meters.

Wired PAN is mostly done by using USB ports.

## 5.2.2  Local Area Network

LAN (Local  Area  Network)  -  A Local  Area Network is  a  geographically  small  computer network. It can be in a single room, a building or a group of buildings shared by many users. E.g. A school network.

## Proposed network components for LAN

## 1. Network Interface Card

The NIC can support both wireless and wired networks.

## 2. Interconnection

Connections can be done by using cables or Wireless Access Points (WAP) .

Network cables are the wires which carry the information between the different computers in a wired LAN.

For WAP, antennas are used to send out radio waves to computers which are found in the wireless LAN.

## 5.2.3  Metropolitan Area Network

MAN (Metropolitan Area Network) -The Metropolitan Area  Network is a network designed for a larger geographical area such as a town or city. Its main purpose is to connect LANs together.

Metropolitan Area Network (MAN)

In this image, we can see a diagram.

<!-- image -->

## Proposed Network components for MAN

Uses the same components as in LANs and WANs.

In this image there is a diagram, in the diagram there are two objects, one is a laptop and the other is a computer.

<!-- image -->

## 5.2.4  Wide Area Network

WAN (Wide  Area  Network)  -  A Wide  Area Network is  a  network that spans over a very large geographical  area.  It  can  connect  computers across the country or around the world.

## Proposed Network components for WAN

## 1. Interconnection

It can be done by using cables or Wireless Access Points.

## 2. Server

It  is  a  powerful  computer which organizes and manages the communication around the network. It also controls access to the files which are stored in a central location.

## 3. An Internet connection

It can be via a modem or via a modem/router.

## 4. Firewall

The firewall is used to block any unauthorized access.

## 5.2.5  Storage Area Network

SAN (Storage Area Network) - A Storage Area Network (SAN) is a network of storage devices accessible  to  multiple  servers.  It  can  span  over  a  large  geographical  area  and  is  useful  for companies with many branches.

## Proposed Network components for SAN

Storage Area Network is made up of components such as servers, cables, and storage devices.

<!-- image -->

<!-- image -->

UNIT 5

Internet

<!-- image -->

## 5.2.6  Virtual Private Network

VPN  A virtual  private  network (VPN) allows a user to create a secure connection over the Internet (public network) to access a private network. For example, VPN allows remote users and regional offices to access the company's head-office applications and resources.

## Proposed Network components for VPN

## 1. VPN Server

The VPN server acts as a connection point for the VPN users who are at a remote location.

## 2. Router

The VPN server will use the router to provide services by providing remote access to clients.

## 3. An Internet connection

Client using the VPN network must have an Internet connection to access the VPN server.

## 4. Firewall

The firewall is used to block unauthorized access to the VPN server.

In this image, we can see a network with two computers and we can see a blue box and a blue box.

<!-- image -->

UNIT 5

Internet

| Types of network                                     | PAN LAN                                         | MAN                            | WAN                                                 | SAN                                                          | VPN                                                                            |
|------------------------------------------------------|-------------------------------------------------|--------------------------------|-----------------------------------------------------|--------------------------------------------------------------|--------------------------------------------------------------------------------|
| Size Limited to a room                               | Limited to a building or a single site          | Limited to a city              | Countrywide or Worldwide                            | Worldwide                                                    | Worldwide                                                                      |
| Purpose Connecting devices small for a single person | in a room Connecting devices within a building. | Connecting LANs across a city. | Connecting network across the country or the World. | Connects storage devices to make them accessible to servers. | A private network accessible over a public network. To protect online privacy. |

## Quick Test

Fill in the blanks with the given words.

- i) A is a computer network that can be in a single room, a building or a group of buildings shared by many users.
2. ii) A network designed for a larger geographical area such as a town is known

as

.

- iii) A is a network of storage devices accessible to multiple servers.
- iv) is a connection of devices for an individual person within a small
- A office.

- v)

- A allows a user to create a secure connection over the Internet

(public network) to access a private network.

- vi) or around the world.

- A is a network that can connect computers across the country

## 5.3  Network topologies

## What is a network topology?

Network topology refers to the physical arrangement of a network. It defines the way different nodes are placed and interconnected with each other.

(A node can be a computer or some other devices, such as a printer.)

There are five main types of network topologies namely:

- i. Bus

- ii. Ring

- iii. Star

- iv. Mesh

- v. Tree.

## 5.3.1  Bus topology

Bus  topology  is  a  network  type  in which every node is connected to a single cable (bus).

In this image we can see a diagram.

<!-- image -->

In this image we can see a diagram.

<!-- image -->

## 5.3.2  Ring topology

It  is  called  ring  topology  because  each node is connected to another node forming a circular arrangement.

## 5.3.3  Star Topology

In the star topology, all nodes are connected to a central server.

In this image there are a few objects.

<!-- image -->

In this image we can see a diagram. In the diagram we can see a diagram of a computer.

<!-- image -->

## 5.3.4 Mesh Topology

In a mesh topology, all nodes or devices are connected to each other.

## 5.3.5  Tree Topology

The tree topology is also known as the hierarchical topology  where  many  connected  elements  are arranged like the branches of a tree.

In this image, we can see a diagram. There are some lines and symbols.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Topology   | Information Transfer                                                     | Expansion                                                                                                                         | Troubleshooting                                                                                                                                                                                    | Used for   |
|------------|--------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------|
| Bus        | One computer at a time sends information along the cable.                | To add a computer, you must shut down the network.                                                                                | If one computer malfunctions, the entire network goes down.                                                                                                                                        | LAN        |
| Ring       | Information goes around the ring until it reaches the correct computer.  | The network is shut down until the new device is added.                                                                           | If there's a break in the cable or an error in the network, information continues to transfer through the rest of the ring until reaching the point of the break. This makes troubleshooting easy. | LAN        |
| Star       | All information passes through the central network connection.           | Add a new computer by plugging in a new cable.                                                                                    | Whenonecomputer goes down, the rest of the network is unaffected. If the central computer goes down, then the network is down.                                                                     | LAN        |
| Mesh       | Data sent from one computer is received by all the other computers.      | To add a new computer, plug one or more cables depending on the number of computers to which the new device will be connected to. | Troubleshooting is most difficult because information can flow in different routes.                                                                                                                | WAN        |
| Tree       | A transmission from any computer can be received by all other computers. | It is simple to install and extend the network by simply plug in the new device.                                                  | Troubleshooting is easy by checking the branch which is not working.                                                                                                                               | WAN        |

## Quick Test

## Fill in the blanks with the given words.

|      | Bus                                                             | Ring                                                            | Star                                                            | Mesh                                                            | Tree                                                            |
|------|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|
| i)   | The topology is also known as the hierarchical topology.        | The topology is also known as the hierarchical topology.        | The topology is also known as the hierarchical topology.        | The topology is also known as the hierarchical topology.        | The topology is also known as the hierarchical topology.        |
| ii)  | In the topology, all nodes are connected to a central server.   | In the topology, all nodes are connected to a central server.   | In the topology, all nodes are connected to a central server.   | In the topology, all nodes are connected to a central server.   | In the topology, all nodes are connected to a central server.   |
| iii) | The topology is a network type in which every node is connected | The topology is a network type in which every node is connected | The topology is a network type in which every node is connected | The topology is a network type in which every node is connected | The topology is a network type in which every node is connected |
| iv)  | All nodes or devices are connected to each other in a topology. | All nodes or devices are connected to each other in a topology. | All nodes or devices are connected to each other in a topology. | All nodes or devices are connected to each other in a topology. | All nodes or devices are connected to each other in a topology. |
| v)   | In a topology, each node is connected to another node forming a | In a topology, each node is connected to another node forming a | In a topology, each node is connected to another node forming a | In a topology, each node is connected to another node forming a | In a topology, each node is connected to another node forming a |

## 5.4  Intranet and Extranet

An intranet is  a  private  network  that  is  accessible  to  only  people  in  an  organisation. For  example:  In  a  school  intranet,  educators  can  communicate  between  themselves,  share information and collaborate.

An extranet is also a private network that allows outsiders (extra) to communicate with users of an intranet. For example: Suppliers can communicate with companies.

| Intranet                                                                                        |                                                                                  | Extranet   |
|-------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|------------|
| Internal employees of an organisation.                                                          | People external to the organisation such as customers and suppliers can connect. | User       |
| Internal communication like chatting and videoconferencing. Sharing of documents.               | Sending emails to customers or checking orders from suppliers.                   | Usage      |
| High security. Uses username and password to identify the user and give access to the Intranet. | UsesVPNfor secured communication                                                 | Security   |

UNIT 5

Internet

## Quick Test

## State whether the following statements are True (T) or False (F).

- i) An intranet is a private network that is accessible to only people in an organisation.

- ( )

- ii)

- An extranet is a public network. ( )

- iii)

- An intranet uses VPN for secured communication. ( )

- iv)

- Suppliers can use extranet to communicate with an organisation. ( )

- v) Intranet. ( )

- Every employee in an organisation uses his/her username and password to access the

## 5.5 Engage in E-discussion on the Internet

E-discussion is an online conversation among a group of people. The conversation can be in the form of text, audio or videos. Requirements for E-discussion are:

- Internet connection
- Web  tools  such  as  videoconferencing,  podcasting,  vodcasting,  wiki,  blogs,  social networking, chat and forum.
- Participants

## Participants

People engaged (involved actively) in the online discussion are called participants.

Their contributions can be in terms of:

- Response to posts
- Sharing of views and experiences

## 5.5.1 Videoconferencing

Videoconferencing is a live visual communication between two or more people that are from different locations. The communication is done using computer networks. Examples of popular videoconferencing software are Skype and WhatsApp.

In this image, we can see a cartoon robot. In the background, there is a text.

<!-- image -->

## 5.5.2  Podcasting/Vodcasting

Podcasting is a free web service that makes audio files available for streaming and downloading. Subscribers to the podcast will receive notifications of new audio files added to the websites. When a video file is uploaded and distributed, it is called Vodcast .

## Example of local websites that offers podcast:

The image is a screenshot of a webpage. The webpage is designed for a social media platform. The main section of the page is divided into two main sections: the header and the footer.

### Header Section
- The header is located at the top of the page. It contains a logo and a URL. The logo is a red circle with a white "D" inside of it. The URL is "https://www.express.com/".
- Below the header, there is a section labeled "Description". This section contains a list of three items: "1. Website Sites".
- The second section is labeled "2. Website Sites".

### Footer Section
- The footer is located at the bottom of the page. It contains a URL and a link to the website. The URL is "https://www.express.com/".
- The footer also contains a section labeled "RSS Feed". This section

<!-- image -->

UNIT 5

Internet

<!-- image -->

With the help of your teacher, search for three more websites that offers Podcast and note them down below:

- 1: http://www.
- 2: http://www.
- 3: http://www.

<!-- image -->

With the help of your teacher listen or view a podcast/vodcast and fill in the blank spaces below

Web site link:

Podcast type: Audio

Title of podcast:

or video

<!-- image -->

<!-- image -->

(put a tick in the appropriate box)

## Step2:

<!-- image -->

## 5.5.3 Wiki

A Wiki is a website that allows internet users to view, add, delete and modify its contents. The most popular Wiki is Wikipedia. It is considered as an online encyclopaedia.

<!-- image -->

## Activity 1 - Working with Wikipedia

## Step 1:

## Visit Wikipedia.org

In this image I can see the text on the top and bottom. I can see the text on the left side and the right side. I can see the text on the top and bottom.

<!-- image -->

In the search text box, type 'Mauritius' .

In the image there is a screenshot of a webpage.

<!-- image -->

## Wikipedia will display the articles related to Mauritius

In this image I can see the sky, clouds and the water. In the water I can see the boats.

<!-- image -->

## Step 3:

Scroll down the web page to reach the content section. The content section displays hyperlink where you can go to a specific part of the article.

In this image, we can see a table with some text.

<!-- image -->

## Step 4:

Search for 'Cuisine' hyperlink and click on it

In this image, we can see some text and numbers.

<!-- image -->

## The following will appear on your screen

<!-- image -->

## Step 5:

## To contribute (edit) to this part, click on edit

<!-- image -->

The following will appear on your screen and click on Start Editing

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

## Step 6:

Add content about Mauritian Cuisine in the space provided on your screen.

In this image there is a page with some text on it.

<!-- image -->

## Step 7:

## With the help of your teacher add content

## E.g. of contents can be:

## Example 1:

Alouda is  a  delicious  cold  beverage  made  with  milk,  basil  seeds  and  agar-agar  jelly which is especially refreshing on a hot summer day.

## Example 2:

Rougaille or rougail is  one of the classic Mauritian dishes that everyone on the island loves. It is essentially a tomato-based dish, with incredibly rich flavours thanks to the combination of spices used.

<!-- image -->

## Step 8:

## Publish changes

Scroll down the page and click on Publish

The image is a screenshot of a webpage, which is displaying a page titled "publish changes". The page is divided into three main sections: "publish changes", "show preview", and "show changes".

### Page Layout and Structure

- **Title:** The top section of the page is titled "publish changes".
- **Subsection:** The second section is titled "show preview".
- **Subsection:** The third section is titled "show changes".

### Content and Content Analysis

#### Title: "publish changes"
- The title is in bold, making it stand out.
- The subsection "show preview" suggests that the content is being displayed in a preview format, which is common in user experiences.

#### Subsection: "show changes"
- The subsection "show changes" indicates that the content is being displayed in a way that allows users to view the changes.
- The subsection "show changes" is

<!-- image -->

## Step 9:

Go back to the Cuisine hyperlink and view your text in this section

<!-- image -->

Note: For the change to be permanent, you need to sign in to Wikipedia.

In this image we can see a cartoon robot. The robot is smiling and giving a thumbs up gesture.

<!-- image -->

## 5.5.4 Blogs

A blog or web log is like an online journal where a person can write his personal opinions or thoughts. The blog is normally public. Someone who writes on blogs is called a blogger.

## Good practice on social networking sites:

- Do not share personal details like date of birth, telephone number and home address to strangers
- Do not share explicit photos online

•

Do not click on suspicious links.

UNIT 5

Internet

In this image, we can see a cartoon image. In the cartoon image, we can see a robot. We can also see some text.

<!-- image -->

Social networking is an online service where people can stay in touch with family, friends and customers. Some of the different ways to communicate on social networking sites are:

- Posts and comments
- Video call
- Instant messaging

Some of the most common social networking web sites are:

1. Facebook
2. YouTube
3. Instagram
4. Twitter
5. WhatsApp

<!-- image -->

## 5.5.6 Chat

It involves two or more people communicating together in a chat room.  The chat room offers textual, audio and video communication facilities. One needs to sign in to join a chat room.

An example of an online chat room is https://tinychat.com

## 5.5.7 Online Forum

Online forums are  websites  used  for  debates  and  online  discussion.    People  contribute  to the debate by posting messages. Online forums are also called newsgroups. Administrators monitor all discussions and you need to sign in to be able to contribute to online forums.

<!-- image -->

In this image we can see a robot. In the background there is a text.

<!-- image -->

## Quick Test

## Match the following computer terms with their appropriate definition.

Videoconferencing

It is a website used for debates and online discussion where people contribute by posting messages.

Podcast

Vodcast

Wiki

Blog

Social Network

Chat

Online Forum

Wikipedia is an example.

A free web service that makes audio files available for streaming and downloading.

It involves two or more people communicating together in a chat room.

It is a live visual communication between two or more people that are from different locations.

It is an online service where people can stay in touch with family, friends and customers.

A free web service that makes video files available for streaming and downloading.

It is an online journal where a person can write his personal opinions or thoughts.

UNIT 5

Internet

## 5.6  Create a web site

A website is a group of web pages that are connected together.

A webpage is part of the website that contains specific information.

To create a website/web page we will use a computer language called HTML .

## What is HTML?

HTML stands  for  Hyper  Text  Markup  Language.  It  is  a  computer  language  used  to  create websites. HTML documents are files that contain tags and text.

A tag is an instruction written in a text file that is given to the web browser. The web browser will interpret the tags and show the contents of the web site on the screen. It is recognized by the &lt;&gt; symbol. E.g. &lt;HTML&gt;.

A tag can be an opening tag or a closing tag. &lt;body&gt; is an example of an opening tag and &lt;/body&gt; is an example of a closing tag.

## Steps to create a simple web site

1. Open a blank text file
2. Write down HTML tags as shown below
3. Save text file and open in web browser

In this image, we can see a file with some text and images.

<!-- image -->

<!-- image -->

3. Display in browser

In this image, we can see a cartoon image. In the cartoon image, we can see a person. We can also see some text.

<!-- image -->

<!-- image -->

## Activity 1: Creating a simple website

In this activity we will create a simple web site with text and a background colour.

Step 1:

## Open a blank Notepad

In this image, we can see a screenshot of a computer screen.

<!-- image -->

Step 2:

Type the following tags in the blank Notepad

Step 3:

In this image, we can see a text in the middle.

<!-- image -->

Save your text file as

'website.html'

The image is a screenshot of a document, which appears to be a file. The file is titled "File" and has a subtitle "Date modified." The date is "09-Apr-19 10:36." The file is opened in a program that is likely a text editor or a similar tool.

The file has several sections, each with a different content. The first section is labeled "Active," and it contains a list of folders. The folders are labeled "File," "Documents," "Pictures," "Music," "Video," and "Voice Recorder."

The second section is labeled "Active," and it contains a list of folders. The folders are labeled "File," "Documents," "Pictures," "Music," "Video," and "Voice Recorder."

The third section is labeled "Active," and it contains a list of folders. The folders are labeled "File," "Documents," "Pict

<!-- image -->

## Step 4:

Double click on the website icon to open your first web site and it should appear as shown.

In this image we can see a page with some text on it.

<!-- image -->

Note: To get your website back in HTML format right click on and choose open with Notepad website

The icon of the file should appear like this.

<!-- image -->

If you are using other web browsers that icon will take the default web browser of your computer.

<!-- image -->

In this image, we can see a robot. There is a speech bubble in the image.

<!-- image -->

&lt;head&gt;

&lt;title) Home Page &lt;/title)

| Tags                                                                              | Descriptions   |
|-----------------------------------------------------------------------------------|----------------|
| <head> defines information about the website. E.g giving a title to the web site. | It             |
| It gives a title to the website. In this case it is'Home Page'.                   | <title>        |

In this image, we can see a list of different options.

<!-- image -->

&lt;BODY BGCOLOR ="PINK" &gt;

size = "20"&gt; MY FIRST WEBSITE &lt;lfont&gt; &lt;br&gt; size "16"&gt;My name is Tipiyu &lt;lfont&gt;&lt;/B&gt; &lt;br&gt; size = "14"&gt;I am 14 years old &lt;/fontvk/I&gt; &lt;br&gt;

UNIT 5

Internet

| Tags        | Descriptions                           |
|-------------|----------------------------------------|
| <body>      | videos and hyperlinks.'bgcolor'defines |
| <p>         | It means paragraph                     |
| <B>         | Bold text                              |
| <I>         | Italic text                            |
| <br>        | Change line                            |
| <font size> | Increase or decrease size of text      |

In this image, we can see a robot. There is a text on the image.

<!-- image -->

<!-- image -->

| Tags   | Descriptions                                                                                                      |
|--------|-------------------------------------------------------------------------------------------------------------------|
| <img>  | It defines an image in an HTML document. The width and height can be specified to describe the size of the image. |

## Step 1:

To insert an image in an HTML document, you need first to identify an image on your computer. If you do not have one, you can download it. Save the image in a folder and name it ' web ' .

<!-- image -->

In this image we can see a robot. In the background there is a text.

<!-- image -->

## Step 3:

Open a notepad and write down the following html tags. Save your text file as website. html in the folder ' web '

k !Doctype HTML&gt;

&lt;html&gt;

&lt;head&gt;

&lt;title&gt; My Profile &lt;/title&gt;

&lt;/head&gt;

&lt;body bgcolor = "Grey"&gt;

&lt;p&gt; My name is Tipiyu and I am in Grade 9 &lt;/p&gt; src = webltipiyu.png"&gt; &lt;img

&lt;/body&gt;

&lt;/html&gt;

## Your website should appear like this:

In this image we can see a cartoon robot.

<!-- image -->

## Quick Test

## Fill in the blanks with the given words.

- i) A is a group of web pages that are connected together.
2. ii) is a computer language used to create websites.
3. iii) A tag is an instruction written in a text file that is given to the web browser.
4. iv) A is part of a website that contains specific information.
5. v)
6. A tag can be an opening tag or a tag.
7. vi)
8. vii)
9. viii)
10. HTML stands for Hyper Text Language.
11. The tag &lt;img&gt;defines an in an HTML document.
12. The tag  contains  all  the  contents  of  an  HTML  page,  such  as  text,

images, videos and hyperlinks.

<!-- image -->

## END OF UNIT QUESTIONS

<!-- image -->

1. What do the following acronyms stand for?  An example has been given.

CPU:

## Central Processing Unit

LAN:

ISP:

WAN:

NIC:

SAN:

VPN:

PAN:

HTML:

## 2. Circle the correct answer.

- (i) What is the name of the following hardware?
- A. Server
- B. Router
- C. ISP
- D .  NIC
- (ii) The smallest type of network is
- A. SAN
- B .  MAN
- C .  WAN
- D. PAN
- (iii) Which of the following is a ring topology?

<!-- image -->

B.

<!-- image -->

<!-- image -->

- (iv) An intranet is a private network that is accessible to
- A. only people in an organisation
- B. only people in another organisation
- C. the public
- D. only people outside an organisation
- (v) A/An is the company that provides you with access to the Internet.
- A .  Intranet Service Provider
- B. Internet Service Provider
- C. Web Server
- D. Extranet

<!-- image -->

.

.

## END OF UNIT QUESTIONS

<!-- image -->

- (vi) refers to the physical arrangement of a network.
- A. Network component
- B. Network interface
- C. Network map
- D. Network topology
- (vii) What is the following hardware?
- A. A router
- B. A Network Interface Card
- C. A MODEM
- D. A motherboard
- (viii)  This diagram refers to a topology.
- A. tree
- B. bus
- C. mesh
- D. ring
- (ix) Which of the following is a data transfer network that makes a network of storage devices accessible to multiple servers?
- A. Virtual Private Network
- B. Storage Area Network
- C. Local Area Network
- D. Wide Area Network
- Another name for a Tree topology is .
- A. Branch topology
- B. Pyramid topology
- C. Hierarchical topology
- D. Bus topology
- (xi) is like an online journal where a person can write his personal opinions or thoughts.
- A. Wiki
- B. Blog
- C. Podcast
- D. Social Network
- (x)

<!-- image -->

<!-- image -->

<!-- image -->

## END OF UNIT QUESTIONS

<!-- image -->

- (xii)

is a live visual communication between two or more people that are from different locations.

- A. Vodcast
- B. Online Forum
- C. Videoconferencing
- D. Wiki
5. (xiii)  Which of the following is NOT a social network?
- A. facebook.com
- B. google.com
- C. instagram.com
- D. twitter.com
10. (xiv)  A is a group of web pages that are connected together.
- A. website
- B. web log
- C. wiki
- D. blog
15. (xv) is a computer language used to create websites.
- A. Scratch
- B. Logo
- C. Flowchart
- D. HTML

## END OF UNIT QUESTIONS

<!-- image -->

<!-- image -->

## 3. Indicate whether the following statements are True (T) or False (F).

Put a tick (  ) in the appropriate column.

|    |                                                                                                 | True   | False   |
|----|-------------------------------------------------------------------------------------------------|--------|---------|
|  1 | AWANis bigger than a LAN.                                                                       |        |         |
|  2 | A PAN is used to connect LANs across a city.                                                    |        |         |
|  3 | AVPN is a public network.                                                                       |        |         |
|  4 | In the ring topology, all nodes are connected to a central device.                              |        |         |
|  5 | If the central computer in a star topology goes down, the whole network is down.                |        |         |
|  6 | WiFi uses radio waves to provide wireless Internet.                                             |        |         |
|  7 | An Intranet is used by people outside the organisation such as customers.                       |        |         |
|  8 | An Internet Service Provider is hardware that gives access to the Internet.                     |        |         |
|  9 | A firewall can be a software or a hardware.                                                     |        |         |
| 10 | A router allows communication between a home network and the Internet.                          |        |         |
| 11 | Someone who writes on blogs is called a blogger.                                                |        |         |
| 12 | Subscribers to the podcast will receive notifications of new audio files added to the websites. |        |         |
| 13 | </body> is an example of an opening tag.                                                        |        |         |
| 14 | The extension of a webpage is .html.                                                            |        |         |
| 15 | 'bgcolor'defines the background colour of an HTML page.                                         |        |         |

## END OF UNIT QUESTIONS

<!-- image -->

## 4. Complete the following sentences with the given words.

| firewall star VPN         | WiFi   | intranet   | router   |
|---------------------------|--------|------------|----------|
| Internet Service Provider | tree   | wiki       | MAN      |

- i) A is a software program or a hardware that prevents unauthorized access to a network.
2. ii) A is a hardware that allows two or more networks to be connected.
3. iii) is the name of the most popular wireless networking technology.
4. iv) An is the company that provide you with access to the Internet.
- v) An is  a  private  network  that  is  accessible  to  only  people  in  an organisation.
6. vi) In the topology, all nodes are connected to a central hub.
7. vii) The topology is also known as the hierarchical topology.
8. viii) A allows a user to create a secure connection over the Internet to access a private network.
9. ix) topology is designed for a larger geographical area such as a town or city.
- x) A is  a  website that allows internet users to view, add, delete and modify its contents.

## END OF UNIT QUESTIONS

UNIT 5

<!-- image -->

5. (a) Name the 5 main types of network topologies.

- (b) Draw a Star Topology in the space provided.

Internet

<!-- image -->

## 6. Complete the following HTML codes with the given tags:

&lt;BODY&gt;

&lt;/HTML&gt;

&lt;/TITLE&gt;

&lt;/P&gt;

&lt;!Doctype HTML&gt;

&lt;HTML&gt;

&lt;HEAD&gt;

&lt;TITLE&gt; My Website &lt;\_\_\_\_\_\_\_\_&gt;

&lt;/HEAD&gt;

&lt;\_\_\_\_\_\_\_&gt;

&lt;P&gt;Welcome to my website&lt;\_\_\_\_\_&gt;

&lt;/BODY&gt;

&lt;\_\_\_\_\_\_\_&gt;

## 7. Define the following computer terms

Internet Service Provider:

MODEM:

HTML:

## Additional Notes

UNIT 5

Internet

e

Multimedia

## Multimedia

## Learning Objectives

## By the end of Unit 6, learners should be able to:

- Create comic strips using an appropriate authoring tool

## 6.1 Comic Strips

In this image we can see a collage of pictures. In the center of the image we can see a cartoon image of a robot. In the background of the image we can see a building and a person.

<!-- image -->

## What is a comic strip?

A comic strip is a sequence of images found in boxes, which make use of dialogues and captions to tell a story.

Note: A box in a comic strip is also called a panel.

Figure 6.1

In this image, we can see a person standing and holding a book. We can also see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can see a person wearing a cap and a red shirt. We can

<!-- image -->

UNIT 6

Multimedia

<!-- image -->

6

## What is a caption in a comic strip?

A caption provides the reader with additional messages about what is happening in the panel. In figure 6.1, the caption is used to describe a particular situation or to indicate the action the character is performing.

Another example of a caption in a comic strip is found below:

In this image, we can see a cartoon image of a boy. He is wearing red t-shirt, white shorts, and green shoes. He is holding a ball in his hand. He is smiling.

<!-- image -->

## What is dialogue in a comic strip?

A  Dialogue  represents  the  thought  or  the  speech  of  the  character.  Dialogues  are  found  in speech bubbles or speech balloons . The tail in the speech balloon indicates the source of speech. Speech balloon shows the emotions of the character.

In this image we can see a cartoon image of a robot. In the robot there is text.

<!-- image -->

## There are 4 main types of speech balloons:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|    | Speech balloons   | Description                                                                                                                                                       | Example                        |
|----|-------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------|
|  1 |                   | General speech balloon The character's dialogue is represented by this speech balloon.                                                                            | acomicstrip                    |
|  2 |                   | Secret/Whisper balloon It is used when you want your character to convey a secret or whisper some words. This speech balloon is characterised by its dotted line. | HeyTommy. Do not tell amacomic |
|  3 |                   | Thought balloon It is used to show someone is thinking.                                                                                                           |                                |
|  4 |                   | Sound/Expression text balloon Itisusedwhenasound is introduced in the story. ForexamplePOW, ZOOM,VROOM,OUCH! and Cool! can bewritten in the speech balloons.      | Cool!                          |

## 6.2 Steps to create a comic strip

## Step 1:

## Writing a script

A script allows you to write the story. The story should have a beginning, a middle and an end. A storyboard can be used to show the sequence of actions. In a comic strip it is not important to write all the details about the story.

## Step 2:

## Deciding the format

At this stage, it is important to decide on the number of panels that would be used. As a start, use 1 row with 3 to 4 panels.

Step 3: Using an authoring tool to design the comic strips

In this image, we can see a diagram.

<!-- image -->

There are many online and offline authoring tools that are available to design comic strips.

Examples of an online authoring tool to design a comic strip are:

1. https://www.toondoo.com
2. https://www.stripgenerator.com
3. https://www.pixton.com

Examples of an offline authoring tool to design a comic strip are:

1. Cosy comic strip creator
2. Comic life
3. Microsoft Powerpoint

UNIT 6

## 6.3 Designing a comic strip on: Reporting to your educator in case of a problem in the computer laboratory

## 6.3.1 Planning the comic strip

The script is written in bulleted form.

## Beginning (1 panel)

- Sound 'PAW!' from socket in laboratory.
- Tommy says ' OMG'. (Tommy does not appear in the panel)

## Middle (1 panel)

- Tommy is feeling shocked.
- Text: What is this sound? Oh, I need to report this problem to the teacher.

## End (1 panel)

- Tommy says: I heard a strange sound coming from the electrical sockets.
- Tipiyu : Thank you for reporting this problem.

This comic strip will contain three panels.

## Storyboard

To plan a comic strip a storyboard template can be of great help.

In this image, we can see a board with some text and images.

<!-- image -->

UNIT 6

Multimedia

## 6.3.2 Using Microsoft Powerpoint 2016 to create the comic strip

Before creating the comic strip, we must first gather photos as mentioned in the storyboard's panel.

Beginning

overloaded socket

<!-- image -->

Middle

<!-- image -->

In this image there is a cartoon robot.

<!-- image -->

## Creating the comic strip in MS PowerPoint

## Step 1:

Insert 3 panels (rectangles) using shapes in MS PowerPoint

In this image, we can see a screenshot of a website.

<!-- image -->

Your slide should look like this.

In this image I can see a page with some text and a picture of a person.

<!-- image -->

## Step 2 :

## Refer to the storyboard and fill the first panel.

In this image, we can see a text box.

<!-- image -->

- Insert photo of overloaded socket.
- Insert caption using a rectangle.
- Insert 2 speech balloons.

## Insert photo of overloaded socket

In this image we can see a screenshot of a page.

<!-- image -->

UNIT 6

The slide will look like this:

In this image, we can see a picture of a wire.

<!-- image -->

## Insert caption

To insert a caption use a rectangle and insert the text 'Somewhere in the computer laboratory' .

The slide will look like this:

In this image we can see a person standing and holding a cable.

<!-- image -->

## Add speech balloon

All speech balloons are found in the shape option MS PowerPoint.

In this image I can see a picture of a person and I can see few objects.

<!-- image -->

## We will add 2 stars banners from shapes as sound balloon

In this image, we can see some text and images.

<!-- image -->

UNIT 6

The slide will look like this:

Step 3:

In this image, we can see a person's hand and a person's hand are connected to a socket.

<!-- image -->

For the 3 other panels , follow the storyboard and your comic strip should look like this:

In this image there is a table with a few things on it. There are a few words written on the table.

<!-- image -->

<!-- image -->

Tipiyu:   With the help of your teacher, design a comic strip on one of the following topics. You can use the storyboard template available in the annex section of the book.

- Repetitive strain injury
- Back pain

## END OF UNIT QUESTIONS

UNIT 6

Multimedia

<!-- image -->

## Question 1

## Fill in the blanks with the correct answer. Choose from the list below.

speech bubbles, dialogues, tail, script

- (a)  A comic strip contains graphics , captions and

- (b)  The first step to design a comic strip is to write a

- (c)  Another name for speech balloons is

- (d)  The of a speech balloon allows you to know the source of a speech.

## Question 2

## Name the 4 types of speech balloons.

1.

2.

3.

4.

## END OF UNIT QUESTIONS

<!-- image -->

## Question 3

Tommy wants to prevent other students from accessing his documents. He asks Tipiyu for help in this matter.

Rearrange the panels of the comic strip in a logical order. Insert the numbers in the correct order in the space provided below.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Panel Number: \_\_\_\_\_\_\_\_\_\_

Panel Number: \_\_\_\_\_\_\_\_\_\_

Panel Number: \_\_\_\_\_\_\_\_\_\_

Panel Number: \_\_\_\_\_\_\_\_\_\_

## Additional Notes

UNIT 6

Multimedia

datacapis

## HEALTH, SAFETY &amp; ETHICS

UNIT 7

## HEALTH, SAFETY &amp; ETHICS

## Learning Objectives

## By the end of Unit 7, learners should be able to:

- Analyse the key features in a Data Protection Act
- Define ownership, copyright &amp; plagiarism of Internet resources
- Distinguish between ownership and copyright
- Show an understanding of how to avoid accidental plagiarism when using Internet sources
- Explain the potential health hazards related to the prolonged use of ICT equipment
- Discuss how to prevent health hazards when using ICT equipment
- Analyse the potential dangers of the Internet

## 7.1  The importance of data backups

Data is the most important aspect of a computer system. Data backup is a method to make copies of existing data. The main reason to do backup is to recover the data in case of loss. Data loss can be caused by hardware malfunctions, software corruptions, human errors, computer viruses or natural disasters.

## 7.2  KEY FEATURES IN A DATA PROTECTION ACT

Data backups can be stored on any storage media available. They can be stored at the same location (at home or in the office) or at a different location. It is also recommended to make them on a consistent and regular basis.

Personal information should be carefully protected against misuse. A Data Protection Act is  a  law  to  protect  personal  information held electronically.

What is privacy?

The objective of the Data Protection Act is to protect the privacy of people when collecting, manipulating and storing personal data.

Privacy refers to keeping one's personal information and affairs to oneself.

<!-- image -->

HEALTH, SAFETY &amp; ETHICS

Unit

7

## 7.2.1  Key Features in the Data Protection Act

- The person has the right to know what information is collected about him/her.
- Any information should be collected legally.
- Any information collected should be kept safe and secure.
- Any information collected should be true, accurate and up to date.
- Any information collected should be kept only as long as it is needed.
- Any information collected should be used only for that particular purpose and not for other purposes.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Quick Test

## Tick (√) True or False next to each of these statements.

|                                                                                              | TRUE   | FALSE   |
|----------------------------------------------------------------------------------------------|--------|---------|
| Any information collected should be kept safe and secure.                                    |        |         |
| Personal information can be shared with everybody.                                           |        |         |
| Data backup is a process to make copies of existing data.                                    |        |         |
| Data backup should be done rarely.                                                           |        |         |
| Anyinformationcollectedshouldbeusedonlyforthatparticular purpose and not for other purposes. |        |         |
| A person has the right to know what information is collected about him/her.                  |        |         |

## 7.3   OWNERSHIP, COPYRIGHT AND PLAGIARISM OF INTERNET RESOURCES

Internet  resources  are  web  pages,  encyclopaedias,  eBooks,  databases,  online  newspapers, magazines, and publications that provide useful information on the Internet.

There are many organisations, companies, schools, individual people, and governments that provide resources on the Internet.

The creator of a resource on the Internet becomes the owner or author of that information. Ownership is the legal right for the creation of resources.

## Examples of original works:   Literature, music, choreography, pictures, sculptures, movies, software, and architectural works.

Copyright © is a law that gives the owner of a work (such as a book, movie, picture, song or website) the right to say how other people can use it.  For example, the owner of an Internet resource can give permission to others to reproduce his/her work. The purpose of a copyright is to protect the work of a person on the Internet.

Plagiarism is a form of stealing another person's resources and claiming it as one's own. For example, copying and pasting information from a website without acknowledging the owner of the resource.

UNIT 7

## 7.4  Distinguish between ownership and copyright

## Consider the following example:

When you buy an original painting, you buy the physical object.  You own only the artwork, not the copyright to it.  The copyright remains with the artist unless the latter gives you the permission to copy or modify the work.  It is the same as when you buy a book, film, music, etc. You have the right to own and enjoy the item but not the right to reproduce it.

Therefore,  ownership  is  when  you  buy  something,  you  own  it;  whereas  copyright  gives  an individual the right to sell, copy and distribute that item.

## 7.5  Show an understanding of how to avoid accidental plagiarism when using Internet sources

Often  without  realising,  students  may  be  guilty  of  plagiarism.  However,  most  cases  of student plagiarism are accidental. For example, including incorrect or inappropriate use of Internet sources.

In order to avoid accidental plagiarism, the following methods can be used.

## 1. Acknowledging Internet sources

To avoid plagiarism, you must always give recognition whenever you use another person's work.  This means that if you are using information obtained from another source, then you must properly cite that source.

## 2. Use plagiarism checkers

Make use of a plagiarism software,  if  you  are  worried  that  you  might  have  accidentally plagiarised.  Nowadays, there are many free online plagiarism checkers.

In this image, we can see a cartoon robot. In the background, we can see some text.

<!-- image -->

<!-- image -->

## 3. Paraphrase correctly

Paraphrasing refers to keeping the same meaning of an original text without copying the same words.  Make sure that you use your own words when you summarise texts written by other authors.

## 4. Use quotation marks

Make sure you use quotation marks every time you use an author's exact words.

## Quick Test

Below is a list of statements. State whether these are TRUE or FALSE. Put a tick (  ) in the appropriate column.

|                                                                                                     | TRUE   | FALSE   |
|-----------------------------------------------------------------------------------------------------|--------|---------|
| It is important to use quotation marks when using an author's exact words.                          |        |         |
| Plagiarism is not a serious offence.                                                                |        |         |
| DupliChecker is not a free online plagiarism checker software.                                      |        |         |
| Paraphrasing refers to keeping the same meaning of an original text without copying the same words. |        |         |
| There is a copyright law that protects original works on the Internet.                              |        |         |

## 7.6  Potential health hazards related to the prolonged use of ICT equipment

The more a person uses a computer a person uses, the more he/she is exposed to health risks. Health risks have been mainly caused by the increased use of computers and equipment.

<!-- image -->

<!-- image -->

| Health risk                                                                                                                                 | Explanation                                                            | Causes                                                                                              | Precautions                                                                                                                                    |
|---------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|
| Pain that occurs in muscles, nerves and tendons (especially the wrist or fingers) due to repetitive use of computer equipment.              |                                                                        | • Repetitive use of keyboard and mouse • Spending too much time on computer games • Bad posture • • | Repetitive Strain Injury (RSI) Adopt the correct sitting posture - correct angle of arms to the keyboard and mouse Make proper of a wrist rest |
| Pain caused by sitting in a poor posture on a chair and facing a desktop monitor for long hours causing muscle soreness and muscle fatigue. | • Prolonged sitting in a bad posture • Not using appropriate furniture | • •                                                                                                 | Back and neck problems monitor at eye level) Avoid prolonged use of a computer in a fixed position Use foot rests reduce posture               |

<!-- image -->

| Health risk                                      | Explanation                                                                                                                                                                                                                                                                                                            | Causes                                                                                                                                | Precautions                                                                                                                                                                                                                                                                                                                                                                                                                 |
|--------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Eye strain (tiredness of the eyes) and headaches | The eye is not naturally designed to be used for fixed focus for long periods of time and monitors emit radiation. Hence, prolonged exposure to computers, tablets, and smartphones cause eye strain. The muscles that focus your eyes do not move, and so get tired and painful. Eye-strain can also cause headaches. | • Radiation emitted by the screen • Dirt on the screen • Glare on the screen • Looking at a monitor which is a constant distance away | • Adjust the brightness of the screen to the surroundings and avoid high brightness settings • Avoid placing screens close to the eyes and using screens beyond their designed resolution • Take frequent breaks and try focusing the eyes to a further distance • Ensure that there is no screen flicker; this can lead to eye strain • Use antiglare screens if lighting in the room is a problem • Keep the screen clean |

This is a list of some common advice to reduce health problems associated with the use of computers.

- Good posture and positioning
- Comfort
- Encouraging movement and exercise
- Taking breaks

Items  that  can  be  provided  in  an  office  or  computer  lab  to  give  the  user  more  control include:  variable  lighting,  curtains  or  blinds,  multiple  working  positions,  user  adjusted devices (chair height, keyboard position etc.)

In this image, we can see a table with chairs and a table lamp. We can also see a person sitting on the chair. We can see a person standing. We can see a chair with a person sitting on it. We can see a person standing. We can see a table lamp. We can see a person sitting on the chair. We can see a person standing. We can see a chair with a person sitting on it. We can see a person standing. We can see a table lamp. We can see a person standing. We can see a chair with a person sitting on it. We can see a person standing. We can see a table lamp. We can see a person standing. We can see a chair with a person sitting on it. We can see a person standing. We can see a table lamp. We can see a person standing. We can see a chair with a person sitting on it. We can see a person standing. We can see a table

<!-- image -->

## THE CORRECT POSTURE WHILE USING A COMPUTER

In this image there is a diagram. In the diagram there is a table. On the table there is a person. On the right side of the image there is a footrest.

<!-- image -->

The science of how we interact with the objects around us is called ergonomics .

An ergonomic chair is one that fits the body well, giving support to areas such as the lower back.

## Quick Test

## 1. Fill in the blanks using the words given below.

back pain

breaks

adjustable chair

eye strain

radiation

RSI

1. Staring for long hours at a screen may cause

.

- 2.

- A fully must be used to avoid neck pain.

3.

on the monitor can cause tiredness of the eyes.

4. refers to pain that occurs in muscles, nerves

and tendons.

5. Bending over your computer can cause

.

6. Taking regular health problems.

- while using a computer avoid most

## Quick Test

## 2. Multiple choice questions. Please circle the correct answers.

- (a) What is ergonomics?
- A. The science of studying human behaviour.
- B. The science concerned with designing safe and comfortable equipment for humans.
- C. Making sure that accidents don't happen at work.
- (b) Which statement is NOT related to health and safety?
- A Use an adjustable chair.
- B. All hardware must be in perfect working condition.
- C. Take regular breaks while using a computer.
- (c) A chair that is not adjustable can lead to which health problem?
- A. Back pain
- B. Eye strain
- C. Fever
- (d) Typing for long hours can cause which of the following problems?
- A. Heart ache
- B. Repetitive strain injury
- C. Belly pain

UNIT 7

HEALTH, SAFETY &amp; ETHICS

- (e) A flickering screen is most likely to cause which type of health problem?

- A.

- Eye strain

- B. Back pain

- C. Wrist pain

- (f) Which of the following can help prevent obesity?
- A. Good posture
- B. Regular exercise
- C. Ergonomic chairs

## 7.7  Potential dangers of the Internet

Excessive use of the Internet can be harmful to the health and social development of a child.

In this image we can see a skeleton wearing a white shirt and sitting on a chair. In front of him there is a table. On the table there is a computer. On the left side there is a wall.

<!-- image -->

| TERM                                                                                                                           | EXPLANATION                                                                                                                             | DANGERS               |
|--------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|-----------------------|
| Gaining illegal access to a computer system.                                                                                   | Hackers can steal private and confidential information, like photos and videos.                                                         | Hacking               |
| Kids can accidentally or incidentally encounter materials that are not related to their age, like adult content (pornography). | Children can make wrong usage of these materials and change their sexual attitude. Children can behave as what they see in pornography. | Inappropriate content |
| Expert manipulators can enter chat rooms or social media to find and trap young children.                                      | They can create fake profiles and befriend children by pretending to be the same age.                                                   | Chat room predators   |
| It is a tiny program intentionally created to cause harm to a computer system.                                                 | Infect computers, delete important data or make the computer unusable.                                                                  | Virus infection       |
| Sending and receiving nude or partially nude photos or videos.                                                                 | Defamation and damage to reputation.                                                                                                    | Sexting               |

UNIT 7

| TERM                                                                                                                     | EXPLANATION                                                                                                                                                                                                              | DANGERS           |
|--------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| Online games can have hidden dangers.                                                                                    | They can include sexual content, violence and vulgour language.                                                                                                                                                          | Gaming addiction  |
| Using the Internet and related technologies to harm and harass other people in a deliberate and repeated manner.         | Sending harassing messages to cause harm. Like using the Internet to spread lies, make offensive comments, death threats, etc.                                                                                           | Cyber bullying    |
| Many teenagers misuse social networks and disclose a lot of personal information like phone numbers, addresses, age etc… | befriend them and misuse data that is personal and private for activities like pirating their account or identity theft. They can hack their account, steal their identity and also post private images on social media. | Social networking |
| An adult befriending a child with the intent to prepare them for sexual abuse.                                           | Unwanted contacts, especially with adults who pretend to be children. Abusers are able to hide behind false online identities and build a falsely perceived personal connections.                                        | Pedophilia        |

## END OF UNIT QUESTIONS

<!-- image -->

## 1. Match the following. An example is given below.

| ColumnA   | ColumnA             | Column B   | Column B                                                            | Column C   |
|-----------|---------------------|------------|---------------------------------------------------------------------|------------|
| 1.        | Data backup         | A          | Copying someone else's work and claiming it as your own.            | 1. E       |
| 2.        | Eye strain          | B          | A tiny program created intentionally to destroy data.               | 2.         |
| 3.        | Data Protection Act | C          | It is a set of laws that protects an author's work.                 | 3.         |
| 4.        | Virus               | D          | Pain caused by incorrect sitting posture for a long period of time. | 4.         |
| 5.        | Ownership           | E          | A method to make copies of existing data.                           | 5.         |
| 6.        | Hacking             | F          | Tiredness of the eyes.                                              | 6.         |
| 7.        | Plagiarism          | G          | It is a law that protects personal information.                     | 7.         |
| 8.        | Back pain           | H          | An acronym for Repetitive Strain Injury.                            | 8.         |
| 9.        | Copyright           | I          | Refers to the legal right for the creation of resources.            | 9.         |
| 10 .      | Ergonomics          | J          | The act of gaining illegal access to a computer system.             | 10.        |
| 11.       | RSI                 | K          | The science of how we interact with the objects around us.          | 11.        |

## END OF UNIT QUESTIONS

2. Define the following terms:

- (a) Ownership

- (b) Copyright

- (c) Plagiarism

- (d) Hacking

<!-- image -->

UNIT 7

HEALTH, SAFETY &amp; ETHICS

<!-- image -->

- (e) Virus

- (f) RSI

- (g) Data back up

3. Give an example of a plagiarism act.

4. Name one plagiarism checker.

<!-- image -->

UNIT 7

HEALTH, SAFETY &amp; ETHICS

5. Differentiate between ownership and copyright.

6. State any three methods that can be used to avoid accidental plagiarism.

7. Give two items in the Data Protection Act.

8. (a) State two health problems associated to the use of computers.

1)

2)

- b) State two precautions that need to be taken to avoid such health problems.

1)

2)

## END OF UNIT QUESTIONS

## END OF UNIT QUESTIONS

<!-- image -->

- 9 (a) List three dangers that one can encounter while using the Internet.

1)

2)

- b) Name three precautions that need to be taken to avoid potential dangers of the Internet.

1)

2)

3)

## Additional Notes

UNIT 7

HEALTH, SAFETY &amp; ETHICS

Afterinstalling the progra

Apps

COVER IMAGE

ON Practical problem solving and programming

STOP

WILL BE ADDED

operating system python

0

## Practical problem solving and programming

START

arrangedin a specifc

INPUT Numl

UNIT 8

Practical problem solving and programming

## Practical problem solving and programming

8

<!-- image -->

## Learning Objectives

## By the end of Unit 8, learners should be able to:

- Draw flowcharts to solve simple problems
- Dry run flowcharts
- Write computer programs for simple problems

## RECAP: Flowchart Grade 8

A flowchart is a diagram which uses symbols to represent problem solving steps. Lines and arrows are used to show the sequences in which the steps occur. The shape of the symbol indicates which type of information goes into the symbol.

## Flowchart symbols

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Symbols   | Description                                                                                                                 |
|-----------|-----------------------------------------------------------------------------------------------------------------------------|
| Start     | This symbol indicates the start of a flowchart.                                                                             |
| Stop      | This symbol indicates the end of a flowchart.                                                                               |
| Input     | Input symbol is used to insert data for processing.                                                                         |
| Output    | Output symbol is used to display data after processing.                                                                     |
| Process   | It is used whenever there is a calculation, sorting, or matching to be carried out.                                         |
| Decision? | It refers to a decision which results in two possible choices. The answer to the Decision/Question can either be Yes or NO. |
| Flowlines | The flowlines indicates the movement of the data.                                                                           |

## Dry run flowcharts

A dry run is a technique which is used to test a flowchart by recording different values in a trace table. It is possible to see what happens to these values as they follow the sequence of a flowchart. This method can be used to check for errors which may exist in the flowchart logic. A dry run can be done on paper by simply following a program flowchart, recording the values which are used at each stage and writing the changes in a trace table.

## Trace table

A trace table enables the recording of values (variables) which are used to dry-run the flowchart. It also shows the output after these values have been processed.

## Variable

Values must be stored in memory so that they can be processed.  There are many locations in the memory.  A variable is a memory location which is given a symbolic name and the content of the location can change during the execution of a program.

A variable can be pictured like a box which can hold a value ( text or number).  A label (variable name) is placed on the box.

Value which is entered while the program is being executed

Label or Variable name

In this image we can see a box.

<!-- image -->

Age = 15

In this image we can see a paper box.

<!-- image -->

UNIT 8

Practical problem solving and programming

The following is a flowchart which adds two numbers:

In this image, we can see a robot.

<!-- image -->

The following sets of numbers will be used to dry run this flowchart.

Set 1: 8, 6.

Set 2: 3, 10.

## Trace table:

| Variables   | Variables   |            |        |
|-------------|-------------|------------|--------|
| Num1        | Num2        | SUM        | OUTPUT |
| 8           | 6           | 8 + 6 = 14 | 14     |

| Variables   | Variables   |             |        |
|-------------|-------------|-------------|--------|
| Num1        | Num2        | SUM         | OUTPUT |
| 3           | 10          | 3 + 10 = 13 | 13     |

<!-- image -->

## Try these values in the trace table above:

- a) Set A: 58, 17

- b Set B: 4, 7

## Draw flowcharts to solve simple problems

## Problem:

Create a flowchart which allows the user to enter a mark for an ICT test. If the mark is greater than 49 , then output Pass else output Fail.

Break down the problem into smaller steps which are easier to understand and solve. This is called Step down refinement.

- INPUT: Mark

(Mark is a variable which can have any value between 0 and 100)

- IF Mark &gt; 49, OUTPUT 'Pass'

In this image we can see a cartoon robot. In the background there is a text.

<!-- image -->

In the image, we can see a graph with two lines. The first line is labeled INPUT MARK and the second line is labeled OUTPUT "PASS".

<!-- image -->

<!-- image -->

## Modify the flowchart to allow the insertion of marks for five students.

In this image, we can see a robot and a robot toy. We can also see a text.

<!-- image -->

<!-- image -->

## Activity 2:    Complete the trace table below with the following marks: 10, 80, 45, 78, 60

<!-- image -->

## Activity 3:   Complete the flow chart  below by using the words from the list:

| List:                |
|----------------------|
| OUTPUT'cool weather' |
| INPUTTemp            |
| START                |
| OUTPUT'hot weather'  |

The image depicts a situation where a machine learning model is trained on a dataset. The model is trained on a dataset that includes a categorical variable labeled "IF TEMP" and a numerical variable labeled "32". The model is trained on this dataset and is capable of predicting the value of "32" based on the "IF TEMP" variable.

The model is trained on the dataset by using a combination of two different models: a logistic regression model and a decision tree model. The logistic regression model is trained on the dataset and is capable of predicting the value of "32" based on the "IF TEMP" variable. The decision tree model is trained on the dataset and is capable of predicting the value of "32" based on the "IF TEMP" variable.

The model is trained on the dataset by using the "IF TEMP" variable and the "32" variable. The model is trained on the dataset by using the "IF

<!-- image -->

<!-- image -->

## Write computer programs for simple problems

## Before moving to Programming you may consider the following:

<!-- image -->

Structured  English  is  an  intermediate  language  which  makes  use  of English  language  and  programming  logic  in  order  for  non-technical users to understand the program steps.  It uses straight forward English words and capitalise keywords to show the logical steps.

Some common keywords which are used in Structured English are:

BEGIN/END

Shows the beginning and the end of statements

READ, INPUT

Used to show input

PRINT, OUTPUT

Used to show output

CREATE, CLOSE, UPDATE, DELETE

Used for processes

A construct is used to control the order or flow by which instructions are  executed.  There  are  three  logic  constructs  which  are  commonly used:

## Sequence

The order by which the steps occur.  In structured English each line is called a statement and they are executed from top to bottom.

## Selection

A selection is used when a statement or a set of statements is executed only if a certain condition is met.

## Repetition/Iteration

It refers to a set of statements which are executed multiple times in the program.

## Introducing PYTHON

A program is  a  set  of  instructions  that  the  computer  executes. To  create  programs  we  use special programs known as programming languages .

Programming refers to the action of writing program instructions. These instructions or lines of codes are called program statements .

Python is  an  easy to use programming language. The Python software is free and it can be downloaded from the following URL:

## https://www.python.org/downloads/

On the Python web site you can choose the version which is the most appropriate for your operating system.

In this image we can see a screenshot of a website.

<!-- image -->

UNIT 8

Practical problem solving and programming

With the help of your teacher download the Python installer, double click on its icon and follow the instructions:

1. Select install for all users and click next .
2. Leave the default directory unchanged and click next .
3. Ignore the customize Python section and click next .

After installing the program, create a shortcut on the task bar to access it easily.

1. Click on
2. Click on
3. Move your pointer across the screen until you locate Python in the list. Right click on the Python icon. Then click on Pin to taskbar .

<!-- image -->

<!-- image -->

In this image there is a screen with some text on it.

<!-- image -->

To start Python , click on the

<!-- image -->

icon which is found on the task bar .

## The Python Screen

The 3 greater- than sign &gt;&gt;&gt; is called the prompt . Commands are typed at the place which is indicated by the prompt and the Enter key is used to execute the command.

In this image I can see a text box and a button.

<!-- image -->

## Saving your file

In this image, we can see a screenshot of a file.

<!-- image -->

<!-- image -->

Type a file name and select a location.

In this image I can see a picture of a computer screen.

<!-- image -->

## PYTHON Commands

## OUTPUT print ( ) command

The print command is used to output/display information. Type the command and strike Enter.

## Displaying Strings/Characters

A string is a sequence of characters that the computer can process. Single quotes or double quotes can be used. The quotes indicate to Python that what is inside the bracket is a string.

In the image we can see there is a web page. On the left side of the page there is a text box. On the right side of the page there is a text box.

<!-- image -->

In this image there is a text on the left side of the image.

<!-- image -->

## Displaying Numbers

To display numbers, no quotes are used.

In this image I can see a text box and a picture of a web page.

<!-- image -->

In this image I can see the text on the screen.

<!-- image -->

UNIT 8

Practical problem solving and programming

## Activity 4: Try the following commands in Python.

<!-- image -->

- a) print (2+5)
- b) print (10 - 8)
- c) print (40 * 3)
- d) print (100/4)
- e) print (5+6-2)

## Displaying Strings using operators

In this image there is a text box in the middle.

<!-- image -->

In this image I can see the text on the left side.

<!-- image -->

## Working with Variables

As we have seen above, a variable is a memory location which stores a value. The value can change when Python is running. You can imagine it like a box on which a label (variable  name)  is  written.  A  number  or  string  can  be inserted inside the box.

The variable name is Name and the string which it stores is John

## Commands:

Name = ('John')

Print (Name)

The program will output John the string which is found in the variable Name

In this image, we can see a screenshot of a file.

<!-- image -->

## Activity 5: Work out the following commands in Python

<!-- image -->

- a)    Age = 15

print (Age)

b)   Text = 'New variable created'

print ( Text )

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

## INTPUT - input () command

The input () command allows you to read the data which is typed on the screen. This data is then sent to a variable. Data which is stored in variables can be further processed or displayed.

Problem: Writing codes to allow the user to enter a Name in a variable and then output the content of that variable.

## Commands:

Name = input('Enter a name')

Print (Name)

## Steps: 1

In this image there is a screenshot of a webpage.

<!-- image -->

Steps: 2 - After typing the above command press enter.

In this image we can see a screenshot of a web page.

<!-- image -->

Steps: 3 - Type the string Paul which will be sent to the variable Name.

In this image, we can see a screenshot of a web page.

<!-- image -->

Steps: 4 - Use the print command to display the content of the variable Name

In this image there is a screenshot of a webpage.

<!-- image -->

<!-- image -->

<!-- image -->

- a)    Write Python statements to allow the user to enter a value in the variable Age and then output its content.

## Selection - IF STATEMENT

In  programming  we  use  a  selection  statement  to  do  a  comparison.  The if statement  is constructed as follows:

## if expression :

print statement or statements for true

else:

print statement or statements for false

Consider the flowchart created above to check marks and output Pass if  the mark is greater than 49 else Fail if the mark is 49 or less.

In this image, we can see a screenshot of a webpage. On the webpage, we can see a text box, a button, a text box, a button, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text

<!-- image -->

## Loop

A loop is used when some steps/statements are repeated a number of times.

## Example: 1

To print a string a number of times. The while command can be used to do this.

## while expression:

## print statement or statements

In this image we can see a screenshot of a text.

<!-- image -->

The string in the variable word is printed 3 times.

<!-- image -->

## Example: 2

The for command can also be used to create loops.

## for expression:

## print statement or statements

To print a list of names, we use the for loop to print all the elements which are in the list one after the other. The list contains 3 names John, Anne, Paul.

In this image we can see a screenshot of a page. On the page we can see a text and some numbers.

<!-- image -->

Print (x) will cause the program to print each value of X in the list Names.

Loops can also be used to do operations inside a string. For example, the variable Word contains the string computer . The following codes display each character which makes up the string.

In this image, we can see a screenshot of a webpage. On the webpage, we can see a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box, a text box,

<!-- image -->

Print (x) will cause the program to print each character in the string 'Computer' .

UNIT 8

Practical problem solving and programming

Loops can also be done to display values which falls in a range .

The range function returns a sequence of numbers starting from 0 which is the default value.

In this image, we can see a text box.

<!-- image -->

Note: range (10) starts with 0 and ends with 9.

<!-- image -->

- a)    Write Python statements to allow the user to input an Age and print 'Adult' if the age is greater than 21 and 'Youngster' if the age is 20 or less.
- b)    Write Python statements to allow the user to input his name and display it five times.
- c)     Write  Python  statements  to  allow  the  user  to  input  his  name  and  output  each alphabets separately.

## END OF UNIT QUESTIONS

<!-- image -->

## 1. Fill in the blanks in the sentences below by using the following keywords:

|      | selection                                                             | statement                                                             | loop construct                                                        |
|------|-----------------------------------------------------------------------|-----------------------------------------------------------------------|-----------------------------------------------------------------------|
|      | program                                                               | flowchart                                                             | programming                                                           |
| i)   | Set of instructions which allows the computer to do a specific task.  | Set of instructions which allows the computer to do a specific task.  | Set of instructions which allows the computer to do a specific task.  |
| ii)  | A line of code in a program.                                          | A line of code in a program.                                          | A line of code in a program.                                          |
| iii) | It is used to control the flow by which instructions are executed.    | It is used to control the flow by which instructions are executed.    | It is used to control the flow by which instructions are executed.    |
| iv)  | Allows the program to execute a set of statements instead of another. | Allows the program to execute a set of statements instead of another. | Allows the program to execute a set of statements instead of another. |
| v)   | A set of instructions which are executed                              | A set of instructions which are executed                              | several times.                                                        |
| vi)  | The use of symbols to represent a program sequence.                   | The use of symbols to represent a program sequence.                   | The use of symbols to represent a program sequence.                   |

## 2. a) Complete the flowchart by using the words from the list below.

| List:                         |
|-------------------------------|
| OUTPUT "Is a college student" |
| INPUT Current year            |
| OUTPUT "Must leave school"    |
| IF Age > 19?                  |

The image is a list of input values for a student evaluation system. The list includes two columns: "OUTPUT" and "IF". The "OUTPUT" column is used to store the output values of the evaluation system. The "IF" column is used to store the if conditions for the evaluation system.

The first column is labeled "OUTPUT" and it is used to store the output values of the evaluation system. The second column is labeled "IF" and it is used to store the if conditions for the evaluation system.

The first column is labeled "OUTPUT" and it is used to store the output values of the evaluation system. The second column is labeled "IF" and it is used to store the if conditions for the evaluation system.

The first column is labeled "OUTPUT" and it is used to store the output values of the evaluation system. The second column is labeled "IF" and it is used to store the if conditions for the evaluation system.

<!-- image -->

## END OF UNIT QUESTIONS

UNIT 8

Practical problem solving and programming

- b) Complete the trace table for the above flow chart with the following year of birth: 2000, 1998, 2005, 2010
2. C ) Write Python statements for the flowchart at A above.

## Additional Notes

## Additional Notes

UNIT 8

Practical problem solving and programming

## STEP BY STEP

Launch Microsoft Access 2016

2

Click Blank database

## Access

## Recent

## Pinned

appears when you hover over Pin

Older

Database3

Oocuments

Students

Documents test

Search for online templates

Suggested searches:

Blankdatabase

Oocuments

Blankdesktop database screen appears in the centre of the screen; as shown below:

Blank database

## 9.3 Creating forms

goes directly into one or more tables.

The Forms group is located on the Create tab in the Ribbon and can be used to create a variety of forms.

Creates anew blankform

in Design view

Telmewhat youwantto do ore Forms

Design Repont

Repons

Createsa new form using the Form Wizard

Home

Design

Creates a simple form

Eternal Data

Hdp

Desigg

Creates anew blank form

in Layoutview

Repon

## Databases

Datasheet view allows you to view the contents ofatable.

0

Landscape button as shown above

## Databases

## Learning Objectives

By the end of Unit 9, learners should be able to:

- Create queries
- Create forms
- Create reports

## 9.1  What are queries?

Queries allow retrieving of information from a database based on certain conditions . In other words, queries provide answers to specific questions set to the database.

Consider the table below called Books .

|   BookID | Title                               | AuthorName              |   YearPublished | Language   |   NumPages | BookFormat   |   QtyInStock |
|----------|-------------------------------------|-------------------------|-----------------|------------|------------|--------------|--------------|
|        1 | Le Petit Prince                     | Antoinede Saint-Exupéry |            2001 | French     |         85 | Hardcover    |           12 |
|        2 | Harry Potter à l'école des sorciers | J.K. Rowling            |            2011 | French     |        321 | Paperback    |            8 |
|        3 | TheWonky Donkey                     | Craig Smith             |            2010 | English    |         24 | Paperback    |            3 |
|        4 | HarryPotter andtheGoblet ofFire     | J.K. Rowling            |            2019 | English    |        464 | Hardcover    |            2 |
|        5 | Cendrillon                          | CharlesPerrault         |            2013 | French     |         26 | Paperback    |            8 |

<!-- image -->

<!-- image -->

9

## Adding Criteria to a Query

Criteria  are  used  to  get  the  most  specific  information  from  a  query.  A  criterion  is  similar  to a formula. Some criteria are simple and use basic operators and constants.

A bookstore clerk might want to know whether French books are available or not.

The query that can be used to obtain information about books written in French language is as follows:

## Example of a simple query:

The image depicts a two-way relationship between two objects, which are labeled as "Field" and "Value." Here is a detailed description of the objects and their relationships:

### Objects and Relationships:
1. **Field**: This is a placeholder object that represents a field in a database. It is represented by a red box with a white outline.
2. **Value**: This is a placeholder object that represents a value in a database. It is represented by a black box with a white outline.

### Relationship:
- **Field**: The field is associated with the value.
- **Value**: The value is associated with the field.

### Description:
- **Field**: The field is associated with the value.
- **Value**: The value is associated with the field.

### Analysis:
1. **Field**: The field is associated with the value.
2. **Value**: The value is associated with the field

<!-- image -->

The above is a simple query as it is using only one condition.

For example, only books having 'French' in the Language field will be displayed as follows:

|   BookID | Title                               | AuthorName               |   YearPublished | Language   |   NumPages | BookFormat   |   QtyInStock |
|----------|-------------------------------------|--------------------------|-----------------|------------|------------|--------------|--------------|
|        1 | LePetit Prince                      | Antoine de Saint-Exupéry |            2001 | French     |         85 | Hardcover    |           12 |
|        2 | Harry Potter à l'école des sorciers | J.K. Rowling             |            2011 | French     |        321 | Paperback    |            8 |
|        5 | Cendrillon                          | Charles Perrault         |            2013 | French     |         26 | Paperback    |            8 |

Now, the bookstore clerk may also want to know whether there are 10 or more French books in stock.

The query is using more than one criterion and will be as follows:

In this image we can see a robot. In the background there is a text.

<!-- image -->

In this image there is a chart.

<!-- image -->

## 1 st criteria

Only records where the value of the Language field is 'French' will satisfy this criterion.

## 2 nd criteria

Only records where the value of the QtyInStock field is greater than or equal to 10 will satisfy this criterion.

## AND Operator

Only records that meet both criteria will be included in the result.

The complex query above will display all French books that are greater than or equal to 10 as follows:

|   BookID | Title          | AuthorName              |   YearPublished | Language NumPages   | BookFormat   |   QtyInStock |
|----------|----------------|-------------------------|-----------------|---------------------|--------------|--------------|
|        1 | LePetit Prince | Antoinede Saint-Exupéry |            2001 | French 85           | Hardcover    |           12 |

<!-- image -->

Now, let us have a look at how queries are created.

In Microsoft Access, queries are created either by using the Query Wizard

<!-- image -->

In this section, only the Query Wizard will be used to create queries.

## Activity 1: Creating a database and a table.

<!-- image -->

## STEP BY STEP

1. Launch Microsoft Access 2016
2. Click Blank database .

<!-- image -->

In this image, we can see a picture of a table. On the table, we can see a cup, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen, a paper, a pen,

<!-- image -->

A Blank desktop database screen appears in the centre of the screen, as shown below:

In this image there is a table. On the table there is a file.

<!-- image -->

<!-- image -->

<!-- image -->

In this image there is a picture of a file.

<!-- image -->

4. The table will  be  opened  in  Datasheet

View.

<!-- image -->

In this image, we can see a table with some text and images.

<!-- image -->

In this image we can see a cartoon robot. In the background there is a text.

<!-- image -->

6. In the Save As dialog box, type Books.
8. The table appears in design view:

In this image, we can see a person and a text box.

<!-- image -->

In this image we can see a cartoon robot. In the cartoon robot there is a text.

<!-- image -->

In this image we can see a table with some text and numbers.

<!-- image -->

| Books      | Books      | Books               |
|------------|------------|---------------------|
| Field Name | Data Type  | Description (Optior |
|            | AutoNumber |                     |

<!-- image -->

## 9. Enter the following field details:

| FieldName     | DataType   | Field Size   |
|---------------|------------|--------------|
| BookID        | AutoNumber | Long Integer |
| Title         | Short Text | 60           |
| AuthorName    | Short Text | 50           |
| YearPublished | Number     | Long Integer |
| Language      | Short Text | 35           |
| NumPages      | Number     | Long Integer |
| BookFormat    | Short Text | 30           |
| QtyInStock    | Number     | Long Integer |

In Design View, table ' Books '  will appear as shown below.

| Primary   | Key   |
|-----------|-------|
| icon      |       |

In this image, we can see a robot. There is a text on the image.

<!-- image -->

In this image, we can see a table with some data.

<!-- image -->

| Books                                |                        |           |
|--------------------------------------|------------------------|-----------|
| Field Name                           | Data Type              | Data Type |
| BookID                               | AutoNumber             |           |
| Title                                | Short Text             |           |
| AuthorName                           | Short Text             |           |
| YearPublished                        | Number                 |           |
| Language                             | Short Text             |           |
| NumPages                             | Number                 |           |
| BookFormat                           | Short Text             |           |
| QtylnStock                           | Number                 |           |
| General Lookup Field Size New Values | Cong Integer Increment |           |

The field size for Field BookID is Long Integer (by default).

Modify for the other fields.

10.  Click the

Save icon to save the table structure.

<!-- image -->

## Activity 2: Entering data into 'Books' table

<!-- image -->

Follow these steps to enter records in the table that you have created in the database 'Crazy Wisdom Bookstore'.

1. Launch Microsoft Access 2016, then open the database 'Crazy Wisdom Bookstore' .

In this image, we can see a screenshot of a page. On the page, we can see a text box, a list, a button, a picture, a text, a link, a text, a picture, a text, a button, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text, a link, a picture, a text

<!-- image -->

<!-- image -->

3. The blank record is shown with a ' * '  in the record selector cell .

In this image, we can see a screenshot of a document.

<!-- image -->

## 4. Enter the following data:

In this image there is a table with some text on it.

<!-- image -->

| Books   |                                       |                          |              |               |
|---------|---------------------------------------|--------------------------|--------------|---------------|
| BookID  | Title                                 | AuthorName YearPubli:    | Numf         | OtylnSt(      |
|         | Le Petit Prince                       | Antoine de Saint-Exupéry | 2001 French  | 85 Hardcover  |
|         | 2 Harry Potter à l'école des sorciers | JK. Rowling              | 2011 French  | 321 Paperback |
|         | 3 The Wonky Donkey                    | Craig Smith              | 2010 English | 24 Paperback  |
|         | Harry Potter and the Goblet of Fire   | JK. Rowling              | 2019 Engllsh | 464 Hardcover |
|         | 5 Cendrillon                          | Charles Perrault         | 2013 French  | 26 Paperback  |
|         | 6 What Should Danny Do?               | Adir Levy                | 2017 English | 72 Hardcover  |
|         | Attraper la lune                      | Efrat Haddi              | 2017 French  | 40 Paperback  |
|         | 8 Llama Llama Easter Egg              | Anna Dewdney             | 2015 English | 14 Board Book |
|         | 9 Bonsoir Lune                        | Margaret Wise Brown      | 2013 French  | 10 Hardcover  |
|         | 10 Goodnight Moon                     | Margaret Wise Brown      | 2007 English | 30 Board Book |

5.  Save the table before closing it.

## 9.2  Creating Queries

When you are creating queries, you can use search criteria and logical operators in order to display specific terms, numbers or date/time.

The tables below show some examples of query criteria and operators.

## Examples of query criteria

| CriteriaName   | Write it like...   | Function                               |
|----------------|--------------------|----------------------------------------|
| Equal to       | ='x'or = x         | Searches for values equal to x         |
| LessThan       | < x                | Searches for all values smaller than x |
| GreaterThan    | > x                | Searches for all values larger than x  |

## Examples of logical operators

| Operator   | Criteria                               | Example                                                                                    |
|------------|----------------------------------------|--------------------------------------------------------------------------------------------|
| AND        | Language = 'French'AND QtyInStock >=10 | Displays French books where quantity in stock is 10 or greater than 10.                    |
| OR         | Language = 'French'OR QtyInStock >=10  | Displays all French books Or Other books where quantity in stock is 10 or greater than 10. |
| NOT        | Language NOT'French'                   | Displays all books where Language is NOT French.                                           |

<!-- image -->

## Activity 3: Creating a simple Query using the Query Wizard

<!-- image -->

<!-- image -->

Let us create a query using the Books table of our Crazy Wisdom Bookstore database. We want to see a list of all French books only.  So, we will search for 'French' in the Language field.

1. Launch Access 2016 and open the database 'Crazy Wisdom Bookstore' .
2. On the Create tab , in the Queries group, click the Query Wizard button . The New Query dialog box appears, as shown below:
3. Click Simple Query Wizard and then click OK . The Simple Query Wizard appears, as shown in the following diagram:

In this image I can see the picture of a book.

<!-- image -->

In this image we can see a table with some text and a few buttons.

<!-- image -->

4. In the Tables/Queries drop-down list, Table: Books should be selected by default. If it is not, select it.
5. Under  Available  Fields, double-click BookID ,  Title,  AuthorName  and  Language  to  move
3. them to the Selected Fields box.

In this image, we can see a table with some text and some images.

<!-- image -->

In this image we can see a robot. In the background there is a text.

<!-- image -->

<!-- image -->

6. Click the Next button . The second screen in the Simple Query Wizard appears.

In this image I can see a picture of a person and I can see a text.

<!-- image -->

In this image there is a question in the middle of the image and there is a text in the middle of the image.

<!-- image -->

In this image, we can see a screenshot of a webpage. On the right side, we can see a menu with some options.

<!-- image -->

8. Click the Finish  button .    The FrenchBooks Query  is  displayed,  as  shown  below.  In  the Criteria row of the Language field, type ' French ' , to display all records where field Language is set to French. Sort the Title in ascending order.

In this image there is a table with some text and a robot.

<!-- image -->

<!-- image -->

9. On the Query Tools Design tab , in the Results group, click the lower half of the View button and then click Datasheet View .
10.  Click the Save button .

In this image, we can see a screenshot of a document.

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

## Activity 4: Adding new records to table Books

<!-- image -->

1. Open the Crazy Wisdom Bookstore database for this lesson.
2. Enter the following records in the Books table.
3. Use the same query as you created above to find all the French books in stock.
4. Double-Click the FrenchBooks Query .
5. Fill in the table below as it would appear after using the FrenchBooks Query.

|   BookID | Title                 | AuthorName                      |   YearPublished | Language   |   NumPages | BookFormat   |   QtyInStock |
|----------|-----------------------|---------------------------------|-----------------|------------|------------|--------------|--------------|
|       11 | WalkTwo Moons         | Sharon Creech                   |            2011 | English    |        288 | Paperback    |            4 |
|       12 | Le Lapin et la Lune   | Marianne Lecron et P. B. Lecron |            2017 | French     |         32 | Paperback    |           13 |
|       13 | J'aime dire la vérité | ShelleyAdmont                   |            2015 | French     |         34 | Hardcover    |           11 |

<!-- image -->

<!-- image -->

The Bookstore clerk often gets questions about the number of books in stock. A customer wants to know which books have more than 10 copies.

Using the Books table create the above query.

1. Open the ' Crazy Wisdom Bookstore '  database for this lesson.
2. On the Create tab, in the Queries group, click the Query Wizard button.
3. Click Simple Query Wizard and then click OK .
4. In the Tables/Queries drop-down list, select Table: Books.
5. Under Available  Fields, double-click BookID, Title,  AuthorName  and  QtyInStock  to  move them to the Selected Fields box.
6. Click the Next button .
7. Click the Next button again. Name the query BooksQuantity Query and then select Modify the query design.
8. Click the Finish button. The BooksQuantity Query is displayed, as shown below. In the Criteria row of the QtyInStock field, type &gt;10, to display all records where field QtyInStock is more than 10.

In this image we can see a box with some text and a picture of a robot.

<!-- image -->

9. On the Query Tools Design tab, in the Results group, click the lower half of the View button and then click Datasheet View. The query results display all records that contain more than 10 books in stock.

In this image there is a table with some text on it.

<!-- image -->

| BooksQuantity Query   | BooksQuantity Query            | BooksQuantity Query   | BooksQuantity Query   | BooksQuantity Query   |
|-----------------------|--------------------------------|-----------------------|-----------------------|-----------------------|
| Title                 | AuthorName                     | QtyInStock            |                       |                       |
| Le Petit Prince       | Antoine de Saint-Exupéry       | 12                    |                       |                       |
| What Should Danny Do? | Adir Levy                      | 15                    |                       |                       |
| Le Lapin et La Lune   | Marianne Lecron et P.B. Lecron | 13                    |                       |                       |
| Jaime dire la vérité  | Shelley Admont                 |                       |                       |                       |

## 10.  Click the Save button .

## Activity 6

<!-- image -->

Create a query to find all books which are older than the year 2010 and that can be sent in the archive section. Use the following steps to find out the result and write it down in the table given.

1. Open the ' Crazy Wisdom Bookstore '  database.
2. On the Create tab, in the Queries group, click the Query Wizard button.
3. Click Simple Query Wizard and then click OK .
4. In the Tables/Queries drop-down list, select Table: Books.
5. Under Available Fields, double-click BookID, Title, AuthorName and YearPublished to move them to the Selected Fields box.
6. Click the Next button . The second screen in the Simple Query Wizard appears.
7. Click the Next button . Name the query BooksBefore2010 Query and then select Modify the query design.
8. Click the Finish button .  The BooksBefore2010 Query is displayed.  In the Criteria row of the YearPublished field, type &lt;2010.
9. Fill in the table below that appears in the BooksBefore2010 Query in the datasheet view.

UNIT 9

| BooksBefore2010 Query   | BooksBefore2010 Query   | BooksBefore2010 Query   | BooksBefore2010 Query   | BooksBefore2010 Query   | BooksBefore2010 Query   | BooksBefore2010 Query   | BooksBefore2010 Query   |
|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|
| BooklD                  | Title                   | AuthorName              | YearPublished           |                         |                         |                         |                         |

## 10.  Click the Save button .

The following table shows some more examples of query criteria.

| CriteriaName            | Write it like...   | Function                                            |
|-------------------------|--------------------|-----------------------------------------------------|
| Does Not Equal          | Not in ('x')       | Searches for all values except those equal to x     |
| Null                    | Is Null            | Searches for empty fields                           |
| Not Null                | Is Not Null        | Searches for non-empty fields                       |
| Contains                | Like'*x*'          | Searches for all values that contain x              |
| Does Not Contain        | Not like'*x*'      | Searches for all values except those that contain x |
| Between                 | Between'x'and'y'   | Searches for values in the range between x and y    |
| LessThan or Equal To    | <= x               | Searches for all values smaller than or equal to x  |
| GreaterThan or Equal To | >= x               | Searches for all values larger than or equal to x   |
| Today                   | =Date()            | Searches for all records containing today's date    |

<!-- image -->

Follow the steps below, to find out which French books are more than or equal to 10 in stock.

1. Open the database 'Crazy Wisdom Bookstore' .
2. On the Create tab, in the Queries group, click the Query Wizard button.
3. Click Simple Query Wizard and then click OK .
4. In the Tables/Queries drop-down list, select Table Books .
5. Under Available Fields, double-click BookID, Title, AuthorName, Language, and QtyInStock to move them to the Selected Fields box .
6. Click the Next button . The second screen in the Simple Query Wizard appears.
7. Click the Next button . Name the query QuantityFrenchBooks Query and then select Modify the query design .

In this image, we can see a page with some text and a picture.

<!-- image -->

<!-- image -->

8. Click the Finish button. The QuantityFrenchBooks Query is displayed, as shown below. In the Criteria row of the Language field, type 'French' and on the same row in the QtyInStock field, type &gt;=10.
9. On the Query Tools Design tab, in the Results group, click the lower half of the View button and then click Datasheet View. The query results display the following records:
10.  Click the Save button and close the database.

In this image we can see a table with some text and some images.

<!-- image -->

In this image there is a table with some text on it.

<!-- image -->

## 9.3  Creating forms

A form is used to enter, edit and or display data from a table or query. Data entered into a form, goes directly into one or more tables.

The Forms group is located on the Create tab in the Ribbon and can be used to create a variety of forms.

In this image, we can see a screenshot of a webpage. On the webpage, we can see a list of different categories, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options, a list of different options,

<!-- image -->

In this section, we will only create forms using the Form Wizard .

Note: Make use of 'Crazy Wisdom Bookstore' from the previous exercise.

Let us create a form called Books, so that the Bookstore clerk can use it to enter records about books.

<!-- image -->

## Creating a form using Form Wizard

1. Open the database 'Crazy Wisdom Bookstore' .
2. On the Create tab, in the Forms group, click the Form Wizard button . The Form Wizard appears as follows:
3. Click the button to move all the fields from the Available Fields box to the Selected Fields box.
4. Click the Next button to move to the next page in the Form Wizard.

In this image, we can see a table with some text and some buttons.

<!-- image -->

<!-- image -->

5. Click Columnar as the layout for the form.
6. Click the Next button to move to the final page in the Form Wizard.
7. Type BooksDetails as the title of the form.

In this image I can see a graph.

<!-- image -->

In this image we can see a text box. In the text box we can see some text.

<!-- image -->

<!-- image -->

8. Click the Finish button . A datasheet form appears as follows:

In this image, we can see a text box. In the text box, we can see some text.

<!-- image -->

The form BooksDetails displays one record at a time from the table  'Books' in column format. You can display other records using the Record Navigation bar.

Now, let us enter more records in table 'Books' , using the BookDetails form.  Follow the steps below:

9. Click the New (blank) Record button on the record navigator at the bottom of the form.
10.  Press the Tab key once and enter the following records in the appropriate fields.
11. Then press the Tab key . The record will be saved and a new blank record will appear again.

| Title                    | AuthorName   |   Year Published | Language   |   Num Pages | Book Format   |   Qty In Stock |
|--------------------------|--------------|------------------|------------|-------------|---------------|----------------|
| Histoires à lire le soir | Marc Thil    |             2013 | French     |         102 | Paperback     |             12 |

## 12.  Click the close button on the form window.

In this image we can see a page with some text and a link.

<!-- image -->

The form appears in the navigation pane as shown below.

<!-- image -->

## 13.  Open the table 'Books' in Datasheet view by double-clicking it .

In this image, I can see the text at the top and bottom of the image.

<!-- image -->

14. Observe the number of records. Now, there are 14 records. The last row is the record you have just added.
15.  Close the database 'Crazy Wisdom Bookstore' .

<!-- image -->

## 9.4  Creating reports

A report is used to organize and display data extracted from tables and queries.  Reports are generated in tabular form where the data is printed in rows and columns with meaningful headings.  The content of reports once generated cannot be modified.

The Reports group is located on the Create tab in the Ribbon as shown below:

In this image, we can see a table with some data.

<!-- image -->

Use the Reports group to create a variety of reports. In the following section, only Report Wizard will be used to create reports.

In the following exercise, use the Report Wizard to create a report based on the Books table.

## Activity 9: Creating a report from a table using Report Wizard

<!-- image -->

1. Open the database 'Crazy Wisdom Bookstore' .

In this image we can see a screenshot of a page.

<!-- image -->

3. The first screen of the Report Wizard appears as below:
4. Select the Books table in the Tables/Queries menu.
5. Click the button
4. to move all the fields into the Selected Fields list.

In this image we can see a table with some text and a few buttons.

<!-- image -->

In this image, we can see a table with some text and some buttons.

<!-- image -->

UNIT 9

6. Click the BookID field to select it and then click the button to move it back to the Available Fields list.
7. Click the Next button .

In this image, we can see a screenshot of a page. On the right side, we can see a text box. On the left side, we can see a text box.

<!-- image -->

9.

In this image, we can see a diagram.

<!-- image -->

Databases

10.  Select AuthorName from the fields menu to sort in ascending order and then click the Next button.

In this image there is a screenshot of a webpage.

<!-- image -->

## 11. In the Layout section, click the Outline button .

In this image, we can see a screenshot of a page.

<!-- image -->

In the Orientation section, click the Landscape button as shown above. Click Next .

<!-- image -->

12. Type Books Wizard as the title of the report.
13.  Click Finish . The Books Wizard report appears on the screen, as shown below.

In this image we can see a screenshot of a page.

<!-- image -->

In this image there is a book in the center.

<!-- image -->

14. CLOSE the report. Notice that the Books Wizard report is listed in the Navigation Pane.
15.  Close the 'Crazy Wisdom Bookstore' database.

In this image, we can see a table with some text and numbers.

<!-- image -->

## Activity 10: Creating a report from a query using Report Wizard

<!-- image -->

1. Open the database 'Crazy Wisdom Bookstore' .
2. On the Create tab, in the Reports group, click the Report Wizard button .
3. Select the FrenchBooks Query in the Tables/Queries menu. Note:  This query was created in a previous lesson.
4. Click the button to move all the fields into the Selected Fields list.
5. Click the Next button .
6. Click the Next button again .
7. Select Title from the fields menu to sort in ascending order and then click the Next button .
8. In the Layout section, click the Justified button . In the Orientation section, click the Landscape button . Click Next .
9. Type FrenchBooks as the title of the report.

<!-- image -->

10.  Click Finish . The FrenchBooks report appears on the screen, as shown below.

In this image I can see the text on the page.

<!-- image -->

| FrenchBooks                       |        |                                  |          |
|-----------------------------------|--------|----------------------------------|----------|
| Tile                              | Bookid | AuthorName                       | anguage  |
| Attraper lune                     |        | Efrat Haddi                      | French   |
|                                   | BookiD | AuthorName                       | Language |
| Bonsorr Lune                      |        | 9 Margaret WIse Brovn            | French   |
|                                   |        |                                  | Language |
| Cencrillon                        |        | Charles Perrault                 | French   |
| Harn Potter à [école des sorciers |        |                                  | French   |
|                                   |        | AuthorName                       | Language |
|                                   |        | 14Marc Thl                       | Freach   |
|                                   | BookiD | AuthorName                       |          |
| Faimedlrela verite                |        | 13 Shelley Admont                | French   |
| Le Lapin et La Lune               |        | 12 Marianne Lecron et P.B.Lecron | French   |
|                                   | Bookio | AuthorName                       |          |

## 11. CLOSE the report .

12.  Close the 'Crazy Wisdom Bookstore' database.

## END OF UNIT QUESTIONS

<!-- image -->

## 1. Identify the icons by matching them with their names:

In this image, we can see some files and there are some text boxes.

<!-- image -->

## 2. The figure below shows part of a Query.

In this image there is a table with some text on it.

<!-- image -->

| Field:    | Title   | NumPages   | BookFormat   |
|-----------|---------|------------|--------------|
| Table:    | Books   | Books      | Books        |
| Sort:     |         |            |              |
| Show:     |         |            |              |
| Criteria: |         | 50         |              |
| Or:       |         |            | Hardcover    |

Using table 'Books' you created in Activity 1, list the titles of books that consist of more than 50 pages or have 'Hardcover' as book format.

## END OF UNIT QUESTIONS

<!-- image -->

<!-- image -->

## 3. Match the term in Column 1 to its description in Column 2.

| Column 1      | Column 2                                                |                                       |
|---------------|---------------------------------------------------------|---------------------------------------|
| •             | • Allows to see the structure                           | Queries of the                        |
| •             | • A way to retrieve information based on specific       | Datasheet view a database conditions. |
| •             | • is used to organize and extracted from tables and     | Form It display queries.              |
| Design view • | •                                                       | Allows to see the contents of         |
| •             | • It is used to enter, edit and/or data from a table or | Report query.                         |

## 4. Below is a list of statements. State whether these are TRUE or FALSE. Put a tick  (  ) in the appropriate column.

| Statements                                                                | TRUE   | FALSE   |
|---------------------------------------------------------------------------|--------|---------|
| Querying means entering data into a table.                                |        |         |
| Data in reports cannot be changed.                                        |        |         |
| Forms are created using only the FormWizard option.                       |        |         |
| Queries are created either by using the Query Wizard or the Query Design. |        |         |
| The reports group is located on the Home tab.                             |        |         |

## END OF UNIT QUESTIONS

<!-- image -->

5. Name the buttons on the navigation bar as shown below:
6. What is the difference between a form and a report?
7. The structure for a table named 'Laptops' is shown below. The table keeps track of laptops sold at a shop.

In this image, we can see a list of names.

<!-- image -->

| FieldName    | DataType   | Field Size                     |
|--------------|------------|--------------------------------|
| LaptopID     | AutoNumber | 3                              |
| Brand        | Short Text | 30                             |
| Model        | Short Text | 30                             |
| Price        | Currency   |                                |
| Processor    | Short Text | 30                             |
| Screen       | Number     | Double (Use Decimal places: 1) |
| QtySold      | Number     | Long Integer                   |
| Availability | Yes/No     |                                |

<!-- image -->

<!-- image -->

- (a) How many fields are there in the table?

## Recall the concept of primary key done in grade 8 and answer the following question

- (b) Identify the field you would use as a primary key in the above table and give a reason for your answer.

Field:

Reason:

- (c) Customers often ask questions about the country, the weight and colour of laptops.  Suggest  two  more  fields  that  can  be  added  to  the  table 'Laptops' . Complete the table below by inserting the data type and the field size.

Field Name

Data Type

Field Size

## The table 'Laptops' contains the following data:

| laptops Brand   | Model        | Price Processor   |                  | OtySold   | Availability   |
|-----------------|--------------|-------------------|------------------|-----------|----------------|
| HP              | Pavillon 15  | Rs47,990 Core I7  |                  | 15.6      | 25             |
| Dell            |              | Rs37,550 Core I5  |                  | 15.6      | 26             |
| Lenovo          | Flex 5       |                   |                  | 14        | 15             |
| Acer            | Aspire 3     | Rs22,990 Core 13  |                  | 15.6      | 20             |
| Asus            | VivoBook S15 |                   | Rs39,550 Core I5 | 14        | 12             |
|                 |              |                   | Rso              |           |                |

## Refer to the Query Design below and answer the following question:

Field:

[Brand]

[Processor]

Table:

Sort:

Show

Criteria:

[Model]

[Price]

[Availability]

laptops laptops

laptops laptops

laptops

=Yes

## END OF UNIT QUESTIONS

<!-- image -->

- (d) Using the table 'Laptops' , display the result based on the above query.

8. Create  a  query  that  displays  the Brand , Model and Availability for  all  the  laptops that cost more than Rs.30000 or which have a Core I5 processor. Sort the records in ascending order based on the Brand . Fill the table below with the criteria given.

Field:

Table:

Sort:

Show:

Criteria:

or:

## Additional Notes

UNIT 9

Databases

## Additional Notes