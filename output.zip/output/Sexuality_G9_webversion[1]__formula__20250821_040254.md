## Sexuality EDUCATION

<!-- image -->

In this image, we can see a square with some text on it.

<!-- image -->

<!-- image -->

In this image we can see a cartoon image of a person holding a pen and writing something on a paper.

<!-- image -->

In this image we can see a cartoon image of a person holding a keyboard.

<!-- image -->

In this image we can see a cartoon image of a man and a woman.

<!-- image -->

In this image we can see a cartoon image of a person.

<!-- image -->

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of

Ministry of Education,Tertiary Education, Science and Technology

i

## Sexuality EDUCATION

<!-- image -->

In this image we can see a poster with some text.

<!-- image -->

<!-- image -->

In this image we can see a cartoon image of a person holding a pen and a cup.

<!-- image -->

In this image we can see a laptop and a keyboard.

<!-- image -->

In this image we can see a cartoon image of two people.

<!-- image -->

In this image we can see a sketch of a person.

<!-- image -->

- Head Curriculum Implementation, Textbook Development and Evaluation

## Panel Members

## MAURITIUS INSTITUTE OF EDUCATION

Dr R. Bholah

- Associate Professor, (Coordinator)

Mrs M. Veerapen

- Lecturer

Mrs P. Ramsaha

- Senior Lecturer

Dr M. C Thondee

- Senior Lecturer

## MINISTRY OF EDUCATION, TERTIARY EDUCATION, SCIENCE AND TECHNOLOGY

Ms  S. Jahangeer

- Educator

Ms K. Golam-Beetun

- Educator

## Acknowledgements

The Sexuality Education textbook panel wishes to thank all stakeholders including Medical doctors, psychologists, secondary school educators, non-governmental organisations and others for their constructive feedback and contribution in the validation exercises.

We are thankful to Dr R. Bungaree-Kolrapu for proof-reading this textbook.

Designed by:

Mr. L. NOWBOTSING

ISBN: 978-99949-75-16-7

- © Mauritius Institute of Education (2024)

All rights reserved. No part of this publication may be reproduced, stored in a retrieval system, or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise, without the prior permission of the Mauritius Institute of Education.

## FOREWORD

The Mauritius Institute of Education (MIE), under the guidance of the Ministry of Education, Tertiary Education, Science and Technology has been working jointly with various stakeholders to implement the Government's vision for education. The MIE has been active in promoting health education among children and young people at pre-primary, primary and secondary levels in the Republic of Mauritius. Sexuality Education (SE) has already been introduced at Grade 7 level.

Developing sexually is an expected and natural part of growing into adulthood. Sexual debut for most young people occurs during their teenage years. Due to lack of reliable information, young people experience sex in unplanned, unprotected and sometimes coercive ways, putting them at risk of unwanted pregnancies and sexually transmitted infections (STI) including HIV and AIDS. It  is  therefore  important  to  provide  young  people  with  comprehensive  sexuality education - with age-appropriate, culturally relevant and scientifically accurate information. Such education also provides young people with opportunities to explore attitudes and values and to practise the skills they will need to be able to make informed and responsible decisions about their sexual lives.

We are therefore pleased to provide Educators and students with teaching and learning SE materials in line with the International Technical Guidance on Sexuality Education (UNESCO, 2018), Sexuality Education Guideline and National Curriculum Framework 2017.

I wish to thank the SE panel members who have been engaged in the development of this SE resource manual, as well as various stakeholders who have been associated directly or indirectly with the writing of the materials or who have contributed by providing their invaluable and constructive views, suggestions and comments.

It is expected that Educators will confidently address SE related concepts and implement related activities in their respective class/school while considering the local regulations and policies as well as professional ethics. We are open to suggestions which would help us improve the SE manual further for subsequent years.

Dr H. Bessoondyal

Director, MIE

## Introduction

Sexually Transmitted infections (STI) including Acquired Immune Deficiency Syndrome (AIDS) and  teenage  pregnancy  are  some  of  the  common  public  health  problems  in  the  Republic of  Mauritius.  Although  adolescents  are  aware  of  these  health  problems,  many  continue  to participate in behaviours that place them at risk.  Education is therefore extremely important in understanding oneself - one's own body, reproductive health and sexuality. Evidence from studies has shown that SE does not promote earlier or increased sexual activity, but may lead to a delay in the onset of sexual activity and to use of safer sex practices among those who are sexually active. SE is thus aimed at promoting sexual health among young people by providing clear,  consistent  and  straightforward  guidance  for  students  of  lower  secondary  level.  The learning objectives of SE are to provide (i) students (children and young people) with age and developmentally appropriate information (fact-based, medically accurate and theory driven ) related to SE; (ii) opportunities to explore values, attitudes and norms concerning sexual and social relationships; and (iii) to reinforce skills and positive health behaviours as well as to adopt, practice and maintain healthy relationships and behaviours and to respect the right of others.

This  SE  resource  package  has  been  aligned  with  both  local  and  International UNESCO SE Guidelines covering a range of concepts organised around eight key themes:

1. Relationships
2. Values, rights, culture and sexuality
3. Understanding gender
4. Violence and staying safe
5. Skills for health and well-being
6. Human body and development
7. Sexuality and sexual behaviour
8. Sexual and reproductive health

While  developing  this  resource  package,  learning objectives  of  the  above  themes  were  thoroughly looked  into  and  concepts  were  re-organised  and presented  systematically  in  a  more  reader-friendly way in the following units:

In this image there is a diagram. In the diagram there are four different colors. In the top left corner there is a text. In the top right corner there is a text. In the bottom left corner there is a text. In the bottom right corner there is a text.

<!-- image -->

Understanding  that  sexuality  Education  has  been  a  very  sensitive  topic  in  many  countries including the Republic of Mauritius, the SE panel agreed to start with the Unit 'My Family' then 'My Friends and Peers' - which include concepts that children are very familiar with. Afterwards, they are provided with information about their own body, providing opportunities to become responsible and also learning about different values and life skills; societal norms, and sexual and reproductive health.

This SE resource manual is therefore intended to serve as a resource material for both Educators and students. Other than being, reader-friendly, it is written in a clear, concise, and thought -  provoking  manner  with  a  variety  of  activities.  It  also  provides  various  opportunities  for expanding children's understanding of SE while enabling the learners to relate basic principles of health to everyday situations and settings. This manual consists of a range of activities and involves several key teaching and learning strategies including role plays and in-depth group discussions to facilitate behavioural change. It thus provides opportunities for learners to think critically and build their own values about the SE topics and concepts. The young learners can also be instrumental in promoting sexual health education among their peers.

It  is  designed to provide learning experiences for students to attain, maintain and enhance their physical, mental and social well-being based on competencies spelt out in the National Curriculum Framework and the Guideline for Sexuality Education.

The journey we are embarking on is one that can make a critical difference in the lives of young people. Through our collective efforts, we look forward to helping teens lead a healthy life.

Dr Ravhee Bholah Associate Professor Sexuality Education Coordinator

MIE

## CONTENTS PAGE

| UNIT 1 | MYFAMILY                      | 1 - 8   |
|----------------------------------------|---------|
| UNIT 2 | MYFRIENDS ANDPEERS            | 9 - 18  |
| UNIT 3 |MYBODY                         | 19 - 26 |
| UNIT 4 | BEING RESPONSIBLE ANDMYVALUES | 27 - 38 |
| UNIT 5 | MYSOCIETY ANDCULTURE          | 39 - 48 |
| UNIT 6 | SEXUAL ANDREPRODUCTIVE HEALTH | 49 - 61 |
| GLOSSARY OFTERMS                       | 62 - 63 |

## UNIT 1 | MY FAMILY

In this image we can see a person holding a child in the hands. In the background we can see the sun.

<!-- image -->

## Lesson 1: Changes in responsibilities as we grow up

As  we  grow  up,  we  are  expected  to  be  more  responsible.  We  shoulder  our  personal responsibilities  by  caring  for  our  own  belongings.  We  also  help  our  parents  at  home  by contributing to household chores. Caring for others in the family is also part of our responsibilities. Carrying out our responsibilities helps us to manage our time, increase our self-esteem and develop healthy relationships with others.

<!-- image -->

ACTIVITY 1:

MY RESPONSIBILITIES AT HOME

In groups of 4, discuss and answer the following questions.

1. What do you understand by the term 'responsibility'?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Complete the table below with the responsibilities you have at home.

## Responsibilities for self

## Responsibilities to help others

(e.g. making my own bed)

(e.g. helping my siblings with their homework)

3. Explain how these responsibilities at home help you build a healthy relationship with your family.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Growing-up means assuming new responsibilities. List down any two new responsibilities you have as an adolescent.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

Read the following scenarios and answer the questions that follow.

Scenarios

Questions

Richa  is  a  15-year-old  girl.  She  is  expected  to  be  home  at  four  o'clock  for  a  religious ceremony. But she was still with her boyfriend at the bus terminal at 3.55 p.m.

Was Richa responsible?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What could she have done to show that she was a responsible adolescent?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Willy is a 14-year-old adolescent. While attending a family wedding, he saw one of his younger cousins smoking. He just walked away without any reaction.

Was Willy responsible?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What could he have done to show that he was a responsible adolescent?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Laina has gone to a party with her family. There, one boy wanted to get intimate with her and started touching and kissing her.

Was Laina responsible?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What could she have done to show that she was a responsible adolescent?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Scenarios

Questions

Troy is 14 years old. Most of his friends have a girlfriend and he does not have one. Troy decided to have a girlfriend too because of peer pressure.

Was Troy being responsible?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What could he have done to show that he was a responsible adolescent?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Amelie is a  14-year-old girl who has more than one sexual partner. She has missed her menses and is afraid that she may be pregnant. She does not want to talk to her parents, but  decided to seek help from her elder sister  at home.

Was Amelie being responsible?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

What could she have done to deal with the situation more responsibly?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Lesson 2: Responsible decision-making and family support

During adolescence, we experience physical, social, and emotional changes. These changes include sexual attraction to the opposite sex.  We need to take responsible decisions related to sexual attraction. We can discuss with family members if we are not sure about our decisions.

<!-- image -->

## Read the case study below and answer the questions that follow.

In this image we can see a cartoon image of a man and a woman.

<!-- image -->

Alia is 14 years old  and she is in Grade 9. She is being pressurised by her boyfriend to have sex. She does not know what to do. She does not want to lose her boyfriend and she is also aware that sex at such an early age is not acceptable by society and can lead to teenage pregnancy and serious health issues.

1. Explain Alia's dilemma.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. What choices does Alia have?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Suggest the possible consequences of the choices proposed in part 2.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. With whom can Alia share her concern at home?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 5. How can Alia' s family help her in this situation?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## KEY MESSAGE

If ever you feel uncomfortable or unsafe because someone wants to have sex with you, you have the right to refuse and seek support from a trusted adult.

## Lesson 3: Parents and adolescents in the family

Our home is a place where we feel loved and accepted by our family members. Our family supports us in developing self-confidence and our identity. However, we see that relationships between teenagers and their parents change during adolescence. Most young people and their families have some ups and downs during adolescence.

<!-- image -->

## ACTIVITY 1: CONFLICT BETWEEN PARENTS AND CHILDREN

Work in groups of 4-6 students.

Watch the video on the link given below and discuss the following questions.

https://www.youtube.com/watch?v=STwChkJbzPs

1. What is happening in the three stories in the video?
2. Discuss the conflict/misunderstanding you notice in the video.
3. What could be done to solve the conflict/misunderstanding in the video?

( N.B: Teachers may use other relevant videos in their class. )

<!-- image -->

Read the following cases and discuss how the conflict could have been addressed differently.

## Case

## What could have been done

After school, Sia asked her mum to buy her a  new  mobile  phone  as  her  friend  has  a phone with latest technology. Her mother said that she could not afford to do so. Sia got  angry  and  started  arguing  with  her mother that she did not get anything, and that her mother did not love her.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Mathieu  usually  reaches  home  at  three o'clock in the afternoon. He reached home at half past three as one of his friends met with an accident and he had to help him. The  moment  he  entered  the  house,  his father started shouting at him.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Jane  is  very  worried  about  the  pimples she has on her face due to puberty. She is  always  seen  popping  them  and  her mother is always asking her not to do so. She keeps on repeating that she has acne because of her parents' genes.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## KEY MESSAGE

We can see conflicts between teenagers and parents in many families. It is important to discuss and solve conflicts and misunderstanding with parents. We should remember that teenagers still need parental and family support as much as they did when they were younger.

## DID YOU KNOW?

To resolve conflicts in your everyday life, you should communicate with others, stay calm during discussions, and respect others.

<!-- image -->

<!-- image -->

Read the story below and answer the questions that follow.

Mrs Jamie shouted and informed all her children that dinner was ready. The younger children came immediately to the dining table. She had to go to the bedroom of Katy, her sixteen-yearold daughter, to call her for dinner.  Katy did not always listen to her mother, but she sometimes helped her in the preparation and serving of dinner.

As they all sat down for dinner, Jamie thought that it was thanks to Katy that the family was having dinner today. With the water heater breaking and the car needing a servicing, funds were running thin this month. Luckily, Katy was helping her family out by delivering newspapers in the morning and picking the younger kids from school.

The younger kids also helped by cleaning their rooms and helping their mother with setting

the table and washing the dishes. As a single mom, she had also been fighting with her older daughter lately about the usual teen stuff, hoping she did not make the same mistakes as she did. However, although Katy fought with her mom, she eventually listened and kept her promise to come home early after school and to always tell her where she was going and who she was going out with.

Mrs  Jamie  wondered  how  their  family  was  going  to  make  it  through  this  difficult  time  as they were passing around the salad, although, in the back of her mind, she felt that she had a supportive family and that without them life would be more difficult.

1. Explain how members in this family showed:

- a. mutual respect for each other

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

b. support each other.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Discuss how mutual respect and support helped the family survive a financial crisis.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Suggest how a family can support its younger members (adolescents) in issues related to sexual health.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## UNIT 2 | MY FRIENDS AND PEERS

In this image we can see a group of people. The people are smiling.

<!-- image -->

## Lesson 1: Types of relationships

In Grade 8, you have learnt that a relationship is any connection between two people, which can be either positive or negative. The phrase 'being in a relationship,' while often linked with romantic relationships, can refer to a variety of associations one person has with another.

<!-- image -->

Observe the diagram and answer the questions which follow.

The image is a pie chart that represents the distribution of various relationships among four categories: family, work, sexual, and acquaintances. The pie chart is divided into four sections, each representing a different relationship. The categories are:
1. Family: This section includes the following relationships:
   - Work: This section includes the following relationships:
     - Family: This section includes the following relationships:
     - Sexual: This section includes the following relationships:
     - Aqual: This section includes the following relationships:
     - Apartants: This section includes the following relationships:
     - Friends: This section includes the following relationships:
     - Other: This section includes the following relationships:
     - None: This section includes the following relationships:
2. Work: This section includes the following relationships:
     - Family: This section includes the following relationships:
     - Sexual: This section includes the following relationships:
     - Aqual: This section includes the following relationships:
     - Apartants: This section

<!-- image -->

1. Which is the most important relationship for you as an adolescent? Why?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Which relationship is the least important for you? Why?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 2: HEALTHY AND UNHEALTHY RELATIONSHIPS

In Grade 7, you have learnt about healthy and unhealthy relationships. Some relationships are healthy and promote wellbeing while some relationships can be unhealthy and can harm us. Healthy relationships are always based on understanding, care, respect, support, and honesty.

- a. Read  the  following  statements  and  identify  whether  they  are  signs  of  a  healthy  or  an unhealthy relationship by putting a tick in the appropriate column.
- b. Discuss  each  statement  with  your  peer  and  justify  why  the  relationships  are  healthy  or unhealthy. Write your answers in your notebook.

| Sn.   | Statement                                                                                                                             | Healthy relationship   | Unhealthy relationship   |
|-------|---------------------------------------------------------------------------------------------------------------------------------------|------------------------|--------------------------|
| 1.    | You feel good about yourself when you are around the other person.                                                                    |                        |                          |
| 2.    | You feel that you give more attention to your partner than he/she gives to you.                                                       |                        |                          |
| 3.    | You like to spend time together but also enjoy doing things apart.                                                                    |                        |                          |
| 4.    | You respect each other's opinion.You listen and try to understand his/her point of view even if you do not always agree with him/her. |                        |                          |
| 5 .   | You feel there is no respect for you or your opinion.                                                                                 |                        |                          |
| 6.    | You feel pressured to spend time together.                                                                                            |                        |                          |
| 7.    | He/shemakesyoufeelguiltywhenyouareboth apart from each other.                                                                         |                        |                          |
| 8.    | There is communication, sharing, and trust in your relationship with your friend. You feel safe and trust to share secrets.           |                        |                          |
| 9.    | You feel fear in your relationship.                                                                                                   |                        |                          |

<!-- image -->

## ACTIVITY 3: DEALING WITH ABUSIVE RELATIONSHIPS

An abusive relationship is  a  term  that  describes any relationship where one person exerts power and control over the other in a negative way.

Abuse can be physical, emotional, verbal, or financial. Victims of abusive relationships face a higher risk of depression, anxiety, suicidal tendencies, and addictions. To avoid all these mental health and social issues, we should be able to deal with, and get out of abusive relationships.

Read the following stories and answer the questions that follow.

## STORY 1

Shania met Ryan when they were studying at the university. They started dating each other and were very happy together. Ryan was very caring and loving. After their studies, they got married. Every Saturday night, they used to have parties at their place. Then, gradually, Ryan started calling his friends home everyday and they consumed alcohol till late at night. When Shania complained about this situation, Ryan became aggressive and hit Shania and said that: 'I am the man of the house, and I can do what I like. You are the wife, and you must be submissive.' The fights became worse, and Shania was admitted to the hospital twice. She then decided that it was better that they separate from each other.

1. Describe the relationship between Shania and Ryan.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Explain how Ryan was abusing Shania.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. If you were Shania's friend, what advice would you give to her?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. If you were Ryan's friend, what advice would you give to him?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. List some sources of help and support for the abuse Shania is facing.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## STORY 2

Tina is in Grade 11 and she has started dating Hans a few weeks back. Whenever they meet, Hans takes Tina's mobile and checks all the messages and calls. He questions her about all the people she is in contact with. He has also instructed Tina to call him and request his permission before she does anything. Last night, Tina saw a boy standing outside her house and when her father checked, it was Hans. He was very insecure and wanted to follow Tina everywhere.

1. Was Tina in an abusive relationship? Why?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. What would you do if you were in Tina's place?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Lesson 2: Expressing emotions in relationships

In Grade 7 and 8, you have learnt that we have different relationships with different people. There are different types of love as well. Each one of us expresses our love differently. Sometimes we are kind to each other; at times we present gifts to our loved ones, or we spend quality time with our close ones.

<!-- image -->

In the space below, draw a card to express your love to someone dear to you.

<!-- image -->

## ACTIVITY 2: EXPRESSING EMOTIONS IN DIFFERENT SITUATIONS

Apart from love, we experience different emotions when interacting with our dear ones. Study the different situations. Identify the emotion you will experience and how you will express the emotions.

| Situation                                                                                                         | Emotion experienced   | Howweexpress the emotions   |
|-------------------------------------------------------------------------------------------------------------------|-----------------------|-----------------------------|
| Your teacher praises you for your good performance in your last test.                                             |                       |                             |
| Every time you want to talk to your mum, your brother tries to get all the attention and he succeeds in doing so. |                       |                             |
| Your best friend is flirting with a girl/ boy on whom you have had a crush since last year.                       |                       |                             |
| Oneof your classmates is trying to get close and intimate with you.                                               |                       |                             |
| Your best friend gives you the giftyouwereexpectingonyour birthday.                                               |                       |                             |

## Lesson 3: Love and infatuation

Study the conversation between two friends and answer the questions that follow.

| Reva:   | Hi Sara, how are you?                                                                                                                                                                                                     |
|---------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Sara:   | I'm fine and what about you? Howwere your holidays?                                                                                                                                                                       |
| Reva:   | I am fine and I am very happy. I met one of my childhood friends, Mathieu.We spent the whole month roaming around and getting to know each other.We did different activities together. Wetalk to each other everyday.     |
| Sara:   | I think you love him.                                                                                                                                                                                                     |
| Reva:   | I amnot too sure, it can be. Howwere your holidays?                                                                                                                                                                       |
| Sara:   | It wasfine. I wenttomycousinsister's birthdayparty.IsawaveryhandsomeboyandI think I love him.Wetalked briefly during the party.Weare friends on Facebook. I chat with him everyday. But you know, sometimes he avoids me. |

1. Why is Sara attracted to that boy?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Does Sara know the boy well?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Do you think that she is really in love with that boy or is it just an attraction?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Does Reva know the boy well? Why do you think so?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Do you think that Reva is in love with the boy?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. What is the difference between Reva's and Sara's situations?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## KEY MESSAGE

Love is a warm attachment, enthusiasm, or devotion to another person. Infatuation is a strong feeling of attraction and fascination towards someone, often without knowing them well. Love is a deep committed attachment to someone whereas infatuation is shallow.

## Lesson 4: Marriage and other long-term commitments

Marriage is the term used to describe the legally-recognised relationships between an adult male and female. Other examples of long-term commitments are live-in relationships which are also known as cohabitation .  All  types of long-term commitments bond two individuals who share sexual intimacy, love, and friendship, among others. The main difference between cohabitation and marriage is that cohabitation is living together, and having a sexual relationship without being married, while marriage is a legal union between two people.

<!-- image -->

Work in pairs and answer the following questions.

1. Discuss why people choose to get married.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. If  you had to choose between marriage and a live-in relationship, which one would you prefer? Why?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ACTIVITY 2: REWARDS AND CHALLENGES OF MARRIAGE AND LONG-TERM COMMITMENT

<!-- image -->

Read the case studies and answer the questions which follow.

## Case study one: Ria and Andy

Ria had been in a live-in relationship with her boyfriend Andy for the past five months. They were very happy together and shared all the household expenses. They often went out together and enjoyed a happy sexual life.  One month ago, Andy lost his job and Ria had to run the household. She found it difficult to cater for the rent, utility bills and food provision alone. When she tried to explain to Andy that she could not do everything on her own, Andy got angry and started blaming Ria for being inconsiderate. The arguments started to be more intense every day.

Moreover, Andy was frustrated staying home all day;  he would usually fight with Ria and even beat her.  He  also  started  suspecting  that  Ria  had  another  boyfriend. This  caused further arguments and fights as he thought Ria was having an affair with someone else. However,  Ria  was  so  tired  with  the  extra  responsibilities  that  she  did  not  want  to  get engaged in other activities.

1. How was Andy and Ria's relationship when they started living together?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. How did the relationship between Andy and Ria change since he lost his job?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 3. How did this affect their relationship?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 4. How could Andy and Ria's relationship become healthy again?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Case study two: Surekha and Vinod

When Surekha met Vinod for the first time, she was 18 years old and had just finished secondary school. Vinod was working as a clerk in a bank, and he instantly fell in love with Surekha. Surekha was also attracted to him and accepted to date him. They started spending time together and realised that they could not live without each other. Vinod wanted to marry Surekha, but both came from poor families and could not spend a lot of money to organise their wedding. As soon as Surekha started working as a receptionist, they both got married. They have two kids and are now a family. Vinod feels happy to be a family man and Surekha is thankful that Vinod loves, respects, and is faithful to her.

1. What kind of relationship do Surekha and Vinod share?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Explain why Vinod and Surekha's relationship is successful and both of them are happy?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Lesson 5: Parenting

The first reaction of parents when they get to know a baby is on its way is whether it is going to be a boy or a girl. This is because children's gender is a powerful identity marker which shapes the child's life. Gender markers strongly influence child rearing practices in most societies.

## ACTIVITY 1: IMPACT OF CULTURE AND GENDER ROLES ON PARENTING

<!-- image -->

## Read the following story:

Bob is five years old, and likes the company of Maya, his elder sister who is 12 years old, but his mother told him to play more with his male friends in the neighbourhood. Both children have been treated fairly but now Bob's mother feels that she needs to make both her children interact with peers of their respective gender. Maya is encouraged to help her mother in household chores while Bob would accompany his dad and cousins to play football, learn to fish, swim, and repair his broken toys on his own. Maya is seldom found roaming around or playing outside her house but prefers reading her favourite books in her room during her spare time. Sometimes she shares them as bedtime stories with Bob when her parents are out for a dinner.

1. What is Bob learning from his father?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. What is Bob learning from his mother?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. How is Maya portrayed in this scenario?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Suggest what factors influence the parents' different treatment towards:

- (i) Bob

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Maya

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## UNIT 3 | MY BODY

In this image we can see a person standing and smiling. In the background there is a white color wall.

<!-- image -->

## Introduction

In Grade 7 and 8, you have learnt about the physical, emotional, and social changes that occur during puberty. Puberty is the time in life when a boy or girl becomes sexually mature. It is a process that usually happens between the age of 10 and 14 for girls and the age of 12 and 16 for boys. It causes physical changes and affects boys and girls differently. Among the physical changes in boys, erections, and night-time ejaculations ( wet dreams )  also  start  happening. Erections are caused by changing hormones and can therefore happen unexpectedly, and not just when boys are thinking of something sexual. Wet dreams happen when boys ejaculate sperm when they are sleeping.

## Lesson 1: Puberty

<!-- image -->

## Work in groups of 4.

Each group  will list the changes that occur during puberty in:

- (i) boys
- (ii) girls
- (iii) both boys and girls

Use the answers from (i) to (iii) to complete the diagram below in your notebook.

## Changes that occur in boys

Changes that occur in girls

The image contains a circle with a diameter of 2.

<!-- image -->

Teacher will have a class discussion on puberty related to the above diagram.

He/she will explain the physical, emotional and social changes that occur in boys and girls during puberty. (He/she may also refer to the male and female reproductive systems during his/ her explanation.)

<!-- image -->

Read the stories below and answer the questions that follow:

## STORY 1

Toby is a 15-year-old school student undergoing puberty. Everyday, on his way to school, he comes across a beautiful girl.  Gradually,  he  starts  to  fall  in  love  with  her.  When he goes to bed at night, he has her on his mind. He dreams of her. This gives him a pleasurable feeling to the point when one day his penis became erect and  he  ejaculated.  Consequently,  Toby  woke up  in  confusion  with  a  feeling  of  wetness  in his pants and on his bed. This is called wet dream (nocturnal emission) .

In this image we can see a cartoon image of a person standing on the bed. In the background there is a bed and a pillow.

<!-- image -->

## STORY 2

Tedy is a 23-year-old university student. He has a beautiful fiancée who is studying abroad. He misses his fiancée very much. At times, before going to bed at night, he thinks about his fiancée and dreams of her. Consequently, he also has wet dreams.

1. What is the name of the student undergoing:
- a) Puberty?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b)  Adulthood?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. State one factor which could have caused wet dreams in both situations.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Suggest two other factors which can cause wet dreams.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. List two feelings which are experienced by boys during wet dreams.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Which two processes cause wetness in pants and bed during wet dreams?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Lesson 2: Body Image

Body image is what people think of themselves and say to themselves as they look in the mirror. An adolescent may have a positive or negative body image based on how he/she feels about what he/she sees in the mirror.

## ACTIVITY 1(a): BODY IMAGE

<!-- image -->

Read the paragraph below and answer the questions that follow in your notebook.

- a. What do you think when you look at yourself?
2. b.
3. Do you like or not like parts, or all of yourself?
4. You may think your face looks nice or you may wish you looked better. You may also not like parts of your body, for example, you may wish your hair looked different.

As an adolescent, step backwards from the mirror and look at your figure. Boys may like their athletic, masculine body or they may wish they had a more masculine appearance. Girls may like their curvaceous and feminine bodies or may wish they had a more feminine appearance. Other adolescents may just be happy the way they are.

1. When you look in the mirror, what do you see?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. What do you think when you look at yourself?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Do you like or not like parts, or all of yourself?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. How would you like to see yourself?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

Work in pairs. Study an extract from local newspaper and answer the questions that follow.

## Facts about Body Image

There are many influences that can make adolescents feel positive or negative about their bodies. How adolescents feel about their bodies depend upon their body image, level of physical activity, and how their peers, family members and other people look at them and speak to them about their bodies.

The media has an important influence on adolescents as television, magazines, newspapers, and the internet may distort the perception of body image by portraying an ideal male as having an athletic body and an ideal female as having an hourglass shape.

Adolescents may also face many situations where they feel other peers and adults may be  looking  at  them.  This  is  called  an imaginary  audience and  refers  to  a  perception by  adolescents  that  they  are  being  observed  by  others.  It  is  called  imaginary  because it  is  not  real  but  imagined, and arises because adolescent brain capacity increases, and consequently their perspective-taking ability causes adolescents to think too much about themselves. Although the perspective-taking ability is good because the teenager can think more, thinking too much, especially about body image may be detrimental especially if the adolescent has a negative self-image. An imaginary audience coupled with idealism, which are both consequences of cognitive growth, may exacerbate a negative self-image.

## Questions

1. Who can cause more harm by creating a negative body image, yourself, or other people? How?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Assuming that you have constructed a negative body image, what should you do:
2. a). if you keep feeling bad about the way you look?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b). if you realise that you are causing yourself unnecessary pain?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 3. How would you reconstruct a positive body image?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ACTIVITY 2(a): SURGICAL METHODS TO CHANGE PHYSICAL APPEARANCE

<!-- image -->

Cosmetic surgery is a medical procedure used to change the physical appearance of a person.

- (a)  Study the pictures below and fill in the blank spaces using the words in brackets about the different types of cosmetic surgery methods available to change one's physical appearance:

nose reshaping, tummy reduction, permanent laser hair removal, breast augmentation, lip filling

<!-- image -->

Picture A:

<!-- image -->

<!-- image -->

Picture B:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Picture C:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Picture D:

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Picture E:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## (b) Name 3 other cosmetic surgery methods that you know.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Your teacher may guide and help you in this activity.

<!-- image -->

## ACTIVITY 2(b): SURGICAL METHODS TO CHANGE PHYSICAL APPEARANCE

1. Work in groups of 4.
2. Identify the different types of cosmetic surgery methods available in Mauritius (Hint: You may wish to consult a local newspaper or the website of a local hospital or clinic to guide you)
3. Design  a  poster  that  can  be  used  to  sensitise  the  school  population  about  the  risks  or dangers associated with cosmetic surgery methods.
4. Each poster will be displayed on the classroom wall.
5. Each group will present their respective poster.
6. Teacher will have a class discussion after all presentations have been made and will highlight the risks/dangers of using surgical methods to change one's physical appearance.

## DID YOU KNOW?

Some common cosmetic surgery complications are:

<!-- image -->

- dissatisfaction with appearance
- troubling scars
- organ damage
- nerve damage
- infection
- bruises
- blood loss

## UNIT 4 | BEING RESPONSIBLE AND MY VALUES

In this image we can see a group of people standing and smiling. In the background there is a sky.

<!-- image -->

## Introduction

In grade 8, you have learnt different concepts about tolerance and respect. In this unit you will be exposed to the concepts of tolerance and respect as part of the core values required to live harmoniously in society.

You will also learn how taboos (restrictions which are sanctioned by society or traditions) , social conventions (norms and mores) , and beliefs (opinions which we hold as true) may act as a barrier to dialogue on issues related to the sexuality of adolescents.

## Lesson 1: Bias and Discrimination

It is often observed that people tend to be biased and intolerant, and negatively discriminate and stigmatise others. Such actions can harm individuals and have serious consequences on social groups and communities.

## Vocabulary

A bias is a prejudice caused in favour of, or against a person or group of persons compared to another. When we say that someone is being biased, we refer to somebody who shows partiality or prejudice or preference which influences one's judgement.

Stigma is viewing people negatively and not valuing them. Stigma creates inequalities among individuals and usually leads to discrimination.

Discrimination is any type of action based on stigma that violates individuals' rights. One  is  discriminated  against  when  one  is  judged  and  treated  badly.  For  example,  a person or a group may be discriminated against because of their race, gender, age, sexual orientation, disability, country of origin, religion, skin colour, health problems or mental health status. Someone living with HIV, a foreigner and a pregnant girl can also suffer from discrimination.

## ACTIVITY 1: BEING AWARE OF BIASES AND DISCRIMINATION IN MY SURROUNDINGS

<!-- image -->

## Read the extract below and answer the questions that follow.

Schools are places where both formal and informal learning take place. Schools can also be considered as a replica of the wider society. The school environment has a direct impact on how well students learn and interact with their peers. School managers, rectors and teachers work hard to make their school and classrooms welcoming, where each student feels involved. Despite these efforts, students who are experiencing sexuality crisis, who are or are perceived to be - lesbian, gay, bisexual and/or transgender (LGBT) continue to be discriminated against

and are often victims of verbal and physical abuse more than non-LGBT youth. Moreover, bias against  them  is  likely  to  be  visible  in  the  form  of  bullying,  harassment  and  social  isolation throughout their schooling, which are also likely to lead to negative educational outcomes.

(Adapted from an extract from the source: http://www.tolerance.org/lgbt-best-practices)

<!-- image -->

1. You are required to work in pairs and discuss how LGBT teenagers may be negatively discriminated against in the following contexts during their school year:

- a).  participation in sports and related tournaments organised at school.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b).  enjoying academic success.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- C).  having friends at school.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- d).  any other example of your choice.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ACTIVITY 2: MY RESPONSIBILITY TO SPEAK AGAINST BIAS

A bias is a point of view influenced by experience. We all  have different biases but we are not always aware of them.  There are different types of biases, for example; racial bias, gender bias, and cultural bias. Biases can create unfair situations. It is our responsibility to speak against any kind of biases.

## Answer the following questions:

1. Recall and write two examples of your personal experience of biases.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. In groups of four,
2. a).  Observe instances of bias in your school for one week;
3. b).  Record your observations;
4. c).  Find ways to report biases.

Note: Each group should have one recorder and one reporter.

3. Consider the following log sheet for observing, recording, and reporting biases.
4. At the end of one week, the reporter from each group summarises the group findings and shares these with the class.
5. Identify which students appeared to reproduce and sustain behaviours which are termed as  ' biased ' .

LOG SHEET

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. Discuss which students appeared to be most often the target of bias.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7. Explain why you think it is important to take actions/speak up against biases.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

DEALING WITH DISCRIMINATION AND BIAS

ACTIVITY 3:

Bias and negative discrimination may have severe consequences on the physical, social, emotional, and mental health of an individual. The table below shows some forms of bias and discrimination which may take place in your day-to-day routine.  Fill in the table below by ticking the appropriate

columns.

## Fill in the table below assuming that you are a victim of any of the following:

1.

(Tick where appropriate)

|                             | Other place (Please specify:___)   |                                                                                                                                                                          |                                                                                                                                                                                                          |
|-----------------------------|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| I would speak:              | On radio/ social media             |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would speak:              | During school assembly             |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would speak:              | In the staff room                  |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would speak:              | On the playground                  |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would speak:              | In the classroom                   |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would speak:              | In the school office               |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would choose to speak to: | Police/NGOs/ Doctor                |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would choose to speak to: | Rector                             |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would choose to speak to: | Parent                             |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would choose to speak to: | Teacher                            |                                                                                                                                                                          |                                                                                                                                                                                                          |
| I would choose to speak to: | Friend                             |                                                                                                                                                                          |                                                                                                                                                                                                          |
|                             | If I amvictim of:                  | Bullying Everyday, a group of boys/girls wait for menear the school gate and force meto give them mylunch or money. I amscared of them and I can't concentrate in class. | Isolation My classmates refuse to be friend with mebecause they say Iam different, and I can cause them harm. Most of the time I amalone in class and even during recess. I can say I don't have friends |

| Other place (Please   | specify:___)                                                                                                                                                                                                                                                                                                                                                                                                                                                |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
|-----------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|--------------------------------------|
| On radio/             | social media                                                                                                                                                                                                                                                                                                                                                                                                                                                |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
|                       | During school assembly                                                                                                                                                                                                                                                                                                                                                                                                                                      |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| speak:                | In the staff room                                                                                                                                                                                                                                                                                                                                                                                                                                           |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| I would               | On the playground                                                                                                                                                                                                                                                                                                                                                                                                                                           |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
|                       | In the classroom                                                                                                                                                                                                                                                                                                                                                                                                                                            |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
|                       | In the school office                                                                                                                                                                                                                                                                                                                                                                                                                                        |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| to:                   | Police/NGOs/ Doctor                                                                                                                                                                                                                                                                                                                                                                                                                                         |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| to speak              | Rector                                                                                                                                                                                                                                                                                                                                                                                                                                                      |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| choose                | Parent                                                                                                                                                                                                                                                                                                                                                                                                                                                      |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| I would               | Teacher                                                                                                                                                                                                                                                                                                                                                                                                                                                     |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
|                       | Friend                                                                                                                                                                                                                                                                                                                                                                                                                                                      |                  |               |                                                                                                                                                       |                                                                                                            |                                                                        |                                      |
| If I amvictim of:     | My classmates and peers have refused to include mein their group; they have clearly toldme they don't like mebecause Iam not a real man/ I amnot feminine enough. They tease meand I should play with girls/ I should roam around with boys only. Hurtful comments and I often get hurtful comments on the way I dress, talk, and behave myneighbourhood. Sometimes, myownrelatives are ashamed of meand prefer to'hide'me when they invite people at home. | Rejection tellme | behaviours in | Emotional abuse Whenever I try to express myviews, I amtold I should keep silent. Iam never taken seriously and myviews are never taken into account. | Sexual abuse 1. My family member/friend forces meto have sex with him/ her without myconsent and freewill. | 2. I have experienced unsafe touches in the school bus/ school toilet. | 3. I amforced to watch porn at home. |

2. In  groups  of  four  to  five  justify  your  answer  for  each  one  of  the  above  statements provided.

## Speaking against:

1. Bullying

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Isolation

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Rejection

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Hurtful comments and behaviours

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Physical abuse

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. Emotional abuse

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 7. Sexual abuse

(i).  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(ii). \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(iii).  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Lesson 2: Values, Attitudes and Skills

In this section, we shall discuss the importance of tolerance and respect in relation to different values, beliefs, and attitudes with respect to sexuality.

## ACTIVITY 1: DEVELOPING TOLERANT ATTITUDES AND RESPECT

<!-- image -->

## 1. Read the extract below.

Andy is 16 years old and has a girlfriend but hides this from his parents. He is scared that his parents might reprimand him as they are very traditional. His father insists that Andy does extremely well in his studies. However, one day, Andy is spotted with his girlfriend after school. His father later took him for a walk where he had conversation with him.

## 2. Discuss the possible reaction of Andy in the following scenarios and put a tick in the columns accordingly.

| Scenario                                                                                                                                                                                 | Possible reaction of Andy                              | Andy's Level of tolerance to his dad High/Low/Non-existent   | Dad's level of tolerance High/Low/Non- existent   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------------|---------------------------------------------------|
| The father shouts at him and blames him for being inconsiderate and irresponsible.                                                                                                       | Shocked                                                |                                                              |                                                   |
| The father shouts at him and blames him for being inconsiderate and irresponsible.                                                                                                       | Guilt Feeling Revolt                                   |                                                              |                                                   |
| The father calmly explains to him that it is normal to have a girlfriend, but he should be careful and be aware that his actions may have serious consequences (e.g., teenage pregnancy; | Dad trusts mebut he doubts I can takemy own decisions. |                                                              |                                                   |
| The father calmly explains to him that it is normal to have a girlfriend, but he should be careful and be aware that his actions may have serious consequences (e.g., teenage pregnancy; | Dad is helpful and I should take his advice seriously. |                                                              |                                                   |
| The father asks him whether he is having sex with his girlfriend.                                                                                                                        | He does not trust me.                                  |                                                              |                                                   |
| The father asks him whether he is having sex with his girlfriend.                                                                                                                        | He thinks I amnot responsible.                         |                                                              |                                                   |
| The father asks him whether he is having sex with his girlfriend.                                                                                                                        | He is a caring father.                                 |                                                              |                                                   |
| The father asks him whether he is having sex with his girlfriend.                                                                                                                        | He does not understand me.                             |                                                              |                                                   |
| His father explains that even if both consent to having sex, they do not have the required age to do so, according to law.                                                               | I feel Dad is too controlling.                         |                                                              |                                                   |
| His father explains that even if both consent to having sex, they do not have the required age to do so, according to law.                                                               | Dad is helping meto take a good decision.              |                                                              |                                                   |

<!-- image -->

## ACTIVITY 2: ASSESS YOUR DEGREE OF TOLERANCE

1.  You  are  required  to  fill  in  the  table  below  to  test  your  level  of  tolerance  in  different situations. Tick the appropriate column and justify your response for each statement in your note book.

| Statements                                                                                                       | Tolerant   | Intolerant   |
|------------------------------------------------------------------------------------------------------------------|------------|--------------|
| Making friends with classmates who are from other ethnic groups.                                                 |            |              |
| Respecting people irrespective of their opinions.                                                                |            |              |
| Respecting people's decisions about their sexuality although I do not always agree with them.                    |            |              |
| Accepting the fact that girls can be more confident than boys and take on leadership roles.                      |            |              |
| Accepting that some boys may prefer to stay indoors and are less involved in outdoor games and sports.           |            |              |
| Having friends who have experienced deprivation and poverty.                                                     |            |              |
| Being familiar to the fact that girls can be leaders and boys can be followers.                                  |            |              |
| Recognising that some people have the right to choose their sexual partners.                                     |            |              |
| Accepting somebody who is homosexual.                                                                            |            |              |
| Treating your friend who has an STI, with dignity.                                                               |            |              |
| Treating your friend whose parent is HIV positive, with dignity.                                                 |            |              |
| Respecting your classmate's choice not to be sexually active or his/her choice for sexual abstinence.            |            |              |
| Respecting your classmate's choice to have a boyfriend/girlfriend.                                               |            |              |
| Respecting your classmate's choice not to have a boyfriend/girlfriend.                                           |            |              |
| Accepting everybody as your equals irrespective of their gender, religion, and cultural affiliations.            |            |              |
| Developing empathy towards myclassmate who got pregnant.                                                         |            |              |
| Developing empathy towards myclassmate who tells methat he likes wearing feminine clothes; and wants to join me. |            |              |
| Making friends with people outside myreligious community.                                                        |            |              |
| Treating your friend who has depression with dignity.                                                            |            |              |

6. In groups of four to five, choose any three statements from the table on page 35 of the above, compare your responses, and discuss why you should be tolerant in each situation chosen. Explain why you would or would not adopt a tolerant attitude.

Statement 1: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Statement 2: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Statement 3: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7. With your classmates, reflect on the importance of showing tolerance and respect to each other irrespective of your differences.

(e.g. When we respect others: When my friend told me she was pregnant, first of all I did not judge her, I continued to be friends with her, I tried to be compassionate and helped her to catch up on her studies when she missed classes.)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

However,  there  are  instances  where  you  cannot  tolerate  unwanted  behaviours  like indiscipline, deviance, bullying, discrimination, and biases. In those instances, you have to

take bold decisions and actions to say 'NO' . Suggest how this can be done.

(e.g. My friend has started smoking on school premises and I refused to cover up for him when he told me to hide his cigarettes in my bag.)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 5: CREATE A CONDUCIVE CLASSROOM ENVIRONMENT FOR ALL STUDENTS

Now  that  you  are  well  informed  about  the  importance  of  tolerance  and  respect  towards individuals who are different and who choose to be different, you are required to devise a plan for your classroom which will sensitise your classmates and peers about fostering a environment of tolerance and respect among yourselves. Your plan should include the following:

1. Devise a motto for the whole class -e.g., 'we belong here' or 'we are family' .
2. A set of rules agreed among the whole class on the importance of respect and tolerance towards each other. You need to include features of tolerance and respect; (e.g., It is my duty not to be hurtful towards my peers and classmates, or we are all equals in class).
3. Design the classroom physical space. This will include a map of the ways classmates are seated (e.g., we make sure everybody is at ease in class and we plan a seating arrangement which showcases diversity and tolerance, and the class has wall decorations with inspirational quotes on tolerance and respect) .
4. Plan one daily routine, or/and get a list of activities expected from the whole class which fosters  tolerance  and  respect. (e.g.,  we  have  a  slogan  to  motivate  us  when  we  feel  down; we celebrate each classmate's birthday; we motivate slow learners by helping them do with homework; we stick to each other during recess; we look after each other and ensure we are safe from bullying; we report abuse).
5. Saying  NO  to  unwanted  behaviours  and  actions  that  may  harm  us  physically, emotionally, and sexually (we are aware of safe and unsafe touch and sexual abuse, and we speak about it frequently with our peers, teachers and parents).

## UNIT 5 | MY SOCIETY AND CULTURE

In this image we can see a group of people sitting on the floor. The people are holding some objects.

<!-- image -->

## Introduction

In unit 4, you were exposed to the concepts of values that influence your behaviour and actions towards any individuals, irrespective of who they are. In the present unit, you will learn about unwanted sexual attention, harassment and stigma.

## Lesson 1: Source of Unwanted Sexual Attention

- I. The internet, cell phones and other new media can be a source of unwanted sexual attention.

An unwanted sexual attention is another way of describing sexual harassment, attempts to rape, voyeurism, unsafe touching, and exhibitionism among others. As such, unwanted sexual attention can be verbal, non-verbal, and physical behaviours, whether intended or unintended, which are offensive and unreciprocated. The perpetrator may be in a situation of power and privilege. In such cases, sexual favours are forced, are without consent, and involve threats, taunts and/or attacks on the victims being abused.

Sexual abuse refers to sexual behaviour that is forced upon someone against his/her will.

Verbal sexual abuse refers to unwanted intimate questions relating to one's body, clothes, or intimacy. These may include jokes with sexual innuendos or proposals made earnestly or even jokingly for sexual activities.

Non-verbal sexual abuse refers to staring at people to intimidate them, showing pictures of objects with sexual suggestions or messages, or pictures of genitals.

Physical  sexual  abuse refers  to  unnecessary  physical  contacts  of  a  sexual  nature,  such  as pressing oneself onto the body of other people, attempting to kiss or caress another person, or pinching an individual among others.

## ACTIVITY 1: UNWANTED SEXUAL ATTENTION ON VARIOUS SOCIAL MEDIA

<!-- image -->

Read the scenario below and in groups  of 3 to 4 students, answer the questions which follow.

Foccoook

In this image we can see a cartoon image of a mobile phone.

<!-- image -->

Sania, 14 years old, is connected on various social media. She likes making selfies which she posts on Facebook, Instagram and Twitter. These posts generate several likes and comments. She  also  accepts  friend  requests,  although  the  people  sending  these invites are mostly unknown to her.

One  day,  she  got  a  new  friend  request  which  she  accepted.  After  some  chats  and  tweets, her 'online friend' told her she was beautiful and that he wanted her to come on Skype for a video conversation. Sania accepted and started getting interested with the new friend who called himself Aaron. After some online conversations, Aaron asked Sania out for a date which she accepted. When she reached the meeting point, she was shocked to see that Aaron was a 50-year-old  man who used social media to attract young teenagers.

## 1. What danger is Sania facing?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. How far is accepting friend requests from unknown people unsafe?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. What is the potential harm that Sania is incurring if she continues accepting such friend requests?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. If  you  were  Sania's  friend,  what  would  you  advise  her  to  protect  herself  from  sexual predators?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 2: PROTECTING MYSELF AGAINST ANY FORM OF UNWANTED SEXUAL ATTENTION ON SOCIAL MEDIA

In groups of 3-4, design a poster to communicate how you can protect yourself from sexual abuse and unwanted sexual attention while using the internet and social media. Some scenarios are provided to showcase possible situations where abuse is evident.

1. Roni likes to post selfies on his Facebook page and his locations are visible to the public.
2. Minnie post TikTok videos of herself and enjoys comments from people.
3. Karl messages back unknown strangers on Instagram and agrees to follow their page.
4. My boyfriend asks me to videocall him and usually asks me to undress.
5. John/Jane send pictures of myself naked to his girlfriend/her boyfriend.
6. I post my vacations on social media to let the world know about my whereabouts.

Teacher has a class discussion on each poster and explain ways one can protect oneself from sexual abuse and against any form of unwanted sexual attention.

<!-- image -->

## ACTIVITY 3: POSSIBLE DANGERS OF THE SOCIAL MEDIA

You are required to work in groups of 3 to 5 students and discuss one category of dangers of the social media. Discuss in your group and fill in the respective columns in the table below.

|   Group | Dangers of social media                                                                                                      | Forms of media   | To what extent are teenagers endangered?   | What should be done to protect teenagers in such situation?   |
|---------|------------------------------------------------------------------------------------------------------------------------------|------------------|--------------------------------------------|---------------------------------------------------------------|
|       1 | Sexting (sending, receiving or forwarding sexually explicit messages, photos, or videos mainly by mobile phone).             |                  |                                            |                                                               |
|       2 | Virtual sexual assaults- the victim of constant messaging containing threats of sexual assault.                              |                  |                                            |                                                               |
|       3 | Digital dating abuse- one using social media and/or other technologies (such as cell phones) to control or harass the other. |                  |                                            |                                                               |
|       4 | Luring/online exploitation of minors- meeting with minors for sexual purposes.                                               |                  |                                            |                                                               |
|       5 | Physical sexual abuse- having unnecessary physical contacts of a sexual nature.                                              |                  |                                            |                                                               |

## Lesson 2: Privacy and bodily Integrity

Unwanted sexual attention and harassment is a violation of one's privacy and bodily integrity. Adolescents must thus be empowered to protect themselves against related situations.

Sexual harassment refers  to  unwelcome  sexual  advances,  requests  for  sexual  favours,  and other behaviour of a sexual nature.  It is also considered as sexual harassment if sexual activity is expected in exchange for a job.  It is also sexual harassment if anyone's sexual talk, touch or actions create a working environment that feels uncomfortable or unsafe.

Sexual harassment includes three distinct dimensions:

This is a cartoon image. In this image there are two people. One person is standing and holding a book. In the background there is a wall.

<!-- image -->

1. Gender harassment occurs when one person harasses another person for reasons relating  to  their  gender  or  the  gender  with  which  they  identify.  For  example,  any insulting remarks made towards a person simply because she is a woman, would be considered a form of gender harassment.
2. Unwanted  sexual  attention  stands  as  a  verbal,  non-verbal  or  physical  sexualised behaviour which are offensive and unwanted.

In this image we can see a person and a dog.

<!-- image -->

In this image we can see a cartoon image of a woman and a man. The woman is holding a cup in her hand. The man is holding a cup in his hand.

<!-- image -->

3. Sexual coercion refers to situations where a person may feel forced into a sexual act/relationship because she is dependent on someone for money, support or even protection.  When the person who is under pressure gives in, it may seem as though she gave consent, but because the person with the resources is misusing his power, it is still a form of abuse.

## ACTIVITY 1: SPEAKING AGAINST UNWANTED SEXUAL ATTENTION AND HARASSMENT

<!-- image -->

In groups of 3-4 students, discuss how unwanted sexual attention and harassment is a violation of your privacy and bodily integrity in the following situations:

1. Gender harassment in a public place (marketplace, workplace, in the bus, etc.).
2. Non-verbal sexual abuse via texts, messages, emails, Viber, WhatsApp at home, school and workplace.
3. Verbal sexual abuse inside school, classroom, school toilets, workplace etc.
4. Physical sexual abuse in school, classroom ,workplace etc.

## DID YOU KNOW?

The Brigade pour la Protection de la Famille and the Cybercrime Unit of the Mauritius Police  Force,  are  responsible  for  taking  actions  whenever  a  child  or  adolescent  is victim of sexual abuse and cyber-criminal activities like child pornography, sexting, circulating images, or videos of sexual nature online namely on social media, or when a child/adolescent is asked  to engage in sexual activities online.

<!-- image -->

## KEY MESSAGE

With the fast-changing society and growing importance of the internet, it is crucial to bear in mind of both positive and negative impacts of the latter on our life. Cyberspace can help us access information rapidly; however, it is also a fertile ground for criminal activities, discrimination, commercial sexual exploitation and sexual violence.

- It  is  sometimes  difficult  to  identify  a  victim  of  unwanted  sexual  attention  on  social media because usually the perpetrators will ensure that the victim is silenced from disclosing the abuse by threats, fear, and further abuse.
- Some victims have even committed suicide out of despair and fear.
- The victim has to speak about it to a trustworthy person so that he/she can receive help and support. By remaining silent, he/she is encouraging the perpetrator to commit abuse on other victims.

<!-- image -->

## ACTIVITY 2: SPEAKING AGAINST UNWANTED SEXUAL ATTENTION AND ABUSE

- (a)  In groups of 3-4 students, discuss how you can denounce somebody who is an abuser on social media. Write 5 possible answers below.
- (b)  Read the case study below and answer the questions that follow.

1.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image we can see a cartoon image. In the cartoon image we can see a woman sitting on the floor.

<!-- image -->

In this image we can see a person with long hair.

<!-- image -->

In this image we can see a person holding a pen and writing on a paper.

<!-- image -->

Brown, a trainer, faces allegations that he has sexually assaulted an Olympic athlete, Patricia, on several instances. Patricia bravely agreed to file a case against Brown in court. The lawsuit alleges that Brown sexually assaulted her three different times in 2017 and 2018. Brown was sexting her at odd hours, and following her after the training until one day he proposed to drop her home but got hold of her and raped her in his car. The second and third time it happened was when they were abroad for an international tournament. Patricia was afraid and ashamed of herself; she felt  scared at the idea of denouncing Brown in the first place, but she decided to

speak to her friend who took her to a lawyer for counsel. The case is still ongoing, but Patricia feels that speaking out has helped her remove the shame that she has felt for the past year and placed it on the person responsible for her rape. She is cooperating with NGOs and other agencies which are investigating the sexual assault claims. She is a shining example of a brave sexual assault survivor who chose to speak out. The public statements of sexual abuse survivors often encourage other victims to speak out.

- I. What did you learn from the above case study?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- II. List the types of sexual abuse Patricia has been victim of .

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- III.  Why is it important to speak about sexual assault?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- IV.  If you were Patricia, how would you protect yourself from being assaulted sexually?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- V. In what ways could young people be sensitised about sexual assault?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- VI.  How would you encourage victims of sexual abuse to denounce their abusers?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

After activites 1 and 2, teacher may have a class discussion to explain how unwanted sexual attention and harassment is a violation of one's privacy and bodily integrity.

## UNIT 6 | SEXUAL AND REPRODUCTIVE HEALTH

In this image we can see a group of people. The background of the image is blurred.

<!-- image -->

## Introduction

Unintended  pregnancy (e.g.,  teenage  pregnancy) is  a  growing  concern  in  the  Republic  of Mauritius and has various negative consequences. This Unit addresses different ways (including use of contraceptives) of preventing unintended pregnancies.

## Lesson 1: Unintended Pregnancy

## ACTIVITY 1: ROLE PLAY ON UNINTENDED PREGNANCY

<!-- image -->

Female students are invited to do role plays, in which they have to pretend they have just discovered they are pregnant and have to tell their parent/s. They have to tell how they would feel about:

1. What their parent/s would say
2. How would they support the baby
3. Their schooling
4. Future plans
5. Others

The male students are also invited to do role plays, in which they have to pretend that they have learnt that their girlfriends have become pregnant and have to tell their parent/s. They have to tell how they would feel about:

1. What their parent/s would say
2. How would they support the baby
3. Their schooling
4. Future plans
5. Others

After the role play, teacher will have a class discussion on the possible impacts/consequences of pregnancy on both male and female students. He/she may draw the table as shown below on the whiteboard to summarise the  consequences of pregnancy on male or female students.

| Consequences of pregnancy   | Consequences of pregnancy   | Consequences of pregnancy   |
|-----------------------------|-----------------------------|-----------------------------|
|                             | Male Students'              | Female Students'            |
| (i) Health                  |                             |                             |
| (ii) Education              |                             |                             |
| (iii) Family and society    |                             |                             |

## Lesson 2: Unintended Pregnancy and Contraceptives

ACTIVITY 1(a): UNINTENDED PREGNANCY AND CONTRACEPTIVES

<!-- image -->

Read the scenarios below and answer the questions that follow:

## Scenario 1

Johny met Teena in a quiz contest organised by a company. They became friends and later, very close friends. One day, Teena told Johny about her deep feelings for him. Since then,  they  started  sharing  their  feelings  for  each  other  and  the  bond  between  them strengthened. As they were young adults, both focused more on their career besides staying together.

In this image we can see a cartoon image of a woman and a man. The woman is wearing a red color jacket and the man is wearing a yellow color jacket. Both of them are smiling.

<!-- image -->

## Scenario 2

After their wedding, they were having sex; but they decided that they should not have children, as they were not yet prepared to face a family life.

To keep their relationship pleasant and healthy, they decided to have a reliable source of information on sexual health. They went to a Health Centre to have more information on how to prevent unintended pregnancies.

The information that they received from the Health Centre was reliable and gave them confidence about their active sexual life. Both took an informed decision as they were not ready financially and timely to be parents.

In this image we can see a collage of pictures of a man and a woman.

<!-- image -->

This is a cartoon image. In this image there are two people. In the middle there is a person. In the background there is a sky.

<!-- image -->

1. Why was it important for Johny and Teena to do not have sex before their wedding?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Suggest how Johny and Teena could enjoy a loving relationship without engaging in sex.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Why was it important for the couple to go to a Health Centre?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Name the Section/Department of the Health Centre where they must have sought advice.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Suggest what possible advice  the couple obtained from the above Section/Department of the Health Centre.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. Suggest a non-governmental organisation where they could seek advice on reproductive and sexual health.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7. Why it is important to plan families nowadays?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

8. Given  that  you  are    young  and  currently  studying  at  a  secondary  school,  answer  the following:

- (i) List some advantages to not having sex at this time in your life.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) What could make it difficult not to have sex?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

9. What should parents do to help their child avoid pregnancy?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(Teacher will look at students' answers and may have a class discussion on this topic).

## KEY MESSAGE

Teacher may conclude Activity 1 with the following: A few months later Teena and Johny were happy with the effective use of contraceptives that they were using. After 9 months of marriage, Teena was happy that she was not pregnant. They were confident and disciplined about the responsibilities regarding their use of contraceptives. They could even advise their friends on effective use of contraceptives.

## ACTIVITY 2(a): UNINTENDED PREGNANCY AND CONTRACEPTIVES

<!-- image -->

## Read the case studies 1 and 2 then answer the questions that follow.

## Case Study 1: Amy, age 17

Ben and I were very close friends and shared common interests.

I did not plan to have a baby. I did not even plan to have sex with Ben. It just happened. One day we went to a party, and we had a few beers. At a certain time, we were alone in our intimate moments, and we could not prevent ourselves from having sex. We just did it  without  protecting ourselves. Later, I found that I was pregnant. My parents were so worried about me. They were always reprimanding and telling me what to do. I had no other choice than to quit school as my pregnancy was becoming visible and my friends were laughing at me. With a baby to look after, I needed money, so I looked for a job. I worked at a fast-food place and the money was not enough to pay for my rent, baby food and diapers. It was very difficult to live such a life with limited income. A few months later, Ben left me.

1. What are the bad consequences of having sex at an early age?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Why is it important to have protected sex?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Why should Amy work?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Case Study 2: Marcelo, age 18

I  like  being with girls. Nowadays, it is so easy to convince a girl about love and to have sex with them. Sometimes I use condoms, as I do not intend to become a father. It is also too early for me to become a parent. I only want to enjoy life and not to be in a serious relationship.  Before  having  sex,  I  ask  them  if  they  are  using  contraceptives.  One  of  my girlfriends became pregnant as she did not use any contraceptive. She did not realise the need for contraceptives as it was her first time having sex. I thought that she was using something, such as a pill or girl's condoms! I did not take this seriously. Now I guess that was stupid on my part.

I  am  still  having  sex  with  many  girlfriends.  I  need  to  have  a  blood  test  as  I  fear  having contracted a sexually transmitted infection (STI).

## 1. What happened to Marcelo's girlfriend?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. How could the pregnancy have been prevented?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Why is Marcelo thinking of having a blood test?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Do you think Marcelo is a responsible boy?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. Should girls trust Marcelo?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 2(b): UNINTENDED PREGNANCY AND CONTRACEPTIVES

After completing activities 1 and 2, related to the case studies, you are required to answer the following questions.

1. Whose responsibility is it to prevent pregnancy in the following case studies?

Case study 1: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Case study 2: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In the scenarios of the couple, Johny and Teena (page 51/52):

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. (ii) Had you been in Johny and Teena's place, what decision would you have taken?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## ACTIVITY 3: DESIGNING A BOOKMARK IN THE CONTEXT OF WORLD CONTRACEPTION DAY

<!-- image -->

Assume that your school has decided to celebrate World Contraception Day (WCD) together with  a  governmental  or  non-governmental  organisation.  Under  the  guidance  of  a  teacher, students are required to design a bookmark that can be used to sensitise their peers in other classes.

## Work in groups of 4-6.

Students are required to work in their respective groups and discuss the ways of preventing pregnancy. They must also highlight the benefits of contraceptives for individuals and societies. Each  group  of  students  discusses  different  ways  of  preventing  pregnancy  and  designs  a bookmark on ways of preventing pregnancy.

The groups also display and present their respective bookmarks and the teacher has a class discussion on the developed bookmarks.

## ACTIVITY 4(a): PREGNANCY PROTECTION: MYTH AND TRUTHS

<!-- image -->

The  activity  provides  some  myths  and  facts  about  contraceptives (including  condoms) ,  and other ways to prevent unintended pregnancy.

You are required to work in pairs. Discuss and put a tick in appropriate column for each statement in your notebook.

Each pair is required to write their answer for each statement in their notebook and provide its justification during the class discussion.

| Statements                                                                                                  | True   | False   |
|-------------------------------------------------------------------------------------------------------------|--------|---------|
| 1. Abstinence is the most effective method of avoiding pregnancy.                                           |        |         |
| 2. Girls can get pregnant even if the penis does not actually enter the vagina.                             |        |         |
| 3. Pregnant women who are infected with HIV can pass the virus on to the baby before it is born.            |        |         |
| 4. Teenagers can obtain birth control pills from Family Planning Centres/ Clinics.                          |        |         |
| 5. It is advisable to practice dual protection - use of condoms as well as another method of contraception. |        |         |

<!-- image -->

## ACTIVITY 4(b): BENEFITS OF CONTRACEPTIVE USE TO INDIVIDUALS AND SOCIETY

## Students work in groups of 4-6.

Some groups will be working on how contraceptive use can help people who are sexually active plan their families, with important related benefits for individuals; other groups will be doing a similar exercise but focusing on benefits for societies.

Each group will write their answers in their notebook . The group will then write the answers in the respective column on the whiteboard as shown below.

Benefits for Individuals

Benefits for Society

Group 1

Group 2

Group 3

Group 4

Group 5

Group 6

- (i) What benefits for individuals were common in groups 1-3?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## (ii)  What benefits for societies were common in groups 4-6?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## DID YOU KNOW?

The emergency contraceptive is used after sex when other birth control methods may have failed, e.g., if a condom breaks or a woman realises she has missed pills. Two types of safe and effective emergency methods commonly used are: hormonal, emergency contraceptive pills (ECPs) taken within 120 hours (5 days of unprotected intercourse, or the sooner the better) .

<!-- image -->

<!-- image -->

## ACTIVITY 5: RISKS ASSOCIATED WITH EARLY MARRIAGE AND EARLY PREGNANCY AND BIRTH

Early marriage (voluntary or forced) and early pregnancy may have several health risks such as depression, STIs, and so on.

You are required to work in groups of 4-6 students.

- (a). Complete the diagram below with some of the health risks associated with early marriage and early pregnancy. One example has been provided.
- (b). Study the above diagram and answer the following:
1. Which of the above health risks are mostly associated with unintended pregnancy among teens in your country?

The image depicts a diagram with four main components. The diagram is divided into four quadrants, each representing a different aspect of a pregnancy. The quadrants are labeled as follows:

1. **Depression**: This quadrant is labeled with a blue box. The box contains a line connecting two points, indicating that depression is present.

2. **Early Marriage and Early Pregnancy**: This quadrant is labeled with a blue box. The box contains a line connecting two points, indicating that early marriage and early pregnancy are present.

3. **Early Marriage and Early Pregnancy**: This quadrant is labeled with a blue box. The box contains a line connecting two points, indicating that early marriage and early pregnancy are present.

4. **Early Marriage and Early Pregnancy**: This quadrant is labeled with a blue box. The box contains a line connecting two points, indicating that early marriage and early pregnancy are present.

The diagram is structured in a way that each quadrant is connected to the others, forming

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 2. Suggest three social consequences that unintended pregnancy may have on

(i) young girls

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) young boys

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Who  would  you  approach  to  talk  to  if  you  were  experiencing  signs  and  symptoms  of pregnancy?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Discuss how early pregnancy or early marriage might affect reaching your goals within the short, medium, and long term, in your notebook.

Short term (less than 6 months) : For example, I may have to stop going to school.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Medium Term (5-10 years) : For  example,  I  may  not  be  able  to  complete  secondary  school studies.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Long term (more than 15 years) :

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## KEY MESSAGE

Students may seek further information about contraceptives (e.g., the most appropriate type of contraceptive, proper use of condoms) from reliable sources (e.g., Preconception Care Clinics in Mediclinic/Area Health Centres, Family Planning Clinics).

## Lesson 3: Sexually Transmitted Infections

We have learnt about sexually transmitted infection (STI) in both grades 7 and 8.  It is a term used to categorise a group of infections typically transmitted through vaginal, oral or anal sex.

<!-- image -->

a) Students will be required to carry out the following role plays as described below.

At the end of each role play, the teacher will ask several questions to students and will also explain the key points of the activity. (Teacher will guide students for the role plays). He/she may also have a class discussion after the completion of all role plays.

1. Students A and B will come in front of the class and act like grown-up men. They will tell the audience that they have been married for almost 15 years and have never betrayed their partner, and that their commitment and loyalty towards each other has proven their selfefficacy in relationship to sexual activities. They proudly add that they feel happy, free and safe from any STI's.
2. Students C, D and E, who include both male and female students will in their turn act like three adults working in night life industry where they are exposed to music, dance, drugs, alcohol, cigarettes, and sex workers. They should admit that they are potentially exposed to a high level of temptation and feel very vulnerable when having multiple sex partners. Their risk reduction strategies in relation to sexual activities are quite poor.
3. Students F and G will act as a boy and a girl in front of the class. They will act with conviction that they are responsible for all their sexual activities. They will write a small script which will highlight that they should assume their responsibilities wisely. Their decisions will impact on their actions. If they choose abstinence, they will be 100% safe from STI.
4. Five students H, I ,J ,K and L  will represent peers from different cultures. They will all act in front of the class that their culture helps them in the risk reduction strategies in relation to sexual activities. They are bound by the principle of monogamy, which  implies having only one sexual partner, hence preventing the risk of contracting STI.
5. They  need  to  respect  their  peers'  decision of  having  only  one  sexual  partner for  the prevention of STIs. They should talk to their sexual partner and convince them to in turn abide by that decision. They should learn about possible signs and symptoms of STIs, and the dangers related to each STI.

## b) Answer the questions that follow

1. What is the importance of being loyal and maintaining a sincere relationship when living as a couple?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Give 2 examples of decisions that will impact your actions.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. How can temptations make you vulnerable in relation to sexual activities?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Explain how staying in a monogamous relationship can help to protect you against STI.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## DID YOU KNOW?

PrEP (pre-exposure prophylaxis) is  a  medicine taken by people who are at a very high risk of getting HIV to decrease their chances of getting the infection. When taken as prescribed, PrEP is highly effective for preventing HIV.

<!-- image -->

## Glossary of terms

1. Acquaintance: a person one knows slightly, but who is not a close friend.
2. Adolescent: a person aged 10 to 19 years, as defined by the UN.
3. Age-Appropriate: designed to teach concepts, information, and skills based on the social, cognitive,emotional, and experience level of most students at a particular age level.
4. Beliefs: beliefs are ideas that we accept as true
5. Casual friends: type of  friends you see from time-to-time.
6. Child  abuse: happens  when  a  parent  or  other  adult  causes  serious  physical  or emotional harm to a child.
7. 7 . Cyberbullying: using  electronic  communication,  such  as  the  internet  and  social media to shame, intimidate, manipulate or threaten someone.
8. Divorce: the legal dissolution of a marriage by a court or other competent body.
9. Extended family: consists of parent and other relatives living under one roof.
10.  Fertilisation: fusion of sperm with a mature egg to form an embryo.
11. Gender: the emotional, behavioural and cultural characteristics attached to a person's assigned biological  sex.  Gender  can  be  understood  to  have  several  components, including gender identity, gender expression and gender role.
12.  Gender Identity: people's inner sense of their gender. Most people develop a gender identity that corresponds to their biological sex, but some do not.
13.  Gender Roles: the social expectations of how people should act, think and/or feel based on their assigned biological sex.
14.  Hormones: are chemical substances produced in the body and are released into the blood which carries them to organs and tissues of the body to exert their functions, for e.g influence the body's growth.
15.  Hygiene: conditions  or  practices  conducive  to  maintaining  health  and  preventing disease, especially through cleanliness.
16.  Menstruation: menstruation, or period, is normal vaginal bleeding that occurs as part of a woman's monthly cycle. Every month, your body prepares for pregnancy. If no pregnancy occurs, the uterus, or womb, sheds its lining. The menstrual blood is partly blood and partly tissue from inside the uterus.
17. 17 . Myths: false beliefs or ideas.

18.  Nuclear family: consists of two parents and children living in the same house.
19.  Ovulation: the release of an egg from an ovary during the menstrual cycle.
20.  Peer pressure: the direct influence on people by peers, or the effect on an individual who is encouraged and wants to follow their peers by changing their attitudes, values or behaviours to conform to those of the influencing group or individual.
21.  Pornography: material (e.g book, photograph, video) that shows people having sex.
22.  Pre-exposure Prophylaxis (PrEP): this is a medicine taken by people who are at a very high risk of getting HIV to decrease their chances of getting the infection.
23.  Puberty: time when the pituitary gland triggers production of some hormones that act on testes in boys and ovaries in girls. Puberty typically begins between ages 8 and 13 for girls, and between the ages of 12 and 14 for boys, and includes such body changes as hair growth around the genitals, menstruation in girls, sperm production in boys, and much more.
24.  Reproduction: is a process by which a new organism or an offspring is produced similar to its kind.
25.  Rights: those things that one is morally or legally entitled to do or have
26.  Sex: biological and physiological characteristics (genetic, endocrine, and anatomical) used to group people as members of either the male or female population.
10. 27 . Sexual abuse: is a form of abuse on a child or children that includes sexual activity.
28.  Single parent family: a family with children under age 18 headed by a parent who is widowed or divorced and not remarried, or by a parent who has never married.
29.  Social norms: attitudes or patterns of behaviour among groups of people that are considered acceptable and influence the way the group thinks and behaves.
30.  Tolerance: attitude which consists in admitting in others a way of thinking or acting different  from  that  which  one  adopts  oneself; respecting  the  freedom  of  others  in matters of opinion.
31. Values: the moral principles and standards of behaviour that are important to us.  For example, respecting oneself and others, and taking responsibility  for one's life.
32.  Young person: a person between 10 and 24 years old, as defined by the UN.
33.  Youth: a person between 15 and 24 years old, as defined by the UN. The UN uses this age range for statistical purposes, but respects national and regional definitions of youth.