Creating

## Vocal Hindustani 9 æBade

Performing

Responding

In this image we can see a group of people sitting on the floor. There are musical instruments in the image. There is a board in the image. There is a table in the image. There are chairs in the image. There is a wall in the image. There is a curtain in the image.

<!-- image -->

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology:

<!-- image -->

In this image, we can see a poster with some text and a logo.

<!-- image -->

Based on the National Curriculum Framework (2016)

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the Ministry of Education, Tertiary Education, Science and Technology, Republic of Mauritius

202 1

## © Mahatma Gandhi Institute (2019)

All  rights  reserved.No  part  of  this  publication  may  be  reproduced,  stored  in  a retrieval system, or transmitted in any form or by any means, electronic, mechanical, photocopying, recording or otherwise, without the prior permission of the Copyright owner.

## Printed by

T-Printers Co. Ltd Industrial Zone, Coromandel. Tel : 230/2332500

First published 2020 Reprinted 2021

While every effort has been made to trace the copyright holders for reproductions, we might have not succeeded in some cases. We offer our sincere apologies and hope that they will take our liberty in good faith. We would appreciate any information that would enable us to acknowledge the copyright holders in our future editions.All materials should be used strictly for educational purposes.

ISBN: 978-99949-54-27-8

i

## Performing Arts (Indian Music and Dance) Panel

Mr.K.Mantadin

- -

Project Co-ordinator

(organisation and development), Senior Lecturer (Tabla), Mahatma Gandhi Institute.

Head, Department of Percussion Instruments,

Dr A.S. Peruman(OSK) -

Panel Co-ordinator

Senior Lecturer (Vocal Carnatic), Head, Department of Creativity and Performance

MGI.

## Writing Team          (Vocal Hindustani)

Mr S. S. Mungroo

- Lecturer (Vocal Hindustani) - MGI Team Leader

Mr A. Chuttoo

- Educator (Vocal Hindustani) - MGI

Mrs R. Nobin

- Educator (Vocal Hindustani) - M.O.E, T.E, Sc.&amp; Tech.

Vetter

Mrs A. Jankee

- Educator (Vocal Hindustani) - PSEA

Proof Reading

Mrs A. Jankee

- -

Educator (Vocal Hindustani) - PSEA

Graphic Designers (cover, illustration, layout and photography)

- Mr.Vishal  Napaul
- Ms.Vaneeta Jatooa
- Ms.Presika Juckhory

## Photography

- Mr.K.G. Moonesawmy ( Pro Foto Plus )

## Word Processing Operator

- Mrs. N. Mugon

## Acknowledgements

Mrs S. N Gayan, GOSK, Director General, Mahatma Gandhi Institute and Rabindranath Tagore Institute for her continued advocacy for music education especially Indian Music and Dance.

Dr (Mrs) V Koonjal, Director, Mahatma Gandhi Institute for her unwavering support to this project.

## The Performing Arts (Indian Music and Dance) panel is also grateful to the following persons:

Dr.Mrs. S.D.Ramful -

Director Schooling - MGI

Mrs.U. Kowlesser -

Registrar - MGI

Dr.D.Ramkalawon

-

Senior Lecturer (Sitar),

-

Head, School of Performing Arts, MGI.

Dr. D. Pentiah Appadoo -

Music Organiser (Oriental), M.O.E, T.E, Sc.&amp; Tech.

## Quality Vetting Team

Dr. S.K.Pudaruth -

Assoc. Professor, Ag.Head, Centre for Quality Assurance - MGI

Mrs K. Pudaruth -

Educator (Vocal Hindustani), MGI

Mrs D. Jahajeeah -

Educator (Vocal Hindustani)- M.O.E, T.E, Sc.&amp; Tech.

Miss V. Curpen -

Lecturer, Head Department of Printmaking - MGI

Mr. R.R.Maloo

- -

Educator (English) MGSS

## Administrative Staff

Mrs.H. Chudoory

Administrative Officer - MGI

Mrs. S. Appadoo

Clerical / Higher Clerical Officer - MGI

Mrs. G. Checkooree

Clerical / Higher Clerical Officer - MGI

Mrs. P. Purmessur

Word Processing Operator - MGI

## Cover Photo

Ms N. Deerpaul and Students of MGISS

- The parents and their wards for giving us the permission to reproduce their photographs and images in the textbook.

## Foreword

'Where the mind is allowed to stumble upon cascades of emotion and where the surprise of creative exchange comes out of tireless striving towards perfection' Rabindranath Tagore

Should music, dance, arts, drama be taught in schools? Do such subjects matter ?

As in the case of all debate, there are those who are for and those who are against. The  decision,  in  the  context  of  the  reforms  leading  to  the  Nine  Year  Continuous Basic Education, to include teaching of the performing arts in the secondary school curriculum shows that 'the ayes have it.' At least for the time being.

Traditionally, music teaching takes place in a one-to-one mode. The piano teacher teaches one student at a time, so does the sitar guru. Dance is more of a group experience. But for each of these disciplines, the context of institutional level teaching introduces opportunities of reaching a broader cross-section of population, thereby giving rise to fresh challenges. Students come from a variety of social and cultural environments which expose them to different types, genres and registers in the arts. Students also come with different levels of aptitude. These are but two of challenges encountered.

From  another  perspective,  it  has  been  repeatedly  pointed  out  that  the  'digital natives', while definitely coming to learning with resources hitherto not available, may,  in  the  process,  be  losing  their  ability  to  grasp,  decipher  and  understand emotional language. In short they may be losing empathy.

The ultimate aim of arts education in the curriculum is to provide a pedagogical space where the young will be able to explore their own affective responses to forms  of  artistic  expression,  to  develop  sensibility,  while  acquiring  a  whole  set of  skills,  including  not  only  spatial  awareness,  pattern  recognition  or  movement coordination, but also the benefits of group and team work, of joint effort, higher level creative thinking and expression, as well as an overall sense of shared pleasure and of achievement. This is what emotional intelligence is all about.

The specialists who prepared the syllabus and the present textbooks for Indian music and  dance  had  all  the  above  in  mind  while  undertaking  the  task.  The  teacher training for these disciplines needs to be a continuous process of exchange between curriculum developers, teaching practitioners, textbook-writers and learners.

The MGI is particularly happy to be part of this major development, at a time when the country is looking at new avenues for continued economic development, and more importantly at new avenues to enhance equity, social justice and inclusion. It is our small contribution to the 'grande aventure' of holistic education.

Mrs Sooryakanti Nirsimloo-Gayan, GOSK Director-General (MGI &amp; RTI)

## Preface

This textbook is the first instructional material in the field of Performing Arts (Indian Music and Dance) written by a team of experienced Mauritian teachers and experts in Vocal Music, Instrumental Music and Dance.

It has been designed on the Aims, Objectives and the Teaching and Learning Syllabus  of  the  Performing  Arts  from  the  National  Curriculum  Framework (2016), under the Nine Year Continuous Basic Education Programme.

The Performing Arts Curriculum is articulated around four strands: Performing, Creating,  Responding  and  Performing Arts  and  Society. Thus,  the  textbook takes into account the development of key skills and understandings under the four strands.

This  set  of  textbook s for  grade  7,  8  and  grade  9  lays  the  foundation  in each  discipline and provides learners with the essential knowledge, skills and attitudes  needed  to  progress  towards  higher  grades.  It  also  takes  into consideration the multicultural nature of our society and its traditions.

This textbook is a support material that gives direction to the educators in the teaching and learning process by linking the curricular components, curricular expectations, pedagogical principles and assessments.

A textbook is not an end in itself like  any  other  instructional  material.It  is  a means to facilitate learning to take place in a continuous and continual manner.

Learning  objectives  in  each  chapter  of  the  textbook  reflect  the  curricular outcomes.  It will help the teacher to design his/her lesson plans which will further ease the teaching and learning transaction towards achievement.  Teachers will have to plan their work so that learning takes place in an effective and efficient way.    They  will  have  to  provide  appropriate  and  enriched  experiences  and modify the teaching and learning strategies according to the needs of learners.

The practical aspects of the discipline have been integrated under 'practical' with step-by-step technique laying emphasis on the mastery of skills from one level to another.

We are aware that children construct knowledge in their own way and have different  learning  styles.The  textbook  has  been  designed  to  cater  for  such needs.

Special  features  and  a  generous  number  of  illustrations,  pictures,  concept maps and activities have been included to promote collaborative learning and other additional skills like team spirit, cooperation and understanding diverse

nature  of  learners.These  would  help  teachers  to  organise  their  interactions at  classroom  level. Teachers  may  give  more  activities,  depending  upon  the availability of resources and time.

Assessments in the form of activities, projects and questions are also included at the end of each chapter.  These are check points to assess the learners.  It will help teachers gather evidences about the expected level of learning taking place in the learners.

I would also request all the Educators to go through the National Curriculum Framework  (2016),  the  Teaching  and  Learning  Syllabus  of  the  Performing Arts (Indian Music and Dance) documents and especially the 'Important Note to  Educators'  which  has  been  provided  in  the  textbook  to  have  a  thorough understanding of the Philosophy and Perspective behind those documents and their implications in the implementation of the Reform process in the education system.

I  hope that this new journey of learning Indian Music and Dance will be an enriching one.

Mr. K. Mantadin, Project Co-ordinator - Performing Arts (Indian Music and Dance), Senior Lecturer (Tabla), Head, Department of Curriculum Development, Mahatma Gandhi Institute.

## Note to Educators

This teaching and learning syllabus of Indian Music and Dance has been designed on the spiral curriculum model in which core components and essential topics are revisited  within  the  three  years.    It  caters  for  both  the  theoretical  and  practical aspects of each discipline.

It also comprises different blocks of knowledge and skills and each block is supported by  specific  learning  outcomes  which  cover  all  the  three  domains  of  learning; cognitive, psychomotor and affective.

The Listening and Viewing component has been integrated in the syllabus as it is a key factor in the development of music and dance abilities. Teachers should provide a wide variety of listening and viewing experiences for learners to stimulate active listening and viewing through questioning, prompting and suggestion.

In  order  to  achieve  the  objectives  of  the  syllabus  and  to  keep  a  good  balance between  theory  and  practical  sessions,  the  teacher  will  have  to  plan  his  /  her work and teaching and learning activities according to the topics to be taught as specified in the scheme of studies.  However, educators may modify the sequence of the topics in which they wish to teach for the smooth running of the course.

## Educators should:

- Ensure that learners use the knowledge, skills and understanding developed from grades 1-6 and build upon that prior knowledge to construct new knowledge. 1.
- Provide  learning  experiences  that  include  opportunities  for  hands-on  and interactive learning, self-expression and reflection. 2.
- Find a variety of ways to align their instruction with the Aims, Learning Outcomes and Specific  Learning  Outcomes by focusing on active learning and critical thinking. 3.
- Provide learning activities that are appropriate in complexity and pacing. 4.
- Provide opportunities for individual and multiple groupings. 5.
- Actively engage and motivate students in the process of Learning Music and Dance. 6.
- Develop the ability in the learners to use and understand the language of Music and Dance through listening  and  viewing  as  well  as  responding  to  live  and recorded repertoires. 7.

## Note to Educators

- Enrich  the  musical  experience  of  the  students  by  gaining  an  understanding of  the  cultural  and  historical  context of music and dance exploring personal connections with them. 8.
- Carry out active listening and viewing sessions through the use of Information Learning  Technologies(ILT's).    This  will  facilitate  developing  their  investigative and methodological abilities. 9.
- Model and demonstrate accurate and artistic musical and dance techniques. 10.
- Differentiate  Music  and  Dance  instruction  to  meet  a  wide  range  of  students needs. 11.
- Educators should also ensure that learners' 12.
- Show proper care and maintenance of classroom instruments.
- Demonstrate respectful behavior as performers and listeners.
- Participate in classroom protocole and traditions for music making and dance.
- Reinforce effort and provide recognition. 13.
- Discuss student performances by using peer assessment as a tool. 14.
- Give opportunities to students to assume various roles in music performances, presentations and collaborations. 15.
- Motivate students to maintain a musical collection and portfolio of their own work over a period of time.  It can be an individual or group initiative that the learner will undertake under the supervision of the educator. 16.

## Table of Contents

| Chapter 1   | Raag                  |   1 |
|-------------|-----------------------|-----|
| Chapter 2   | Taal and Laya         |  19 |
| Chapter 3   | Voice Culture         |  31 |
| Chapter 4   | Shruti and Swar       |  43 |
| Chapter5    | Exponent              |  49 |
| Chapter6    | Notation Ststem       |  55 |
| Chapter 7   | Vocal Forms           |  65 |
| Chapter8    | Musical Instruments   |  71 |
| Chapter9    | Listening and Viewing |  85 |
|             | GLOSSARY              |  90 |

In this image we can see a person standing and smiling. In the background there is a wall.

<!-- image -->

## Learning Objectives

## At the end of this chapter, students should be able to:

- Elaborate on the concept of Raag and Raag-Jati-s
- Explain the time-theory of raag-s
- Define the terms alaap and taan
- Define the salient features of each raag prescribed: Bhairav, Khamaj
- Sing the aroha, avroha and pakad of each prescribed raag
- Sing at least five alankaar-s in each prescribed raag
- Sing one sargam geet , one chota khayal with alaap and taan and any thematic song in any prescribed raag in tune and rhythm
- Demonstrate a set of values related to Indian music.

In this image we can see a musical instrument.

<!-- image -->

1.0

## Raag

The term Raag , which is unique to Indian classical Music, is a combination of musical notes (melody) to express certain feelings. The combination of notes is  not  just  a  random  selection  of  notes,  but  the  melody  must  satisfy  a  few conditions known as the rules of raag-s .

1.1

## Rules of Raag-s:

1. Raag is a set of notes arranged in ascending ( aroha ) and descending ( avroha ) order.
2. A raag must have a minimum of 5 different notes.
3. The tonic note (Sa) is never omitted.
4. Notes Ma and Pa are never omitted at the same time.
5. Two variants of the same note ( shudh and vikrit ) cannot follow each other in succession in aroha or avroha . However, one variant  can be used in aroha and the other in avroha . There are exceptions to this rule.
6. A raag is always categorised under a particular thata .

Furthermore, every raag has a very specific way of combining the different notes used known as the Chalan of the raag . This is very important, specially when two raag-s have  the  same  combination  of  notes,  yet  are  distinct  and different by their chalan .

Last but not the least, every raag has its specific ornamentations (kan, meend, khatka ) to be able to create the desired mood. These ornamentations are the soul of Indian classical music. Compared to Indian Music, western music allows notes to be taken staccato; that is, detached or separated from the other notes. Singing a raag in this way will never create the desired mood.

In this image we can see a poster with some text and images.

<!-- image -->

2

In this image we can see a musical instrument.

<!-- image -->

1.2

## Raag Jati

Jati is a way of classifying raag-s where the criteria of classification is based on the number of notes used in that raag . As mentioned in the rules of raag-s , a minimum of 5 and a maximum of all 7 notes are used in a raag . Hence, there are three basic Jati-s :

| Jati (Scale)           |   Number of Notes Used |   Number of Note(s) Omitted |
|------------------------|------------------------|-----------------------------|
| Sampoorna (Heptatonic) |                      7 |                           0 |
| Shadav (Hexatonic)     |                      6 |                           1 |
| Audav (Pentatonic)     |                      5 |                           2 |

Since a raag has  both  aroha  and  avroha,  a  total  of  9 Jati-s are  formed  as follows:

|   Number of Notes Used in Aroha |   Number of Notes Used in Avroha | Jati                  |
|---------------------------------|----------------------------------|-----------------------|
|                               7 |                                7 | Sampoorna - Sampoorna |
|                               6 |                                7 | Shadav - Sampoorna    |
|                               5 |                                7 | Audav - Sampoorna     |
|                               7 |                                6 | Sampoorna - Shadav    |
|                               6 |                                6 | Shadav - Shadav       |
|                               5 |                                6 | Audav - Shadav        |
|                               7 |                                5 | Sampoorna - Audav     |
|                               6 |                                5 | Shadav - Audav        |
|                               5 |                                5 | Audav - Audav         |

3

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

1.3

## Time theory of Raag-s

This  theory  was  developed  by  Indian  musicologists  after  observing  human behaviour from dawn to dusk. Just like human beings have mood swings during the 24 hours or even during the different seasons, in the same way, raag-s are believed to have their own specific time of singing and season too.

The image is a diagram of a circular diagram with four labeled points labeled as Pdns, Midnight, Sun, and Purvang. The diagram is titled "Uttarang" at the top. The diagram is divided into four quadrants, each labeled with a different color. The colors of the quadrants are as follows:

- **Pdns**: This is the top-left quadrant.
- **Midnight**: This is the top-right quadrant.
- **Sun**: This is the bottom-right quadrant.
- **Purvang**: This is the bottom-left quadrant.

Each quadrant is colored in a gradient of colors, starting from a light gray at the top and transitioning to a darker gray at the bottom. The gradient is symmetrical, with the colors alternating between the two quadrants.

The diagram is labeled with the names of the four points:
- **Pdns**: Midnight
- **Midnight**: Sun

<!-- image -->

4

The theory in its simplest form divides the 24 hours into 2 parts. Noon to midnight is known as purvang, and midnight to noon is known as uttarang .  The ashtak also is divided into 2 parts: the lower tetra chord (S, R, G and M) also known as purvang, and the upper tetra chord (P, D, N and Ṡ) known as the uttarang .

When a raag has its vadi swar in the lower tetra chord, it is an indication that this raag will be sung or played in between noon and midnight. Likewise, a raag having its vadi swar in the upper tetra chord will be sung or played between midnight and noon.

In this image I can see a musical instrument and a musical note.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

A more detailed form of the theory divides the 24 hours into 8 parts of 3 hours each known as the prahar . Thes e prahar-s are as follows.

The 10 thata-s of Pandit V. N. Bhatkhande are categorised into 3 groups as follows:

| Time Slot           | Prahar-s                                                               |
|---------------------|------------------------------------------------------------------------|
| 7 a.m till 10 a.m   | 1 st part of the day                                                   |
| 10 a.m till 1 p.m   | 2 nd part of the day                                                   |
| 1 p.m till 4 p.m    | 3 rd part of the day                                                   |
| 4 p.m. till 7 p.m.  | 4th part of the day also known as the evening Sandhi-Prakash period    |
| 7 p.m. till 10 p.m. | 1 st part of the night                                                 |
| 10 p.m. till 1 a.m. | 2 nd part of the night                                                 |
| 1 a.m. till 4 a.m.  | 3 rd part of the night                                                 |
| 4 a.m. till 7 a.m.  | 4 th part of the night also known as the morning Sandhi-Prakash period |

5

|              | Thaat-s                          | Thata with            | Time period allocated                                             |
|--------------|----------------------------------|-----------------------|-------------------------------------------------------------------|
| First Group  | Kalyan, Bilawal and Khamaj       | Shudh Re and Shudh Ga | 7 - 10 a.m. 7 - 10 p.m.                                           |
| Second Group | Bhairav, Purvi and Marwa         | Komal Re and Shudh Ga | 4 - 7 a.m. 4 - 7 p.m.                                             |
| Third Group  | Kafi, Asavari, Bhairavi and Todi | Komal Ga              | 10 a.m. - 1 p.m. 1 p.m. - 4 p.m. 10 p.m. - 1 a.m. 1 a.m. - 4 a.m. |

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

The first group, that is, raag-s classified  under Kalyan, Bilawal and Khamaj thata-s are sung or played during the 1st part of the day or night. The second group, that is, raag-s classified under Bhairav, Purvi and Marwa thata-s are sung or played during the two sandhi prakash periods (dawn and dusk).Finally, the remaining 4 prahar-s are occupied by raag-s classified under thata-s having komal Ga .

## The importance of the note Madhyam:

Predominance of shudh M  indicates  morning raag-s while tivra M  indicates evening raag-s .That is why the note M is referred to as the ' Adhva darshak' swar, meaning the one who shows the path or direction.

The time theory of raag-s can be summarized by the following diagram: Day and Night Cycle of Hindustani raag-s

In this image, we can see a diagram.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

1.4

## Raag Bhairav

In this image we can see a person standing on the beach. In the background there is the sky.

<!-- image -->

Raag Bhairav is a morning sandhi-prakash raag sung between 4 a.m. and 7 a.m. This raag is classified under Bhairav thata . Raag Bhairav is the ashraya raag of Thata Bhairav . It uses all the 7 swara-s ( sampoorna jati ) with the note R and D as komal (flat). The vadi swar is D and the samvadi is R .

Aroha :

S R G M P D N S S N D P M G R S

Avroha :

Pakad :

S G M D P , G M R S

Thata :

Bhairav

Jati

:

Sampoorna- Sampoorna

Vadi

:

D

Samvadi

:

R

Time of Singing

:

4 th  Part of the night (4.00 a.m - 7.00 a.m)

In this image we can see a musical instrument.

<!-- image -->

7

In this image, we can see a musical instrument.

<!-- image -->

1.4.1

## Sargam Geet in Raag Bhairav set to Jhaptaal

8

| 1      | 2      | 3      | 4      | 5      | 6      | 7      | 8      | 9      | 10     |
|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Dhin x | Na     | Dhin 2 | Dhin   | Na     | Tin 0  | na     | Dhin 3 | Dhin   | Na     |
| Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi |
| S G    | D R    | P G R  | P      | D      | M      | P      | M R    | G      | R S    |
|        |        |        | M      | P      | M      | G      |        | R      |        |
| N      | S      |        | R      | S      | D      | D      | N      | S      | -      |
| G x    | R      | G 2    | M      | P      | M 0    | G      | R 3    | R      | S      |
| Antra  | Antra  | Antra  | Antra  | Antra  | Antra  | Antra  | Antra  | Antra  | Antra  |
| P M    | P D    | D N    | D      | N R    | S S R  | -      | D D    | N      | S      |
| D      |        |        | S      |        |        | N      |        | D      | P      |
|        | G      | M      | P      | D      |        | S      | D      | D      | P      |
| S x    | N      | D 2    | D      | P      | M 0    | G      | R 3    | R      | S      |

<!-- image -->

## Chota khayal of raag bhairav set to teentaal

## Sthayi:

## Antra:

Jago mohan pyare, sanvari surata more mana bhave sundara laal hamare

Prata samaya outhi bhanudaya bhayo, Gwala bala sab bhupata thade Darashana ke sab bhukhe pyase, Uthiyo nandkishore

In this image we can see a musical instrument.

<!-- image -->

| 1     | 2      | 3     | 4      | 5     | 6      | 7     | 8      | 9      | 10     | 11   | 12   | 13   | 14    | 15   | 16    |
|-------|--------|-------|--------|-------|--------|-------|--------|--------|--------|------|------|------|-------|------|-------|
| Dha   | Dhin   | Dhin  | Dha    | Dha   | Dhin   | Dhin  | Dha    | Dha    | Tin    | Tin  | Ta   | Ta   | Dhin  | Dhin | Dha   |
| X     |        |       |        | 2     |        |       |        | 0      | 0      |      |      | 3    |       |      |       |
|       |        |       |        |       |        |       |        | Sthayi | Sthayi |      |      |      |       |      |       |
|       |        |       |        |       |        |       |        | G      | M      | D    | P    | P -  | D     |      | M     |
|       |        |       |        |       |        |       |        | Ja     | ʃ      | go   | ʃ    | Mo   | ʃ     | ha   | na    |
| DD    | PM     | P     | -      | M     | -      | G     | -      | G      | -      | M    | R    | G    | M     | P    | P     |
| Pyaʃ  | ʃ ʃ    | ʃ     | ʃ      | re    | ʃ      | ʃ     | ʃ      | San    | ʃ      | va   | ri   | Su   | ʃ     | ra   | ta    |
| M     | G      | M     | G      | R     | -      | S     | -      | N      | S      | G    | M    | P    | D     | N    | Ṡ     |
| Mo    | re     | ma    | na     | Bha   | ʃ      | ve    | ʃ      | Sun    | ʃ      | da   | ra   | la   | ʃ     | la   | ha    |
| Ṙ     | Ṙ      | Ṡ     | N      | D     | P      | M     | G      |        |        |      |      |      |       |      |       |
| Ma    | ʃ      | ʃ     | ʃ      | ʃ     | ʃ      | re    | ʃ      |        |        |      |      |      |       |      |       |
|       |        |       |        |       |        |       |        | Antra  | Antra  |      |      |      |       |      |       |
|       |        |       |        |       |        |       |        | P      | -      | P    | P    | D D  | N     |      | N     |
|       |        |       |        |       |        |       |        | Pra    | ʃ      | ta   | sa   | ma   | ya ou |      | thi Ṡ |
| Ṡ     | -      | Ṡ     | -      | Ṡ     | N      | Ṙ     | Ṡ      | D      | - ʃ    | D    | N    | Ṡ    | Ṡ     | Ṡ    |       |
| Bha   | ʃ      | nu    | ʃ      | Da    | ya     | bha   | yo     | Gwa    |        | la   | ba   | ʃ    | la    | sa   | ba    |
| Ṙ     | -      | Ṡ     | Ṡ      | (Ṡ)   | -      | D     | P      | G      | M      | P    | D    | Ṡ    | N     | D    | P     |
| Bhu   | ʃ      | pa    | ta     | tha   | ʃ      | re    | ʃ      | Da     | ra     | sha  | na   | ke   | ʃ     | sa   | ba    |
| G     | -      | (M)   | -      | R     | -      | S     | -      | N      | S      | G    | M    | P    | D     | N    | Ṡ     |
| Bhu   | ʃ      | khe   | ʃ      | Pya   | ʃ      | se    | ʃ      | Ou     | thi    | yo   | ʃ    | Nan  | ʃ     | da   | Ki    |
| Ṙ     | Ṙ      | Ṡ     | N      | D     | P      | M     | G      |        |        |      |      |      |       |      |       |
| sho   | ʃ      | ʃ     | ʃ      | ʃ     | ʃ      | re    | ʃ      |        |        |      |      |      |       |      |       |
| x     |        |       |        | 2     |        |       |        | 0      |        |      |      | 3    |       |      |       |
| Taan  |        |       |        |       |        |       |        |        |        |      |      |      |       |      |       |
| SR    | GM     | PD    | NS     | ND    | PM     | GR    | S -    |        |        |      |      |      |       |      |       |
| DD    | PM G - | PM RG | GM M - | PM GM | GM P - | GR MP | S - D- | PD     | N -    | DN   | S-   | SN   | DP    | MG   | RS    |
| SR SG | MP     | GM    | DD     | P -   | GM     | PD    | NS     | R R    | S -    | SN   | DP   | MP   | GM    | GR   | S -   |

Ga Ma Pa

Sa Re GaMaPaDha Ni

888888

88

8 8

In this image, we can see a musical instrument.

<!-- image -->

1.5

## Raag Khamaj

10

In this image we can see the sun. At the bottom of the image there is a sea.

<!-- image -->

Raag Khamaj is an evening raag sung between 10 p.m. and 1 a.m. This raag is  classified  under Khamaj thata . Raag khamaj is  the ashraya raag of thata Khamaj . It uses six swar-s in the aroha (Re is omitted) and all seven swar-s in the avroha . Moreover, Shudh Ni is used in the aroha while komal Ni is used in the avroha . The vadi swar is G, and the samvadi is N.

Aroha :

S

G

M

P

D

N

S

Avroha

:

S

N

D

P

M

G

R

S

Pakad :

N

D,

M

P

D,

M

G

Thata :

Khamaj

Jati

:

Shadav- Sampoorna

Vadi

:

G

Samvadi :

N

Time of Singing :

2 nd  Part of the night (10.00 p.m - 1.00 a.m)

Ga Ma Pa

Sa Re GaMaPaDha Ni

88888888

88

In this image we can see a musical instrument.

<!-- image -->

1.5.1

## Sargam Geet in Raag Khamaj set to Teentaal

| 1       | 2       | 3       | 4       | 5       | 6       | 7       | 8       | 9       | 10      | 11      | 12      | 13      | 14      | 15      | 16      |         |
|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| Dha X   | Dhin    | Dhin    | Dha     | Dha 2   | Dhin    | Dhin    | Dha     | Dha 0   | Tin     | Tin     | Ta      | Ta 3    | Dhin    | Dhin    | Dha     |         |
| Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  | Sthayi  |
| G       | G       | S       | G       | M       | P       | G       | M       | N       | D       | -       | M       | P       | D       | M       | G       |         |
| G       | -       | -       | -       | D       | N       | S       | -       | S       | N       | D       | P       | M       | G       | R       | S       |         |
| X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 | X 2 0 3 |
| Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   | Antra   |
| G       | M       | D       | N       | S       | -       | N       | S       | S       | G       | M       | G       | N       | N       | S       | -       |         |
| S       | R       | S       | N       | D       | N       | D       | P       | D       | M       | P       | G       | M       | G       | R       | S       |         |
| N       | S       | G       | M       | P       | G       | -       | M       | N       | D       | -       | M       | P       | D       | M       | G       |         |
| G       | -       | -       | -       | D       | N       | S       | -       | S       | N       | D       | P       | M       | G       | R       | S       |         |
| X       | X       | X       | X       | 2       | 2       | 2       | 2       | 0       | 0       | 0       | 0       | 3       | 3       | 3       | 3       | 3       |

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## 'Hallmarks of a true Vaishnav'

## Translation

Vaishnava Janato, Tene Kahiye Jé Peer Paraayi Jaané Ré, Para Dukhé Upakāar Kare Toye Maan Abhimāna Na Āane Ré

Sakala Lok Māa Sahune Vande, Nindā Nakaré Kenī Ré, Vāach Kāach Maan Niśchal Rāakhe, Dhan Dhan Jananī Tenī Ré

Samadrishthi Ne Trishnā Tyāagī, Para-Stree Jene Māat Ré, Jihvā Thakī Asatya Na Bolé, Para-Dhana Nav Jhāli Hānth Ré

Moha Māyā Vyāpe Nahi Jene, Dridh Vairāgya Jenā Maan Maan Ré, Rāam Nāam Śuna Tāalī Lāgī, Sakala Tīrath Tenā Tan māan Ré

Vaan-Lobhī Né Kapat-Rahit Cche, Kāam Krodh Nivāryā Ré, Bhane Narsaiyo Tenu Darshan Karatā, Kula Ekoter Tāryā Ré

Him we call a 'Vaishnav, who Realises the pain of others who helps those who are in misery without letting pride enter his mind.

One who respect the entire World, who doesn't disparage anyone, who keeps his speech, deeds and thoughts Pure, Blessed Indeed is the mother of such a soul!

One who sees all equally and relinquishes cravings, who reverse other woman as his own mother. His tongue may tire, but never utter untruth! And his hand never touch other's wealth.

One who doesn't succumb to wordly attachments whose mind is deeply rooted in  staunch  renunciation. He is immersed in chanting the praises of Lord Ram And all holy pilgrimage sites are embodied within him!

One who is devoid of greed and deceit and has forsaken lust and anger Narsing Says: ' I'd be grateful to meet such a soul, whose virtue liberates the entire lineage'

Translated by Sharanya Bharathwaj

In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

12

1

X

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

-

ʃ

X

2

S

Vai

G

Te

G

Pee

N

Ja

G

Pa

D

Ka

G

Ma

N

A

G

Sa

N

Sa

D

nin

N

ké

S

Va

G

Ni

G

dha

N

Te

6

G

na

P D

hi

N DP

ʃʃ

GM

ʃʃ

-

ʃ

MPD

ʃ	ʃ	ʃ

N DP

ʃ	ʃ

GM

ʃ	ʃ

N

ka

-

ʃ

MPD

ka

GM

ʃ	ʃ

G

cha

P D

ʃ	ʃ

N DP

na

GM

ʃ	ʃ

## Sthayi

5

0

G

ja

D P

ka

PD

raʃ

MP

reʃ

D

khé

DP

reʃ

PD

maʃ

MP

reʃ

## Antra

N

ʃ

S

van

DP

na

MP

reʃ

G

ʃ

D P

ra

PD

Jaʃ

MP

réʃ

3

GG

shna

MP

ʃné

MP

ʃra

DP

ʃné

MD

radu

NN

ʃra

MP

naa

DP

ʃne

M

Ka

NS

huné

ND

ʃda

DP

ʃné

RS

ʃcha

MP

shcha

MP

nadha

DP

ʃni

4

-G

ʃva

-

ʃ

-P

ʃpa

M

ʃ

-

ʃ

-N

ʃka

-P

ʃbhi

M

ʃ

PP

lalo

N

ʃ

P

ʃ

M

ʃ

-S

ʃka

-P

ʃla

-P

ʃna

M

ʃ

0

All other antra-s will follow the same tune(melody).

Ga Ma Pa

Sa Re GaMaPaDha Ni

888888

88

8 8

7

M

to

D M

ye

PD

yi

RG

ʃʃ

D

u

P

to

PD

na

RG

ʃ	ʃ

N

ma

S

dé

P

reʃ

RG

ʃ	ʃ

G

ma

D M

khé

PD

niʃ

RG

ʃ	ʃ

8

GR

ʃ	ʃ

G

je

NS

ʃʃ

-

ʃ

D

pa

P

ye

DNRS

na	ʃ	ʃ	ʃ

-

ʃ	ʃ

N

ʃ	ʃ

-

ʃ

P

ʃʃ

-

ʃ	ʃ

G

na

G

ʃ	ʃ

NRS

ʃ	ʃ

-

ʃ	ʃ

13

In this image, we can see a musical instrument.

<!-- image -->

## Did you know?

This poem was written by ' Adi Kavi ' Narsing Mehta in the 15 th century. Mahatma Gandhi  adopted  this  bhajan  into  his  roster  of  prayers,  routinely  sung  at  the Sabarmati Ashram . He strived to live by the ideals as described by Narsing Mehta.

1.6

## Alaap

Alaap-s are musical phrases used in raag elaboration. Alaap can be a nibadh (without taal )  or nibadh (with taal ).  Vocalists  normally  start  their raag presentation with alaap . However, he or she may choose any type of alaap depending on his or her mood or preference. There are different types of anibadh and nibadh alaap-s .They are described in the table below:

14

|    | Types of Alaap   | Features                                                                  |
|----|------------------|---------------------------------------------------------------------------|
|  1 | Sargam alaap     | Alaap sung with musical notes                                             |
|  2 | Akaar alaap      | Alaap sung with the mnemonic 'aa'                                         |
|  3 | Nom-tom alaap    | Alaap sung with meaningless syllables like nom, tom, ri, da, na, tana etc |
|  4 | Bol alaap        | Alaap sung using the lyrics of the composition                            |

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

## Taan

Taan is  a  form  of  embellishment  where  musical  notes  are  weaved  together in a melodious and logical sequence, and sung in fast tempo. Taan is highly creative, hence requires more practice. Taan also can take the form of sargam taan, akaar taan or bol taan .

<!-- image -->

-  A raag is combination of musical notes (melody) to express certain feelings.
- Jati is a way of classifying raag-s where the criteria of classification is based on the number of notes used in that raag .
-  There are three main jati-s : audav, shadav and sampoorna .
- Alaap and taan are forms of embellishment in raag elaboration.
- Raag Bhairav uses komal Rishab and komal Dhaivat .
- Raag Khamaj uses shudh Nishad in aroha and komal Nishad in avroha .
-  The note Rishab is omitted in the aroha of raag Khamaj .

In this image we can see a musical instrument.

<!-- image -->

15

In this image, we can see a musical instrument.

<!-- image -->

In this image we can see a book.

<!-- image -->

## Activity 1

1.  With the help of your teacher, work individually or in groups, and try  to compose two alankaar in aroha and avroha in the following raag-s.
- a) Raag Bhairav
- b) Raag Khamaj
- c) Share your alankaar-s with your friends, and try to sing them with the help of your teacher.
2.  From which raag can	you	find	the	following pakad :
- a) S G M D P, G M R S
- b) : N D, M P D, M G
3.  Discuss the time theory of raag-s .

In this image we can see a musical instrument.

<!-- image -->

16

In this image we can see a musical instrument.

<!-- image -->

## Assessment

1. Complete the table:
2. State whether the following statements are true (T) or false (F).
- a) Jati relates to the number of notes used in both aroha and avroha .
- b) The jati of raag Khamaj is sampoorna-sampoorna .
- c) The note Re is omitted in the aroha of raag Khamaj .
- d) Raag Bhairav uses all shudh swar-s .
- e) Raag Khamaj is sung in the morning sandhi-prakash period.
- f) Raag Bhairav is sung during the first part of the day.
- g) The vadi swar of raag Bhairav is Dha .
- h) The samvadi swar of raag Khamaj is Re.
- i) Raag Khamaj uses both forms of Nishad .
- j) Both Bhairav and Khamaj are ashraya raag-s .

| Raag            | Bhairav   | Khamaj   |
|-----------------|-----------|----------|
| Aroha           |           |          |
| Avroha          |           |          |
| Pakad           |           |          |
| Vadi            |           |          |
| Samvadi         |           |          |
| Thata           |           |          |
| Jati            |           |          |
| Time of Singing |           |          |
| Varjit swar     |           |          |
| Vikrit swar     |           |          |

In this image we can see a musical instrument.

<!-- image -->

17

In this image, we can see a musical instrument.

<!-- image -->

## 3. Complete the following crossword.

18

Across

3.

In this image we can see a board.

<!-- image -->

## Across

7.

Down

- pentatonic scale a raag using both Ni 3. pentatonic scale

8.

- rapid movement of notes 7. a raag using both Ni

9.

12.

1.

## flat note Down

2.

4.

- using all seven notes raag 8. rapid movement of notes
- one slot of 3 hours a raag with 2 komal swar-s 2. group of seven notes
- group of 7 notes 1. flat note

5.

6.

- midnight to noon 4. one slot of 3 hours

10.

- musical phrase to elaborate 9. raag using all seven notes

13.

13. raag using six notes
11. 13. one note omitted 12. musical phrase to elaborate raag
3. number of notes used in a raag pure note 6. midnight to noon
4. noon to midnight 5. a raag with 2 komal swar-s
10. noon to midnight
11. a way of classifying raag-s
13. natural notes

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

In this image we can see a poster with some text and some objects.

<!-- image -->

## Learning Objectives

## At the end of this chapter, students should be able to:

- Recognise each of the following components in the process of singing: Avartan, vibhag, matra, sam, dusri, khali, tisri, tali, theka
- List the importance of Laya in music
- Write the notation of the taal-s : Ektaal and Deepchandi
- Write the notation of previous taal-s (Grade 7 and 8) in dugun laya
- Count and recite with correct pronunciation the prescribed taal-s in thaah (Basic Laya )
- Recognise the action of the hands while counting the taal
- Recognise the taal-s prescribed previously
- Demonstrate the different types of Laya by clapping the hands
- Count and recite with correct pronunciation (grade 7) in dugun laya .

In this image, we can see a musical instrument.

<!-- image -->

## Components of Taal

## Avartan

Avartan is the complete cycle of a taal . It starts from the first beat and ends on the same beat.

## Matra

Matra is the unit of measurement in taal . For example, teentaal consists of 16 matra-s, and jhaptaal consists of 10 beats / matra-s.

## Vibhag

Vibhag refers to the different sections found in a taal. Each vibhag consists of a specific number of beats. For example, dadra taal has 2 vibhag-s, and each vibhag consists of 3 matra-s .

## Theka

Theka is  the  pre-set bol-s of  a taal. It  gives  the taal a  form  when  played repeatedly to establish a unique pattern.

## Tali

Tali refers to accented beats in a taal .

## Sam

Sam is the first and most accented beat in any taal . It is denoted by the sign 'X' into notation form and by a clap while counting.

In this image we can see a musical instrument.

<!-- image -->

20

In this image we can see a musical instrument.

<!-- image -->

## Dusri/ Teesri

Dusri/ Teesri is indicated by a clap.

## Khali

Khali is the unaccented beat in any taal. It is denoted by the sign '0' into notation form and by a waving of the hand while counting.

## Laya

Laya is  the  term  used  for  speed  or  tempo  in  Indian  music.  It  is  the  steady and regular flow of beats in a rhythmic cycle. Any action repeated at a regular interval establishes a specific laya . For example, when somebody is walking at a regular pace or speed is established; the heartbeat or ticking of the clock is at a particular speed. The speed or pace of the beat is termed as laya in Indian music.

## Importance of Laya in music

It brings regularity in music.

It is a medium to enhance the mood or the sentiment one wishes to express. It gives form to music.

Apart from Sam ,  the  other  accented beats of a taal are  represented by the numbers 2,3 and 4, and are shown by a clap while counting.

## Types of laya

There are 3 main types of laya, namely vilambit (slow speed), madhya (medium speed) and drut (fast speed).

In this image, we can see a musical instrument.

<!-- image -->

21

In this image, we can see a musical instrument.

<!-- image -->

## Taal Ektaal

Taal Ektaal is a cycle of 12 beats divided into six equal vibhag-s.

Taal Ektaal -Notation in thaah and dugun laya

| Matra         | 1    | 2                   | 3     | 4      | 5           | 6      | 7        | 8           | 9 10        | 11          | 12     |
|---------------|------|---------------------|-------|--------|-------------|--------|----------|-------------|-------------|-------------|--------|
| Theka (Ekgun) | Dhin | Dhin                | DhaGe | TitKit | Tin         | Na Kat | Ta       | DhaGe       | TitKit      | Dhin        | Na     |
| Taal Signs    | x    |                     | 0     |        | 2           | 0      |          |             | 3           | 4           |        |
| Dugun         |      | DhinDhinDhaGeTitKit | TitNa | KatTa  | DhaGeTitKit | DhinNa | DhinDhin | DhaGeTitKit | TinNa KatTa | DhaGeTitKit | DhinNa |
| Taal Signs    | x    |                     | 0     |        | 2           |        | 0        |             | 3           | 4           |        |

The hand kriya-s in the diagram below depict the padhant of taal ektaal .

In this image, we can see a chart.

<!-- image -->

22

(Repetition of 1 to complete the cycle)

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## Taal Deepchandi

Deepchandi taal is  a  rhythmic  cycle  consisting  of  14  beats.  There  are  four vibhag-s.

Taal Deepchandi

-

Notation in thaah laya

| Matra         | 1   | 2    | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10   | 11   | 12   | 13   | 14   |
|---------------|-----|------|-----|-----|-----|-----|-----|-----|-----|------|------|------|------|------|
| Theka (Ekgun) | Dha | Dhin | S   | Dha | Ge  | Tin | S   | Ta  | Tin | S    | Dha  | Ge   | Dhin | S    |
| Taal Signs    | X   |      |     | 2   |     |     |     | 0   |     |      | 3    |      |      |      |

The hand kriya-s in the diagram below depict the padhant of taal deepchandi .

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Taal Kaherwa

Taal Kaherwa -Notation in and

thaah dugun laya

| Matra      | 1     | 2    | 3    | 4     | 5     | 6    | 7    | 8     |
|------------|-------|------|------|-------|-------|------|------|-------|
| Theka      | Dha   | Ge   | Na   | Ti    | Na    | Ka   | Dhi  | na    |
| Taal Signs | X     |      |      |       | 0     |      |      |       |
| Dugun      | DhaGe | NaTi | NaKa | Dhina | DhaGe | NaTi | NaKa | Dhina |
| Taal Signs | X     |      |      |       | 0     |      |      |       |

## Did you know?

Bollywood songs ' sun ri sakhi ' from the film ' Humse Hain Muqabala ' (1994), sung by Hariharan, and ' Kahe chhed chhed mohe ' from the film ' Devdas ' (2002), sung by famous kathak expert Birju Maharaj, Kavita Krishnamurthy and Madhuri Dixit are set to taal ektaal .

24

Famous thumri ' Aaj jaane ki zid na karo ' , composed in Raag Yaman, is set to Taal Deepchandi . Moreover, many Bhojpuri wedding songs are set to this taal. Two examples are haldi geet 'Sone ke katoriya main ' and Parchawan geet 'Gaawa ou mangal gaan'.

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

- Taal Ektaal is a cycle of 12 beats.
- Taal Deepchandi is a cycle of 14 beats.
-   There are 3 main types of laya: vilambit, madhya and drut.
- Laya brings regularity and consistency in music.

In this image, we can see an object. In the background, we can see some text.

<!-- image -->

25

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Activity 1

## 1. Matching

| Laya       | Cycle of 12 beats   |
|------------|---------------------|
| Vilambit   | Void / wave         |
| Drut       | Cycle of 14 beats   |
| Khali      | Starting Point      |
| Sam        | Fast Speed          |
| Matra      | Other accented beat |
| Theka      | Slow tempo          |
| Tali       | One unit            |
| Deepchandi | Preset bol-s        |
| Ektaal     | Tempo               |

## 2. Complete the following table

| Taal    | Number of beats   | Vibhag   | Sam   | Khali   | Dusri   | Tisri   |
|---------|-------------------|----------|-------|---------|---------|---------|
| Dadra   |                   |          |       |         |         |         |
| Keherwa |                   | 2        |       |         |         |         |
| Roopak  |                   |          |       | 1       |         |         |

In this image we can see a musical instrument.

<!-- image -->

26

In this image we can see a musical instrument.

<!-- image -->

## 3. Find the components of Taal

M  D K I L J O  Z Q  C X Q  Y Q  C U H L H K A Q  S E X B H K S B V A E M  A W  Y M  K L M  P L O  S T D J Y Y L B A V Z K A F N F O  N B Y F W  I G  B E N U B J P C A D I J D I A B C G  W  T E I B H H R R S Q  Z N R R Z H F M V K F Y R S W  P M  A G  V E W  V L I Z H A R U F C A T H K D E M  S B E C Q  Q  D M  K T R A M  B M  K E H U P V D L H A R A T B A C X R A W  D L H T T J A V R S L G  D S G  K J E O  H T G  D A I N G  D N R C E E Y X A U P O M  F A I D V Y U L D M  C H T S

27

AVARTAN

DUSRI

KHALI

KHAND

LAYA

MATRA

SAM

TALI

THEKA

VIBHAG

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Assessment

## 1. Fill in the blanks.

- a) Taal …………… is a cycle of twelve beats.
- b) Taal
3. …………… is a cycle of fourteen beats.
- c) The symbol '3' in Ektaal
5. is in the ………… vibhag .
- d) Taal ………….. has 6 vibhag-s .
- e) Three taal-s
8. having sign X - 2 - 0 - 3 are ……………, ………………

and ……………..

## 2. State whether the following statements are true (T) or false (F).

- a) Taal Deepchandi has 6 vibhag-s. (\_\_\_)
- b) Taal Ektaal is a cycle of  12 beats. (\_\_\_)
- c) Laya is the term used for tempo or speed in music. (\_\_\_)
- d) Taal Deepchandi has an equal number of matra-s in each vibhag . (\_\_\_)
- e) Khali is the unaccented beat in any taal . (\_\_\_)

## 3. Complete the following table

| Taal       | Number of beats   | Vibhag   | Sam       | Khali   | Dusri   | Tisri   |
|------------|-------------------|----------|-----------|---------|---------|---------|
| Deepchandi |                   |          |           |         | 4 th    |         |
| Ektaal     |                   |          | 1 st beat |         |         |         |

Ga Ma Pa ,

Sa Re GaMaPaDha Ni

28

8

8888888

8 8

In this image we can see a musical instrument.

<!-- image -->

4. Study the table below and answer the following questions:
- a. Which taal has 7 matra-s ?
- b. Complete the missing theka on number 2, 6 and 7.
- c. Complete the dugun of the taal .
5. Recognise the taal below.

| Matra      | 1         | 2        | 3         | 4         | 5         | 6         | 7         |
|------------|-----------|----------|-----------|-----------|-----------|-----------|-----------|
| Theka      | Tin       | ......   | Na        | Dhin      | Na        | .......   | .......   |
| Taal Signs | X         |          |           | 2         |           | 3         |           |
| Dugun      | ......... | ........ | ......... | ......... | ......... | ......... | ......... |
| Taal Signs | X         |          |           | 2         |           | 3         |           |

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## NOTES

30

8

8888888

8 8

Ga Ma Pa

Sa Re GaMaPaDha Ni

In this image we can see a girl wearing a blue dress and a cap is standing. In the background there is a board with some text.

<!-- image -->

## Learning Objectives

At the end of this chapter, students should be able to:

- Identify the process of voice production and its different stages.
- Identify different ways and means to keep the voice healthy.
- Differentiate between loud singing and proper singing through  voice modulation.
- Sing alankaar-s together with gamaka-s.

In this image, we can see a musical instrument.

<!-- image -->

3.0

## Voice    Production

Voice is  the  sound  produced  through  the  mouth  in  the  form  of  speech  and singing. Voice production is the sound produced in the larynx by the vibration of the vocal cords. The human voice can be modified in many ways like whispering, speaking, orating and shouting. Different sounds are also possible in different forms of vocal music such as rock singing, gospel singing and opera singing. The foundation for a well-trained voice is based on the coordination of three factors namely:

- Breathing
- Phonation
- Resonance

3.1.1

## Breathing

In this image we can see a person's body.

<!-- image -->

32

Breathing is the process of  respiration  during  which air is inhaled into lungs through the mouth or nose. Professional  singers  need to  practise  good  breathing techniques as singing and  breathing  are  closely related.

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

3.1.2

## Phonation

Phonation is defined as the process  where  vocal  sound  is created by the opening and closing  of  the  vocal  cords.  It  is caused by air flow from the lungs, which is essential for normal speech and singing.

In this image there are two pictures. On the left side there is a picture of a tissue. On the right side there is a picture of a tissue. In the center there is a picture of a tissue.

<!-- image -->

3.1.3

## Resonance

33

Resonance  occurs  when  a voiced sound is amplified and modified  by  the  vocal  tract resonators (the throat, mouth cavity, and nasal passages).

This image is a medical illustration of a human face. The image is divided into three main sections. The top section shows a close-up of the nose, with the nose and the mouth clearly visible. The nose is depicted as a human face with a full, rounded shape. The mouth is also shown, with the lips slightly parted and the tongue visible. The nose and mouth are positioned in such a way that the nose is the central focus of the image.

The middle section shows a close-up of the throat, with the throat and the mouth clearly visible. The throat is depicted as a human face with a curved, curved shape. The mouth is also shown, with the lips slightly parted and the tongue visible. The throat and mouth are positioned in such a way that the throat is the central focus of the image.

The bottom section shows a close-up of the neck, with the neck and the neck muscles clearly visible. The neck is depicted as a

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

<!-- image -->

## Keeping the Voice Healthy

Keeping  the  voice  healthy  is  of  utmost  importance  both  for  speaking  and singing. The following are different ways and means to keep the voice healthy.

<!-- image -->

## 1. Staying hydrated:

Drinking  six  to  eight  glasses  of  water  per day is recommended.

Drinks containing alcohol or caffeine should be avoided.

Some  medications  that  dry  out  the  vocal folds should not be taken too often.

<!-- image -->

<!-- image -->

## 2. Maintain a healthy lifestyle and diet:

Avoid  smoking.  Smoking  is  injurious  to health.

In this image we can see a musical instrument.

<!-- image -->

34

In this image we can see a musical instrument.

<!-- image -->

Avoid eating spicy foods.

<!-- image -->

<!-- image -->

Keep a good hygiene.

Foods containing vitamins A, E, and C like whole  grains,  fruits,  and  vegetables  are beneficial  to  keep  the  mucus  membranes healthy.

<!-- image -->

<!-- image -->

Physical fatigue should be avoided and enough rest should be taken. One has to sleep at least 6 hours per day.

One should exercise regularly as it increases stamina and muscle tone which helps provide good posture and breathing

In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

35

In this image, we can see a musical instrument.

<!-- image -->

<!-- image -->

Avoid screaming.

## 3. Using the voice wisely:

Avoid  speaking  or  singing  when  the  voice is hoarse or tired, and rest the voice when sick.

<!-- image -->

<!-- image -->

36

Consider using a microphone in noisy places.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Practise  good  breathing  techniques  when singing or talking

In this image we can see a musical instrument.

<!-- image -->

## Activity 1

## LET'S PLAY

## Rearrange the words to construct the proper sentence.

- 1) Techniques when singing Practise good breathing or talking

...................…………………………………………………………….

- 2) The voice is hoarse Avoid speaking rest the voice or when or tired and singing when sick

........…………………………………………………………………….

- 3) Sleep at least 6 hours per day Physical fatigue rest should be taken or one has to should be avoided and enough

...................…………………………………………………………….

- 4) Regularly as it increases One should exercise stamina provide good posture and breathing and muscle tone which helps

...................…………………………………………………………….

In this image, we can see a musical instrument.

<!-- image -->

37

In this image, we can see a musical instrument.

<!-- image -->

3.3

## Voice Modulation

Voice modulation is the act of  adjusting or controlling one's pitch and volume while speaking or singing. It is a very useful process through which one can deliver a speech or sing by making oneself heard by the listener. The following elements are used for voice modulation:

1. Pitch - The level of sound of the voice.
2. Volume - how loud or soft is the voice.
3. Pause - Pause is taken to breathe and gain more energy.
4. Tempo - A certain speed should be maintained.
5. Expression - Expressions in a voice can easily send the message to the listener.

<!-- image -->

38

## Voice practice through alankaar-s and gamaka-s

Sadhana (practice  with  dedication)  and  music  grammar  are  important  for  a singer. It implies a regular practice of swar in laya and taal . Swar-s should be practised steadily and correctly for voice modulation. For a singer, the practice of alankaar-s is of utmost important to help in the modulation of voice.

In this image we can see a book and a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## Activity 2

## Practice the following sargam many times by increasing the laya gradually:

S

S

S

-

R

R

R

-

G

G

G

-

M

G

R

S

P

P

P

-

M

G

M

-

G

R

G

-

M

G

R

S

P

P

S

-

S

N

D

P

SN DP SN DP SN DP MG RS

0

3

X

2

<!-- image -->

- An effective voice is based on the coordination of three factors, namely: Breathing, Phonation, Resonance.
- Keeping the voice healthy is of utmost importance both for speaking and singing.
- Sadhana  is important for a singer.

In this image we can see a musical instrument.

<!-- image -->

39

In this image, we can see a musical instrument.

<!-- image -->

## Assessment

## 1. Fill in the blanks

- a) The foundation for a well-trained voice is based on the coordination of three factors, which are \_\_\_\_\_\_\_\_\_\_\_\_\_\_, \_\_\_\_\_\_\_\_\_\_\_\_\_\_ and

\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- \_\_\_\_\_\_\_\_\_\_\_\_\_\_ is the process of inhaling oxygen and exhaling
- b) carbon dioxide.
- c)
- Avoid speaking or singing when the voice is \_\_\_\_\_\_\_\_\_\_\_\_\_\_ or
- \_\_\_\_\_\_\_\_\_\_\_\_\_\_ and rest the voice when sick.
- d) \_\_\_\_\_\_\_\_\_\_\_\_\_\_ \_\_\_\_\_\_\_\_\_\_\_\_\_\_ happens when someone adjusts or controls his/her pitch and volume while speaking or singing.
- e) One should \_\_\_\_\_\_\_\_\_\_\_\_\_\_ regularly as it increases stamina and muscle tone, which helps provide good posture and breathing.
2. Define	the	term Sadhana in music.
3. Name the three factors that help in the foundation of a welltrained voice.
4. What	are	the	five	aspects	in	voice	modulation?
5. Elaborate on any 3 ways one can maintain a healthy voice.
6. Indicate whether the following statements are true (T) or false (F)
- a) Screaming is good for the voice. (\_\_)
- b) Sleeping only 2 hours per day helps to maintain a healthy life style. (\_\_)
- c) Sadhana implies a regular practice of swar in laya and taal. (\_\_)

d)

- Foods containing vitamins A, E, and C are beneficial to keep the
- mucus membranes healthy. (\_\_)

In this image, we can see a musical instrument.

<!-- image -->

40

In this image we can see a musical instrument.

<!-- image -->

## Activity 3

In this image, we can see a poster with some text and images.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## NOTES

42

88888888

88

Ga Ma Pa

Sa Re GaMaPaDha Ni

In this image we can see a person's hand on a piano.

<!-- image -->

## Learning Objectives

At the end of this chapter, students should be able to:

- Define shruti
- Differentiate between shruti and swar through a linear representation
- Identify the swar-s out of the 22 shruti-s
- Sing and recognise the shudh swar-s
- Sing and recognise the 5 vikrit swar-s
- Sing alankaar-s in swar and akaar.

In this image we can see a musical instrument.

<!-- image -->

## Definition	of	the	term	'Shruti'

The word shruti is derived from the root ' shru ' which means to hear. Therefore, shruti can be defined as an audible sound; a sound which can be heard. Shruti is also known as microtones.

Ancient musicologists describe shruti as ' shruyate iti shruti ' which means that when sound is clearly heard, it can be identified as a shruti .  The  possibility of resting or pausing on a sound allows the human ear to recognise it as a specific swar . Hence, shruti and swara-s are closely connected. When shruti-s are clearly pronounced, sustained and expressed, they take the form of a swar .

There are 22 shruti-s in  a  musical  scale. These 22 shruti-s are  distinct  and different from each other. It is relatively easier for the common human ear to differentiate between shudh swar-s as opposed to vikrit swar-s . However, it is more difficult to distinguish between shruti-s .

## The names of the 22 shruti-s are as follows:

44

|   1 | Tivraa      |   12 | Preeti     |
|-----|-------------|------|------------|
|   2 | Kumadati    |   13 | Maarjanee  |
|   3 | Mandaa      |   14 | Kshiti     |
|   4 | Cchandovati |   15 | Raktaa     |
|   5 | Dayaavati   |   16 | Sandeepani |
|   6 | Ranjani     |   17 | Aalaapinee |
|   7 | Raktika     |   18 | Mandati    |
|   8 | Rawdri      |   19 | Rohinee    |
|   9 | Krodhaa     |   20 | Ramyaa     |
|  10 | Vaarjika    |   21 | Ougraa     |
|  11 | Prasaarinee |   22 | Kshovini   |

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## Ancient and modern musicologists' views on shruti-s.

Both  ancient  and  modern  musicologists  accept  the 4+3+2+4+4+3+2=22 distribution  of shruti-s amongst the seven swar-s .  The  distribution  is  shown below:

Swar-Shruti-s distribution

| Swar   |   Number of Shruti-s |
|--------|----------------------|
| S      |                    4 |
| R      |                    3 |
| G      |                    2 |
| M      |                    4 |
| P      |                    4 |
| D      |                    3 |
| N      |                    2 |

However, ancient musicologists believe that Sharaj (Sa) is on the 4 th shruti while modern musicologists assume Sharaj to be the starting point of the distribution. The following diagram depicts this difference.

45

## Ancient Scale

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Alankaar for practice (Raag Bhairav)

## Step 1:

Choose a standard pitch on an electronic tanpura and sing the note S.

## Step 2:

Sing each alankaar in aroha and avroha.

## Step 3:

Try each alankaar in sargam and akaar with different laya-s.

## Step 4:

After completing each alankaar, sing it individually and in groups.

46

In this image I can see a musical instrument and a musical note.

<!-- image -->

| Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   | Alankaar 1 :   |
|----------------|----------------|----------------|----------------|----------------|----------------|----------------|----------------|----------------|----------------|
| Aroha :        | S              | R              | G              | M              | P              | D              | N              | Ṡ              |                |
| Avroha :       | Ṡ              | N              | D              | P              | M              | G              | R              | S              |                |
| Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   | Alankaar 2 :   |
| Aroha :        | SS             | RR             | GG             | MM             | PP             | DD             | NN             | ṠṠ             |                |
| Avroha :       | ṠṠ             | NN             | DD             | PP             | MM             |                | GG             | RR SS          |                |
| Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   | Alankaar 3 :   |
| Aroha :        | SRG            | RGM            | GMP            | MPD            | PDN            | DN             | Ṡ              |                |                |
| Avroha :       | Ṡ ND           | NDP            | DPM            | PMG            | MGR            | GRS            |                |                |                |
| Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   | Alankaar 4 :   |
| Aroha :        | SR             | RG             | GM             | MP             | PD             | DN             | N              | Ṡ              |                |
| Avroha :       | Ṡ N            | ND             | DP             | PM             | MG             | GR             | RS             |                |                |
| Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   | Alankaar 5 :   |
| Aroha :        | SRGM           | SRGM           | RGMP GMPD      | RGMP GMPD      | MPDN           | MPDN           | PDN            | Ṡ              |                |
| Avroha :       | Ṡ NDP          | Ṡ NDP          | NDPM DPMG      | NDPM DPMG      |                |                | PMGR           | MGRS           |                |

In this image, we can see a musical instrument.

<!-- image -->

<!-- image -->

- Shruti-s are microtones.
-  There are twenty two different and distinct shruti-s in a musical scale.

In this image we can see an open book.

<!-- image -->

47

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Assessment

1. What	do	you	understand	by	the	term	' shruti '?
2. What is the relationship between shruti and swar ?
3. Match	the	terms	in	the	first	column	to	their	corresponding terms in the second column.
4. Name any 5 shruti-s .
5. Complete the following raag based alankaar-s in aroha and avroha :
6. (a)					SG			GM			MP			\_\_\_			\_\_\_				NṠ

| Shru   | Sound      |
|--------|------------|
| Naad   | Natural    |
| Shudh  | Microtones |
| Shruti | Hear       |

Ṡ

N    ND   \_\_\_   \_\_\_  \_\_\_    RS

- (b)    SRSRG  RGRGM  \_\_\_\_\_\_\_  \_\_\_\_\_\_ \_\_\_\_\_\_ DND

NṠ

ṠNSN D  NDNDP   \_\_\_\_\_\_\_  \_\_\_\_\_\_ \_\_\_\_\_\_ GRGRS

- (c)				SG		RM		\_\_\_		\_\_\_		\_\_\_		DṠ

ṠD			NP		\_\_\_		\_\_\_		\_\_\_		GS

In this image we can see a musical instrument.

<!-- image -->

48

In this image we can see a poster with some text.

<!-- image -->

## Learning Objectives

At the end of this chapter, students should be able to:

- Sketch the life history of Pt. V.D. Paluskar.
- State how V.D. Paluskar has contributed to the field of Hindustani Music, highlighting his major achievements and innovations.

In this image we can see a musical instrument.

<!-- image -->

## Life sketch of Pt.Paluskar

Pandit V. D. Paluskar was born on 18 th  August 1872, during the British rule, in a small town named Kurundwad. At that time, Kurundwad fell under the Deccan division  of  Bombay  Presidency.  Digambar  Gopal  Paluskar,  father  of  Pandit Paluskar  was  a  singer  himself  and  he  used  to  sing  kirtans  during  religious activities.

<!-- image -->

V.  D.  Paluskar  temporarily  lost  his  eyesight  during  a festival, yet he continued his musical activities. It was then  that  the  King  of  Miraj  recognized  his  talent  and sent him to learn music from a renowned musician, Shri Bal Krishna Bua Ichalkaranjikar.

Shri Bal Krishna Bua Ichalkaranjikar

After his musical studies, Paluskar ji took up the task of conveying the message of music to every home in the simplest way. In 1901, he founded the Gandharva Mahavidyalaya in Lahore, the first music school run by public funds.

He was praised when he sang the original version of the bhajan ' Raghupati Raghav Raja Ram '. He then turned out to be an exponent of the famous Gwalior gharana .

Furthermore, he travelled throughout the country and organized music festivals in different places like Gwalior, Mathura, Delhi, Lahore, Amritsar, Kashmir etc. During his tour, he realized that many musicians were subject to various vices and that people were not interested in classical music. After a deep research in music, he came up with a notation system which is known as the 'Paluskar Notation System'. Paluskar died on 21 st  August 1931, three days after his 59 th birthday.

In this image we can see a musical instrument.

<!-- image -->

50

In this image we can see a musical instrument.

<!-- image -->

Today, Paluskar is seen as the musician who brought respect to the profession of  classical  musicians  and  took  Hindustani  classical  music  out  from  the traditional gharana system to the masses. He wrote a book on music called Sangeet Bal Prakash in three volumes, and 18 volumes on raga-s as  well. His disciples Vinayakrao Patwardhan, Omkarnath Thakur, Narayanrao Vyas, and B. R. Deodhar became renowned classical singers and teachers. His son Dattatreya Vishnu Paluskar was also trained in classical music.

On 21 st  July 1973, the Post and Telegraph Department, Government of India paid homage to Paluskar by releasing a commemorative stamp. In its 2000 millennial  issue,  India  Today  magazine  included  Paluskar  in  its  list  of  '100 people who shaped India'.

In this image we can see a painting of a man.

<!-- image -->

51

In this image we can see a group of people sitting on the ground. In the background there are plants and a building.

<!-- image -->

Gandharva Mahavidyalaya in Delhi

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

- V. D. Paluskar did his training under renowned

musician Shri Bal Krishna Bua Ichalkaranjikar.

<!-- image -->

- He was an exponent of the Gwalior Gharana .
- He founded the Gandharva Mahavidyalaya in Lahore.
- He created the Paluskar notation system.
- He brought classical music to the general public.
- He wrote many books on music and raag-s .

52

In this image we can see an open book.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## Assessment

1. Answer the following questions.
- a. Where was Pt. V. D. Paluskar born?
- b. Who was Pt. V. D. Paluskar's Guru?
- c. What did he discover during his musical tours around the country?
- d. Which gharana did he belong to?
- e. What is the name of the school founded by Pandit ji?
- f. List four contributions he made to the field of music.
- g. How did the Government of India recognise his contribution to the field of music?
- h. What was the opinion of India Today magazine of Pt. V. D. Paluskar?

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## NOTES

54

8 88888

8 8 88

Ga Ma Pa

Sa Re GaMaPaDha Ni

In this image, we can see a poster with some text.

<!-- image -->

## Learning Objectives

At the end of this chapter, students should be able to:

- Notate the compositions in the prescribed taal-s .
- Notate the theka-s of the taal-s prescribed in single speed.
- Sing the vocal compositions through sight reading.
- Count and recite  the taal-s through  sight  reading  with  correct  pronunciation.

In this image, we can see a musical instrument.

<!-- image -->

6.0

## Notation writing in Hindustani Music

Notation  is  a  method  of  representing  the  various  musical  notes  used  in  a composition by a system of letters, signs and symbols. Hindustani music is monophonic in nature  and  its  teaching  was  done  through  the guru-shishya parampara . However, when teaching of music was institutionalized, there was the need for an easy notation system.

Pandit V. N. Bhatkhande and Pandit V. D. Paluskar were the two pioneers who came up with an Indian notation system. These notation systems have been devised to:

- Preserve musical materials.
- Help in the transmission of knowledge.
- Standardize the teaching and learning of music.
- Help students to memorize the musical compositions.

In this image we can see a person.

<!-- image -->

In this image we can see a person.

<!-- image -->

Pt.Paluskar

Pt.Bhatkhande

Ga Ma Pa

Sa Re GaMaPaDha Ni

56

8

8 8888

88

8 8

In this image we can see a musical instrument.

<!-- image -->

## 6.1     Paluskar's and Bhatkhande's notation system

| Notes/Lyrics/Rhythm   | Paluskar's system                      | Bhatkhande's system                        |
|-----------------------|----------------------------------------|--------------------------------------------|
| Shudh swar            | S R G M P                              | S R G M P                                  |
| Komal swar            | R G D N                                | R G D N                                    |
| Tivra swar            | M                                      | M                                          |
| Mandra swar           | S R                                    | S R                                        |
| Taar saptak           | PM                                     | PM                                         |
| Kan swar              | P G                                    | P G                                        |
| Meend                 | P G                                    | P G                                        |
| Prolonged note        | G ʃ ʃ                                  | G - -                                      |
| Sam                   | 1                                      | X                                          |
| Khali                 | +                                      | 0                                          |
| Tali                  | Corresponding number of beats          | 2 nd , 3 rd , 4 th                         |
| 1 matra               | Dhin or G - -                          | Dhin or G                                  |
| ½ matra               | Dha Ge or G P o o o o                  | DhaGe or GP                                |
| ¼ matra               | Ti ta ki ta or S R G M                 | Ti ta ki ta or S R G M                     |
| 1/8 matra             | Double brackets under each bol or swar | Single bracket under all 8 bol-s or swar-s |

57

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## 6.2     Taal Notation in Paluskar's and Bhatkhande's system

## Taal Ektaal

## Paluskar's system

| Matra          | 1 2       | 3 4          | 5   | 6   | 7 8    | 9 10         |      | 11 12   |
|----------------|-----------|--------------|-----|-----|--------|--------------|------|---------|
| Theka          | Dhin Dhin | DhaGe TitKit | Tin | Na  | Kat Ta | DhaGe TitKit | Dhin | Na      |
| Value of matra | - -       | o o          | -   | -   | - -    | o o          | -    | -       |
| Taal Signs     | 1         | +            | 5   | +   |        | 9            | 11   |         |

## Bhatkhande's system

| Matra      | 1 2       | 3 4          | 5 6    | 7 8    | 9 10         | 11 12   |
|------------|-----------|--------------|--------|--------|--------------|---------|
| Theka      | Dhin Dhin | DhaGe TitKit | Tin Na | Kat Ta | DhaGe TitKit | Dhin Na |
| Taal Signs | x         | 0            | 2      | 0      | 3            | 4       |

## Teentaal

## Paluskar's system

| Matra          | 1   | 2    | 3    | 4   | 5   | 6    | 7    | 8   | 9   | 10   | 11   | 12   | 13   | 14   | 15   | 16   |
|----------------|-----|------|------|-----|-----|------|------|-----|-----|------|------|------|------|------|------|------|
| Theka          | Dha | Dhin | Dhin | Dha | Dha | Dhin | Dhin | Dha | Dha | Tin  | Tin  | Ta   | Ta   | Dhin | Dhin | Dha  |
| Value of matra | o   | o    | o    | o   | o   | o    | o    | o   | o   | o    | o    | o    | o    | o    | o    | o    |
| Taal Signs     | 1   |      |      |     | 3   |      |      |     | +   |      |      |      | 7    |      |      |      |

## Bhatkhande's system

| Matra      | 1   | 2    | 3    | 4   | 5   | 6    | 7    | 8   | 9   | 10   | 11   | 12   | 13   | 14   | 15   | 16   |
|------------|-----|------|------|-----|-----|------|------|-----|-----|------|------|------|------|------|------|------|
| Theka      | Dha | Dhin | Dhin | Dha | Dha | Dhin | Dhin | Dha | Dha | Tin  | Tin  | Ta   | Ta   | Dhin | Dhin | Dha  |
| Taal Signs | X   |      |      |     | 2   |      |      |     | 0   |      |      |      | 3    |      |      |      |

In this image we can see a musical instrument.

<!-- image -->

58

In this image we can see a musical instrument.

<!-- image -->

Bhatkhande's notation system is simpler and easier to decode than Paluskar's system.This is the reason why Bhatkhande's notation system is more popular and used in the teaching and learning of Hindustani sangeet.

## Activity 1

The famous nursery rhyme 'Frere Jacques' has been set into Bhatkhande's notation system below. Try to sing the words first and then try to sing the notes with the help of your teacher.

In this image I can see the text.

<!-- image -->

59

| FRÈRE JACQUES   | FRÈRE JACQUES   | FRÈRE JACQUES   | FRÈRE JACQUES   | FRÈRE JACQUES   | FRÈRE JACQUES   | FRÈRE JACQUES   | FRÈRE JACQUES   |
|-----------------|-----------------|-----------------|-----------------|-----------------|-----------------|-----------------|-----------------|
| S               | -               | -               | R               | G               | -               | S               | -               |
| Frè             | ʃ               | ʃ               | re              | jac             | ʃ               | ques            | ʃ               |
| G               | -               | M               | -               | P               | -               | -               | -               |
| Dor             | ʃ               | mez             | ʃ               | vous            | ʃ               | ʃ               | ʃ               |
| P               | D               | P               | M               | G               | -               | S               | -               |
| So              | nnez            | les             | ma              | ti              | ʃ               | nes             | ʃ               |
| R               | -               | N               | -               | S               | -               | -               | -               |
| Ding            | ʃ               | ding            | ʃ               | dong            | ʃ               | ʃ               | ʃ               |
| X               |                 |                 |                 | 0               |                 |                 |                 |

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Assessment

1.   Write the name of the taal-s below.  Complete them, and then count and recite them with the correct hand gestures and pronunciation.

TAAL

: ...............................................

| NUMBERS              | 1         | 2   | 3        | 4        | 5        | 6   | 7    | 8        |
|----------------------|-----------|-----|----------|----------|----------|-----|------|----------|
| SYLLABLES DHA        | ......... | NA  | ........ | ........ | KA       |     | DHIN | ........ |
| TAAL SIGNS ......... |           |     |          |          | ........ |     |      |          |

TAAL ………………………….

60

| NUMBERS       | 1         | 2   | 3        | 4        | 5   | 6        |
|---------------|-----------|-----|----------|----------|-----|----------|
| SYLLABLES DHA | ......... | NA  | ........ | TIN      |     | ........ |
| TAAL SIGNS    | ......... |     |          | ........ |     |          |

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

2.   The composition below has been taught in Grade 7. Write the name of  the raag from which it has been taken, and write the corresponding notes above each word.

## RAAG

: ...............................................

In this image I can see the text and numbers.

<!-- image -->

61

In this image I can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

3.    What does the following letters and signs indicate?
1. G
2. M -
3. Mo ʃ
4. P -  - -
5. R M
6. SRGM
7. M  R
8. (P)
9. M
10. X  |  0

88888888

88

62

Ga Ma Pa

Sa Re GaMaPaDha Ni

In this image we can see a musical instrument.

<!-- image -->

- Music notation means the writing of musical compositions using letters, signs and symbols.
- Two systems of notation in indian music are Bhatkhande and Paluskar notation system.
-   Bhatkhande's notation systems is more popular because it is simpler and easier than Paluskar's system.

<!-- image -->

In this image we can see a book.

<!-- image -->

63

In this image, we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## NOTES

64

88888888

88

Ga Ma Pa

Sa Re GaMaPaDha Ni

In this image, we can see a poster with some text and images.

<!-- image -->

## Learning Objectives

At the end of this chapter, students should be able to:

- Elaborate on the following terms : Thumri, Lakshangeet, Tarana
- Perform solo or in an ensemble along with musical instruments
- Demonstrate through singing the emotive aspects of the compositions.

In this image, we can see a musical instrument.

<!-- image -->

## Thumri

In this image we can see a painting of a woman.

<!-- image -->

The word ' thumri ' is made up of three syllables: ' thu ', ' ma ' and '' ri '. ' Thu ' means ' thumak ', the graceful and leisurely movements of the dancer. ' Ma ' stands for ' mana ', meaning both mind and heart. Last ' ri ' stands for ' rijhana ', meaning the enchanting quality of such music and dance.

## Origin

Thumri is a North Indian vocal form based on the romantic - devotional literature mainly influenced by the bhakti movement in the mid-19th century. The most accepted  theory  attributes  the  origin  of thumri to  the  Royal  court  of  Oudh, especially under the patronage of Nawab Wajid Ali Shah of Lucknow.

In this image we can see a musical instrument.

<!-- image -->

66

In this image we can see a musical instrument.

<!-- image -->

## Characteristics

- Kathak dancing is an adjunct to thumri . This dance form enhanced the beauty of the romantic lyrics of the composition.
-  The poetic content evolves from the romantic or shringaar rasa .
- Thumri-s are adorned with musical ornaments such as vistaar , bolbant, murki etc. Hence, this style requires a special training and voice quality for its proper rendering.
- Thumri singing allows artistic freedom as two or more raag-s can be mixed in one thumri . That is why some musicologists believe this genre should fall under light or semi classical music.
- Thumri-s are usually set to taal-s such as Deepchandi , Teentaal ( punjabi style), Ektaal and Jhaptaal .
- Thumri-s are mostly sung in raag-s such as Des, Tilak Kamod, Pilu, Kafi, Khamaj, Bhairavi, Jhinjhoti and Tilang .
-  Some famous exponents of this genre are: Rasoonlan Bai, Siddeshwari Devi, Girija Devi, Begum Akhtar, Shobha Gurtu, Noor Jahan and Prabha Atre.

## Lakshangeet

Lakshangeet is  another form of classical composition. The word 'lakshan '  is translated as characteristics or features. Lakshangeet is similar to chota khyal, having one sthayi and one antra . However, the lyrics of these two forms are different.  While the lyrics of chota khayal can be open to all topics such as love, separation, gods and goddesses etc., laskhangeet describes the salient features of the raag to which the lakshangeet is set. Thus, the lyrics can relate to the vadi, samvadi, time of singing, thata of the raag.

In this image we can see a musical instrument.

<!-- image -->

67

In this image, we can see a musical instrument.

<!-- image -->

'Bhairav lakshan gaay gunivar, komal sur Dha Re, Ga Ma Ni shudh kar...', for example, is the opening line of a lakshangeet in Raag Bhairav which means 'the characteristics ( lakshan ) of raag Bhairav are sung( gaay ) by scholars( gunivar ) where the note Dha and Re are flat ( komal ) and the note Ga, Ma and Ni are natural ( shudh ).

## Tarana

Tarana is  one  among  the  various  classical  forms  of  composition.  It  is  very similar to chota khayal, having one sthayi and one antra set to a particular raag and taal .  However, the lyrics used in tarana are  meaningless syllables, and it is usually sung in fast tempo. It is believed that Amir Khusro (1253 - 1325 BC) invented this style of composition. Legends state that during the time of Allaudin Khilji,  there  were 'musical' competitions between Gopal Nayak and Amir Khusro. Both wanted to impress the emperor and show their superiority in  music.  Amir  Khusro  did  not  understand  Hindi  or  Sanskrit.  Hence,  while rendering raag-s he substituted the Indian (Sanskrit, Hindi or Braj) words with Persian words. This is how syllables such as 'odani', 'tadani', 'tadeem', 'yalali' , or 'derena' is used as lyrics in tarana.

## Did you know?

A related style called ' Tillana '  is  prevalent in Carnatic music and it is used in dances like Bharata Natyam and Kuchipudi.

In this image we can see a musical instrument.

<!-- image -->

68

In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

- Thumri is a genre of light or semi-classical music.
-  The singer of thumri has the liberty to take foreign notes in a raag .
- Thumri is closely linked to kathak dance form.
- Lakshangeet is a form of composition where the lyrics describe the salient features of the raag to which the composition is set.
- Tarana is that form of composition where meaningless syllables are used as lyrics.
- Tarana is usually sung in drut laya .

<!-- image -->

## Keywords

Graceful movements, salient features, meaningless syllables.

Ga Ma Pa

Sa Re GaMaPaDha Ni

888888

88

8 8

69

In this image, we can see a musical instrument.

<!-- image -->

## Assessment

## 1. Fill in the blanks.

- a) …………………………. Is a type of composition where
2. meaningless syllables are used.
- b) ……………………… is closely linked to the kathak dance form.
- c) ……………………….unfolds the features of a raag .
- d) Tarana
6. is sung in ………………… laya .
- e) The equivalent of tarana in Carnatic style is known as

……………………… .

2. Write a short paragraph on the following musical forms.
- a) Thumri
- b) Lakshangeet

70

- c) Tarana

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a poster with some images and text.

<!-- image -->

## Learning Objectives

At the end of this chapter, students should be able to:

- Differentiate between the different categories in the classification of musical instruments
- Classify the various types of musical instruments
- Identify sound produced by different categories of instruments
- Describe the following instruments: Tanpura and manjira
- Demonstrate a keen interest in how the sounds produced by different categories of musical instruments differ from one another.

In this image, we can see a musical instrument.

<!-- image -->

8.0

## Introduction

Musical  instruments  differ  in  shape,  size,  material  and  tonal  quality.  These differences have led to the classification of musical instruments into different categories.  In  ' Natyashastra '  (Bharat  Muni),  four  categories  of  musical instruments have been mentioned.

1. Tat Vadya (Chordophone)
2. Avanadh Vadya (Membranophone)
3. Sushir Vadya (Aerophone)
4. Ghan Vadya (Idiophone)

With the evolution of technology one more category has been added:

5. Electrophones

<!-- image -->

72

## Tat Vadya ( Chordopones)

String  Instruments  are  known  as Tat  Vadya (Chordophones).  Sound  in chordophones is produced by means of stretched vibrating strings. As soon as the strings vibrate, the resonator of the instrument picks up that vibration and amplifies it to produce a more appealing sound. Chordophones are divided into subcategories depending on how the strings are being played.

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

- Chordophones played by Bowing
- Chordophones played by Plucking
- Chordophones played by Striking

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Ga Ma Pa

Sa Re GaMaPaDha Ni

<!-- image -->

<!-- image -->

<!-- image -->

88888

73

In this image, we can see a musical instrument.

<!-- image -->

8.2

## Tanpura

The tanpura is an instrument used for providing basic notes. It is important to note that the use of  this  instrument is  a  unique  feature of Indian music  as  no  other  musical  tradition  uses  an instrument to provide the base note. It is usually called tanpura in  North  India  and tambura in South India.

The tanpura is  a  long-necked  plucked  string instrument,  having  4  strings,  where  the  two middle  strings  are  tuned  to  the  tonic  (Sa),  the fourth string to an octave below the tonic pitch (Sa) and the first  string  to  either  Pa,  Ma  or  Ni depending on the raag .

## How to hold the tanpura?

on the lap

In this image we can see a girl is standing and holding a musical instrument.

<!-- image -->

8

8 8 8888888

across the lap

<!-- image -->

The tanpura can be played on the lap, across the lap or placed on the ground.

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a woman holding a musical instrument.

<!-- image -->

Ga Ma Pa

Sa Re GaMaPaDha Ni

on the ground

74

In this image we can see a musical instrument.

<!-- image -->

## How to play the tanpura?

The thumb supports the neck of the tanpura so that the remaining four fingers are placed almost parallel over the strings. The first string is strummed with the middle finger tip of the right hand whereas the second, third and fourth strings are strummed with the index finger one after the other. Strings are strummed from left to right in sequence and succession.

Thumb supporting the neck

<!-- image -->

<!-- image -->

<!-- image -->

Fingers almost parallel over the strings

<!-- image -->

Wrong finger position

Middle finger playing 1 st string

<!-- image -->

Index finger playing 2 nd ,3 rd and 4 th string

In this image we can see a musical instrument.

<!-- image -->

75

38

88

## Parts of a Tanpura

In this image, we can see a musical instrument. There are some musical notes and strings.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## Activity 1

## Write the name of the Instruments

In this image we can see a guitar.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

Ga Ma Pa

Sa Re GaMaPaDha Ni

88888

88

<!-- image -->

<!-- image -->

<!-- image -->

77

In this image, we can see a musical instrument.

<!-- image -->

8.3

## Ghan Vadya ( Idiopones)

Ghan Vadya are non-membranous percussive instruments. In this category, we have solid percussive instruments mostly made of metals. The Manjira , Ghatam ,  Cymbal ,  Ghunghroo, Chimta and the famous 'Triangle' used in the Mauritian sega are some examples of this category.

## Examples of Ghan Vadya

In this image we can see a few things.

<!-- image -->

6 8 €

## Some Useful Tips:

My  name  is  Ghatam.  I  am one of the most ancient percussion instruments of South  India.  I  am  made  of clay with iron fillings, Copper, silver,  gold  and  aluminium particles to give resonance. The player taps on my surface with the fingers and the base of the palm to change pitch and resonance

8 8

In this image we can see a person playing a drum.

<!-- image -->

In this image we can see a person sitting on the floor and holding a bowl in his hand.

<!-- image -->

I am a jal tarang , one of the oldest music instruments. I have pleasant  characteristic tones  similar  to  the  Feng Shui  wind  chimes.  I  am  a set  of  China  clay  bowls  of descending  sizes  laid  in  a semicircular  way  while  the player strikes my edge with wooden sticks to create the sound.

Ga Ma Pa

Sa Re GaMaPaDha Ni

888888

88

8 8

79

In this image, we can see a musical instrument.

<!-- image -->

## Manjira

The manjira , is a pair of small hand cymbals. It is usually made of brass and used in devotional singing  most  of  the  time.    It  is  made  of  two small copper plates tied together with a string. Both  copper  plates  should  hit  against  each other's edge to produce sound. The ' Manjira ' is considered to be one among the most ancient instruments.

<!-- image -->

80

The Manjira is  played  mostly  during devotional singing, like bhajan-s or kirtan-s . It is also used in music concerts as accompaniment and in dance performances such as Bharat Natyam, Kuchipudi, Manipuri,  Mohiniattam,  Andhra  Natyam, Katha Kali etc

In this image we can see a person's hand holding a yellow object.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

## Activity 1

## Match the followings:

1. Struck

Guitar

2. Plucked

Violin

3. Bowed

Piano

Fill	in	the	blanks	with	names	of	musical	instruments	fitting in each category. One example is already given.

|    | Chordophones   | Aerophones   | Membranophones   | Idiophones   |
|----|----------------|--------------|------------------|--------------|
|  1 | Sitar          | Flute        | Tabla            | Manjira      |
|  2 |                |              |                  |              |
|  3 |                |              |                  |              |
|  4 |                |              |                  |              |
|  5 |                |              |                  |              |

81

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Assessment

1. Fill in the blanks.
- a) The \_\_\_\_\_\_\_\_\_\_\_\_\_\_ is a pair of clash small hand cymbals.
- b) I am one of the oldest music instruments called \_\_\_\_\_\_\_\_    \_\_\_\_\_\_\_\_.
- c) The \_\_\_\_\_\_\_\_\_\_\_\_\_\_ is made of clay with iron fillings, copper,
5. silver, gold  and aluminium particles to give resonance.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_.

- d) Non-membranous percussive instruments are known as \_\_\_\_\_\_\_\_\_\_\_ Vadya.
- e) The \_\_\_\_\_\_\_\_\_\_\_\_\_\_ is a famous idiophone used in the Sega.
2. Give another term used for string instruments.
3. Explain how the tanpura is being played.
4. What do you understand by Ghan Vadya ?
5. Indicate whether the following statements are true (T) or false (F).
- a) The manjira is a dance form. (\_\_)
- b) The tabla is classified as a Ghana Vadya . (\_\_)
- c) The sega is a musical instrument. (\_\_)
- d) The Triangle is used in sega . (\_\_)

In this image we can see a musical instrument.

<!-- image -->

82

In this image we can see a musical instrument.

<!-- image -->

## Activity 2

## Find the hidden musical Instruments

E B V B Q L G J Y T W S C N M S Y G I G R H U R M Z A T I H I S N H H Y S I P I A N O Z D Z M U C U E A F M N I J D W  C Y J J Z F N A N I R C I E D V G C D L G P G L X F Z C J V N T A Q L M A O H G X I L E B O K L E C I D N N R R Q A T U A X O Z C N D A C J O Y V A Z R C I A A W H C A U R O I N M L R V M T C L W C T A R C P B S I R I R L D L I S M Z H U Q L M D U D K A R T A A L O R R S V M I J G N J T Q Z J R A D M N T C Z C Y M B A L K D W F V

83

CYMBAL

MURCHANG TRIANGLE PIANO

GHUNGHROO VIOLA CLAVICHORD

KARTAAL

MANDOLIN

TANPURA

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

In this image, we can see a paper with a pen on it.

<!-- image -->

- Musical String Instruments are known as Chordophones.
- Chordophones are divided into subcategories depending on how the strings are played.
- Tanpura is a drone instrument with 4 strings providing the base note.
- Non-membranous percussive instruments are known as Ghana Vadya.

## Keywords

Chordophone, Idiophone, correct posture, clean environment, hand cymbals, Non-Membranous, percussive, long-necked

84

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a person's ear.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

## Chapter 1

## What is a raag and its rule?

https://www.youtube.com/watch?v=CBtFt3HUkT0

## Time theory of raag-s

https://www.youtube.com/watch?v=RjurjBmhG6M

## Sargam geet of Raag Bhairav

https://www.youtube.com/watch?v=PbzVVrbwufo

## Chota Khayal Raag Bhairav

https://www.youtube.com/watch?v=EsWEskTh-SM https://www.youtube.com/watch?v=8jt8692FeEU

## Sargam geet of Raag Khamaj

https://www.youtube.com/watch?v=jeDaS8zeFtI

## Thematic song 'Vaishnav Jana to'

https://www.youtube.com/watch?v=xipue67yfPQ

## Raag Elaboration

## Alaap

https://www.youtube.com/watch?v=Is7GFL39OZ0

Taan https://www.youtube.com/watch?v=G6KSKcLGut8

In this image we can see a musical instrument.

<!-- image -->

86

In this image, we can see a musical instrument.

<!-- image -->

## Chapter 2

## Concept Taal

https://www.youtube.com/watch?v=g-TlqIQ17NU

## Taal Ektaal

https://www.youtube.com/watch?v=cLLhedNFZZ0

## Taal Deepchandi

https://www.youtube.com/watch?v=Utaz-inmtlQ

## Chapter 3

## Voice Culture

https://www.youtube.com/watch?v=Y26OynKfW1Q

https://www.youtube.com/watch?v=3ccGhf4Y-cw https://www.youtube.com/watch?v=pg7beTtXmW8

## Chapter 4

## Swar and Shruti

https://www.youtube.com/watch?v=OeTvUQzeg7g

## Chapter 5

## Pt. V D Paluskar

https://www.youtube.com/watch?v=1-X9pB8goLo

In this image we can see a musical instrument.

<!-- image -->

87

In this image we can see a musical instrument.

<!-- image -->

## Pt. V D Paluskar Singing

https://www.youtube.com/watch?v=MoeC0JEEt9U

## Chapter 6

## Notation system

https://www.youtube.com/watch?v=v3N8y0N874A

## Chapter 7

## Thumri

https://www.youtube.com/watch?v=CNmySJwrvOI

https://www.youtube.com/watch?v=oGKqg5\_XN5E

## Lakshangeet

## Raag Bhairav

https://www.youtube.com/watch?v=qdgGNDhcX5U

## Raag Khamaj

https://www.youtube.com/watch?v=cbFTK1jZFEw

## Tarana

https://www.youtube.com/watch?v=ZqEsW\_YR3R0&amp;list=PLhZfNWNZE6

MW04V75BDbOLYZiOt-lJHzT

https://www.youtube.com/watch?v=gMmpGMkr2Ck&amp;list=PLhZfNWNZE6

MW04V75BDbOLYZiOt-lJHzT&amp;index=2

In this image we can see a musical instrument.

<!-- image -->

88

In this image, we can see a musical instrument.

<!-- image -->

## Chapter 8

## Importance of Tanpura

https://www.youtube.com/watch?v=2QZi53ZQPVo

## Playing and parts of Tanpura

https://www.youtube.com/watch?v=\_b0ApDlnbAg

## Manjira

https://www.youtube.com/watch?v=GtQflhX35II https://www.youtube.com/watch?v=X0Y573Sdpfs

Ga Ma Pa

Sa Re GaMaPaDha Ni

88 88888885

89

In this image, we can see a musical instrument.

<!-- image -->

## Glossary

90

Aalaapinee Adhva darshak Akar alaap

Name of the 17 th shruti One who shows the path or direction Musical phrases sung with the vowel 'aa' to elaborate a raag Musical phrases used to introduce and elaborate a raag Musical exercise to train the voice Not bound by rhythm The second part of a musical composition Ascending order of notes Raag bearing the same name as its thaat Pentatonic scale, that is, using 5 notes Percussion instruments Complete cycle of a taal starting on sam and ending on sam Descending order of notes South Indian classical dance style Musical phrases sung with the lyrics of the composition to elaborate a raag Rhythmic variation with the text of the song South Indian music style Name of the 4 th shruti The pre-established movement of a raag A form of composition in the Hindustani style

Alaap

Alankaar

Anibadh

Antra

Aroha

Ashraya

Audav

Avanadh

Avartan

Avroha Bol alaap

Bharata Natyam

Bolbant

Carnatic

Cchandovati

Chalan

Chota khayal

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Dayaavati

Name of the 5 th shruti

Drut

Fast tempo

Dugun

Double speed of the basic laya

Dusri

Second accented beat

Gamaka

A melodic embellishment giving special vibratory

effects

Ghan

A category of musical instruments known as solid South Indian percussion instrument made of clay pot

Ghatam

Hindustani Jal tarang

North Indian style of music

Musical instruments using Chinese soup bowl and water ( jal )

Jati

Way of classifying raag-s using the number of notes used in aroha and avroha Rhythmic cycle having 10 beats

Jhaptaal

Kan

Grace note

Kathak

North Indian Classical dance

Khali

The unaccented beat of a taal

Khatka

While singing a note, quickly touching a higher or a lower note before landing on the main note A form of devotional song sung in lead and

Kirtan

chorus style

Komal

Flat note

Krodhaa

Name of the 9 th shruti

Kshiti

Name of the 14 th shruti

Kshovini

Name of the 22 nd shruti

91

In this image, we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

92

Kuchipudi

South Indian classical dance

Kumadati

Name of 2 nd shruti

Lakshangeet

Form of composition whose lyrics is related to the salient features of the raag to which it is set Tempo or speed

Laya

Maarjanee

Name of the 13 th shruti

Madhya

Middle tempo

Mandaa

Name of the 3 rd shruti

Mandati

Name of the 18 th shruti

Manjira

A solid musical instrument

Matra

One unit of time

Meend

A glide from a higher to a lower note

Murki

Fast and delicate ornamentation using 2 or more

notes

Naad

Sound

Nibadh

Taal bound

Nom-tom alaap

Musical phrases sung with meaningless words to

elaborate a raag

Ougraa

Name of the 21 st shruti

Pakad

Catching musical phrase of a raag

Prahar

a time segment of 3 hours

Prasaarinee

Name of the 11 th shruti

Preeti

Name of the 12 th shruti

Purvang

Lower tetrachord

Raag

Melodic structure guided by rules

Raktaa

Name of the 15 th shruti

Raktika

Name of the 7 th shruti

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Ramyaa

Name of the 20 th shruti

Ranjani

Name of the 6 th shruti

Rawdri

Name of the 8 th shruti

Rohinee

Name of the 19 th shruti

Sadhana

Rigorous musical practice

Sam

The first accented beat of a taal

Sampoorna

Using all 7 notes

Samvadi

Second most important note of a raag

Sandeepani

Name of 16 th shruti

Sandhi-Prakash

Twilight period, dawn and dusk

Sargam alaap

Raag elaboration using musical notes

Sargam geet

Form of composition with music notes

Shadav

Scale using 6 notes ( Hexatonic scale)

Shadaj

Full name of the note Sa

Shru

To hear

Shruti

Microtones

Shudh

Natural or pure note

Sthayi

First part of a composition

Sushir

Wind Instrument (Aerophones)

Swar

Musical note

Taan

Singing group of notes in fast tempo

Tali

Clap

Tanpura

Musical instrument giving base note

Tarana

Form of composition with meaningless lyrics

Tat

Stringed Instruments (Chordophones)

Thaah Thata

Basic speed/tempo

Parental scale under which raag-s are classified

93

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

Theka

Syllables of the tabla

Thumri

Form of composition associated to kathak dance

Tillana

South Indian musical form like tarana

Tisri

Third accented beat

Tivraa

Name of the 1 st shruti

Uttarang

Upper tetrachord

Vaarjika

Name of the 10 th shruti

Vadi

Most important note of a raag

Vadya

Musical instrument

Vibhag

Division of a taal

Vikrit

Variant

Vilambit

Slow tempo

Vistaar

Detailed elaboration of a raag

Vivadi

Foreign note to enhance beauty of a raag

94

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->