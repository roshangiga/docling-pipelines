SOCIAL

0

Beofoa

Suggested answers post Workshop Feb 2020

MODERN

<!-- image -->

PLEASE NOTE:   ANSWERS ARE NOT LIMITED TO WHAT HAS BEEN PROVIDED IN THIS DOCUMENT. THEY ARE RATHER SUGGESTED ANSWERS PROVIDED FOLLOWING DISCUSSIONS DURING THE WORKSHOP. YOU MAY ALSO NOTE THAT AS SOCIAL STUDIES EDUCATORS, YOU MUST CONSIDER A RANGE OF ANSWERS RELEVANT TO THE TOPICS.

<!-- image -->

UNIT  1

<!-- image -->

- 1.
- (a) independent (b) prime minister (c) republic (d) democratic, vote
- (e) autonomy
2. (a)   Constitution is a set of basic laws or principles for a country that describes the rights and duties of its citizens and the way in which it is governed.
- (b)   Government is a group of people that governs a country. It sets and administers public policy and exercises power through institutions and laws within a state.
- (c)   Democracy is a form of government which is considered to be 'of the people, by the people, for the people'.
- (d)   Sovereignty is the supreme power of a state to govern over its territory, have its own constitution, elect its own representatives, make its own laws and take its own decisions without any interference from outside sources.
- (e)   Autonomy is the state of being self-governing especially the right of self-government.

<!-- image -->

- 1.
- (i) January (ii) February
2. Carol.
- Because it passed directly over Mauritius.
- Because it has the highest gusts (256 km/hr)

Because after the passage of cyclone Alix, the country did not have sufficient time to recover from the damages.

<!-- image -->

- (a) Malaria
- (b) It is spread by the bite of infected mosquitoes (anopheles females)
- (c)
- (i) 1179 (ii) 12
- (d) Government measures such as:

Extensive environmental sanitation work (Elimination of mosquito breeding grounds) Spraying campaign of all houses with DDT.

<!-- image -->

- (a) 1968
- (b) Professor James Edward Meade
- (c) It is described as a small island dependent on agriculture with strictly limited area of land and existing population pressure on it.
- (d) A rapid reduction of the death rate due to better health care, medication and vaccination coupled with an increase in birth rate.
- (e) More proper houses would be needed. (Housing problems) There may be a high rate of unemployment.
- Limited resources may affect the living conditions of the people.
- 3.
- Cyclones cause damage to infrastructure such as roads, street lighting, buildings etc.. Cyclones may cause loss of lives. Cyclones cause floods that may damage houses and property. Cyclones damage agricultural fields like sugarcane and vegetables. Heavy rainfalls during cyclones cause soil erosion and waves cause coastal erosion.
4. Gervaise (1975), Claudette (1979).

<!-- image -->

<!-- image -->

1. (a) The export of sugar.
2. (b)   It was used for development works such as construction of roads, public buildings, reservoirs schools and hospitals.
1. Because there were very few industries. Goods commonly used by the people were not produced locally.
2. Agricultural machinery, transport equipment, medicines, tobacco, rice, flour, oil
1. It means to set up industries that would manufacture goods locally to reduce imports and increase self-sufficiency.
2. Professor James Edward Meade
3. (a)   Mauritius Breweries Ltd, Micro Jewels Ltd, Soap and Allied Ltd, Food and Allied Industries, Margarine Industries Ltd, Mauritius Oil Refineries
8. (b)   Mauritius Breweries Ltd - soft drinks and other breweries Micro Jewels Ltd - watch jewel components Soap and Allied Ltd -
2.   Fluctuation of prices in the world market.

<!-- image -->

<!-- image -->

Rising wages of workers.

Unfavourable climatic conditions.

3. Yes.
2. The country was over dependent on only one crop for export and as income.

Since there was no diversification, when sugarcane plantations were hit by cyclones, droughts or pests, it would seriously affect the economy.

Since there were no industries to produce goods, majority of our goods had to be imported.

- Food and Allied Industries Margarine Industries Ltd Mauritius Oil Refineries -
4. Unemployment rate did not reduce. Self-sufficiency did not increase satisfactorily. Imports was not reduced satisfactorily.

<!-- image -->

<!-- image -->

## ACTIVITY 2.4

1. Export Processing Zone - A zone identified by the government to attract investment from industrialists to produce goods mainly for export purposes like Plaine Lauzun and Coromandel in Mauritius. (elaborate and explain)
2. The main objective is to manufacture goods for export purposes. To obtain foreign currencies.
3. Textile industry

<!-- image -->

## ACTIVITY 2.5

1. Primary sector
2. Tertiary sector
3. The rapid expansion of the tourism, financial &amp; banking services increased employment and income from industries in the tertiary sector.

<!-- image -->

## ACTIVITY 3.1

1. They are protesting because they want to return to settle in their home place (Chagos Archipelago).
2. It ruled that the excision of the Chagos Archipelago from Mauritius in 1965 prior to independence was unlawful.
4. (b)   Labour - Plenty of literate and cheap labour meant more profits for investors
4. Tax Exemptions - no taxes on a variety of items helped investors maximise their profits.

<!-- image -->

(Students can pick any other advantages from the list provided on page 22)

The level of education rose and people preferred to work in tertiary sectors thus increasing the output in that sector and reducing GDP in other sectors.

3. 116 to 6
4. It states that the Chagos Archipelago forms an integral part of the territory of Republic of Mauritius and set a 6 months deadline for the United Kingdom to withdraw from the Archipelago.

<!-- image -->

In this image, we can see a group of people. We can also see some text.

<!-- image -->

<!-- image -->

<!-- image -->

UNIT  2

<!-- image -->

1. Free education, Low cost Housing, Free health care, Social Security
2. To all Mauritians
5. It could lead to an unhealthy population since the medical costs are high.
3. They are important so that the population at large can be healthy, educated, live in decent homes so that they can be more economically productive.
4. The State (government)
1. Seeks to remove poverty, hunger and unemployment to bridge the gap between the rich and the poor.
7. Gives equal importance to the liberty of the individual and the interests of the society.
8. Functions through democratic institutions in a democratic way. Gives equal rights to all, irrespective of their differences, does not discriminate and treats all equally.

<!-- image -->

Seeks to provide welfare to people through planned programmes.

- People with low income could find it difficult to afford decent houses. Elderly people could find it difficult to afford amenities as cost of living rises.
- No provision of free education could lead to the population being less qualified academically.
6. Sensitization campaigns against social ills like smoking, drugs and alcoholism.
- Encourage the population to do physical activities to keep in good health.

It means to try to decrease the income disparity between the lowest earners and highest earners, make sure that free quality services are provided to everyone at par with paid services and making sure that everyone is provided with the same opportunities.

<!-- image -->