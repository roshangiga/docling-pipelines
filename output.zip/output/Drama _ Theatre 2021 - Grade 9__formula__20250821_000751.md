## DRAMA &amp; THEATRE

GRADE 9

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of Ministry of Education, Tertiary Education, Science and Technology

Based on the National Curriculum Framework: Grades 7,8 &amp; 9 (2017) - Nine-Year Continuous Basic Education

In this image we can see a person standing on the water. In the background there is the sun and the sky.

<!-- image -->

Professor Vassen Naëck

- -Head Curriculum Implementation,Textbook Development and Evaluation

## DRAMA &amp; THEATRE PANEL

Nuckiren Pyeneeandee

- Coordinator, Lecturer, MIE

Per Skjöldebrand

- Panel coordinator

Zainab Soyfoo

- Panel member

Nazra Bibi Emamdee

- Panel member

## Proof reading: Bibi Kratijah Khodabux

<!-- image -->

Design

Kunal Sumbhoo

- Graphic Designer, MIE

© Mauritius Institute of Education (2021) ISBN: 978-99949-53-88-2

Consent from copyright owners has been sought. However, we extend our apologies to those we might have overlooked. All materials should be used strictly for educational purposes.

## Foreword

With  the  Grade  9  textbooks,  we  now  complete  textbook  production  for  Grades  1-9  in  the  context  of the  Nine  Year  Continuous  Basic  Education  (NYCBE) project of the Ministry of Education and Human Resources, Tertiary Education and Scientific Research. The textbooks are designed in line with the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and continuous improvement of the learners' cognitive skills using contextualised materials which should be highly appealing to the learners.

The  writing  of  the  textbooks  involved  several  key  contributors,  namely  academics  from  the  MIE  and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head, Curriculum Implementation and Textbook Development and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the   NCF, while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic artists who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

## Preface

I know a lecturer and author who wakes up every morning saying 'Lights, camera, action!' Through this ritual, he activates the image that he is on a stage and that his actions are needed to make things happen.

Not every one of us is ready to picture ourselves as the main character on a stage, throughout the whole day. We prefer to see ourselves as standing backstage or in the wings supporting others. We may feel the risk of always having the spotlight directed on us and our actions. 'Everyone will reveal my shortcomings or mistakes!'

We can even, at times, choose to take a passive role of the audience and relax while watching others act.

This last book in Drama &amp; Theatre focuses much more on the process of staging than the previous two books. Staging includes other functions than actors; scriptwriter, director, set designer, costume designer, technicians and the active audience.

Those functions are all necessary to create a performance in theatre, where the final result is a result of a collective, collaborative, process. During the creating process we can have many different functions or roles and we learn the benefit of changing perspectives.

This process can also teach us something about life in a dynamic society.

And in real life, from your point of view, you are always in the spotlight.

To quote the author Timothy Kurek in his book The Cross in the Closet :

'You are the main character in the story of your life, but other people are the main characters of their own lives. And sometimes you can find healing just by playing a supporting role in someone else's experience. '

Per Skjöldebrand Panel coordinator Drama and Theatre

## Table of content

| 1. Introduction                        | 1. Introduction                                               | 1   | 4.6       | Lines                                                                  | 18    |
|----------------------------------------|---------------------------------------------------------------|-----|-----------|------------------------------------------------------------------------|-------|
| 1.1                                    | Drama as grooming for life                                    | 2   | 4.7       | No Language barrier                                                    | 20    |
| 2 . Focus areas                        | 2 . Focus areas                                               | 4   | 4.8       | Analysing a script and reaching new levels                             | 21    |
| 2.1                                    | Creating                                                      | 5   | 4.9       | To collect inspiration and                                             | 23    |
| 2.2                                    | Arts & Society                                                | 6   |           | information                                                            |       |
| 2.3                                    | Performing                                                    | 7   | 4.10      | An investigating approach creates                                      | 24    |
| 2.4                                    | Responding                                                    | 7   |           | organic results                                                        |       |
| 3. From page to stage                  | 3. From page to stage                                         | 8   | 4.11 4.12 | Theatre conventions vs. film andTV The conflicts make the cyclone spin | 25 27 |
| 4. Guidance for the process in Grade 9 | 4. Guidance for the process in Grade 9                        | 12  | 4.13      | Actantial model                                                        | 28    |
|                                        |                                                               |     | 4.14      | Interactive drama                                                      | 29    |
| 4.1                                    | Howdowework in groups?                                        | 12  | 4.15      | Obstacles not comfort                                                  | 30    |
| 4.2                                    | Group process by keeping the same members during a production | 15  | 4.16      | Two expressions                                                        | 31    |
| 4.3                                    | What is a theme?                                              | 17  | 4.17 4.18 | The director's function What makes the play convincing?                | 33 35 |
| 4.4                                    | Space management                                              | 17  | 4.19      | Positions on stage - the 9 point                                       | 37    |
| 4.5                                    | Length of scripts                                             | 18  |           | exercise                                                               |       |

- 4.20 What is Gestus?
- 4.21 Why shoes must come first
- 4.22 Costume Designer
- 4.23 Private or in character
- 4.24 Two different Black outs
- 4.25 Rational and irrational
- 4.26 Rehearsal techniques
- 4.27 What is a 'run-through'?
- 4.28 A performance
- 4.29 Constructive criticism
- 4.30 Outline of activities

## 5. Suggested activities Grade 9

What did we learn?

## 5.1 Scripting the theme

Life experiences from a theme Introduction to tableau and statue Sculpting tableaus Freeze game with a topic

- 37 Prepared improvisation

- 38 Freeze game without words and without a set topic

- 39 Physicalise your character

- 40 Physicalisation

- 41 Elements in a story

- 42 Script writing

- 43 What is a social issue?

- 44 Up for a twist

- 45 Interactive drama

47

48

Worldview

- 5.2

## The swapping of scripts 60

51

52

Analysing a script in a social and cultural context

10 line story x 2 Adjusting the script Allocate functions

- 5.3 Investigating and rehearsing

Inspiring sources

The actantial model

63

The maximum will

Flashback - flash-forward

Identify the will

Situation improvisation - focus on the actor

Identify the conflict

Emotions

The 9 points

Eye contact 1

Eye contact 2

Observe - Validate - React

Collect and recreate role material

Lines and memory

## 5.4

## By heart 78

Letting go of the manuscript

Relation improvisation - to create memories in the

character

Fast and slow

The unexpected guest

Freeze!

Shifting roles

Restart please!

Silent rehearsal

Relaxed rehearsal

Technical rehearsal

Preparatory dress rehearsal

Dress rehearsal

5.5 Performance and analysis

84

Performance analyses

Constructive critique

Checklist

Quality assurance

Love bombing

## Appendix

93

A. Specific learning outcomes in Drama &amp; Theatre   94

Grade 7 - 9

B. Templates for constructive remarks (performance and process)

96

<!-- image -->

This handbook  is build upon  the concepts introduced  in  Drama  and  Theatre  textbooks Grade  7  and  8  to  fulfill  the  NCF's  vision  of promoting a holistic approach to the education system.  While the former textbooks are an introductory part to drama exercises and concepts,  this  last  book  of  the  series  is  more focused towards a systematic process that leads to a final performance. It provides students and teachers  with  opportunities  to  collaboratively examine human experiences through situations to connect with others, to experience tensions, to resolve conflict and to create meanings in their world.

'Theatre  is  a  form  of  knowledge;  it  should  and can  also  be  a  means  of  transforming  society. Theatre can help us build our future, instead of just waiting for it.'

- Augusto Boal, Games for Actors and Non-Actors

The  aim  of  Drama  and  Theatre  is  not  only  the retelling of stories in actions, but to communicate ideas of human dealings, feelings and experiences by using expressive skills in Performing Arts.

Based  on  the  expected  learning  outcomes  of the NCF, the textbook is a guide for students to confidently  perform  and  present  to  a  general audience.  In  the  process,  they  participate  in  a range  of  activities  based  on  their  personal  and social  contexts.  The  different  forms  of  cultural expressions  allow  students  to  challenge  their beliefs, perceptions and socially constructed realities.  By  engaging  in  autonomous  roles  as well as in group work, students are empowered through the responsibilities given to them. Thus, they are made to feel valued.

## 1.1 Drama as grooming for life

Drama and Theatre  provides  students  with  the opportunity  to  engage  their  mind,  body  and emotions  into  a  collaborative  expression  of  all that it means to be human. By discovering their own voice, they grow in confidence and develop empathy.  They  deepen  their  understanding  of human behavior, culture and diversity.

## 1. Promotes perseverance and resilience

Through  Drama,  students  develop  their  ability to  turn  barriers  into  opportunities,  overcome difficulties in completing complex tasks. One key quality gained is resilience, that is the ability to adjust and bounce back when things do not go as planned. In other words, they do not stagger or dwell on failures. Acknowledge the situations, learn from previous mistakes and move forward.

## 2. Facilitates cross-cultural understanding

Drama  does  not  contribute  to  the  superficial knowledge  about cultures through different festivals  that  are  celebrated,  but  it  gears  more towards creating a cultural awareness to promote social tolerance and  social behaviors. By so doing, we are not only encouraging our students to  discover  new  perspectives  but  we  are  also preparing  them  for  an  increasingly  global  and diverse world.

## 3. Builds community and supports civic engagement

Drama and Theatre fosters a sense of community by going  beyond  the  restrictive concept  of making reference to specific religious belonging or  social  cultural  organization.  It  is  an  attempt to develop the idea that through unity, a sense of belonging can be developed. Different perspectives  enhancing  the  personal,  artistic, civic,  and social development would contribute

to  a  reflection  of  a  healthy  society.  Therefore, Drama and Theatre vehicle effective changes in the immediate surroundings.

## 4. Fostering team spirit and collaboration

Being  a  team  player  in  a  Drama  and  Theatre class also allows students to accept navigating in different roles such as a cheerleader, a follower, a  supporter  and  a  leader.  In  so  doing,  they develop the ability to work with diverse people in a variety of circumstances. It also equips them with the ability to cope with unwanted situations which do not always work in their favour in the professional and personal spheres.

The  school  of  the  future  will,  perhaps,  not  be a  school  as  we  understand  it-with  benches, blackboards, and a teacher's platform-it may be a theatre, a library, a museum, or a conversation.

## -Leo Tolstoy

The  holistic  nature  of  learning  which  would contribute into the making of an active citizen can be enhanced by using drama as a pedagogical tool  is  an  existing  strategy.  However,  Drama  as a subject is just an emerging subject area in the Mauritian context. To make it a success, teachers' attitudes  will  contribute  in  shaping  responses towards  it.  Consequently,  teachers  could  also focus on promoting the different skills embedded in Drama and Theatre.

2.

Focus Areas

The  textbook  for  Grade  8  was  built  on  the foundation put forward in the book for Grade 7. Thus,  the  textbook  of  Grade  9  will  be  founded on  both  previous  texts.  It  intends  at  further developing and refining skills needed during the process leading to a performance and during the performance per se. Grade 9 focuses at preparing the students to perform at the level of the school or the community as an end product.

The  specific  learning  outcomes  for  Grade  9  as described in the National Curriculum Framework Nine-Year Continuous Basic Education are builtup again on four main focus areas:

## CREATING

At the end of Grade 9 learners should be able to:

A.  Improvise  dramatic  stories  from  a  variety  of situations especially life experiences.

- B. Use a variety of performance styles including tableau, mime and script based.

## ARTS &amp; SOCIETY

At the end of Grade 9 learners should be able to:

- A. Use problem-solving skills in groups to dramatise a story with social significance.
- B.  Relate  Drama  and  stories  to  the  wider  social and cultural contexts.

## PERFORMING

At the end of Grade 9 learners should be able to:

- A.  Dramatise  and  perform  stories  from  fiction, literature  or  life  experiences  in  groups  using theatre conventions.
- B.  Express  emotions  in  a  convincing  manner during performance.
- C. Use body movement, expression and voice to enhance meaning.

## RESPONDING

At the end of Grade 9 learners should be able to:

A. Observe, analyse and discuss character traits

- B.  Evaluate  a  performance  using  vocabulary pertaining to drama

## 2.1 Creating

To be creative is to turn the invisible into something  visible.  The  students  will  artistically shed light  on  the  hidden  aspects  of  the  society. Performing  Arts  allows  students  to creatively communicate  expressions  in  new  ways.  It  is  no longer  a  mundane  presentation  whereby  the students  solely  rely  on  a  laptop  and  a  projector as support to deliver information on any societal topic.  Performing  Arts  take  the  students  for  a holistic  tour  through  the  varying  ways  in  which they  can  express  themselves.  For  instance,  they can  express  themselves  in  the  form  of  theatre, tableaus, interactive drama, miming and so much more.

In  Grade  8,  the  students  were  accustomed  to stories  created  by  others,  this  time  the  process will  start  with  self-experienced  stories  to  end with performances. Creating will involve the development of both instant and prepared improvisations pertaining to more relatable plots  and  characters.  Students  will  investigate

themes related to their own lived experiences. In groups, they should be able to represent thematic tableaus associated to their life experiences. They will  have  the  freedom  to  experiment  with  their performing  styles.  Students  will  also  learn  to create their own scripts while basing themselves on  their  improvisations.  All  students  will  have  a random  task  or  role  throughout  (set  designer, actor, costume maker, prop designer….) to ensure that nobody is left out.

## 2.2 Arts and society

Drama  and  Theatre  invites  us  to  see  and  hear other  perspectives  that  can  change  our  own point  of  view.  It  can  even  bring  up  unpleasant and taboo topics that are often left in the realm of  the  unknown.  Through  Drama  and  Theatre, the students will now aim at making the 'society speak' .  They  will  socialise  amongst  themselves and work as an ensemble to dramatise a story to make  it  socially  significant.  Drama  and  Theatre will  act  as  the  bridge  that  will  connect  the personal  and  private  experiences  of  a  student to  more  universal  ones.  Students  will  benefit from  varying  opinions  on  the  societal  topics which they will propose and this may iterate and ultimately broaden their own perspectives about the society. Besides, they will be endowed with more tolerance by learning to accept the changes others make to their plots or themes.  This will open  up  their  understanding  on  how  some themes are culturally and socially broader than how they imagined it. They may see the similarity between the structures of a micro society to that of  a  macro  one. Through  the  process  of  group work,  they  will  learn  to  develop  their  sense  of empathy  to  come  to  an  agreement.  Students at  this  level  will  also  take  their  performance  to a  larger  social  and  cultural  scale.  Not  only  will the themes in their performance be socially and culturally accessible, but also their audience this time will  not  be  limited  to  the  classroom. They will  have  a  more  significant  audience  at  the level of the school or the community. The whole process  to  the  final  product  will  be  artistically meaningful.

## 2.3 Performing

A performance is different from a presentation as it is done in front of an invited audience that will watch the play for the first time. In the framework of  this  book 'presenting' is done only during the process of learning and/or rehearsing.

Students at this stage should be able to comfortably relate their lived experiences to existing popular or classical fiction and literature. They  will  do  so  by  observing  the  motivation of  existing  characters  towards  their  goals  and their  manifestations  and  manipulations  when in  confrontation  with  an  obstacle.  They  should be  able  to  observe  the  varying  patterns  in  the emotions  and  behaviours  of  the  characters  in different situations and be able to act accordingly in a most natural fashion in their rehearsals. Students should be able to adapt their performance to make it seem more real and acceptable to the audience.

## 2.4 Responding

As per the National Curriculum Framework (NCF),  it  is  important  to  note  that  a  three-fold relationship  needs  to  be  fostered  in  Drama  and Theatre:  the  artist-audience  relationship,  artistartist  (interpersonal  relationship)  and  the  artist and  himself/herself  (intrapersonal  relationship). To  be  able  to  do  so,  students  should  be  trained to make and receive constructive criticisms while  using  specific  vocabularies  pertaining  to Performing Arts. Through active evaluations, students will  need  to  improve  their  final  results. The  focus  is  divided  into  feedback  concerning both the characters and the whole performance. The  feedback  serves  two  purposes:  Firstly,  you learn  from  others  so  that  you  can  develop  your own  artistic  ability  and  secondly,  you  support development of others when you verbalize your  critique.  Responding  is  not  only  related  to performances, it is the most important part of the development process, during improvisations and rehearsals as well.

In this image, we can see a text.

<!-- image -->

In this chapter, we let you have an overview of all the learning outcomes connected to the specific activity areas that  cover  the  subject  Drama and theatre  in  Grade  9. To  formulate  these  has been  the  first  core  task  for  the  textbook  panel and  during  the  process,  the  panel  started  to work out the Guidance section in the following chapter alongside with the activities in the last chapter. From Page to Stage ensures the smooth running  of  the  whole  requirements  of  Drama and Theatre throughout Grade 9, by forming and highlighting its foundation and the panel hopes that all queries and concerns have been thereby addressed accordingly.

## CREATING

A. Improvise dramatic stories from a variety of situations especially life experiences

The students must have learned how to:

1. Make  use  of  both  instant  and  prepared improvisations
2. Individually recall life experiences pertaining to specific given (or relatable) themes
3. From a theme, prepare and present different situations  with  a  beginning,  middle  and ending

## B. Use a variety of performance styles including tableau, mime and script based

The students must have learned how to:

1. Sculpt individual thematic tableaus with group members, based on life experiences
2. Investigate  how  a  situation  can  change  if the  group  removes  the  spoken  words  and focuses on physical expressions
3. In groups, prepare a script from one prepared improvisation

## ARTS &amp; SOCIETY

## A. Use problem-solving skills in groups to dramatise a story with social significance

The students must have learned how to:

1. In  groups  dramatise  a  difficult  improvised social situation which does not seem to have any solution
2. Present the situation to the rest of the class and invite them to express their solutions.

## B. Relate drama and stories to the wider social and cultural contexts

The students must have learned how to:

1. Define social and cultural contexts and relate to them
2. Analyse  a  script  created  by  another  group and  relate  the  story  to  a  wider  social  and cultural context
3. Freely change, remove, merge or add characters,  setting  or  time  to  transform  the individual and specific perspective to a more social and general one.
4. Re-adapt the script in a written form

## PERFORMING

## A. Dramatise and perform stories from fiction, literature or life experiences in groups using theatre conventions.

## The students must have learned how to:

1. Relate their personal experiences, shown in their  dramatisations,  to  existing  popular  or classical fiction and literature
2. Identify a range of sources to find inspiration for stories and characterisations

## B. Express emotions in a convincing manner during performance.

The students must have learned how to:

1. Locate and define the motivation and the will of the character(s) towards their objectives
2. Identify the obstacles faced by the characters and the different techniques used to confront those
3. Compare the obstacle they face in their own life  experiences  to  that  of  characters'  in  a story and identify how they similarly need to come up with actions to reach their goal
4. Recognise  that  emotions  correlate  to  will, motivation and obstacles
5. Point out the different techniques making the actions of the whole ensemble convincing

## C. Use body movements, expressions and voice to enhance meaning.

The students must have learned how to:

1. Use different rehearsal techniques

2. Collect and reproduce a palette of movements,  tics, expressions and voices inspired from people in the real world
3. Show awareness about the different usages of eye contact
4. Compose different levels of tempo, tones of voice and positions on the stage

## RESPONDING

## A. Critique a performance using vocabulary pertaining to drama

The students must have learned how to:

1. Interpret the factors contributing to the whole  development  of  the  performance, including:  actions,  turning  points,  changes in  status  and  tempo,  the  space,  set  design, costumes, sounds and music, light.
2. Value the importance of receiving constructive critical remarks on a performance and accepting those to improve it.
3. Discuss their own point of views from notes they have written down using theatre terms in their analysis.
4. Contrast  the  conventions  of  movies  and  TVseries to that of theater.
5. Evaluate their performances  and  others' for quality  assurance,  both  regarding  the  process and the final result.

## B. Observe, analyze and discuss character traits

The students must have learned how to:

1. Identify the individualities of a character: movements,  tics,  voice,  ways  of  interaction  with others,  tempo,  status,  age  and  gender  projection, profession, jargon and language

<!-- image -->

## Guidance for the process in Grade 9

This chapter is meant to build a stable foundation before  reading  and  executing  the  activities  in the  next  chapter.  It  is  basically  giving  answers and  explanations  to  many  of  the  secrets  that generate quality in the whole process of creating a performance.

## 4.1 How do we work in groups?

To  ensure  that  a  fair  group  development  takes place, group members should be aware of how to proceed at different stages.

## •    Random formation of a group

The teacher should make sure that students are having the experience of working with different classmates throughout the year. There are different ways through which the teacher could randomly separate students into groups.

- -Alphabetical  order:  From  the  class  list, the teacher regroups students following the alphabetical sequence, each group may have 5 members, for e.g., AAABB and BBCDDE and so on.

The short articles are following the same timeline as  the  activities,  starting  with  group  dynamics and ending with 'run-through rehearsals' and the special circumstances around a performance.

The final part of this chapter will address the role of the teacher as a guide to students who are in the process of independently creating.

- -The  teacher  chooses  the  leaders  and decides  on  the  number  of  students  each group  will  comprise  of.  Write  the  names of  the  rest  of  the  class  on  separate  chits  of papers. Leaders are then asked to pick the set number of chits of paper.
- -Students  form  a  circle.  In  a  clockwise direction, each of them counts in ascending order,  up  to  5  (for  e.g.,  1,  2,  3,  4,  5,  1,  2,  3, 4,  5…).  At  the  end,  all  students  who  said number 1 form a group, all number 2 forms another group and so on.
- -By carefully observing the group dynamics and the behavior of students towards their classmates, the teacher should occasionally  prepare  the  list  of  group,  by placing  students  who  have  never  worked together  in  the  same  group  and  students who do not get along in different groups.

## •    Choosing a leader

Once the group is formed, a leader is chosen for each  group.  The  teacher  should  ensure  that  it is  not  always  the  same  people  who are chosen as group leaders. The leader should be made to understand that the work should be delegated to  the  group  including  himself  or  herself.  It is  not  mandatory  that  the  leaders  obtain  the main roles in a presentation, but rather to work collaboratively  with  each  member  in  order  to make the presentation a success.

## •    Each opinion matters

As the assignment is given and group members get together to work, each group member should voice their point. One way of achieving this is by asking each group to form a circle and the leader would  go  around  asking  each  of  the  members their  views.  There  should  not  be  any  pressure from the leader, but, more of an encouragement echoing welcomed participation through simple questions like 'is  there  anything  anyone  of  you would like to add?'

## •    Respect

No perspective should be ignored. The teacher should ensure support to any student deliberately left out during the discussion process. Everyone can be assigned a role, depending on his or her abilities.  Care  should  be  taken  not  to  let  the dominant  voices  of  the  class  overpower  those who  have  diverging viewpoints or are shy. Students should not be allowed to belittle other members on their contribution to the group.

## •   Teamwork

The  group  should  cooperate  to  present  their work in a cohesive manner. Each student should be fully aware of each member's contribution to the  assignment.  In  so  doing,  the  performance/ presentation will not look fragmented and if any of the team members is absent, anyone should be able to take over.

In this image we can see an animal on the branch of a tree.

<!-- image -->

## 4.2 Group process by keeping the same members during a production

The tasks in this textbook will deal with the same group  of  students  across  the  focus  areas.  It  is understandable  that  such  type  of  group  work might  be  tedious  and  conflicting  for  some.  In order  to  make  the  process  more  effective,  the following tips might be helpful:

## •    Structuring the group

The teacher should always structure the group. Groups should be made diverse by distributing students  according  to  their  different  abilities, gender  and  ethnic  background.  If  there  are visible  clashes  among  students,  avoid  putting them in the same groups, as it will only fuel more conflicts.

## •   Coach the group

The  teacher  should  constantly  move  around the class to monitor that each group is making significant progress.

The  teacher  will  probably  develop  a  picture  of how  the  performance  could  be  and  will  want the best rendition so as to impress members of the  school.  Maybe  an  impulse  to  interfere  will arise.  Note  that  at  this  point,  it  must  primarily be  the  director's/leader's  and  the  group's  task. The teacher can invite the director to come and discuss and that will give value to their status and role. Evaluate using the 'sandwich approach' will get them to take over from there.

## •    The Sandwich Approach

Throughout  this academic  year, the teacher will  observe many positive attributes as well as negative aspects in each student's performance. It is important to provide students with

constructive feedback to bring improvement in the ways in which they are delivering their tasks. Students can be quite vulnerable at this age and the way in which adults bring out and confront the negative remarks can be rather complex.

'Responding'  in  itself,  is  a  very  important  stage in Drama and Theatre. Even students will have  to  evaluate  their  friends'  performance  or presentation.

The teacher will have to guide them in responding with  a  gentle  approach  and  the  best  way  to teach them to do it is by using and adopting the 'sandwich approach' .

In this image we can see a sandwich.

<!-- image -->

- a) First slice of Bread: Start off with positive feedback (authentic praise of something they just created)
- b) The 'Meat  of  the  Matter':  Provide  your constructive criticism
- c) The  second  Slice  of  Bread:  End  on  a positive note

## •    Group identity

The groups should form a strong sense of unity by  choosing  a  name.  Group  members  should motivate each other instead of creating troubling situations.

## •    Tracking the contribution

The  leader  should  keep  track  of  each  of  the member's  participation  by  regularly  touching base  with  different  group  members  about  the decisions taken to reach the final assignment.

## 4.3 Space Management

In this image we can see a person sitting on the floor. In the background there is a wall.

<!-- image -->

In  'Drama  and  Theatre' there  is  a  common challenge of space management in the classroom.    Students  will  be  mostly  working out  in  groups,  at  this  stage,  and  they  will  be rehearsing for a performance. Not everyone will be  able  to  have  a  big  space  while  bearing  the nine points, to circulate accordingly. Even if they manage to circulate with their body, sometimes they  may  encounter  trouble  as  voices  will  be interfering and creating a frenzied crescendo in the  classroom.  Students  should  be  allowed  to leave the classroom and to use other appropriate spaces at school, the gymnasium for example.

The  teacher  must  however  be  able  to  keep  an eye on the students and visit them all during the duration of the class.

## 4.4 What is a theme?

A theme  is a series of observations, ideas and  issues  about  a  particular  subject.  Typical examples of subjects are love, friendship, balance, confidence, money and humour.

Themes emerge when there is a conflict within the subject. It could be betrayal in a love relationship, greed of power, solitude in a technologydriven  world,  happiness  and  poverty,  fear  of commitment,  desire  and  lies,  nasty  childhood, survival, peaceful death, compliance and control, identity crisis…

## 4.5 Length of Scripts

A  group  is  encouraged  to  adapt  its  play  to  the duration  of  about  10  minutes  or  even  lesser, including the time to set up the stage. The length of the script is going to be based on many factors influencing the actual play. It may depend on the tempo of the actions  and  the  dialogues  or  the length of the dialogues. Students are encouraged to keep their performance at a reasonable length and not to exaggerate it. A lengthy performance does not necessarily mean an outstanding performance. The quality of the act matters more than the quantity or the lengthy duration of it in this context. The script is alive and students surely are allowed to adapt it in case they have forgotten a  line  or  two.  They  may  do  so  by  empathising with  the  character  they  are  personifying  and improvising a suitable and adapted dialogue on spot. However, they should not keep on editing the written script in hope to improve it again and again; they can easily ruin it by adding too much and  going  overboard.  They  should  leave  out unnecessary details without underestimating the audience. A sense of mystery should be left out to keep their curiosity on. During the rehearsal, it  will  be  discovered  if  the  length  of  the  script adapts to the duration/timeframe. Actions on the stage may be further developed or added while leaving  untouched  the  dialogues  themselves. For instance, the standing actor can go to have a seat or pour himself/herself a cup of tea if there is nothing to be said. The performance should not only be verbal, it should also focus on actions.

## 4.6 Lines

A  line  is  part  of  the  script  and  is  referred  to  as what the characters are saying.

Here we need to point out three things:

## •    Counting lines

Each of the characters contributes to the ensemble.

In this image we can see a paper with some text on it.

<!-- image -->

Students  might  have  the  impression  that  the one with the most number of lines is of greater importance and hence feel 'superior' to be assigned  this  role.  If  students  think  that 'I  have only a few lines. I don't matter' , their performances will also reflect the state of mind.

On the  contrary,  a  character  who  barely  says  a word  may  be  more  challenging  to  enact.  The teacher should probably be more attentive to  those  who  have  fewer  lines  so  that  their movements are on point.

One example is in  the  Becket  play 'Waiting  for Godot', the character Lucky talks only at the end of  the  play  and  yet,  he  remains  a  remarkable character.

## •    Reducing - not adding lines

When  a  group  is  presenting  their  play  to  the class,  long  before  the  performance,  they  will have constructive comments about unclear

relations and setting. A rather common mistake is that they will want to add more lines to explain. The opposite is usually better: removing lines will refine the text. It will also encourage the actors to  clarify  relations  and  setting  through  their interactions and approaches.

## •    Acting is reacting

Based  on  Sanford  Meisner's  (1987)  concept  of Pinch  and  Ouch,  actors  need  to  be  responsive to each other. They should literally listen to their partners and not just wait to deliver lines. Actors do not turn on and off on stage but their actions happen in relation to someone or something. The audience  will  definitely  feel  the  inauthenticity of the performers if the engagements are done in  a  robotic  and  technical manner. Many of the rehearsing  techniques  later  in  this  chapter  will help the students to understand the meaning of 'Acting is reacting' .

## 4.7 No Language Barrier

Performing in an incomprehensible language is not necessarily doable. To force a student to do so can be an illogical move that will block them. It is certain that the usage of English and French languages is most valued, however, the medium that will be used in the scripts of students should be  one  of  their  own  choices  and  not  anyone else's. Just remember that the choice of language is  closely  connected  to  the  character.  There could even be a benefit in using multi-language techniques in the performance.

In this image we can see a few pictures of text on the paper.

<!-- image -->

If the students can communicate in other languages comfortably, then performing in those  languages  may  benefit  their  language acquisition of the same.

## 4.8 Analysing a script and reaching new levels

Many  of  you  are  familiar  to  computer  games. Then you might also know how important it is to level up. Your idea is to find new knowledge and new tools in order to be able to continue to the next challenge, the new level.

The same can be applied when we meet a text for  the  first  time.  However,  if  we  do  not  have the tools to level up, the text will remain closed and we cannot get any further. This is a normal approach because our brain wants to understand the whole picture as soon as it can and we have no idea how to change it.

This  is  a  part  of  the  lyrics  from  the  song  Hotel California:

'There she stood in the doorway;

I heard the mission bell

And I was thinking to myself

'This could be heaven or this could be Hell'

Then she lit up a candle and she showed me the way

There were voices down the corridor,

I thought I heard them say

Welcome to the Hotel California Such a lovely place (such a lovely place)

Such a lovely face.'

Many people will  associate  this  song  with  love or some other pleasant emotions. Looking closer they will see that it is a scary song about a terrible situation, far from love.

The secret is that we have to find ways to 'open' the  text  and  not  closing  it.  Otherwise  we  will present or perform it at the same basic level, like in  the  computer  game.  We  have  to  level  it  up artistically.

To open the text we need to ask questions:

- -What do we see?
- -What do we hear, smell or feel?
- -Who is it? What is happening?
- -Where are we?
- -Are there any objects in the text?
- -What does all this tell us?
- -What associations do we get?
- -What could it be about?

After this process we can start to close it again but on a new level. We know what we want the text to be about!

In  the  next  step  we  start  to  rehearse  and  we think we know everything. Now the actor starts to  investigate  the  text,  within  the  context,  and it  should  start  to  open  again. Their  action  adds some  new  elements  and  we  start  the  research again. We improvise to learn more, we relate to ourselves, collect material and observations from all around. In the end of the rehearsing process we need to close it again. If we have too many options we will not be able to tell the same story for every performance.

We  have  to 'block'  or  lock  all  possibilities  and follow one concept. We have reached a new level and on that level we meet the audience. Finally in  that  meeting  we  have  to  open  up  to  their interpretations again.

The image below is an illustration of this level up process in theatre.

In this image, we can see a graph. There is a text at the bottom of the image.

<!-- image -->

## 4.9 To collect inspiration and information

In the process of analysing and later rehearsing we will find that we are dealing with a material that  we  must  have  more  information  about.  In the lyrics above we found out that no one in the group knows the meaning of 'mission bell' . We need to get that information and share it with the group. For example, we may not be familiar with topics  like  mental  disorder,  addiction  to  drugs, domestic violence and depression. Also, we need to  learn  about  occupations, and what does the work  of  the  police,  headmaster,  architect,  etc. consists of.

Inspiration might usually appear as soon as you are committed to the project. Many people can tell how they think that the news, or everything that  they  read  and  hear  are  connected  to  their production. The easiest thing to do is to look at the theme, the time and place you are working with and search as much information as possible on that topic. Watch films, read books and listen

to  other  people  when  you  ask  them  about  the theme.

## 4.10  An investigative approach creates organic results

To  work  with  a  written  story  with  the  purpose of staging it, is more than just trying to translate a text into 3 dimensions. It is an artistic process that requires more than a technical approach; it needs an artistic approach. That means also that we  must  acknowledge  the  artistic  actors.  They need to contribute with their input, research and knowledge. A technical approach tends to create scared marionettes hoping they will repeat what seems to be right.

Even if the rehearsing process started, we should not know the exact final result before. It leads to mechanical  learning  and  actions.  Like  with  oil

In this image we can see a person standing on a big book.

<!-- image -->

painting, we work with layer on layer. Similarly, through  rehearsals,  we  create  a  depth  in  the characters and the whole performance.

The rehearsal process is, like the analysis process, an investigation of what we can create together with the support of this material. We work with questions  rather  than  answers.  Questions  are also  a  scientific  tool  that  opens  up  rather  than closing possibilities.

To  have  an  exact  plan  from  the  beginning prevents  the  actors  from  being  part  of  that investigation  and  instead  of  having  an  organic process and performance, they will end up with something 'dead' .

The investigation continues when we share our results  with  the  audience. They  do  not  want  to see actors behaving like trains on rails, they want to meet a story that invites them to be co-creator and that means the performance must have an open attitude.

## 4.11 Theatre conventions vs. film and TV

In  the  Mauritian  context,  we  are  more  used  to watching  movies  rather  than  live  theatre.  As  a consequence,  students  tend  to  copy  concepts they have previously watched when they perform in class. Below are some of the main elements of how theatre conventions differ from the screen.

## •    Facial Expressions and Body Gestures

On  stage,  the  audience  is  usually  farther  away from  the  actor  than,  say,  you  would  be  if  we were having a conversation in real life. My acting choices have to reach the people in the very back of  the  theater,  which  means  making  physical, vocal, and emotional/psychological choices that  are  bigger  than  what  most  people  would consider naturalistic. Using a microphone is not an  option  at  this  stage  since  actors  have  been trained from Grade 7 to vary the volume, pitch and tone of their voice.

In this image we can see a person holding a box and a hand.

<!-- image -->

In  television  and  film,  there  is  the  camera  that takes close-up shots and facial expressions and gestures need to be subtle. Big movements will only  make  actors  looks  cartoonish.  On  stage, actors need to use the whole body to convey a given  feeling  or  moment  because  subtle  facial expressions would not read in the last row.

## •    Perspectives

The  audience  in  theatre  always  sees  the  stage from the same  perspective where  they are sitting.  The  actors  therefore  have  to  move  and modulate  their  performances  in  order  to  draw the audience's focus.

In  films,  the  audience's  view  is  determined  by the eye of the camera. Unlike in theater, both the actor and camera/audience are in motion.

## •    Retakes/Rehearsals

Compared  to  films  where  there  are  retakes, theatre  takes  place  in  front  of  a  live  audience. Therefore, actors in theatre should be well prepared to deliver their performance in the best possible way at one go. For this to happen, actors should have various rehearsals which will allow them  to  focus  and  learn  to  deal  with  different unexpected situations.

## •    Interaction between characters

The screen often avoids direct interaction by  letting  characters  use  the  phone.  Most  of the  time  there  is  an  economic  reason  for  this: actors cannot be at the same place all the time. However, in theatre, students should be taught to avoid this TV convention and attempt to put the characters in the same frame.

With the awareness of these conventions, we can now approach the next part.

## 4.12 The conflicts make the cyclone spin

The engine of the drama is conflicts and everything spins around that. A series of conflicts form part of the rising action leading to a climax. Conflicting situations take birth  when  there is  an  obstacle  preventing  the  character  from achieving his/her objective. This obstacle may be internal (characters versus the self) or external between characters or between characters and their environment. When the conflicts are solved, it leads to the resolution and ending.

In this image there is a man walking and holding a blue color object.

<!-- image -->

## 4.13  Actantial model

The actantial model was first designed to investigate  the  overall  structure  of  oral  story tradition (folk tales) told by people from different cultures around the world. The model suggests that every story is built in the same way:

We need at least one subject who wants to reach something, the objective.

All subjects have a motivation or motivator. The motivation  answers  the  question: 'Why  do  you want this objective.'

To make the story interesting we need to insert obstacles on the road to the objective.

An obstacle can be intrapersonal or interpersonal but it can also be a physical, social or economical obstruct. In theatre,  the  obstacles  are  often personalized.

A complex story will let the main character have some helpers and some anti-helpers, not to mix with the antagonist who is usually the obstacle in person.

For the subject to reach the objective and fight the  obstacles  he  /  she  will  have  to  use  a  wide range  of  skills  (means,  techniques,  strategies) and sometimes the character will not reach the goal, or just change the objective.

This graphic illustration shows the essence of the actantial model:

## The actantial model

The image is a diagrammatic representation of a task involving a task manager and a task. The task manager is labeled as "Subject" and "Object". The task manager is connected to the task by a line, which is labeled as "Subject". The task manager is connected to the object by a line, which is labeled as "Object".

The task manager is connected to the object by a line, which is labeled as "Object". The task manager is connected to the goal, which is labeled as "Goal". The goal is connected to the object, which is labeled as "Object".

The goal is connected to the object, which is labeled as "Goal". The goal is connected to the task manager, which is labeled as "Task Manager".

The goal is connected to the object, which is labeled as "Object". The object is connected to the task manager, which is labeled as "Task Manager".

The goal is connected to the object, which

<!-- image -->

In the activity chapter you will find a way to use this model in practice.

The  structure  of  the  Actantial  model  will  also serve  as  a  guide  when  the  groups  are  creating interactive  drama.  You  have  the  protagonist, the  antagonist,  helpers  and  anti-helpers  and surrounding them are the, more or less passive, bystanders.

## 4.14  Interactive drama

Interactive drama is about finding possible options and opinions about an issue. The issue could be within the community, global or even  personal.    This  is  done  by  presenting  a dramatized story about an issue that ends with a  disagreement.  The  audiences  are  no  more passive spectators, but they  become  spectactors, where they have to watch, question and later actively engage with the actors. At the end of the performance, the audience is then invited to investigate into the causes and effects of the issue.  The  group  presents  the  story  again,  but this time, the audience calls 'freeze' at a specific moment  and  comes  to  replace  the  character by changing turning points of the story to find a  possible  solution(s).  The  students  should  be taught that not every character could be changed. Converting  the  person  perpetuating  the  social evil into a nice, righteous, moral character is not realistic.  Rather,  students  should  change  their choice of minor characters to show how they can influence the rest of the story positively.

Interactive  drama  is  an  effective  way  to  initiate discussions  and  see  problems  from  a  bigger perspective.  It  develops  leadership  skill,  that  is, taking initiatives to promote change.  The spectactors' actions should be strategic so that the flow of events changes significantly. Students should be encouraged to create relevant characters and situations so that they can transfer the knowledge to the real life situations. The aim is not to give advices but to uncover our own decision-making and reactions.

After an intervention, the teacher may  ask questions  such  as  'what  do  you  think  of  this solution'; 'can this be done in real life?'

## 4.15  Obstacles not comfort!

The teacher is expected to challenge the teams, giving  them  more  hurdles  to  surmount.  The students, as actors would usually choose to stay in their comfort zone by taking up a relatable role requiring  an  easy  vocal  expression  and  familiar movements. However, the teacher should encourage the students to go beyond the usual type  of  performances  that  what  they  engage with.

In this image we can see a wooden blocks arranged in a stack. In the background there is a building and a tree.

<!-- image -->

## 4.16  Two expressions

In  Drama,  but  most  of  all,  in Theatre,  there  are many expressions that can sound a little strange and contradicting from the outside. They are also commonly used in other genres

Some are created out of superstitions but some are really meaningful in production terms.

For example: Break a leg.

Less  is  more: Sometimes  we  think  that  the audience will not understand if we do not make things very clear. If we need a forest on stage we overload it with trees and branches, stones and high grass. We add birdsong, the sound of wind in  the  trees  and  special  light  effects  with  gobo filters.  (A  gobo  is  a  stencil  or  template  placed inside or in front of a light source to control the shape of the emitted light.) We are close to what movies are doing, building up something almost realistic. However, on a stage this will easily look silly and at the same time the audience will feel underestimated. Maybe the singing birds are all what it takes to create the illusion of the forest. Less is more.

A manuscript can be full of 'more is more' . The children repeat 'Mami, mami' over and over just to make sure to show that she is the mother of them. We are so insecure whether the audience will understand that we decide to explain everything through lines. Instead we must trust their  ability  to  use  their  imagination  and  our ability to act.

Therefore, even the best introduction before the performance  starts  can  be  disturbing.  Do  we really need to know the plot, the setting or the characters in advance? We should instead let it happen and bloom towards the understanding of the audience and not underestimate them.

A very common mistake is to let four chairs on stage  with  four  actors.  They  will  immediately place themselves in the chairs and nothing will happen. In this case less is more refers to how to

better create conflicts by using unbalance - three chairs and four actors create tension.

In this image we can see a group of people wearing costumes.

<!-- image -->

Kill your darlings: You are preparing a birthday cake. You have one layer of bananas and one layer of custard. What to add as topping? Your favorite is 'Pima confi' so you decide to sprinkle it all over the cream on top of the cake. Very tasty! Is it?

If  you keep something or add something in the text or in the performance that lacks motivation or is completely out of context, you have kept a 'darling' .

Someone is stumbling in a fun way - everyone is laughing. 'Let's keep that.'

Someone shows good skills in singing - everyone adores it. 'Let's keep it.'

The musician made a very long and interesting guitar solo.  'Let's keep it and add 2 minutes more.'

Kill your darlings is an appeal to really motivate everything  that  takes  place  on  stage.  Look  for unmotivated  things  that  you  like  to  keep  just because you like it and 'kill' , remove, them.

The function to keep an eye on Darlings and Less is more, is the director.

## 4.17 The director's function

Directors  are  the  ones  who  lead  the  work  on stage. They are guiding the actors and have the final  decision  about  set  design  and  everything that is visualized or heard on stage. One part of this  role  is  to  be  pedagogical.  The  actors  must understand  the  complex  story  and  see  their own part in that story. The relation between the director  and  actor  makes  the  actor  grow  into the character. After some time the director can withdraw from being a 100% leader and let the actor lead together with the director.

At  the  end  of  the  process  more  and  more responsibilities can be given to the one who is on stage (where the director has no place) and they will take over the leadership of telling the story in their performance.

The process can be illustrated with the following time line.

In this image, we can see a graph. There are two lines on the graph. There is a text on the graph.

<!-- image -->

In  a  way  you  can  think  that  this  is  also  the progression of the textbooks in Drama &amp; Theatre from Grade 7 which contains the foundation with very  little  independent  work  of  the  students. In Grade 8 the textbook gave  them  more responsibility and here in Grade 9 the students are given a long independent process of work.

The graphic illustration can also serve as a model for  relations:  parents  /  children  or  a  teacher's relation  to  a  student.  They  have  to  learn  how to stand on their own with the knowledge they have incorporated.

## The roles of the director are:

- To take responsibility of the process leading the actors
- To lead and prepare the rehearsals
- To take responsibility of the artistic result as a whole
- To be the eye from outside
- To be able to see things for the first time even if it is the 22 nd time.
- To use questions more than answers and let the actor answer by acting
- To use words rather than physical expressions
- To create obstacles for the characters even  if  the  actors  think  it  should  be  more comfortable without
- To  give  the  actors  their  space  and  not  to pretend to be an actor as the director has his / her own space.
- To  avoid  mixing  roles  with  being  a  director

In this image we can see a group of people sitting on the chairs. There are some objects on the table.

<!-- image -->

- Try  avoid  showing  actors  how  to  do  or  say things,  they  will  imitate  or  they  can  feel offended. Try  using  words  to  give  the  right impulses not actions. If you need to show, do it in an exaggerated way or very badly.
- Stop actors from directing other actors, they just want to avoid obstacles.
- To start a specific rehearsal by using commands like 'Silence, concentration, breath,  please  start'  and  to  end  it  by  using 'thank you' . The actors should not interrupt rehearsing by themselves.
- To understand that in the end the actors are there alone on stage telling the story.
- To  understand  that  the  actors  and  also  the rest  of  the  production  staffs  are  creative artists.

## 4.18  What makes the play convincing?

Anyone can read words off of a page, but creating a  really  convincing  character  takes  much  more than that.

Remember the last time you lied - What did you do to make it look convincing? In that moment, you need to believe in what you are saying and seem confident even if deep down, it is not the case. No matter what happens, the show must go on.

Your goal as an actor is to create a character by knowing how they would behave and respond in  various  situations:  Who  is  that  character? What are  the  main  events  of  his/her  life? What has influenced your character in becoming who they are? What are your character's strengths and weaknesses?

The key is for the actor to believe in everything his/her  character  is  going  through.  If  an  actor

seems  to  be  faking  his  emotions  and  actions, the  audience  will  easily  pick  it  up  and  will  fail to  engage  in  the  performance.  Instead  of  the performance giving the desired effects they work for, it might turn into a discouraging ridicule.

## •    Confidence

The  audience  will  be  convinced  with  actors' performance  if  they  play  confidently.  It  applies to the way the actors talk, carry themselves and move. If actors look self-conscious and awkward in  front  of  the  audience,  the  latter  will  feel  the uneasiness and will not believe in the flow of the events.  Confidence  includes  the  way  the  actor speaks, with proper articulation, intonation and voice  projection.  Otherwise,  there  will  be  no suspension  of  disbelief  as  the  audience  will  be conscious that the performance is not real.

Confidence can be gained through collaboration between the crew. For instance, if someone has forgotten their line, someone else might just take up their next line or ask an impromptu question to which the actor will remember his/her initial line.

Another  way  of  achieving  this  confidence  is by  knowing  your  character  on  the  tips  of  your finger,  that  is,  try  to  think  how  your  character would react to that particular situation at times. Focusing  too  hard  on  remembering  the  exact words  of  a  particular  line  could  destabilize  the performer.

## •    Positioning on the stage

One  common  mistake  among  students  when they perform in class is that they do not move around enough or they have their back facing the audience. This could be irritating as the audience will see only one dimension of the actor, and not facing  the  audience  limits  the  understanding of  part  of  the  performance.  Students  need  to make effective  use  of  the  space  given  to  them by  thinking  that  the  purpose  of  theatre  is  to

perform for an audience that has to be aware of the stage actions. One way of helping students positioning  on  the  stage  could  be  the  use  of marking on stage. However, every movement on stage must have a purpose. Students should not move around for unnecessary reasons, causing a distraction to the audience.

## 4.19 Positions on stage the 9 point exercise

Normally in theatre, the stage is divided in 9 areas or fields.

In this image we can see a table with some objects on it.

<!-- image -->

This  is  done  for  many  reasons,  such  as,  light, scenery and set design.

As a part of the acting training, we can use the nine  positions  or  points  in  exercises  to  explore the  relation  between  space  and  actors  and between several actors.

## 4.20  What is Gestus?

The chapter Activities in  this  book  encourages the  students  to  observe  and  collect  behaviors, movements and ways of talking from the word outside of theatre. A technique that can be useful is  to  see  that  social,  occupational,  cultural  and economical factors can be revealed through that.

The  term  for  that  is  Gestus,  not  to  mix  with gestures or tics.

This  acting  technique  was  developed  by  the German  theatre  practitioner  Bertolt  Brecht.  It carries  the  sense  of  a  combination  of  physical gestures and 'gist' or attitude.

A  Gestus  makes  a  character's  social  relations visible and the causality of his behaviour, as interpreted from a historical materialist perspective.

In this image we can see a woman holding a musical instrument.

<!-- image -->

Compare for instance with what physical Gestus a carpenter will use to describe how to make a cake, with a hairdresser. Their background can be told by the way they are expressing themselves. A poor waiter will react differently from a wealthy one,  when  he  finds  a  golden  ring  under  the tablecloth.

A  Gestus  is  not  a  cliché;  the  actor  develops a character's Gestus through a process of exploration  of  concrete  physical  behaviour  and according to a principle of selective realism.

## 4.21  Why shoes must come first

In  relation  to  Gestus  we  can  also  mention  that the way the character dresses up can show his/ her social and economic background.

When you  are  rehearsing  and  start  to  have  an idea of what your character is about, it is time to give him or her the right footwear. In so doing, every time that you rehearse, you will be wearing

the  specific  footwear.  They  might  be  changed later  in  the  process  with  something  that  works better in the performance but usually it does not create any problem.

In this image we can see a group of shoes.

<!-- image -->

The shoes determine the gait (the way you move) and your posture and the sooner you start using the right shoes, the better.

Just imagine  that  everyone  is  rehearsing  in 'tennis'  shoes  and  getting  used  to  that;  in  the end  you  will  find  that  they  are  all  moving  the same way.

The  same  will  apply  for  dresses,  skirts,  trousers and jackets.

Especially for girls this is essential. How does my character  dress:  A  long  or  short  dress  or  some kind of pants? A jacket or a skirt will give you a new approach and the sooner you start using it, the better for you characterization.

## 4.22  Costume Designer

Each performing group will consist of a costume  designer.  It  is  to  be  noted  that  he  or she  only  decides  on  the  types  of  clothing  that will  determine  the  status  of  the  character.  The responsibility  to  bring  those  does  not  belong to  that  student  who  was  chosen  as  costume designer. Students should bring their own outfits or  props.  In  fact  only  they  will  own  outfits  of their  actual  size.  Avoid  borrowing  clothing,  in case  any  mishap  happens  during  rehearsals  or performance.  It  is  to  be  noted  that  shoes  are

meant  to  be  used  as  soon  as  rehearsing  starts in order to ease the students' transition into the character they are playing. Everybody can freely decide  to  contribute  with  props,  accessories, make-up  or  any  other  requirement  to  render the  performance  better.  You  may  extend  the responsibility of the costume designer by asking  him/her  to  supervise  all  materials.  Be careful of any types of make-up products being used,  students  may  have  allergies.    Remember, sometimes less is more!

## 4.23 Private or in character

When  you  are  on  stage  and  start  thinking  - 'I wonder what I will have for dinner tonight' or 'Look at Kevin he is pretending he is a rabbit, he looks stupid' you can be sure you are becoming 'private'  and  that  everyone,  audience  and  coactors, will notice that. The major risk is now that your  friends  on  stage  will  lose  concentration, start to laugh or plan for their own dinner.

Keep the concentration and thoughts within the character and focus on what is going on.

The  rehearsals  are  there  to  let  us  get  used  to strange  things  and  during  the  process  we  will have the opportunity to laugh at poor Kevin with his long ears. After a while our laughter will fade and we can focus on being the Wolf.

In this image we can see a cartoon image of a person. There are some text and images on the image.

<!-- image -->

The characters are, like you and I, observing and reflecting all the time. One secret in convincing acting is that the characters reflecting thoughts are present during the play. This is what is called Sub-text in theatre. The sub-text is what decides how the lines will sound. The character can think 'I really hate to do this' and the line is 'Yes, mum, I am so happy to help washing.'

## 4.24  Two different Black outs

In  theatre  we  can  mean  two  things  with  the 'black out': One is related to the light. We turn it  off  completely,  maybe  because  we  need  to change the set, to show that time passes or to mark the end of the play.

A recommendation is to avoid this type of black out. They cut the contact with the audience and can make the actors stumble blindly around in darkness.

If there is a change in time or a new place must be established on stage, use some kind of sounds or music that gives the feeling of the next scene.

In this image there is a black background. In the middle of the image there are two eyes.

<!-- image -->

The other use of the expression is when an actor gets a black out. His memory is gone, he has no idea what to say or do. This usually happens when the  actors  are  too  focused  on  the  lines  instead of the will of the character. His focus on the will and the other on stage will help him. Normally the actor's muscular memory is better than their verbal memory and one key is to give the actor help during rehearsal to physicalise the lines. A line  connected  to  body  and  will  is  stronger  to remember.

This  leads  us  to  the  use  of  the  actantial  model and different rehearsing techniques.

## 4.25 Rational and irrational

One  of  the  reasons  scientists  show  interest  in the process of drama and theatre and the way it affects students and professionals, is knowledge improvements (academic, social, cultural, comprehension, psychological etc) among participants.

A good process in drama or theatre involves two approach levels: the rational and the irrational. We need to have a scientific, rational and disciplined approach but at the same time we must embrace the irrational, magical and crazy level where the creativity  will  maximize.  There  is  a  movement from irrational to rational back to irrational and again rational. With a more scientific language we can say: We collect data and then we analyse and implement it. We open up to the irrational and creative level and then, with discipline, we return to the logical level and refine the knowledge into a performance.

The movements between levels encourage students with a strong logical sense to walk on the thin ice of irrationality. Students with a strong creative or irrational mindset will be encouraged to develop their discipline and rational side.

Movements from rational to irrational in the process

In this image we can see a graph.

<!-- image -->

A good director or leader knows when it is time to change level to lead the development of the process with the right energy. The next text will guide you through some of the techniques that can appear irrational but they all have qualitative purposes.

## 4.26  Rehearsal techniques

Most  of  the  above  text  depends  on  how  the group is rehearsing. If they understand the idea with layer on layer they will love to investigate the play  with  different  rehearsing  techniques  from where they will have new and deeper knowledge about  characters,  concentration,  focus,  tempo, status, relations, etc.

They  are  meant  to  add  a  new  layer  and  make the acting more convincing. In this process, the groups should be encouraged to be curious and investigate  several  options.  In  the  chapter  with activities, you will find several examples.

Just  remember:  the  rehearsing  techniques  are not  supposed  to  add  new  pages  to  the  script, it  is  supposed  to  add  deeper knowledge about the characters, their backgrounds and the relations between them. The techniques will also sharpen the concentration and mental presence of  the  actor.  You  do  not  see  that  the  plank  is sandpapered and the first coating of paint, but you  will  sure  find  out  when  the  paint  starts  to peel off.

Another aspect of rehearsing techniques concerns what to rehearse and in which order:

In this image, we can see a glass.

<!-- image -->

The recommendation is to start with the whole play once. The group will get a holistic feeling.

If the play can be divided into acts or scenes it will help the further work. A scene is usually starting with someone entering the stage and end with someone leaving.

The first scene is the next part to rehearse, then the next, one by one.

After  going  through  all  the  scenes  it  is  time to  'run-through'  the  whole  play  again  to  find weaknesses and strength. Maybe here it is time to sort out some difficult parts for the actors.

The next process is to rehearse the sequences in each scene. A sequence is what is going on from one turning point to another. The turning points are decided in the analysis process and they are smaller units in a scene.

After that it is time to just go through the whole scene to see the effect(s) of the changes.

So, in short: rehearsing is to go from the whole to smaller units and back to the whole. From the whole built, break it in further smallest units and back to smaller units. Then, again to the whole and so on. In this way, we are also using the layer on layer technique in the rehearsal process.

We  should  avoid  to  'run-through'  the  whole play  over  and  over  again.  It  might  be  during the last week of rehearsing, only just before the performance for it to serve a purpose.

## 4.27  What is a run-through?

A  Run-through  in  theatre  is  a  rehearsal  of  the whole  show  or  sections  of  the  performance with all elements of performance from the script being used. For instance, actors will  be  in  their costume and will go through costume changes if  required  for  the  production,  the  set  design and any change required during the staging, the operation of theatre lights as well as the inclusion of any sound effects. It also helps actors identify any weaknesses in memorising their lines and it is an opportunity to ensure all cues are identified. However,  some  directors  use  the  rehearsing technique of the run-through to create bonding in the ensemble.

## 4.28  A performance

To  cover  this  topic  would  usually  take  a  whole book  but  nevertheless  there  are  some  aspects that need to be mentioned.

concentration and finally the pep-talk, a usually brief,  intense,  and  emotional  talk  designed  to encourage the group. The pep-talk can be used as a vocal warm-up so give each other the best pep-talk before performing.

Some time before the time for the performance, the ensemble must gather. The time must be set so that everyone is there. No matter if it is 2 hours or  40  minutes  before,  everyone  must  be  there. This is the time for the last preparations, warm-up,

Everyone reacts differently to stress and adrenaline,  some  seem  to  become  tired,  while some become hyper active. Try to let everyone behave in their own way without disturbing their 'upload' .

In this image we can see a group of people standing on the stage.

<!-- image -->

Not every group is lucky to rehearse in the same room as the performance takes place. That means that the room must change; the space is larger and the audience is far away. This suggests that the final rehearsals should take place where the performance is held. Besides, the space must be marked so that everyone knows how to fill it. Not only body movements and expressions but the voice can also be an issue.

A professional theatre usually consists of supports such as lighting, hidden bodywork mics, curtains, etc.  None  of  these  are  imposed  on  students  or teachers.  Students  were  trained  in  regards  to voice projection and physicalisation for instance. Those skills gathered in Grade 7 and 8 should be implemented  when  facing  a  bigger  audience. The stage should be adjusted according to the easily accessible materials.

Every actor should try out what is needed from him or her in the 'theatre' . Let someone stand at the back and see if your voice can be heard. Let the voice fill up the room to know the acoustic.

Note also that when the room is full of people the sound and the acoustic  will  change  from 'wet' (reverberant spaces) to 'dry' (absorbent rooms).

Don't  let  the  presence  of  the  audience  lose your aim, to share a story together. Besides the change of acoustic, the audience can also make you lose  control  over  what  you  have  prepared. They can be silent when you expected them to laugh  and  they  can  laugh  when  you  thought they  will  cry,  or  you  just  feel  that  they  are  not there. Take your time, do not stress if any of this happens. Give the audience time to react but do not  let  it  change  your  way  of  performing.  This takes some discipline to hold together what you have created.

For some,  the  first time  meeting  will be  a surprising shock that is hard to prepare for.

If  you  are  not  on  stage  for  the  moment,  keep quiet and try to concentrate on what is going to happen on stage. Encourage the ones who will enter and support the ones who exit the stage.

They will do the same for you!

When the play has finished, the actors will line up to take a bow.

In this image we can see a group of people standing on the stage. In the background there are lights.

<!-- image -->

Thanking the audience for being part of sharing a story is one humble perspective when we  talk  about  taking  a  collective  bow  after the  performance.  This  is  the  last  view  of  the ensemble that the audience will carry after the performance. That is also why this line up should be rehearsed!

Finally,  there  could  be  some  disorder  after  the performance that needs to be taken care of. Make sure  that  everyone  stays  for  a  short  reviewing and to create order around the stage.

## 4.29 Constructive criticism

The  purpose  of  Art  is  to  elicit  a  response.  The students are required to give a critical appraisal of the performance. Students' comments should not  be  limited  to 'good'  or 'bad'  or 'I  like  the ending'.  They  should  instead  be  specific  and have a thoughtful analysis of the production by using the accurate vocabulary. The opinions on

the play should be supported by a discussion of the production elements and how they worked together as a whole. The 3 steps of a response are, 1) to describe, 2) to analyse and 3) to reflect.

Students  should  not  take  criticism  personally but should understand how the play could have been  improved  or  what  are  the  elements  that could have been altered.

The  different  groups  should  also  be  able  to comment on their own performances including the strengths and weaknesses as well as challenges they encountered for each stage.

## 4.30 Outline of activities

The activities  in  the  next  chapter  are  proposed to prepare  students  with  the  skills  required to  sculpt  a  good  performance.  The  activities will  contribute  in  fragments,  but  prepare  the students for a main performance. They are thus all somehow interrelated towards the development concretisation of a bigger theatrical project. The activities in the textbook are separated into five topics and they are all interconnected to cater for special skills and gears that students require.

- Scripting the theme
- The Swapping of Scripts
- Investigating and Rehearsing
- By Heart
- Performance and Analysis

Scripting  the  theme  will  be  the  phase  during which students will write their own scripts from experienced  social  or  cultural  issues  pertaining to  themes.  Students  will  have  the  freedom  to unleash  within  a  familiar  context,  their  own creativity,  rather  than  just  comply  with  a  given and set script. Their sense of empathy will be fully activated as they can relate to their creation. They will, in the journey, learn the technical aspects of a script production.

The  Swapping  of  Scripts  will  consist  of  further forming  the  students  who  at  times  tend  to  be possessive over what they own. The fact that they will have to let go of their own creation to which they may be attached to, trains them to become more open and receptive to accepting iterations made to their work and to comments that they will  receive  from  students  not  belonging  in their  own group. They will learn how to accept appraisals, constructive comments and changes. Their  perspective  and  ability  to  empathise  will broaden  in  all  its  capacities  as  they  will  learn through  accepting  and  sharing  within  a  micro and macro ensemble.

Investigating and Rehearsing are crucial stages. A  script  when  drafted  from  scratch  does  not become  the  final  product.  In  most  cases  the script needs further investigation and editing for it  to  conveniently  marry  the  other  unforeseen aspects of the play.

Since students will perform in Grade 9, rehearsal becomes  a  fundamental  task  that  needs  to  be taught to students. The skills of rehearsal are not acquired, it is to be learnt and developed.

By Heart will prepare the students to memorise their text by heart. Drama and Theatre, through creative play, repetition, rehearsing, performing words,  movements  and  cues,  strengthens  the students' memory.

In this image we can see a puzzle.

<!-- image -->

Drama and Theatre brings a repertoire of exercises  that  will  encourage  the  students  to exercise their brain in a fresh creative approach to  activate  it  to  its  further  capacities  again.  It provides them with the platform to engage with the creative side of their brain holistically. They will train their brain to become more receptive. They will learn by heart side by side with bodily hints and this will be a skill that they will learn to master and use even outside the framework of Drama and Theatre.

Performance and Analysis are at the final stages of  Drama  and Theatre. The  textbooks  of  Grade 7,  8  and  9  all  come  together  to  the  delivery  of a  final  performance  that  will  be  thoroughly investigated and prepared. Through this whole  sculpting  process,  students  learn  how to  effectively  and  constructively  analyse  and appraise  a  presentation  or  performance  within the framework of Drama and Theatre. They not only learn the strategies of how to appropriately appraise, but also to accept valuable advice given to them to rectify and improve their skills.

<!-- image -->

## Suggested activities Grade 9

This chapter constitutes of a list of recommended activities  that  supports  the  arc  across  the  four focus  areas,  namely  creating,  arts  and  society, performing and responding along the 3 semesters.

The framed activities below are used to prepare the  students  to  understand  and  manage  the next group task in a better way. If the teacher is sure they can manage without this 'put on track' activities, they can go on to the next activity.

There  will  be  two  types  of  grouping  for  the activities: fixed and varied.

At  the  beginning  of  the  semester,  fixed  groups will be formed to work together for the whole year for a final presentation. However, throughout the 'put on track' activities, the teacher is required to temporarily create new groups.

<!-- image -->

By  varying  groups,  students  will  then  be introduced  to  new  or  previously  worked techniques  and  in  parallel,  it  will  promote  a relaxing and socialising environment.

## What did we learn?

Aims: For the students to recall the experiences from Grade 8 and to let the teacher note what has to be worked on more.

Duration: 10+25 minutes

In groups of 4-5

Discuss what have been the strongest memories from Grade 8 in drama and theatre.

Present the result of the discussion in class with some physical illustrations.

## 5.1 Scripting the theme

## Life experiences from a theme

Aim: To be able to relate personally to a theme. Duration: 15 minutes In groups of 5-6

The groups now founded will continue to work together all the way, with some exceptions, to a performance.

A theme is introduced by the teacher.

Suggested themes are procrastination, forbidden love and individual vs. society. Refer to chapter 4 for more explanation on 'what is a theme?'

Everyone must be given some time to individually understand the theme and then find a situation from their own life (past or present) that relates to the theme.

The members in the small group start to share their  experiences  related  to  the  specific  theme. Students must be encouraged to see the situation, before and after.

Teachers are advised to give their students the opportunity to raise generally taboo and controversial subjects such as poverty, homosexuality,  dealing  of  drugs  among  school students, teenage pregnancy and sexual harassment.  Try  to  avoid  the  traditional  topics and themes (e.g., unity in a multicultural context) that conform to moral principles.  The discussions should  be  however  closely  monitored  and  be done in a professional manner in order to prevent possible overreactions.

<!-- image -->

## Introduction to Tableau and statue

Aim: To enable students to experiment with the isolation of movements and postures

Duration: 20 minutes

In new groups of 5-6

Students will be divided in groups of 5 to 6 and are given different situations to sculpt.

They will be asked to choose scenarios conveying  specific  emotions  through  facial expressions and postures. The idea behind is to allow a shift in perception by communicating ideas or telling a story through a non-verbal communication of a static image. It could be a way of boosting confidence of shy performers since there is no pressure of learning lines.

For example, a goal being scored in a football match  could  be  expressed  by  focusing  on the  emotions  and  facial  expression  of  the supporters when their team has scored.

Other examples could be discovering a body on a crime scene, students in an examination room, ritual  at  a  wedding  ceremony,  funeral procession,  a  bus  conductor  working  or  a depiction of recess-time in school…

## Sculpting tableaus

Aim: To be able to sculpt life experiences in groups. Duration: 30 minutes

Back to the original groups and let everyone in the  group  sculpt  their  own  situation  related  to the theme.

Step 1. One by one sculpts the situation with the members of the group as part of the tableau.

If  the  group  has  6  members  there  will  be  6 tableaus to sculpt.

Step 2. Back to the first tableau; a situation frozen in action. That member of the group now sculpt two more tableaus starting with the beginning, what happened before the Step 1 tableau, what was  the  origin  of  the  situation.  Finally,  a  third tableau  that  shows  the  end  or  the  outcome of the situation is made. One by one, they take responsibility  for  sculpting  the  other  members into a sequence of three tableaus.

After  this  internal  group  task  they  now  have to  choose  one  of  the  situations  that  they  find inspiring, interesting and challenging and present  the  three  tableaus,  in  that  situation,  to the  rest  of  the  class.  No  verbal  explanation  is needed but the class is invited to reflect on what they see and understand.

<!-- image -->

## Freeze game with a topic

Aim: To remind the learners about improvisation Duration: 15 minutes The whole class and in pairs

The  freeze  game  starts  with  two  persons standing  or  moving  in  the  room.  They  start a  scenario  and  as  soon  as  the  teacher  calls 'Freeze' , the two stop as statues. The teacher then gives a topic, for example, puberty, magic, autonomy, comedy, leisure, fight, tension.

Based on the theme given, any other student in  the  class  replaces  one  of  the  students by  tapping  their  shoulder  and  taking  the exact  same  position  as  the  person  who left.  However,  he/she  now  has  to  start  a completely  new  situation.  After  some  time the teacher says 'freeze' again and someone else takes over.

## Prepared improvisation

Aim: To go from three tableaus to improvisation Duration: 30-40 minutes

The groups continue with the decided situation and create a prepared improvisation with the help of the three sculptures in the tableau; beginning, middle  and  end.  Now  talking  is  allowed  if  the situation requires that.

The group presents it to the class and the class answers the questions:

What actions did I see? Who did I see? Where is this? When is this? What does it mean to me? that?

Follow up question: What made me see or think

<!-- image -->

## Freeze game without words and without a set topic

Aim: To improvise without words. Duration: 15 minutes The whole class

The same as the normal freeze game but  now  done  without  the  use  of  words. Communication will be based on body language, breathing, eye contact, etc. The  only  word  that  will  be  heard  is 'Freeze' . The exercise starts with two students.

<!-- image -->

## Physicalise your character

Aim: To enable students to master the characters' movements from head to toe Individual exercise in the whole class

Students  walk  around  the  class  and  occupy space from the pace 1 to 7, 1 being the slowest and  7  the  fastest.    The  teacher  asks  them  to focus on different parts of their body, from the head, the face, their look and the neutral face expression, the upper body, the shoulders, the chest as well as the lower body, the hips, the legs and the feet.

## Physicalisation

Aim: To expand their physical expressions and see that words are not everything. Duration: 15+15 minutes

The groups now prepare an improvisation based on  the  decided  situation  that  they  showed  in the  prepared  improvisation,  but  without  the use of words. It does not mean that they repeat the  same  actions  and  just  remove  talking.  The groups must find a way to expand on their range of expressions to create meaning.

The  groups  present  their  results  to  the  rest of  the  class  and  the  class  is  invited  to  reflect whether  there  should  be  any  changes  or  any improvements from the prepared improvisation?

<!-- image -->

## Elements in a story

Aim: To locate the elements of a story Duration: 10 minutes New groups of 3

In  groups  of  3,  students  locate  the  multiple elements  of  the  story  below,  including  the plot,  setting,  characters,  conflict,  suspense, helper and resolution.

## Who is it?

On a late Saturday, Sindy was alone sleeping in her room. Her parents were not yet back from work. She woke up to the sounds of the neighbour's dogs barking. She had a feeling that something  was  amiss.  She  listened carefully and heard an unusual sound upstairs:  someone  was  walking  across  the corridor.  Terrified  of  what  could  happen  to her,  she  sensed  her  heartbeats  quickening. Her eyes were watery and she could barely move. Very  timidly,  she  reached  out  to  her phone  and  sends  a  text  message  to  her mother,  'please  come  home' ,  she  almost pleaded.  Her  mother  called  her  back,  she picked  up,  and  with  a  trembling  voice,  she whispered  'There  is  someone  else  in  the house, I am scared' . Her mother immediately called  the  police  station  and  reported  that her daughter might be in danger. The police officer asked for the details such as her name and address.

Any sound detected caused Sindy to panic  more.  She  visualised  various  scenes, imagining  how  she  would  react  if  she  is faced  with  the  stranger.  Minutes  felt  like hours and Sindy could now hear the wailing of  the  police  siren.  She  leapt  from  her  bed and  opened  the  door  for  the  policemen. Two officers went upstairs and one of them sat down with Sindy, trying to comfort her. When the  two  policemen  came  back,  they declared that there was no one in any of the rooms. She was relieved but at the same time felt silly.

## Script writing

Aim: To transfer one prepared improvisation to a script.

Duration: 30 minutes

The same groups as above must now write down the  characters'  names  for  the  roles  they  have created  and  what  they  are  saying  (reduce  the words  after  experiencing  the  physicalisation). The groups need to add the actions, usually in brackets,  and  they  can  choose  if  they  want  to describe the 'When' and 'Where' at the top of the scene(s).

<!-- image -->

## What is a social issue?

Aim: Introduction of the term The whole class

The teacher introduces the meaning of social issues and asks the students to give examples of social issues. Examples of social issues are: poverty,  unemployment,  ageing  population, violence against  Women,  crimes, bullying, drug abuse, corruption,  theft,  road  accidents and sexual harassment. The teacher has to be careful to not deliberately avoid certain topics.

The discussion will be guided by the following:

Share  a  story  where  you  witnessed  a  social issue (real life or fiction)

What are the causes of the social issue?

How can we fix or prevent a social issue from happening?

Who can help fix these problems?

<!-- image -->

## Up for a twist

Aim: to identify causation and co-relation between events and their consequences Duration: 15 minutes In pairs

Students  pair  up  and  work  on  identifying and  illustrating  a  social  problem  that  they think need to be addressed due to its rising importance.  During  the  activity  they  will discuss about the causes and consequences of the social issue.  They  will also  work towards  identifying  solutions  to  the  social issue.  Information  obtained  from  the  said discussion  could  be  presented  in  the  form of  an  interview  where  root  cause(s)  of  the social issue is identified and discussed by the interviewer while the interviewee would be up to propose solutions. It could be expanded to  a  televised  TV  show  on  the  social  issue they worked on by having multiple speakers. That is, it could be further developed to the idea that the issue is thoroughly discussed by different  participants  in  the  televised  show who would then propose solution.

## Interactive drama

Aim: To use drama as a way to 'discuss' solutions of social issues. Duration: 20+20 minutes

The same fixed groups as above discuss general social  issues  that  surround  them  from  their perspectives. They decide on one situation to  which  they  have  no  solution  and  create  a prepared  improvisation.  It  must  have  a  clear beginning, middle and end. The end should be tragic, thereby inviting for suggestions.

The groups present the tragic prepared improvisation to the rest of the class.

The  class  is  invited  to  either;  verbally  suggest solutions  that  can  be  improvised  by  the  group or  replace  one  of  the  characters  and  try  find resolutions by acting in an improvisation.

<!-- image -->

## Worldview

Aim: To discover different perspectives of the same situations Duration: 20-30 minutes

Groups: 5-6

In  groups,  students  will  work  on  creating situations  involving  a  co-construction  of  a shared reality in order to present contrasting perspectives,  that  is,  they  will  be  taking  into consideration the following topics to complete their tasks:

The  setting/Where:  Country,  rural  or  urban area, house, and apartment…

Social network: with whom does the individual/s interact with on a daily basis?)

Religion:  How  does  religion  affect  the  way people behave?

Education:  How  literate  and  educated  is  the framework?

Language: What are the languages the people use?

Values and norms: What is the lifestyle of the people?

What is the historical background of different countries?

They  have  to  pay  attention  to  their  conduct in relation to the context: How do you behave (dress, speak and act) in different situations?

## 5.2 The swapping of scripts

## Analysing a script in a social and cultural context

Aim: To analyse a story from a social and cultural perspective.

Duration: More than 30 minutes

The same groups as above swap their scripts. Now they are holding a new script, from another group, in their hands.

What could this story be about in our perspective? In what social and cultural context can we put it? Who are they? Where are they? When is this? What can we make the story be about? And finally decide: What do we want to tell with this script?

Who, when, where?

<!-- image -->

## 10 line story x 2

Aim: to make the learner see how the same text can be applied in different situations. Duration: 10+10 minutes

New  group  constellation  5-6  in  each  group silently reading the lines below. Everyone must have a chance to give his or her reflections on what  they 'see' .  Now  they  can  start  sharing and  deciding  what  this  is  about:  Beginning, middle and end, where, who, what and when. The lines will now be given to the characters and the group can prepare the improvisation.

The next step is to show the result and everyone will be amazed to see all the different ideas.

A 10-line story is a set of lines without connection to a character. The lines could be of  no  clear  sense,  a  random  set  of  lines  that creates more imagination. As soon as we think there  is  a  certain  situation,  we  tend  to  block our creativity. These lines can be produced by the teacher or use the below examples:

## First example:

- Ooops!
- What is it?
- Look there.
- Who did that?
- I am going.
- Who?
- This must come to an end! Someone must do something.
- I am going
- Who do you think you are?

- I knew that the end will be like this

Second example:

- Maybe around two-thirty
- Isn't it too late?
- When do you suggest?
- Not later than noon,
- Okay, put them in the bag,
- I could bring someone else.
- Oh, that will be interesting,
- Yes, it will be more fun
- You ever tried it?
- Only once -

## Adjusting the script

Aim: To turn a script into something the group wants to tell Duration: 30 minutes

The same group as above now has a script and one idea what they would like to tell with it. The task  for  them  is  now  to  process  and  adjust  the script.

They are  allowed  to  change,  remove,  merge  or add characters, setting or time to transform the individual  and  specific  perspective  to  a  more social and general one. The only limitation is that the lines must be kept, in the same way as in the 10 line story.

Finally  the  group  re-writes  the  script  with  the changes.

The result of this activity is a new script 'washed' through the new group's perspective.

## Allocate functions

At  this  point  it  can  be  useful  if  the  members of  the  group  decide  who  is  having  which  role in  the  process  of  staging  the  text.  Most  of  the members will be on stage but some have to take extra responsibility: actor, director, set designer, costume  designer,  prop  maker/collector,  mask and  hair,  sound,  music  and  light.  From  now on  the  team  leader  (refer  to  4.1)  will  have  a more important role, to make sure the group is progressing.

## 5.3 Investigating and rehearsing

## Inspiring sources

Aim: To connect a script created by the learners to other media and literature in order to identify sources  of  inspiration  for  the  coming  staging process.

Duration: 20 minutes excluding individual research.

Individually and in groups, in two steps

This is a task the learners can start thinking about outside of drama hours:

Can I find a similar story or characters in films or books to what I have experienced?

What more can inspire us in the staging process of this particular play?

How can we use this knowledge in the staging of the play?

What  is  the  main  difference  in  conventions  if  I compare a film with theatre?

The members of the group meet and share their thoughts on what they have found to 'spice up' the play but no adding of 'darlings' (refer to 4.16).

This  is  a  task  that  can  go  on  during  the  whole process.

<!-- image -->

## The actantial model

The  actantial  model  can  be  used  for  role analyses but will need a practical introduction by the teacher (Refer to 4.13).

Invite  one  student  to  stand  on  the  floor  and place a chair four meters in front of him / her, facing the chair. Tell the student to sit on the chair. The student walks and sits down.

'You are the subject, the chair is your objective and the skill you use, is walking' .

'Go  back  to  the  starting  point  now  and  ask yourself what is the reason for you waning to sit?'

Student: 'I am tired and need a rest'

Teacher: 'Let  that  be  your  motivation!  And now by showing your tiredness can you walk to the chair?'

Student: 'Sure.' The student walks tired and finally reaches the chair and relaxes visually.

Teacher:  'What  you  see  here,  when  the student sits down is an example of a turning point.  The  subject  goes  from  one  state  of mind to  another.  Let's  see  if  we  can  create an obstacle that  makes  the  story  more interesting. Can you find up something that will make it more difficult to walk?'

Student:  'Yes, I hurt my knee playing football.'

Teacher: 'Good. Can you show us how that hinders your way to the chair?'

Students do so. We will see how the motivation is  enlarged  and  the  turning  point  becomes even more obvious.

The teacher now invites a second student, the antagonist (a new obstacle), and that student is placed just in front of the chair. The second student is told to stop the 'protagonist' from sitting  down  but  is  not  allowed  to  sit  on  or move the chair. Both are told to use both verbal and physical movements to achieve the task.

Student  1  starts  his  mission  to  sit  on  the chair.  A  negotiation  starts  where  the  subject (protagonist) need to use strategies and changing  of  means  in  order  to  reach  the objective.

Maybe the student will manage but sometimes they focus too much on the problem so they forget  the  objective.  Now  we  have  created  a dramatic conflict with the chair as a metaphor.

Two more students are invited to characterise the Helper and the Anti-helper. They take place close  behind  the  Subject  and  everyone  take the  starting  position.  The  helper  is  there  to encourage and motivate the Subject to persist. The helper talks to  the  Subject  and  can  give new ideas how to succeed. The anti-helper will discourage and disturb the Subject.

The rest of the class can illustrate the bystanders and follow the dramatic action.

With this metaphorical introduction the groups can use the model to investigate their own stories and all their characters objectives, obstacles, motivations, helper and anti-helper.

<!-- image -->

## The maximum will

'Maximum will'  refers  to  improvisation  where  everyone  gets  one  note  of  a  situation  and  their different wills. They have to act it out at the same time and in the whole class. This will be noisy, so when you do this exercise it could be a good idea to inform your surrounding.

Below you can see some examples of notes. Feel free to add your own but make sure they will be interacting with others.

| You and your friends are trapped in a cave. Make everyone, at the same time, shout'HELP'                                           | You are nurse at the mental institution. Make all the patients line up to take their medicine.                                                                    | Your birthday party is in chaos. Make everyone sit down and sing 'Happy birthday to you…'                                                   |
|------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| Your fellow trainees are stressed because of a surprise test. Make them all relax by instructing and showing a breathing exercise. | You are in a demanding dance performance. All your colleagues seem to be nervous. Help them by keeping your concentration and do you steps, jumps and pirouettes. | You have been to camping on the beach. The tent collapsed with you inside.You must roll around and scream to get help from someone outside. |
| You think someone is trying to drug your friends and you. Make all of them hold their hand to cover their mouth.                   | During your basketball match you lose your contact lenses. Make your team members help you search the floor.                                                      | You are a flight hostess. During this flight an emergency occurred. All passengers must sit, lean forward and cover their heads.            |

| You are at the hospital with a sudden strong allergic reaction. Ask everyone where to find the doctor.                                         | The ship is sinking because all passengers are standing on one side of the boat. Make them spread all over and not to move so much.                 | You and your big family are cleaning the yard. They get a sudden panic because of a strong cyclone. Make everyone cover in the corner.         |
|------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|
| You love gardening and you have just planted a lot of seeds on this big area; Make your friends aware not to walk and destroy your plantation. | You are recording the sound of birds singing. Your friends show no respect to your project. They make too much sound. Make them quiet at any price. | A large group of tourists just entered this holy room. Make them remove their shoes immediately.                                               |
| Your neighbors are having a party late at night.You need to sleep. Make them understand that it is time to end the noise and go to bed.        | All your friends seem to take thing too seriously. Make them laugh by singing, telling stories, make funny faces or tickle them.                    | At the airport.You are the head of security. Everyone who looks and acts suspicious must follow you calmly for interrogation and body search.  |
| You are promoting the new orange juice in the supermarket. Make everyone try a glass and ask them their thoughts                               | Your mobile phone battery is low. You need to ask your friends for a charger.                                                                       | You as head of an interviewing panel need to carry out job interviews with many people today. Find out who will be the best lecturer in Drama. |

<!-- image -->

## Flashback - flash-forward

Aim: To formulate an understanding of situations based on their personal interpretations Duration: 5 minutes Individually

Each student will close their eyes and imagine personal life situations and experiences

Students  will  use  the  guidelines  below  to create the characters in  order  to  awaken emotions.

What is my personal background?

What do I want to achieve?

How will I reach it?

What is preventing me from reaching my goal?

What will I do when I get there?

## Identify the will

Aim: To understand the characters will. Duration: 30 minutes

The same groups with their new scripts as above start  to  define  the  will  of  each  character  in  the play.

- a.  What  do  they  want  to  achieve  even  if  they might never succeed?

When decided, they can improvise with the text using 'maximum will power':

- b.  Reading  the  text  with  only  one  will  and driving each will to its maximum. Sometimes the lines will support the will but most of the time not. Anyway, try to express the will using your movements, objects or voice.
- c.  What  could be the motivation for each character  in  the  play?  Try to  'turn  up'  the motivation of each character.

d. Improvise the actions with a higher motivation.

## Situation improvisation - focus on the actor

Aim: To transfer a situation in a play to a situation that the actors are familiar with.

Not to be confused with relation improvisation: A  situation  improvisation  is  an  improvisation where a situation in an analysed script is related to something the actors can relate to. If someone in the play is telling something shocking about a hidden secret, we must transfer it to a situation the actor can relate to: a friend comes at your place and informs you that your girlfriend / boyfriend is spreading a specific rumour about you. And that is only the start of the improvisation.

The  whole  script  can  in  fact  be  translated  into situation improvisations, even before the actors have seen the script.

For example, the actor playing Hamlet is put in an improvised situation where he gets a visit from his  real  dead  great  grandmother  who  wants  to tell a secret.

What if the actor playing Juliet is put in a situation where  her  parents  really  forbid  her  to  engage with her love?

This  must  be  a  teacher-guided  improvisation. One  improvisation  from  each  group  can  be done  without  preparation,  just  with  a  short introduction of the teacher.

This is part of the rehearsal techniques but it can be done early in the process, in order to 'ground' the situation within the actors.

## Identify the conflict

Aim:  To  identify  clashes  of  wills  and  to  relate them  to their life. To be able to  compare how they try to manage conflicts and obstacles  with  the  characters  in  the  play.  To get  used  to  collect  techniques  from  real  life.

Duration: 30 minutes

a. The same groups as above extract the knowledge  from 'maximum  will'  improvisation and actantial model to see if they can find all the conflicts in their script or play.

A  good  idea  is  to  write  them  down.  Example: Sandrine wants to have a cup of tea but her father stops her and wants to have a serious discussion about her wasting food.

b.  All  characters have different skills to manage conflicts and obstacles: what are the skills of the characters in your play? Normally they have one favorite action but if that fails they need to come up with more strategies.

c.  Ask yourself and each other what techniques you  /  they  are  using  in  real  life  to  achieve objectives  trying  to  get  past  an  obstacle. What do  you  see  if  you  look  at  other  people?  What techniques  do  member  of  families,  bus  driver, caretaker, teacher, etc use to manage conflicts?

This activity is a continuous task during the whole process and can be a part of the rest of our life.

The  more  techniques  in  conflict  management the  more  assured  it  is  that  we  will  reach  our objectives.

## Emotions

Aim: To investigate different emotions within characters and ourselves. Duration: 30 minutes The same groups as above

The characters show different skills and techniques to outsmart obstacles and this is also connected to their emotions. They as well as we, have their favorite emotions and some emotions that they try to avoid. Note that emotions are not a mask to put on - they are generated from the will, motivation and depending on the obstacle the character encounter.

One way to rehearse the play is to let everyone have the same emotion all the way from start to end:  Anger,  fear,  envy,  love,  amused,  ashamed, etc.

The emotions in the play can also be significantly connected to the theme.

A suggestion is to try out three different emotions and then discuss which of them can be used by which character and when.

<!-- image -->

## The 9 points

Aim: Investigating space, movements and relation

Timeframe: 10 minutes or more depending on how much the leader wants to develop the awareness of the students. In pairs

During this activity, students will explore the importance and value of, space and movements.  They  will  discover  how  different types of interaction between the two bring out different  outcomes.  Students  will  become aware  of  the  meaning  of  movements  and how they can use it in their rehearsal process and presentation.

In this image we can see a cheetah and a person.

<!-- image -->

As  shown  in  the  figure,  the  leader  marks the  9  points  with  tape  by  using  the  whole class.  Two  students  are  then  placed  in  two diagonal corners and should make eye contact.  They  are  then  required  to  move to  the  point  on  their  left  or  on  their  right or  forward  or  backward,  one  at  a  time. The only movement not allowed is the diagonal.

This  is  done  in  complete  silence,  keeping  a neutral facial expression, but maintaining eye contact  (as  far  as  possible),  in  order  to  focus on communication only through movements. When  one  actor  is  moving,  the  other  one should wait.

When  they  have  grasped  the  concept  of the  activity,  the  leader  can  then  add  new instructions.  They can  change  the  tempo in  their  movement  and  add  pauses  before moving.  Explore  different  tempos  and  break the  routine  and  comfortable  patterns.  They should notice how tension is build by pauses and  different  tempos  in  their  movements. Afterwards, they can be reminded that breathing is a part of the action. The way they inhale and exhale during their movements will influence the meaning of the actions.

The interesting thing about this activity is that even  if  the  movements  at  first  are  randomly picked,  they  will  still  have  a  meaning  to  the audience  while  the  actors  per  se  will  not necessarily perceive that.

At a more advanced stage, the students can experiment  with  their  script.  In  that  case they move or say a line. Movements and lines should not be simultaneous. When every one gets  the  technique  it  is  possible  to  involve larger amounts of actor by following the one move or line at a time pattern.

## Reflections:

To the audience: What did you see happening? What  was  this  situation  about?  What  is  a strong / weak movement? Was there tension between the two?

To the actors: How did you feel? Did it remind you of something? When did you understand what  this  scene  was  about?  How  was  the confrontation between the two of you?

## Eye contact 1

Aim: To find out what more or less eye contact contributes to in a play. Duration: 20 minutes. The same groups as above

The  same  method  as  with  emotions  but  now two  options:  either  characters  with  constant eye contact or completely without eye contact. The group tries both approaches and the actor decides  what  will  suit  the  character  best  and when.

Start  with  no  eye  contact  during  the  whole rehearsal (run-through)

End  with having  total concentration in eye contact.

Finally, the learner must have time to draw their conclusion to add to the character.

## Eye contact 2

Aim: To give focus by shifting eye contact Duration: 15 minutes The same groups as above

This exercise has it roots from Commedia dell'arte and is used even by clowns.

To explain this exercise we need to think about table tennis or tennis, the focus shifts all the time. The rule is that when I talk or do something I do not  maintain  eye  contact  with  anyone.  When  I am ready I give focus to someone else by looking at that person in the eye and now, instantly, that person looks away and talks or does something. When  ready, that person turns back or to someone else. The result is that everyone keeps looking  at  one  person  that  speaks  or  acts  and that person does not look at anyone.

No one is looking the other one in the eye.

a. Work in pairs first to understand the technique.

I look at you and you look away. You look at me and I look away. And so on.

- b. Work in pairs and now instead of only turning your head to or away, when you have the focus from  the  other,  do  something  physical.  When you are ready turn back and the other one does something and so on.
- c. Apply  this to the situation the group  is rehearsing or investigating.

Finally; remember to note what should be kept as good ideas.

## Observe - Validate - React

Aim: To force the actors to be concentrated and mentally present Duration: 30 minutes The same groups as above

The 9-points exercise will help even here as a reminder.

What normally makes a performance organic is the awareness of being present and even if the actor knows what is going to happen, he needs to act as if everything is happening for the first time. This activity is an exercise that can illustrate this effect and it can also be applied during rehearsal.

Organic performance is the single most important thing when it comes to convincing acting.

The actor first observes with all senses (absorbs or  collects  data)  what  is  going  on  and  what  is said, then the actor thinks and feels 'what does this mean to me?' An image of an action or contra action appears. Now at last the reaction can take place.

Separate  clearly  the  three  steps  during  a  very slow rehearsal. The actor can say the subtext out silently.

## Collect and recreate role material

Aim: To create convincing acting for each character.

Duration: 20 minutes Individual and in the group

The  task  is  in  short  to  observe  people  to  get materials  that  can  help  each  actor  to  create trustworthy characterizations.

First everyone collects material and observations and  then  they  share  them  and  show  them  in the  group.  This  is  also  an  ongoing  process  of collecting inspiration.

Depending on the characters and the functions in the groups' play, the individuals in the group observe  what  the  characteristics  for  their  roles are.  What  makes  us  understand  that  someone is a sister/brother, mother/father, teacher, grandfather,  police  officer,  bus  driver,  caretaker etc?

How  do  they  move,  use  tempo,  talk,  express themselves? Do they have any specific tics that can help to identify who they are? How do they act  when  they  are  not  in  their  role  of  teacher, shop  owner,  businessman,  waiter,  etc?  How  do they  drink  tea,  walk,  brush  their  teeth,  read  a book, sleep at night, water the plants, cook their dinner, etc?

These are all approaches that can make the action on stage convincing when applied. Through this activity the script does not need to contain lines like: 'Mum, I have to…' or 'Granny, I will do that later'

We already see who they are in their actions.

Other  things  to  observe  are  their  clothes  and especially their shoes. This observation will guide the actor to find the right costumes, starting with shoes  because  the  shoes  we  wear  decide  the posture of the body and sometimes our status. Compare moving in jogging shoes to that with walking in high heal shoes (Refer to 4.21).

This activity will also help the group to see that characters have different tempos, tones of voice and positions on stage, in the set. Some like to sit  down to rest, some like to stand because of back pain, others like to stand close to the stove, or close to a window or the door out.

## Lines and memory

Aim: To use a memorisation technique to learn lines faster

The  first  time  an  actor  reads  the  lines  is  also the  time  when  he/she  can  start  activating  the memory. One way to do so is to read them aloud in a neutral way in order to activate the memory of eyes, ears and muscles. Besides, you can notice 'the taste of the words' when saying them and by so doing, you also involve one more of your senses.

From  the  moment  the  actors  start  reading  the text  together,  and  later  on  in  rehearsals,  they should  get  used  to  another  technique.  They should be able to say the lines without looking at the manuscript and try to direct the lines with eye contact. This process will take more time but while doing so, they will activate their short term memory.

Example of the process:

Two persons in dialogue

Actor One looks in the script: Are you alone or is mum in the kitchen?

Actor One looks up and makes eye contact with the second actor: Are you alone…

Actor One looks at the continuation in the script, looks up again and finishes the sentence with eye contact: …or is mum in the kitchen?

For the first time Actor Two looks in the script to see the response: This is  not  a  good time to talk

about our plans. We have to be more careful.

Actor  Two  must  probably  divide  this  line  in several  segments  and  deliver  it  gradually  with the eye contact.

It  is  more important to pay attention to the coactors, since the direction and focus is not in the script.

When  this  technique  has  been  established  by all  actors,  the  process  of  learning  the  text  will go  faster.  The  basic  idea  is  also  to  understand that every line has a direction. Later during the rehearsal process it may not be eye contact that you should look for and that will develop through the  knowledge  that  you  will  gather  about  the character.

Our  educational  system  focuses  a  lot  on  the connection between two senses in use are that of  sight  and  hearing.  If  we  learn  for  the  exam, we use a specific kind of memory that may not last after the examinations. As an actor, we start to  understand  how  we  can  use  our  muscular memory  by  moving  and  connecting  the  text to our physical action. The line comes from the body reacting to impulses.

We have individual differences when it comes to memory. Some are better at memorising words they hear and some like to use their eyes. Some connect  text  to  images  that  they  store  in  their brain  and  some  prefer  the  senses  of  smell  and taste. Therefore, every actor must find out his / her  preferences.  Everyone  must  investigate  the connection  between  imagination,  senses  and memory.

If you imagine a lemon and think about the taste; you will soon notice how the three are connected. You  use  your  imagination  to  remember  whilst the  body  and  senses  would  then  react  to  the memory.

## 5.4 By heart

## Letting go of the manuscript

In  the process of rehearsing there is normally a set  date  for  when the actor needs to know the lines  by  heart,  the  day  when  no  one  is  holding the script in their hands.

From that day it is possible to use more advanced rehearsing  techniques  also  assuming  that  the actors know more about their characters.

Students  are  allowed  to  modify  their  lines  but they  still  need  to  convey  the  same  meaning, during the initial phase when rehearsing without a script.

The  techniques  have  the  purpose  to  add  more layers to the character and to create awareness, concentration and stage-presence. They are meant to be used only when needed to enhance the interaction and awareness on stage. Here are some of the rehearsing techniques in short:

## Relation improvisation - to create memories in the character

Aim: To give the characters a 'real' background and physical history.

This is one of the most common improvisations when rehearsing.

Given  that  students  may  not  necessarily  have been in all the situations that the character have been involved in, relation improvisation helps to fill these gaps within the actor.

We move the character to either a past situation mentioned in  the  script  or  a  situation  which  is likely  to  have  happened, and let the characters create the situation. The focus should be on the relation between the characters.

In so doing, actors build a reminiscent baggage that they bring with them to the stage.

E.g. An important line in the script is: Last week you insulted me when I was installing the DVD.

You called me a technical disaster!

Let the two characters do the situation last week! This will help them to do the real play because they  remember  what  happened  in  their  minds and bodies.

In  Shakespeare's  play  Macbeth  there  is  a  big party  when  the  King  arrives.  That  party  in  not shown on stage. Just after this welcoming party the King is killed. During rehearsal we can let the party happen by improvising it and that will add more knowledge to the characters.

In the same way we can let any situation come to  life  and  add  new  knowledge  to  the  relation between characters.

The situation must be relevant to the characters and the final result. You will find out that when they mention an event they actually attended it will give a deeper meaning to the performance and glow as they remember what happened in their minds and bodies during the improvisation.

## Fast and slow

Aim: To make the actors aware of tempo, rhythm and pauses.

A 'run-through' (refer to 4.27) of the whole play or  specific  scenes  can  be  done  in  exaggerated tempos.

Italian rehearsal is extremely fast and comical.

Russian rehearsal is extremely slow, serious and tragic.

Remember that all the lines and actions must be exactly the right ones.

Local and regional culture can also give you ideas to design rehearsals.

What  if  we  try  to  rehearse  in  Bollywood-style, Western-style, etc.

## The unexpected guest

Aim: To shake the self-confident actors and force them to be present and not ahead of the action.

When rehearsing over and over again our mind starts to feel secure because we know what will happen and what to do and say. We can feel that we are in school and have done our homework. However,  in  a  performed  story,  the  characters have  no  idea  what  will  happen,  unlike  in  real life.  The  response  from  someone  cannot  be predicted.  How  someone  acts  and  what  they say will change our actions and what we say. To prevent this  sort  of  discomfort  the  unexpected guest was invented.

Before  a  'run-through'  the  director  or  leader reminds the group that they must be ready for everything  and  work  together  as  a  team.  Even if  something  unexpected  happens,  they  must relate to it and not pretend it is not there.

Secretly the leader has asked someone to support in this exercise, someone who is told to make an entrance as a new character with a special task. The tasks could be:

- Delivering a package and ask for a signature
- Asking for the phone to help in an emergency
- -Controlling if there is a water leakage everywhere
-  A  religious  leader who wants to have some economical support and never leaves
- The owner of a dog starts to search for his lost pet.

Let  your  imagination  create  the  unexpected visitor.  As  a  leader  you  must  tell  this  character when  to  enter  and  it  should  be  at  the  most dramatic moment.

The actors are playing and they think they know what will happen, but now there is a knock on the door, someone shouts or just enters to fulfill his/her commitment.

When the actors know their characters well, they will  sort  this  out  by  just  adjusting  to  the  new situation  as  characters  and  sooner  or  later  put the  story  back  on  track  again.  If  they  are  good they  will  even  refer  back  to  that  situation  as  a part of the story.

If the actors are not well prepared they will lose concentration, freeze, black out or just privately laugh.

## Freeze!

Aim:  To  make  sure  that  actors  are  using  the characters' subtext.

The leader of the rehearsal can at any time say 'freeze' and everyone on stage stops but keeps their  concentration  and  focus.  The  leader  asks one  or  several  characters  'What  do  you  think about  in  this  situation?  What  do  you  observe? How do you want to take the next step?'

When  you  watch  the  actors  from  outside  you can  sometimes  see  that  their  minds  are  empty or  they  are  thinking 'What will I say next?' This technique reminds them that they have to have subtext from the characters not from themselves. As in real life we are reflecting all the time - so must the characters.

## Shifting roles

Aim: To  collect  information  and  understanding from each other's characters.

Instead of accepting actors directing each other and more important to find solutions to difficult short  sequences  during  rehearsal,  we  can  let two  actors  take  the  role  of  the  other.  This  will give them a deeper understanding of the other character's  viewpoint.  It  can  also  contribute  to new ideas on how to do the scene or sequence. To do this short swap, the actor must of course know each other's lines.

Actors  should  understand  that  it  is  an  egoistic habit to direct other actors and it is normally used to  make  their  own  acting  smoother.  However, if  you  as  a  leader  take  it  seriously,  let  them  not only show what to do but shift the roles. Then the other character can contribute as well instead of being only a passive receiver of critiques.

## Restart please!

Aim: To  remind  the  actors  that  they  must  help each other as a team.

During football matches we often see how team members are unhappy with their own team. They show all kind of disappointments through their gestures. This is not the way an actor should act during  rehearsals.  Everyone  is  there  to  support each  other.  If  something  goes  wrong  everyone must cover up fast and continue. It happens that actors jump 2 pages in the story and everyone must  be  prepared  to  find  a  new  way. To  stand like an idiot, stare and blame someone else is not accepted.

This is a 'run-through' rehearsal from beginning to  end.  However,  if  someone  is  left  without help or the whole group does not find the way to  continue  immediately,  the  director  or  leader from  outside  of  stage  says:  Restart  please!  The group  then  starts  from  the  beginning  again.  If the same happens several times, the order will be repeated: Restart please!

This rehearsal is not meant as a punishment. The leader  or  director  must  be  convinced  that  the group can act as a team and sort out everything. The  whole  group  will,  after  this  experience,  be less stubborn, more secure and confident.

## Silent rehearsal

Aim: To strengthen the contact between actors

This  is  a  very  demanding  rehearsal  technique. It  is  done  without  any  words  spoken  but  by pretending that words were spoken. The concentration and focus on the others must be

100% and the actors learn how to sharpen their interaction with the whole body, ears, eyes and feelings. This technique can only be done in the end of the process and if the actors have reached excellence.

## Relaxed rehearsal

Aim: To create confidence in the whole ensemble

The last week before the 'opening night' , the first performance, let the actors lay down on the stage, relaxed,  use  only  their  inner  movie  to  see  the actions and interactions, and have a conversation imagining the situation to have happened. Allow it  to take some time since it will strengthen the groups and its feeling of togetherness and power.

Technical rehearsal is normally done during the last  week  and  it  lets  the  technical  aspect  and designers take the time to adjust everything. The actors are on stage but they have to stand back and  subordinate  themselves.  They  are  needed but only to show technicalities of what they do. It  might  seem  frustrating  for  them  but  at  the same time it helps them building up a feeling of togetherness as a team of actors.

Preparatory  dress  rehearsal  is  done  as  if  it  was a real performance but it can be interrupted to correct or change minor issues.

Dress  rehearsal  is,  in  the  English  context,  the last time a theatre work is rehearsed before the real performance, when it is performed with the clothes, stage, and lighting exactly as they will be for  the  real  performance.  This  rehearsal  should never be interrupted.

The term dress rehearsal is misleading because all the costumes are normally already, since long time, ready.

## 5.5 Performance and analysis

## Performance analyses

Aim: To use three steps to analyse a performance: describe, interpret and reflect. Duration: 40 minutes The same groups as above

## Here are three rules to start with:

- Wait with values and assumptions - interpret rather than judge!
- Assume that all choices are conscious choices and can therefore be analysed artistically
- Start with yourself and your own experience!

## a.    To  describe  using  the  4 W's  (WHAT, WHO, WHEN, WHERE)

Activity: All students in the audience must have a paper and a pen to be able to make notes during the performance (it is so easy to forget if they get carried away).

The questions they have to think about during the performance and recall after are:

## WHAT (Actions)

- -What did you concretely see and hear?
- -How did the set design look, in details?
- -Where did the characters enter and exit?
- -Were there any props in use?
- -Did props and set change during the performance?

- -Did they use any music?
- -How was sound used in the performance? Light? Voice?
- -How was pace and rhythm used?
- -How did the characters make use of the space?
- -Was there continuity in the play?
- -What is the genre and theme of the play?
- -How did the plot unfold? Did anything change in the end compared to the starting point?

## WHO (Characters)

- -How many people were there on stage?
- -How did they look?
- -What were they wearing?
- -How did they move?
- -Who are they? Relations, age, occupation, gender?
- -What do they seem to want?
- -
- What did they have in common and what distinguished them?

## WHEN (Time)

- -What time did the performance take place?
- -Was the time chronological? Was there any time jumps?

## WHERE (Place)

- -Where did the story take place?
- -What in the set design or actions made me understand where?

## b.  To analyse using WHY

Activity:  Everyone  in  the  class  should  now  be able to describe what they have seen.

In  this  step  they  are  asked  to  follow  up  with the 'WHY?' questions depending on their descriptions.

In the same groups as above they compare their descriptions and they ask themselves 'why?'

## Some examples:

Why  were  the  specific  settings  chosen?  Were they relevant?

Were the characters believable? Why?

Why were the characters dressed exactly in that way?

Why were specific colours, shapes and expressions chosen?

Why did actors move and use their body language in that way?

For  which  purpose  did  characters  change  the tempo of their movements?

How did the characters approach each other and why?

Were  there  changes  in  status  during  the  play? Did it have any consequences?

Did you notice any conflicts and turnings points?

What did the positioning of each character and the  distance  between  characters  convey  about their relationship?

For  which  purposes  did  the  actors  vary  their language/jargon,  tone,  volume,  pitch  and  pace of voice?

## Relations in clash or support

How was the room in relation to the characters?

How was the music in relation to the clothes?

What  was  the  purpose  of  the  music  that  they used?

Was the music enhancing or detracting?

How  was  the  relationship  between  stage  and audience?

Was it played with a 'forth wall' or did they have eye contact with the audience?

Did the audience participate in the performance?

## c.  Reflections

This  is  the  reflection  part  after  watching  the performance.

With which feeling did you leave the performance?

What did the different parts of the performance make you think about?

If you had to change something in the performance - what would it be?

Which  of  the  characters  in  the  performance would you prefer to be and why?

Who would you not want to be?

Was there someone you felt extra sympathy for?

What did you appreciate in the performance?

If this was a movie or TV-series, how would it have been presented differently?

## Constructive critiques

Aim: To conclude process, rehearsing and performing.

Duration: 30+30 minutes

Activity:  Each  group  sums  up  their  discussions from Description, Analysing and Reflections and one group at a time presents their conclusions verbally  to  each  performing  group.  This  part must include both strengths and weaknesses of the performance. The final note must be on how they can further develop.

## Checklist

To be able to summarize your impressions during and after the performance, this matrix can be of help. It is based on the previous article but may let you feel more free to ask and answer your own questions. It is supposed to be a checklist for the memory.  There  are  some  spaces  for  your  own topics if you see something is missing!

|                  | 1. Description   | 2. Analysis   | 3. Reflection   |
|------------------|------------------|---------------|-----------------|
| Plot             |                  |               |                 |
| Theme            |                  |               |                 |
| Obstacles        |                  |               |                 |
| Conflicts        |                  |               |                 |
| Turning points   |                  |               |                 |
| Beginning        |                  |               |                 |
| End              |                  |               |                 |
| Script - lines   |                  |               |                 |
| Characters       |                  |               |                 |
| Character traits |                  |               |                 |
| Status           |                  |               |                 |
| Movements        |                  |               |                 |
| Voice            |                  |               |                 |
| Used props       |                  |               |                 |
| Use of space     |                  |               |                 |
| Set items        |                  |               |                 |
| Costumes         |                  |               |                 |
| Accessories      |                  |               |                 |
| Hair and Make-up |                  |               |                 |
| Set design       |                  |               |                 |
| Sound & Music    |                  |               |                 |
| Lighting         | Lighting         |               |                 |

## Quality assurance

Aim: To assure the quality of a future work with drama  and  theatre  regarding  group  process, rehearsing as well as performing.

With the feedback from the other groups in mind, discuss and formulate a conclusion for:

- Strength(s):  What  we  must  remember  as being successful in performing, rehearsing and in our group process?
- Weakness: What we could have done better in performing, rehearsing and in our groups process?
- What  affected  us  in  a  negative  direction during the whole process and how did we cope with it (or not)?
- What in the whole process will we bear in mind for the future and our development?

Shortly share your group's conclusions to the rest of the class.

Note that the Appendix includes templates that were used during Grade 8 for both performance and group process remarks. These can be used as a initial reminder before using the checklist and other techniques above.

## Love bombing!

Aim: Affirmation of everyone in the class Duration: 30 minutes The whole class

This is a relaxing and joyful activity that can be used after a very demanding process.

The leader puts on ambient music. Everyone sits in a circle with an A4 paper and a marker or pen. In the middle of the paper they write their name inside of a circle.

They then turn to their left and give that person their paper.

That  person  has  to  write  one  positive,  warm and affirmative word connected to that person's name.

The paper then continues its way round the circle with new supporting word written.

Finally, it returns to the owner and now s/he has positivity on a paper.

I  Drama &amp; Theatre  I

## Appendix

- A. Specific learning outcomes in Drama / Theatre grade 7 - 9
- B. Templates for constructive remarks (performance and process)

## Appendix A

## Specific learning outcomes in Drama / Theatre grade 7 - 9

At the end of each Grade learners should be able to:

| Grade 7                                                                                                                                   |                                                                                                                                          | Grade 8                                                                                                                                                             | Grade 9       |
|-------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|
| Improvise a variety of simple stories and situations from their environment Perform by using alternative endings to familiar stories      | Use their own experience and imagination to create different characters and situations Retell or rewrite stories from different cultures | Improvise dramatic stories from a variety of situations, especially life experiences: Use a variety of performance styles, including tableau, mime and script-based | Creating      |
| Identify local stories, themes and characters and compare these with universal stories Relate stories and performances to specific values | Discuss how theatre can reflect and address social issues                                                                                | Use problem-solving skills in groups to dramatise a story with social significance Relate drama and stories to the wider social and cultural contexts               | Arts& Society |

|                                                                                                                                                                                                                            | Grade 7                                                                                                                                                                                                                                                               | Grade 8                                                                                                                                                                                                                              | Grade 9    |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------|
| Create simple scripts and performances in groups Engage with basic blocking and stage movement Demonstrate how voice, expression and movement can create meaning Use appropriate costumes, props and decor for performance | Collaborate in groups to perform and to script scenarios Design and create appropriate costumes, props and decor for performance Perform with an awareness of blocking and space Vary expressions, voice, body movement and posture according to different situations | Perform and dramatise stories from fiction, literature or life experiences in groups using theatre conventions Express emotions in a convincing manner during performance Use body movement, expression and voice to enhance meaning | Performing |
| Reflect on one's performance as well as that of their peers Observe and adhere to principles of safety and practice Show respect and a positive attitude to drama as an art form                                           | Discuss the different structural elements of a story or a performance and its emotions Describe the experience of performing and being part of a production                                                                                                           | Observe, analyse and discuss Observe, analyse and discuss character traits Evaluate a performance using vocabulary pertaining to drama                                                                                               | Responding |

## Appendix B

Templates for constructive remarks (performance and process)

What was good in the performance/presentation?

Why was it good?

Additional positive notes:

What was not good in the performance/presentation?

Why was it not good?

How can it be improved? (Make sure you can verbalize all 3 steps)

What was good in the whole group process?

Why was it good?

Additional positive notes:

What kind of difficulties did we encounter in the group process?

How did it affect us?

How and what kind of solution did we find?

- Mauritius Institute of Education 2021