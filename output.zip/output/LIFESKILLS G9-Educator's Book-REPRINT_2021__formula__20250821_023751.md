<!-- image -->

## LIFE SKILLS

In this image, we can see a colorful image.

<!-- image -->

<!-- image -->

<!-- image -->

Mauritius Institute of Education under the aegis of

Ministry of Education, Tertiary Education, Science and Technology

In this image we can see a colorful image.

<!-- image -->

## Professor Vassen Naëck

- Head Curriculum Implementation, Textbook Development and Evaluation

## LIFE SKILLS PANEL

MAURITIUS INSTITUTE OF EDUCATION

Jay RAMSAHA

- Coordinator (Main Stream &amp; Extended Programme),

- Senior Lecturer

Prema RAMSAHA

- Lecturer

Komal Reshma GUNGAPERSAND

- Lecturer

Pillay Jagambrum NAGAMOOTOO

- Lecturer

## EDUCATORS

R. Shaheen B.M.A JAHANGEER Hasina Banu JANNOO Marie Fleurette L'EVEQUE Anne Helena Francesca MERCURE Valerie WONG KAI IN Marie Christine ROUSSETY-SADOO Varsha Rye RUGHOO

Asheenah SEENGH-ENASSEE

Design

<!-- image -->

Kamla ERNEST Yasin ROSUNALLY

- Chief Technician

- Graphic Designer

Proofreading: Mangala JAWAHEER

- © Mauritius Institute of Education (2021)

## ISBN : 978-99949-53-71-4

## Acknowledgements

Thanks to all the educators who have contributed during the workshops in the different zones to the elaboration of certain activities.

Consent from copyright owners has been sought. However, we extend our apologies to those we might have overlooked. All materials should be used strictly for educational purposes.

<!-- image -->

This textbook is designed for Year 3 of the Mainstream and the Extended Programme (EP). It is based on the Nine Year Continuous Basic Education (NYCBE) curriculum for Grades 7, 8 and 9 which is accessible through the MIE's website, www.mie.ac.mu .

The textbook builds upon the competencies acquired in the first two years of the Programme. The content and pedagogical approaches are adapted to the cognitive level and profile of the students, while also paving the way for them to acquire essential skills and knowledge to move to the next level. The fact that the material is contextualised will certainly make it highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. It took into account feedback obtained  during  community-of-practice  sessions  to  ensure  relevance  and  adequacy.  This  was  an innovative approach which promoted a valuable partnership with Mainstream and EP educators for the development of the resources. We are especially appreciative of the insight brought by educators whose suggestions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard, thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every endeavour involves several dedicated, hardworking and able staff whose contribution needs to be acknowledged. Professor Vassen Naëck, Head Curriculum Implementation and Textbook Development and Evaluation provided guidance with respect to the objectives of the NCF, while ascertaining that the instructional designs are appropriate for the age group targeted. I also acknowledge the efforts of the graphic artists who put in much hard work to maintain the quality of the MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment which is conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of the textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks.

Dr O Nath Varma Director Mauritius Institute of Education

<!-- image -->

This Life Skills &amp; Values Education (LSVE) pack is meant to be used with both Grade 9 extended programme students &amp; Grade 9 mainstream students in the Life Skills &amp; Values Education (LSVE) classes. This material aims at enabling students to develop the appropriate social and behavioural skills that will help them face and deal effectively with the challenges of modern society. The underlying philosophy of the LSVE is to offer  learners with varied learning experiences to further discover who they are, the environment they are living in and how to better cope with real life situations.

Through the activity based approach, students will be actively engaged in dealing with issues pertaining to their own context. They will build resilience, develop self-regulation, increase self-awareness, practise positive relationships and strengthen problem-solving skills. We expect that through playful, creative, critical and reflective activities the students will develop some basic competencies in decision-making and improve their communication skills. We hope that they will also learn how to better cope with their own emotions whilst developing interpersonal skills. The educator should encourage students to participate actively in the activities through inquiry, questions and discussions on the different themes. These processes should help learners understand their own context and facilitate the internalisation of core skills relevant to their lives.

Due to classroom size and/or school consideration, it is recommended that the school administration makes provision on the time-table for the audio-visual room, or any other specialist room (library, hall, art-room) for the purpose and good implementation of the activities. The school administration should ensure that the educator has all the required tools and that he/she is well-prepared for the class / topic or theme of discussion, for the proper implementation of this subject.

Most of the proposed activities are learner-centered where the teacher acts as a guide/facilitator. The level of guidance will vary on the needs and requirements of various types of learners. For those who still have some literacy problems, pictures from magazines can be used instead of writing. In class, the teacher may help the students to find and use relevant vocabulary. For reflective purposes, meditative or relaxing music can be played in the background of the class to create a relaxing atmosphere. The educator must ensure that other classes are not disturbed during the LSVE classes.

For the Life Skills &amp; Values Education (LSVE), learners will be assessed in the three domains: social skills, emotional skills, and cognitive skills. A variety of methods can be used to assess and evaluate students.  The following modes of assessment can be used: records/ evidence of participation, observation schedules, checklists, production of artefacts, portfolios, performance based tasks and practical activities.

## CONTENTS

|    | School-based project _________________________                               | School-based project _________________________                                 | 1   |
|----|------------------------------------------------------------------------------|--------------------------------------------------------------------------------|-----|
| 1. | CreativeThinking Skills _______________________                              | CreativeThinking Skills _______________________                                | 5   |
|    | Educator's Guide in helping the students to develop creative thinking skills | Educator's Guide in helping the students to develop creative thinking skills   | 6-7 |
|    | 1.1                                                                          | Thinking outside the box                                                       | 9   |
|    | 1.2                                                                          | Myrights and myresponsibilities                                                | 13  |
|    | 1.3                                                                          | Myisland, myresponsibility                                                     | 15  |
|    | 1.4                                                                          | Cultural diversity, a rainbow nation                                           | 17  |
|    | 1.5                                                                          | Thinking about humanrights and respect                                         | 19  |
|    | 1.6                                                                          | Sustainable actions for a sustainable environment                              | 21  |
|    | 1.7                                                                          | Sustainability in the classroom and at school                                  | 23  |
| 2. | CriticalThinking _____________________________                               | CriticalThinking _____________________________                                 | 25  |
|    | 2.1                                                                          | Visit of aliens on planet Earth                                                | 27  |
|    | 2.2                                                                          | Class debate                                                                   | 29  |
|    | 2.3                                                                          | What would happen if?                                                          | 31  |
|    | 2.4                                                                          | Thinking about safety on the road                                              | 33  |
|    | 2.5                                                                          | Preventing road accidents                                                      | 37  |
| 3. | Decision Making _____________________________                                | Decision Making _____________________________                                  | 39  |
|    | 3.1                                                                          | The dangers of cigarettes, alcohol and drugs on an individual's health         | 41  |
|    | 3.2                                                                          | Prevalence of drug consumption amongteenagers in our society                   | 43  |
|    | 3.3                                                                          | Impact of drug consumption on the family                                       | 45  |
|    | 3.4                                                                          | Letter writing to organisations/resource persons                               | 47  |
|    | 3.5                                                                          | Production of video clips/role-plays on the damaging effects of drug addiction | 49  |
|    | 3.6                                                                          | Logos/posters on'Synthetic Drugs'                                              | 51  |

| 4.                                                | Coping with Emotions_________________________     | Coping with Emotions_________________________      | 53    |
|---------------------------------------------------|---------------------------------------------------|----------------------------------------------------|-------|
| Educator's guide for coping with emotions         | Educator's guide for coping with emotions         | Educator's guide for coping with emotions          | 54-58 |
| 4.1                                               | Myemotions journal                                | 59                                                 |       |
| 4.2                                               | Emotional                                         | changes                                            | 61    |
| 4.3                                               |                                                   | Moodswings                                         | 63    |
| 4.4                                               | Managing                                          | moodswings                                         | 65    |
| 2.5                                               |                                                   | Myemotional wheel                                  | 67    |
| 5. Problem solving ______________________________ | 5. Problem solving ______________________________ | 5. Problem solving ______________________________  | 69    |
| Educator's Guide for Problem solving              | Educator's Guide for Problem solving              | Educator's Guide for Problem solving               | 70-72 |
| 5.1                                               | Problem solving in everyday life                  |                                                    | 73    |
| 5.2                                               |                                                   | Issues related to being sexually active            | 75    |
| 5.3                                               |                                                   | Awareness on sexually transmitted infections (STI) | 77    |

'Life  skills  are  defined  as  'the  abilities  for  adaptive  and  positive behaviour that enable individuals to deal effectively with the demands and challenges of everyday life' (World Health Organisation). The aim of Life Skills and Values Education as a curricular subject is to equip learners  with  a  broad  set  of  appropriate  social  competencies  and behavioural skills that will help them to deal effectively and positively with  the  challenges  of  modern  society.  LSVE  helps  learners  to  reshape their beliefs, attitudes and actions by taking into consideration the  four  themes  and  the  ten  core  skills  in  the  Teaching  &amp;  Learning Syllabus' .   (MIE 2017).

## School-based project

Through  the  school-based  project  approach as  proposed  in  the  Life  Skills  and  Values Education,  students  are  expected  to  learn by  being  actively  engaged  in  real-world  and meaningful projects. The aim of Project Based Learning (PBL) is to enable students to work on a project over an extended period of time from one week up to a term - to engage them in solving a real-world problem or answering a complex question.

- knowledge and skills from various areas and disciplines will be encouraged.
- autonomous learning through assiduous research to be developed.
- teamwork and preparation of students for a social environment will be reinforced.
- self-evaluation and self-criticism will guide students to see beyond their own ideas and knowledge.
- the ability to plan time for the project will be strengthened in students.

In  an  endeavour  to  diversify  the  kinds  of activities proposed in the activity sheets and to enhance the teaching and learning of Life Skills  and  Values  Education,  project-based learning (PBL) through school-based projects is  an  appropriate  and  appealing  approach. While engaging in these projects, it is expected that:

- oral  and  written  skills  for  the  dissemination of the project will be developed.

We hope that through project work, students will be able to develop essential life skills, be motivated to learn, be role models and active citizens.  In  short,  we  expect  that  through Project Based Learning (PBL), students will  improve  their  life  skills  which  can  be transferred to their personal and social lives.

In this image, we can see a diagram with some text and images.

<!-- image -->

## What are the projects that can be considered?

The  projects  may  cut  across  the  different themes covered in the Life Skills and Values Education  (LSVE)  curriculum.  Themes  like values, human rights education, social and emotional wellbeing, substance abuse, sustainable development, intercultural education, civic  education,  animal  welfare and  road  safety  can  be  used  for  project work.

Students will be assessed in three domains: Social Skills, Emotional Skills and Cognitive Skills.

## Why go for Project Based Learning (PBL)?

Schools have the freedom to choose feasible/practical  school-based  projects  in line with the Life Skills and Values Education curriculum. Schools are encouraged to engage students in projects which will use low-cost  materials/recycled  materials  with the aim of reducing wastage, in line with the philosophy of sustainable development.

Project Based Learning (PBL) engage students in stress-free and hands-on activities  which  will  require  students  to do some basic research. The school-based projects should cater for the different abilities  and  levels  of  learners.  Hence,  a learner-centred  approach  is  being  primed with the belief that skills are acquired when learning  by  doing  is  carried  out.  Through these school-based projects, collaboration with different stakeholders at school level, community  level (e.g parents, Ministry, Municipality, District Council GOs and NGOs) need to be reinforced.

In this image there is a chart with few headings. The chart is in black and white color. There are few boxes in the chart. There are few words written on the boxes. There is a pink color box at the bottom of the image.

<!-- image -->

Furthermore, as a non-core  subject, the assessment  and  evaluation  of  students  for Life  Skills  and  Values  Education  (LSVE)  will be based on the students' participation and performance to the different activities/ projects through attendance records, evidence of participation through observational checklists, production of artefacts, portfolios, performance-based tasks and practical activities.

## How to implement Project Based Learning (PBL)?

Students will be involved in small-scale projects at classroom  level but are also encouraged to go for bigger projects at school level  under  the  guidance  of  their  teachers. Educators will provide the necessary support and  guidance  to  students  to  formulate  the rationale, the aim and the objectives of their project and ensure the time frame is realistic. The educator will  be  expected  to  carry  out consistent monitoring and act as a facilitator.

The assistance of rectors is required to ensure the  smooth  communication  and  collaboration with all stakeholders in the implementation and realization of the different projects. It is recommended  that  students  carry  out  2-3 projects over the year. However, schools can be flexible  in  the  number  of  projects  to  be carried out depending on the availability of time.

## Remember

School based projects should provide opportunities  for  students  to  undertake  an individual study in areas which are of interest to  them.  Through  the  different  activities, students should develop important life skills and values in order to be effective citizens in society  to  better  cope  with  all  the  changes happening around them.

## Useful links:

## A. Project Based Learning

https://www.pblworks.org/what-is-pbl https://www.teachthought.com/projectbased-learning/a-better-list-of-ideas-forproject- based-learning/

## B. Ideas for school clubs

https://blog.prepscholar.com/best-clubs-tostart-in-high-school https://en.wikipedia.org/wiki/High\_school\_ clubs\_and\_organizations

https://www.kidactivities.net/clubs-forschool-age-kids-page-1/

1

## Creative Thinking Skills

Education  is not the learning of facts but the training of the mind to think.

(Albert Einstein)

## General Learning Outcomes:

## Students will be able to:

- think creatively by conceiving and elaborating new ideas and approaches to cope more easily with change.
- appreciate diversity and advocate aesthetic dimensions in diversity for social justice.
- recognise that the premise of civic responsibility lies in action and doings.

## Educator's  Guide  in  helping  students  develop their creative thinking skills.

In this image we can see a person's hand holding a light bulb. In the background there is a black color board.

<!-- image -->

Creative thinking skills use very different approaches  to  critical thinking skills. They involve a much more relaxed, open and  playful  approach.  This  can  require some risk-taking. Creative thinking skills involve:

- looking for different answers.
- allowing  the  learner  to  make  wild and  crazy  suggestions  as  well  as sensible ones.
- not judging ideas early in the process and treating all ideas that are potentially useful equally.
- allowing the students to doodle, daydream  or  play  with  a  theory  or suggestion.
- making lots of suggestions that are unworkable and may sound silly.
- making mistakes.
- learning from what has not worked as well as what did work.

In this section, you will learn more about the processes and what creative thinking really involves.

## A state of mind

Creative thinking skills are as much about attitude  and  self-confidence  as  about talent.  Creativity  is  often  less  ordered, less  structured  and  unpredictable.  As you  are  not  looking  for  'one'  answer, you  are  likely  to  come  up  with  lots  of suggestions that are not  'right' . This can be difficult if you are more used to analytical and logical approaches. It can also be experienced as 'risky' as the prospect  of  making  a  mistake  or  not coming up with an answer is more likely.

## Creativity and emotions

Strong  emotional  self-management  is often needed to allow creative thinking. It  is  important  to  be  able  to  cope  with risk,  confusion,  disorder  and  insecure feelings as you are not progressing quickly.

## Creative thinking techniques

There  is  no  limit  to  ways  of  thinking creatively.  Some  techniques  you  can begin with are:

- brainstorm ideas on one topic onto a large piece of paper.
- allow  yourself  to  play  with  an  idea whilst you go for a walk.
- draw or paint an idea on paper.
- ask the same question at least twenty times  and  give  a  different  answer each time.
- combine a few features of two different objects or ideas to see if you can create several more.
- change your routine. Do things differently. For example: walk a different route to college.
- let your mind be influenced by new stimuli  such  as  music  you  do  not usually listen to.
- be open to ideas when they are still new. Look for ways of making things work  and  pushing  the  idea  to  its limits.
- ask questions such as 'what if….?' Or 'supposing….?'

Reference: Cotrell, S. (2003). Skills for Success. Palgrave, Macmillan Ltd.

The  following  three  themes  have  been identified  to  develop  creative  thinking skills in students:

- intercultural values
- human rights
- sustainable development

## ACTIVITY

1

Thinking outside the box

In this image, we can see a quotation.

<!-- image -->

In this image there is a puzzle. In the background there is a yellow color box.

<!-- image -->

This  activity  aims  at  enabling  students develop  a  creative  mind  set  through different warm up exercises which they can practise and use randomly.

## Learning outcomes

- explore the different ways of triggering creative thinking
- understand  the  concept  of  creative thinking
- practise the concept of being creative

## Warm-up Exercise 1 - Emptying my pockets

## Materials

Whichever  materials  students  have  in their pockets.

If  they  have  nothing,  select  materials from their backpack or pencil case.

## Procedure

1. Set students in groups of 5
2. Ask  each  student  to  empty  his/ her  pockets  on  the  table,  (special precautions should be taken if money is involved).
3. Set all the materials in the middle of the table.
4. Ask  each  group  to  come  up  with a  list  of  functions  /  purposes  for each objects they have (eg. a handkerchief  can  be  used  as  a bandana, purse...) in a time limit of 10 minutes. Encourage students to be creative and think of a maximum of possibilities.
5. Ask each group to share their findings with the class.

## Warm up Exercise 2 - Follow the lead

## Materials

- A4  size  papers  depending  on  the number of students

## Procedures

1. Give each student a sheet of paper
2. Ask  them  to  listen  and  enact  the following instructions:
- stand up (if some students stand  up  holding  their  paper, ask them to sit back and listen carefully to the instructions. then, repeat instructions.)
- hold  the  paper  with  the  left hand over their heads.
- close their eyes.
- fold  the  paper  the  number  of times  they  want  with  closed eyes).
- tear off the upper right hand of the paper.
- tear off the bottom part of the paper (if some students tear the paper completely,  ask  them  to sit down).
- open their eyes.
- look at your sheet of paper.
- compare it  with  the  ones  next to you.
- sit down.
3. Ask students to colour, fold or draw on the paper so as to make it become a unique piece of work.
4. Ask leading questions: Was it hard? Did  you  respect  the  rules?  Why?

- Did you peep on your peers work before doing yours? Why?...
5. Ask  each  student  to  share  their ideas with the class
6. Encourage students to engage in a general discussion about their  views,  ideas  or  comments regarding their piece of work.

## Warm  up  Exercise  3  -  Wedded words

## Procedure

1. Set students in groups of 5.
2. Provide  each  group  with  a  word and ask them to add words to the given word to make combinations that go together. For example 'white' - white house, my old white car, the lovely white bird, and so on.
3. Ask them to brainstorm about their ideas in their respective groups.
4. Share their ideas with the class.

Although  the  list  may  be  exhaustive, here are some word ideas: happy, silent, brave, and so on.

The  learners  are  encouraged  to  write and present their  answers  in  a  creative way (For example through a slam ,song or poem).

## Warm up Exercise 4 - Creatively use me

## Materials

- bandana / handkerchief
- paper (gift paper, tracing paper, plain paper…)
- paper clips
- chairs / table (any furniture available in class)
- toothbrush
- drinking straws
- ruler
- empty boxes
- any other available resources

## Procedure

1. Set students in pairs.
2. Assign an object to each pair.
3. Ask each pair to come with a list of 3-5  different  uses  for  the  assigned object other than its original purpose (about 10 to 15 minutes).
4. Ask each pair to present their ideas to the class.

## Warm up Exercise 5 - Scrambled Sentences

## Materials

- A pack of 5 different set of coloured paper 5cm x 10cm
- Markers / pens

## Procedure

1. Set the students in groups of 5.
2. Provide each group with a pack of 5 different coloured paper.
3. Provide each group with the following commands. Instruct them to hide what they are writing.

Ask  the  students  to  think  about  and write a:

- (a) name of a person / pet (Red).
- (b) verb (present continuous) (Blue).
- (c)  name  of  an  object  or  another person (Yellow).
- (d) a location (can be a somewhere in a room / a city / a village / another country…) - (Green).
- (e) a purpose (Orange).

Create sentences with different colour patterns.

4. Ask each group to put their paper on their desk.
5. The captain then selects one of each coloured paper to build a sentence and read it aloud to the class.
6. Each group can take turns to read the sentences they have created.
7. Ask  each  group  to  reflect  on  the purpose  of  this  activity  and  share their ideas with the class.

## Warm  up  Exercise  6  -  Thinking creatively

## Materials

## paper, markers

## Procedure

1. Set students in groups of 4 or 5.
2. Ask  them  to  brainstorm  on  issues which might be problematic for them (for example: stress related to boyfriends/girlfriends, exams, death, family situations, communication,  peer  pressure…) for about fifteen minutes.
3. Ask  each  group  to  select  1  major problem and write it down on the piece of paper provided.
4. Ask each group to come in front of the class to present their identified problems and leave the piece of  paper  on  the  educator's  desk after  presentation.  (At  this  point no educator's intervention is necessary, all should listen.)
5. When all the groups are done with their presentation, assign each group's identified problems to another group.
6. Ask each group to think creatively about the different possible solutions and  come  in  front  to present their ideas.
7. Once a group has presented their  proposed  solution(s),  allow students  to give their  feedback or comments  on  the proposed solutions.
8. Conclude  this  activity  by  putting emphasis on the possibility of having  different  solutions  for  one problem.

<!-- image -->

## My rights and my responsibilities

To  be  good  and  to  do good is all we have to do. John Adams

In this image we can see a group of people standing on the road. In the background there are buildings, trees, poles, vehicles, and the sky.

<!-- image -->

This activity will enable students to reflect  on  their  civic  responsibilities.  It will  also  encourage  them  to  recognise their civic responsibilities.

## Learning outcomes

- Reflect on one's personal civic duty.
- Come up with creative ways to fulfil their selected civic duty.

## Materials

Bristol paper, kitchen paper, markers

## Procedure

## Part A

1. Brainstorm on their understanding of  the  term 'civic  responsibility'  or 'duty' .
2. Note all the responses on the bristol / kitchen paper.
3. Focus on their sense of belonging to the school's culture.
4. Set the students in groups of 5.
5. Ask  students  to  think  about  new ways through which they can become  more  engaged  in  school life and school activities.
6. Provide students with the materials if  they  want  to  express  ideas  in writing.
7. Provide the necessary time to work on their ideas.
8. Enable each group to present their ideas.

## Part B

9. Ask  students  to  think  about  new and  sustainable  ways  to  extend their  civic/social  engagement  to their neighbourhood/locality.
10. Conclude this activity with a discussion on their thoughts and  feelings  about  how  they  can become  active citizens in their community

## Ending Note

Students' responses written on the bristol paper or kitchen paper should be kept for the next activity.

## Useful link

https://www.kidactivities.net/ community-service-ideas-for-kids-allages/

ACTIVITY

3

My island, my responsibility

A hero is someone who understands the responsibility that comes with his freedom.

Bod Dylan

In this image we can see a group of people, boats, a mountain, water, and the sky.

<!-- image -->

This activity will enable students to reflect and  discuss about  their civic responsibilities.  It  will  also  help  them uncover ways through which their civic responsibilities can  contribute  in the development of the country.

## Learning outcomes

- Enumerate civic responsibilities.
- Discuss how civic responsibilities help in the well-being of their locality and their country.

## Materials

Previously  worked  out  bristol  /  kitchen paper.

## Procedure

1. affix the previously  worked  out bristol / kitchen paper on the white board.
2. set  the  students  in  groups  of  5 and  ask  them  to  think  about  one mini  project  they  can  implement either  as  a  group  or  individually in  their  locality  with  the  aim  of bringing  change  for  the  benefit of their locality and ultimately the development of their country.
3. use a flow chart or mind map and ask  each  group  to  present  their findings.
4. ask  students  to  discuss  how  their project can have a 'snow ball effect' on the development of the island.
5. enable  other  groups  to  comment on each other's presentations.
6.  sum up the activity by brainstorming  on  the  importance of  how  individual  civic  action  can

help in bringing change at a larger scale.

## Ending Note

Students should be encouraged to give shape to their ideas. Teachers can set up clubs at school level for the implementation of the projects.

## Useful links

https://www.volunteermauritius.org/ https://www.intaward.org/mauritius

<!-- image -->

Cultural diversity, a rainbow nation

We may have different religions, different languages,  different  coloured  skins  but we all belong to one Human Race.

Kofi Annan

In this image we can see many umbrellas.

<!-- image -->

This activity will enable students to develop  their  creative  skills.  They  will also  learn  how  to  respect  our  rainbow nation.

## Learning outcomes

- List the ways in which cultural diversity is present in our society.
- Implement creative ways to express and expose our cultural diversity.

## Materials

Projector  /  selected  picture  or  drawn picture,  paint  brushes  /  water  colour paint, bristol paper / kitchen paper, felt pens / water colour / clay.

Materials depend on activities that have been selected.

## Procedure

1. Brainstorm  with  students  creative and artistic ways to showcase cultural diversity in the class/ school/society/work (can be a painting, sculpture or a play).
2. Note  students'  responses  on  the board.
3. Set the students in groups of 4. Ask them to brainstorm on the artwork they could create to showcase Mauritian cultural diversity.
4. Students should be encouraged to write  a  few  sentences  to  explain their art work.
5. Provide students with adequate time (two to three weeks, depending the artwork) and resources (materials) to implement their artwork.
6. Monitor their work closely and provide further  guidance  where needs be.

## Ending Note

The educator is encouraged to work in collaboration with other colleagues like the ICT, Art and Design and Performing Arts teachers.

<!-- image -->

Thinking about human rights and respect

In this image, we can see a poster with some text and images.

<!-- image -->

This activity will enable students to recall  the  principles  of  human  rights and discuss how far these are present in society.

## Learning outcomes

- Reflect on the importance of human rights.
- Propose simple ways to promote and sustain human rights and respect in society.

## Materials

Bristol paper, kitchen paper Coloured paper, markers.

## Procedure

## Part A

1. Set the students in pairs.
2. Give  ten  minutes  for  the  pairs  to recall  what  they  understand  by Human Rights and respect.
3. Ask each pair to write their findings on the whiteboard.
4. Allow for 5 to 10 minutes feedback from all students.
5. Act as a moderator (if need be).
6. Conclude  this  activity  by  asking each pair to think about an issue  they  would  want  to  work on  regarding  human  rights  and respect.

## Part B

1. Ask each student to draw a map of his/her  own  town  or  village  with their homes and any other;
2. (a)  major public buildings (e.g., post office, hospitals, town/village hall, schools, places of worship, police station, and so on) and
3. (b)  any other places that are important to the community (e.g., grocery stores, cemetery, cinemas, gas stations).
2. When  each map  are completed, ask  students  to  analyse  their  map from  a  human  rights  perspective  (Example What  human  rights  can you  associate  with  the  different places on the maps? )
3. Students are encouraged to compare their  maps  and  discuss  how  some places  are  or  not  associated  with human rights principles.
4. Students  are  encouraged  to  come up with new and innovative ideas in terms of how to promote and sustain human rights and respect in society

## Ending Note

Prior  to The  educator  is  encouraged  to carry out the activity over different days.

## Useful links

https://www.youthforhumanrights. org/what-are-human-rights/universaldeclaration-of-human-rights/ articles-1-15.html

<!-- image -->

Sustainable actions for a sustainable environment

In the image there is a white background with a pink border. On the white background there is a text written in black color.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

This activity will enable students to think about  the  importance  of  sustainable living and devise an 'Eco-Friendly Alphabet Chart' .

## Learning outcomes

- Explain  the  concept  of  sustainable living.
- Discuss the importance of sustainable practices  for  the  protection  of  the environment.
- Design an original 'Eco-Friendly Alphabet Chart' .

## Materials

## Kitchen or bristol paper, markers

## Procedure

## Part A

1. Brainstorm on students' understanding of the term 'sustainable living' .
2. Note all students responses on the whiteboard.
3. Set the students in groups of 3 -5.
4. Ask  them  to  use  a  mind  map/ diagram/ drawing to:
5. (a)  illustrate / write aspects of their  lives  which  they  believe might not be a good example of sustainable living.
6. (b)  illustrate  /  write  original  and sustainable practices which are more environmental friendly.

## Part B

5. Enable  each  group  to  present  their ideas.
6. Encourage students to write short sentences on ways to adopt sustainable living.
7. Students will combine their sentences  and  produce  an  'EcoFriendly Alphabet Chart' which would  reflect  the  students  ideas of good practices for a sustainable living.
8. Conclude this activity with a discussion  on  the  importance  of adopting a sustainable lifestyle for  their  own  wellbeing  and  the wellbeing of the planet.

## Ending Note

The teacher  can  make  reference  to  the UNESCO document on Sustainable Development Goals (SDGs) 2015 [www.un.org / sustainabledevelopment. un.org].

The  teacher  is  encouraged  to  use  the links  below  or  any  other  resources  to strengthen students' knowledge and understanding of sustainable living.

## Useful links

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=gTamnlXbgqc https://www.conserve-energy-future. h t t p s : / / w w w . y o u t u b e . c o m /

com/15-ideas-for-sustainable-living.php watch?v=kZIrIQDf1nQ

<!-- image -->

Sustainability in the classroom and at school

In this image there is a poster with a circle on it.

<!-- image -->

In this image there is a green color recycling circle.

<!-- image -->

This activity will enable students to act as agents of change and initiate sustainable practices in their classroom and at school level.

## Learning outcomes

- Discuss creative and innovative ideas in developing a culture of sustainable development at school.
- Propose an implementation plan for sustainable practices at school.

## Materials

## Board / whiteboard, markers

## Procedure

1. Ask students to look and describe what they see.
2. Start  a  class  discussion  upon  the following questions.
- how do you perceive your classroom?
- is  it  a  conducive  environment for learning?
- what is an ideal classroom according to you?
- what  can  you  do  to  improve your classroom environment?
3. Write  students'  responses  on  the board / whiteboard.
4. Review students' ideas about improving their classroom environment.
5. Select 4 or 5 creative and practical ideas together for further implementation.

## Ending Note

Please  consult  with  the  administration before the implementation of any project at school level.

## Useful links

https://carbontrack.com.au/blog/ sustainability-classroom/

http://mrkempnz.com/2018/08/6-ideasfor-a-sustainable-classroom.html

2

## Critical Thinking

Critical  thinking  is  the  intellectually disciplined process of actively  and skillfully conceptualizing, applying, analyzing, synthesizing, and/or evaluating information gathered from,  or  generated  by,  observation, experience,  reflection,  reasoning,  or communication,  as  a  guide  to  belief and action.

The Foundation for Critical Thinking

## Learning outcomes

## Students will be able to:

- think critically by analysing information objectively
- think clearly and rationally

Critical thinking is clear, rational, logical, and  independent  thinking.  It  is  about improving thinking by analyzing, assessing,  and  reconstructing  how  we think.  It  also  means  thinking  in  a  selfregulated and self-corrective manner. It is  thinking on purpose. Through critical thinking,  students  learn  to  formulate their own opinions and draw conclusions regardless of the influence of others. Critical thinking involves mindful communication,  problem-solving,  and a  freedom  from  egocentric  tendency. Critical  thinking  can  be  applied  to  any kind of subject, problem or situation. Critical thinking is about questioning. It is using the what and why questions.

## Strategies for developping critical thinking skills

1. Ask  open-ended  questions  which will encourage students to think and analyse different points of view.
2. Brainstorming  can  also  be  used  for the development of critical thinking skills.
3. Use  statistics  and  available  data  or information on themes of discussion. Giving  facts,  figures  and  important information on related themes or  topics  arouse  the  curiousity  of students  and  encourage  them  to explore different alternatives.
4. Pose problems to be solved.
5. (To  develop  critical  thinking  skills assign students specific  problems and  let  them  think  about  ways  to solve the problems.).
5. Role-Play.

Role-play is a good method  for practising critical thinking skills. (When  students  get  into  the  shoes of  others,  this  allows  them  to  be analytical and understand others.).

6. Drawing.

(Expressing ideas using drawing or  sketches  can  also  help  in    the development of critical thinking skills.).

In this image, we can see a picture of a road. There is a text on the image.

<!-- image -->

This activity will encourage students to analyse who they are as individuals and as  part  of  a  society.  It  is  about  looking at what we do or what we value from a fresh  perspective.  Students  will  explore situations they live daily. The activity also aims  at  enhancing  the  communication skills of students.

## Learning outcomes

- Identify  common  issues  faced  by adolescents in their lives.
- Analyse the issues faced by adolescents.
- Think critically  about  different  ways to deal with the identified issues.

## Materials

Scenarios of issues faced by adolescents, interview questions, paper and pencil.

## Procedure

1. The educator informs students that they  will  be  working  in  pairs  for this  activity  and  that  they  will  be provided  with  two  scenarios.  For each  scenario,  one  student  will  be the alien asking questions and the second one will be the human being answering the questions.
2. Give the two scenarios along with the set of questions to the different pairs.
3. Allow time for students to complete the interviews.
4. Ask students to present the answers they have received from their peers.
5. The educator highlights the importance of protecting the environment to decrease the effect of  climate  change.  The  educator also proposes friendly ways to resolve conflict and bullying at school level.
6. Ask  students  to  write  a  scenario based  on  an  event  which  they have lived and devise questions to critically analyse the situations.

## Ending Note

If  students  have  difficulty  to  read  the scenarios, the educator can narrate the  scenes  in  the  preferred  language of  students.  Educators  are  encouraged to  develop  other  scenarios  which  are related to the real life situations of students.

## Scenario 1

You are conducting a tour for aliens who are visiting earth and observing humans. You are in their spaceship when you fly over the North Pole and see an ice berg which is melting and a baby polar bear drifting away from his mother.

Try answering these questions:

- (a)  Why  are  the  ice  bergs  melting  so quickly?
- (b)  What are the consequences of climate  change  on:  animals,  human beings and on the ecosystem?
- (c)  How  can  you  contribute  to  prevent climate change?
- (c)  What would happen if the sea level rises and your island disappears?

## Scenario 2

You are chatting with a group of aliens and guiding them towards your school. On  the  way  two  boys  are  fighting.  An alien  turns  to  you  and  asks  you  these questions:

- (a)  Why are they fighting?
- (b)  Is this the only way to resolve conflict?
- (c)  How  do  you  decide  who  wins  and who loses?
- (d)  What impact does violence have on  education  and  the  daily  lives  of students?
- (e)  What can you do to prevent violence and bullying at school?

<!-- image -->

## Class debate

The great majority of  men  and  women,  in ordinary  times,  pass  through  life  without  ever comtemplating  or  criticising,  as  a  whole,  either their own conditions or those of the world at large.

Bertrand Russell

In this image we can see the buildings.

<!-- image -->

In  this  activity,  students  will  learn  the importance of being able to take a stance on  an  issue  and  defending  that  stance with logical reasoning.

## Learning outcomes

- Present their point of view on different issues.
- Defend  their  stance  with  logic  and reasoning.

## Materials

Issue  for  debates  already  written  on  a piece of paper with choice of option, pen and paper.

## Procedure

1. The  educator  informs  students  that they will be working in groups of 4/5.
2. The educator will then ask one student  from  each  group  to  select  a chit randomly.
3.  Afterwards students will work on their issue  and  find  arguments  to  defend their  point  of  view. They  will  also  find counter  arguments  to  convince  the opposing  group  why  their  decision  is the best.
4. The educator will explain the rules for the  debate  emphasising  on  respect for opinions of others.
5.  After each debate, the educator will  highlight  the  ethical  and  moral dimensions  related to the different issues.

## Ending Note

The language used for the debate can be decided  by  the  educator. The  topic  for debate can also be decided by educator. It does not have to be the ones proposed.

## List of possible issues for debate:

1. You  find  a  golden  chain  in  the school canteen near a table in the corner What will you do?
2. Option 1 : give  it  to  the  usher  or rector. Option 2: keep it and keep quiet.
2. Your  friend  is  stressed  about  an upcoming  test.  You  already  took the test and got very good marks. What will you do?
4. Option 1: give the answers to your friend.
5. Option 2: not get involved at all.
3. The  PE  educator  has  caught  two of his star basketball players vandalising  school  property.  The rule is that they must be suspended. If that happens their team will lose the  upcoming  semi-finals.  If  the coach  keeps  quiet,  they'll  surely win, but he could lose his job.

Should the coach:

Option 1: suspend the two players and obey the rules.

Option 2: pretend he never saw them.

4. A friend tells you that he/she has been receiving anonymous bullying messages online. You suspect  that certain people  are guilty.

Would you:

Option 1: tell your friend just to ignore them.

Option 2: encourage them to report the abuse.

ACTIVITY

3

What would happen if?

Life belongs to the living, and he who lives must be prepared for changes.

Johann Wolfgang

In this image we can see a group of people standing in the center.

<!-- image -->

This activity is designed to help student think and discover new ways of looking at  the  world.  Students  will  try  to  find answers to different situations.

## Learning outcomes

- Think critically about different situations.
- Develop their writing skills.

## Materials

## Pen and paper

## Procedure

1. The educator informs students that they are going to do a fun activity today. They must write answers to the questions as quickly as possible.
2. The  educator  will  start  asking  the questions one after the other in the following order:
3. (i) what  would  happen  if  there were  suddenly  no  computers, tablets, or phones anywhere on earth?
4. (ii)  what would happen if we had  to  live  in  a  world  without electricity?
5. (iii) what would happen if you woke up one morning to discover you had  changed  into  a  cartoon character?
6. (iv) what  would  happen  if  all  the animals in the world could suddenly communicate with us in our own language?
3. Students  will  share  their  answers with the whole group and explain why  they  have  opted  for  these answers.
4. The educator will highlight the main ideas proposed by students.

ACTIVITY

4

Thinking about safety on the Road

In this image there is a white background with a pink circle in the middle. There is a text on the left side of the image.

<!-- image -->

In this image, we can see a yellow color sign with black borders. There are many lines of lights on the road.

<!-- image -->

This activity aims at engaging teenagers in developing consciousness about incidents  on  roads.  It  will  also  enable students  to  critically  examine  attitudes and  different  types  of  behaviour  with respect to road use and danger.

## Learning Outcomes

- Discover different cases of road incidents through short stories.
- Critically  analyse  attitudes  and  the behaviour of different individuals on the road.

## Materials

Whiteboard,  markers,  stories  related  to incidents on the road

## Procedure

- Divide the class in groups of five and assign one story to each group.
- Ask the students to read the stories and guide them to identify important points / ideas from each story.
- Ask students to analyse the attitudes and behaviour of the different characters.
- Ask  students  to  change  the  story to  show  a  positive  change  in  the attitudes and behaviour of the different characters.

## Story 1:  Toto and the zebra crossing

In this image we can see a few vehicles on the road.

<!-- image -->

Toto is an eight-year-old boy. He really likes school life as he enjoys learning and playing with  his  friends.  His  grandfather  Jamie always holds his hand while accompanying him to school as they have a few streets to cross. One day, while returning home, a car goes through without respecting the zebra crossing and almost hits them. Toto and his grandfather are frightened.

## Short Story 2: Joe and the traffic lights

In this image there is a black background. On the black background there is a white border. In the center of the image there are three objects.

<!-- image -->

One day, Joe, the new car driver meets Mike. Mike  is  an  experienced  driver.  They  both start to drive on the road. Joe is very excited, as this is his first outing. At a traffic signal, the red light is on but Joe does not stop. Seeing this, the traffic police officer gets angry and stops  Joe.The  traffic  police  officer  warns Joe  not  to  commit  further  mistakes  whilst driving and leaves.

## Short Story 3: Sue's Story - Drinking or Driving

In this image, we can see a person sitting in a car. We can also see a steering wheel, seat belt, seat, and a person holding a handbag. We can also see a red color circle with a white border.

<!-- image -->

At a party, Sue has been drinking alcohol, along with her friend. At around 11pm, Sue tells her friend that she is leaving. Her friend asks her if she can drive her home. Sue accepts. But, on the road, she can barely keep control of the car. She is drowsy. On waking up, all she remembers is she was screaming. Later, she learns that her friend has been badly injured. Sue feels upset because she is responsible for all this.

Short Story 4: Tama and the seat belt

In this image we can see a person is driving a car.

<!-- image -->

Tama: Mom and Dad like it when I wear my seat belt. They make sure my seat belt is fastened as soon as I get in the car.

Yupi: What is a seat belt?

Tama: A seat belt is used to secure someone in the seat of a motor vehicle.

Yupi: Do all cars have seat belts?

Tama: Yes.

Yupi: Why are seat belts so important?

Tama: Seat belts help to keep us safe while travelling. It makes me very happy when I wear my seat belt so I know I am safe in the car.

Yupi: Do your parents also wear their seat belts?

Tama: Yes, of course.

Yupi: Do you unbuckle your seat belt during your road trip?

Tama: No, I always wait for my parents to let me know when the car has stopped and it is safe to take off my seat belt.

Yupi: Oh, this is so important what you have shared with me, Tama. Thanks, a lot. Tama: You are welcome.

## Short Story 5: The girl who did not dress bright in the dark

Renee always likes to look her best. One night, she did not wear the bright vest when she was out at night. Unfortunately, other vehicles could not see her crossing. One car hit her and left her with bruises. Since then, she has regretted not having been more prudent on the road at night. Her advice to all is simple. 'Dress bright. Be seen !' .

In this image we can see a group of people.

<!-- image -->

In this image, we can see a car on the road. There are some buildings and lights. We can see the text on the image.

<!-- image -->

This activity is meant to make teenagers reflect on the causes of road accidents in Mauritius. It focuses on the consequences of  road  accident  and  ways  to  prevent them from occurring.

## Learning Outcomes

- Analyse the causes of road accidents.
- Discuss  the  consequences  of  road accidents.
- Reflect on ways to prevent or minimise road accidents.

## Materials

Statistics on road accidents, newspaper articles  on  accident  cases  with  some causes and consequences, Bristol paper, colouring  pencils,  old  magazines  and glue

## Procedure

1. Distribute  the  newspaper  articles to  students  working  in  groups  of 4/5.
2. Ask students to analyse the causes and consequences of the road accidents in the newspaper articles.
3. Based on the their findings, students will be guided to develop
4. a mindmap illustrating the causes  and  consequences  of  road accidents.
4. Students  present  their  mindmaps to class.
5. Students prepare a poster to illustrate ways in which road accidents can be prevented.
6. Each group presents their work in front of the class.
7. Educator sums up the activity.

## Ending Note

The posters can be displayed at school level to sensitise students on the dangers on the road and ways of preventing road accidents.

## Decision Making

<!-- image -->

Decision  making  and problem solving are not the same. To solve a  problem,  one  needs to  find  a  solution.  To make  a  decision,  one needs to make a choice

Michael J. Marx

## Learning outcomes

## Students will be able to:

- make the right decision among possible alternatives
- understand the process of decision making
- recognise  potential  consequence  on  people's  health  and  future  plans  when taking decisions

<!-- image -->

The dangers of cigarettes, alcohol and drugs on an individual's health

In this image we can see a circle with some text and some drawings.

<!-- image -->

## Dangers of Cannabis

| Short-Term                                        | Long-Term                                  |
|---------------------------------------------------|--------------------------------------------|
| ￭ Mood shifts.                                    | Lower IQ level. ￭                          |
| ￭ Impaired body movement.                         | Decline in verbal ability. ￭               |
| ￭ Seeing vivid colours or hearing strange sounds. | Onset of breathing problems. ￭             |
| ￭ Problems with decision making.                  | Risk of greater heart attack. ￭            |
| ￭ Onset of hallucinations.                        | Child development problems, ￭ if pregnant. |
| ￭ Onset of delusions.                             | Possibility of suicidal thoughts. ￭        |
| ￭ Possibility of psychosis.                       | Onset of anxiety and depression. ￭         |

This activity is meant to alert teenagers about  the  harmful  effects  of  cigarette, alcohol and drugs on their health.

## Learning outcomes

- Recognise that cigarette, alcohol and drugs are harmful to health
- Discuss the harmful effects of cigarette, alcohol and drugs on health

## Materials

whiteboard, markers, bristol paper, blue tack

## Procedure

1. Start the lesson with a recap of different types of drugs affecting society. (Refer  to  Grade  7  part  II  Lifeskills pack, Activities 10-11)
2. Assemble students in groups of 4-5 and identify a group leader for each group.
3. Ask each group to work on the harmful effects of one particular substance. For example:
- group  1  works  on  the  harmful effects of cigarettes on one's health.
- group  2  works  on  the  harmful effects of alcohol on one's health
- group  3  works  on  the  harmful effects of synthetic drugs on one's health.
- group  4  works  on  the  harmful effects of cannabis on one's health.
4. Ask students to discuss the harmful effects of each substance assigned to their group.
5. Request  the  group  leader  to  jot down  the  main  points  about  the harmful effects of the substance.
6. Invite each group to give a presentation on the harmful effects of  the  substance  assigned  to  their group.  All  the  groups  can  choose

how  they  would  like  to  present their findings.

## Ending Note

Visuals like newspaper cuttings, pamphlets from the Ministry of Health, information on the internet can be used to assist students in their group work.

## Useful Links

https://www.betterhealth.vic.gov.au/ health/HealthyLiving/How-drugs-affectyour-body h t t p s : / / w w w . y o u t u b e . c o m / watch?v=AJQygDDwtlU

http://health.govmu.org/English/ Documents/2018/National.pdf https://www.who.int/substance\_abuse/ facts/cannabis/en/

ACTIVITY

2

Prevalence of drug consumption among teenagers in our society

In this image, we can see a poster with some text and images.

<!-- image -->

Through this activity, discussion will be initiated around the prevalence of drugs consumption  among  teenagers  in  our society. This activity will also encourage students to discuss alternatives to harmful substances like cigarettes, alcohol and drugs.

## Learning outcomes

- Discuss the reasons why some teenagers consume cigarettes, alcohol and drugs.
- Explain  how  consumption  of  such substances  can  life  threatening  for teenagers.
- Identify healthy alternatives to these substances.

## Materials

Bristol paper, A4 paper and blue tack

## Procedure

Present  the  following  headlines  to  the students:

1.  La drogue dans les écoles est la pire des  choses  qui  puissent  arriver  à un pays en progrès (Le Mauricien, 30 Sep 2018)
2.  Phénomène : Les drogues synthétiques peuvent être mortelles (Défi Media, 2017).
3.  Drogue  :  71  jeunes  arêtes  depuis 2015 (L'Express, 7 Septembre 2016).
4.  La drogue de synthèse : Les jeunes en première ligne pour son élimination  (Défi  Media,  24  Sep 2018).
5.  Maurice  :  Les  consommateurs  de drogue dure sont de plus en plus jeunes (indien-ocean-times.com)
6. Consommation de drogue en milieu scolaire  :  Quatre  élèves  suspendus (mbcradio.tv, 25 Sep 2018).
7. Allow students to reflect individually on  the headlines for five to ten minutes.
8. Ask  each  student  to  identify the reasons  why  some  youngsters  take drugs nowadays.
9. Ask each student to think of three  possible  effects  of  drugs  on teenagers.
10. Ask students to present their individual reflections to the class.
11. Encourage  each  student  to  express his/her opinions and to suggest healthier  alternatives  to  substance abuse.
12. The educator may encourage students to design posters/ pamphlets/slogans/slams on the theme below or on a similar theme.

'The Youth of today without cigarettes, alcoholic drinks and drugs'

## Ending Note

Students should be encouraged to gather  information  from  the  internet, newspaper,  parents,  governmental  and non-governmental organizations on the alternatives to substance abuse.

## Useful links

https://www.who.int/tobacco/en/

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=lhmHmlIKjps https://www.who.int/tobacco/research/ youth/health\_effects/en/

https://www.who.int/tobacco/ healthwarningsdatabase/en/

## ACTIVITY

3

## Impact of drug consumption on the family

In this image we can see a picture of a circle with some text written on it.

<!-- image -->

In this image we can see a person's hand is holding a pair of scissors.

<!-- image -->

This activity is meant to help students realise the extent to which drug consumption can have a negative impact on social relationships within the family.

## Learning outcomes

- Identify some examples of how drug consumption can change someone's behaviour.
- Discuss how drugs can damage the family bond.
- Analyse  how  drugs  can  have  an irreversible impact on family life.

## Materials

Whiteboard, markers, bristol paper and blue tack

## Procedure

1. Assemble students in groups of 4-5 and identify a group leader for each group.
2. Provide each group with bristol paper  on  which  they  will  draw  a mind  map  to  show  how  substance abuse  changes  a  person's  life  over time.
3. Request  each  group  to  discuss  the negative impact of substance abuse on  a  person's  life  and  how  his/her family may suffer from this situation.
4. Invite each group to make a presentation of their mind map showing how substance abuse has a negative impact on the whole family. Students can also present their findings through a role play.

## Ending Note

The educator can use the following links to show the devastating effects of substance abuse.

## Useful links

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=Y18Vz51Nkos

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=shtRXgefI9U

<!-- image -->

Letter writing to organisations/ resource persons

In this image we can see a logo and some text.

<!-- image -->

In this image we can see a person wearing a jacket.

<!-- image -->

This activity will enable students to identify and communicate with Governmental  and  Non-Governmental Organisations  to  help  them  develop  a better knowledge and understanding of issues  related  to  cigarette,  alcohol  and drug  consumption  amongst  youth  of our  Republic.  This  activity  also  aims  at developing oral and writing skills.

## Learning outcomes

- Recognise  that  smoking  cigarettes and  consuming  alcohol  before  the age of 18 is illegal.
- Discuss the legal implications of smoking, alcohol and drug consumption.

## Materials

Whiteboard markers, A4 paper and pens.

## Procedure

1. Assemble students in groups of 4 and select a group leader for each group.
2. Provide  each  group  with  a  letter template.
3. Request each group to write a letter to a chosen organisation to:
4. (a)  ask for information about  the harmful effects of cigarettes, alcohol and drugs.
5. (b) come to school to give a talk on substance abuse.
6. (c)  create awareness about the illegal aspects  of  smoking,  alcohol  and drug consumption in society.
4. Inform each group that their letter  will  be  sent  to  the  selected organisations.
5. Ask  each  group  leader  to  write  the names  of  all  group  members  and their grade at the end of the letter.
6. Collect  the  letter  from  each  group and allow each group leader to read their letter to the class.

## Ending Note

The educator may select the best letter(s) and  these  can  be  sent  to  the  chosen organisation(s)  through  management. The educator can refer to the addresses of  the  organisations  provided  below. The teacher can also extend this activity by inviting students to read their letters during school assembly.

## Useful links

http://www.actogether.mu/fr/trouverune-ong

## Some  example  of  important  contact details that can be considered

- Anti Drug &amp; Smuggling Unit (ADSU) Les Casernes, Port-Louis Tel: 211 0877

•

Brigade des Mineurs

Tel: 2134093

- Police Crime Prevention Unit, Sir Virgil Naz St, Rose Hill Tel: 454 0766
- Youth Counselling Service (Rodrigues)
- Tel: 831 5000
- Brigade pour la Protection des mineurs (Rodrigues) Tel: 832 4180

In this image, we can see a person holding a cigarette and a hand.

<!-- image -->

This activity aims at developing students' understanding  of  the  damaging  effects of drug addiction.

## Learning outcomes

- Create short video clips on the damaging effects of substance abuse on drug users and their surroundings.

## Materials

Markers, phone, paper and pens.

## Procedure

1. Inform students that they will participate  in  the  creation  of  short video clip/role play on the damaging effects  of  drug  addiction  on  drug users and their surroundings.
2. Assemble students into groups of 4-5 and identify a group leader, a group recorder and actors in each group.
3. Assign each group with a scenario:
- scenario 1: effects of drug addiction on the family.
- scenario 2: effects of drug addiction on health.
- scenario 3: effects of drug addiction on education.
- scenario 4: effects of drug addiction on finance.
4. Ask  students  to  share  their  ideas and write a script for their respective groups.
5. Prepare the students and help them to enact the scenario.
6. Ask  each  group  recorder  to  record the scenes.

## Ending Note

Prior  to  students'  participation  in  the video  clip/role  play,  it  is  recommended that  the  educator  seeks  the  consent  of parents and the school management. If the class size is small, only one clip/role play can be produced. The teacher may request students to produce either a role play or a short video.

## Useful links

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=eDp8tEVeSVs

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=BYxMpWKFI50

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=Zoc63rWguP8

<!-- image -->

## Logo/poster on 'Synthetic Drugs'

In the center of the image there is a blue rectangle. On the left side of the image there is a blue swoosh. On the right side of the image there is a blue text.

<!-- image -->

In this image, we can see a white color box with some text and images.

<!-- image -->

This  activity  aims  at  engaging  students in  the  creation  of  a  logo/poster  on  the theme 'Say No to Synthetic Drugs' .

## Learning outcomes

- Design a logo/poster on the theme 'Say No to Synthetic Drugs'
- Develop and enhance communication and presentation skills

## Materials

Bristol paper, coloured pencils and paint, paintbrush

## Procedure

1. Assemble  students  in  groups  of  5 and provide each group with a bristol paper.
2. Explain to students that they have to design a logo on one of the following themes:
- Think  Health,  Say  No  synthetic Drugs.
- Synthetic drugs ruin lives.
- Life does not rewind with synthetic drugs.
3. Create  the  logos/posters  using  the bristol paper provided.
4. Ask  all  the  groups  to  present  their logos/posters during the school assembly with a brief explanation.

## Ending Note

Prior to this activity, ask students to bring the materials listed above. Students may propose to design their logos/posters on other related themes.

The best logo/poster could be used for mural painting /as logo for the existing Health  Club/  creation  of  a  new  Health and Wellness Club.

The educator may refer to the following link to enhance understanding on effects of substance abuse.

## Useful Links

h t t p s : / / w w w . y o u t u b e . c o m / watch?v=FN78E\_iaITE

4

## Coping with Emotions

Feelings are much like waves,  we  can't  stop them from coming but we  can  chose  which ones to surf

(UNKNOWN)

## Learning outcomes

## Students will be able to:

- appreciate and cope with emotional changes during adolescence.
- identify strategies to manage their emotions in everyday life.
- deal with their own emotions in a multicultural context.

## Educator's guide for coping with emotions

In this image we can see a collage of images.

<!-- image -->

Coping  with  emotions  is  an  important component  of  the  social  and  emotional development in an individual. As adolescents, Grade 9 students too are undergoing physical, social and emotional  changes.  These  changes  are often  accompanied by various emotions which they have to handle. Therefore, as educators,  we  should  be  able  to  create emotional  awareness  and  help  students to self-regulate their emotions.

The  activities in this unit will allow students to address two important aspects of social and emotional development as listed below.

## Emotional awareness

It  will  help  students develop the ability to recognise and understand their own feelings and actions and those of other people, and how  their feelings and actions affect themselves and others.

## Self-regulation

It will empower students to develop the ability to express thoughts, feelings, and behaviour  in  socially  appropriate  ways. Learning  to  calm  down  when  angry  or excited and persevering during difficult tasks are examples of self-regulation.

According  to  Sylwester  (1995)  emotions are very important in the education process because  they drive attention, which in turn drives learning and memory. To be able to cope with emotions, students  should  understand  what  are emotions. The first part of this guide will focus on developing an understanding of emotions.

In this image we can see a person. In the background there are trees.

<!-- image -->

## Understanding Emotions

Emotions are a central part of our core consciousness. Emotions provide information  about  one's  core  goals  and needs.  There  are  two  broad  systems  of emotions: negative and positive.

there are good and bad ways of expressing (or  acting  on)  emotions.  Learning  how to  express  emotions  in  acceptable  ways is  a  separate skill. Managing emotions is built on the foundation of being able to understand emotions.

Negative emotions signal threat to needs and goals and energise avoidance whereas positive emotions signal opportunity to  meet  needs  and  goals  and  energize approach.

Emotions  come  and  go.  Most  of  us  feel many different emotions throughout the day. Some last just a few seconds, others might linger to become a mood.

Emotions can be mild, intense, or anywhere  in  between.  The  intensity  of an emotion can depend on the situation and on the person.

There are no good or bad emotions, but

Emotional awareness helps us know what we need and want (or don't want!). It helps  us  build better relationships. Being aware of our emotions can help us talk about feelings more clearly, avoid or resolve  conflicts  better,  and  move  past difficult feelings more easily.

Some people are naturally more in touch with their emotions than others. The good news is,  everyone  can  be  more  aware  of their  emotions.  It  just  takes  practice.  But it's worth the effort. Emotional awareness is the first step toward building emotional intelligence,  a  skill  that  can  help  people succeed in life.

In this image we can see a yellow color smiley face.

<!-- image -->

## Emotional changes during adolescence

appropriate life choices.

To  help  our  students  to  develop  an awareness and cope with different emotions  ,  we  should  understand  the emotional changes during adolescence. Due to hormonal changes, adolescents have 'mood swings' and frequently change  their  temperament.  They  tend to have more intense and wide-ranging emotions  than  children  or  adults,  and they exaggerate their problems as well.  It's  common  to  see  adolescents fluctuating between feeling like they're on top of the world one  moment and  being  depressed  the  next.  These emotional  changes  affect  their  school performance, appearance, choice of friends and  their ability  to  make

Adolescence is a time of emotional stress in  the  house  as  adolescents  become increasingly independent and their desires  often  clash  with  the  wish  and requests of their parents. Adolescents are inclined  to  take  risks,  whereas  their  parents are interested in their safety. Adolescents tend to act impulsively, without thinking about the consequences, and they make decisions based on what feels good at a given  moment.  Even  when  parents  try to  explain  their  own  decisions  based on their life experience and knowledge, adolescents often react emotionally without  even  listening  to  the  reasons. Therefore, behaviour issues and rebellion are common. However, although unwelcome,  their  defiance  is  necessary in  order  for  the  adolescents  to  develop their unique identity.

In this image we can see a collage of photos.

<!-- image -->

Adolescents lean toward making intimate relationships with friends while distancing themselves from their family. In addition, their perception  of  themselves  is tied to  how  others  view  them.  Adolescents may think they are constantly being watched  and  evaluated,  making  them overly  concerned  with  their  appearance. Although adolescents crave independence from  their  family,  insecurity  and  social pressure cause them to strive to fit in with the crowd in order to be accepted.

Along with independence and emerging identity, adolescence is marked by the beginning of romantic interests. However, sexual emotions induce anxiety and  these  underlying  emotions  often distract  adolescents  from  their  day-today activities, such as school and sports.

The following changes can be noticed in students:

- They show strong feelings and intense  emotions at different  times. Moods  might  seem  unpredictable.

These  emotional  ups  and  downs can  lead  to  increased  conflict.  The adolescent's brain is still learning how to control and express emotions in a grown-up way.

- They are more sensitive to the emotions  of  other  young  people get better at reading and processing other people's emotions as they get older. While they are developing these skills, they can sometimes misread  facial  expressions  or  body language.
- They are more self-conscious, especially about their physical appearance.  Teenage  self-esteem  is often affected by appearance - or by how  teenagers  think  they  look.  As they develop, teens might compare their  bodies  with  those  of  friends and peers.
- They are going through an  'invincible' stage  of  thinking  and  acting  as  if nothing bad could happen to them. Their  decision-making  skills  are  still developing, and they are still learning about the consequences of actions.

In this image we can see a group of people standing and smiling.

<!-- image -->

## Strategies to cope with emotions

Each individual has his or her own way of coping with emotions. In view of helping teenagers  develop  adaptive  behaviour to lessen periods of anxiety, depression, stress  and  other  emotional  problems, some  general  coping  mechanisms  can be proposed to the students; such as:

- relaxation and breathing techniques (taking several deep breath by breathing in and out slowly).
- enjoying  nature  (going  for  walks, going to the seaside…).
- doing sports.
- listening to music or singing.
- writing  down  their  emotions  in  a journal.
- laughing therapy.
- eating healthily.
- watching a movie.
- keeping a positive attitude.
- hanging out with friends.
- taking care of themselves.
- saying  positive affirmations (I  am capable of….).
- talking to trusted adults and getting help.

## As an educator, you can:

- be  a  role  model  for  forming  and maintaining positive relationships with  your  friends,  children,  partner and colleagues. Adolescents will learn  from  observing  relationships where there is respect, empathy and positive ways of resolving conflict.
- listen to your students. If they want to talk and share important personal issues  which  may  be  disturbing  to them,  stop  and  give  them  your  full attention.  If  you  are  in  the  middle of  something,  make  a  specific  time when you can listen.
- Be a role model for positive ways of dealing  with  difficult  emotions  and moods.

In this image, we can see a picture of a person holding a pen and a paper.

<!-- image -->

- This activity will enable the students to  create  and  customise  a  special diary in which they can write down or  draw  their  different  emotions  in relation to their day to day life.

## Learning outcomes

- recall  the  different  emotions.  (Refer to Grade 7 - Part 1, Activities 7 to 11)
- develop an understanding about the  difficulties  in  expressing  one's emotions.
- create an alternative way to express oneself.
- develop self-confidence and selfawareness.

## Materials

Scrap book / diary / copybook, decorative items as per students' choice (colourful wrapping paper, magazine cuttings, stickers,  etc...),  coloured  pencils,  pens, scissors and glue.

## Procedure

1. Discuss  emotions  in  general.  (Refer to Grade 7 - Part 1, Activities 7 to 11, Grade  8  -  Self  Awarreness:  Activity 15, Empathy: Activities 7 -12)
2. Ask students how they feel when they need to talk about their emotions.
3. Brainstorm alternative ways to express oneself.
4. Ask students to start preparing their diaries.
5. Write/ Draw/ Stick emojis about their emotions. Encourage students to do theirs regularly.

## Ending Note

This  diary  could  be  an  effective  tool  to express themselves.

## ACTIVITY

2

## Emotional changes

Whatever  thought  that  activates a negative mood  in your life, absolutely doesn't deserve a single moment in your mind.

Edmond Mbiaka

In this image we can see a person's face.

<!-- image -->

This activity will enable students to understand  various  emotional  changes during adolescence.

## Learning outcomes

- Develop an understanding of various emotional changes related to physical changes during adolescence.
- Discuss  the  impact  of  the  feelings experienced due to physical changes in  adolescence  on  their  day  to  day activities

## Materials

Kitchen paper and coloured markers.

## Procedure

1. List down the physical changes during adolescence.
2. Brainstorm emotions attached to these physical changes.
3. Write down the students' responses on the kitchen paper. (Separate the positive and  negative  feelings, in case, there are mixed emotions, write them in the middle).
4. Carry out a class discussion to create awareness that the emotions attached  to  the  different  changes may  vary  from  one  individual  to another.
5. Allow students to reflect individually on the impact of these emotions on himself/herself.  Allow  students  who want to share their feelings to do so. Those who do not want to share may write in their diary or drop it in the question box.
6. Ask students to reflect on the different ways they use to cope with these different emotions for the next class.

## Ending Note

Keep the kitchen paper for next class.

## ACTIVITY

3

## Mood swings

We are governed by our moods;  should  be  the  other way around.

Haresh Sippy

In this image we can see a person.

<!-- image -->

This  activity  will  enable  the  students to reflect  on  their  mood  swings  by exploring different scenarios.

## Learning outcomes

- Identify various types of behaviour in the propsed scenarios.
- Relate these behaviour to emotional changes.
- Propose alternate reactions / behaviour  to  cope  with  emotional, physical and social changes that takes place during puberty.

## Materials

Kitchen, bristol paper, markers , scenarios.

## Procedure

1. Set the students in groups of 5 and provide each group with a case study /  scenario (You may wish to choose the scenarios which are most relevant to your context or adapt them)
2. Ask  the  students  to  read  each  case study and answer these questions in their assigned group:
3. (a)  What is the scenario about? Identify the people involved.
4. (b)  How  did the characters  react? Why?
5. (c)  How would you react if you faced the same situation?
6. (d)  Identify others ways to cope with the changes.
3. Ask  the  students  to  write  the  main points / ideas on the bristol paper / kitchen paper
4. Ask each group to come in front of the  class  for  a  genaral  presentation on their given scenarios.

## Ending Note

Keep  all  the  bristol  /  kitchen  paper  for the next class as this activity needs to be carried  forward  for  further  discussion. The educator may consider the proposed scenarios for discussion or may come up with stories of their own which may be more specific.

## Scenario 1

Rita was a brilliant student in Grade 8 and always excelled in her studies. However, she spent most of her time alone and always sat at  the  back  of  the  class.  She  would  never participate in any school activity like music or sports day. She felt that she was too fat for sports, and did not have any talent for music day.

Once a teacher noticed her habitual retreat from social gatherings. Through the motherly  attitude  of  the  teacher,  Rita  felt confident and confessed that she hated her physical appearance and she did not like to look at herself in the mirror.

From that day, the teacher always complimented Rita on her physical appearance  and  gradually  the  behaviour of Rita started to change. She started to sit in front of the class, made more friends and even participated in the school activities.

## Scenario 2

As soon as the bell rang for recess, Jessen and  Abdool  rushed  out  of  the  classroom. They did not even wait for the teacher to leave first. Although they have had several warnings about this, their behaviour remained  the  same.  Both  went  down  to secure a spot on the football pitch.

However, this time Jessen was unable to get a space as all the spots were already taken by other students. He was quite mad when his friends came down to see him. Tom and his team were laughing at him. Jessen and his friends walked around for some minutes in  the  school  yard  then  they  just  sat  near the school canteen.

Suddenly,  a  ball  came  in  front  of  them. Jessen  was  furious  as  it  bounced  on  his juice which spilled everywhere. He grabbed the ball and threw it in the other direction. When  someone  came  to  get  it  back,  he swore and just laughed at him.

One  of  his  friends  mentioned  that  this attitude was mean. He snapped back at his friend saying:

'You always have something to say anyway! I  don't want you in my team anymore.' His other  friends  started  to  argue  and  that's how the fight started.

## ACTIVITY

4

## Managing mood swings

In this image we can see a poster with some text and a quotation.

<!-- image -->

In this image we can see a mountain and a lake.

<!-- image -->

This activity will enable students to manage  their  emotions  and  behaviour through  critical  thinking  and  decision making.

## Learning outcomes

- Discuss the impact of physical, emotional and social changes during puberty.
- Devise strategies to manage emotions and behaviour.

## Materials

Previously worked out kitchen or bristol paper.

## Procedure

1. Stick all bristol paper / kitchen paper on the board.
2. Ask  each  group  to  come  up  with an  ending  to  the  the  scenario  (this can be done in terms of a role play / discussion / song… )
3. Following each presentation, ask other groups' opinions  and  ideas about the case presented.
4. If a group comes up with a negative ending, ask them to think about an alternative  way  in  response  to  the situation. Should they not be able to find a positive way out, ask the help of the other groups.
5. Praise and encourage each group for their participation and presentation.
6. You can conclude with a quote:
7. 'Be kind to unkind people. They need it the most' . (Buddha)
8. Engage  students  in  a  general  class discussion to trigger further thinking

## and reflection.

## Ending Note

Keep all the materials (posters / discussions / roleplays / songs/ …) and note all alternative behaviours proposed by  the  students  as  guidelines  for  the next class.

In this image, we can see a diagram with some text and images.

<!-- image -->

This  activity  will  equip  students  with skills to manage their emotions related to physical, emotional and social changes.

## Learning outcomes

- Discuss  ways  to  cope  with  different emotions.
- Develop critical thinking and decision making skills.
- Create  a  coping  wheel  for  different situations.

## Materials

An empty box, coloured pens and markers

## Procedure

1. Set  students  in  group  of  4-5.  Ask them  to think about a situation where they had difficulty to control their emotions.
2. Ask students to consider the alternative situations to manage their  emotions  they  have  identified in the previous class.
3. Explain the different steps in creating a coping wheel.
4. Ask students to list down six situations which are related to:
5. (a)  sadness
6. (b) anger
7. (c)  excitement
8. (d) happiness
9. (e)  fear
10. (f )  nervous
5. Discuss  the  different  situations  and find the best strategies to cope with the emotions.
6. Each group will present their situation and their strategies.
7. Using the strategies identified, each group will create an emotional wheel.

In this image, we can see a diagram. There is a white color background. There is a black color line on the right side. There is a black color line on the left side. There is a white color line on the top. There is a black color line on the bottom.

<!-- image -->

5

## Problem Solving

Forget past mistakes, forget failures, forget everything except what you're going to do now and do it.

William C. Durat

<!-- image -->

## Learning outcomes

## Students will be able to:

- Understand the steps in problem solving.
- Propose solutions to complex problems.

## Educator's Guide for Problem-solving

In this image, we can see two hands are holding a puzzle.

<!-- image -->

Teenagers may face all sorts of problems, ranging from academic difficulties, hormonal changes, emotional stress to tense  relationships  with  parents.  Yet, few of them have a formula for solving those problems.

Problem-solving is an important life skill  for  teenagers  as  developing  the appropriate problem solving skills may help them to explore and analyse problems before solving them. Problemsolving  skills  will  enable  students  to adopt  rational  thinking  in  dealing  with their problems.

The  seven  step  model  is  an  example of  how  spontaneous  reaction  based  on emotions can be avoided in dealing with problems.

## Steps in problem-solving

## 1. Identify the problem

The first step is to identify the problem. There  should  be  an  initial reflection about the situation and how it may turn out.  Always approach the problem in a positive attitude.

## 2. Focus on the problem

Focus  on  the  issue,  not  the  person  or the emotion. This will help deal with the problem in a more confident way rather than suffer from anxiety and frustration.

In this image there is a chart. At the top of the image there is a blue circle. In the middle of the image there is a text. At the bottom of the image there is a text.

<!-- image -->

## 3. Define the nature of the problem

It  is  only  after  the  problem  has  been identified  and  analysed,  that  one  can define the nature of the problem. If the definition is  not  clear  this  may  indicate that  the  problem  at  hand  is  not  fully understood. So,

- (a) define exactly what the problem is.
- (b) define  exactly  what  needs  to  be solved.
- (c) define the desired outcome.

## 4. Evaluate the options

Think about all the possible ways to solve the problem at hand. In  today's  world,  there  are  experts  on pretty much any topic you can imagine. So, sometimes the best and fastest way of getting the information we need can be  simply  to  ask  someone  who  knows more about the subject than we do.

## 5. Select an option or options

With  a  list  of  possible  solutions  now, it  is  time  to  select  the  best  solution  or solutions to be put into action to address the  problem  at  hand.  The  process  of selecting  the  best  solution  is  a  matter of  ranking  all  of  the  available  solutions against one another. It also entails evaluating  the  pros  and  cons  of  each possible solution.

## 6. Put the idea(s) into practice

Implement  the  best  idea(s)  that  can resolve the problem.

## 7. Evaluate the outcome

Evaluate the outcome(s) of the solution(s).  It  may  take  time  to  resolve the  problem  at  hand.  So  do  not  give up easily. Instead ask the following questions:

- (a) What has or hasn't worked well?
- (b) What  can  be  done  differently  to make the solution work more smoothly?

The seven step model can be used in any situation. The educator is encouraged to think and design additional activities on problem solving. The  three  activities  in this section focus on the issue of sexuality. Educators may decide to work out other activities on other issues like substance abuse, sustainable development, human rights and so on.

## ACTIVITY

1

Problem solving in everyday life

In this image, we can see a circle with some text written on it.

<!-- image -->

In this image we can see a group of people sitting in front of a table. On the table we can see laptops. In the background we can see a building and a glass window.

<!-- image -->

In  this  activity,  students  will  learn  the steps to solving a problem in groups and individually. They will use this process to critically think through various problems to find possible solutions.

## Learning outcomes

- Identify the seven steps to solving a problem effectively.
- Practise  solving  different  problems as an individual and as a member of a team.
- Understand how the same problemsolving  process  works  in  different situations.

## Procedure

1. Educator will explain the seven step model involved in problem solving.
2. As  individual  work,  ask  students to  think  of  a  problem,  they  have recently  faced  as  an  adolescent. Choose any one from the list they  provide  or  decide  on  other problems you feel pertinent to the students.
3. Ask each student to briefly describe how they reacted to the problem.
4. Ask students to use the seven step model  to  show  how  appropriate problem-solving skills can help better manage problems.
5. Ask  each  group  to  act  out  the scenario and come  up  with at least  one  solution  for  solving  the problem.
6. Solicit additional solutions from the class.
7. Ask students to think about any problem  they  are currently facing  and  apply  the  seven  step model  to  find  the  most  reliable solution(s).  Students  who  want  to share their individual problems are encouraged to do so.

## Examples  of  problems  a  teenager may face:

- You invite four of your friends at your place and you realise that you have only 3 burgers and 3 can of coca cola left. What will you do?
- You are very hungry and when you look for your lunch in your bag, you realise that you have left it at home. You have also forgotten your wallet at home. What will you do?
- There  is  a  guy  in  your  class  who  is always mean to you. He always bumps into  you  when  he  walks  by  and  he calls you names. He knocks stuff out of  your  hands  and  makes  you  feel stupid. You don't think you can take it anymore. What will you do?
- You really want to invite this new girl/ guy to come to your birthday party, but you have never talked to him/her before.  You  are  worried  she/he  will say no. What will you do?
- You wake up and see that your alarm never  went  off.  So  you  are  starting your morning 15 minutes later than you planned. It is a really important day at school and you cannot be late. What will you do?
- You are giving a group presentation in front of class and it's your turn to talk.  All  of  the  sudden  you  sneeze. You cover it with your hand, but now your hand is full  of  snort. What  will you do?
- You  are  taking  a  test  and  the  guy behind you asks you for help. He wants to  know  what  you  put  for  question number two. What will you do?
- You  are  hanging  outside  with  your friend  and  she  decides  to  pick  your neighbour's  flowers.  She  gives  you the  pretty  handful  of  flowers  and right then your neighbour opens the door.  She  asks  you  why  you  picked her flowers. What will you do?

<!-- image -->

## Issues related to sexuality

In this image, we can see a picture of a person holding a hand. We can also see some text on the image.

<!-- image -->

This activity aims at sensitizing teenagers on the consequences of becoming sexually active at an early age and  empower them to solve  dilemmas related to sexual decision making.

## Learning outcomes

- Understand the risks of being sexually active at an early age.
- Examine the consequences of becoming sexually active at an early age.

## Procedure

1. Brainstorm  why  more  and  more teenagers are sexually active at an early age.
2. Divide students in small groups and ask them to discuss the dangers of becoming sexually active at an early age. They may think in terms of:
3. (a)  risk to health
4. (b)  education achievement
5. (c)  family relationship
6. (d)  life chances
7. (e)  status
8. (f )  social acceptance
9. (g)  legal implications
3. Ask students to write their ideas on a  bristol  paper  and  present  their findings to the class.
4. Initiate  a  class  discussion  on  how they feel about the issue they discussed in this lesson.

## Ending Note

1. Possible reasons of becoming sexually active at an early age can be:
- difficulty in parent-adolescent relationship. Particularly  parentdaughter  conversation  regarding sexuality.
- Peer influence and negative pressure.
- Adult models of sexual behaviour.
- Media models of sexual behavior (movies  and  videos  reinforcing roles  and  messages  -  women  as passive victims, women as sexual beings, women as play things).
2. Potential negative  consequences of being sexually active at an early  age:  teen  pregnancy,  STIs, high abortion rate, emotional and behavioural problems, neo-natal mortality levels are higher.

In this image, there is a poster with some text on it.

<!-- image -->

Sexually Transmitted Infections (STIs) spread from person to person during sex or close intimate contact. It is important to inform students on STIs as many are often  sexually  active  at  an  early  age. However, one has to understand that the only sure way of being safe of STIs and teenage pregnancy is abstinence.

## Learning outcomes

- Explain STIs.
- Describe ways in which STI transmission can be reduced.
- Discuss why sexual abstinence is the best option to avoid STIs and teenage pregnancy.

## Procedure

1. Ask students why they think the rate of  STI  among  youth  is  increasing every year in the Republic of Mauritius.
2. Divide students in small groups and ask them to describe ways in which STI transmission can be reduced.
3. Ask students to define the concept of  sexual  abstinence  and  explain why it is important.
4. Ask  students  to  be  creative.  They can either write a  poem/song/ slam or create a poster to sensitize people  on  the  benefits  of  being sexually abstinent.
5. Each group presents their work to the class.

## Ending Note

1. Benefits of being sexually abstinent to share with students.

## Waiting will:

- make  your  dating  relationship better.  you'll  spend  more  time getting to know each other.
- help  you  find  the  right  mate later (someone who values you for the person you are).
- increase  your  self-respect  and gain the respect of others.
- takes pressure off you.
- means  a  clear  conscience  and peace of mind.
- teaches you to respect others as you will never pressure anyone.
- means a better sexual relationship in marriage ( free of comparisons and based on trust).

In this image, we can see a colorful image.

<!-- image -->

ISBN: 978-99949-53-71-4