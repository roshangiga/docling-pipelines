In this image we can see a poster with some text and images.

<!-- image -->

## ENGLISH L A N G U A G E

A fun learning experience

Professor Vassen Naëck

- Head Curriculum Implementation, Textbook Development and Evaluation

## ENGLISH PANEL

Dr Yesha Mahadeo-Doorgakant

- Panel Coordinator, Lecturer, MIE

Rajendra Korlapu-Bungaree

- Senior Lecturer, MIE

Mangala Jawaheer

- Lecturer, MIE

Iqrah Azam

- Educator

Gianysha Beehuspoteea

- Educator

Yasvina Ghoora-Gopalsing

- Educator

Nipti Rajni Kamal Gopaul

- Educator

Bhavna Gayatri Mohaband-Duljeet

- Educator

Mary Jane Raboude

- Educator

Westley Puven Valaydon

- Educator

Design

Vedita Jokhun

- © Mauritius Institute of Education (2021)

ISBN : 978-99949-53-78-3

Acknowledgements

The English textbook panel wishes to thank:

- Dr Aruna Ankiah-Gangadeen (Associate Professor, MIE) and Reshma Gungapersand (Lecturer, MIE), for proof reading and vetting.

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

- Graphic Designer

## Foreword

With the Grade 9 textbooks, we now complete textbook production for Grades 1-9 in the context of the Nine Year Continuous Basic Education (NYCBE) project of the Ministry of Education and Human Resources, Tertiary  Education  and  Scientific  Research.   The  textbooks  are  designed  in  line  with  the National Curriculum Framework (NCF) and the syllabi for Grades 7, 8 and 9 which are accessible on the MIE website, www.mie.ac.mu .

These textbooks build upon the competencies learners have developed in Grades 7 and 8, based on the philosophy of the NCF for the NYCBE. The content and pedagogical approaches allow for incremental and  continuous  improvement  of  the  learners'  cognitive  skills  using  contextualised  materials  which should be highly appealing to the learners.

The writing of the textbooks involved several key contributors, namely academics from the MIE and educators from Mauritius and Rodrigues, as well as other stakeholders. We are especially appreciative of comments and suggestions made by educators who were part of our validation panels, and whose opinions emanated from long-standing experience and practice in the field.

The development of textbooks has been a very challenging exercise for the writers and the MIE. We had to ensure that the learning experiences of our students are enriched through approaches which appeal to them, without compromising on quality. I would, therefore, wish to thank all the writers and contributors who have produced content of high standard thereby ensuring that the objectives of the National Curriculum Framework are skilfully translated through the textbooks.

Every  endeavour  involves  several  dedicated,  hardworking  and  able  staff  whose  contribution  needs to be acknowledged. Professor Vassen Naëck, the Head of Curriculum Implementation and Textbook Development  and  Evaluation  provided  guidance  with  respect  to  the  objectives  of  the  NCF,  while ascertaining that the instruction designs are appropriate for the age group targeted. I also acknowledge the  efforts  of  the  graphic  artists  who  put  in  much  hard  work  to  maintain  the  quality  of  the  MIE publications. My thanks also go to the support staff who ensured that everyone receives the necessary support and work environment conducive to a creative endeavour.

I am equally thankful to the Ministry of Education, Human Resources, Tertiary Education and Scientific Research for actively engaging the MIE in the development of textbooks for the reform project.

I wish enriching and enjoyable experiences to all users of the new set of Grade 9 textbooks

Dr O Nath Varma Director Mauritius Institute of Education

## Preface

The Grade 9 English Textbook is based on the reviewed National Curriculum Framework (2016) and adheres to the English Teaching and Learning Syllabus (2017). In line with the Nine-Year Continuous Education policy, it builds upon the competencies, attitudes and behaviour that have been taught at primary level and in Grade 7 and 8. Moreover, it is aimed at equipping learners to use the English language with growing proficiency.

The textbook constitutes the following components:

## Communications skills

Simple listening activities have been conceptualised to develop a multiplicity of listening competencies. Educators are encouraged to prepare appropriate pre-listening activities as a lead-in to the recordings. Speaking activities have been designed to help students develop ease, fluency and confidence while expressing themselves in English.

## Reading comprehension

For Grade 9, different types of reading texts have been conceptualised to develop and build upon the wide array of reading competencies that are engaged in a reading exercise. Instead of one main reading text, two different types and levels of reading texts have been proposed to cater for a range of students. Moreover, the varied themes, lay-out and content of the texts  provide a rich context for the development of effective reading strategies that will make the learners become independent readers. To that end, pre-reading, while-reading and post-reading activities have been provided, taking into account the different levels of learners.

## Just For Fun

The ability  to  read  for  enjoyment  cannot  be  undermined as it  contributes  to  the  overall development of reading skills. Each unit, therefore, includes one text that students will read for pleasure and appreciation. A glossary has been included to promote reader autonomy and  post-reading  activities  have  been  suggested  to  provide  a  platform  for  sharing  and discussion.

## Writing

For Grade 9, we emphasise on the production of different types of texts to develop students' awareness that the function,  lay-out  and  register  of  text  vary  according  to  the  purpose, reader and situation. Hence, they will develop the ability of varying the style and language to suit the context. Moreover, the writing activities designed in the textbook work towards developing the creativity and originality of students.  Emphasis has also been on familiarising

learners with the different stages of the writing process such as: planning, drafting, editing and proofreading to improve the overall quality of their written work.

## Vocabulary

Vocabulary development is an inescapable part of language learning and each unit provides an array of vocabulary tasks to enrich the learners' repertoire. The thematic approach of the textbook allows for the development of vocabulary across the units. Oral and written activities require the students to use words learnt, thereby reinforcing their knowledge, and use of the English language.

## Grammar

Grammar is also a significant aspect of language learning and a knowledge of grammar rules is  essential  for  effective  communication. The learners must view grammar as a means to express themselves correctly and with precision, rather than an end in itself. Thus, while there is some attention drawn to the rules at secondary level where usage has to be promoted rather than rote learning. Educators are encouraged to provide supplementary grammar practice exercises as per their students' needs and to review the use of grammar to reinforce acquisition.

In  addition  to  instructions  for  all  the  activities, Teaching Tips have  been  included  where necessary  to  provide  guidelines  or  suggestions  for  implementation.  Nevertheless,  the teaching approach will have to be adapted in line with the level and needs of the learners. It is understood that all students do not learn at the same pace and that the use of additional examples/samples/resources are always beneficial to the learning experience. A CD is provided for the listening activities to help students develop familiarity with a variety of speakers and accents. Nevertheless, educators could read the texts aloud, if deemed appropriate. To that end, all transcripts have been included in the Appendix.

It is hoped that both educators and students will enjoy working with the textbook and find the process enriching.

## TABLE OF CONTENTS

<!-- image -->

1

Looking after Oneself

Activity 1:

Communication Skills

Listening - Critically Speaking - Discussion

Activity 2:

Reading Comprehension

Ask Sylvia

Activity 3:

Vocabulary

Activity 4:

Grammar

Use of Reflexive and Emphatic Pronouns

Activity 5:

Just For Fun

The Life of An Old Man

Activity 6:

Grammar

Perfect Conditional Tense

Activity 7:

Writing

Speech Writing

Page 1 - 25

<!-- image -->

Activity 1:

Communication Skills

Listening - Listening for specific information Speaking - Expressing feelings

Activity 2:

Reading Comprehension

Mr Globetrotter The Cocullo Snake Festival

Activity 3:

Vocabulary

Activity 4:

Grammar

Passive Voice

Activity 5:

Grammar

Preposition

Activity 6:

Just For Fun

The Pamplona Bull Run

Activity 7:

Writing

Descriptive Writing

## Festivals around the World

Page 27 - 53

2

<!-- image -->

<!-- image -->

In this image, we can see a graph.

<!-- image -->

Activity 1:

Communication Skills

Listening - Listening for the main idea Speaking - Responding to a given situation

Activity 2:

Reading Comprehension

The Sunshiners Connect We are Hiring

Activity 3:

Vocabulary

Activity 4:

Grammar

Nouns in Apposition

Activity 5:

Grammar

Future Perfect and Future Perfect Continuous Tense

Activity 6:

Just For Fun

Russell: The Hero

Activity 7:

Writing

A CV and a Job Application Letter

4

## Changing Worlds: From Past to Future

3

## The World of Work

Page 55 - 80

Activity 1:

Communication Skills

Listening - Listening for specific information Speaking - Description

Activity 2:

Reading Comprehension

Mauritian Youths' Attitudes Towards Work

Activity 3:

Vocabulary

Activity 4:

Grammar

Passive Voice

Activity 5:

Grammar

The Dash

Activity 6:

Just For Fun

Technology is always on the move

Activity 7:

Writing

Reflective Essay

Page 81 - 103

<!-- image -->

World Issues

Activity 1:

Communication Skills

Listening - Listening with Empathy Speaking - Debate

Activity 2:

Reading Comprehension

Ecological 10 Year Challenge School Strike for Climate

Activity 3:

Vocabulary

Activity 4:

Grammar

Adjectives used as nouns

Activity 5:

Grammar

Semicolon

Activity 6:

Just For Fun

Alice Hawkins - The Suffragette

Activity 7:

Writing

Short Story Writing

<!-- image -->

Page 105 - 127

5

Appendices

Page 128 - 132

In this image, we can see a poster with some text and images.

<!-- image -->

This unit aims at helping you develop an understanding of mental health and well-being.

- You will listen:
- to a speech by a psychologist on mental health
- You will speak:
- about tips on how to help someone facing issues
- You will read:
- an advice column
- You will write:
- a speech

<!-- image -->

## ACTIVITY 1: Communication Skills

## 1a. Listening - Listening critically

Listen carefully to the short speech given by Dr Pierre Roch, a psychologist, who will talk about mental health.

## Teaching Tip:

Brainstorm on the concept of mental health and well-being and how it is understood by students.

In this image we can see a person standing on the floor and holding a microphone in his hand.

<!-- image -->

## Listen to the text and answer the following questions.

1. According to you, what is Dr Pierre Roch talking about?
2. Why is it not easy to help someone who is facing problems?
3. According to you, is the topic that Dr Roch chose to speak about important? Why do you think so? Discuss in groups.

## 1b. Speaking - Discussion

In this image we can see a person standing and holding a microphone. In the background there is a blue color background.

<!-- image -->

- (i)  After going through the tips provided by Dr Roch, do you think that they are helpful? Why do you think so?
- (ii)  Rameez has noticed that his friend Neil is not behaving like he normally does. He thinks Neil has a problem and has decided to help him by using the tips from the leaflet. Imagine the conversation between Rameez and Neil and enact it.

## Teaching Tip:

Guide the students to imagine possible scenarios about how Neil's behaviour has changed. Invite the students to imagine the conversation.

Draw attention to how to go about giving advice, using appropriate language choices (style, tone, body language…)

Students can be paired up for the role play.

<!-- image -->

2a (i) Write a few sentences to describe what is happening in the pictures below.

## Teaching Tip:

Get students to present their work to the class and explain their interpretation of the pictures.

In this image we can see a cartoon image of a man and a cartoon image of a woman. The man is holding a flower in his hand. The woman is holding a flower in her hand. There are trees in the image.

<!-- image -->

In this image we can see a person standing on the ground. In the background there are trees and there are clouds.

<!-- image -->

In this image we can see a person sitting on the grass. In the background there are trees.

<!-- image -->

## 2a (ii)  Discuss the following questions in groups.

- A.  Why is the boy feeling sad?
- B.  How would you feel if you were the boy?

## Teaching Tip:

Encourage a variety of responses. You can also question the students about other issues that can cause discomfort to them.

In this image we can see a cartoon image of a woman holding a book in her hand.

<!-- image -->

## Sylvia's Advice Column

Are  you in  a  fix ?  Are  you depressed ?  Well,  you  don't need to agonise anymore!  Sylvia  is  here  to  guide  you. Sylvia will help you by providing genuine responses to your intimate queries.

IMAGE ISSUES?

In this image, we can see a poster with some text and images.

<!-- image -->

HEART BROKEN?

From  deciding  what  to  wear  to  going  out  with  your girlfriend to preparing for exams,  'Dear Sylvia' is here to provide sound advice to you. If you think your parents are perplexed ,  Sylvia  is  here  to  answer  their  questions too.    Sylvia  is  25  years  old  and  has  just  completed  her studies  in  Psychology.  She  is  the  youngest  of  her  six siblings and has lost her parents at an early age. She has personally gone through different issues.

You can therefore trust her to understand what you are going through. So, what are you waiting for? Grab that pen and start writing to her.

## 2b. Fill in Sylvia's profile sheet below using the information from the text.

Name

Age

Number of siblings

Studied

1. What does Sylvia do?
2. Who does Sylvia want to help?
3. What issues can Sylvia help teenagers with?

## 2c. Going deeper in the text: Read the text again and answer the questions below.

1. Explain the phrase: ' in a fix ' .
2. According to you, should teenagers seek advice when they have problems? Discuss.
3. Why would a teenager write to someone for advice?
4. Imagine that you have a problem. Write to Sylvia for advice.

## 2d. Read the text below carefully.

<!-- image -->

## Sylvia's Advice Column

## Dear Sylvia,

Can you believe my parents treat me like a baby, although I am fourteen? They won't let me go anywhere without accompanying me. The other day, my friends asked me out to watch a horror movie. Mum decided to accompany me. She actually sat right behind me during the movie! It was impossible to have a nice time with my friends. Everybody felt awkward. I felt mortified ! The next day, my friends teased me for being a grown-up baby . I want to take all my belongings and go to live at my grandparents' . At least, Grandpa lets me do what I want to do. Should I go live with my grandparents? I await for your advice eagerly.

Amar

<!-- image -->

## Ask

## Dear Sylvia,

My dad has left us and gone abroad because of his job. Mum says he has got a promotion and he will be earning more. She says we will be wealthier now and we will have a better life. My dad calls me once or twice every week and he keeps telling me how drained he feels. He often sends me a gift with a loving note telling me that he loves and misses me.  The other day, there was the prize giving ceremony at school and I had won several prizes. My friends' parents were all there but only my mum came. When I looked around in the crowd, I wished that my dad had been there. I miss him. I feel unwanted and I feel that he has abandoned me. I really want him to come back. Should I tell him how I feel?

Krishna

## Dear Sylvia,

Neha is the new girl in my class and I think she is extremely cute. She is also very smart and kind. I wish we could become friends, but I feel shy to talk to her. I am not so popular. I don't really like the way I look. I wish I were handsome and cool like my friend Vicky, who is the best football player in the school. Sometimes, I find Neha staring at Vicky from far and I feel spiteful . Neha likes Maths, like me. Both of us are often the only ones who get the best marks during the Maths class. How can I ask her to join me for lunch one of these days? Please advise.

Andrew

## SYLVIA

## Dear Sylvia,

My parents have a lot of dreams for me because I am the intelligent one in my family. I wish I were like my sister who takes after my mum and is known as the prettiest one. I feel suffocated . I need to constantly work hard to prove to my parents that I am the smartest one in the family. I don't go out with my friends as I am always studying so I can be first in my class. It's so frustrating to see my sister going out all the time. I wish I could have her life. Recently, I have started feeling sad for no reason. I don't understand what is happening to me. I often sit in the dark and  stay in bed till late at night and I can't sleep. When I sit down at my desk to start working, the letters start dancing in front of my eyes and I can't concentrate. I am scared to tell my parents how I am feeling because I do not want to disappoint them. Please tell me what to do.

Sheena

- 2e. Read the text and fill the notes in Sylvia's notebook with the appropriate information. Answer the questions below.
1. What did Amar's mum do when he went to watch a movie with his friends?
2. Why did Krishna's father go abroad?
3. How did Krishna feel when he looked at the crowd and saw only his mum?
4. Why does Andrew want to become friends with Neha?
5. What do Andrew and Neha have in common?
6. Why does Sheena think that she is not like her sister?

In this image, we can see a table with some text and numbers.

<!-- image -->

## 2f. Going deeper in the text: Answer the following questions.

## 1. Explain the following expressions:

- a. 'grown-up baby'
- b. 'takes after'
- c. 'the letters start dancing in front of my eyes'
2. Imagine you are Krishna's dad. Write down a few lines in the note below.

In this image we can see a paper with a note and a line on it.

<!-- image -->

## Teaching Tip:

Get students to imagine what Krishna's dad and Amar's mum  might  be  thinking  or  feeling.  The  idea  is  to develop empathy for the characters by understanding different points of view.

3. Fill the thought cloud below with the thoughts of Amar's mum as she is sitting behind her son and watching the movie.
4. Why do you think  Sheena's  parents  have  many  expectations  from  her?  Discuss  in groups.
5. Imagine you are Sylvia. Write an advice column in answer to one of your readers' problems (Krishna, Amar, Andrew or Sheena).

In this image we can see a cartoon image. In the cartoon image we can see a woman and a man sitting on the chairs. In the background there is a wall.

<!-- image -->

## Teaching Tip:

Get students to brainstorm the different types of advice that Sylvia can give to the teenagers who wrote to her. Draw attention to the different features of writing an advice column; use of questions within the text, use of modal verbs, making suggestions and showing empathy with the person who asked for advice. You can bring other examples of advice columns in class for students to examine.

<!-- image -->

3a (i) Fill the textbox with the words below to describe the following pictures. Define each using your own words.

<!-- image -->

<!-- image -->

<!-- image -->

depressed unwanted

agonised spiteful

perplexed mortified

drained oppressed

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2

22?

7

7

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image we can see a person.

<!-- image -->

3a (ii)  Now use the new vocabulary learnt to write sentences of your own.

- 3b. Match the following expressions with their appropriate definition.
- remorseful
- nervous
- smug
- infuriated
- reserved
- jittery
- very angry
- feeling sorry
- proud of oneself
- feeling shy

<!-- image -->

## ACTIVITY 4: Grammar - Use of Reflexive and Emphatic Pronouns

## 4a (i) Listen to the speech of Dr Pierre Roch and pay attention to the underlined words.

In this image we can see a person standing in front of a podium. On the podium there is a microphone.

<!-- image -->

Hello students, I have one question for you: do you like yourself? I often hear youngsters who say 'I hate myself because I have pimples' . What you say about yourself says a lot how you feel about yourself. People with low self-esteem normally view themselves poorly.

The  underlined  words  are  called  Reflexive  Pronouns.  A  Reflexive  Pronoun refers back to the subject of the sentence. It is formed by adding 'self' or 'selves' to the personal pronoun.

For example: I looked at myself in the mirror while they stared at themselves.

## 4a (ii)  Fill in the blanks with the appropriate Reflexive Pronouns.

Sir, one reason could be because of our parents. I have to take care of  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  as my parents are always busy and have no time for me.

Friends, who are mean to us, are probably \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ suffering  from  low  self-esteem because they are facing personal issues.

<!-- image -->

<!-- image -->

<!-- image -->

'Why do people suffer from low self-esteem?'

<!-- image -->

<!-- image -->

As

a

poor performer

usually find

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

at school,

Sagarika finds

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

feeling lost all the time.

leading  a  stressful  life  as my  parents  died  in  a  car crash  and  I  keep  living  in different shelters.

Melissa had  to fend for \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ as she was bullied because of her looks.

## 4b. In groups, come up with different ways people can deal with low self-esteem. Use Reflexive Pronouns in the sentences you come up with.

## Teaching Tip:

Get students to brainstorm ways to combat low self-esteem and come up with sentences using reflexive pronouns. This task can either be carried out as a written task or as an oral activity.

## 4c. Fill in the blanks with the appropriate  pronouns.

An Emphatic Pronoun is used to put emphasis on the subject or object of a sentence.

For  example:  We  saw  the  King  himself.  (Himself  is  the  emphatic  pronoun  for  the object 'king')

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

<!-- image -->

You

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

are a priority. It is not selfish. It is a necessity.

<!-- image -->

<!-- image -->

In this image we can see a green color box. In the box we can see a text.

<!-- image -->

In this image, we can see a green color box. Inside the green box, we can see some text.

<!-- image -->

<!-- image -->

We,    \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  should make  room  for  things  that  bring  joy and nourish our soul.

<!-- image -->

<!-- image -->

<!-- image -->

## ACTIVITY 5: Just For Fun

5a. Read the text below.

## The Life of An Old Man

This passage is about an old man who remembers his youth when a young boy visits him in a home for elderly people.

There  is  nothing  as  bad  as  waking  up  and  knowing  that  nothing will happen. Today was such a day, like every day…  No hope for something new, no scope for  anything  new.  Then,  that  young boy and his family came to visit us. I sat for dinner and he came to serve food to us. After eating, I was in a rush to retreat to my room, a habit that I have adopted to avoid having people look at me. I feel ashamed being there.

As I got up, I felt someone grip my arm strongly. 'Please do not go uncle!  We  have  organised  a  small  karaoke  programme  for  all  of you,' said the boy. The boy and his family sang and danced. Some of us were enjoying the show while others were simply indifferent. As for myself, I did not know what to think or how to feel until the boy caught my hand again. He tried to drag me to the dance floor. I looked at his face; he had such a lovely smile, happy eyes and a vivacious attitude. I was once like that.

That  boy  took  me  to  my  lost  youth.  Those  were  the days when life was more exciting. I used to go out with my friends after school. We were a group of five close friends,  always  there  for  each  other.  We  spent  time strolling  along  river  banks,  organising impromptu picnics, eating fish which we caught and grilled on the spot. Believe me, we loved life! How I miss my friends, I wonder where they are now…

After  my  wife  passed  away,  my  two  children  became the reason why I looked forward to life. But they have very busy lives. I miss them and I wish I could see them everyday. Here I am, sitting within the four walls of this home for elderly people. I have a room, a cup, a plate, a fork, a spoon, some clothes and my walking stick. I have a few friends here. The helpers are very affectionate towards me. Now, they are my family. Indeed, this is how it is and how it will be, until my last breath.

In this image we can see a person holding a box.

<!-- image -->

## GLOSSARY

scope: possibility, choice

retreat: go, withdraw

grip: hold

vivacious:

energetic

impromptu:

unplanned, improvised

affectionate:

loving, caring

## 5b. Answer the following questions orally.

1. Imagine you are the young boy paying a visit to the elderly home. What are your thoughts and feelings?
2. Do you think that old people should live in homes for elderly people? Why? Discuss in groups.

<!-- image -->

## ACTIVITY 6: Grammar Perfect Conditional Tense

In this image we can see a cartoon image of a person sitting on a bench and talking to the person. There is a text on the image.

<!-- image -->

## 6a. Observe the underlined words.

- The tense used in the underlined verbs is known as Perfect Conditional Tense.
- We use the Perfect Conditional Tense when we describe what we could have done differently or what would have happened if events had been different.

## Teaching Tip:

Introduce Perfect Conditional Tense to the students and explain the usage of it. Provide a few examples and then elicit additional examples from the students. Use these to draw explicit attention to how the Perfect Conditional Tense is formed.

- 6b. Pair up. Imagine you are Mr Kumar and your classmate is the young boy who came to visit you at the elderly home. Fill the speech bubbles below with sentences using Perfect Conditional Tense.
- Take turns to roleplay being Mr Kumar and the young boy.

In this image we can see a cartoon image of two persons sitting on a bench. In the background there are buildings and trees.

<!-- image -->

## Teaching Tip:

Pair the students up. Get them to come up with different examples using the Perfect Conditional in their sentences. You can get them to enact the scene later.  Guide students to show regret and sadness when they are speaking.

<!-- image -->

## 7a. Match the rhetorical devices in column A with examples in column B.

Table 1

| A- Rhetorical devices    | B - Examples                                             |
|--------------------------|----------------------------------------------------------|
| Exaggeration             | When I was little, I used to eat a lot of sweets.        |
| Fact                     | Imagine! Imagine!                                        |
| Quote from famous people | The capital of Mauritius is Port-Louis.                  |
| Repetition               | 'Theonlywaytodogreatworkistolovewhat you do.' Steve Jobs |
| Anecdote                 | The young lady was drowning in tears!                    |

## Teaching Tip:

Introduce students to the concept of rhetorical devices. Discuss why rhetorical devices are effective in persuasive speeches. Encourage students to give examples from speeches they have heard in the local context.

- 7b. Ratna is giving a speech on the statement: 'Teenagers have an easy life! They do not need to work for a living and are enjoying life most of the times' .  Read the beginning of the speech.

In this image we can see a girl is walking. She is wearing a jacket, blue pant and blue shoes.

<!-- image -->

Good morning friends.

I  don't  understand why elders always say that we have an easy life. I am tired of hearing this!   But I am not the only one who hears this!  No! I am sure that you too, a teenager just like me, must have heard this many times!

Yet, this is not the truth!  I can assure you my life is definitely not easy and looking at your faces, dear friends, I know that neither is yours!

Let me share three reasons why as teenagers we do not have an easy life!

- 7c. List three possible reasons Ratna will use to convince the audience that the life of a teenager nowadays is not easy.

(i)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(ii)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(iii)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- 7d. Imagine you are Ratna. Continue the speech on the topic: 'Teenagers have an easy life! They do not need to work for a living and are most of the time enjoying life' . Use a few rhetorical devices from table 1 to better persuade your audience.

Teaching Tip:

Get students to deliver their speech after writing it.

<!-- image -->

Remember that writing a speech is not the same as writing an essay. When writing a speech, use the following tips:

- sound conversational, i.e. you should write the way you speak,
- use short sentences and familiar vocabulary,
- use contractions like i'm or we'll , and
- read your speech aloud while you are writing.

In this image we can see the poster with some text and images.

<!-- image -->

## Looking Forward

This unit aims to help you discover and learn about different festivals that are celebrated around the world.

- You will listen:
- to a presentation on an international festival
- You will speak:
- about your feelings at attending a festival
- You will read:
- a blog
- You will write:
- a descriptive essay

<!-- image -->

## ACTIVITY 1: Communication Skills

1a. Listening-Listening for specific information

Listen carefully to the presentation made by Khushi about an international festival and circle the correct answer.

In this image we can see a group of people standing on the sand.

<!-- image -->

1. Where do you think Khushi is giving this presentation?
2. A Korea
3. B in the classroom
2. Where does the Korean Mud Festival take place?
5. A South Korea
6. B North Korea
3. The Korean Mud Festival allows tourists to wrestle in
8. A ice.
9. B mud.
4. The prices for activities at the Korean Mud Festival are
11. A affordable.
12. B expensive.
5. After listening to Khushi's presentation, what questions would you ask her?

## Teaching Tip:

Focus on developing questioning skills for the last question.

## 1b. Speaking:  Expressing feelings

- (i)  Look at the following images of the Porlwi by Light Festival and fill the textboxes below with the appropriate information.

In this image we can see a building with pillars and windows. There are lights and a tree.

<!-- image -->

Describe what you see.

Your feelings

In this image we can see a building.

<!-- image -->

Describe what you see.

In this image we can see a path with benches and trees.

<!-- image -->

Your feelings

In this image we can see a building. There are boats on the water.

<!-- image -->

Describe what you see.

Your feelings

Describe what you see.

Your feelings

Describe what you see.

Your feelings

- (ii)  Find other images of the Porlwi by Light Festival and stick them in the empty spaces given below.

(iii)  How  would  you  feel  if  you  had  attended  the  Porlwi  by  Light  Festival?  Share  your feelings with your classmates.

Teaching Tip:

Guide the students to clearly express their emotions about attending such an event. You can get them to use the pictures given in the textbook and additional ones to describe what they see and share their feelings about these images.

<!-- image -->

## ACTIVITY 2: Reading Comprehension

## 2a. Study the poster carefully and answer the questions that follow.

In this image we can see a poster with some text and images.

<!-- image -->

1. Which festival is being celebrated?
2. What do you think about the festival being celebrated in the poster?
3. Have you ever attended such festivals? If so, describe what happened at the festival you attended.
4. What other types of festivals are you aware of? List a few.

## Teaching Tip:

Discuss the poster using  'Wh' questions to extract as much information as possible.

## 2b. Read the text below.

Hi  fellow  travellers.  I  am  Mr  Globetrotter  and

In this image we can see a poster with some text and images.

<!-- image -->

welcome to my channel:

Attending festivals around the world in 150 days!

My challenge is to travel the world and discover as many festivals as  possible in 150 days. On my channel,  I  share  with  you  my  experience  of  the different festivals. I also ask my subscribers to find festivals that they challenge me to attend.

So, if you want to be part of the world's different festivals, don't forget to like, share and subscribe.

In this image we can see a person wearing spectacles.

<!-- image -->

## Here goes the cheese!

Watching grown up men tumbling down a hill is quite a sight to behold .  The Cheese Rolling Festival, held in England, is a festival which attracts over 40  contestants  yearly.  The  festival  starts  with  a huge cheese sent rolling down the hill with the contestants scampering after  it.  The  first  person who crosses the finish line wins.

Everytime,  there  are  some  minor  injuries  and bruises,  but  it  doesn't  damper  the gleeful and electrifying atmosphere.  The  Cheese  Rolling Festival  is  one  of  the 'strangest  competitions  in the history of mankind.'

Despite  having  a  lot  of  bruises,  I  thoroughly enjoyed  my  experience  at  the  Cheese  Rolling Festival.

In this image we can see a collage of photos. In the collage there are people standing and holding a wooden object.

<!-- image -->

## 2c. Read the text again and answer the following questions.

1. What is the name of Mr Globetrotter's channel?
2. What is Mr Globetrotter's challenge?
3. What does Mr Globetrotter ask his subscribers to do?
4. Where is the Cheese Rolling Festival held?
5. Around how many contestants participate in that festival?
6. What happens at the Cheese Rolling Festival?

## 2d. Going deeper in the text: Answer the following questions.

1. Explain the following expressions: ' a sight to behold '  and ' scampering ' .
2. According to you, why does Mr Globetrotter think that the Cheese Rolling Festival is one of the  strangest competitions in the history of mankind?
3. How safe is this event for the participants? How do you know?
4. Describe how you would organise a similar festival in your neighbourhood.

## Teaching Tip:

Guide  students  to  come  up  with  a  Mauritianised  and  creative version of the festival.

## Below is one of the  festivals that has been voted as one of the most challenging festivals that Mr Globetrotter will have to attend.

The image is a collage of multiple images, each featuring a different object or scene. Here is a detailed description of the objects present in the image:

1. **Top Left Corner**: There is a red flag with a white emblem. The flag has a red background with a white emblem. The flag is placed on a white background.

2. **Top Center**: There is a white object with a red emblem. The object is placed on a white background.

3. **Top Right Corner**: There is a blue object with a red emblem. The blue object is placed on a white background.

4. **Bottom Left Corner**: There is a white object with a red emblem. The object is placed on a white background.

5. **Bottom Center**: There is a white object with a red emblem. The object is placed on a white background.

6. **Bottom Right Corner**: There is a blue object with a red emblem. The blue object is placed on a

<!-- image -->

HOME     VIDEOS TRAVEL DISCUSSION     ABOUT     CONTACT

Festivals &gt; My bucket list of festivals

In this image we can see a person with a mask and a stick. In the background there is a wall.

<!-- image -->

The Cocullo Snake Festival is not for the faint-hearted .  This festival is definitely not for those with ophidiophobia as it attracts snake lovers and their snakes. This festival is held on the 1st of May in the quaint medieval town of Cocullo in St Domenico. It is known as one of the strangest and most unique festivals in Italy.

There are several myths associated with the celebration of this festival and one of the most popular is its association with Saint Dominic. According to legend, during the 11th century, Saint Dominic cleared the fields of Cocullo which were infested with snakes. Since that day, the festival of snakes is held in that town.

Although it was originally a pagan festival, it is now a very popular festival because people from different cultures celebrate it.  It attracts snake lovers from all around the world who enthusiastically attend the festival to proudly showcase their snakes.

On the day of the festival, the wooden statue of Saint Dominic is taken out of the church and  snakes  are  placed  onto  the  statue.  Then,  a surreal procession  of  snake  lovers  and their snakes goes through the town and ends up back at the same church. Girls dressed in traditional costumes follow the procession with delicious local cakes. The festival ends with a spectacular display of fireworks.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

1000 votes

- 2f. Write 'agree' or 'disagree' next to each of the following statements.

1. The Cocullo Festival is a festival that snake lovers like attending.

2. The Cocullo Festival is celebrated in Spain.

3. The Cocullo Festival is celebrated in the month of May.

4. The Cocullo Festival is known as being a very funny festival.

5. The Cocullo Snake Festival is celebrated because of Saint Dominic.

6. Saint Dominic cleaned the fields of Cocullo which were full of snails.

7. On the day of the festival, snakes are placed on the statue of Saint Dominic.

## Teaching Tip:

The statements can be extended and more questions may be asked around the different information to check on the understanding of students.

## 2g. Going deeper into the text: Answer the following questions.

1. Explain what is meant by the terms: ' ophidiophobia '  and ' medieval' .
2. Why is the Cocullo festival known as one of the strangest festivals in Italy?
3. Why is the festival now well-known in the world?
4. Imagine you are at the Cocullo Festival. Describe your feelings while attending the festival.

<!-- image -->

- 3a. Fill in the missing information in the tables below. The first one has been done for you.

## 1.   Example:

## Definition

To be really happy and excited about something

## Sentence

The infant gave a gleeful laugh as soon as he saw the clown.

## Definition

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Illustration

<!-- image -->

## Connections: Synonym &amp; Antonym

Synonym: merry, joyful, delighted Antonym: gloomy

## Illustration

<!-- image -->

E\_ \_ \_ \_ \_ \_F\_ \_ \_G

## Sentence

## Connections: Synonym &amp; Antonym

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Synonym: exciting, energising

Antonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2.

## GLEEFUL

3.

<!-- image -->

<!-- image -->

4.

Q\_ \_ \_ \_T

## FAINT-HEARTED

## Definition

## Definition

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Synonym: charming, pleasantly old fashioned

Antonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Synonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Antonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Sentence

## Sentence

## Connections: Synonym &amp; Antonym

## Connections: Synonym &amp; Antonym

## Illustration

## Illustration

6.

<!-- image -->

P\_ \_ \_ \_

## Definition

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Religious beliefs apart from the main world religions

Synonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Antonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Sentence

## Connections: Synonym &amp; Antonym

## Illustration

S\_ \_ \_ \_ \_L

## Definition

Synonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Antonym: natural, genuine

## Sentence

## Illustration

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Connections: Synonym &amp; Antonym

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

7.

8.

<!-- image -->

S\_ \_ \_ \_ \_ \_ \_ \_ \_ R

S\_ \_ \_ C \_ \_ E

## Definition

## Definition

Beautiful in a dramatic and eye- catching way

## Sentence

## Sentence

## Illustration

## Illustration

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Synonym: exhibit, display

Antonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Connections: Synonym &amp; Antonym

## Connections: Synonym &amp; Antonym

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Synonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Antonym:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 3b. Replace each of the underlined words or phrases with one word from the list below.

breath-taking

gigantic

decorative

deafening

voracious

- (i) The extremely loud noise of the audience's cheer at the music festival was unbearable.
- (ii) The designs on the buildings during the Por Lwi by Light festival were fascinating .
- (iii) Ahmed's greedy son insisted at stopping at all food stalls to taste the different types of foods at the festival.
- (iv) The pilgrims carried huge statues of their gods towards their temple.
- (v) The children were excited to adorn the christmas tree with attractive streamers.

<!-- image -->

Read the news headline below. Pay attention to the use of Passive Voice.

25 April 2020

## MORE THAN TEN THOUSAND LANTERNS WERE LIT FOR YEE PENG FESTIVAL

The sky was illuminated by more than ten thousand lanterns on Friday night. Every year,  these  floating  paper  lanterns are  released at  Nawarat  Bridge,  in  Chiang  Mai, Thailand. The festival begins as early as 6:30 pm and is continued throughout the night. It is considered illegal to fly the lanterns before air traffic is stopped as air traffic might be affected.

In this image we can see many lanterns hanging from the ceiling.

<!-- image -->

## (a) Find three examples from the text that fit the rules below.

The image is a chart titled "RULES." The chart is divided into three main sections: Change of Tenses, Use of "by," and Change from Subject to Object. Each section is represented by a different color and contains text.

The chart is structured in a way that it is easy to understand and interpret. The text in each section is aligned to the left and right, with a gray background. The text is in a sans-serif font, which makes it easy to read.

### Change of Tenses
The chart is labeled with the word "Change of Tenses" at the top. Below this, there is a blue box with the text "Change of Tenses add participle." This indicates that the chart is about the addition of a verb in the present tense.

### Use of "by"
The chart is labeled with the word "Use of "by"" at the bottom. Below this, there is a

<!-- image -->

## Teaching Tip:

Get the students to find examples from the text on page 42 of the rules used in passive voice. Consolidate the teaching of these rules by adding examples of your own.

This image consists of a poster with text and images. The poster is in a cartoon style. The background is white with a pattern of tiny dots. There are some images of people and text on the poster.

<!-- image -->

In this image, we can see the text and images.

<!-- image -->

<!-- image -->

## ACTIVITY 5: Grammar : Prepositions

## 5a. Observe the words underlined.

In this image, we can see a person's profile picture and some text.

<!-- image -->

## Teaching Tip:

Get the students to discuss how the prepositions are used  for  different  functions.  Remind  students  that the same preposition can have different purposes.

REMEMBER

<!-- image -->

The prepositions that have been used above identify time, place and direction.

## Below you will find a table of prepositions that can be used to indicate time, place and directions.

| Time                                                       | Place                                                   | Direction                                                  |
|------------------------------------------------------------|---------------------------------------------------------|------------------------------------------------------------|
| after before during from on past since through to by until | above behind below besides between by in within near on | against along down from into off on onto out of towards up |

## Teaching Tip:

Elicit a few examples from the students, getting them to use some of the prepositions above. Consolidate on how prepositions can be used for different purposes.

## 5b. Fill in the blanks below using appropriate prepositions from the above table.

## Shayna's scrapbook on Indigenous Festivals

In this image I can see the text on the image.

<!-- image -->

Laura Dance Festival

In this image we can see a group of people. They are wearing the clothes. In the background we can see the trees.

<!-- image -->

The Laura Dance  Festival is held \_\_\_ the town of Laura. It is normally celebrated \_\_\_ the months of JuneJuly. It is one of the oldest Aboriginal cultural  festivals  in  Australia.  People from  numerous  communities  travel \_\_\_ Laura, meeting to perform cultural ceremonies, sing and dance to ancient songs.

## Oaxaca, Mexico

Lunes Del Cerro (Guelaguetza Festival)

In this image we can see a group of people standing on the road. In the background there are buildings and the sky is cloudy.

<!-- image -->

The Lunes Del Cerro, also known as the Guelaguetza Festival, is celebrated \_\_\_ the last two weeks \_\_\_ July, every year.  Nestled \_\_\_ the Sierra Madre Valley of Southern Mexico, Oaxaca de Juarez hosts the festival each year. People travel all the way \_\_\_ the valley to celebrate together the richness of their individual culture. \_\_\_ each festival, a local woman is selected to perform the role of the goddess of corn, Centeol.

- 5c. Research about any indigenous festival. Share the information you found with your classmates using appropriate prepositions in your sentences.

<!-- image -->

## ACTIVITY 6: Just For Fun

6a. Read the text below.

## The Pamplona Bull Run

In this image we can see a group of people standing on the road. In the background there are some buildings and a person standing on the road.

<!-- image -->

Booof! It felt as if thunder had crashed down on earth. The deafening sound of hooves thudding on the ground could be heard. Yes! The bulls had been released and had begun their run. Varun had always wanted to live the experience of the Pamplona Bull Run. Now he was actually standing in the streets of Spain, witnessing this exhilarating sight!

Runners, all dressed in milky white clothes and bloody red scarves tied around their necks, raced forward. Varun could see beads of sweat trickling down the faces of some panicked runners. They raced for their lives in the same direction as the rampaging bulls.  The atmosphere was electrifying as shrill screams pierced through the air. Varun felt as if he could actually see the runners' hearts racing an extra mile as some scrambled out of the way and missed being attacked in the nick of time.

The Pamplona Bull Run is celebrated in Spain to honour Saint Fermin, every year from 6 to 14 July. Many tourists, like Varun, fly down to Spain to witness this amazing sight where numerous adventurers  race  down  the  streets  with  the  noble  beasts  at  their  pursuit.  Wooden  barriers  are positioned, blocking off side streets and alleyways , guiding the bulls along the desired path. At the end of this thrilling run, the bulls meet a sad fate as they are put to death by the matador .

Spectators normally make their way along the fences or move to the balcony of neighbouring flats to make the most of this exciting spectacle, cheering loudly for the runners. It is needless to say that the Pamplona Bull Run is considered to be a very dangerous event. Each year, approximately 50 to 100 runners are injured quite badly and have to return home maimed .

## GLOSSARY

deafening:

extremely loud

thudding:

making a dull sound

exhilarating:

thrilling

rampaging:

moving violently

shrill:

loud and piercing

scrambled:

moved quickly

alleyways:

lanes

matador:

bullfighter whose job is to kill the bull

maimed:

injured

6b  i)  Write  down  the  words  that  have  been  used  to  describe  the  Pamplona  Bull  Run. Discuss in groups what this tells you about the adventurers who run during the Pamplona Bull Run.

- ii) Imagine you are one of the bulls running for the Pamplona Bull Run. How would you feel during this experience?

<!-- image -->

## Writing Activity

Festivals  are  important  occasions  for  people  to  gather  and  share  special  moments  as  a community. If you have attended any festival, you may have experienced a number of things through all your senses. Below is an example of what can be experienced during the National Day Celebrations in Mauritius.

In this image, we can see a poster with some text and images.

<!-- image -->

A.

Now, use the same template to identify the different experiences you could have at a local festival.

B:

In this image, we can see a diagram with four circles. In the circles, we can see the names of festival.

<!-- image -->

From the information gathered, describe a local festival you attended.

## Teaching Tip:

Guide students to organise the ideas laid out in the template above into different paragraphs. Encourage them to use descriptive vocabulary in their writing.

In this image we can see a collage of images. In the images we can see people, some of them are holding hands, some of them are smiling, some of them are wearing clothes, some of them are wearing hats, some of them are wearing gloves, some of them are wearing shoes, some of them are holding a book, some of them are holding a pen, some of them are holding a paper, some of them are holding a pen, some of them are holding a book, some of them are holding a pen, some of them are holding a book, some of them are holding a pen, some of them are holding a book, some of them are holding a pen, some of them are holding a book, some of them are holding a pen, some of them are holding a book, some of them are holding a pen, some of them are holding a book, some of them are holding a pen, some of them are holding a book, some of them are

<!-- image -->

Looking Forward

This unit aims to help you discover and learn about the variety of jobs that people do.

- You will listen:
- to a conversation between two friends
- You will speak:
- about your response in a given situation
- You will read:
- a newsletter and an advertisement
- You will write:
- a CV and a job application letter

<!-- image -->

## ACTIVITY 1: Communication Skills

1a. Listening for the main idea

Emmanuel  and  Meeta  are  talking  about  their  plans  for  the  holidays.  Listen  to  their conversation carefully.

In this image we can see a building. There are windows. There are people.

<!-- image -->

- 1b. Listen to the conversation carefully and fill the table below with the information obtained.

## Working During Holidays

Emmanuel's arguments for working during

holidays

Meeta's arguments for working during

holidays

## 1c. Speaking: Responding to a given situation

Emmanuel has worked for six weeks as a shop assistant. Below are four situations he has encountered when he was working in the shop. In groups of four, choose a situation each and take turns to share what you would have done if you had faced a similar situation.

1

On my first  day  of  work,  I  was really  shocked  to  learn  that  I would not have a desk to work at.  I  was  expected  to  stand  on my  feet  all  day  and  just  relax when  I  got  my  thirty  minutes' break.  At  the  end  of  that  first day, my feet were so sore that I wanted to stop working.

2

I will never forget that horrid customer  who  came  to  the  shop during  the  holidays.  She  took  her time  to  go  through  the  shelves and  then  chose  at  least  ten  pairs of  shoes.  She  wanted  to  try  all  of them.  I  took  a  lot  of  time  to  look for  all  ten  pairs  of  shoes.  When  I returned,  she  started  shouting  at me because I had taken so long and left the shop without trying any of the shoes. Before leaving the shop, she told my manager that I was not a good worker.

3

When  I  decided  to  work  in  a shop,  I  had  not  realised  shops would  be  so  crowded  during holidays.  During  the  six  weeks that I  worked,  the  shop  was always full of customers wanting to be served. I had to deal with people  I  had  never  even  talked to  in  my  life,  and  keep  a  polite smile. Some days, I really felt like crying because of the number of times they would call me to help them.

One  of  the  most  unforgettable experiences I had while I was working  was  when  I  realised  that someone  had  sneaked  a  pair  of shoes in his bag, without paying for it. I wouldn't even have realised this if  my  colleague  had  not  pointed the  man  to  me  and  told  me  that he  looked  suspicious.  I  informed my manager who actually stopped him at the door and went through his bag. There was indeed a pair of shoes in his bag.

## Teaching Tip:

Divide the class in groups of four. Get each student to choose a situation. Brainstorm these situations with the class to get them to share how they would have reacted. You can also come up with other situations. Preteach any necessary vocabulary to ensure that students understand.

4

<!-- image -->

## ACTIVITY 2: Reading Comprehension

- 2a. Esha has already completed her studies and left Sunshine Secondary School. She meets one of her old school friends and they talk  about what they have done after they left secondary school. Imagine the conversation between them.

The image is a simple, colorful graphic with a white background. It features a woman standing with a confident pose, holding a large rectangular object in her right hand. She is wearing a sleeveless, light blue dress with a purple scarf tied around her neck. Her hair is long and dark, and she has a warm smile on her face.

In front of her, there is a rectangular object that appears to be a sign or a piece of paper. The sign is large and appears to be a large rectangular piece of paper, possibly a piece of paper that is being held up by the woman. The sign is white with a red border, and it has a design that includes a few lines of text. The text on the sign is not clearly visible, but it appears to be written in a language that is not entirely legible.

The woman is standing on a flat surface, possibly a table or a floor, and she is looking directly at the viewer. Her

<!-- image -->

## Teaching Tip:

Question students to check their understanding.

## 2b. Read the text below.

The ex-students of Sunshine Secondary School publish a newsletter once a year. This newsletter  offers  them  an  opportunity  to  share  their  life  experiences  after  having completed their studies.

## Sunshine Secondary School · Newsletter

In this image we can see a person standing and holding a stick. In the background there are trees.

<!-- image -->

VINESHA:  'My passion is writing. As a Mauritian dramatist, I am lucky to have published a few plays. I have also staged some plays at national level. I have recently created a Drama club, where youngsters learn to develop their creativity in writing or acting. '

In this image we can see a woman sitting on a chair and holding a paper in her hand. In the background there are some objects and a wall.

<!-- image -->

<!-- image -->

MANOJ: 'I am a landscaper. My job is to design gardens and make plots of land more appealing. I  normally  enjoy  creating endemic gardens during  my  projects.  I  use  a  lot  of  Mauritian plants in my projects. My vision is that one day, our native flora and fauna will be valourised . '

In this image we can see a woman is writing on the paper. In the background there is a table. On the table there are some objects.

<!-- image -->

SANDHYA:  'I  am  an  occupational  therapist. My patients are normally injured, sick or have disabilities.  Many of them cannot take care of themselves.  They  cannot  eat,  shower  or  dress by  themselves.  They  cannot  take  care  of  their homes.  I help them to develop or learn the skills to take care of their everyday occupations. My job demands a lot of dedication and patience. Very often, these patients are in a lot of pain and I  always  need  to  be  there  for  them.  However, nothing  makes  me  feel  nicer  than  seeing  one of my patients smile when they manage to do something they could not do before!'

## 2c. Circle the correct answer using the information obtained from the text.

1. Sandhya, Vinesha and Manoj \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- A are students of Sunshine Secondary school.

- B have already completed their studies.

- C are on holidays.

- D will be joining Sunshine Secondary college.

2. Vinesha likes \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- A dancing.

- B singing.

- C writing.

- D playing the piano.

3. Vinesha created \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- A an acting club.

- B a book club.

- C a cooking club.

- D a painting club.

4. As a landscaper, Manoj \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- A cleans plots of land.

- B changes the appearance of gardens to make them look nicer.

- C construct buildings on different plots of lands.

- D designs houses.

5. Manoj likes to use \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ in his projects.

- A exotic plants from other countries

- B plants from Mauritius

- C artificial plants

- D recycling crafts

6. Sandhya works with \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- A surgeons.

B

patients.

C dentists.

- D cleaners.

7. Sandhya needs to have \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ to do her work.

- A courage

- B physical strength

- C patience

- D organisation skills

## 2d. Going deeper in the text: Answer the questions below.

1. Explain the following terms as they are used in the text: ' endemic '  and ' valourised ' .
2. Why does Vinesha feel that she is lucky?
3. Would you like to be one of Vinesha's students? Say why.
4. According to you, why does Manoj make an effort to use native flora and fauna in his projects?
5. According to you, is the job of an occupational therapist an easy one? Why do you think so?

- 2e. Veer is a professional photographer and he is looking for assistants. He has posted an advert on the noticeboard of Sunshine Secondary School.

In this image, we can see a poster with some text and images.

<!-- image -->

- 2f. Westley has written an email to Veer to apply for the post of assistant photographer. Fill in the blanks below with the information obtained from the text above.

In this image, we can see a person's name is written on the image.

<!-- image -->

## 2g. Going deeper in the text: Read the text again and answer the questions below.

1. According to you, what are the most important skills for this job? State why.
2. Explain the term: ' assignments ' .
3. Should students work during their holidays? Discuss.
4. Three persons have applied for the post of assistant photographer. Their details are given below. Who do you think is more likely to be chosen for this post? In about 30 words, give two reasons to justify your choice.

| CANDIDATES   |
|--------------|
| Westley      |
| Rhea         |
| Naadir       |

## Teaching Tip:

Students can choose anyone as long as they can justify their choice.

<!-- image -->

## 3a. Circle the correct definition of the words as they are used in the texts above.

1. Vision
2. A the images seen on a television screen
3. b the ability to think differently and wisely about the future
2. Passion
5. A being very enthusiastic about something
6. B not liking something
3. Creativity
8. A ability to  work hard
9. B ability to use imagination to create something
4. Dedication
11. A devotion to work
12. B refusing to take any responsibility
5. Originality
14. A the ability to learn new things
15. b the ability to think in a new and creative manner
6. Interpersonal skills
17. A the ability to work alone
18. b the ability to interact well with people
7. Willingness
20. A to be ready to do something
21. b to refuse to do something
8. Efficiency
23. A having an adventurous spirit
24. B ability to do something successfully

## 3b (i)   Read the cover collage of Sheena's Facebook page.

In this image we can see a picture of a woman.

<!-- image -->

3b (ii)  Research and find quotes using the words in the textbox below. Share your quotes in class and explain to your classmates what you understand by them. You can stick an image of the quote you found in the box below or write it down.

dedication

willingness

efficiency

originality

creativity

interpersonal skills

## 3c. Fill in the blanks with the appropriate word from the textbox.

The image is a webpage that is designed to provide information about a job interview. The webpage is divided into two main sections: the left side and the right side.

**Left Section:**
- The left side of the page features a cartoon image of a person standing in front of a desk. The person is wearing a blue shirt and has short hair. They are holding a pen and appears to be looking at the interviewer.
- The right side of the page features a cartoon image of a person sitting at a desk. The person is wearing a white shirt and has long hair. They are holding a pen and looking at the interviewer.

**Right Section:**
- The right side of the page features a text box with the heading "I am always nervous when I have to meet my coworker." Below the heading, there is a paragraph of text that reads: "She does not scold me."
- The right side of the page features a text box

<!-- image -->

In this image we can see a cartoon image of a person sitting on a chair and holding a laptop. In front of him there is a table. On the table there is a laptop, cup, saucer and a lamp. On the right side of the image there are two persons sitting on chairs. In the background there is a wall. On the wall there are frames.

<!-- image -->

In this image we can see a cartoon image of a person holding a red color basket and walking on the road. In the background there is a building and a sign board.

<!-- image -->

In this image we can see a cartoon image of a person standing and holding a book in his hand. In the background there is a table and a person sitting on the chair.

<!-- image -->

<!-- image -->

## ACTIVITY 4: Grammar: Nouns in Apposition

- 4a. Read the sentences below and observe the words underlined.
1. Haben,  the  first  deaf-blind  lawyer,  graduated from Harvard College.

<!-- image -->

Haben Girma

2. Dr William Tan, an accomplished sportsman, was the first to finish a marathon in a wheelchair.
3. Frida Kahlo, the talented artist, spent much of her life in bed after suffering from polio.

In this image we can see a person sitting on a wheelchair. There is a watermark on the image.

<!-- image -->

<!-- image -->

Frida Kahlo

The noun phrases used to describe the first nouns are called nouns in apposition. Nouns in apposition normally offer more information or description about the first noun.

## 4b. Put the following words in the correct order to form sentences.

- 1.
- building - a house - Zaina - the strong mason - is.
2. Avish - frying - the chicken - the cook - is.
3. the  handicapped  waiter  -  took  care  -  my order - Diya - of.
4. climbed  -  Sandhya  -  a  ladder  -  the  daring firefighter - the old lady - to rescue.
5. at a concert - Adrian - performed - the graceful dancer.
6. Punit - doctor - during the operation - helped - the young male nurse - the.

<!-- image -->

## ACTIVITY 5: Grammar - Future Perfect Tense and Future Perfect Continuous Tense

- 5a. Ryan needs to do a presentation about what his dream in life is. He has designed a poster to share with his classmates. Read the poster below, paying close attention to the words in bold.

In this image, we can see a text and a picture of a person.

<!-- image -->

## Notice how

- (a)  The Future Perfect is used when an action will have ended in the future.

... will have + past participle

- (b) The Future Perfect Continuous is used when an action will have been going on for some time in the future.

...will have been + present participle

- 5b. Discuss your dream in groups using some of the verbs below as prompts.

## Teaching Tip:

After  providing  examples  of  your  own, encourage students to practise using the Future  Perfect  and  Future  Perfect  tense with verbs given.

In this image, we can see a text.

<!-- image -->

- 5c. Fill in the poster below with your information using the Future Perfect Tense and Future Perfect Continuous Tense.

In this image, we can see a table with some text and some images.

<!-- image -->

<!-- image -->

6a. Read the text below.

## Russell: The Hero

<!-- image -->

HOME     VIDEOS

NEWS

DISCUSSION

ABOUT     CONTACT

<!-- image -->

My name is Russell and today is my last day at work. I can still remember my first shift at Mcdonald's, which started from 8 a.m in the morning and lasted till midnight. It was in 1986 and I had just turned 18 when I got my dream job. During those days, people like me hardly worked. You see, I was born with Down Syndrome and for the first few years of my life, most people looked at me with pity in their eyes because of the way I looked.

'You are handicapped!' many persons would tell me.

I joined McDonald's after having completed my training. I proved that I could be professional. The day I started working,  I stopped being a handicapped person. When someone asked me if I was not normal, I would say with gusto , 'I used to be when I was in school, but now I work and I am not handicapped!'

For the past 32 years, I have worn my red uniform and my black cap with a lot of pride. To me, it looked no less than a soldier's uniform.  Being able to earn my living, despite looking the way I do, is for me a dream come true and a real achievement. Whenever I walked past the door of my workplace, I would break into a big smile. While I cleaned the tables, I would greet all the customers. For the past 32 years, I have earned my living with integrity .

People in my area call me a legendary hero but I don't see myself as a hero. I love what I do and it makes me happy. It gives me immense pleasure to share this happiness with all those around. I always think that a smile is enough to brighten someone's day.

Today, I walked into the restaurant for the last time as an employee. The staff had planned a lovely farewell party for me. They got me to cut a huge red cake and everyone shared their feelings about how it had been to work with me. I felt so much love coming from everyone. My supervisor told me that they would all miss me and that the customers would look for me. I have already started receiving some messages from some of them, asking me to keep visiting the restaurant so they can drop by to see me.

Maybe I will. But right now, I want to spend my retirement bowling. Apart from my job, bowling is my other passion. Thank you all for the love and support you gave me through my life. This world is a better place only because of the love of people like you.

## GLOSSARY

shift:

a period of time during which work is done

gusto:

enthusiasm

legendary:

famous

integrity:

honesty and strong moral principles

bowling:

playing a game in which balls are rolled down an alley at an object or group of objects

1. Imagine you are Russell's colleague. Come up with a speech to give at his farewell party.
2. You normally used to go to McDonalds and each time, Russell greeted you with a beaming smile. Describe your feelings for the treatment you got.

<!-- image -->

## ACTIVITY 7: Writing a CV and a Job Application Letter

## 7a (i) Read the advertisement below.

12

In this image, we can see a logo.

<!-- image -->

15 June 2020

## DODO COMPANY LTD

Are you a competent and dynamic college student? Are you looking for a summer job? Then join Dodo Company Ltd as a translator.

You will be required to act as a translator for French clients who want to  set  up  business  in  Mauritius  and who will be targeting English speaking tourists.

## Key duties

- Translate orally from French to English
- Translate in written form from French to English

## Kindly apply if you have:

- a good grasp of English and French
- good communication skills

Interested candidates matching the above criteria should send their cv and application at dodohotel.recruitment@gmail.com.

The closing date is on the 30 th  May 2022.

- 7a (ii)  You have decided to apply for the post of translator. You will need to write your Curriculum Vitae (CV). For this purpose, you need to fill the diagram below with all the relevant information.

The image is a diagram that shows the relationships between different categories. The categories are:
1. Qualifications
2. Achievements
3. Skills

The diagram is divided into four quadrants, each representing a different category. The colors of the quadrants are as follows:
- The top left quadrant is red, representing Qualifications.
- The top right quadrant is orange, representing Achievements.
- The bottom left quadrant is green, representing Skills.
- The bottom right quadrant is purple, representing Achievers.

Each quadrant is connected to the other by a line, forming a web-like structure. The line connecting the quadrants is a blue circle, which represents the "Translator" category.

### Detailed Description:
1. **Qualifications**:
   - The top left quadrant is red, representing Qualifications.
   - The top right quadrant is orange, representing Achievements.
   - The bottom left quadrant is green,

<!-- image -->

## Teaching Tip:

Get the students to jot down all the qualifications, skills, qualities, experience, achievement and hobbies that they think would be relevant in relation to this job .  Guide them to include information that will make an impression and help them stand out as applicants.

7a (iii) Fill in all the relevant details under the headings provided.

## E D U C A T I O N   A N D   Q U A L I F I C A T I O N S (START WITH YOUR HIGHEST QUALIFICATION INCLUSIVE OF DATES)

S K I L L S

ACHIEVEMENTS

NAME AND ADDRESS OF 2 REFEREES

## P E R S O N A L   D E T A I L S

H O B B I E S   A N D   L E I S U R E   A C T I V I T I E S

## Curriculum Vitae for

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Name:

Age:

Address:

Contact details:

Email Address:

Teaching Tip:

Guide students to include the information that is relevant and to edit their work.

7b (i) After having written your CV, prepare a letter of application. Plan the letter by filling out the graphic organiser below.

Give examples of things you have done that are relevant for this job. E.g: I successfully coordinated the fashion show for the fancy fair at my school.

Include a few interesting details that others will not think of and that will make you stand apart. E.g.: I keep a scrapbook to note interesting ideas and these help me  for future events.

Use language that is positive and which showcases your character. E.g.: I am excellent at meeting deadlines.

Persuasive techniques

Use triples to emphasise a point. E.g: I plan, organise and manage my work effectively.

## Teaching Tip:

Brainstorm the different points and get students to organise these using the graphic organiser above.

## 7b (ii)  Write your letter of application now, using the template below.

## Your Name:

Your Address:

Date:

## Employer's name:

Employer's address:

## Title of your letter: Letter of Application for …. ( include reference number)

## Salutation: Dear Madam/Sir,

## Introductory paragraph:

Inform prospective employer about the purpose of your letter.

## Paragraph 1:

The most important reason you think you are most suitable for this position.

## Paragraph 2:

The second reason you think you are suitable.

## Paragraph 3:

Other reasons why you are suitable.

## Concluding paragraph:

Inform the employer that you are available for interview and hope to hear positively from them soon.

## Signing off:

Yours faithfully,

## 7c. Share your CV and letter of application with your neighbour and ask him/her to edit and proofread. Make the necessary changes and check your work a final time.

## Teaching Tip:

Guide students to follow the steps especially the planning stages to highlight relevant information pertinent to the job.

- For the writing task, scaffold where needed especially in terms of persuasive techniques.
- Provide exemplars if needed.
- Also encourage students to use vocabulary introduced in this unit before brainstorming more in class.
- Reiterate the need to edit and proofread writing as is required for this writing task.
- Choose another job if needed.

In this image we can see a collage of different images. In the background there are some text and some images.

<!-- image -->

Looking Forward

This unit aims to help you understand the different changes that have occurred over the past decades.

- You will listen:
- to a speech about how shopping has changed over the years
- You will speak:
- about the changes that have occurred in fashion over the past decades
- You will read:
- a report and an infographic
- You will write:
- a reflective essay

<!-- image -->

## ACTIVITY 1: Communication Skills

1a. Listening for specific information

Wendy has been asked to talk about how shopping has changed over the years. Listen carefully to what she has to say.

In this image we can see a few houses. There are some objects in the image. There are some trees and the sky is in blue color.

<!-- image -->

In this image we can see a person wearing a blue color shirt and a black color tag is holding a box in the hand.

<!-- image -->

In this image we can see a shopping mall. There are people walking on the escalator. There are stores in the background.

<!-- image -->

- (i)  Listen to the text again and fill the table below with details on how shopping has changed over the years.
- (ii)  After listening to the text again, share your thoughts about the changes that have taken place over the years.

## Teaching Tip:

Get students to reflect on how things have changed from the 1980s to recently.

- 1b. Speaking - Description
- (i)  Look at the scrapbook in the next page and describe the changes with respect to the different decades.
- (ii)  Find some pictures of which clothes are fashionable currently. You can add them on pages 86-87. Are they different from what was worn in the past?
- (iii)  Add an image of how clothes might be in 2050 on pages 86-87. Will they be different from what is worn currently?

## Teaching Tip:

Get students to fill pages 86-87 with images of clothes worn in 2019 and of clothes that might be worn in 2050. You can also get them to draw these images.

## WOMEN FASHION EVOLUTION

<!-- image -->

1980

In this image we can see a cartoon image of two women. One woman is holding a bag.

<!-- image -->

<!-- image -->

1980

<!-- image -->

1990

1990

<!-- image -->

2000

2010

<!-- image -->

2010

<!-- image -->

In this image, we can see a poster with some images of men.

<!-- image -->

## WOMEN'S FASHION - 2019

## WOMEN'S FASHION - 2050

In this image, we can see a book with some text on it.

<!-- image -->

<!-- image -->

## ACTIVITY 2: Reading Comprehension

## 2a. Look at the pictures below and discuss what you can see.

## DIFFERENT TYPES OF JOBS IN MAURITIUS

In this image we can see two persons are standing on the horse. In the background we can see the trees.

<!-- image -->

In this image we can see a person wearing a blue color dress and a cloth is working on the sewing machine. In the background there are many machines.

<!-- image -->

In this image we can see three people sitting on the chairs. The person in the middle is wearing a suit.

<!-- image -->

In this image we can see a group of people standing and smiling.

<!-- image -->

| What I knowalready                                 | What I want toknow   |
|----------------------------------------------------|----------------------|
| What types of jobs did most people do in the past? |                      |
| What types of jobs do they do now?                 |                      |
| What types of jobs still exist?                    |                      |

## Teaching Tip:

Use questions from the table to get students to brainstorm the topic. You can use the pictures above to guide the discussion. Encourage them to come up with questions about what they want to know in regards to the text and write them in the second column of the table. You can use the title to get students to predict information present in the text.

- 2b. Career  Network  recently  published  a  report  about  Mauritian  youths'  attitudes towards work. Read the text below and answer the questions that follow.

## MAURITIAN YOUTHS' ATTITUDES TOWARDS WORK

Summary:  Since 1968, the economy of Mauritius has evolved very rapidly and this has changed the attitudes of young Mauritians towards work. The study carried out by Career Network shows how the youth is working differently today.

## Job-Hopping

Earlier,  an  employee  worked  at  the  same  place  until  he/she retired .  However,  the  study revealed that today a person spends, on average, 4 to 5 years in one organisation. The youth prefers  to  change  jobs  during  his/her  career  and  job-hopping  is  becoming  more  common. They undertake different  jobs  for  different  reasons.  Some  prefer acquiring different  skills and experiences and become more professional. Others move when they get a better salary, employers and working conditions.

## Flexible Work Schedule

Traditionally,  most  Mauritians  had  preferred  a  full-time  job,  working  from  9  a.m  to  4  p.m. However, now, workers prefer a more flexible work schedule . Moreover, many work from home or work while travelling. Employees are valued for the quality of their work rather than on how many hours they work.

## Multiple Jobs

The report also stated that young Mauritians choose more than one job to cope with the cost of  living.  Part-time  jobs,  opening  a  side-business  and  working  on  short-term  contracts  are popular among the youth now.

## Working Space

In the 1990s, workers of the same company would socialise only amongst themselves. Now, as small businesses emerge , many organisations share the same offices to save on cost. Thus, the young Mauritian employees get the opportunity to socialise with those doing different jobs than them. This allows them to share ideas and experience and therefore grow at different levels.

## 2c. State whether the following statements are True or False.

1. The study revealed that youths' attitudes towards work in Mauritius have not changed.

2. Job-hopping is when one person keeps working in the same company throughout his whole life.

3. Many Mauritian youths change jobs after 4-5 years.

4. Now, Mauritians also work when they are travelling.

5. Young Mauritians take up more than one job at the same time.

6. Many companies do not use the same working space as they like to have offices of their own.

7. Workers grow by socialising with workers from other companies.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 2d. Going deeper in the text: Answer the questions below.

1. Explain the following expression as it is used in the text: ' flexible work schedule ' .
2. Why do Mauritians not keep the same job throughout their whole life nowadays?
3. Why does the Mauritian youth take up more than one job at the same time?
4. Would you share the same attitudes towards work as those discussed in the study? Justify your answer.

## 2e. Career Network has also published an infographic about Mauritian youths' attitudes towards work. Read the infographic below.

In this image, we can see a diagram. There are some text and numbers on the image.

<!-- image -->

## 2f. Read the infographic again and answer the following questions.

1. How old are those who believe they can adapt to different work situations?
2. What are most Mauritian youths sure of?
3. What is the percentage of Mauritian youths who feel they do not have enough technological skills?
4. How do women view changes in work in the future?

## 2g. Going deeper in the text: Answer the questions below.

1. Discuss whether it is better to work for yourself or for others.
2. Do you think that technological skills are necessary for any profession? Why do you think so?
3. According to you, will the ways of working be different in the decades to come? How do you think it might be different?

4

## ACTIVITY 3: Boost your vocabulary

<!-- image -->

3a (i) Complete the crossword with the vocabulary used in the texts above.

2

In this image we can see a diagram.

<!-- image -->

## ACROSS

## DOWN

- 1 learning

4

developed gradually

6

7

showed manage

- 2 carry out
- 3 have
- 5 are created
- 8 stopped working

## 3a (ii)  Fill in the blanks with the appropriate verbs from the textbox below.

## Make appropriate changes to the verb if needed.

evolved retired undertake                      cope                        possess acquiring emerge revealed

Since  Akash  joined  the  company  of  Newzone,  things  have  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  a  lot. Opportunities \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ for the company to grow more. More workers joined the company. Akash moved from occupying a small office to a bigger and modern one. Now, there are around 100 workers working in Newzone which \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ the best reputation as a technological company. Many of Akash's older colleagues have already \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and are now making the most of life after having left work. Unfortunately, many were unable to \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ with the demands of the growing company and have also left. However, Akash did not leave. Over the years, he learnt to \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ all responsibilities given to him and \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ the necessary skills and experience that was needed to grow professionally. In 2018, it was \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ that Akash was the best employee of the company. He felt extremely happy for having given his best at work for all these years.

## 3b. Replace the words in italics as used in the sentences with its appropriate synonym. Make appropriate changes to the verb if needed.

<!-- image -->

1. It was impossible for Sharvin to imagine living a day without drinking a drop of water.
2. Judy is tired of changing her plans every time because of the caprices of the weather.
3. Vaishali did not expect that the weather would change when she left home in the morning.
4. The judge maintained his authority over the court amidst the noise made.
5. Yaksh kept quiet, unable to think of an answer that did not show his anger.

<!-- image -->

## ACTIVITY 4: Passive Voice

Dr Wen, a time traveller, has come to visit us in 2020. He is talking about inventions of the past and how they have changed in modern times. Below are the five inventions that Dr Wen talks about.

- 4a. Transform the sentences below in the passive voice. Pay attention to the changes usually made in the passive voice. The first one has been done for you.

In this image we can see a paper with a pen and a note on it.

<!-- image -->

In this image I can see a paper with some text and a picture of a person.

<!-- image -->

Dr Wen has time travelled again but this time he is visiting the future. He is in the year 2169 and everything has changed again.

- 4b. Write about future inventions using sentences in the passive voice. Some words have been given to help you. The first one has been done for you.

In this image we can see a person sitting on the bed and looking at the other person. In the background we can see a window and a wall.

<!-- image -->

In this image we can see two persons standing on the floor. In the background there is a blue color circle.

<!-- image -->

Video call applications - replace - hologram.

In  2169,  video  call  applications  have  been replaced by holograms.

Teleportation - prefer - cars.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image we can see the sky, buildings, trees, plants, and some objects.

<!-- image -->

In this image we can see the Earth.

<!-- image -->

Colonise - Mars - people.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Discover - new - planet.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## 5a. Read the following sentences and pay attention to the dash.

1. The Italian artist - Leonardo Da Vinci - invented many devices.
2. There are four inventions which changed the world - the wheel, the nail, the telephone and the internet.
3. Alessandro Volta invented the battery - Thomas Edison developed the electric light.

## The dash has a number of uses such as:

- to create a break in a sentence so as to add more information.
- to create emphasis.
- in place of a semicolon.

## 5b. Read the following sentences and add a dash where appropriate.

1. The inventor Esther Sans Takeuchi was a finalist for the inventor award for inventing batteries to reset the heart.
2. Leonardo Da Vinci came up with many ideas flying machines, parachutes and weapons.
3. Steve Jobs launched Apple Mark Zuckerberg created Facebook.

## Teaching Tip:

Emphasise on when a dash is used instead of a semicolon.

<!-- image -->

6a. Read the text below.

## Technology is always on the move

The Cupidon family was visiting Australia on holiday. Yashin found the unusual sights extraordinary as these were very different from what he saw in Rodrigues. That afternoon, the family was visiting a  park in Sydney. Mr Cupidon had packed his Canon camera and some spare batteries to take pictures.  He  had  also  brought  his  Walkman,  his  headphones  and  some  of  his  favourite  audio cassettes.

The parents had decided to take the train on that day. As they were waiting for it, Yashin wandered around and stared at everything and everybody. The shiny trains, the foreign voices, the music in the station, and the busy people coming and going, fascinated him. Then, something very peculiar caught his eyes. A lady was talking to a box! The six year old young boy ran to his dad and shouted, 'Papa, look at the lady! Why is she talking to a box?' His father answered, 'Son, this 'box' is called a mobile phone.'

Yashin was very excited. The phone that he was familiar with was fixed to the wall and had wires. What he saw now left him speechless! Yashin couldn't understand how a phone could be cordless and not attached to a wall as was the case for their landline phone in Rodrigues. His parents tried to explain to him what a mobile phone was. But he could not understand. Mr Cupidon told him that one day when the mobile phone would be available in Rodrigues, he would get him one.

Time has gone by and today, 30-year-old Yashin works as a salesman for a mobile network company. He communicates with his colleagues and friends via his mobile phone and even makes video calls to his relatives living in Australia. Yashin is now familiar with mobile technology; he is no longer that small boy who discovered the mobile phone and thought it was a box. The big 'box' is now a modern device that allows people to communicate, to entertain themselves and to stay connected.

However, he still cannot help feeling like that little boy each time a new technological device is invented. Technology has indeed made a great leap and continues to progress.

## GLOSSARY

peculiar:

unusual

cordless:

which works without wires

device:

gadget

1. Yashin was amazed at something he had never encountered before. Can you think of some possible inventions which we could be using in the future? Draw and name these inventions. Share your inventions with your class.

<!-- image -->

## ACTIVITY 7: Writing a Reflective Essay

## 7a. Spot the difference.

Life  has  changed a lot in the past decades. These are two sets of images of the same playground; one set has been taken a few decades ago. The second one was taken in 2019. In pairs, find the changes have occurred over time.

## Teaching Tip:

Encourage students to identify key words for this question. Get them to use the pictures as trigger. Guide them to discuss about the different ideas.

In this image we can see a painting. In the painting we can see a bench. In the background there are some trees.

<!-- image -->

In this image we can see two persons sitting on a bench. In the background there are trees.

<!-- image -->

In this image we can see a kid jumping in the mud. In the background there are trees and a fence.

<!-- image -->

In this image we can see a cartoon image of a building, a person, a fence, a house, a tree, a plant, a grass, a pond, a hill and a sky with clouds.

<!-- image -->

In this image, we can see a person holding a bowl. In the background, there are trees.

<!-- image -->

In this image we can see a kid sitting on the floor. In the background there is a wall.

<!-- image -->

In this image we can see a boy riding a bicycle. In the background there is a fence.

<!-- image -->

In this image we can see a cartoon image of a boy. In the background there are buildings and trees.

<!-- image -->

In this image we can see a cartoon image of a girl. In the background there is a wall. On the right side of the image there is a bed.

<!-- image -->

In this image we can see a cartoon image of a person riding a bicycle on the road. There is a person wearing a helmet and a helmet is riding a bicycle. There is a road. There are houses. There is a tree.

<!-- image -->

- 7b. 'Games have changed a lot in the past decades' .  Reflect on the impact of these changes on our lives and write a reflective essay of about 200 words.

In this image we can see a person standing and holding a book.

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->

This unit aims to help you learn about the different issues that exist around the world.

- You will listen:
- to a news bulletin on violence at school
- You will speak:
- about violence in society and debate about it
- You will read:
- a magazine article
- You will write:
- a short story

<!-- image -->

## ACTIVITY 1: Communication Skills

1a. Listening - Listening with empathy

Listen  carefully  to  the  news  bulletin  on  violence  in  schools  and  answer  the  following questions.

In this image we can see a person standing on the floor and holding a book in his hand. He is wearing a white shirt and black pant. In front of him there is a board. On the board there are some words written. On the right side of the image there are some people sitting on the chairs.

<!-- image -->

1. What problems are teachers facing nowadays?
2. How would you have reacted in the place of Mr Vishal?
3. According to you, why are students more violent in class now?

## 1b. Speaking - Debate

## (i)  Enact the scene below in pairs and add ideas of your own as you go along.

In this image, we can see a cartoon image of a person. We can also see some text.

<!-- image -->

- (ii)  Debate on this following statement: 'Teenagers are becoming more and more violent nowadays.'

Below is a table to help you gather your ideas. One example has been done for you.

## Teaching Tip:

Brainstorm the topic and get the students to fill the mindmap below before starting the debate . Introduce the students to the concept of debating and explain the procedures.

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

## ACTIVITY 2: Reading Comprehension

- 2a. On the next page, you will find  some  information  from  Greta's  scrapbook.  Look carefully at the text and discuss it with your friend.

## While discussing, consider the questions below:

- What is Greta's scrapbook about?
- What message do you think Greta wants to convey?
- What are your views about these issues?

In this image we can see a poster with some text and images.

<!-- image -->

- 2b. Choose and cut out two of the pictures below and add them to the scrapbook on page 113. Discuss why you have included them.

## Teaching Tip:

Guide the students to explain why they chose the different pictures and how they relate to the issues already discussed above.

In this image we can see vehicles on the road. There is smoke in the image.

<!-- image -->

In this image we can see a factory. In the background there is a sky.

<!-- image -->

In this image we can see a pile of drums and some other objects.

<!-- image -->

In this image we can see a beach with sand, stones, water, and the sky.

<!-- image -->

In this image we can see a fire.

<!-- image -->

In this image we can see a book with some text on it.

<!-- image -->

2c (i) Below  are  some  examples  of  the  Ecological  #10yearchallenge#.  Read  the  texts carefully.

#10yearchallenge#RondoniaBrazil#Deforestation

In this image, we can see a collage of images.

<!-- image -->

The  Amazon,  once  home  to  a lush forest,  has  undergone  massive  deforestation. The most affected region is the Rondonia region of Brazil. Over time, the forest has become expanses of barren land as farmers destroy it for agriculture. Deforestation has devastating consequences. Many wildlife species are endangered. Animals such as the river dolphins of the Amazon and the jaguars are currently under threat.

#10yearchallenge#ColumbiaGlacierAlaska#GobalWarming

In this image we can see a collage of different images.

<!-- image -->

Columbia Glacier is one of the most rapidly changing glaciers in the world. Due to global warming,  it  is  melting  fast.  This  can  lead  to  a  rise  in  sea  level  which  has significant consequences for small islands around the world.

Moreover,  the  natural  habitats  of  animals  such  as  the  polar  bears  and  the  seals  are gradually disappearing, forcing them to move to inhabited areas.

## 2c (ii)  Fill in the blanks using information from the text above. You can use your own words to write your sentences.

1. The Amazon has \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

2. The \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ is the most affected region.

3. Farmers have cleared the forests because \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

4. One consequence of destroying forests is that \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

5. Some of the animals which are under threat are \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

6. Columbia Glacier is melting fast because of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ which can lead

- to \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

7. Due to this, the places where animals live are being \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and

- they need to \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ .

## 2c (iii)  Going deeper in the text: Answer the following questions.

1. Explain the expression: ' expanses of barren land ' .
2. Are there other consequences of deforestation? Name a few that you know of.
3. According to you, what has led to global warming?
4. List a few consequences of global warming that you know of.
5. Is  there  anything  that  can  be  done  to  save  the  planet  from  deforestation  and  global warming? Name a few ways through which we can protect the planet.

2c (iv)  After having read the above, fill this incomplete post with information of your own.

- #10yearchallenge#jaguar#lossofhabitat

The jaguars are inhabitants of the Amazon forest.

In this image we can see a cheetah.

<!-- image -->

#10yearchallenge#jaguar#lossofhabitat

In this image there is a poster with some text and a woman standing on the right side.

<!-- image -->

I n November 2018, the world witnessed a  great  act  of  courage  from  a  15  year old. The image of a girl sitting outside the  Swedish  Parliament  alone,  going  on strike,  became  a  symbol  of  courage  and determination.

According to organisers, a phenomenal 1.6 million people in 133 countries participated in  a  climate  strike.  Most  of  the  protesters were students who walked out of school for a few minutes, an hour or a full day march.

Greta  Thurnberg,  the  climate  activist  is the  youngest  but  the  loudest  voice  in  the fight  against  climate  change.  When  she was  11,  Thurnberg  was  so  affected  by  the gruesome changes in climate that she became severely  depressed.  She  could  not understand why nothing was being done to solve  this  problem.  She  therefore  decided to  protest  against  the blatant inaction  of the government and thus went on strike in front of the Swedish parliament.

Thurnberg  soon  became  a  popular  face and gained millions of followers worldwide who  joined  her  cause  in  their  own  ways.

Since then, Thurnberg has spoken at various meetings including the United Nations climate  change  conference  in  December 2018 among many others. Greta's struggle against  climate  change  is  not  only  limited to strikes and impassioned speeches but it has also changed her life. Greta has stopped eating  meat  and  prefers  to  travel  by  train instead of plane.

Greta's unwavering dedication was recognised  when  she  was  nominated  for Nobel  Peace  in  March  2019.  She  knows action  on  climate  change  will  not  happen instantly but she is prepared to work hard for this cause over the years to come.

## 2d (i) Fill the bio sheet below with information from the text.

Name

Age

Gender

Nationality

Fighting for the cause of

Protested alone in front of

Gave a speech at

In this image, we can see a list of numbers.

<!-- image -->

2d (ii)  Going deeper into the text: Answer the following questions.

1. Why was it a great act of courage for a 15 year old to sit outside the parliament?
2.   Why did Greta become severely depressed when she was 11?
3.   How did Greta inspire students?
4.   Would you have acted in the same way as Greta did for a cause you believe in? Justify your answer.

<!-- image -->

## 3a. Circle the correct meaning of the words from the text.

| lush         | A abundant      | B barren      |
|--------------|-----------------|---------------|
| devastating  | A gorgeous      | B disastrous  |
| significant  | A not necessary | B important   |
| A phenomenal | extraordinary   | B common      |
| gruesome     | A dreadful      | B pleasant    |
| blatant      | A unclear       | B obvious     |
| impassioned  | A heartfelt     | B unconcerned |
| unwavering   | A weak          | B firm        |

- 3b. Imagine you are Greta giving an interview. Use the words learnt from the text to answer the questions asked.

<!-- image -->

Greta, congratulations  on  the  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ success of your protest. Could you tell us about your fight?

I want to fight the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

consequences of global warming.

<!-- image -->

What  exactly  are  the  consequences of global warming?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  forests  are  disappearing  and animals are meeting a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ end.

<!-- image -->

<!-- image -->

<!-- image -->

Do  you  think  people  are  showing enough concern?

I  think  there  is  a  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  lack  of concern from some people.

What motivates you to fight for this cause?

I  have  this  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  belief  that  we should protect our planet.

What  can  be  done  to  protect  our planet?

If we want to see \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ changes we need to take \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ measures.

## 3c. Explain the words below and write a sentence to make its meaning clear.

| Word       | Definition   | Example                                              |
|------------|--------------|------------------------------------------------------|
| depleted   | diminished   | Extreme pollution has left us with depleted forests. |
| resolute   | determined   |                                                      |
| dwindling  |              |                                                      |
| zealous    |              |                                                      |
| relentless |              |                                                      |

<!-- image -->

## ACTIVITY 4: Adjectives used as nouns

## 4a. Read the following text and observe the words in bold.

The fortunate rarely think of the unfortunate ,

Those of us who

Have lost everything we had,

In war, famine, and destruction.

We are the homeless , without a roof over our head;

We are the jobless ,

Without means to provide for ourselves.

All we wanted was peace for our young and our old ,

A place for all of us, the rich and the poor , to live in harmony.

## 4b. Discuss how the adjectives in bold are used.

The adjectives in  bold  are  being used as nouns .  Adjectives are sometimes used to perform the purpose of nouns.

## Unit 5     World Issues

- 4c. In the following sentences, circle the adjectives which are being used as nouns.
1. The innocent often end up suffering because of dishonest people.
2. Many among the deceased could not be identified after the explosion.
3. The elderly were amongst the exhausted refugees who could not look after themselves.
4. Every Mauritian should contribute to make this country a better place to live.
5. Public institutions should provide adequate facilities for the disabled.
- 4d. Write a short poem using the following adjectives as nouns.

<!-- image -->

## Teaching Tip:

Guide the students to write a short poem. This work can be done in groups. You can get them to recite after.

<!-- image -->

## ACTIVITY 5: Grammar -Semicolon

## 5a. Read the following text and observe the punctuation in red.

In this image we can see buildings, poles, vehicles, and some objects.

<!-- image -->

Samairah was 11 years old only when war tore Syria  apart.  For  five  years,  she  lived  in  very hard conditions. The country was destroyed ; houses  were  blasted ; schools  were  closed down ; classes  stopped  running.  Samairah lost  touch  with  most  of  her  friends  during those difficult times ; many of her relatives lost their lives in the war. Samairah missed three years of schools and she could not continue learning anywhere.

## 5b. Discuss how the punctuation in bold is used.

## The punctuation in bold is called a semicolon. A semicolon is used:

- mostly to link  two  independent clauses that are closely  related  in thought.

## Teaching Tip:

Introduce the semi-colon and elaborate upon how it is used. Elicit a few examples from them if need be.

- 5c. What do you think happened to Samairah eventually? Write a  small  paragraph, using the semicolon where appropriate.

In this image we can see a paper with lines on it.

<!-- image -->

## Teaching Tip:

Model and scaffold when and where necessary to ensure that the semicolon is being used correctly.

<!-- image -->

6a. Read the text below.

## Alice Hawkins -the Suffragette

In this image we can see a woman standing and holding a book and a flag. In the background we can see a building, plants and trees.

<!-- image -->

Born in 1863, Alice lived in United Kingdom for most of her life and had six children. She was a shoe machinist who also believed firmly in her rights. As she believed that women should have the right to vote, she joined the suffragette movement .  Alice went to prison five times because she dared to speak about her views.

Since a young age, Alice understood that the working conditions and the salary of  women were different from those of men. So, she joined the shoe trade union to  try to improve these. Alice soon realised that their main focus was to improve the working conditions of male workers.

In February 1907, she attended her first meeting of the suffragette movement in Hyde Park. After the meeting, all the women participated in a march to demand their right to vote. That afternoon, the police charged down all  the  women present there. Alice was arrested and imprisoned for the first time in her life.  This had a deep effect upon her. After that, she spoke vociferously at factory gates and market squares, encouraging women to ask for their rights to vote.

Alfred, Alice's husband, fully supported his wife.  On many occasions, Alfred attended political meetings of ministers which women could not attend because of their gender.  In 1909, in a political meeting, Alfred interrupted Winston Churchill's speech to enquire why women did not have the right to vote. After that, Alfred was expelled from the meeting. When Alice and other suffragettes tried to attend the meeting, they were all arrested. Alice, refusing to pay the fine, spent fourteen days in jail.

Unfortunately,  not  all  men  and  women  accepted  the  suffragette  movement.  Speakers  at  public gatherings were frequently physically attacked. The suffragette activity continued until 1914 when the First World War broke out. Politicians advised the nation to support the government during the war and put a stop to all protests.

And so ended Alice's time as a suffragette.

Unit 5     World Issues

## GLOSSARY

suffragette movement: the fight for the right for women to vote trade union: an organisation which protect members' rights at work march: a collective walk to protest against something

charged down:

ran towards

vociferously:

forcefully

expelled:

cast out

6b.

1. How would you have felt if you had been Alice and had been arrested for the beliefs you had? Discuss in groups.
2. Would you have supported Alice if you had been in the place of Alfred? Share your reflections with your classmates.
3. Imagine  you  are  Alice  and  standing  at  the  factory  gate  encouraging  women  to  ask  for their right to vote. Write a short speech in the textbox below. Share the speech with your classmates.

In this image there is a paper with a sketch on it.

<!-- image -->

<!-- image -->

The  short  story  below  is  written  by  a  15  year  old  who  participated  in  a  short  story competition on World Issues.

## 7a. Read the comment from the judges.

In this image, there is a white background with a decorative pattern. There is a text in the image.

<!-- image -->

7b. Imagine you are the 15 year old who wrote the short story. Correct the mistakes and make the necessary changes as per the comments of the judges.

I  sat  dejeted in the refugee camp, feeling as if my life was over. My parents were dead because of the civil war in my homeland. My eldest sister and I had managed to escape, but along the way, she became violently ill and passed away. Now, I was all alone in a camp with hundreds of strangers, many of whom where speaking in languages that I had never heard before.

Judge COMMENT 1: Describe this camp in greater detail - consider using the five senses

What was I going to do? I was tired and sad. I felt a lump in my throat and tears started rolling down my diry cheeks as I looked at  a  mother  comforting  her  young  child.  I  could  not  help  but remember the privileged life I had before the war. My father was a paediatrician and my mother a teacher and they looked after us well. we were always showered with love. Who will going to look after me now?

Suddenly, I saw a woman enter the camp. Her kind, gentle face with a warm smile caught my attention as it seemed so out of place. Fascineted by her, I stopped thinking of the past and watched her movements. I was surprised to see her approaching a young girl and talking to them in a friendly and comforting way.

She came closer to me. I felt my heart beat faster as she stopped in  front  of  me.  I  looked  up  at  her  and  again  the  kindess  on  her face struck me. She talked to me; but I could not understand. She tended her hand towards me and I took it.

(290 words)

## JUDGE COMMENT 2:

Change these two words- they are too simple- find words that express these emotions better

JUDGE COMMENT 3: Correct  all  the  grammatical, spelling and punctuation mistakes in paragraph 2

JUDGE COMMENT 4: Describe this woman's appearance in greater depth.

JUDGE COMMENT 5: Correct all the spelling mistakes in paragraph 3

JUDGE COMMENT 6: Add some dialogue here.

JUDGE COMMENT 7: Correct all the spelling mistakes in paragraph 4

JUDGE COMMENT 8: Add a sentence to show what actions the woman did which showed that she was kind.

JUDGE COMMENT 9: Develop this paragraph in more details and say how the story might have ended.

## Appendices

## Appendix 1:

Unit 1: Mental Well-being

Activity 1     Listening

<!-- image -->

## Transcript

Dear students,

Today, we are going to talk about how being mentally healthy is important. Sometimes, you notice that someone close to you has changed his or her social habits, or is not behaving as he or she normally does. This might be a warning sign that something could be happening to that person.

You might have noticed someone behaving differently but do not know how to help. It is not always easy to help someone who is facing personal issues. They might be facing a problem which could be linked to studies, family issues, rejection by peers, or even bullying. This could lead to stress, anxiety and sadness. They might need some time to understand what they are going through. They certainly do not want people to question them or look at them in a strange way.

We need to think carefully about our own reactions. Sometimes we do not even know how to speak to a friend who is facing problems, or we may say the wrong things at the wrong time. As a friend, I think that your presence can make a difference. Sometimes just showing someone you care is enough. You may not solve their problems but at least they might feel less isolated, because you are there for them. Having someone you can rely upon and confide in can thus be a great comfort. So, ask yourself these questions today: Am I a good friend? What am I doing to help the people in my life?

## Appendices

## Appendix 2:

Unit 2: Festivals around the World

## Activity 1     Listening

<!-- image -->

## Transcript

Good morning, dear Ma'am and friends. For my classroom presentation, I have chosen to talk about the Korean Mud Festival. For two weeks in July, many tourists flock to Boryeong, a small town in South Korea. They eagerly want to experience mud wrestling, mud sliding and mud swimming, even if the prices are exaggerated. The festivities begin in the morning, with mud pools, mud massage zones and even mud fountains. Tourists enjoy barbecues on the beach along with the numerous seafood restaurants. Some of them party until late as they are not so keen to return to their modest accommodations. These are often uncomfortable and guests have to sleep on the floor.

Now, friends, just imagine being in a situation where you are smeared up in mud. Would you have enjoyed attending such an event?

## Appendices

## Appendix 3:

## Unit 3: Professions

Activity 1     Listening

<!-- image -->

## Transcript

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Hey  Meeta! What  are  your  plans  for the holidays?

I saw an ad for zoo assistants at Zooland. I'll probably apply for the job.

That's great! I know how much you love animals.

Yes,  I'm  very  excited.  What  about  you? Do you plan to work too?

Oh, yes! I will be working in a shop as a shop assistant. I can't wait to get my first salary.

Yes! Just imagine! We will earn our own pocket money!

I want to help my mum pay my exam fees. Since dad passed away, she works really hard to make sure I complete my studies. I want to be more independent and be able to buy my own things.

That's  a  really  nice  idea,  Emmanuel.  I  have  not thought  what  I  would  do  with  my  salary.  My parents always complain that I am irresponsible. I want to show them that I can be responsible like them. I want them to be proud of me.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Appendices

## Appendix 4:

Unit 4: Changing Worlds

## Activity 1     Listening

<!-- image -->

## Transcript

In the 1980s, life was very different from how it is today. At that time, people would get their groceries from small shops called ' demi gros ' .  These  were  often  run  by  people  belonging  to the Chinese community. My mum often tells us how she used to buy chocolates on the way back from school. In those days, bars of chocolate were cut into pieces and sold per piece. My mum also bought her clothes from the hawkers who would sell their products door to door. Now, people shop at hypermarkets or in shopping malls. Many also choose online shopping. I wonder how things will be in twenty years' time. Maybe there won't be any hypermarkets and shops. Maybe all products will be kept in stores and will be delivered when an order is placed. Maybe in 2039, all transactions will be done online only.

## Appendices

## Appendix 5:

Unit 5: World Issues

Activity 1     Listening

## Transcript

## 'Student Violence - A Growing Concern?'

Last Tuesday, Mr Vishal had to run away from his class to hide in the Rector's office because his students had become violent. This is yet another of the many cases of student violence which are being reported nowadays. Teachers are increasingly feeling threatened in their classrooms these days. Many are being insulted, aggressed physically or having their cars damaged. Some have  even  left  their  jobs.  Many  teachers  take  days  off  because  they  cannot  cope  with  the pressure at work. They feel demotivated to deal with troublesome students and parents on a daily basis. In some cases, a number of teachers have reported that they are spending more on their health because of stressful work environments. In highly problematic areas, where there is a lot of crime, teachers even fear for their lives after school hours.

- ©  Mauritius Institute of Education - 2021