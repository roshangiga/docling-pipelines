In this image we can see a musical instrument.

<!-- image -->

<!-- image -->

## MAHATMA GANDHI INSTITUTE

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology

<!-- image -->

## TEXTBOOK GRADE 9 SITAR

Based on the National Curriculum Framework 2016

## MAHATMA GANDHI INSTITUTE

<!-- image -->

under the aegis of the

Ministry of Education, Tertiary Education, Science and Technology. Republic of Mauritius 202 1

<!-- image -->

## © Mahatma Gandhi Institute (2019)

All rights reserved.No part of this publication may be reproduced, stored in a retrieval  system,  or  transmitted  in  any  form  or  by  any  means,  electronic, mechanical, photocopying, recording or otherwise, without the prior permission of the Copyright owner.

## Printed by:

T-Printers Co. LTD Industrial Zone, Coromandel. Tel: (230) 233 2500

First published 2020 Reprinted 2021

While every effort has been made to trace the copyright holders for reproductions, we might have not succeeded in some cases. We offer our sincere apologies and hope that they will take our liberty in good faith. We would appreciate any information that would enable us to acknowledge the copyright holders in our future editions. All materials should be used strictly for educational purposes.

ISBN: 978-99949-54-30-8

## PERFORMING ARTS (INDIAN MUSIC AND DANCE) PANEL

Mr. K. Mantadin

## -

## Project Co-ordinator

(organisation and development), Senior Lecturer (Tabla), Head, Department of Curriculum Development, Mahatma Gandhi Institute.

Dr. D.Ramkalawon

## - Panel Co-ordinator

Senior Lecturer (Sitar), Head, School of Performing Arts, Mahatma Gandhi Institute.

## Writing Team (Sitar)

Dr. D. Ramkalawon

## - Team Leader

Senior Lecturer (Sitar), Head, School of Performing Arts, MGI

Mr. M. Goolaup

- Educator (Sitar) - MGI

Mr. A. C. Bhujun

- Lecturer (Sitar) - MGI

## Vetter

Mrs. T. B. Joynathsing

- -

Former Lecturer (Sitar) Indian Music and Dance

Former Ag. Head, Department of

## Proof Reading

Mrs. D. Balaghee

- Deputy Rector - MGISS

## Graphic Designers - MGI

(cover, illustration, layout and photography)

Ms. P. Juckhory

Ms. V. Jatooa

Mr. V. Napaul

## Photography

Mr. G. Moonesawmy

-          Pro Foto Plus

## Word Processing Operator

Mrs. N. Mugon

## ACKNOWLEDGEMENTS

Mrs. S. N. Gayan, GOSK, Director General, Mahatma Gandhi Institute and Rabindranath  Tagore  Institute for  her  continued  advocacy  for  music education especially Indian Music and Dance.

Dr.  (Mrs.)  V.  D.  Koonjal,  Director,  Mahatma  Gandhi  Institute for  her unwavering support to this project.

## The  Performing  Arts  (Indian  Music  and  Dance)  panel  is  also  grateful  to  the following persons:

| Dr. Mrs. S. D. Ramful     | -   | Director Schooling - MGI                                                                  |
|---------------------------|-----|-------------------------------------------------------------------------------------------|
| Mrs. U. Kowlesser         | -   | Registrar (MGI)                                                                           |
| Dr. D. Ramkalawon         | -   | Senior Lecturer (Sitar), Head, School of Performing Arts, MGI                             |
| Dr. D. Pentiah-Appadoo    | -   | Music Organiser (Oriental), M.O.E, T.E, Sc. & Tech.                                       |
| Professor Roop Kumar Soni | -   | Retired professor Indira Kala Sangit Vishwavidya laya Khairagarh, India                   |
| Professor M.S. Mishra     | -   | Former Professor, Faculty of Music and Fine Arts, University of Delhi, India              |
| Professor Anupam Mahajan  | -   | Professor, Faculty of Music and Fine Arts, University of Delhi, India                     |
| Professor S. Sarkhel      | -   | Professor, Department of Classical Music, Sangit Bhavana, Visva Bharati University, India |
| Professor S. Bandopadhyay | -   | Professor, Head Department of Indian Music, Sikkim University, India                      |
| Mrs. Ashu Nagpal Gandhi   | -   | Educator, Sachdeva Public School Pitampura, New Delhi, India                              |
| Mr. Kartar and Hari Chand | -   | Musical instruments manufacturers, New Delhi, India                                       |
| Dr. G. Gumani             | -   | Former Educator (Sitar)                                                                   |

MGI

## Quality Vetting Team

Dr. S. K. Pudaruth

- Assoc. Professor, Ag. Head, Centre for Quality Assurance - MGI

Mrs. T. A. S. Makoonlall

- -

- Senior Lecturer (Sitar), Head, Department of Stringed Instruments, MGI

Mr. S. Choytoo

- Educator (Sitar) - M.O.E, T.E, Sc. &amp; Tech.

Mrs. L. Ramduth

- Lecturer,

Department of Design &amp; Communication, MGI

Mr. R. R. Maloo

- Educator (English) - MGSS

## Administrative Staff

Mrs. H. Chudoory

- Administrative Officer - MGI

Ms. V. Cahoolessur

- Office Supervisor - MGI

Mrs. G. Checkooree

- Clerical / Higher Clerical Officer - MGI

Mrs. S. Appadoo

- Clerical / Higher Clerical Officer - MGI

- Mrs. P. Purmessur

- Word Processing Operator- MGI

- The parents and their wards for giving us the permission to reproduce their photographs and images in the textbook.

## FOREWORD

'Where the mind is allowed to stumble upon cascades of emotion and where the surprise of creative exchange comes out of tireless striving towards perfection'.

Rabindranath Tagore

Should music, dance, arts, drama be taught in schools? Do such subjects matter ?

As in the case of all debate, there are those who are for and those who are against. The decision, in the context of the reforms leading to the Nine Year Continuous Basic Education, to include teaching of the performing arts in the secondary school curriculum shows that 'the ayes have it.' At least for the time being.

Traditionally, music teaching takes place in a one-to-one mode. The piano teacher teaches one student at a time, so does the sitar guru. Dance is more of a group experience. But for each of these disciplines, the context of institutional level teaching introduces opportunities of reaching a broader cross-section of population, thereby giving rise to fresh challenges. Students come from a variety of social and cultural environments which expose them to different types, genres and registers in the arts. Students also come with different levels of aptitude. These are but two of challenges encountered.

From another perspective, it has been repeatedly pointed out that the 'digital natives', while definitely coming to learning with resources hitherto not available, may, in the process, be losing their ability to grasp, decipher and understand emotional language. In short they may be losing empathy.

The ultimate aim of arts education in the curriculum is to provide a pedagogical space where the  young  will  be  able  to  explore  their  own  affective  responses  to  forms  of  artistic expression, to develop sensibility, while acquiring a whole set of skills, including not only spatial awareness, pattern recognition or movement coordination, but also the benefits of group and team work, of joint effort, higher level creative thinking and expression, as well as an overall sense of shared pleasure and of achievement. This is what emotional intelligence is all about.

The specialists who prepared the syllabus and the present textbooks for Indian music and dance had all the above in mind while undertaking the task. The teacher training for these disciplines needs to be a continuous process of exchange between curriculum developers, teaching practitioners, textbook-writers and learners.

The MGI is particularly happy to be part of this major development, at a time when the country  is  looking  at  new  avenues  for  continued  economic  development,  and  more importantly at new avenues to enhance equity, social justice and inclusion. It is our small contribution to the 'grande aventure' of holistic education.

Mrs. Sooryakanti Nirsimloo-Gayan, GOSK Director-General (MGI &amp; RTI)

## PREFACE

This textbook is the first instructional material in the field of Performing Arts (Indian Music and Dance) written by a team of experienced Mauritian teachers and experts in Vocal Music, Instrumental Music and Dance.

It has been designed on the Aims, Objectives and the Teaching and Learning Syllabus of the Performing Arts  from  the  National  Curriculum  Framework  (2016),  under  the  Nine  Year Continuous Basic Education Programme.

The Performing Arts Curriculum is articulated around four strands: Performing, Creating, Responding and Performing Arts and Society. Thus, the textbook takes into account the development of key skills and understandings under the four strands.

This set of textbooks for grade 7, 8 and grade 9 lays the foundation in each discipline and provides  learners  with  the  essential  knowledge,  skills  and  attitudes  needed  to  progress towards higher grades. It also takes into consideration the multicultural nature of our society and its traditions.

This textbook is a support material that gives direction to the educators in the teaching and learning process by linking the curricular components, curricular expectations, pedagogical principles and assessments.

A textbook is not an end in itself like any other instructional material.It is a means to facilitate learning to take place in a continuous and continual manner.

Learning objectives in each chapter of the textbook reflect the curricular outcomes.  It will help the teacher to design his/her lesson plans which will further ease the teaching and learning transaction towards achievement.  Teachers will have to plan their work so that learning takes place in an effective and efficient way.  They will have to provide appropriate and enriched experiences and modify the teaching and learning strategies according to the needs of learners.

The  practical  aspects  of  the  discipline  have  been  integrated  under  'practical'  with step-by-step technique laying emphasis on the mastery of skills from one level to another.

We are aware that children construct knowledge in their own way and have different learning styles.The textbook has been designed to cater for such needs. Special features and a generous number of illustrations, pictures, concept maps and activities have been included to promote collaborative learning and other additional skills like team spirit, cooperation and understanding  diverse  nature  of  learners.These  would  help  teachers  to  organise  their interactions  at  classroom  level.  Teachers  may  give  more  activities,  depending  upon  the availability of resources and time.

Assessments in the form of activities, projects and questions are also included at the end of each chapter. These are check points to assess the learners. It will help teachers gather evidences about the expected level of learning taking place in the learners.

I  would also request all the Educators to go through the National Curriculum Framework (2016),  the  Teaching  and  Learning  Syllabus  of  the  Performing Arts  (Indian  Music  and Dance)  documents  and  especially  the  'Important  Note  to  Educators'  which  has  been provided  in  the  textbook  to  have  a  thorough  understanding  of  the  Philosophy  and Perspective behind those documents and their implications in the implementation of the Reform process in the education system.

I hope that this new journey of learning Indian Music and Dance will be an enriching one.

Mr. K. Mantadin, Project Co-ordinator - Performing Arts (Indian Music and Dance), Senior Lecturer (Tabla), Head, Department of Curriculum Development, Mahatma Gandhi Institute.

## NOTE TO EDUCATORS

This teaching and learning syllabus of Indian Music and Dance has been designed on the spiral curriculum model in which core components and essential topics are revisited within the three years. It caters for both the theoretical and practical aspects of each discipline.

It also comprises different blocks of knowledge and skills and each block is supported by specific  learning  outcomes  which  cover  all  the  three  domains  of  learning;  cognitive, psychomotor and affective.

The Listening and Viewing component has been integrated in the syllabus as it is a key factor in the development of music and dance abilities.

Teachers should provide a wide variety of listening and viewing experiences for learners to stimulate active listening and viewing through questioning, prompting and suggestion.

In  order  to  achieve  the  objectives  of  the  syllabus  and  to  keep  a  good  balance  between theory and practical sessions, the teacher will have to plan his / her work and teaching and learning activities according to the topics to be taught as specified in the scheme of studies. However, educators may modify the sequence of the topics in which they wish to teach for the smooth running of the course.

## Educators should:

1. Ensure that learners use the knowledge, skills and understanding developed from grades 1 -6 and build upon that prior knowledge to construct new knowledge.
2. Provide learning experiences that include opportunities for hands-on and interactive learning, self-expression and reflection.
3. Find a variety of ways to align their instruction with the Aims, Learning Outcomes and Specific Learning Outcomes by focusing on active learning and critical thinking.
4. Provide learning activities that are appropriate in complexity and pacing.
5. Provide opportunities for individual and multiple groupings.
6. Actively engage and motivate students in the process of Learning Music and Dance.
7. Develop the ability in the learners to use and understand the language of Music and Dance through listening and viewing as well as responding to live and recorded repertoires.

8. Enrich the musical experience of the students by gaining an understanding of the cultural and historical context of music and dance exploring personal connections with them.
9. Carry out active listening and viewing sessions through the use of Information Learning Technologies(ILT's).  This will facilitate developing their investigative and methodological abilities.
10. Model and demonstrate accurate and artistic musical and dance techniques.
11. Differentiate Music and Dance instruction to meet a wide range of students needs.
12. Educators should also ensure that learners:
-  Show proper care and maintenance of classroom instruments.
-  Demonstrate respectful behavior as performers and listeners.
-  Participate in classroom protocole and traditions for music making and dance.
13. Reinforce effort and provide recognition.
14. Discuss student performances by using peer assessment as a tool.
15. Give opportunities to students to assume various roles in music performances, presentations and collaborations.
16. Motivate students to maintain a musical collection and portfolio of their own work over a period of time.  It can be an individual or group initiative that the learner will undertake under the supervision of the educator.

## TABLE OF CONTENTS

| 1                                                                             | Shruti-swara distribution   |
|-------------------------------------------------------------------------------|-----------------------------|
| 1.1 Shruti 1.2 Shruti-swara distribution                                      | 2                           |
| Raag elaboration                                                              | 4                           |
| and 2.1 Alaap 2                                                               | Improvisation 8             |
| 3.6.1 Salient features 3.6.2 Razakhani Gat Raag - Jati System                 | 35                          |
| 4.1 Jati                                                                      | 42                          |
| 4.2 Classification of raag-s based on the raag-jati                           | system 47                   |
| 3.1 Ashraya raag 3.2 Characteristics of a raag 3.3 Thaat 3.4 Raag Bhupali 3 5 | 16 16                       |
| 5.1 Khayal                                                                    | 18 20                       |
| 5.2 Bhajan 5.3 Ghazal                                                         | 28 31 34 34                 |
|                                                                               | 27                          |
| 3.4.1 Salient features 3.4.2 Razakhani Gat 3.4.3 Introduction to toda-s       | 20 21                       |
|                                                                               | 58                          |
| / taan-s 3.5 Raag Brindavani Sarang                                           | 24 27                       |
| 3.5.1 Salient features                                                        |                             |
| 3.5.2 Maseetkhani Gat                                                         |                             |
| 3.5.3 Razakhani Gat 3.6                                                       |                             |
| Raag Alhaiya Bilawal                                                          |                             |
| 4                                                                             |                             |
| Vocal Forms                                                                   |                             |
|                                                                               | 56                          |
|                                                                               | 54                          |
| 5.4 Folk Songs                                                                |                             |
|                                                                               | 60                          |

| 5.5 Folk music in Mauritius                             | 63   |
|---------------------------------------------------------|------|
| 5.5.1 Sega                                              | 63   |
| 5.5.2 Bhojpuri folk songs                               | 65   |
| 5.6 Importance of folk music                            | 67   |
| 5.7 Local artists in Mauritius                          | 68   |
| Taal and Laya 6                                         |      |
| 6.1 Layakari                                            | 74   |
| 6.2 Tihai                                               | 75   |
| 6.3 Jhaptaal                                            | 78   |
| 6.4 Ektaal                                              | 79   |
| Classification of Musical Instruments 7                 |      |
| 7.1 Classification of Musical Instruments               | 84   |
| 7.1.1 Chordophones / Tat vadya                          | 86   |
| 7.1.2 Membranophones / Avanaddha vadya                  | 90   |
| 7.1.3 Aerophones / Sushir vadya                         | 95   |
| 7.1.4 Idiophones / Ghana vadya                          | 99   |
| 7.1.5 Electrophones                                     | 103  |
| Musicians and Musicologists 8                           |      |
| 8.1 Pandit Vishnu Narayan Bhatkhande                    | 108  |
| 8.2 Pandit Vishnu Digambar Paluskar                     | 110  |
| 8.3 Pandit Ravi Shankar                                 | 113  |
| 8.4 Ustad Vilayat Khan                                  | 117  |
| Music prevalent in Mauritius and other cultures 9       |      |
| 9.1 Tamil community                                     | 122  |
| 9.2 Telugu community                                    | 126  |
| 9.3 Marathi community                                   | 129  |
| 9.4 Gujarati community                                  | 132  |
| 9.5 Muslim community                                    | 134  |
| 9.6 Musical instruments used in folk music of Mauritius | 136  |
| 9.7 Music in various cultures of the world              | 138  |
| 9.7.1 Arabian Music music                               | 138  |
| 9.7.2 Western                                           | 143  |

In this image, we can see a poster with some text and images.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  Establish the relationship between shruti and swara .
-  Elaborate on the modern shruti-swara distribution.

2

<!-- image -->

Shruti originates from the Sanskrit word shru which means to hear. Therefore, any minute sound that is capable of distinctly being heard by the human ears is called shruti . It can also be referred to the unit interval of pitch of the swara-s .

Talented  musicians  regularly  use shruti-s in  their  musical  performances  in order to embellish the rendition of raag-s .

From the time of the ancient scholars, shruti-s were primarily selected for the purpose of fixing the scales. The division of the scale into 22 small divisions led to the establishment of the 22 shruti-s in Indian classical music.

The  names  of  the  22 shruti-s have  been  mentioned  in  the Natyashastra , Sangeet Ratnakara , Sangeet Parijata and many other treatises almost in the same manner.

The following table shows the names of the 22 shruti-s according to Bharata and Sharangdev :

| Swara-s   | Names of the 22 shruti-s   | Names of the 22 shruti-s   | Names of the 22 shruti-s   | Names of the 22 shruti-s   |   Number of shruti-s |
|-----------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------|
| Shadja    | 1. Teevra                  | 2. Kumudavati              | 3. Manda                   | 4. Chandovati              |                    4 |
| Rishabh   | 5. Dayavati                | 6. Ranjani                 | 7. Ratika                  |                            |                    3 |
| Gandhara  | 8. Roudri                  | 9. Krodha                  |                            |                            |                    2 |
| Madhyama  | 10. Vajrika                | 11. Prasarini              | 12. Priti                  | 13. Marjani                |                    4 |

| Panchama   | 14. Kshiti   | 15. Rakta     | 16. Sandipini   | 17. Alapini   |   4 |
|------------|--------------|---------------|-----------------|---------------|-----|
| Dhaivata   | 18. Madanti  | 19. Rohini    | 20. Ramya       |               |   3 |
| Nishada    | 21. Ugra     | 22. Kshobhini |                 |               |   2 |

However, Bhavabhatt, a great scholar, gave a different set of names for these 22 shruti-s in his book Anupa Sangeet Vilas .

The table below shows the names of the 22 shruti-s according to Bhavabhatt :

| Swara-s             | Names of the 22 shruti-s   | Names of the 22 shruti-s   | Names of the 22 shruti-s   | Names of the 22 shruti-s   | Number of shruti-s   |
|---------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------|
| 1. Nandana Shadja   | 2. Nishkala                |                            | 3. Guda                    | 4. Sakala                  | 4                    |
| 5. Madhura          | 6. Lalita                  | 7. Kakshara                |                            | 3                          | Rishabh              |
| 8. Bharagajati      | 9. Hraswagiti              |                            |                            | 2                          | Gandhara             |
| 10. Ranjika         | 11. Chapara                | 12. Purna                  | 13. Alankarini             | 4                          | Madhyama             |
| 14. Vainika         | 15. Valitha                | 16. Trishthana             | 17. Suswara                | 4                          | Panchama             |
| 18. Soumya          | 19. Bhashangina            | 20. Vartika                |                            | 3                          | Dhaivata             |
| 21. Vyapaha Nishada | 22. Subhanga               |                            |                            | 2                          |                      |

3

4

<!-- image -->

## Did You Know?

During Pandit Venkatamukhi's time, 2 more shruti-s were added to the 22 shruti-s, making a total number of 24 shruti-s .

In his book Gundha kriya lakshana Geeta , Pandit Venkatamukhi mentioned that these two extra shruti-s were also in vogue.

It is interesting to note that the ancient Greeks also divided their octave into 24 small intervals. Great similarity has been found between Indian music and the ancient Greek music.

However, the concept of 22 shruti-s is in vogue nowadays.

<!-- image -->

## Shruti-swara distribution

The following table shows the location of the 7 shuddha swara-s with respect to the 22 shruti-s :

| 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10   | 11   | 12   | 13   | 14   | 15   | 16   | 17   | 18   | 19   | 20   | 22   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|------|------|------|------|------|------|------|------|------|------|------|------|
|     |     |     | S   |     |     | R   |     | G   |      |      |      | M    |      |      |      | P    |      |      | D    | N    |

According to the modern shruti - swara distribution,

- Sa is located on the 4 th shruti as it has 4 s hruti-s
- -Re is located on the 7 th shruti as it has 3 s hruti-s
- -Ga is located on the 9 th shruti as it has 2 s hruti-s
- -Ma is located on the 13 th shruti as it has 4 s hruti-s
- -Pa is located on the 17 th shruti as it has 4 s hruti-s
- Dha is located on the 20 th shruti as it has 3 s hruti-s
- Ni is located on the 22 nd shruti as it has 2 s hruti-s.

## Knowledge Plus!

## Relationship between shruti and swara

Narada,  a  great  scholar,  describes  the  relationship  between shruti and swara in the form of a poem:

- ' Jathapsu Caratang margo minanang nopolabhyatey Akasey ba bihanganang tatabatsaragatha sruti Jata dadhanisarphi syat hasthatho ba Prajatney Nopalabhyatey tatbat swaragata sruti '

'Just as the fish swims in the water and birds fly over the sky, the shruti follows  the swara in  the  same  way.  It  has  the same relation as the serpent with the milk and the fire with the wood'.

In this image, we can see a circle and text.

<!-- image -->

5

6

ASSESSMENT

1. (a) Define the term shruti .

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………...

- (b) Write the number of shruti-s associated to each swara in the table given below:
- (c) In the given chart representing the modern shruti-swara distribution, write down the position of the 7 shuddha swara-s :

| Swara   | Number of Shruti-s   |
|---------|----------------------|
| S       | ...................  |
| R       | ...................  |
| G       | ...................  |
| M       | ...................  |
| P       | ...................  |
| D       | ...................  |
| N       | ...................  |

In this image, we can see a person playing a guitar.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  Define the term alaap , jod alaap , mohra and jhala .
-  Play few simple alaap-s .
-  Play simple jhala in pattern of 4 strokes (one da and three chikaari-s ).

8

<!-- image -->

The alaap is the introductory part or prelude of a classical performance which is slow-paced and free flowing. It expresses and unfolds the characteristics of a raag with respect to its chalan / melodic movements.

While playing or singing the alaap , the performer lays emphasis on particular swara-s , their order and usage in such a way that the vadi swara (dominating note) can  be  clearly identified by  the listeners.  There  is  no  rhythmic accompaniment in an alaap .

The rendition of the alaap usually starts with the swara-s in the mandra saptak , then moves to the madhya saptak and finally to the taar saptak .

Alaap is given the highest place in Indian music.

The alaap is  the  invocation  of  the raag calling forth its mood or rasa .

The  elaboration  of  the alaap is  an indication of the depth of knowledge and  virtuosity  the  musician  has  in regards to the raag being played.

In instrumental music, the musicians make the  maximum  use  of meend , gamak and other types of ornamentations while performing the alaap in order to unfold the characteristic features of the raag.

Figure 2.1 : Ustad Vilayat Khan using meend while playing an alaap

In this image we can see a person holding a musical instrument.

<!-- image -->

## Practical

## Playing  simple alaap in Raag Yaman

- Guided by your class teacher, play the following musical phrases based on Raag Yaman at a very slow pace and add the chikaari as appropriate:

## Prior knowledge

## Raag Yaman

N R G M P D N S

S N D P M G R S

N R G, R S, P M G R, Ṇ R S

Aroha :

Avroha :

Pakad :

- 1) S, N R S
- 2) N R G, G R, N R G
- 3) G M P M G R, N R G
- 4) N R G M P, R G R, N R S
- 5) S N D P, N D P
- 6) P D N, D N, N D N, N R S
- 7) G M P, P M G M D P
- 8) M D N, D N D P, N D P
- 9) G M D D N D P, M D P
- 10) D M P M G, G M P D P, M G
- 11) N R G M P M G, N R S
- 12) G M D N, M D N S, N R S
- 13) N D N D P, M G R G, R S, N R S

9

10

<!-- image -->

The jod alaap is the second part of a classical instrumental performance and it is  played  after  the alaap .  It  consists  of  melodic  patterns  played  by  the synchronization of the main, jod and chikaari strings. The jod alaap is played at a faster tempo than the alaap and the rhythm is maintained by the increased use of the chikaari .

<!-- image -->

The mohra is used either in instrumental or vocal music. It indicates the end of an  expression  / vistara .  It  can  be  referred  to  as  a  full  stop,  as  used  in  the languages.

## An example of a mohra

S - - S - - - - - SN SN R- S-

- 1) Slow tempo:

d - - d - - - - -   d    d  d-  d-

S - - S - - SN SN R- S-

- 2) Medium tempo:

d - - d - -   d    d   d- d-

S - S - SN SN R- S-

- 3) Fast tempo:

d - d -   d    d   d- d-

<!-- image -->

The jhala is the concluding part of a classical instrumental performance. It is played  at  the  end  of  a razakhani  gat .  It  consists  of  improvising  different rhythmic patterns by the various combinations of the swara-s and the chikaari . The tempo of the jhala is continuously increased by the musician until it ends with a tihai . It is generally played in teentaal .

Jhala playing has evolved from the Beenkar and Rababiya gharana-s in India.

Another type of jhala played after the jor alaap is called the jor-jhala .

The following chart shows the basic stages in a classical instrumental performance:

In this image, we can see a diagram.

<!-- image -->

11

12

In this image, we can see a diagram.

<!-- image -->

## Practical

## Step 3

Similarly, repeat steps 1 and 2 for Re, Ga and the remaining swara-s .

## Step 4

Practise the above exercise a few times.

## Step 5

Now, repeat the same exercise in avroha as shown in the following table. Under the guidance of your teacher, practise it with the appropriate strokes.

| 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10   | 11   | 12   | 13   | 14   | 15   | 16   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|------|------|------|------|------|------|------|
| S   | -   | -   | -   | S   | -   | -   | -   | S   | -    | -    | -    | S    | -    | -    | -    |
| N   | -   | -   | -   | N   | -   | -   | -   | N   | -    | -    | -    | N    | -    | -    | -    |
| D   | -   | -   | -   | D   | -   | -   | -   | D   | -    | -    | -    | D    | -    | -    | -    |
| P   | -   | -   | -   | P   | -   | -   | -   | P   | -    | -    | -    | P    | -    | -    | -    |
| M   | -   | -   | -   | M   | -   | -   | -   | M   | -    | -    | -    | M    | -    | -    | -    |
| G   | -   | -   | -   | G   | -   | -   | -   | G   | -    | -    | -    | G    | -    | -    | -    |
| R   | -   | -   | -   | R   | -   | -   | -   | R   | -    | -    | -    | R    | -    | -    | -    |
| S   | -   | -   | -   | S   | -   | -   | -   | S   | -    | -    | -    | S    | -    | -    | -    |
| X   |     |     |     | 2   |     |     |     | 0   |      |      |      | 3    |      |      |      |

In this image, we can see a logo and text.

<!-- image -->

13

14

(i) Alaap

……………………………………………………………………………………

……………………………………………………………………………………

(ii) Jod alaap

……………………………………………………………………………………

……………………………………………………………………………………

(iii) Mohra

……………………………………………………………………………………

……………………………………………………………………………………

(iv) Jhala

……………………………………………………………………………………

In this image, we can see a paper with some text written on it.

<!-- image -->

In this image we can see a collage of different images.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  Explain the term ashraya raag .
-  State the characteristics of raag .
-  Elaborate on the structure of the 10 thaat-s .
-  Describe the salient features of the raag-s prescribed.
-  Play one maseetkhani ( vilambit ) gat , one razakhani ( madhyalaya / drut ) gat , with at least four toda-s / taan-s in each gat including two toda-s / taan-s with tihai and simple jhala in any one of the raag-s prescribed.
-  Play one razakhani ( madhyalaya / drut ) gat with at least four toda-s / taan-s including one with tihai in the other prescribed raag-s .

16

<!-- image -->

Musicologists are of the opinion that a raag cannot be formed using less than 5  notes  of  the  scale,  the  only  exception  being raag  Malasri ,  having  only  4 notes. By using the notes in their proper sequence, each of the 10 thaat-s, consisting of 7 notes, can be used to indicate the raag-s after which that thaat has been named. But for any other raag-s falling under that thaat , a variation of the sequence would be needed to mark the difference between them and the principal raag which lends its name to the thaat .

In Carnatic music, this principal raag is called melakarta / the Lord of the scale or janaka raag / the father raag .

The ashraya raag refers to a raag which bears the same name as the thaat under which it takes shelter . The other raag-s grouped under that thaat are known as asrita (sheltered) or janya / begotten raag-s .

<!-- image -->

## Characteristics of a raag

The raag can be defined as a melodic mode having a rigid form in view of the several conditions laid down for its elaboration. Just as a Yogi disciplines his body and mind through rigorous practice to experience communion with the infinite,  similarly  the  musicians  have  to  go  through  dedicated,  regular  and committed practice to be in communion with the raag , which is the vehicle of the feelings they want to convey. Considering the rules and salient features of a raag , it may seem to be very rigid and bounded, but in fact, a raag is capable of limitless variations and expansion.

The characteristics of a raag as devised by Pandit V. N. Bhatkande are:

- It must be classified under a thaat . 1)
- It should have all the 7 or a minimum of 5 swara-s of its thaat. 2)
- The swara Sa is never omitted. 3)
- Both swara-s Ma and Pa cannot be omitted at the same time. 4 )

- Two forms of the same swara are not used in a raag , in a way that one swara is played or sung immediately after the other. However, there are certain exceptions. 5)
- It must have its aroha and avroha . 6)
- It must have a pakad, vadi, samvadi, vikrit swara (if any), varjit swara (if any) and jati . 7 )
- A raag is rendered at a particular time of the day / night or season of the year. 8)
- It must depict  a certain mood and be pleasant to the ears of the listener. 9)

## Knowledge Plus!

In the medieval period, the evolution of raag-s was closely connected to  the  Indian  mythology  and raag-s were  dedicated  to  particular deities, such as Lord Shiva and Goddess Parvati or Lord Narayana and Goddess Lakshmee. Thus, the concept of classifying raag-s into raag and raagini (male  and  female  concept)  was  adopted  in  the 16 th  - 17 th  century.

Apart  from  classifying raag-s based  on  gender,  specific  colour  or mood was also ascribed to each raag . Several texts in music namely, Dattillam,  Sangeet Ratnakar, Sangeet Parijat, Svaramela Kalanidhi and others have given descriptions of this aspect of the raag .

Therefore,  music  being  one  of  the  finest  of  all  fine  arts,  it  is considered  to  be  one  of  the  direct  paths  to  salvation.  Since  each swara is associated to a particular deity, its invocation is considered necessary to attain mastery in the art and eventually unison with the ultimate divinity.

Raag is  a  unique  gift  of  Indian  music  to  the  world,  for  in  no other music system worldwide, any concept similar to the raag can be found .

17

18

<!-- image -->

The set of  7 swara-s ,  written  in  their  natural  ascending  order,  under  which raag-s are  classified  is  termed  as  a thaat,  krama,  mela or  a  scale. Thaat-s have only an aroha. Since there are 12 swara-s in Indian music, including the tivra and the komal swara-s, a selection of 7 swara-s has to be made to form a thaat.

In North Indian Classical music, Pandit V. N. Bhatkhande devised 10 thaat-s under which the raag-s could be classified.

Figure 3.1: Pandit V. N. Bhatkhande

In this image we can see a man.

<!-- image -->

Pandit V.  N  Bhatkhande  named each thaat after  the  most  common raag falling under it so that the names of the thaat-s could be easily memorized.

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

## The description of the 10 thaat-s as devised by Pandit V. N. Bhatkhande are as follows:

|    | Thaat (Hindustani)   | Mela (Carnatic)                | Swara structure   | Brief description                     |
|----|----------------------|--------------------------------|-------------------|---------------------------------------|
|  1 | Bilawal              | D h i r an s an k ab h a r a m | S R G M P D N     | S c al e us in g all shuddha swara-s  |
|  2 | Kalyan               | M ec a k alyani                | S R G M P D N     | Scale using tivra M                   |
|  3 | Khamaj               | Ha r i k a m b hoj i           | S R G M P D N     | Scale using komal N                   |
|  4 | Bhairav              | Maya m ala v a g a v la        | S R G M P D N     | Scale using komal R and D             |
|  5 | Purvi                | Ka m a v a rdh ani             | S R G M P D N     | Scale using komal R, D and tivra M    |
|  6 | Marwa                | G a m ana sr a m a             | S R G M P D N     | S c al e us in g komal R an d tivra M |
|  7 | Kafi                 | K h a r a h a r ap r iya       | S R G M P D N     | Scale using komal G and N             |
|  8 | Asawari              | N a t ab h ai r a v i          | S R G M P D N     | Scale using komal G, D and N          |
|  9 | Bhairavi             | Han um a ttod i                | S R G M P D N     | Scale using komal R, G, D and N       |
| 10 | Todi                 | S u b h apan tuv a r ali       | S R G M P D N     | Scale using komal R, G, D and tivra M |

## Knowledge Plus!

A thaat loses its identity as soon as its swara-s are arranged to indicate a particular raag . After such an arrangement, the thaat becomes the aroha of a raag .

Even in the case of a raag after which the thaat has been named, if any ascending arrangement of swara-s is made with a view of expressing the chalan of the raag , it is simply called aroha and no longer a thaat .

For example, Bilawal thaat is S R G M P D N but if it is rearranged as S R G R, G P N D N, it becomes the aroha of a variety of Bilawal.

19

20

3.4

Raag Bhupali

## 3.4.1  Salient features

In this image, we can see a group of people. There are some text on the image.

<!-- image -->

## 3.4.2 Razakhani Gat

In this image we can see a graph.

<!-- image -->

| 1      | 2      | 3      | 4      | 5      | 6      | 7      | 8      | 9      | 10     | 11     | 12     | 13     | 14     | 15     | 16     |        |
|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi |
|        |        |        |        |        |        | DD     | PP     | G-     | GR     | -R     | GG     | S      | DD     | S      | R      |        |
|        |        |        |        |        |        | dir    | dir    | d      | rd     | r      | dir    | d      | dir    | d      | r      |        |
| G      | -      | G      | R      | G      | P      |        |        |        |        |        |        |        |        |        |        |        |
| d      | -      | d      | r      | d      | r      |        |        |        |        |        |        |        |        |        |        |        |
| Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha | Manjha |
|        |        |        |        |        |        | D      | P      | G      | RR     | GG     | RR     | S-     | SD     | D      | S      |        |
|        |        |        |        |        |        | d      | r      | d      | dir    | dir    | dir    | d-     | rd     | r      | d      |        |
| P      | DD     | S      | R      | G      | P      |        |        |        |        |        |        |        |        |        |        |        |
| d      | dir    | d      | r      | d      | r      |        |        |        |        |        |        |        |        |        |        |        |
| Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara | Antara |
| P      | GG     | R      | G-     | -G     | P      | D      | S      | P      | DD     | SS     | RR     | G-     | GR     | R      | S      |        |
| d      | dir    | d      | d      | r      | d      | d      | r      | d      | dir    | dir    | dir    | d-     | rd     | r      | d      |        |
| D      | PP     | G      | R      | S      | -      |        |        |        |        |        |        |        |        |        |        |        |
| d      | dir    | d      | r      | d      | -      |        |        |        |        |        |        |        |        |        |        |        |
| X      |        |        |        | 2      |        |        |        | 0      |        |        |        | 3      |        |        |        |        |

22

## Practical

## Step 1

Play the aroha, avroha and pakad :

S R G P D S

S D P G R S

G R S D, S R G, P G, D P G R S

Aroha :

Avroha :

Pakad :

## Step 2

Guided by your teacher, practise the following alaap given below:

```
1)  S  D  S,  D  S  R  S,  D  S  R  G 2)  R  G  R  G  P  G,  R  G, 3)  S  R  D  S 4)  S  R  G,  R  G  P  G,  G  P  D  P,  G, 5)  S  R  G  P,  D,  P  G,  G  P  G,  R  S 6)  S  R  G  P,  G  P  D  P,  D  P  G,  R  G  P,  G  P  D  P, G  P D S,  D  P,  G  P  D  P,  G,  R  G  P,  P  G,  D  P  G, R  G,  R  S,  D  S
```

## Step 3

Play the sthayi with the appropriate strokes:

The image is a table with 16 rows and 16 columns. The table has a light blue background with a white grid pattern. The table is titled "16" and has a white header. The table is structured with 16 rows and 16 columns. Each cell in the table contains a number or a mathematical expression. The numbers and expressions are written in a different font and color. The table is structured in a way that it is easy to read and understand.

The table has a title at the top of the table, which reads "16". Below the title, there are 16 rows and 16 columns. Each row contains a number or a mathematical expression. The numbers and expressions are written in a different font and color. The table is structured in a way that it is easy to read and understand.

The table is labeled with the number "16" at the top of the table. The table is structured with

<!-- image -->

In this image we can see a diagram.

<!-- image -->

24

## Practical

## Step 6

Play the whole razakhani gat in the following sequence:

1. Play the sthayi twice.

2. Play the manjha once.

3. Repeat the sthayi once.

4. Play the antara once.

5. Repeat the sthayi once.

## 3.4.3  Introduction to toda-s / taan-s

5 toda-s / taan-s of 6 matra-s have been given below:

1. SR  GP  GP  GR  S- -

2. GP  DP  GR  SD  S- -

3. G-   G-   RS  DP  GR  S-

4. GP  DP DS DP  GR  S-

5. GG  RS  DP   PD  SR  G-

## Practical

How to play a toda / taan ?

Step 1

Guided by your teacher, play the first toda / taan .

SR GP GP GR S--

Step 2

Practise it a few times.

## Practical

## Step 3

Replace the last 6 matra-s of the sthayi by the 6 matra-s of the toda / taan as shown below:

In this image, we can see a graph.

<!-- image -->

| 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10 11   | 12   |     | 13   | 14   | 15   | 16   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|---------|------|-----|------|------|------|------|
|     |     |     |     |     |     | DD  | PP  | G-  | GR      | -R   | GG  | S    | DD   | S    | R    |
|     |     |     |     |     |     | dir | dir | d-  | rd      | -r   | dir | d    | dir  | d    | r    |
| SR  | GP  | GP  | SR  | S-  | -   |     |     |     |         |      |     |      |      |      |      |
| dr  | dr  | dr  | dr  | d-  | -   |     |     |     |         |      |     |      |      |      |      |
| X   |     |     |     | 2   |     |     |     | 0   |         |      |     | 3    |      |      |      |

## Step 4

Play the remaining toda-s / taan-s using the same procedure:

| 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10   | 11   | 12   | 13   | 14   | 15   | 16   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|------|------|------|------|------|------|------|
|     |     |     |     |     |     | DD  | PP  | G-  | GR   | -R   | GG   | S    | DD   | S    | R    |
|     |     |     |     |     |     | dir | dir | d-  | rd   | -r   | dir  | d    | dir  | d    | r    |
| GP  | DP  | GR  | SD  | S-  | -   |     |     |     |      |      |      |      |      |      |      |
| dr  | dr  | dr  | dr  | d-  | -   |     |     |     |      |      |      |      |      |      |      |
| X   |     |     |     | 2   |     |     |     | 0   |      |      |      | 3    |      |      |      |

In this image we can see a table with some numbers.

<!-- image -->

25

26

In this image we can see a chart.

<!-- image -->

3.5

## Raag Brindavani Sarang

## 3.5.1 Salient features

In this image, we can see a diagram.

<!-- image -->

27

## 3.5.2 Maseetkhani Gat

In this image, we can see a chart.

<!-- image -->

Aroha :

Avroha :

Pakad : N S R M R, P M R, S

S R M P N S

S N P M R S

In this image, we can see a chart.

<!-- image -->

30

1. Play the sthayi twice.

2. Play the manjha once.

3. Repeat the sthayi once.

4. Play the antara once.

5. Repeat the sthayi once.

In this image, we can see a diagram.

<!-- image -->

## 3.5.3 Razakhani Gat

In this image I can see the text on the right side.

<!-- image -->

32

In this image, we can see a chart. There are some numbers on the chart.

<!-- image -->

1. Play the sthayi twice.

2. Play the manjha once.

3. Repeat the sthayi once.

4. Play the antara once.

5. Repeat the sthayi once.

In this image, we can see a diagram.

<!-- image -->

34

3.6

Raag Alhaiya Bilawal

## 3.6.1 Salient features

In this image, we can see a graph.

<!-- image -->

## 3.6.2 Razakhani Gat

In this image, we can see some text and numbers.

<!-- image -->

| 1         | 2         | 3         | 4         | 5      | 6      | 7      | 8      | 9      | 10     | 11     | 12     | 13     | 14     | 15     | 16     |        |
|-----------|-----------|-----------|-----------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
|           |           |           |           | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi | Sthayi |
|           |           |           |           | G      | PP     | DD     | NN     | D-     | DP     | P      | DP     | G      | MM     | P      | M      |        |
|           |           |           |           | d      | dir    | dir    | dir    | d-     | rd     | r      | dir    | d      | dir    | d      | r      |        |
| G- -G G R | G- -G G R | G- -G G R | G- -G G R |        |        |        |        |        |        |        |        |        |        |        |        |        |
| d-        |           |           |           | G      | PP     | D      | N      | S      | -      | N      | RR     | S      | N      | D      | P      | 35     |
|           |           |           |           | d      | dir    | d      | r      | d      | -      | d      | dir    | d      | r      | d      | r      |        |
| DD        | NN        | D         | RS        | N      | S      | DD     | NN     | D-     | DP     | P      | DP     | G      | MM     | P      | M      |        |
| dir       | dir       | d         | rd        | r      | d      | dir    | dir    | d-     | rd     | r      | dir    | d      | dir    | d      | r      |        |
| G- -G G R | G- -G G R | G- -G G R | G- -G G R |        |        |        |        |        |        |        |        |        |        |        |        |        |
| d-        | -r        | d         | r         |        |        |        |        |        |        |        |        |        |        |        |        |        |
| X         |           |           |           | 2      |        |        |        | 0      |        |        |        | 3      |        |        |        |        |

36

Aroha :

Avroha :

Pakad :

S, G R G P, D N S

S N D P, D N D P, M G M R, S

G R, G P, M G M R, G P D N D P

In this image, we can see a diagram.

<!-- image -->

| 1   | 2   | 3   | 4   | 5   | 6   | 7   | 8   | 9   | 10   | 11   | 12   | 13   | 14   | 15   | 16   |
|-----|-----|-----|-----|-----|-----|-----|-----|-----|------|------|------|------|------|------|------|
|     |     |     |     | G   | PP  | D   | N   | S   | -    | N    | RR   | S    | N    | D    | P    |
|     |     |     |     | d   | dir | d   | r   | d   | -    | d    | dir  | d    | r    | d    | r    |
| DD  | NN  | D   | RS  | N   | S   | DD  | NN  | D-  | DP   | P    | DP   | G    | MM   | P    | M    |
| dir | dir | d   | rd  | r   | d   | dir | dir | d-  | rd   | r    | dir  | d    | dir  | d    | r    |
| G-  | -G  | G   | R   |     |     |     |     |     |      |      |      |      |      |      |      |
| d-  | -r  | d   | r   |     |     |     |     |     |      |      |      |      |      |      |      |
| X   |     |     |     | 2   |     |     |     | 0   |      |      |      | 3    |      |      |      |

1. Play the sthayi twice.

2. Play the antara once.

3. Repeat the sthayi once.

In this image we can see a diagram.

<!-- image -->

The image consists of two main elements: a circular object and a text box. The circular object is a white background with a red outline. It has a rounded shape and a slight curve at the top. The text box is placed on the right side of the circular object.

The text box is white with a red outline. It contains the text "keywords" in uppercase letters. The text is in a sans-serif font, which is easy to read. The text is in a larger font size compared to the circle.

The background of the text box is a gradient of red and white, transitioning from a darker shade at the top to a lighter shade at the bottom. This gradient helps to draw attention to the text.

The image is simple and clean, with minimalistic elements. The use of color and font makes the text box stand out. The overall design is modern and professional.

### Analysis and Description:

- **Object**:

<!-- image -->

37

38

ASSESSMENT

1. (a) Explain the term ashraya raag .

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

- (b) In the table given below, write down the name(s) of:
- (i)  any 5 thaat-s
- (ii) 1 ashraya raag classified under that thaat.

| Thaat             | Ashraya Raag      |
|-------------------|-------------------|
| ……………………………………….. | ……………………………………….. |
| ……………………………………….. | ……………………………………….. |
| ……………………………………….. | ……………………………………….. |
| ……………………………………….. | ……………………………………….. |
| ……………………………………….. | ……………………………………….. |

ASSESSMENT

## Raag Bhupali

Thaat

Aroha

Avroha

Pakad

Vadi

Samvadi

## Raag Alhaiya Bilawal

Thaat

Aroha

Avroha

Pakad

Vadi

Samvadi

## Raag Brindavani Sarang

Thaat

Aroha

Avroha

Pakad

Vadi

Samvadi

2. State whether the following sentences are True (T) or False (F).

- i. Raag Brindavani Sarang is an ashraya raag falling under the Kalyan thaat .

- ii. Out of the 10 thaat-s, Bilawal is one of them.

- iii. The vivadi swara-s in raag Bhupali are Ma and Ni.

- iv. Raag Brindavani Sarang is classified under the Kafi thaat .

- v.  The vadi swara of raag Alhaiya Bilawal is Dha.

3. In the tables given below, write down the salient features of the following raag-s :

13 39

40

## NOTES

In this image, we can see some text and images.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  Define the term jati and its varieties.
-  Describe the three main jati-s ( sampurna, shadav, audav ) and the nine jati combinations obtained from the permutation of the three main ones.
-  Explain the classification of raag-s based on the raag-jati system.

42

<!-- image -->

According to the shastra-s , jati is so called, owing to its being born from the 2 grama-s :

- •
- Shadja Grama · Madhyama Grama

Grama means a collection or a group. In Indian music, grama refers to the collection of swara-s.

The jati is a method of classifiying the raag-s according to the number of swara-s used in their aroha and avroha .

The 3 main jati-s are:

In this image, we can see a diagram.

<!-- image -->

By the permutation of the 3 jati-s, 9 jati combinations are obtained which are as follows:

1. When a raag takes 7 swara-s in both the aroha and avroha , it is categorized as a sampoorna - sampoorna jati .
2. When a raag takes 7 swara-s in the aroha and 6 swara-s in the avroha , it is categorized as a sampoorna - shadav jati .
3. When a raag takes 7 swara-s in the aroha and 5 swara-s in the avroha , it is categorized as a sampoorna - audav jati .
4. When a raag takes 6 swara-s in the aroha and 7 swara-s in the avroha , it is categorized as a shadav - sampoorna jati .
5. When a raag takes 6 swara-s in both the aroha and avroha, it is categorized as a shadav - shadav jati .
6. When a raag takes 6 swara-s in the aroha and 5 swara-s in the avroha , it is categorized as a shadav - audav jati .
7. When a raag takes 5 swara-s in the aroha and 7 swara-s in the avroha , it is categorized as an audav - sampoorna jati .
8. When a raag takes 5 swara-s in the aroha and 6 swara-s in the avroha , it is categorized as an audav - shadav jati .
9. When a raag takes 5 swara-s in both the aroha and avroha , it is categorized as an audav - audav jati .

43

44

## The 9 jati combinations are as follows:

|   Number of swara-s in aroha |   Number of swara-s in avroha | Jati                                     |
|------------------------------|-------------------------------|------------------------------------------|
|                            7 |                             7 | Sampoorna - Sampoorna (Heptatonic scale) |
|                            7 |                             6 | Sampoorna - Shadav                       |
|                            7 |                             5 | Sampoorna - Audav                        |
|                            6 |                             7 | Shadav - Sampoorna                       |
|                            6 |                             6 | Shadav - Shadav (Hexatonic scale)        |
|                            6 |                             5 | Shadav - Audav                           |
|                            5 |                             7 | Audav - Sampoorna                        |
|                            5 |                             6 | Audav - Shadav                           |
|                            5 |                             5 | Audav - Audav (Pentatonic scale)         |

Diagram showing the 9 jati combinations of raag-s :

In this image we can see the image of a person and the background is white in color.

<!-- image -->

46

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

## Classification of raag-s based on the raag-jati system

The formation of raag-s based on the raag-jati system is shown below:

- With reference to the Bilawal thaat ,

## NOTE:

- Bilawal thaat has been chosen since all the swara-s are shuddha .
- (i) Only 1 scale of 7 swara-s ( sampoorna jati ) can be obtained which is:

S  R  G  M  P  D N

- (ii) 6 scales of 6 swara-s ( shadav jati ) can be obtained as shown below:

## NOTE:

-  T o obtain a scale of 6 swara-s , 1 swara has to be omitted out of the 7.
-  Sa is never omitted.

| Swara omitted   | Scale obtained   |
|-----------------|------------------|
| R               | S G M P D N      |
| G               | S R M P D N      |
| M               | S R G P D N      |
| P               | S R G M D N      |
| D               | S R G M P N      |
| N               | S R G M P D      |

47

- (iii) 15 scales of 5 swara-s ( audav jati ) can be obtained which are as follows:

## NOTE:

-  T o obtain a scale of 5 swara-s , 2 swara-s have to be omitted each time:

| Swara-s omitted   | Scale obtained   |
|-------------------|------------------|
| R G               | SMP D N          |
| R M               | S G P D N        |
| R P               | S G M D N        |
| R D               | SGMPN            |
| R N               | SGMP D           |
| G M               | S R P D N        |
| G P               | S R M D N        |
| G D               | SRMPN            |
| G N               | SRMP D           |
| MP                | S R G D N        |
| M D               | S R G P N        |
| M N               | S R G P D        |
| P D               | SRGMN            |
| P N               | SRGM D           |
| D N               | SRGMP            |

- Using these scales and combining them with the 9 jati combinations, the formation of 484 raag-s from 1 thaat is obtained:

| Aroha       | Avroha      |   Number of raag-s formed | Description                                                                                                                                                                                                            |
|-------------|-------------|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Sampoorna 1 | Sampoorna 1 |                         1 | Only 1 raag with a sampoorna - sampoorna jati is obtained. ( 1 X 1 = 1)                                                                                                                                                |
| Sampoorna 1 | Shadav 6    |                         6 | When the 1 sampoorna - jati scale is paired with 6 shadav - jati scales, there is the possibility of the formation of 6 raag-s . Each raag will have 7 swara-s in the aroha and 6 swara-s in the avroha . (1 X 6 = 6)  |
| Sampoorna 1 | Audav 15    |                        15 | When 1 sampoorna - jati scale is paired with 15 audav - jati scales, there is the possibility of the formation of 15 raag-s . Each raag will have 7 swara-s in the aroha and 5 swara-s in the avroha . ( 1 X 15 = 15 ) |
| Shadav 6    | Sampoorna 1 |                         6 | When 6 shadav - jati scales are paired with 1 sampoorna - jati scale, there is the possibility of the formation of 6 raag-s . Each raag will have 6 swara-s in the aroha and 7 swara-s in the avroha . ( 6 X 1 = 6 )   |
| Shadav 6    | Shadav 6    |                        36 | When 6 shadav - jati scales are paired with 6 shadav - jati scales, there is the possibility of the formation of 36 raag-s . Each raag will have 6 swara-s in the aroha and 6 swara-s in the avroha . ( 6 X 6 = 36 )   |

49

50

| Shadav 6   | Audav 15    |   90 | When 6 shadav - jati scales are paired with 15 audav - jati scales, there is the possibility of the formation of 90 raag-s . Each raag will have 6 swara-s in the aroha and 5 swara-s in the avroha . ( 6 X 15 = 90 )    |
|------------|-------------|------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Audav 6    | Sampoorna 1 |   15 | When 15 audav - jati scales are paired with 1 sampoorna - jati scale, there is the possibility of the formation of 15 raag-s . Each raag will have 5 swara-s in the aroha and 7 swara-s in the avroha . ( 15 X 1 = 15 )  |
| Audav 15   | Shadav 6    |   90 | When 15 audav - jati scales are paired with 6 shadav - jati scales, there is the possibility of the formation of 90 raag-s . Each raag will have 5 swara-s in the aroha and 6 swara-s in the avroha . ( 15 X 6 = 90 )    |
| Audav 15   | Audav 15    |  225 | When 15 audav - jati scales are paired with 15 audav - jati scales, there is the possibility of the formation of 225 raag-s . Each raag will have 5 swara-s in the aroha and 5 swara-s in the avroha . ( 15 X 15 = 225 ) |
| Total      |             |  484 | Thus, 484 raag-s are formed from 1 thaat .                                                                                                                                                                               |

The image is a circular graphic with two words written on it. The words are "keywords" and "scale," and they are written in a sans-serif font. The background of the graphic is white, and the text is in red.

The circle is positioned in the center of the image, and it has a simple, clean design. The text is written in a sans-serif font, which means it is not stylized or embellished. The background of the graphic is a solid white color, which makes the text stand out.

The image is simple and straightforward, with no additional elements or decorations. The focus is on the text, which is the main focus of the image. The text is written in a clear, easy-to-read font, and it is positioned in such a way that it is easily readable.

The image does not contain any additional objects or elements, such as additional text, images, or graphics. The focus

<!-- image -->

ASSESSMENT

1. (a) Explain the term jati .

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

- (b) List down the 3 types of jati .

……………………………

……………………………

……………………………

- (c) Write down the 9 jati combinations that can be obtained by the permutation of the 3 jati-s that you have mentioned above.

1.

...................................  -  ...................................

2.

...................................  -  ...................................

3.

...................................  -  ...................................

4.

...................................  -  ...................................

5.

...................................  -  ...................................

6.

...................................  -  ...................................

7.

...................................  -  ...................................

8.

...................................  -  ...................................

9.

...................................  -  ...................................

51

52

ASSESSMENT

## 2. Write down the jati-s of the following raag-s in the table below:

NOTE: When calculating the jati of a raag , two similar swara-s (for example, madhya saptak Sa and taar saptak Sa) are counted as one.

| Raag       | Aroha       | Avroha      | Jati                                                  |
|------------|-------------|-------------|-------------------------------------------------------|
| Bilawal    | SRGMPDNS    | SNDPMGRS    | ......................... - ......................... |
| Bhupali    | SRGPDS      | SDPGRS      | ......................... - ......................... |
| Bhimpalasi | NSGMPNS     | SNDPMGRS    | ......................... - ......................... |
| Bhairav    | SRGMP D N S | SNDPMGRS    | ......................... - ......................... |
| Khamaj     | SGMPDNS     | SNDPMGRS    | ......................... - ......................... |
| Malkauns   | SGM D N S   | S N D MGS   | ......................... - ......................... |
| Asawari    | SRMP D S    | S N D PMGRS | ......................... - ......................... |

In this image we can see a poster with some text and images.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  Explain the prescribed vocal forms.
-  Identify and list some of the folk songs prevalent in Mauritius.
-  Elaborate the role of folk songs in bringing unity among various communities in Mauritius.
-  Name at least 3 persons who are famous in the field of folk songs in Mauritius.

54

<!-- image -->

Khayal is one of the most popular forms of vocal music in North Indian classical music. Khayal is a Persian word which means idea or imagination. It is believed that khayal came into existence because its precursor, the dhrupad (a  vocal genre  with  very  rigid  rules)  lost  popularity. Khayal gained  much  public appreciation over dhrupad as  since  it  is  mostly  based  on  improvisation,  the singer has the liberty to use swara-s in  his  own  way,  based on the melodic movements of the raag .

It is believed that the qawaliya-s used to sing the khayal as a form of folk song. In  the  14 th  century  A.D,  Amir  Khusro  introduced  the khayal as  a  form  of chamber music in the court of Emperor Alauddin Khan. In the 15 th  century A.D, Nawab Sultan Hussain Shirqui of Jaipur bestowed dignity to khayal singing in his  own  court.  Various  ornamentations  that  were  prohibited  in  the dhrupad were introduced in this form of singing and this enriched it. In the beginning, the khayal resembled  in  many  aspects  the dhrupad form  but  in  the  course  of evolution, it took a distinct form of music.

Later,  the khayal was  further  enriched  by  Shah  Sadarang,  descendant  of Saraswati Devi, daughter of Tansen.

Figure 5.1: Musicians in the court of King Allaudin Khan

In this image we can see a group of people sitting on the chairs. There are some objects in the image.

<!-- image -->

The khayal is mostly composed  in North Indian languages such as Braj-bhasha, Hindi, Rajasthani, Punjabi and so on. Khayal singing is usually based on themes such as the praise of Gods or kings, divine or human love, and seasons, amongst others.

The composition / bandish is very important in a khayal performance and the ability of the singer is judged by the accuracy with which he / she renders it. The khayal is  usually  sung  in taal-s such  as Ektaal,  Teentaal,  Tilwada,  Jhumra, amongst others.

The khayal is divided into two parts namely the sthayi and antara . The sthayi is sung in the mandra and madhya saptak-s whereas the antara is mostly sung in the madhya and taar saptak-s .

There are two types of khayal namely bada khayal and chhota khayal .

Figure 5.2: Pandit Bhimsen Joshi, a famous vocalist

In this image we can see a person holding a musical instrument.

<!-- image -->

The bada khayal is sung in slow tempo, after the alaap has been completed by the singer. Due to its slow tempo, the bada khayal is full of grace.

The chhota khayal is  sung in madhya or drut laya and starts after the bada khayal has  been  completed.  It  is  composed  in  the  same raag as  the bada khayal and it is usually set in the same taal .  Emphasis is laid on the proper singing of toda-s at fast speed.

The musical instruments accompanying a khayal singer are the tabla, sarangi, harmonium, tanpura and so on.

55

<!-- image -->

Bhajan is a devotional genre of vocal music that developed during the bhakti movement  in  North India. It is performed by a main  singer, usually accompanied by one or more musicians.

Figure 5.3: Singing of bhajan-s in a temple by a group of devotees

In this image we can see a group of people sitting on the chairs. In the background there is a wall with some designs.

<!-- image -->

Bhajan-s were originally meant to be performed in homes and temples, but nowadays, they are also performed in concerts before an audience.

Figure 5.4: Artists performing in a bhajan concert

In this image we can see a group of people. There are mics, a guitar and a banner.

<!-- image -->

Depicting the shanta rasa , some of the popular themes of bhajan-s are based on devotion for the deities, holy texts from the scriptures, teachings of great saints and so on. The name of the composer is usually included in the last line of the bhajan .

Some of the finest authors of bhajan during the bhakti period in India were:

Meera Bai

In this image we can see a person sitting on the sofa.

<!-- image -->

In this image we can see a cartoon image of a person.

<!-- image -->

In this image we can see a painting of a person.

<!-- image -->

Shree Vallabhacharya

<!-- image -->

Sant Tukaram

<!-- image -->

<!-- image -->

Some of the deities / saints on which bhajan-s are usually sung are:

-  Lord Shiva
-  Lord Vishnu
-  Goddess Durga
-  Goddess Saraswati
-  Incarnations of Lord Vishnu such as Ram, Krishna, amongst others
-  Sri Sathya Sai Baba

57

<!-- image -->

Ghazal is  a  light  classical  form  of  singing  which  became  popular  in  the 19 th  century. Ghazal consists of poetry which has been set to tune and metre ( taal ).  Originally  written  in  Persian  language,  the  lyrics  of  a ghazal are nowadays mostly written and sung in Urdu.

Figure 5.5: Mirza Ghalib, a famous poet of the 19 th  century

In this image we can see a person wearing a hat.

<!-- image -->

This style of singing lays much emphasis on:

- (i) the correct pronunciation of words
- (ii) emotional appeal.

A ghazal consists of rhyming couplets and the common themes that inspire ghazal composers are love, pain and so on.

Ghazal is  rendered  in  popular raag-s such  as Bhairavi,  Pilu,  Bhimpalasi, Khamaj and so on. It is mostly set in taal-s like Dadra, Keherwa, Deepchandi, amongst others.

Musical instruments which are usually used as accompaniment in a ghazal performance are the tabla, harmonium, sarangi, violin, sitar, guitar and so on.

Figure 5.6: A ghazal singer accompanied by his musicians

In this image we can see a group of people sitting on chairs and playing musical instruments. In the background there is a light.

<!-- image -->

Radio  channels  and  the  Indian  film  industry  have  greatly  contributed  in popularizing ghazals and  today,  this  vocal  art  form  has  a  wide  range  of admirers.

In this image, we can see a video playing.

<!-- image -->

59

60

<!-- image -->

Folk music is found in all countries over the world. It refers to original tribal singing. Also known as gramya-gaan, folk songs are simple verses composed and  sung  by  common  people  in  their  dialect.  Traditionally  performed  by untrained  musicians,  these  songs  are  passed  on  from  one  generation  to another orally, without any form of notation.

Great  changes  have  been  brought  in  the social, religious, economic and political fields through  folk  music  due  to  its  enchanting charm and power. It has a great educative value and gives grace and refinement to all human expressions.

Folk songs are very lucid and full of expressions  in  simple  forms. They  express the feelings of common people.

Folk music is one of the oldest form of music.

Figure 5.7: A folk singer accompanied by the musicians

In this image I can see a logo and text. The text is in white color.

<!-- image -->

In this image we can see a group of people sitting and playing musical instruments.

<!-- image -->

Folk  songs  are  always  linked  with  legends  and  themes.  While  some  are associated  with  activities such  as  work,  games or  religious  ceremonies, others are purely meant for entertainment purposes.

## Some of the common themes of folk songs are:

- Birth of a child
- Death of a person
- Departure of the bride
- Love
- Separation
- Joy
- Village sceneries such as drawing of water from the well

<!-- image -->

## Did You Know?

It  is  believed that the coming into existence of folk tunes in India was originally due to the restrictions imposed by the high class pandit-s who did  not  permit  people  of  other  classes  to  join  them  in  the  chanting  of Veda-s . In order to be able to express their inner feelings through music and for recreational purposes, these people created their own folk tunes, thus bringing a change in the social pattern in their life.

In the beginning, the only difference in the chanting of ' Om ' was in the pronunciation  and  the  metre  ( taal ).  The  palanquin  bearers'  songs consisted of ' Om, Om, Om ' in a peculiar style of their own. Hence, it can be said that the sense of music prevailed among all religions and castes without any barrier.

61

62

In this image, we can see a poster with some text and images.

<!-- image -->

5.5

## Folk music in Mauritius

## 5.5.1  Sega

Introduced in Mauritius during the slavery period, the Sega was performed by the African slaves. It was a medium through which they could express their feelings and forget their sorrows and daily hardships. In those days, the lyrics of  the  Sega were based on the miseries faced by them, the cruelty of their masters and the pain of separating from their dear ones.

Figure 5.8: Portrait of slaves practising the Sega

In this image there are a group of people standing and holding a person.

<!-- image -->

However,  today,  the  Sega  is  a  form  of celebration and entertainment. Once regarded as the music mainly for the Afro-Mauritian  community,  the  Sega  has achieved  great  popularity  and  today,  it  is widely  enjoyed  by  the  whole  population  of Mauritius.

Composed in the Creole language, the main themes of  the  Sega  are  about  love,  social matters, amongst others. The lyrics, strong rhythms, and the catchy tunes contribute to the popularity of the Sega.

<!-- image -->

## Did You Know?

When  the  singer  says 'eh-la-eh-la-eh', it is the signal  for  everyone  to join in. This sentence is repeated by all the dancers as the Sega reaches its climax.

63

64

The traditional clothes of the Sega are very colourful and attractive. Men wear rolled-up trousers and a loose buccaneer shirt which is usually knotted. Some even wear a straw hat as part of the costume. Women dancers wear a long colourful skirt and a short blouse.

Figure 5.9: Sega dancers in the colourful dresses

In this image we can see a group of people standing on the beach. There are two men and a woman. One of them is holding a surfboard. There is a woman holding a handbag. There is a man holding a hat. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a handbag. There is a man holding a surfboard. There is a woman holding a hand

<!-- image -->

As the musician starts playing the ravanne,  slowly  at  first,  everyone  starts gathering  around  the  fire.  Holding  their skirts with both hands and swinging their hips, the women are the first ones to start dancing.

The male dancers also join in, with their arms wide open. As the rhythm increases, both  men  and  women  can  be  seen swaying  and  dancing  with  full  joy  and excitement.

The main instruments of the Sega are the ravanne, maravanne and triangle.

Figure 5.10:  A Sega dancer holding her skirt with both hands

In this image we can see a woman wearing a costume and holding a cloth in her hands. In the background we can see a person and a curtain.

<!-- image -->

## Knowledge Plus!

## Sega Tambour

The  Sega  of  Rodrigues  is  called Sega tambour or  Sega barré .  It  is mostly sung by women while male dancers,  one  at  a  time,  join  in  to form a dancing pair with them.

<!-- image -->

A very fast rhythm and the repetition of the same words over and again are its main features.

Sega tambour was inscribed on the Representative List of the Intangible Cultural Heritage of Humanity on 7 th  December 2017.

## 5.5.2  Bhojpuri folk songs

## · Sumiran

Sumiran , also known as Devi-Devta ke geet , is a collective devotional singing which expresses the faith and love for the Divinity.

Normally, Sumiran consists of:

- (i) Ganeshji ke geet ( Songs of Lord Ganesha)
- (ii) Suraj Devta ke geet ( Songs invoking the Sun God)
- (iii) Ram - Sita ke geet ( Songs of Lord Ram and his consort Sita)
- (iv) Shiv - Parvati ke geet ( Songs of Lord Shiva and Goddess Parvati)
- (v) Radha - Krishna ke geet (Songs of Lord Krishna and Radha)

## · Jhoomar

Jhoomar is derived from the word jhoom , which means swaying with the music. Performed on festive occasions such as weddings, jhoomar is a lively song full of  happiness  and  merry-making.  Dressed  in  colourful  traditional  dresses, women sing, dance and clap their hands to the beats of the dholak and chammach (spoon) - lota .

65

## · Chawtaal

Performed during the Holi festival, the chawtaal consists of traditional folk songs sung  in  a  group.  Traditionally  sung  by  male  singers  only,  it  is  nowadays performed  by  both  men  and  women  who  wear  traditional  dresses.  Musical instruments which are usually played during a chawtaal performance are the dholak, jhaal and chimta. The lyrics are mostly based on the pranks of Lord Krishna  and  the  praise  of  Lord  Ram.  Starting  at  a  slow  pace,  a chawtaal performance usually ends at a very fast tempo.

Figure 5.11: Villagers performing the chawtaal

In this image we can see a group of people standing and holding some objects. In the background there is a building and some objects.

<!-- image -->

## · Gamat

Gamat, in Bhojpuri language, means enjoyment. It is performed on the eve of the  wedding  ceremony  in  the  Hindu  community. A gamat singer  is  usually accompanied by musicians performing on the harmonium and tabla.

Figure 5.12: Sona Noyan, a famous gamat singer accompanied by a percussionist

In this image we can see a man standing in front of a microphone and playing drums. In the background there are some other people standing and there are some lights.

<!-- image -->

The special feature of the gamat is the sawal-jawab . It consists of a musical session of questions and answers between two singers and ends when one of them gives up.

There are other folk songs such as:

- Sohar and lallna - sung at child birth.
- Harparawri - sung during  rainy seasons.

<!-- image -->

## Importance of folk music

## Folk music

- Represents the history, culture &amp; values of a community. 1
- Is a medium of transferring the traditions and cultures from one generation to another. 2
- Is closely associated with the community rituals and social events. 3
- Is a way of communicating with the population. 4
- Helps in understanding the cultural background of a country. 5
- Brings people together and thus, helps in socialization. 6

67

68

<!-- image -->

## Local artists in Mauritius

## · Sega

## Serge Lebrasse

- Born on 25 th  June 1930.
- In 1976, he was awarded the MBE (Member of the British Empire) for his contribution to the Mauritian culture.
- One of his famous songs: Madame Eugene .

<!-- image -->

Here are two links of 'Serge Lebrasse' songs on YouTube:

https://www.youtube.com/watch?v=sJfF2v9r2gA

## Louis Gabriel Joseph

- Artist name: Fanfan
- Born on 27 th  July 1930 in Mahebourg
- One of his popular songs: Ala la ki ti zoli zoli .

<!-- image -->

Here are two links of 'Fanfan' songs on YouTube:

https://www.youtube.com/watch? v=RUg6Q01SqX4 https://www.youtube.com/watch?v=l2qW\_iNPSbk

Figure 5.13: Serge Lebrasse

<!-- image -->

Figure 5.14: Louis Gabriel Joseph

<!-- image -->

## · Bhojpuri folk songs

## Gowree Brothers

- Gave a new dimension to Bhojpuri folk music in the 60s.

<!-- image -->

Here are two links of 'Gowree Brothers' songs on YouTube:

https://www.youtube.com/watch?v=EgDx9XlPFaw https://www.youtube.com/watch?v=bmHIXetmduk

## Sona Noyan

- Also known as Bhai Sona .
- Titled as the King of Gamat by his admirers.
- One of his popular songs: Khali pile .

<!-- image -->

Here are two links of 'Bhai Sona' songs on YouTube:

https://www.youtube.com/watch?v=K69N-pWoSRQ https://www.youtube.com/watch?v=hZ8CgVP6MeM

<!-- image -->

Figure 5.15: Gowree Brothers

<!-- image -->

Figure 5.16: Sona Noyan

<!-- image -->

Classical music, vocal, traditional music.

69

70

ASSESSMENT

## 1. Fill in the blanks with the appropriate words:

- (i) There are two types of khayal,

- namely \_\_\_\_\_\_\_\_\_\_ and \_\_\_\_\_\_\_\_\_\_\_.

- (ii)  \_\_\_\_\_\_\_\_\_\_\_\_\_ is a type of devotional song in North India, depicting the shanta rasa .

- (iii)  A \_\_\_\_\_\_\_\_\_ consists of rhyming couplets written and sung in the Urdu language.

- (iv) A \_\_\_\_\_\_\_\_ song is sung by the common people and is an expression of the life in the village.

- (v) Composed in the Creole language, the \_\_\_\_\_\_ is a form of folk music

- in Mauritius.

## 2. State whether the following sentences are True (T) or False (F).

- A bada khayal is a classical composition sung in vilambit laya . (i)

- Ghazal is a form of devotional singing. (ii)

- One of the famous composer and singer of bhajan-s during the bhakti period was Meera Bai. (iii)

- Folk songs are closely linked to the rituals and events in a community. (iv)

- Bhojpuri was introduced in Mauritius by the African slaves. (v)

ASSESSMENT

3. Briefly explain the following vocal forms:

- (i) Khayal

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

- (ii) Ghazal

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

- (iii) Bhajan

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

- (iv) Folk songs

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

4. Write a short paragraph on 'Folk music in Mauritius'.

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

……………………………………………………………………………………

71

72

## NOTES

In this image we can see a musical instrument.

<!-- image -->

## Learning Objectives

## At the end of this chapter, learners should be able to:

-  Explain the term layakari .
-  Differentiate between thah , dugun and chawgun laya-s .
-  Explain tihai and its varieties ( bedam, damdaar ).
-  Examine the structure and the salient features of the following taal-s : Jhaptaal and Ektaal .
-  Count and recite taal-s Dadra, Teentaal, Kaherwa and Roopak (single and double tempi).
-  Count and recite taal-s Jhaptaal and Ektaal in single tempo only.
-  Recognise all taal-s studied since grade 7.

74

<!-- image -->

Layakari is derived from the 2 words laya and kari . Laya means tempo and kari means skill. Layakari refers to the skill of improvising at different laya-s within the basic tempo ( thah laya ) of the taal . The basic laya is usually maintained by the tabla accompanist.

Three types of layakari explained below are:

## (i) Thah laya

Thah  laya refers  to  the  basic laya of  a  composition  and  is  also  known  as ekguna laya .

| Matra     | 1 2   | 3   | 4   | 5   | 6   | 7   | 8   |
|-----------|-------|-----|-----|-----|-----|-----|-----|
| Swara     | S R   | G   | M   | P   | D   | N   | Ṡ   |
| Taal Sign | X     |     |     | 0   |     |     |     |

In this image we can see a table with some numbers.

<!-- image -->

## (ii) Dugun

When two swara-s are played within a time frame of one matra , it is called dugun .

| Matra     | 1 2 3 4 5 6 7 8         |
|-----------|-------------------------|
| Swara     | SR GM PD NS SN DP MG RS |
| Taal Sign | X 0                     |

In this image, we can see a table. On the table, we can see some numbers.

<!-- image -->

## (iii) Chawgun

When four swara-s are played within a time frame of one matra ,  it  is  called chawgun .

| Matra     | 1 2 3 4 5           | 6 7 8               |
|-----------|---------------------|---------------------|
| Swara     | SRGM PDNS SNDP MGRS | SRGM PDNS SNDP MGRS |
| Taal Sign | X                   | 0                   |

In this image, we can see a table with some data.

<!-- image -->

<!-- image -->

A tihai is the repetition of a rhythmic / melodic phrase thrice with equal or no interval in between them.

It is one of the important components used in the three art forms, that is, vocal, instrumental and dance. As all these three forms have their own  identity, tihai-s are  used  differently  to  adapt  to  each  of  these  forms.

<!-- image -->

## Did You Know?

The concept of tihai is thought to have originated from the tradition of the  oral recitation of the Veda-s in which the last pada or phrase of a line was repeated thrice to show the end of the line. This triple repetition denoted the end of the  current  line.  Scholars  consider  this  tradition  as  the source of the concept of tihai in Indian music.

75

76

## Types of tihai :

## · Damdaar tihai

A damdaar tihai refers to a tihai consisting of a break of half a matra or more in between each phrase.

In this image we can see a number line. On the number line we can see a number 1,2,3,4,5,6,7,8,9,10,11,12.

<!-- image -->

## · Bedam tihai

Unlike the damdaar tihai , a bedam tihai is one in which there is no break or gap in between each repeated phrase.

In this image there is a table with some numbers on it.

<!-- image -->

## Knowledge Plus!

Other types of complex tihai-s :

## · Chakradaar tihai

```
X 2 0 3 1      2      3      4      5      6      7      8      9     10     11    12    13    14    15    16 GM   DN    S-   GM   DN    S-    GM   DN    S-     -    GM   DN S-   GM   DN    S-    GM   DN    S--GM   DN    S-    GM   DN    S-    GM   DN S-
```

## · Bedam Chakradaar tihai

```
X 2 0 3 1      2      3      4      5      6      7      8      9     10     11    12    13    14    15    16 GM   DN  S M DN S, G   MD   NS    MD NS , GM   DN   S M   DN S, G   MD  NS   MD   NS , GM   DN   S M   DN S, G    MD NS   MD   NS , GM  DN   S M   DN S, G    MD    NS    MD     NS ,  GM    DN     S M    DN S-
```

## · Navhakka tihai

```
X 2 0 3 1      2      3      4      5      6      7      8      9     10     11    12    13    14    15    16 PM   GR   NR   GR   G- ,  PM   GR   NR   GR    G- , PM   GR   NR   GR    G-  , --PM   GR    NR   GR   G-  , PM   GR   NR   GR    G- , PM   GR   NR   GR    G- , --PM   GR   NR    GR    G- , PM  GR   NR   GR    G- ,  PM   GR   NR   GR G-
```

77

78

- In a chakradaar tihai , the tihai is played thrice to reach the sam and to the listeners, the melodic or rhythmic phrase appears to have been played 9 times (3x3).
- If a tihai is repeated more than 3 times, it loses its identity of a tihai and is called a chakradaar tukda .

<!-- image -->

Jhaptaal is a rhythmic cycle of 10 matra-s / beats. It has 4 vibhaag-s . The sam is on the 1 st matra and khali on the 6 th matra .

| Number of matra-s   | 10                    |
|---------------------|-----------------------|
| Divisions           | 2 / 3 / 2 / 3         |
| Sam                 | 1 st matra            |
| Khali               | 6 th matra            |
| Tali-s              | 3 rd and 8 th matra-s |

| Matra     | 1    | 2   | 3    | 4    | 5   | 6   | 7   | 9    |      | 10   |      |
|-----------|------|-----|------|------|-----|-----|-----|------|------|------|------|
| Theka     | Dhin | Na  | Dhin | Dhin | Na  | Tin | Na  | Dhin | Dhin | Na   | Dhin |
| Taal Sign | X    |     | 2    |      |     | 0   |     | 3    |      |      | X    |

<!-- image -->

Ektaal is  a  rhythmic  cycle  of  12 matra-s /  beats.  It  has  6 vibhaag-s ,  each consisting of 2 matra-s . The sam is on the 1 st matra and khali on the 3 rd  and 7 th matra .

| Number of matra-s   | 12                            |
|---------------------|-------------------------------|
| Divisions           | 2 / 2 / 2 / 2 / 2 / 2         |
| Sam                 | 1 st matra                    |
| Khali               | 3 rd and 7 th matra-s         |
| Tali-s              | 5 th , 9 th and 11 th matra-s |

| Matra     | 1 2       | 3 4          | 5 6   | 7   | 8   |    | 9 10   | 11 12       | 1   |      |
|-----------|-----------|--------------|-------|-----|-----|----|--------|-------------|-----|------|
| Theka     | Dhin Dhin | DhaGe Titkit | Too   | Na  | Kat | Ta | Dhage  | Titkit Dhin | Na  | Dhin |
| Taal Sign | X         | 0            | 2     |     | 0   |    | 3      | 4           |     | X    |

In this image we can see a circle and text.

<!-- image -->

79

80

ASSESSMENT

## 1. Fill in the blanks with the appropriate words:

- The type of layakari in which 4 swara-s are played within one matra is called \_\_\_\_\_\_\_\_\_\_. i.

- The tihai which consists of a gap between each of the 3 melodic  phrases is  called a \_\_\_\_\_\_\_\_\_\_\_\_\_ tihai whereas that in which there  is no gap in between is known as a \_\_\_\_\_\_\_\_\_\_\_ tihai . ii.

- Jhaptaal is a rhythmic cycle of \_\_\_\_\_\_\_ matra-s and its first bol is iii.

\_\_\_\_\_\_\_\_ .

- Ektaal vibhaag-s . iv.

- is a rhythmic cycle of \_\_\_\_\_\_\_ matra-s and consists of \_\_\_\_\_\_

- During taal demonstration, the 3 rd  and 7 th matra-s of Ektaal are demonstrated by a \_\_\_\_\_\_\_\_ of the hand. v.

## 2. State whether the following statements are True (T) or False (F).

- The type of layakari in which 4 swara-s are played within a time frame of one matra is called chawgun . i.

- A bedam tihai is played with a break in between each of the 3 repetitions. ii.

- Jhaptaal is a rhythmic cycle which consists of 6 vibhaag-s . iii.

- The first bol of Ektaal is Dhin . iv.

- The taal signs of Jhaptaal are X, 2, 0 and 3. v.

ASSESSMENT

3. In the spaces provided below, notate the following taal-s with the appropriate signs and symbols:
2. (i) Jhaptaal

## (ii) Ektaal

81

82

## NOTES

In this image, we can see musical instruments. There are drums, guitars, and other musical instruments.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  List and explain the categories of musical instruments.
-  Name at least five instruments in each category.

84

<!-- image -->

## Classification of Musical Instruments

## · Bharata's classification system

According to Bharata's Natyashastra ,  musical  instruments  can  be  classified into 4 categories based on their sound producing mechanism. These are as follows:

In this image, we can see a chart with different categories. There are some musical instruments in the image.

<!-- image -->

## · Hornbostel - Sachs classification system

The Hornbostel - Sachs system is a method of classifying acoustic musical instruments which is widely used around the world. It was developed in 1914 by two European musicologists.

Curt - Sachs (1881 - 1959) was a German musicologist known for his extensive study  and  expertise  in  the  history  of  musical  instruments.  Erich  Moritz  Von Hornbostel (1877 - 1935) was an Austrian musicologist.

Their collaboration led to a system of classifiying musical instruments based on how they produce sound.

Western musical instruments can be classified into 5 categories:

- Chordophones
- Membranophones
- Idiophones
- Aerophones
- Electrophones

## Knowledge Plus!

The oldest known scheme of classifying musical instruments is believed to have originated from the Chinese people and may date as far back as the 2 nd  - 3 rd  millennium B. C. Instruments were grouped according to the materials they were made of.

The image is a table with 4 columns and 3 rows. The table is titled "The 8-fold classification was as follows:". The table has a red background and a white background. The table is divided into 4 sections.

### Table Description:

| Column 1: | Chinese Classification of Musical Instruments (Bamboo, Leather, Gourd) |
| --- | --- |
| **Column 2: **Metal** | **Wood** | **Gourd** |
| **Column 3: **Clay** | **Wood** | **Gourd** |
| **Column 4: **Leather** | **Wood** | **Gourd** |

### Analysis:

The table is structured with the following information:

- **Column 1:**
  - **Description:** The table lists the Chinese classification of musical instruments.

- **Column 2:**

<!-- image -->

85

86

## 7.1.1  Chordophones / Tat vadya

Chordophones / tat vadya are stringed instruments that produce sound by the vibration of stretched strings such as animal gut, metal wire and many others.

Chordophones are of 3 types:

- (i) Plucked instruments - The strings are plucked by a plectrum, fingertip, etc.
- (ii) Bowed instruments - The performer draws a bow against the strings in order to make them vibrate.
- (iii) Struck or hammered instruments - The strings are struck with a hammer or a pair of sticks.

In this image, we can see a guitar.

<!-- image -->

In this image, we can see a violin. There is a musical note.

<!-- image -->

In this image, we can see a piano.

<!-- image -->

In plucked and bowed instruments, some of them have frets while others do not. Frets are metal strips which are found along the fingerboard and help the performer to directly locate the position of musical notes.

Two examples of fretted instruments:

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a guitar.

<!-- image -->

Two examples of unfretted instruments:

In this image we can see a violin and a pencil.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

Many chordophones, particularly those in India, also have sympathetic strings along with the playing strings.

Sympathetic strings, also known as the Tarab ke taar-s, are those strings which are not plucked but they vibrate sympathetically with the notes being played by the performer, thus giving additional amplification to the sound produced.

Figure 7.1: Sympathetic strings of the sitar found beneath the upper strings.

In this image we can see a musical instrument.

<!-- image -->

87

88

## Knowledge Plus!

## Saraswati Veena

The veena is about 4 feet in length.

It consists of 7 strings - 4 steel ones for playing and 3 steel sympathetic strings.

The front part of the veena consists of the kudam , the middle part is the daandi and the last part has the yali .

In this image we can see a guitar.

<!-- image -->

The kudam , also known as the large resonator is carved and hollowed from a log of seasoned wood.

The daandi or fingerboard consists of 24 metal frets, which are fixed with the help of a concoction made out of wax and other substances.

At the other end of the wooden fingerboard is the yali . It can be in the form of a dragon or a peacock head.

## Activity 7.1

From the given list, write down  the names  of the following chordophones in the spaces provided:

Santoor, Ukelele, Banjo, Cello, Ektara, Harp

1

<!-- image -->

<!-- image -->

<!-- image -->

3

5

<!-- image -->

<!-- image -->

4

6

<!-- image -->

<!-- image -->

89

90

## 7.1.2  Membranophones / Avanaddha vadya

Membranophones / avanaddha vadya are instruments consisting of hollow bodies of different sizes and shapes. They are made of different materials such as wood, metal or clay.

A membrane, usually made of an animal skin, is stretched and tightened over:

- (i) one side of the hollow body,
- (ii) both sides of the hollow body,
- (iii) or a frame.

In this image there are two drums. One is in white and the other is in brown color.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a few objects.

<!-- image -->

Sound is produced when the stretched membrane is made to vibrate when it is struck either by the hand, a pair of sticks or any other object.

In this image, we can see a person playing a drum.

<!-- image -->

In this image we can see a person holding a stick.

<!-- image -->

The pitch of the sound produced depends upon the:

- (i) nature of the membrane.
- (ii) shape and size of the hollow body of the instrument.

Membranophones can be further classified into 3 categories according to their shapes. These are:

- (i) Tubular drums:

These are instruments having the hollowed body in the form of a tube.

In this image we can see a musical instrument.

<!-- image -->

91

92

- (ii) Kettle drums

These are instruments having a large bowl-shaped body.

In this image there are three musical instruments.

<!-- image -->

- (iii) Frame drums

These are instruments having a frame instead of a hollowed body.

In this image, we can see three musical instruments.

<!-- image -->

## Knowledge Plus!

## Tabla

The tabla is the main percussion instrument in North Indian music. The word tabla is derived from the Arabic word tabl which means a drum.

The tabla consists of a pair of drums; the right hand drum called the daayan or tabla and the left hand drum called the baayan or dagga .

The daayan is conical in shape, having a broader base and is made out of thick wood from a tree trunk.

In this image we can see two drums.

<!-- image -->

The baayan is commonly made of metals such as brass, nickel or copper.

The head of both the daayan and the baayan consists of a stretched animal skin, most preferably the goat skin and it is called the pudi .

A black circular paste, called the syahi , is found on the both pudi-s and it helps in sound production.

93

94

## Activity 7.2

From the given list, write down  the names  of the following membranophones in the spaces provided:

Conga, Mridangam, bongo, Dholak, Djembe, Ravanne

In this image we can see a musical instrument.

<!-- image -->

## 7.1.3  Aerophones / Sushir vadya

Aerophones / sushir vadya are instruments that produce sound by the vibration of air enclosed inside. Air is blown inside these wind instruments either:

- (i) by a mechanical device such as the bellows or,
- (ii) by the breath of the performer.

In this image we can see a musical instrument.

<!-- image -->

In this image we can see a musical instrument.

<!-- image -->

In this image, we can see a musical instrument.

<!-- image -->

In wind instruments, the shape of the resonator within which the air vibrates is responsible for their unique timbre.

95

96

If the resonator enclosing the air is tubular in shape, the length of the vibrating column of air determines the pitch. In such instruments, the vibrating length of the air column can be changed by means of:

- (i) fingered or keyed holes
- (ii) valves that open and close
- (iii) a sliding tube.

In this image we can see a person holding a flute.

<!-- image -->

In this image we can see a person holding a musical instrument.

<!-- image -->

In this image, we can see a person's hand holding a musical instrument.

<!-- image -->

In this image we can see a person playing a musical instrument.

<!-- image -->

In this image we can see a person playing a piano.

<!-- image -->

## Knowledge Plus!

## Harmonium

The harmonium belongs to the aerophone category of musical instruments.

It is the most commonly used instrument in North India and it has been brought from the West.

One hand of the harmonium player is used to pump air inside the instrument using the external bellows.

In this image we can see a musical instrument.

<!-- image -->

The other hand of the player is used to press the desired keys.

The free vibration of the metal reeds inside the instrument are responsible for the sound production.

The higher is the pressure of the pumped air inside, the louder is the sound.

97

98

## Activity 7.3

From the given list, write down the names of the following aerophones in the spaces provided:

Recorder, Pan flute, Saxophone, Bansuri, Mouth organ, Bagpipe

1

2

<!-- image -->

<!-- image -->

3

5

<!-- image -->

<!-- image -->

4

6

<!-- image -->

<!-- image -->

## 7.1.4  Idiophones / Ghana vadya

Idiophones / ghana vadya are instruments that produce sound when the body itself is made to vibrate. Idiophones are made from naturally sonorous materials,  that  is,  they  are  capable  of producing a deep and resonating sound.

The pitch of the sound produced by the vibration of the body is already set at the time  of  its  manufacture  and  cannot  be changed by the performer.

In this image we can see a poster with some text and a logo.

<!-- image -->

Some examples of materials used in the making of idiophones are:

## (i) Metal

In this image there are three things.

<!-- image -->

## (ii) Wood

In this image, we can see a musical instrument. We can also see some objects.

<!-- image -->

99

100

(iii) Clay

In this image we can see a flower pot.

<!-- image -->

There are various ways in which sound is produced in idiophones. Some of the most common ways are when these instruments are:

## (i) Struck

<!-- image -->

## (ii) Shaken

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## (iii) Scraped

<!-- image -->

Cabasa

## Knowledge Plus!

The nattuvangam belongs to the idiophone category of musical instruments.

The metal piece which is held in the right hand is made of brass and the one in the left hand is made of cast iron.

<!-- image -->

## Nattuvangam

It is the main accompanying instrument in Indian classical dances such as the Bharata Natyam or Kuchipudi.

<!-- image -->

Different sounds forming a rhythmic pattern are produced when these two metal pieces are struck together at different angles.

Nattuvangam consists of two metal pieces, with a thick thread made of cotton tied to them separately.

The person who plays the nattuvangam is called the nattuvanaar.

101

102

## Activity 7.4

From the given list, write down the names of the following idiophones in the spaces provided:

In this image we can see some objects.

<!-- image -->

## 7.1.5  Electrophones

Musical instruments grouped under the electrophone category produce sound when the electrical signals produced are converted to sound by the use of mixers, amplifiers and loudspeakers.

In this image we can see a guitar and a speaker.

<!-- image -->

Such instruments can be operated on AC mains and batteries and are easily portable due to their compact size.

In this image we can see a keyboard and a charger.

<!-- image -->

Due to the hard resistant material from which they are made, these instruments are  capable  of  sustaining  shocks  and  are  not  affected  by  temperature  and humidity.

103

104

## Knowledge Plus!

## Electronic Tanpura

<!-- image -->

## Electronic Taalmala

- It is an electronic version of the traditional tanpura.
- It simulates the plucked sound of the tanpura.
- It is equipped with knobs which can be used to adjust the pitch, tempo and volume.
- It is an electronic version of the tabla.
- It simulates the bol-s and provides the basic theka of many taal-s .
- It is equipped with knobs which can be used to adjust the pitch, tempo and volume.

<!-- image -->

In this image we can see a white circle and a red color banner. In the banner we can see some text.

<!-- image -->

## ASSESSMENT

## 1. Fill in the blanks with the appropriate words:

- The violin is an example of a bowing instrument which is grouped under the \_\_\_\_\_\_\_\_\_\_\_\_\_ category. i.
- \_\_\_\_\_\_\_\_\_\_\_\_\_ are those instruments that produce sound when the membrane covering the hollow body is struck by the hands, sticks or any other object. ii.
- Musical instruments that produce sound when air is blown inside are grouped under the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ category. iii.
- Musical instruments such as the triangle and cymbals are classified under the \_\_\_\_\_\_\_\_\_\_\_\_\_ category. iv.
- Musical instruments that use electronic circuits or electrical amplification are grouped under the \_\_\_\_\_\_\_\_\_\_\_\_\_\_ category. v.

## 2. List down any 5 musical instruments for each of the following categories:

| Chordophones                        | Membranophones                      | Aerophones                          |
|-------------------------------------|-------------------------------------|-------------------------------------|
| 1) ................................ | 1) ................................ | 1) ................................ |
| 2) ................................ | 2) ................................ | 2) ................................ |
| 3) ................................ | 3) ................................ | 3) ................................ |
| 4) ................................ | 4) ................................ | 4) ................................ |
| 5) ................................ | 5) ................................ | 5) ................................ |

105

106

ASSESSMENT

## Idiophones

1) ................................

2) ................................

3) ................................

4) ................................

5) ................................

## Electrophones

1) ................................

2) ................................

3) ................................

4) ................................

5) ................................

## 3. Write a short paragraph on 'Classification of musical instruments'.

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

....................................................................................................................

## 4. Project Work

Design a poster presentation on 'Classification of musical instruments'. Search for pictures of musical instruments (internet, books, and magazines) and classify them into the 5 categories.

In this image we can see a collage of different people.

<!-- image -->

## Learning Objectives

At the end of this chapter, learners should be able to:

-  Discuss the contributions of the following musicologists and musicians: Pandit V. N. Bhatkhande, Pandit V. D. Paluskar, Pandit Ravi Shankar and Ustad Vilayat Khan.
-  Sketch, in summary, the life history of the above-mentioned musicologists and musicians.

108

8.1

## Pandit V. N Bhatkhande

## · Birth and Childhood

Pandit Vishnu Narayan Bhatkhande was born in a Chitpavan Brahmin family in Walukeshwar, in Bombay, on 10 August 1860. Inspired by the nursery songs of his mother, he started singing as a child. He won many prizes at school for poem recitation and singing.  While not a professional musician himself, his father, who worked for an affluent businessman, ensured that Vishnu and his siblings received an education in classical music. At the age of fifteen, Vishnu started learning sitar and subsequently began studying Sanskrit texts that dealt with music theory.

## · Studies and Career

In  1887, Pandit V.  N.  Bhatkhande    graduated  with  a  degree  in  law  from Bombay University and started his professional career as a lawyer in criminal law.

In this image I can see a man wearing a cap.

<!-- image -->

<!-- image -->

## Did You Know?

Pandit V.  N  Bhatkhande had practised law for a few years  and  earned  enough  to  support  himself  for  the rest  of  his  life.  Later,  he  gave  up  his  profession  to devote  himself  completely  to  the  cause  of  music. During his law career, he never lost any case.

He was also a member of the Gayan Uttejak Mandali, where he studied Indian music. He learned a variety of compositions in both khayal and dhrupad forms from musicians such as Shri Raojibua Belbagkar and Ustad Ali Hussain. Music was something of a leisurely pursuit for him until 1900 when his wife died, followed by the death of his daughter in 1903. He then abandoned his law practice and devoted himself to music.

## · Contributions in the field of Indian classical music

Pandit V. N. Bhatkhande wrote the first modern treatise on Hindustani classical music, an art which had been propagated earlier mostly through oral traditions. With Pandit Bhatkhande's  efforts,  Indian  classical  music  (both  theory  and practical) became well organized. He established the thaat system which was used to classify the North Indian raag-s .

Pandit Bhatkhande developed the Indian notation system for writing music. He obtained ancient hereditary compositions from families of musicians ( gharana-s ) and published them in six volumes of ' Kramik Pustak Maalikaa '. He always travelled tirelessly in the hunt for ancient books.

He organized music conferences in many cities across India. Through these conferences, he brought artists and music scholars from various traditions and gharana-s on the same platform, where they exchanged their opinions and discussed  music  theories.These  conferences  helped  in  propagating  Indian music.

The first conference was held in Baroda in 1916, and a proposal was brought  forward  to  establish  the  'All India Music Academy'.

He established music colleges in many places and started organized or institutionalized programs for studying music.  In  Lucknow,  he  established the  'Mairis  Music  College',  which  is now called 'Bhatkhande University of Music'.

In this image we can see a logo and text.

<!-- image -->

109

110

Pandit Bhatkhande published 4 volumes of ' Bharatiya Sangeet Paddhati ' in the Marathi language.  These books contain a valuable collection of well researched and complicated topics in music. He also wrote a Sanskrit book called the ' Lakshya  Sangeetam '.  In  many  world  class  universities,  his  book ' Kramik Pustak Maalikaa ' has been adopted as a standard text book.

## · Death

He passed away on 19 th  September 1936.

<!-- image -->

## Pandit Vishnu Digambar Paluskar

## · Birth and childhood

Pandit Vishnu  Digambar  Paluskar  was  born  on  18 th  August 1872 in a town called  Kurundwad  in  the  Maharashtra  state,  in  India.  His  father,  Digambar Gopal Paluskar, was a kirtan singer.

In this image we can see a person with a beard.

<!-- image -->

<!-- image -->

## Did You Know?

Vishnu Digambar Paluskar's original surname was Gadgil but as his family hailed from the village Palus (near Sangli), the members came to be known as the "Paluskar" family.

He went to a local school in Kurundwad and was a brilliant student. The king of Miraj  recognising  the  talent  in  the  boy  put  him  under  the  guidance  of Balakrishnabuwa Ichalkaranjikar, a learned musician. Paluskar gained rigorous training under him for 12 years.

## · Contributions in the field of Indian classical music

With the aim of uplifting classical music in the society, Pandit V. D. Paluskar began touring the country and studied the musical traditions in each part of Northern India. He went from place to place and visited many royal families in cities like Baroda and Gwalior, well known for their patronage of musicians. He became a very successful vocalist and gave concerts in many places.

Figure 8.1: Indian stamp bearing the portrait of Pandit V. D. Paluskar

In this image I can see a painting of a man. In the background I can see the text.

<!-- image -->

Pandit V. D. Paluskar met Pandit Chandan Chaube and learnt Dhrupad music from him. In 1901, he reached Lahore, where he decided to establish a music school.

111

112

In 1901, he established the Gandharva Mahaavidyaalaya , a school to impart formal training in Indian classical music. This school was open to all and ran on public support and donations, rather than royal patronage. He not only taught music (vocal, instrumental and dance) to his students, but he also taught them to live disciplined and become responsible citizens.

He worked hard at becoming a good orator and made sure his students were good artists as well as good orators. He awakened patriotic feelings in children and aroused the passion for music in ordinary citizens. The art of classical music that was confined to courts of kings, was made popular in the society through public concerts, conferences and ceremonies.

Pandit V.  D.  Paluskar  gained  much  popularity  and  many  young  disciples gathered around him. Soon after, more such music academies were launched in cities like Mumbai, Nagpur and Pune. Many students from the school's early batches became respected musicians and teachers in North India.

Pandit V. D. Paluskar created the ' Swaralipi ' (script of writing music), opened  a  printing  press  for  publishing books for music and set up a factory for manufacturing musical instruments. While bringing honor to music and musicians, he also worked in many other related fields.

He  organized music conferences. In these  conferences,  famous  musicians discussed music theories during the day and performed live music at night.

In this image we can see a poster with some text and a picture of a speaker.

<!-- image -->

Along with the magazine ' Sangeetaamrut Pravaah ' (Flow of music nectar), he edited  and  published  over  60  books  such  as: 'Sangeet  Baal  Prakaash', 'Baalbodh', 'Raag Pravesh', 'Mahilaa Sangeet' .

## · Death

Pandit V. D. Paluskar passed away on 21 st  August 1931, at the age of 59.

8.3

## Pandit Ravi Shankar

## · Birth and childhood

Pandit Ravi Shankar was born on 7 th  April 1920 in a Bengali family, in Varanasi, India. His birth name was Robindro Shankar Chowdhury. He moved to Paris in 1930  and  received  most  of  his  education  there.  From  the  age  of  12,  he performed as a musician and dancer on tours in Europe and America with his brother Uday Shankar's dance troupe.

Pandit Ravi  Shankar  gave  up  his  dancing career in 1938 to go to Maihar and study Indian classical  music  as Baba Allauddin  Khan's pupil.  He  lived  with Baba Allauddin  Khan's family in the traditional gurukul system known as the Maihar gharana .

Baba Allauddin  Khan was  a  rigorous  teacher and Pandit R . Shankar had training on both the sitar and surbahar. He learned raag-s and the musical styles of dhrupad, dhamaar and khayal . He was taught the playing techniques of instruments such as the rudra veena, rabab and  sursingar.  He  often  studied  with Baba Allauddin  Khan's  children, Ali Akbar  Khan  and Annapurna Devi.

Figure 8.2: Ravi Shankar and his brother Uday Shankar

In this image we can see a group of people.

<!-- image -->

## · Contributions and achievements in the field of Indian classical music

By 1945 , Pandit Ravi Shankar was known as a leading performing artist. He also started composing music for ballets and films.

113

114

In this image we can see a man playing guitar.

<!-- image -->

Pandit R. Shankar developed a style of sitar playing distinct from that of his contemporaries and incorporated influences from rhythm practices of Carnatic music. His performances begun with alaap,  jor  alaap and jor jhala influenced by the slow and serious dhrupad genre and was followed by gat-s , fast speed taan-s and the jhala .

Pandit Ravi Shankar often ended his performances  with  a  piece  inspired by the light-classical thumri genre.

In 1949, he became the Music Director  of All-India  Radio  in  Delhi, and founded the Vadya Vrinda Chamber Orchestra.

For  his  outstanding  contributions  to Indian music and culture, he received his first Presidential Award in 1962, India's highest honor in the arts.

In this image I can see a poster. On the poster I can see a person and a musical instrument.

<!-- image -->

George Harrison, the guitar player of the famous band 'The Beatles' developed a  deep  interest  in Hindustani music,  and  began  to  learn  playing  sitar  with Pandit Ravi Shankar. The introduction of the sitar in 'The Beatles' band gave rise to a new genre of music, thus giving Pandit R. Shankar and Indian music great popularity in the West.

Figure 8.3: Pandit Ravi Shankar and George Harrison

In this image we can see a person holding a guitar.

<!-- image -->

Pandit Ravi  Shankar's  long  and  distinguished  musical  career  included numerous recordings,  performances  all  around  the  world's  leading  venues, and a series of unprecedented collaborations with other leading musicians.

In this image we can see a trophy, a cup and a ribbon.

<!-- image -->

## · Death

Pandit Ravi Shankar passed away on 11 th  December 2012 at the age of 92 in California, USA.

116

## Knowledge Plus!

## Anoushka Shankar, the daughter of Pandit Ravi Shankar

In this image we can see a person sitting and playing a guitar. In the background there is a door.

<!-- image -->

Anoushka Shankar was born on the 9 th  June 1981 in London. At the age of 9, Anoushka began her training on the sitar with her father, Pandit Ravi Shankar. By the age of 13, she started giving public performances.

Today,  she  is  a  world-renowned  sitar  player  and  composer.  She  has been  honored  for  her  musical  journey  with  the  Grammy  Awards and many others.

In this image we can see a woman playing a guitar. In the background there are people.

<!-- image -->

8.4

## Ustad Vilayat Khan

## · Birth and childhood

Ustad Vilayat Khan was born in Gouripur in East Bengal (later known as Bangladesh) in August 1922. His grandfather, Ustad Imdad Khan and his father Ustad Enayat Khan were famous musicians and Ustad Vilayat Khan and his younger brother, Imrat Khan, gained musical knowledge under their guidance.  Their gharana is  known  as the Imdadkhani gharana, named  after their grandfather.

Ustad Vilayat Khan initially studied with his father. On his father's death in 1938, his training became the responsibility of his mother, Bashiran Begum, his grandmother, Bande Hussain Khan, and his maternal uncle, Wahid Khan.

In this image we can see a person playing a musical instrument.

<!-- image -->

Young  Vilayat  Khan's  first  public  performance  was  at  All  Bengal  Music Conference in Kolkata in 1936.

## · Contributions and achievements in the field of Indian classical music

Ustad Vilayat  Khan  worked  closely  with  instrument  makers,  especially  the famous sitar-makers Kanailal and Hiren Roy, to further develop the sitar.

Some of the changes he brought to the sitar are:

- Removal of the kharaj - Laraj strings
- Removal of the tumbi , amongst others.

117

118

In this image we can see a person sitting and playing a musical instrument. There are two microphones.

<!-- image -->

Following  the  tradition  of  his gharana , Ustad Vilayat Khan further developed the vocal  style,  known  as  the gayaki ang ,  in sitar playing which made the sound of the sitar  resemble  the  human  voice.  This made the audience feel as if his instrument was singing.

He also devised his own tuning method for a  better  and  distinct  sound  quality  by changing and re-arranging the strings.

Ustad Vilayat Khan participated in various prestigious music festivals worldwide. He has also recorded a large number of discs and cassettes in India and abroad. He has also composed music for many films.

In this image we can see a poster with some text and a picture of a person.

<!-- image -->

Figure 8.4: Ustad Vilayat Khan in concert with Ustad Bismillah khan

In this image we can see a group of people sitting and playing musical instruments.

<!-- image -->

He was the only sitarist who received the title 'Bharat Sitar Samrat' (Emperor of Sitar) and 'Aftab-E-Sitar' (Sun of the Sitar).

## · Death

Ustad Vilayat Khan passed away in Mumbai on 13 th  March 2004, at the age of 75.

In this image, we can see a circle and text.

<!-- image -->

120

Chapter 8 Musicians and Musicologists

ASSESSMENT

## Project Work

-  Arrange yourselves in groups of 3.
-  Make a poster presentation in front of the class on any one of the musicologists and any one of the musicians listed below:

Musicologists:

Pandit Vishnu Narayan Bhatkhande Pandit Vishnu Digambar Paluskar

Musicians:

Pandit Ravi Shankar Ustad Vilayat Khan

Chapter 9 Music prevalent in Mauritius and other cultures

In this image, we can see a collage of pictures.

<!-- image -->

## Learning Objectives

## At the end of this chapter, learners should be able to:

-  Identify and list the types of music in the different communities of Mauritius.
-  List the musical instruments used in the musical performances of the different communities of Mauritius.
-  Describe the role and importance of music in the different communities of the Mauritian society.
-  Relate the music of the different communities to specific occasions, ceremonies or festivals in Mauritius.
-  Demonstrate understanding of their and others' culture values and attitudes through different forms of cultural expression.
-  Distinguish between the musical styles of various cultures of the world.
-  Demonstrate respect for the music of diverse cultural groups of Mauritius and the world at large.

122

<!-- image -->

## Tamil community in India

The  Tamil  community,  also  known  as  the  Dravidian  people  of  the  Indian subcontinent, have a recorded history going back to more than two millennia. The  oldest  Tamil  communities  live  in  Southern  India  and  North-Eastern  Sri Lanka.

The art and architecture of the Tamil people contribute to the heritage of India and the world at large.

The traditional Tamil performing arts have ancient roots. The royal courts and temples have been centers for the performing arts since the classical period, and possibly earlier. Descriptions of performances in classical Tamil literature and the Natyashastra indicate a close relationship between the ancient and modern art forms.

The Tamil community shares a classical music form and tradition called the Carnatic music with the rest of South India, primarily oriented towards vocal music with instruments functioning either as accompaniment or as imitations of the singer's role. Carnatic music is centered around the raagam (melody) and taalam ( rhythm).

Unlike the Hindustani music tradition, Carnatic music  has  an almost exclusively religious gravity.

Today, the Tamil emigrant communities are scattered around the world, especially in Sri Lanka, Malaysia, South Africa, Singapore, Mauritius with more recent emigrants  found  in  New  Zealand, Australia, Canada, the United States, and Europe.

Figure 9.1: Architectural designs of the temples in Tamil Nadu state in India

In this image we can see a temple. In the background there is a sky with clouds.

<!-- image -->

## Tamil community in Mauritius

The style of Indian classical music brought  from  South  India  and  mostly practised by the Tamil-speaking community  is  the Carnatic music.  It  is primarily  oriented  towards  vocal  music and  is  based  on raagam (melody)  and taalam (rhythm).

<!-- image -->

## Did You Know?

Musical instruments that usually accompany a Carnatic singer in a musical performance are the mridangam, veena, ghatam, khanjira and so on.

The Tamil-speaking community are  also  known  as  Dravidians  as the  Southern  region  of  India  was named Dravida. They were brought to Mauritius as indentured labourers  from  southern  regions like Trichinopoly, Madurai, Tanjore, Kerala amongst others.

Figure 9.2: Famous vocalist M. S. Subbulakshmi in concert

In this image we can see a group of people sitting on the floor. There are some musical instruments.

<!-- image -->

Music and dance form part of the rituals and ceremonies. Devotional songs are sung  in Carnatic style  by  devotees  during  religious  functions.  Musical instruments such as the thavil and nadaswaram are played during prayers in kovils, and musicians playing the tappu and drums lead processions during the Cavadee festival.

123

124

Figure 9.3: Singer and musicians accompanying a bharata natyam performance

In this image we can see a group of people sitting on the chairs and playing musical instruments. In the background there is a curtain.

<!-- image -->

The bharata natyam is the dominant classical dance form, originating from South India. The dance form constitutes the exposition of the story contained in a song, usually performed by one performer on stage with an orchestra of drums, a tanpura, and  one  or  more  singers  backstage.  The  dancers  relate  the  story  through  a combination of mudra-s (hand gestures), facial expressions, and body postures.

In this image we can see a group of women standing and dancing.

<!-- image -->

Figure 9.4: A group of bharata natyam dancers

<!-- image -->

## Did You Know?

In 1960, the Government of Tamil Nadu  held  a  World  Conference and meet periodically since then. In 1999, Tamil representatives established a World Tamil Confederation to protect and foster  Tamil  Culture  and  bring  a sense of unity among Tamil ians residing in various countries of the world.

Some examples of folk dance forms practised during religious processions and festivals are:

- (i) Kolatam - also known as the 'stick dance'.
- (ii) Kummi-attam - performed during Pongal, the harvest festival.

In this image we can see a group of people standing and holding sticks.

<!-- image -->

In this image we can see a group of women dancing. In the background there are trees.

<!-- image -->

125

126

9.2

## Telugu community

## Early settlement of the Telugu community in Mauritius

Although Sanskrit writings dated to about 1000 B.C contain references of people called Andhra-s  living  in  the  South  of  the  central Indian mountain  range,  definitive historical evidence of the Andhra-s dates from the time of the Mauryan dynasty in India.

The Telugu-s came to Mauritius in the 19 th century  from  the  Southern  part  of  India, particularly from the following regions such as Badraathalam, Kaakinaasa, Chittoor, Simhaachalam and Vishakapatnam.

In this image we can see a poster with some text and images.

<!-- image -->

Together with other Indians belonging to different ethnic groups, the Telugu community came to work as indentured  labourers. They  came  to  Mauritius along  with  their  valuable  scriptures.  They  tried  their  best  to  preserve  their culture, language and religion.  They transmitted their culture to their descendants, thus maintaining their identity as Telugu-s.

Figure 9.5: The State of Andhra Pradesh, India

In this image we can see a map. On the map there is a name of a place.

<!-- image -->

In those days, the Telugu community would meet in the evenings after a hard day's work in a modest thatched hut, which they built as their temple or place of worship.  Hence, they would preach and explain the texts of Holy scriptures and discuss matters related to their religion and culture.

## Telugu culture in Mauritius

Andhra Pradesh, a state of Southern India, has always been known for its musical and dance heritage.  The land has given birth to three legends in the world of Carnatic music  namely  Shyam  Sastri,  Swami  Tyagaraja  and Muthuswami Dixtar. Some of the famous Carnatic music composers include Kshetraya Annamacharya and Bhadrachala Ramdasa.

In Mauritius, regular evening bhajan and kirtan sessions are held in temples where devotees sing devotional songs in the praise of Lord Venkateshwara or Ramadasu. During the Ram bhajanam ceremony, devotees sing bhajan-s in the  praise  of  Lord  Ram  and  they  perform  dance  movements  around  a  tall decorated lamp.

Figure 9.6: Devotees singing and dancing around a tall lighted lamp

In this image we can see a group of people standing and some are holding candles. In the background there is a wall and some objects.

<!-- image -->

127

A state which does not have dance as part of its culture can never be regarded as a culturally rich state. The Kuchipudi dance, a classical Indian dance form originating from Andhra Pradesh, is also performed during religious gatherings and festivals in the Telugu community.

Figure 9.7: Kuchipudi dancers on stage

In this image we can see two persons dancing. The background is dark.

<!-- image -->

Some  of  the  festivals  which  are  celebrated  by  the  Telugu  community  are Ugaadi,  Rambhajanam, Andhra  Day,  Swami  Tyagaraja's  birthday,  amongst others and special cultural programs are organized.

Figure 9.8: Muggulu, a tradition where people decorate entrances with white rice powder

In this image we can see a person's hand and a painting on the wooden surface.

<!-- image -->

9.3

Marathi community

## Origin of the Maratha settlement in India

In  India,  the  origin  of  the  Marathi-community  dates  back  to  more  than  two millennia.  The existence of this community in the state of Maharashtra became prominent only during the reign of Shivaji Bhonsle, an Indian warrior King, who established the Maratha Empire in 1674.  The Maharashtrians occupy the state of Maharashtra which is in the western region of India.

The  Maharashtrians  speak  the  Marathi  language  which  is  a  part  of  the southern group of Indo-Aryan languages.  It was during the 20 th  century that people belonging to the peasant community, who were described as kumbi, started being called as the Maratha.

Figure 9.9: The state of Maharashtra, India

In this image there is a map of the country.

<!-- image -->

129

130

Some of the most popular folk dances from Maharashtra are:

Lavani -  The  word Lavani is  derived  from  the  word  ' lavanya '  which  means beauty.  It  is  performed  by  a  group  of  women  and  accompanied  by  musical instruments such as dholak, jhaal and so on.

In this image we can see a group of people standing on the floor. In the background we can see a screen.

<!-- image -->

Koli - The koli dance has originated from the fishermen community.

In this image we can see a group of people dancing on the floor.

<!-- image -->

Powada -Powada is  a  dance  form  which  revolves  around  the  incidents surrounding the life of the great Chhatrapati Shivaji Maharaj.

In this image we can see a group of people standing on the floor. In the background we can see a wall and a sculpture.

<!-- image -->

## Marathi culture in Mauritius

In the Marathi community, music and dance form part of the religious festivals, rituals and other celebrations. Bhajan-s are sung by skilled groups of singers called bhajanik during satsangs , rituals and  festivals. During  wedding ceremonies, songs and dances are performed by the gamatia-s .

An  example  of  a  traditional  song which forms part of their daily activities is the 'sante janta' which is sung by women while grinding corn.

<!-- image -->

## Did You Know?

One of their most popular dances is the Jakri . It is a folk dance traditionally performed during the Ganesh Chaturthi  festival.  The  participants, both men  and women,  sing and dance  around  a  dholak  player  and musicians  who  play  instruments  like the jhaal and chimta .  Women  wear kashti-s while  men  wear kurta-s on that occasion.

The Marathi-speaking community are referred to as the 'Bombaye'  people  because  the port from which they were embarked was in Bombay, today known as Mumbai.  They   came to Mauritius from different regions  of  Maharashtra  such  as Konkan, Ratnagiri and others.

Figure 9.10: Devotees of the Marathi community performing the jakri

In this image we can see a group of people dancing on the floor. In the background there is a wall and a roof.

<!-- image -->

131

132

<!-- image -->

## History of the Gujarati settlement in India

It is believed that the earliest settlement in Gujarat began with the Stone Age, in the valleys of the Sabarmati and Mahi rivers in the eastern part of the state. After the fall of the Gupta Empire in the 6 th  century, Gujarat flourished as an independent Hindu / Buddhist state.

Figure 9.11: The state of Gujarat, India

In this image there is a map of India.

<!-- image -->

## Early settlement of the Gujarati community in Mauritius

During the British and German rule, Indian indentured labourers were brought to construct the East African railways in the 1890's.  Gujarati traders followed those Indian workers to East and South Africa, Zimbabwe as well as Mauritius where they established themselves in business as retail and wholesale merchants.

The Gujarati-s came to Mauritius from regions like Kutch, found in the state of Gujarat in India. Their primary business was the trade of clothes, rice, jewels and they later diversified. They were well-known for their trading skills.

## Gujarati culture in Mauritius

The folklore and folk arts form a major part of the culture of the Gujarati-s.  Most of the art traditions and cultural heritage of the Gujarati-s can be traced back to the ancient period of Lord Krishna.

Two popular folk dances practised by the Gujarati community are the Garba and Dandiya .

Garba is a popular folk dance which is performed during the Navratri festival in honor of Goddess Durga. In this dance form, women sing garba songs in praise of Goddess Durga and perform specific dance movements in circular patterns.

Figure 9.12: Garba dancers

In this image we can see a group of people dancing. There are lights and some objects.

<!-- image -->

Dandiya is  another folk dance form performed during the Navratri festival in honor of Goddess Durga. The performers, both men and women, make the use a pair of colorfully decorated sticks in their dance movements.

Figure 9.13: Dandiya dancers

In this image we can see a group of people standing and holding sticks in their hands.

<!-- image -->

134

<!-- image -->

## Muslim community

## Early settlement of the Muslim community in Mauritius

The Muslims in Mauritius are mostly of Indian descent. The presence of the first Muslims dates back to the early days of the French colonization. In 1735, the  famous  Governor  Mahé  de  Labourdonnais  brought  a  group  of  skilled tradesmen from India to work as artisans and seamen in the dockyard and harbour in Port Louis. During the period of colonisation of the island by the British (1810-1968), large numbers of Muslims arrived in Mauritius as part of the large scale indentured labour force brought from India.

## Popular musical genres in the Muslim community

Some of the popular musical genres practised by the Muslim community in Mauritius are:

## (i) Naat

Naat consists of poetry recited in the praise of the Prophet Muhammad. The subject  matter  of naat can  be  anything  related  to  the  Prophet  Muhammad such as his personality, his qualities, his teachings, his life and so on. It is recited on religious occasions and festivals.

Naat is traditionally recited without any instrumental accompaniment.

Figure 9.14: A naat performer

In this image we can see a man wearing a hat and holding a mic.

<!-- image -->

## (ii) Ghazal

Ghazal is  a  light  classical  form  of  singing which consists of rhyming couplets written in the Urdu or Persian language. Some of the common themes of ghazals are spirituality, love, pain and lovers' separation.

Usually performed during musical evenings called mehfil-s ,  musical  instruments  which are usually used in as accompaniment in a ghazal performance are the tabla, harmonium, sitar, violin and others.

Figure 9.15: Mehdi Hassan, the King of Ghazal

In this image we can see a man is playing a piano. In the background there is a building.

<!-- image -->

## (iii) Qawwali

Derived from the Arabic word qual , qawwali is a form of devotional song based on Sufi music. A typical qawwali group consists of male singers only, having a lead singer, one or two side singers and a chorus of five or more singers who repeat  the  main  verses  and  provide  side  rhythm  by  clapping  their  hands. Musical  instruments  usually  used  during  a qawwali performance  are  the harmonium, tabla, dholak and others.

Figure 9.16: Ustad Nusrat Fateh Ali Khan, a famous qawwali singer

In this image we can see a person standing and holding a musical instrument. There are other musical instruments and a person playing a musical instrument. There are lights in the background.

<!-- image -->

The common themes of a qawwali are the praise of Sufi saints and martyrs as well as that of the Prophet. The lyrics and the rhythm are very important in qawwali singing. Starting at a slow pace, the rhythm becomes faster and more intense towards the end.

135

136

9.6

## Musical instruments used in folk music of Mauritius

<!-- image -->

<!-- image -->

<!-- image -->

| Sega      | Sega                                                                                                                                                                                   |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Ravanne   | The traditional ravanne consists of a wooden frame with an animal skin, preferably the goat skin, stretched over it. Nowadays, the ravanne made of synthetic material is also used.    |
| Maravanne | It is a rectangular-shaped box made from the stem of sugarcane flowers, with dried seeds inside. Sound is produced by the movement of the seeds inside when it is shaken horizontally. |
| Triangle  | It consists of a steel or iron rod bent to the shape of a triangle with an opening at one end. Another steel or iron rod is hit against it to produce sound.                           |

<!-- image -->

<!-- image -->

<!-- image -->

| Bhojpuri folk songs       | Bhojpuri folk songs                                                                                                                                                                                       |
|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Dholak                    | The traditional dholak consists of a cylindrical wooden drum, with the middle portion slightly larger than its both ends. Animal skin is tightly stretched over the two ends using ropes and metal rings. |
| Lota and Chammach (spoon) | The lota is a container made of copper or brass. Sound is produced when a pair of spoons is hit against the rim of the lota .                                                                             |
| Wooden block              | Two pieces of wooden blocks are hit against each other to provide side rhythm.                                                                                                                            |

137

138

<!-- image -->

## Music in various cultures of the world

## 9.7.1  Arabian Music

Arabian  music  refers  to  the  music  of  the Arab  world. There  are  twenty-two countries which constitute the Arab world and each country has its own dialect and style of music. Arabian music has also been influenced by interaction with other regional music styles and genres.

<!-- image -->

Figure 9.17: Musical styles in some of the Arabian countries

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## History

Historians agree that the origin of Arabian music dates back to the 5 th  and 7 th centuries A.D. In those time, Arabian music consisted of poem recitation in high pitch.  Later,  music  also  was  included.  Hence,  the  recitations  were  done  by poets and the singing part was entrusted to women with beautiful voices who would also learn to play musical instruments. The compositions were simple and every singer would sing in a single maqam (melodic scale). The maqam is the base of compositions and improvisation in Arabian music. The maqam can be  realized  with  either  vocal  or  instrumental  music  and  does  not  include  a rhythmic component.

Some of the popular songs of that period were the Huda, nasb, sanad and rukbani .

## Famous authors in Arabian Music

Some of the famous authors who have written on Arabian music are:

-  Al-Kindi (801-873 A.D)

He was a notable early theorist of Arabian  music  and  wrote  several books on musical theory.

<!-- image -->

-  Abu Al-Faraj (897-957)

He wrote the Kitab Al-Aghani ,  an encyclopedic  collection  of  poems and  songs  that  runs  to  over  20 volumes in the modern edition.

Figure 9.18: An illustration of the book Kitab Al-Aghani

<!-- image -->

139

140

Chapter 9 Music prevalent in Mauritius and other cultures

-  Al-Farabi (872-950)

He wrote a book on music entitled Kitab al-Musiqi-Al-Kabir (The  Great  Book  of Music). His pure Arabian tone system is still used in Arabian music.

-  Al-Ghazali (1059-1111)

He wrote a treatise  on  music  in  Persia which  stated  'Ecstasy  means  the  state that comes from listening to music'.

-  Safi-al Din

In 1252, he developed a unique form of music  notation  in  which  rhythms  were represented by geometric representation.

In this image we can see a person wearing a turban.

<!-- image -->

<!-- image -->

In this image we can see a person holding a musical instrument.

<!-- image -->

In  the  20 th   century,  Egypt  was  the  first among Arabian countries to experience a sudden  emergence  of  nationalism,  as  it became independent after 2000 years of foreign rule. French and Turkish songs got replaced by National Egyptian Music. Cairo became a center for musical innovation.

<!-- image -->

## Did You Know?

The Belly dance, also known as the Arabian dance, has its roots  in  Egypt.  It  may  have originated in the Pre-Islamic era, as shown by proofs found from 200 BCE.

During  the  1950's  and  1960's,  Arabian music began to take a more westernised trend by adopting some Western musical instruments to the Egyptian Music.

Figure 9.19: A musical ensemble of Arabian and Western instruments

In this image we can see a person standing.

<!-- image -->

In this image we can see a group of people playing musical instruments.

<!-- image -->

141

142

## Knowledge Plus!

Takht , which means seat or podium in Persian, is a musical ensemble of  the  Middle  Eastern music. This ensemble consists of the musical instruments such as the:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 9.7.2  Western music

Western  music  refers  to  the  music  which  is  produced  and  rooted  to  the traditions of the countries in the Western hemisphere of the globe. It has been developed based on the music of Greeks and Romans.  There are six historical eras in the Western culture which have greatly influenced its music. These are as follows:

In this image we can see a painting.

<!-- image -->

<!-- image -->

3. Baroque era

<!-- image -->

5. Romantic era

<!-- image -->

4. Classical era

<!-- image -->

<!-- image -->

Although the genres, styles and language have changed through the centuries, the five main elements which constitute the foundation of Western music are:

1)  Melody      2)  Harmony      3)  Rhythm      4)  Timbre      5)  Form

143

144

## · Evolution of  the Western Notation system

In  ancient  times,  music  was  not  written  down.  It  was  sung  or  played  from memory. One singer might teach a particular song to others and they in turn would teach it to others. Of course, many changes crept into the tunes in this way. People needed to find a way of writing their music, so that it would be sung  or  played  exactly  as  they  had  composed  it.  The  method  that  they developed for writing music is called notation.

Figure 9.20: The modern staff notation

In this image we can see a musical note written on the paper.

<!-- image -->

Musical  notation,  like  written  language,  is  a  means  of  communication.  It enables the composers to record their music in written symbols. Musicians can read those symbols and bring the composers' ideas to life through sound, thus communicating them to the listeners.

The system of musical notation generally used today in the Western world is the result of centuries of development from about the end of the 9 th  century to the early 1700's.  This development began in the cathedrals and monasteries of  the  Roman  Catholic  Church.  From  early  Christian  times,  many  of  the church's services were sung.

For centuries, this music called the Gregorian chant or plain chant was sung from memory.  But towards the end of the 9 th  century, dots and dashes and little squiggles were written over the words in the service books. These signs, called neumes, helped the singer's memory by showing the direction in which the melody would go.

Guide  d'Arezzo  (990-1050),  a  scholarly  monk,  is  usually  given  credit  for inventing the staff.

Figure 9.21: Guide d'Arezzo

In this image there is a person.

<!-- image -->

The early staff was made of 4 lines.  The neumes were written on the lines, as well as in the spaces between the lines.

Not only was the notification of the exact pitch possible, but also the staff was an aid to the composers in writing new melodies. The ancient chants of the Catholic Church are still written on a four line staff.

A method that shows the duration or length of the notes was developed in the 13 th  and 14 th  centuries. This development included the use of five line staff which was introduced about 1200. Notes took on new shapes and stems were added to some notes according to their length. In the middle 1400's, white notes were being used.

By the 1600's, the square and diamond  shaped  notes  had  become round  and  musical  notation  began  to  take  on  the  general  appearance as it has today.

145

146

## Knowledge Plus!

## Origin of the clef signs

The word 'Clef' which is a French word derived from the Latin word 'Clavis'. The signs are also called keys because they unlock the secret of the staff.

<!-- image -->

The clef signs come from the old gothic letters C, I and G that are placed on certain lines of the staff to indicate the pitch of that line and consequently, the pitch  of  the  remaining  lines  and  spaces.  In  this  way,  performers  are  able locate the pitch of the chants.

In this image, we can see a logo and a circular object.

<!-- image -->

ASSESSMENT

## 1. List down any 3 musical instruments used in:

## 2. Write a short paragraph on:

- (i)  Arabian music

- (ii) Western music

## 3. Project Work

Make a poster presentation on 'Music in the different communities of Mauritius'.

Sega

1) ................................

2) ................................

3) ................................

Bhojpuri folk songs

1) ................................

2) ................................

3) ................................

Arabian music

1) ................................

2) ................................

3) ................................

Western music

1) ................................

2) ................................

3) ................................

147

148

## Glossary of Terms

Affluent

- wealthy

Antara

- second part of a gat / composition

- Ascribed                - attributed

Beenkar

- a been (musical instrument) player

Communion          - oneness

- Dhrupad                - a classical style of vocal form in North Indian music

- Gamak                  - oscillation of swara-s

- Gharana                - a community of performers who share a particular musical style

- Gut                        - fibre from the intestines

- Imdadkhani           - the school of sitar and surbahar playing named after Imdad

gharana                    Khan

- Immigrant              - a person who leaves a country permanently to live in another

one

- Laya                      - the regular flow of matra-s

- Legends                - traditional stories popularly regarded as historical but which are not based on facts

- Maihar gharana     - the school of Hindustani classical music, formed by Baba Allaudin Khan in the state of Maihar

- Manjha                  - part of a gat linking the sthayi to the antara

- Maseetkhani gat   - composition played in slow tempo

- Matra                     - unit interval of time measure

- Meend                   - a continuous glide of the sound from one note to another

- Millennium             - a period of a thousand years, especially when calculated from the traditional date of the

- Musicologists        - experts in the field of musicbirth of Christ

- Mythology             - a collection of myths, especially one belonging to a particular religious or cultural tradition

- Pakad                    - identyfing phrase of a particular raag

- Palanquin              - a one-passenger carrier, consisting of a seat and curtains

- Pandit / Ustad       - title given to a person as a respect for his wisdom / skill

Patronage             - support

- Prahar                   - particular phase of the time

- Permutation          - any of the various ways in which a set of things can be arranged

- Pitch                      - the degree of highness or lowness of a tone

- Precursor              - something that existed before another thing

- Rababiya              -  a rabab (musical instrument) player

- Rasa / mood         - emotions experienced by the humans

- Razakhani gat       - composition played in medium / fast tempo

- Sanskrit                 - an ancient language which used to be spoken in India

- Scale                     - an organized sequence of musical notes

- Scholars                - specialists in a particular branch of study

- Shanta rasa          - the feeling of calmness, quietness and peacefulness

- Shastra-s              - sacred scriptures of Hinduism

- Sthayi                    - first part of a gat / composition

- Swara                    - musical note of a definite pitch

Synchronization    - coordination

- Theka                    - basic syllables (bol-s) combined to form rhythmic phrases

- Themes                 - subject / topic

- Toda / taan            - a melodic phrase played at a faster speed

- Treatise                 - a written work dealing with a particular subject

- Tribal                     - a group of people with similar customs and traditions

- Unprecedented     - something never done or known before

- Vadi swara            - most prominent swara in a raag

- Veda-s                   -  religious texts of Sanskrit literature and the oldest scriptures of Hinduism

- Virtuosity               - great skill in music

- Vivadi swara         - musical note which is omitted in a raag

Vogue                    - trend

- Yogi                       -  a person who is proficient in yoga

149

In this image, we can see a poster with some text and images.

<!-- image -->