## CHEMISTRY GRADE 9

In this image we can see a poster with some text and images.

<!-- image -->

## CHEMISTRY GRADE 9

In this image we can see a collage of different images.

<!-- image -->

i

-Head Curriculum Implementation,Textbook Development and Evaluation

## CHEMISTRY TEXTBOOK DEVELOPMENT PANEL

## MAURITIUS INSTITUTE OF EDUCATION

Dr Sarojiny Saddul-Hauzaree

- Coordinator, Associate Professor, MIE

Vickren Narrainsawmy

- Lecturer, MIE

Ummeh Wazeela Ahsun

- Educator

Ajeshwaree Douquia

- Educator

Kiran Saddul-Ramasamy

- Educator

Design

Kamla Ernest

- Chief Technician, MIE

Leveen Nowbotsing

- Graphic Designer, MIE

Rakesh Sookun

- Graphic Designer, MIE

Acknowledgements

The Science textbook panel wishes to thank:

-   Dr Fawzia Narod (Associate Professor, MIE) for her contribution
- -Helina Hookoomsing (Senior Lecturer, MIE) and Majhegy Murden -Louise (Lecturer, MIE) for proofreading
- -Prakash Roopun (Senior Laboratory Technician, MIE) for taking photos that have been used in the textbook

## GRADE 9 CHEMISTRY TEXTBOOK REVIEW PANEL

Mohun Cyparsade

- Overall Coordinator, Associate Professor, MIE

Vickren Narrainsawmy

- Lecturer, MIE

Ajeshwaree Douquia

- Educator

Dinesh Seetul

- Educator

Design

Vedita Jokhun

- Graphic Designer, MIE

Acknowledgements

The Science textbook panel wishes to thank:

- Prakash Roopun (Senior Laboratory Technician, MIE) for taking photos that have been used in the textbook
- K. Reshma Gungapersand (Lecturer, MIE) for proofreading
- © Mauritius Institute of Education - 2023

ISBN: 978-99949-75-30-3

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

FOREWORD

The MIE produced a set of new textbooks for Grades 1-9 based on the National Curriculum Framework and Teaching and Learning Syllabus for the implementation of the Nine Year Continuous Basic Education (NYCBE) reform. These have been key to curriculum transaction in the classroom. However, curriculum development is a dynamic enterprise that constitutes constant review and readjustment in relation to the evolving contextual factors and needs of Educators and learners. As such the Grade 9 Science textbook was reviewed taking into consideration the insights and views of stakeholders as well the emerging trends in Science Education. Even though dedicated textbooks are now available for each of the Science subjects, namely Biology, Chemistry and Physics, for ease of use, the guiding philosophy has remained unchanged. The content is contextualized, incremental and founded on basic scientific skills developed in Grades 7 and 8.

As in all curriculum endeavours, a number of contributors have been involved in the review of the Grade 9 textbook. I remain appreciative of the efforts of the panel who, at the inception, gave the textbook its orientation. I thank the review team for finetuning the resource in the light of feedback obtained to enhance teaching and learning experiences. The Educators who were part of the validation process have also played an important role in ensuring that the reviewed Science textbooks are sound. Last, but not the least, the Graphic Designers are to be thanked for their continuous collaboration in the development of apt educational resources.

I wish all users of the Science textbooks an enriching and enjoyable experience.

Dr Hemant Bessoondyal Director Mauritius Institute of Education

PREFACE

The Grade 9 science textbook is in compliance with the National Curriculum Framework (NCF, 2017) and the Teaching and Learning Syllabus (TLS, 2017) for science. The textbook ensures a smooth transition from the earlier grades by building upon content learnt up to Grade 8.

The  textbook  is  conceptualised  in  such  a  way  that  it  includes  a  number  of inquiry-based activities and accompanying tasks for learners. In line with the constructivist approach, the activities will enable learners to build and reinforce understanding of science concepts. As such, a conscious effort must be made to  actively  engage  pupils  in  all  activities  and  to  allow  them  to  manipulate specimens,  materials,  simple  equipment  and  apparatus  safely  and  under supervision.

The use of everyday experiences and contexts that students can easily relate to  is  favoured.  Care  is  taken  to  incorporate  learner-centred  strategies  like project-based learning and concept mapping to actively engage the learners in the learning process and to provide for independent learning. Furthermore, whenever  relevant,  applications  of  the  science  concepts  learnt  in  real  life situations are highlighted.

Additionally,  the  activities  seek  to  develop  in  students  the  necessary  skills, attitudes and values for scientific inquiry. Students must be given ample time to actively engage in the activities, communicate their findings and observations in  multiple  ways,  discuss  with  their  friends  and  teachers  and  think  before writing down their answers. Though many questions are incorporated within the  activities,  educators  are  encouraged  to  prompt  learners  with  additional questions while implementing them in the classroom.

The textbook includes important features that support effective assessment. ' Test  yourself '  is  for  formative  purposes  and  are  meant  to  reinforce  and consolidate understanding of the concepts learnt and the inquiry skills that students have developed. At the end of each unit, the questions are scaffolded so that students can apply their knowledge and understanding to solve simple as well as challenging questions.

More  importantly,  for  Grade  9,  the  textbook  seeks  to  provide  relevant  and authentic  assessment  materials  for  the  purpose  of  the  National  Certificate of  Education  (NCE)  assessment  at  the  end  of  the  NYBCE  cycle.  The ' End  of Unit  Exercises '  provides  educators  with  opportunities  to  assess  learners' understanding  of  concepts  addressed  in  the  units  and  to  provide  timely feedback  and  support.  This  section  comprises  a  variety  of  exercises,  such as  fill-in-the-blanks,  matching,  multiple  choice  and  structured  questions, amongst others.  It is recommended to encourage learners to develop higher order thinking skills and to justify their answers as and when appropriate as this promotes critical analysis and deeper conceptual understanding. Using a differentiated approach, educators are expected to develop more assessment exercises or to adapt those provided to assess learners of different abilities.

The ' What  I  have  learnt '  icon  summarises  the  concepts  learnt  through  the inquiry-based activities. The 'Find out' icon aims at encouraging students to look  for  information  beyond  the  scope  of  the  textbook  and  to  develop  the habit and skills of looking for information from various sources. The ' Did you know ?' icon is included to trigger students' interest and curiosity about science. This  section  not  only  provides  them  with  interesting  information  related  to the concepts being addressed but it also helps to stimulate their curiosity and stretch  their  imagination  further.  Suggestions  are  made  for ' Project work '  to promote cooperative learning.

A ' Summary of unit ' and ' Concept map ' are incorporated at the end of each unit to clearly summarise all the key and relevant concepts learnt. With the visual impact that graphic organisers afford, students can make connections among concepts in the hope that learning is aided, consolidated and eventually a high retention rate is ensured.

It  is  sincerely  hoped  that  the  textbook  helps  motivate  learners,  stimulates their interest in science and develops the habits of mind and skills for scientific inquiry.

Dr (Mrs) Sarojiny Saddul-Hauzaree Coordinator The Science Panel

In this image we can see a blue color background with some text.

<!-- image -->

## Table of Contents

In this image, we can see a diagram with some text and images.

<!-- image -->

Fe

Iron

Ru

Ruthenium

Os

Osmium

Hs

Hassium

Co

Cobalt

Rh

Rhodium

Ir

Iridium

Mt

Meitnerium

Ni

Nickel

Pd

Palladium

Pt

Platinum

Ds

Darmstadtium

Atmosphere and Environment around us

Unit

Unit

C1

1

Unit

<!-- image -->

## Atmosphere and Environment around us

<!-- image -->

## Learning Outcomes

## At the end of this unit, you should be able to:

- Recall the composition of air in the Earth's atmosphere
- Define greenhouse gas as a gas that contributes to the greenhouse effect by  'heat' radiation
- Identify carbon dioxide and methane as greenhouse gases
- Recognise that increase in the absorption of heat energy by the atmosphere is responsible for global warming
- Use data to correlate the increase in global temperature with the increased amount of greenhouses gases (e.g., carbon dioxide) in the atmosphere
- Define global warming in terms of the increase of the Earth's average temperature due to the presence of increasing amounts of greenhouse gases in the atmosphere
- Identify the causes of global warming such as cattle breeding, pollution from vehicles, landfills, deforestation, decay of vegetation and animals, and burning of fossil fuels
- Identify  the  effects  of  global  warming  such  as  heat  waves,  coral  bleaching,  melting  of glaciers, extreme flooding, rising sea levels, more violent rainfall and cyclones, and severe drought
- Define climate change in terms of long-term temperature shifts and weather patterns
- Discuss measures to combat climate change in terms of burning fewer fossil fuels, saving electrical energy, planting trees, recycling plastic wastes and adopting other environmentfriendly practices
- Recognise carbon monoxide, oxides of nitrogen, sulfur dioxide, CFCs and smoke as air pollutants
- State the sources and effects of carbon monoxide, oxides of nitrogen, sulfur dioxide, CFCs and smoke as air pollutants
- Describe the causes of acid rain due to the increasing amount of sulfur dioxide and oxides of nitrogen which react with water vapour and oxygen in the air to form sulfuric acid and nitric acid, respectively
- Describe the effects of acid rain in terms of erosion of limestone structures, corrosion of steel structures and rendering water bodies as well as the soil more acidic
- Discuss measures to prevent air pollution such as removing sulfur dioxide from flue gases, using catalytic converters and adopting other environment-friendly practices
- Describe the causes of water pollution in terms of littering, excess fertilisers, untreated sewage and industrial wastes
- Describe the effects of water pollution on humans, aquatic organisms and marine ecosystem
- Describe the process of eutrophication and identify its harmful effects
- Discuss measures to prevent water pollution such as handling the problem of littering, treating sewage and industrial wastes, avoiding the use of excess fertilisers, and adopting other environment-friendly practices

Climate change and air pollution are closely interconnected. In this unit, you will learn about climate change to develop effective climate change responses, adopt more sustainable ways of living and in turn demand greater change from society at large.

<!-- image -->

## Composition of Air

The Earth is surrounded by a layer of air called the atmosphere. Air is a mixture of gases and is important for living things. The two main gases present in air are nitrogen and oxygen. Gases present in smaller amounts are carbon dioxide and the inert gases. Examples of inert gases are argon, helium and neon. The amount of water vapour varies from day to day and place to place.

Table 1 shows the approximate composition of gases present in a sample of clean dry air.

Table 1: Composition of gases in clean dry  air

| Gases                      |   Percentage (%) |
|----------------------------|------------------|
| Nitrogen                   |            78    |
| Oxygen                     |            21    |
| Carbon dioxide             |             0.04 |
| Inert gases (mainly argon) |             0.96 |

<!-- image -->

## DID YOU KNOW…

The air above a desert is very dry and contains less water vapour compared to the air above seawater which contains a large amount of water vapour. Hence, level of humidity is lower in desert regions than in seawater regions.

<!-- image -->

Desert

<!-- image -->

Seawater

<!-- image -->

## FIND OUT

Natural gas is a fossil fuel. Natural gas is a naturally occurring mixture of gases consisting primarily of methane.

Find out the chemical formula for methane.

## Greenhouse Gases

Greenhouse gases are heat-trapping gases. They keep the Earth's surface warm and livable. Overall, greenhouse gases are beneficial. Without naturally occurring greenhouse gases, our planet would be too cold and non-livable.

<!-- image -->

DID YOU KNOW…

Without  naturally  occurring  greenhouse  gases,  the  Earth's  average  temperature  would  be approximately -18°C instead of the much warmer 15°C.

When solar radiation reaches the Earth's surface, heat energy is trapped by the greenhouse gases. This  effect is called the greenhouse effect because the Earth's atmosphere acts like a greenhouse that traps heat. Figure 1 illustrates how a greenhouse helps in trapping energy from the sun.

The two main greenhouse gases are carbon dioxide and methane.

In this image we can see a plant house with some plants and a wall. We can also see a wall, a fence, a sky and some clouds. We can also see some text on the image.

<!-- image -->

Figure 1: Greenhouse trapping the energy from the sun

<!-- image -->

Identify other greenhouse gases which are emitted in significant quantities by human activities.

Unit

C1

The Earth is surrounded by a layer of air called the atmosphere.  When solar radiation reaches the  Earth,  most  of  the  radiation  is  absorbed  by  the  Earth's  surface.    Some  of  the  incoming radiation is reflected by the Earth. Some of the radiation that passes through the atmosphere is  absorbed and re-emitted in all directions by atmospheric greenhouse gases. These gases retain heat energy in the atmosphere and keep the Earth's surface warm. This effect is called the greenhouse effect and is illustrated in Figure 2.

In this image, we can see the Earth and the Sun. We can also see some text.

<!-- image -->

Figure 2: Greenhouse effect

<!-- image -->

Find out why the Earth is sometimes called the 'Goldilocks' planet.

C

1

1

## Global Warming

You learnt that some of the sun's radiation is reflected by the Earth and its atmosphere while some  of  the  radiation  passes  through  the  atmosphere.  Gases  such  as  carbon  dioxide  and methane trap heat energy in the atmosphere keeping the Earth warm enough to sustain life.

An increase in the amount of greenhouse gases will retain a greater amount of heat energy in the atmosphere resulting in an increase of average global temperature. This phenomenon is  called global warming and is illustrated in Figure 3 below. Global warming is defined as the increase of the Earth's average temperature due to the presence of increasing amount of greenhouse gases in the atmosphere.

Step 5 :

Figure 3: Global Warming (Image: environment.gov.au/climate-change)

In this image, we can see a diagram.

<!-- image -->

An example of a heat-trapping gas is carbon dioxide (CO 2 ) which is released in the atmosphere mainly during the burning of fossil fuels. Excess heat is trapped as the amount of carbon dioxide in the atmosphere increases.

In the following activity, you will use data to understand the relationship between an increase in the amount of carbon dioxide and an increase in Earth's temperature.

<!-- image -->

<!-- image -->

## ACTIVITY 1.1 Using data to correlate the increase in Earth's temperature with the increase in the amount of carbon dioxide in the atmosphere

Table 2 shows the amount of carbon dioxide in the atmosphere from 1800 to 2000.

Table 2: Amount of carbon dioxide in air from 1800 to 2000

| Year                         |   1800 |   1850 |   1900 |   1950 |   2000 |
|------------------------------|--------|--------|--------|--------|--------|
| Amount of carbon dioxide/ppm |    100 |    150 |    200 |    230 |    450 |

Figure 4 shows the rise in Earth's temperature throughout the years from 1800 to 2000.

Figure 4: Graph illustrating evolution of Earth's temperature from 1800 to 2000

The image is a line graph that shows the temperature in Fahrenheit from 1800 to 2000. The x-axis represents the years, while the y-axis represents the temperature in Fahrenheit. The graph is labeled as "Earth's temperature in Fahrenheit," and it shows a trend of increasing temperature over the years.

### Description of the Graph:
1. **Title and Axis Labels**:
   - The title of the graph is "Earth's temperature in Fahrenheit."
   - The x-axis is labeled "Year" and the y-axis is labeled "Temperature."

2. **Data Points**:
   - There are 10 data points on the graph.
   - The data points are marked with a black line.

3. **Line Graph**:
   - The line is a straight line that starts at the bottom of the graph and extends upwards.
   - The line starts at the year 1800 and extends to the year

<!-- image -->

1. Study Table 2 and Figure 4 above and answer the questions that follow.
2. (a)  Calculate the increase in the amount of carbon dioxide from the year:
3. (i)  1800 to 1850.
4. (ii)  1850 to 1900.
5. (b) Calculate  the rise in the Earth's temperature from the year:
6. (i)  1800 to 1850.
7. (ii)  1850 to 1900.
8. (c)  (i) As from which year did the Earth's temperature start to increase drastically?
9. (ii)   What has happened to the amount of carbon dioxide as from this particular year?
2. Draw a conclusion on the correlation between the increase in the amount of carbon dioxide and the rise in the Earth's temperature.

## Causes of Global Warming

It is a fact that human activities over the past century have been mostly responsible for causing the Earth's warming by releasing heat-trapping gases. It is important to understand the causes of global warming so that we can fight for the survival of our planet. In the following activity, you will identify the causes of global warming resulting from an increase in the amount of carbon dioxide and methane.

<!-- image -->

## ACTIVITY 1.2 Identifying the causes of global warming

1. Figure 5 illustrates the natural and man-made causes of global warming.  Observe Figure 5 carefully and fill in the blanks with the appropriate words or phrases from the list.

cattle breeding pollution from vehicles decay of vegetation and animals landfills deforestation burning of fossil fuels

<!-- image -->

<!-- image -->

<!-- image -->

Causes of Global Warming

Figure 5: Causes of global warming

<!-- image -->

<!-- image -->

<!-- image -->

Unit

C1

2.   From the identified causes of global warming;
2. (i) state the natural cause of global warming.
3. (ii) name the gas produced during this natural process.
4. (iii) state the man-made activities which release the gas mentioned in (ii).
3. Identify the man-made activities which increase the amount of carbon dioxide in the atmosphere.
4. How do these man-made activities contribute to global warming?

<!-- image -->

## WHAT I HAVE LEARNT

- Global warming is defined as the increase of the Earth's average temperature due to the presence of increasing amounts of greenhouse gases in the atmosphere.
- Examples of greenhouse gases are carbon dioxide and methane.
- Methane is released:
- by cattle
- during the decay of vegetation and animals
- in landfills
- Carbon dioxide is released when fossil fuels are burnt in power plants and from exhaust pipes of vehicles.
- Trees absorb carbon dioxide during photosynthesis.  Therefore, deforestation indirectly leads to an increase in the amount of carbon dioxide in the atmosphere.

In the following activity, you will learn the effects of global warming.

<!-- image -->

## ACTIVITY 1.3 Identifying the effects of global warming

Some of the possible consequences of global warming have been identified in Figure 6. Observe Figure 6 carefully and fill in the blanks with the appropriate words or phrases given below.

Figure 6: Effects of global warming

In this image, we can see a collage of pictures. There are some text and images.

<!-- image -->

## Global Warming and Climate Change

'Global warming' and 'climate change' are terms which are often used interchangeably but have distinct meanings. Global warming is  the  increase of the Earth's average temperature due to increasing amounts of greenhouse gases in the atmosphere. Climate change focuses on the changes (shifts) in the weather patterns over time caused by increasing amounts of greenhouse gases and other pollutants.

<!-- image -->

## GLOBAL WARMING

Global warming can increase the risk of flash floods. A warmer climate holds more water vapour and eventually leads to more precipitation. Over the past decade, Mauritius has faced several flash floods. Warm oceans also favour the formation of cyclones.  With an increase in the average global temperature, there are greater chances for cyclones to develop and intensify rapidly.

The Intergovernmental Panel on Climate Change (IPCC) Sixth Assessment Report (Chapter 15) informs that the relative sea-level rise in Mauritius and Rodrigues is 4 mm per year and 6 mm per year, respectively. Severe coral bleaching, together with declines in coral abundance have been observed.

Global warming is the long-term heating of Earth's surface. Climate change is a long-term change in the average weather patterns that have come to define Earth's local, regional and global climates. We may conclude that global warming is related to climate change.

In the next section, you will learn about measures to combat climate change.

## Combating Climate Change

An increase in the amount of greenhouse gases and other pollutants has led to climate change. The hazards associated with climate change are real and cannot be neglected. It  is important for  human  beings  to  take  appropriate  measures  to  combat  climate  change.  Most  of  these measures aim at reducing the amount of  greenhouse gases released in the air.

Some measures to combat climate change are listed in Table 3.

<!-- image -->

<!-- image -->

Table 3: Measures to combat climate change

| Description                                                            |
|------------------------------------------------------------------------|
| Save electrical energy by using economic bulbs.                        |
| Plant trees which will absorb more carbon dioxide from the atmosphere. |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Use  non-polluting  sources  of  energy,  like solar energy and wind energy.

Use public transport as often as possible.

Recycle plastic wastes.

Avoid burning fossil fuels, thus reducing the amount of carbon dioxide released in air.

<!-- image -->

## WHAT I HAVE LEARNT

- Global warming is associated with an increase in the Earth's average temperature.
- Climate change is associated with an abnormal shift in the planet's weather patterns over time.
- The consequences (harmful effects) of global warming are:
- -coral bleaching
- -melting of glaciers
- -flooding
- -rising of sea levels
- -more frequent cyclones
- -increase in prevalence of droughts
- -extinction of animal and plant species
- Some measures to combat climate change include:
- -burning less fossil fuels to reduce emission of carbon dioxide
- -saving electrical energy by using economic bulbs
- -planting trees which will absorb more carbon dioxide from the atmosphere
- -recycling plastic wastes
- -using non-polluting sources of energy and public transport as often as possible.

<!-- image -->

## Air Pollution

Air pollution refers to the contamination of air that modifies the natural characteristics of the atmosphere. Air pollution occurs when harmful gases, dust and smoke enter the atmosphere. Air pollution leads to diseases, allergies and may even cause death. Also, air pollution affects living and non-living things and occurs indoors as well outdoors.

Substances  which  are  responsible  for  the  contamination  of  air  are  called air  pollutants . Pollutants emitted into the atmosphere can be of natural origin or man-made.

In  the  following  activities,  you  will  learn  about  the  sources  and  effects  of  the  following  air pollutants:

- carbon monoxide
- sulfur dioxide
- oxides of nitrogen
- smoke
- chlorofluorocarbons (CFCs)

You will also learn how to reduce air pollution.

<!-- image -->

Air pollution kills an estimated 7 million people worldwide every year. World Health Organization (WHO) data shows that 9 out of 10 people breathe air containing high levels of air pollutants.

## Carbon Monoxide

Carbon  monoxide  is  produced  during  the incomplete  combustion of  carbon-containing compounds like fossil fuels, wood and charcoal. However, when these substances are burned in sufficient amount of oxygen , carbon dioxide is formed as one of the products. This reaction is called complete combustion .

Complete combustion

Carbon

+ sufficient oxygen

carbon dioxide (CO 2 )

Carbon +

insufficient oxygen

carbon monoxide (CO)

Incomplete combustion

In the following activity, you will identify the potential sources of carbon monoxide.

<!-- image -->

## ACTIVITY 1.4 Identifying the sources of carbon monoxide

The pictures in Table 4 show some sources of carbon monoxide. Study the pictures carefully and describe each source.

You may choose from the following descriptions:

- Operating portable generators (burning kerosene) in a closed room
- Using charcoal grills in a closed garage
- Operating gas water heaters in an enclosed bathroom with no proper ventilation
- Internal combustion engines of vehicles

Table 4: Sources of carbon monoxide

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

You have identified the sources of carbon monoxide. In the following activity, you will identify the effects of carbon monoxide.

<!-- image -->

## ACTIVITY 1.5 - Identifying the effects of carbon monoxide

Read the article and answer the questions that follow.

Carbon monoxide is a poisonous gas as it binds to haemoglobin in the blood and disrupts the oxygen flow in the body. The most common symptoms of carbon monoxide poisoning, as shown in Figure 7 are  headache, nausea, vomiting, dizziness, loss of consciousness and even death. Carbon monoxide is a colourless, odourless and tasteless gas. The presence of carbon monoxide in air cannot be easily detected. Thus, carbon monoxide is sometimes referred to as a 'silent killer' .

Figure 7: Symptoms of carbon monoxide poisoning

In this image, we can see a person wearing a red color shirt and holding a bag. We can also see some other people. We can see the text on the image.

<!-- image -->

## Questions

1. Why is carbon monoxide a poisonous gas?
2. Why is carbon monoxide referred to  as a 'silent killer'?
3. Describe the symptoms of carbon monoxide poisoning.

<!-- image -->

## WHAT I HAVE LEARNT

- Carbon monoxide is formed by the incomplete combustion of carbon-containing fuels. In other words, carbon monoxide is produced when the combustion occurs in limited (insufficient) amount of oxygen.
- Carbon monoxide is poisonous as it reduces oxygen transport by haemoglobin in the blood.
- Symptoms  of  carbon  monoxide  poisoning  include  headaches,  vomiting,  loss  of consciousness and death.
- Sources of carbon monoxide include:
- -operating portable generators (burning kerosene) in a closed room
- -using charcoal grills in a closed garage
- -operating gas water heaters in an enclosed bathroom with no proper ventilation
- -internal combustion engines of vehicles

## Sulfur Dioxide

You have learnt about the sources and effects of carbon monoxide. In the following activity, you will learn about the sources and effects of sulfur dioxide.

<!-- image -->

## ACTIVITY 1.6 - Identifying the sources and effects of sulfur dioxide

Read the article and answer the questions that follow.

## Sulfur dioxide

Sulfur dioxide (SO 2 ) is a colourless gas with an irritating smell. It is mostly produced by the burning of fossil fuels. Fossil fuels contain sulfur which combines with oxygen to form sulfur dioxide on combustion.

Sulfur dioxide is released into the atmosphere from chimneys of factories that burn fossil fuels (for example from coal-fired power stations) as shown in Figure 8 and exhaust pipes of motor vehicles.

Naturally, sulfur dioxide is released into the atmosphere during volcanic eruptions as shown in Figure 9.

Figure 8: Coal-fired power stations

<!-- image -->

<!-- image -->

<!-- image -->

Figure 9: Volcanic eruptions

## Effects of sulfur dioxide on the environment

Sulfur dioxide reacts with water vapour and oxygen in the air to form sulfuric acid.  The sulfuric  acid  dissolves  in  clouds,  causing  rain  water  to  become  acidic  (Figure  10).  This phenomenon is known as acid rain.

Figure 10: Acid rain formation

In this image, we can see a picture of a truck, trees, buildings, hills, and the sky. We can also see some text on the image.

<!-- image -->

## Effects of sulfur dioxide on health

Sulfur dioxide affects the respiratory system and aggravates conditions such as asthma and bronchitis. Sulfur dioxide also irritates the eyes and the skin.

## Questions

1. State two sources of sulfur dioxide which result from human activities.
2. State one natural source of sulfur dioxide.

3. Write the word equation for the formation of sulfur dioxide from combustion of fossil fuels.
4. Write the word equation for the formation of sulfuric acid as acid rain.
5. Describe the main effect of sulfur dioxide on the environment.
6. Describe the effects of sulfur dioxide on human health.

<!-- image -->

## DID YOU KNOW…

Normal rain is slightly acidic, with a pH between 5.4 and 5.6, while acid rain generally has pH between 4.2 and 4.4.

## Oxides of Nitrogen

You have learnt about the sources and effects of carbon monoxide and sulfur dioxide. In the following activity, you will identify the sources and effects of oxides of nitrogen.

<!-- image -->

The  two  most  common  and  hazardous  oxides  of  nitrogen  are  nitrogen  monoxide  (NO)  and nitrogen dioxide (NO 2 ).

Nitrogen dioxide is an acidic gas but nitrogen monoxide is not an acidic gas.

<!-- image -->

ACTIVITY 1.7 Identifying the sources and effects of oxides of nitrogen

Read the article on the next page carefully and answer the questions that follow.

<!-- image -->

## Oxides of nitrogen

Oxides of nitrogen come mostly from internal combustion engines of vehicles (Figure 11). Oxygen and nitrogen present in air react at  high  temperatures  in  the  engines. The  two most common and hazardous oxides of nitrogen are nitrogen monoxide (NO) and nitrogen dioxide (NO 2 ).

Oxides of nitrogen are also formed during lightning (Figure 12). The high temperature in the vicinity of a lightning bolt causes oxygen and nitrogen to react and form oxides of nitrogen.

Figure 11: Exhaust gases from vehicles

<!-- image -->

<!-- image -->

Figure 12: Lightning

## Effects of oxides of nitrogen

Oxides of nitrogen react with water vapour and oxygen in the air to form nitric acid, which causes acid rain. Oxides of nitrogen also have detrimental effects on human health. For example, oxides of nitrogen damage the lungs and cause respiratory problems. Oxides of nitrogen also irritate the eyes and the skin (Figure 13).

Figure 13: Eye and skin irritation

<!-- image -->

## Questions

1. Describe one source of oxides of nitrogen which results from human activities.
2. Describe one natural source of oxides of nitrogen.

3. Write word equations for the formation of nitrogen monoxide and nitrogen dioxide in the atmosphere.
4. Write a word equation for the formation of nitric acid as acid rain.
5. Describe the effect of oxides of nitrogen on the environment.
6. Describe the effects of oxides of nitrogen on human health.

You have learnt that sulfur dioxide and oxides of nitrogen cause acid rain. In the next activity, you will learn more about acid rain.

## Acid Rain

Sulfur dioxide and oxides of nitrogen react with water vapour and oxygen in the air to form sulfuric acid and nitric acid, respectively. Consequently, rain water becomes more acidic (Figure 14).

In the following activity, you will identify the effects of acid rain on the environment.

Figure 14: Acid rain formation

In this image we can see a diagram, in the diagram we can see a graph, in the graph we can see some text, in the background we can see some trees, in the background we can see some hills, in the background we can see some buildings, in the background we can see some clouds.

<!-- image -->

Unit

C1

<!-- image -->

## ACTIVITY 1.8 - Identifying the effects of acid rain on the environment

The pictures in Table 5 show the effects of acid rain on the environment. Study Table 5 carefully and describe each effect.

You may choose from the following descriptions:

- Acid rain erodes limestone buildings, statues and monuments.
- Acid rain corrodes steel structures like cars, bridges, railways and iron roofs.
- Acid rain makes water in lakes and rivers more acidic thus killing fish and other aquatic organisms.
- Acid rain renders the soil more acidic and kills plants.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 5: Effects of acid rain

<!-- image -->

Complete the chart which illustrates the effects of oxides of nitrogen and sulfur dioxide on the environment.

<!-- image -->

In this image, we can see a chart. There are some text written on the chart.

<!-- image -->

- Sulfur dioxide is released by factories that burn fossil fuels and by motor vehicles.  Sulfur dioxide is also liberated during volcanic eruptions.
- Oxides of nitrogen are formed when oxygen and nitrogen, present in air, react together at the high temperatures in car engines. Also, oxides of nitrogen are formed during lightning.
- Sulfur dioxide reacts with water vapour and oxygen in air to form sulfuric acid, thus causing acid rain.
- Similarly, oxides of nitrogen react with water vapour and oxygen in air to form nitric acid, thus causing acid rain.
- Both oxides of nitrogen and sulfur dioxide  irritate the eyes and affect the respiratory system.
- Acid rain erodes limestone structures, corrodes steel structures and makes water bodies as well as the soil more acidic.

## Smoke

Smoke is an unwanted by-product of fires. Smoke consists of tiny suspended solid particles which are mainly composed of carbon (soot) and ash. Also, smoke contains poisonous gases like carbon monoxide, sulfur dioxide and oxides of nitrogen.

In the following activity, you will identify the sources and effects of smoke. This activity consists of  two parts - Part A and Part B.

<!-- image -->

## ACTIVITY 1.9 - Part A - Identifying the sources of smoke

Figure 15 shows some sources of smoke. Study Figure 15 carefully and describe the sources of smoke.

You may choose from the following descriptions:

- Chimneys of factories
- Burning of garbage
- Burning of cigarette
- Exhaust pipes of vehicles
- Barbecue grills
- Spreading fire

Figure 15: Sources of smoke

In this image, we can see some images of buildings, smoke, trees, and the sky.

<!-- image -->

## Sources of smoke

Picture 1:

Picture 2:

Picture 3:

Picture 4:

Picture 5:

Picture 6:

<!-- image -->

## ACTIVITY 1.9 - Part B - Identifying the effects of inhaling smoke

Read the article carefully and answer the questions that follow.

Smoke-filled  areas  have  reduced  oxygen  content  leaving  the  person  with  less  oxygen  to breathe, thus causing suffocation. Also, during fire and explosions, a large amount of carbon monoxide is produced. Carbon monoxide is the leading cause of death in smoke inhalation.

Smoke also contains sulfur  dioxide  and  oxides  of  nitrogen  which  damage  the  lungs. The symptoms of smoke inhalation include cough, shortness of breath, headache and chest pain. Consequently, a firefighter has to wear an oxygen mask to protect himself from smoke as shown in Figure 16.

Figure 16: Firefighter wearing oxygen mask

<!-- image -->

## Questions

1. Why does smoke inhalation cause suffocation?
2. Which gas is the leading cause of death during smoke inhalation?
3. Which gases damage the lungs during smoke inhalation?
4. State 3 symptoms of inhaling smoke.

<!-- image -->

## DID YOU KNOW…

According to the Burn Institute of the United States, more than half of fire-related deaths result from smoke inhalation rather than burns.

<!-- image -->

## WHAT I HAVE LEARNT

- Smoke is released by exhaust pipes of vehicles, chimneys of factories, spreading fires (including forest fires), burning garbage, barbecue grills, burning charcoal and burning cigarettes.
- Smoke consists of tiny carbon particles (soot) and ash.
- Reduced oxygen content in smoke causes suffocation.
- Smoke contains carbon monoxide which leads to headache, loss of consciousness and death.
- Smoke contains sulfur dioxide and oxides of nitrogen which cause irritation of the eyes, skin burns and damage of the lungs.

## Chlorofluorocarbons (CFCs)

Chlorofluorocarbons (CFCs) were developed in the 1930s and became the product of choice for many manufacturers since they are not toxic and not flammable. However in mid 1970s, CFCs were found to be harmful to the environment.

In  the  following  activity,  you  will  learn  about  the  sources  of  CFCs  and  their  effects  on  the environment.

<!-- image -->

## ACTIVITY 1.10 Identifying the sources and effects of CFCs on the environment

Read the article carefully and answer the questions that follow.

CFCs  (chlorofluorocarbons)  are  compounds  which  are  made  up  of  carbon,  fluorine  and chlorine. CFCs were used as coolants in refrigerators and air conditioners, as propellants for aerosol cans (sprays) and as cleaning agents since they remove grease and dirt.

The Earth's atmosphere is surrounded by a layer of ozone which absorbs ultraviolet (UV) rays from the sun. The ozone layer prevents UV rays from entering the atmosphere. Ultraviolet rays are harmful as they cause skin diseases, skin cancers and eye diseases like cataracts.

CFCs break down in the upper atmosphere to form chlorine atoms which react with ozone, thus depleting the ozone layer. Consequently, harmful ultraviolet rays enter the atmosphere as shown in Figure 17. Therefore, the risk of having skin diseases, skin cancer and eye diseases increases.

Figure 17: Effects of CFCs

In this image there is a poster with some text and images.

<!-- image -->

CFCs have a lifetime of 20 to 100 years in the atmosphere, meaning that their harmful effects can be felt for decades. After discovering that CFCs have detrimental effects on the planet's protective ozone layer, the Montreal Protocol has put an end to the widespread use of CFCs in 1989.

## Questions

1. Name the elements present in CFCs.
2. State the uses of CFCs before the Montreal Protocol.
3. How does the ozone layer protect the Earth's atmosphere?
4. What is the effect of CFCs on the ozone layer?
5. Describe the consequences of the ozone depletion.

Unit

C1

<!-- image -->

## DID YOU KNOW…

Ultraviolet rays are also harmful to plants and marine ecosystems.

<!-- image -->

Find out which substances are being used as substitutes for CFCs.

<!-- image -->

## WHAT I HAVE LEARNT

- CFCs were used as coolants in refrigerators and air-conditioners, as propellants in sprays and as cleaning agents.
- The  Earth's  atmosphere  is  surrounded  by  an  ozone  layer  which  absorbs  harmful ultraviolet rays from the sun.
- CFCs deplete the ozone layer. Harmful UV rays from the sun enter the atmosphere and increase the  risk of skin diseases, skin cancer and eye diseases.

## Measures to Prevent Air Pollution

Air  pollution  is  destroying  our  planet  and  it  is  imperative  to  find  solutions  to  reduce  the emission of pollutants in the atmosphere.

The following are measures to prevent air pollution.

1. Sulfur dioxide from flue gases of factories can be removed by passing the flue gases through powdered calcium carbonate (limestone) as shown in Figure 18.

Calcium carbonate + sulfur dioxide + oxygen calcium sulfate + carbon dioxide

Figure 18: Removing sulfur dioxide from flue gases

In this image there is a table with some text on it.

<!-- image -->

<!-- image -->

2. Catalytic converters (illustrated in Figure 19) are devices which are found in exhaust systems of cars. They convert harmful gases into less harmful ones. Carbon monoxide is converted into carbon dioxide and oxides of nitrogen are converted into nitrogen.
3. To  reduce  the  amount  of  fossil  fuel  burnt,  people  should  be  encouraged  to  use  public transport and make use of carpooling as illustrated in Figure 20 and Figure 21, respectively.

Figure 19: Catalytic converter in a car

<!-- image -->

<!-- image -->

Figure 20: Using public transport

<!-- image -->

4. The use of clean energy like solar, wind and tidal energy (illustrated in Figure 22) should be encouraged.

Solar energy

<!-- image -->

Tidal energy

<!-- image -->

Figure 22: Forms of clean energy

5. CFCs should be replaced by other substances which do not deplete the ozone layer.
6. Burning wastes at home should be avoided as it produces a lot of smoke and toxic gases.
7. Regular servicing of vehicles should be done to prevent emission of large amounts of smoke.

Wind energy

<!-- image -->

<!-- image -->

## DID YOU KNOW…

We usually think of air pollution as being outdoors, but the air in the house or office could also be polluted. Sources of indoor pollution include mold and pollen, dust, tobacco smoke, chemicals in cleaning products and carbon monoxide.

<!-- image -->

Match the following air pollutants with the appropriate descriptions.

Carbon monoxide

Deplete the ozone layer

Sulfur dioxide

Oxides of nitrogen

CFCs

Smoke

Contains soot particles and harmful gases

Formed by the incomplete combustion of carbon containing fuels

Removed by catalytic converters

Released by factories and volcanoes

<!-- image -->

## WHAT I HAVE LEARNT

- Oxides of nitrogen can be removed from exhaust gases of vehicles by using catalytic converters which convert oxides of nitrogen into nitrogen.
- Carbon  monoxide  can  be  converted  to  carbon  dioxide  by  catalytic  converters  in vehicles.
- Sulfur dioxide can be removed from flue gases of factories.  The flue gases are passed through powdered calcium carbonate.
- Gas water heaters and generators should be operated in a ventilated area so that there is enough oxygen for complete combustion.
- CFCs have been replaced by less harmful substances which do not deplete the ozone layer.

## Water Pollution

Water  pollution  occurs  when  harmful  substances  are  discharged  directly  or  indirectly  into water bodies (lakes, rivers and oceans). Water pollution is mainly caused by human factors. In the following activity, you will learn about causes of water pollution.

<!-- image -->

## ACTIVITY 1.11 - Identifying the causes of water pollution

Figure 23 shows some causes of water pollution. Study Figure 23 carefully and identify the causes of water pollution.

Figure 23: Causes of water pollution

In this image we can see a cartoon image. In the cartoon image there is a river, there are some houses, there are some trees, there is a pond, there is a person, there is a boat, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person holding a stick, there is a person

<!-- image -->

## Causes of water pollution:

1.

2.

3.

4.

5.

<!-- image -->

You have identified some causes of water pollution. You will now learn the effects of these water pollutants.

## 1.  Sewage from households, offices and industries

Untreated sewage is dumped illegally in rivers as shown in Figure 24. Sewage contains harmful viruses and bacteria which may kill fish and other aquatic organisms.

Figure 24: Dumping untreated sewage in rivers

In this image we can see a water body. There are two pipes.

<!-- image -->

## 2.  Fertilisers from agriculture

Excess fertilisers  are washed into nearby lakes and rivers during heavy rainfall. The nutrients in the fertilisers cause rapid growth of algae in water. The algal bloom covers the surface of water and this prevents sunlight from reaching aquatic plants. When the plants die, bacteria feed on the dead plants and use oxygen present in the water.  The oxygen in the water is depleted. Consequently, fish and other aquatic organisms die.  This phenomenon is known as eutrophication and is illustrated in Figure 25.

Figure 25: Eutrophication in a lake

In this image there are some plants and there is a text.

<!-- image -->

In this image we can see a plant, grass, water, sun, and a plant suffocate.

<!-- image -->

In this image we can see a lake. In the background there are trees.

<!-- image -->

## 3.  Industrial wastes

Industrial  wastes  may  contain  detergents,  pesticides,  acids,  dyes  which  are  harmful  to aquatic life. Figure 26 illustrates dyes being dumped in rivers.

Figure 26: Dyes being dumped in rivers

<!-- image -->

## 4.  Oil spillage from ships

Oil spill (Figure 27) occurs during shipwrecks. The oil spreads in the sea and affects marine life. For instance, the oil gets stuck on the feathers of seabirds (Figure 28) causing them to lose their ability to fly. It also causes death of fish.

<!-- image -->

Figure 27: Oil spill

<!-- image -->

<!-- image -->

Figure 28: Seabird coated in oil

## 5.  Garbage dumping

Plastic  is  one  of  the  most  common materials found in garbage. Plastic objects are light and float easily, thus plastic objects travel long distances across the oceans (Figures 29 and Figure 30).

<!-- image -->

Figure 29: Dumping of garbage in rivers

<!-- image -->

Figure 30: Plastic object carried far away from the shore

<!-- image -->

The most visible and disturbing impacts of plastics are suffocation and entanglement of marine species as illustrated in Figure 31.

<!-- image -->

Death of turtle trapped in plastic

<!-- image -->

Seal trapped in discarded fishing net

Figure 31: Impact of plastic on marine species

<!-- image -->

## DID YOU KNOW…

Most plastics are non-biodegradable (do not break down naturally in the environment), hence plastic objects stay for a very long period of time in the sea.  For example, a plastic bottle can survive an estimated 450 years in the ocean and plastic fishing lines and nets can last up to 600 years.

## Measures to Prevent Water Pollution

1. Litter should be properly disposed in bins. Litter should never be thrown in places like the beaches, riversides and water bodies.
2. Sewage and industrial wastes should be treated to remove harmful substances before being disposed in water bodies.
3. Farmers should be made aware that excess use of fertilisers does not increase  crop yield but pollutes the environment.
1. Describe why sewage from households causes water pollution.
2. Name four pollutants present in industrial wastes which are harmful to aquatic life.

<!-- image -->

3. Excessive use of fertilisers from agriculture may cause eutrophication. Describe what is meant by the term 'eutrophication' .

4. Describe two effects of oil spillage.

5. Describe how plastic objects are harmful to aquatic animals.

6. Describe two measures to prevent water pollution.

<!-- image -->

## WHAT I HAVE LEARNT

- Water pollution is caused by:
- -Sewage containing harmful viruses and bacteria which kill fish and cause serious illness to humans
- -Fertilisers from agriculture which may cause eutrophication
- -Industrial wastes containing toxic metals, detergents, pesticides, acids and dyes
- -Oil spills from shipwrecks which cause damages to marine life
- -Dumping plastic objects into rivers and the sea
- Water pollution can be prevented by:
- -treating sewage and industrial wastes
- -using the right amount of fertilisers
- -disposing litter in bins

<!-- image -->

## Summary of unit

- Greenhouse gases are heat-trapping gases.
- Greenhouse gases keep our planet warm. However, an increasing amount of these gases  causes  an  increase  in  the  Earth's  average  temperature. This  phenomenon  is called global warming.
- Examples of greenhouse gases are:
- -Carbon dioxide: released during the combustion of fossil fuels in power plants and from exhaust pipes of vehicles
- -Methane:  released from landfills, cattle breeding and the decay of vegetation and animals
- Climate change is mostly associated with an abnormal shift in the Earth's weather patterns over time.
- Consequences of global warming include:
- -droughts
- -coral bleaching
- -melting of ice caps, leading to rise in sea level
- Measures to combat climate change include:
- -burning of less fossil fuels
- -saving electrical energy
- -planting trees
- -recycling of plastic wastes
- -using non-polluting sources of energy, like solar energy, wind energy and hydroelectricity

- Air pollution refers to the contamination of air by harmful gases, dust and smoke which causes harm to living and non-living things in the environment.

| Air pollutants     | Sources                                                                                             | Effects                                                                                                                                                                | Reduction                                                                                                                                                        |
|--------------------|-----------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Oxides of nitrogen | • Internal combustion engines of vehicles • Lightning                                               | • Reacts with water vapour and oxygen to form nitric acid which results in the formation of acid rain • Causes eye and skin irritation as well as breathing problems   | • Fit motor vehicles with catalytic converters which convert oxides of nitrogen into nitrogen                                                                    |
| Sulfur dioxide     | • Volcanic eruptions • Burning of fossil fuels in vehicles, factories and coal-fired power stations | • Reacts with water vapour and oxygen to form sulfuric acid which results in the formation of acid rain • Causes eye and skin irritation as well as breathing problems | • Removed by passing the flue gases containing sulfur dioxide through powdered calcium carbonate                                                                 |
| Carbon monoxide    | • Incomplete burning of carbon-containing fuels                                                     | • Binds to haemoglobin in the blood and prevents it from carrying oxygen, causing headaches, loss of consciousness, vomiting and death                                 | • Use of catalytic converters in vehicles which convert carbon monoxide into carbon dioxide • Operate gas water heaters and generators in a well ventilated area |
| CFCs               | • Coolants in refrigerators and air-conditioners • Propellants in sprays • Cleaning agents          | • Deplete the ozone layer • Harmful UVrays from the sun enter the atmosphere and increase the risk of skin cancer and eye cataract                                     | • Replace CFCs by less harmful substances which do not deplete the ozone layer                                                                                   |
| Smoke              | • Exhaust pipes of vehicles, chimneys of factories and fires                                        | • Damages the lungs (causes suffocation and death)                                                                                                                     | • Avoid burning wastes at home • Servicing of vehicles should be done regularly                                                                                  |

| Sources of water pollution                                | Effects                                                                                              |
|-----------------------------------------------------------|------------------------------------------------------------------------------------------------------|
| Sewage from households, offices and industries            | Sewage contains harmful viruses and bacteria that may kill fish and cause serious illness to humans. |
| Fertilisers from agriculture                              | Excess fertilisers from agriculture causes eutrophication.                                           |
| Industrial wastes (toxic metals, detergents, acids, dyes) | They are toxic and kill aquatic life.                                                                |
| Oil spillage from ships                                   | The oil spreads in the sea and affects marine life.                                                  |
| Garbage dumping                                           | Garbage contains plastic which causes death of fish and other aquatic organisms.                     |

- The different stages involved in eutrophication are listed below.
- Stage 1:  Excess fertilisers are washed away into nearby rivers during heavy rainfall.
- Stage 2:  The nutrients cause rapid growth of algae.
- Stage 3:  The algal bloom covers the surface of water, preventing sunlight from reaching aquatic plants.
- Stage 4:  The aquatic plants die.
- Stage 5:  Bacteria feed on the dead plants using oxygen present in the water.
- Stage 6:  With time, the oxygen content of the water is depleted and consequently, fish and other aquatic organisms die.

In this image, we can see a diagram with some text and some images.

<!-- image -->

In this image, we can see a diagram.

<!-- image -->

• Unit 1 • Atmosphere and environment

1

The image is a detailed flowchart that shows the process of the production of a product. The flowchart is structured to show the steps involved in the production process. The main components of the flowchart are:

1. **Producer**:
   - **Producer Name**: The producer is identified as the person who is responsible for the production of the product.

2. **Producer Name**:
   - **Producer Name**: The producer is identified as the person who is responsible for the production of the product.

3. **Producer Name**:
   - **Producer Name**: The producer is identified as the person who is responsible for the production of the product.

4. **Producer Name**:
   - **Producer Name**: The producer is identified as the person who is responsible for the production of the product.

5. **Producer Name**:
   - **Producer Name**: The producer is identified as the person who is responsible for the production of the product

<!-- image -->

<!-- image -->

## Multiple choice questions

## Circle the correct answer.

1. Which gas is most abundant in the Earth's atmosphere?
2. How much of the air we breathe is composed of nitrogen and oxygen?
3. A 99%
4. B 77%
5. C 63%
6. D 54%
3. Which pollutant is mostly produced by bacterial decay of vegetable matter?
8. A Carbon monoxide
9. B Methane
10. C Ozone
11. D Sulfur dioxide
4. Which term is given to the condition whereby the Earth's average temperature increases?
13. A Ozone depletion
14. B Respiration
15. C Global warming
16. D Combustion
5. Which gas, produced during combustion of coal in power stations, leads to acid rain?
18. A Carbon monoxide
19. B Carbon dioxide
20. C Sulfur dioxide
21. D Water vapour
6. Which gas is removed from exhaust gases of a petrol-powered car by its catalytic converter?
23. A Sulfur dioxide
24. B Carbon dioxide
25. C Oxygen
26. D Oxides of nitrogen
7. Oxides of nitrogen and carbon dioxide are gases which affect the environment. How do these gases affect the environment?

- A Nitrogen

- B Carbon dioxide

- C Argon

- D Oxygen

|    | Oxides of nitrogen       | Carbon dioxide           |
|----|--------------------------|--------------------------|
| A  | Depletion of ozone layer | Global warming           |
| B  | Depletion of ozone layer | Acid rain                |
| C  | Global warming           | Depletion of ozone layer |
| D  | Acid rain                | Global warming           |

8. Which condition causes eutrophication in lakes and rivers?
2. A Increase in the amount of dissolved fertiliser
3. B Increase in the amount of dissolved oxygen
4. C Decrease in the amount of dissolved mineral salts
5. D Decrease in the number of bacteria
10. The following stages happen during eutrophication.
7. 1: Increase in growth of algae
8. 2: Prevent sunlight from reaching plants
9. 3: Death of aquatic plants
10. 4: Decrease in dissolved oxygen

9. Which gas, present in pond water, decreases during eutrophication?

- A Carbon dioxide

- B Methane

- C Nitrogen

- D Oxygen

Write the correct order.

- A 1 2 3 4
- B 1 2 4 3
- C 2 1 3 4
- D 2 1 4 3

## STRUCTURED QUESTIONS

1. Carbon dioxide is a greenhouse gas.
2. (i) What do you understand by the term 'greenhouse gas'?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Name another greenhouse gas and give a natural source of this gas.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

2. Graph 1 shows how the average temperature at the Earth's surface may have changed over  the last 150 thousand years.

Graph 2 shows how the percentage of carbon dioxide in the atmosphere may have changed over the last 150 thousand years.

Average temperature at the Earth's surface / ºC

Time/thousands of years ago

Graph 1: Variation of the average temperature at the Earth's surface over the past 150 years

In this image, we can see a graph. On the graph, we can see the numbers.

<!-- image -->

Percentage of carbon dioxide in the atmosphere

Graph 2: Variation of the percentage of carbon dioxide in the atmosphere over the last 150 years

In this image, we can see a graph. On the graph, we can see numbers.

<!-- image -->

Carbon dioxide is a greenhouse gas. Scientists believe that an increase in the amount of greenhouse gases results in global warming.

- (a)  Explain how Graph 1 and Graph 2 support this statement.

- (b)  Describe two consequences of global warming.
3. Sulfur dioxide is an air pollutant which is formed during the combustion of coal in a power station. Sulfur dioxide combines with moisture and oxygen present in the air and forms acid rain.
- (a)  State another source of sulfur dioxide which results from human activities.
- (b)  State one natural source of sulfur dioxide.
- (c) (i) Name the acid formed when sulfur dioxide reacts with oxygen and water vapour.
- (ii) Write a word equation for the formation of this acid.
- (d)  Describe two environmental effects of acid rain.
- (e)  Describe the effect of sulfur dioxide on human health.
4. The diagram shows five places (labelled A to E) along a river, where water samples were collected and analysed.

In this image there is a map. On the map there is a water supply, water treatment, water supply for the town, water supply for the farm and water supply for the sea.

<!-- image -->

<!-- image -->

The table below provides results of the analysis.

|   Sample | Temperature/˚C   | Dissolved oxygen/ppm   |
|----------|------------------|------------------------|
|        6 | 15               | A                      |
|       13 | 13               | B                      |
|       13 | 13               | C                      |
|       23 | 12               | D                      |
|       26 |                  | E                      |

- (a) Describe how the temperature of the river varies from the river source to the sea.
- (b) As the river flows past the farmland, fertilisers get into it.
- (i) Suggest a value for the oxygen content in sample E.
- (ii) Explain your reasoning as fully as you can.
5. Match the name of each air pollutant to its corresponding effect.

## Air pollutants

## Effects

- Methane
- Sulfur dioxide
- Chlorofluorocarbon
- Carbon monoxide
- leads to global warming
- causes headaches, dizziness and even death
- causes depletion of the ozone layer
- causes brain damage
- leads to acid rain

Mixtures and Separation Techniques

Measurement in Science

Unit

## Mixtures and Separation Techniques

Unit

Unit

Unit

C2

1

1

<!-- image -->

## Learning Outcomes

## At the end of this unit, you should be able to:

- Identify mixtures and list the components present in some mixtures
- Investigate how mixtures can be separated into their respective components by the following separation techniques: sublimation, crystallisation, and simple distillation
- Use labelled illustrations to describe how sublimation, crystallisation, and simple distillation are carried out
- Describe the principles involved in the process of sublimation, crystallisation, and simple distillation

Mixtures are all around us. Solutions and suspensions are examples of mixtures. You learnt about mixtures and their properties. Based on the differences in physical properties, the components of  mixtures  can  be  separated  using  different  separation  techniques.  These  techniques  are termed physical methods of separation.

Separation  techniques  which  you  studied  in  Grade  8  are  magnetic  separation,  f  iltration, decantation and evaporation. In this unit, you will investigate other separation techniques such as sublimation, crystallisation and simple distillation.

## DICTIONARY CORNER

Physical properties include size, boiling point, and solubility.

<!-- image -->

## Mixtures

A mixture consists of two or more components that are physically (or not chemically) combined together. Components of mixtures can be separated by physical methods.

## ACTIVITY 2.1 - Identifying components of mixtures

<!-- image -->

Observe the pictures in Table 1 which illustrate some mixtures and list the components present in each mixture.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 1: Components of mixtures

| Mixture                      | Components present   | Mixture                                          | Components present   |
|------------------------------|----------------------|--------------------------------------------------|----------------------|
| Sugar solution               |                      | Mixture of sodium chloride and ammonium chloride |                      |
| Air                          |                      | Copper (II) carbonate suspension in water        |                      |
| Copper (II) sulfate solution |                      | Green ink                                        |                      |

## Separation of Mixtures

Mixtures are separated to obtain or to identify the components present. For example, at home we carry out different separation processes such as straining tea leaves, sieving flour, sorting grains and decanting water from boiled rice.

In Grade 8, you learnt about magnetic separation, decantation and filtration. In the following sections,  you  will  investigate  the  following  separation  techniques,  namely  sublimation, crystallisation and simple distillation.

## Sublimation

## ACTIVITY 2.2 -   Defining the term 'sublimation'

<!-- image -->

Mothballs are pesticides intended to kill clothes moths and other fabric pests. Some mothballs were kept in  a  warm  place  for  two  weeks.  Four  students,  namely  Jason,  Zariah,  Reeya  and Alyan observed that the mothballs decreased in size. The students were curious to understand what had happened to the mothballs and why the mothballs had decreased in size. Study the conversation among the four students in Figure 1 and answer the questions that follow.

Figure 1

In this image we can see a cartoon image of a boy and a girl. The boy is wearing a red shirt and the girl is wearing a blue dress. In the background there is a text.

<!-- image -->

<!-- image -->

1. (a) Why did Zariah say that the mothballs have not melted?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Who has correctly described what has happened to the mothballs? Justify your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. From the conversation, deduce a definition for sublimation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Examples of solids that sublime on heating are shown in Figure 2:

In this image we can see a glass flask and a bowl. In the bowl there is a powder. In the glass flask there is a powder.

<!-- image -->

Sublimation is a separation technique used by chemists to separate a mixture of two or more solids, provided that one of the solids sublimes on heating. The solid that sublimes on heating changes directly into vapour, forming a solid deposit again on cooling.

## ACTIVITY 2.3 -   Separating a mixture of two solids by sublimation

<!-- image -->

In this activity, you will work in groups and carry out an experiment to separate a mixture of ammonium chloride and sodium chloride.

## Materials needed:

- Evaporating  dish,  glass  funnel,  cotton  wool,  Bunsen  burner,  tripod,  pipe  clay  triangle,  a mixture of ammonium chloride and sodium chloride

## Procedure:

1. Place the mixture of ammonium chloride and sodium chloride in an evaporating dish.
2. Place the inverted glass funnel on the evaporating dish.
3. Close the narrow end of the funnel with cotton wool as shown in Figure 3.
4. Heat the evaporating dish using a Bunsen burner.
5. Observe carefully what happens when the mixture is heated (Figure 4) and write down your observation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image we can see a bowl placed on a table. There is a pipe and a wire.

<!-- image -->

Figure 3: At the start of the experiment

In this image we can see a light bulb, pipe and a pipe.

<!-- image -->

Figure 4: Sublimation taking place

<!-- image -->

6. Stop heating after a few minutes and answer the questions that follow.

- (a) Suggest why a cotton wool is used to close the narrow end of the funnel.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) What do you observe on the inner surface of the glass funnel once the vapour has cooled down?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) On heating, ammonium chloride is separated from sodium chloride. Suggest a reason for this statement.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) Name the process involved in this separation technique.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e) (i)   The solid formed on the inner surface of the funnel is called the sublimate . Identify the sublimate from the mixture.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)  Name the solid left in the evaporating dish.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f ) Explain why the separation of these two solids is possible by this separation technique.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (g) What do you understand by the term sublimation?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

1. Figure  5  shows  the  sublimation  process  to  separate  a  mixture  of  sodium  chloride  and ammonium chloride.  Label  the  diagram  by  choosing  appropriate  word(s)  from  the  list below.

In this image, we can see a diagram, there is a label, there is a text, there is a diagram, there is a text, there is a diagram, there is a diagram, there is a text, there is a diagram, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text, there is a diagram, there is a text,

<!-- image -->

Figure 5: Sublimation Process

<!-- image -->

## WHAT I HAVE LEARNT

- Sublimation is the change from the solid state to the gas state without passing through the liquid state.
- Examples of substances which sublime on heating are ammonium chloride and iodine.
- Sublimation is used to separate a mixture of solids provided that one of the solids sublimes on heating.
- The mixture is heated in an evaporating dish, over which an inverted funnel is placed.
- A cotton wool is plugged to close the narrow end of the funnel. This prevents vapours from escaping.
- On cooling, the ammonium chloride vapour directly changes to the solid state.
- The solid formed on the inner surface of the funnel is called the sublimate.

C

<!-- image -->

2

## Crystallisation

Common salt can be obtained by evaporating seawater in salt pans, as shown in Figure 6. Heat from the sun slowly evaporates the water, leaving behind the solid salt.

Figure 6: Salt pans at Tamarin, in Mauritius

<!-- image -->

In  school  laboratories,  common  salt  can  be  obtained  more  rapidly  by  heating  a  sample  of seawater in an evaporating dish, over a Bunsen flame. When all the water has evaporated, the salt is left in the evaporation dish. This method is called evaporation to dryness and can be used to separate a soluble solid (solute) from a solution.

However,  evaporation  to  dryness  cannot  always  be  used  as  some  solids  decompose  when heated strongly. For example, when sugar solution is strongly heated until all the water has evaporated, the sugar decomposes into black carbon, as shown in Figure 7. This is a major disadvantage of evaporation to dryness. The appropriate technique to obtain sugar crystals from sugar solution is the crystallisation method.

<!-- image -->

Strong heating of sugar solution

Figure 7: Decomposition of sugar solution on strong heating

<!-- image -->

Crystallisation is the process of obtaining crystals of a dissolved solid (solute) from a solution. When the solution is heated, evaporation occurs. Heating is stopped at the stage when a hot saturated solution is formed. When the saturated solution is allowed to cool, crystals are formed. Crystals start to appear on cooling as the solubility of solutes is dependent on temperature.

<!-- image -->

Why are crystals formed when a saturated solution is cooled?

## DICTIONARY CORNER

- Decomposition is the break down of a substance into simpler substances.
- Solubility is the amount of a substance that dissolves in a given amount of solvent at a given temperature.
- A saturated solution is one in which no more solute can be dissolved.

<!-- image -->

In the following activity, you will learn how crystallisation is carried out in the school laboratory.

<!-- image -->

## ACTIVITY 2.4 -   Separating a mixture of copper (II) sulfate and water by crystallisation

In this activity, you will work in groups and carry out an experiment to obtain crystals of copper (II) sulfate (solute) from copper (II) sulfate  solution.

## Materials needed:

- Half-filled  beaker of water, evaporating dish, copper (II) sulfate solution, glass rod, Bunsen burner, tripod, wire gauze, filter papers and spatula

## Procedure:

1. Pour the copper (II) sulfate solution in an evaporating dish.
2. Place the evaporating dish on a beaker of water.
3. Heat the beaker as shown in Figure 8 and answer the questions that follow.
4. (a)   Draw a labelled diagram in the empty box below to illustrate the experiment.

In this image we can see a table and a glass on the table.

<!-- image -->

Diagram illustrating the crystallisation process

Figure 8: Crystallisation as a separation technique

- (b)    State the safety precautions that should be taken while carrying out the experiment.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

4. Stop heating when most of the water has evaporated to form a hot saturated solution. The following step can be used to confirm whether the solution is saturated.

Dip a glass rod into the solution, remove it and allow the solution on the glass rod to cool as shown in Figure 9.

Figure 9: Confirming whether the solution is saturated

<!-- image -->

If  small crystals appear on the glass rod, heating is stopped. The solution is said to be saturated.

5. Allow  the  hot  saturated  solution  to  cool  in  the  evaporating  dish.  Observe  Figure  10 carefully and write down your observation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

6. Use a spatula to remove the crystals from the solution.

Figure 10: Hot solution allowed to cool

7. Wash the crystals with water and dry the crystals in between sheets of filter paper, as shown in Figure 11. Describe the appearance of the crystals.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The crystals can also be dried by placing the filter paper in the sun.

Figure 11: Drying of crystals using filter paper

<!-- image -->

<!-- image -->

## DID YOU KNOW…

Salts that contain water of crystallisation are called hydrated salts. Salts that  do  not  contain water  of  crystallisation  are  called anhydrous salts.  When  hydrated

<!-- image -->

<!-- image -->

copper  (II)

sulfate is

heated  to

Blue solid of hydrated copper (II) sulfate

White solid of anhydrous copper (II) sulfate

dryness , anhydrous copper (II) sulfate is obtained. Hydrated copper (II) sulfate is blue in colour whereas anhydrous copper (II) sulfate is white in colour.

<!-- image -->

## WHAT I HAVE LEARNT

- Crystallisation is used to obtain crystals of a soluble solid (solute) from its solution.
- During crystallisation, the solution is heated until it becomes saturated.
- When the hot saturated solution is allowed to cool, crystals are formed.
- The  crystals formed  are  then  dried  either between  sheets  of  filter  paper or in sunlight.

## Simple distillation

Simple  distillation  is  usually  used  to  separate  the  solvent  from  a  solution.  During  simple distillation, the solution is heated and the solvent changes into vapour. The vapour enters the condenser and cools down into the liquid form. The pure liquid which is collected is called the distillate . In the following activity, you will study simple distillation as a  separation technique.

<!-- image -->

## DID YOU KNOW…

Alcohol  (ethanol)  can  be  made  by  fermenting  sugarcane  juice.  The  alcohol  is  separated  from the fermenting mixture by distillation. In Mauritius, distilleries may be found at the Rhumerie de Chamarel and the Rhumerie de St Aubin.

<!-- image -->

## ACTIVITY 2.5 -   Separating the solvent from a mixture of copper (II) sulfate solution

<!-- image -->

## Materials needed:

- Retort stands, Bunsen burner, thermometer, distillation flask, copper (II) sulfate solution, boiling chips, condenser, rubber tubing, conical flask, rubber bung, wooden block, wire gauze and tap water
1. Y our teacher will set up the apparatus for simple distillation, as shown in Figure 12. During the demonstration, your teacher will discuss the principle of distillation and the necessary safety precautions to be taken while carrying out the experiment.
2. Observe the simple distillation process once the burner is turned on and answer the questions that follow.
- (a)    Observe carefully what happens inside the distillation flask a few minutes after the burner is turned on. Write down your observation.

Figure 12: Simple distillation

In this image we can see a table with some objects on it.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)    Is there any increase in temperature inside the flask as the vapour rises? Justify your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)    Observe  carefully  the  vapour  as  it  flows  through  the  condenser.  Write  down  your observation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) (i)   Record the temperature at which the first few drops of the liquid falls into the conical flask (receiver).

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)   The liquid obtained in the receiver is called the distillate . Identify the distillate.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii)   Observe the temperature until the liquid flows into the conical flask (receiver). Write down your observation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)    What is left in the distillation flask when all the water has distilled over?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Figure 13 illustrates the simple distillation process for obtaining pure water from copper (II) sulfate solution. Label the diagram.
4. Observe the set-up of the apparatus as shown in Figure13 and answer the questions that follow.
3. (a)  Why are boiling chips (anti-bumping granules) added to the copper (II) sulfate solution?

Figure 13: Simple Distillation

In this image, we can see a machine and a stand. We can also see a bottle and a stand. We can see a pipe and a stand. We can see a bottle and a stand. We can see a pipe and a stand. We can also see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can also see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can also see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can also see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can see a pipe and a stand. We can

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)    Why should the bulb of the thermometer be placed at the side-arm of the distillation flask?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)    Why should the condenser slope downwards?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

- (d)    Why does cold water enter at the bottom of the condenser and leave from the top?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## WHAT I HAVE LEARNT

- Simple distillation is used to separate a solvent from a solution.
- Simple distillation involves the processes of boiling and condensation.
- During distillation, the solution boils. Steam rises and enters the condenser. In the condenser, the gas condenses and changes into a pure liquid (the distillate).
- The following precautions should be taken when carrying out simple distillation:
- -Anti-bumping granules are added to the mixture to smoothen boiling.
- -The bulb of the thermometer should be placed at the side-arm of the flask.
- -The condenser slopes downwards so that the distillate flows easily into the receiver.
- -Cold water enters at the bottom of the condenser and leaves from the top, thus ensuring efficient cooling of the gas inside the condenser.

<!-- image -->

## DID YOU KNOW…

Chromatography  is  another  separation  technique  which can  also  be  used  to  identify  the  components  of  a  mixture. It  is  usually  used  to  separate  mixtures  consisting  of  several solutes  dissolved  in  a  solvent.  For  example,  it  can  be  used to  separate  the  different  dyes  in  ink  or  food  colouring. Also,  chromatography  is  used  to  analyse  blood  samples  to determine the cholesterol level and blood sugar level.

<!-- image -->

## Summary of unit

Sublimation is  the  process  whereby a solid changes directly into the gaseous state without passing through the liquid state.

- Examples of substances which sublime include ammonium chloride and iodine.
- Sublimation can be used  to separate a mixture of solids if one of the solids sublimes.
- The solid formed on the inner surface of the funnel is called the sublimate.

Crystallisation is a method of obtaining crystals of a solid (solute) from a solution.

- During crystallisation, the solution is heated on a water bath until it becomes saturated.
- The hot saturated solution is cooled and crystals are formed in solution.
- The crystals are removed, washed with water and dried between filter papers or in direct sunlight.

Simple distillation is used to separate a solvent from a solution.

- Distillation involves the processes of boiling and condensation.
- The solution is heated and the solvent evaporates.
- In the condenser, the gas changes to the liquid state which is collected as distillate.
- A thermometer is used to measure the boiling point of the liquid being distilled.

The image is a diagram of a system, which is a mixture of different components. The components are connected by arrows, and the system is represented by a line. The system is connected to the following components:

- **Crystal**: This is the main component of the system. It is connected to the following components:
  - **Solutions**: This is connected to the following components:
    - **Crystal**: This is connected to the following components:
      - **Solutions**: This is connected to the following components:
        - **Crystal**: This is connected to the following components:
          - **Solutions**: This is connected to the following components:
            - **Crystal**: This is connected to the following components:
              - **Solutions**: This is connected to the following components:
                - **Crystal**: This is connected to the following components:
                  - **Solutions**: This is connected to the following components:
                    - **Crystal**: This is

<!-- image -->

## Multiple choice questions

## Circle the correct answer.

1. Which substance is a mixture?
2. A Oxygen
3. B Sea water
4. C Sodium chloride
5. D Solid iodine
2. Which method can be used to obtain sugar crystals from sugar solution?
7. A Crystallisation
8. B Distillation

C Filtration

- D Sublimation
3. What  is  the  most  appropriate  separation  method  of  obtaining  pure  water  from  sugar solution?
- A Sublimation
- B Distillation
- C Filtration
- D Crystallisation
4. Why are boiling chips added to a mixture in the simple distillation process?
- A To increase the boiling point of the mixture
- B To ensure smooth boiling of the mixture
- C To decrease the boiling point of the mixture
- D To maintain the boiling point of the mixture constant
5. Figure  14  illustrates  the  separation  of  two  solids,  namely  iodine  and carbon. Name this separation method.
- A Filtration
- B Crystallisation

C Evaporation

- D Sublimation

## STRUCTURED QUESTIONS

1. A list of separation techniques is given below.

## distillation

## crystallisation

## sublimation

From this list, choose the most suitable technique to obtain the component from the following mixtures.

- (a) Water from a solution of magnesium sulfate (soluble salt) \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (b)   Potassium chloride crystals (soluble salt) from potassium chloride solution \_\_\_\_\_\_\_\_\_
- (c) Ammonium chloride from a mixture of ammonium chloride and sodium chloride

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 14

<!-- image -->

<!-- image -->

2. State whether each of the following statements is TRUE or FALSE .
3. (a) The diagram below illustrates how zinc sulfate crystals can be obtained from a solution of zinc sulfate. The zinc sulfate solution is heated until a saturated solution is obtained. Label the diagram by filling the empty boxes.
3. (b) When the saturated solution is cooled, crystals of zinc sulfate are formed. The crystals are removed and dried.
4. State two methods by which the zinc sulfate crystals can be dried.

| (a)   | A mixture consists of two or more substances that are chemically joined together.             |
|-------|-----------------------------------------------------------------------------------------------|
| (b)   | A solution is said to be saturated when no more solute can dissolve in it.                    |
| (c)   | In sublimation, the solid deposited on the inner surface of the funnel is called the residue. |
| (d)   | Crystallisation is used to obtain crystals of a solute from a solution.                       |
| (e)   | Distillation can be used to separate pure water from copper (II)sulfate.                      |

In this image we can see a food grill.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Complete the 1st Column of the Table below by correctly writing the labels A - F.
5. In Mauritius, kitchen salt can be obtained by evaporating seawater. In some countries, salt is found in the solid state in the rocky layers of the Earth's crust. This type of salt is called rock salt and must be extracted from the rocks which contain salt and  insoluble impurities.
3. A group of students carried out an experiment to separate salt from rock.
4. (i) Which of the pieces of equipment A, B, C or D was used to grind up (crush) the rock salt at the beginning of the experiment? \_\_\_\_\_\_\_\_\_\_
5. (ii)  Then, the rock salt was mixed with hot water in a container. The mixture was stirred to allow the salt to dissolve. Name the piece of equipment (container) in which the crushed rock salt was placed before the hot water was added. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
6. (iii) Name the piece of equipment that was used to heat the water.

In this image, we can see a flask and a tube.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iv)  The salt and water mixture was separated from the insoluble impurities.

<!-- image -->

To obtain the salt from the mixture of salt and water, the water must be removed. This could be done by either evaporation or distillation.

Write the name of the separation technique under each drawing.

<!-- image -->

In this image, we can see a metal rod and a glass flask. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a metal rod and a metal tube. We can also see a

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. Answer this question in your copybook.

With the aid of a labelled diagram, describe how you would obtain salt crystals from sea water in the school laboratory,

Your answer should include the following:

- -Materials needed
- -Procedure
- -Observation
- -Conclusion

30

100

50

Language of Chemistry

Unit

Unit

Unit

C3

1

Measurement in Science

1

Unit

## Language of Chemistry

20

150

Learning Outcomes

## At the end of this unit, you should be able to:

- Recall symbols and valencies of some elements
- Recall  formulae and valencies of the following radicals: hydroxide, carbonate, sulfate, ammonium and nitrate
- Work out the formulae of compounds, including compounds containing radicals
- Identify reactants and products in chemical reactions
- Recognise that chemical reactions involve the rearrangement of atoms
- Convert word equations to chemical equations
- Write balanced chemical equations

In Grade 8, you learnt that the language of chemistry is a distinct language which chemists use to communicate. For example, you learnt that a symbol is a short-hand way of representing an element and formulae are used to represent molecules, compounds and radicals.

In this unit, you will learn more about the language of chemistry. We will first recall what you learnt about the language of chemistry in Grade 8.

## Symbols and Valencies of Elements

In lower grades, you learnt that elements are arranged in the Periodic Table. Figure 1 shows a simplified version of the Periodic Table.

## GROUP

The image is a table that contains the elements of the periodic table. The table is titled "Period" and is divided into three columns: "K", "C", and "H". The first column is labeled "K", the second column is labeled "C", and the third column is labeled "H". The table is arranged in a vertical column format, with the first column on the left and the third column on the right.

The table has the following elements:
1. **K**: The first column is labeled "K", and the second column is labeled "C".
2. **C**: The first column is labeled "C", and the second column is labeled "H".
3. **H**: The first column is labeled "H", and the second column is labeled "V".
4. **V**: The first column is labeled "V", and the second column is labeled "I".
5. **I**: The first column is

<!-- image -->

C 3

<!-- image -->

According to the language of chemistry, an element is represented by a symbol which usually consists of one or two letters. When a symbol consists of two letters, the first letter is always capitalised, while the second letter is lowercase.

In Grade 8, you learnt that an element has a combining power which is called its valency . Table 1 shows a list of some elements and their respective symbol and valency(ies).

Table 1: Symbols and valencies of some elements

| Nameofelement   | Symbol   | Valency   |
|-----------------|----------|-----------|
| Argon           | Ar       | 0         |
| Helium          | He       | 0         |
| Neon            | Ne       | 0         |
| Bromine         | Br       | 1         |
| Chlorine        | Cl       | 1         |
| Iodine          | I        | 1         |
| Fluorine        | F        | 1         |
| Hydrogen        | H        | 1         |
| Potassium       | K        | 1         |
| Sodium          | Na       | 1         |
| Silver          | Ag       | 1         |
| Calcium         | Ca       | 2         |
| Magnesium       | Mg       | 2         |
| Barium          | Ba       | 2         |
| Oxygen          | O        | 2         |
| Zinc            | Zn       | 2         |
| Aluminium       | Al       | 3         |
| Nitrogen        | N        | 3         |
| Copper          | Cu       | 1 or 2    |
| Mercury         | Hg       | 1 or 2    |
| Gold            | Au       | 1 or 3    |
| Iron            | Fe       | 2 or 3    |
| Carbon          | C        | 2 or 4    |
| Lead            | Pb       | 2 or 4    |
| Tin             | Sn       | 2 or 4    |
| Sulfur          | S        | 2, 4 or 6 |
| Phosphorus      | P        | 3 or 5    |

<!-- image -->

1. What do you understand by the following terms:
2. (i) ' symbol of an element'?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) ' valency of an element'?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Some elements in Table 1 have valency 0.
2. (i) Why do these elements have valency 0?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) How are elements having valency 0 called?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Some elements exhibit more than one valency. Name one metal and one non-metal which have more than one valency.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

## DID YOU KNOW…

The  valency(ies)  of  some  elements  can  be deduced  from  their  positions  in  the  Periodic Table.

Discuss with your teacher how the valency(ies) of some elements can be deduced from the Periodic Table.

In Grade 8, you learnt about diatomic elements. For example, oxygen is a diatomic element and a molecule of oxygen consists of two oxygen atoms chemically joined together.

<!-- image -->

<!-- image -->

Let us recall about diatomic elements.

1

<!-- image -->

## Diatomic Elements

Diatomic elements are a special class of elements as their basic unit is a molecule consisting of two atoms chemically joined together. Some non-metals are diatomic elements. Table 2 shows the names and respective formulae of some diatomic elements.

Table 2: Diatomic elements

| Element   | Formula of the molecule   |
|-----------|---------------------------|
| Hydrogen  | H 2                       |
| Nitrogen  | N 2                       |
| Fluorine  | F 2                       |
| Oxygen    | O 2                       |
| Iodine    | I 2                       |
| Chlorine  | Cl 2                      |
| Bromine   | Br 2                      |

In this image there is a table. On the table there is a name board.

<!-- image -->

Remember that metals and other non-metals that you will encounter in Grade 9 are not diatomic.

<!-- image -->

The following table shows some elements and their respective formula. Complete the table by placing in the 3 rd column, either a '  ' if the formula is correct or a '  ' if the formula is incorrect. The first one has been done for you.

| Element    | Formula of the molecule of the element   | '  ' or '  '   |
|------------|------------------------------------------|------------------|
| Sodium     | Na 2                                     |                 |
| Magnesium  | Mg                                       |                  |
| Chlorine   | Cl                                       |                  |
| Carbon     | C 2                                      |                  |
| Hydrogen   | H 2                                      |                  |
| Aluminium  | Al                                       |                  |
| Nitrogen   | N                                        |                  |
| Bromine    | Br 2                                     |                  |
| Sulfur     | S 2                                      |                  |
| Zinc       | Zn 2                                     |                  |
| Iodine     | I 2                                      |                  |
| Phosphorus | P 2                                      |                  |
| Oxygen     | O                                        |                  |

## Formulae of Compounds

You will recall that a compound is formed when two or more elements chemically combine together. According to the language of chemistry, a compound is represented by a formula. In Grade 8, you learnt how to work out the formulae of compounds using the 'swap valency' method. Let us recall how the formula of a compound can be worked out.

## Working out the formula of a compound

Sodium oxide is a compound made up of sodium and oxygen, chemically combined in fixed ratio. The following steps describe how the formula of sodium oxide can be worked out.

| Step 1                                                           | Identify the constituent elements of the compound   | Sodium   | Oxygen   |
|------------------------------------------------------------------|-----------------------------------------------------|----------|----------|
| Write the symbols of the different elements                      | Na                                                  | O        | Step 2   |
| Write the valencies of the elements                              | 1                                                   | 2        | Step 3   |
| Swap the valencies of the elements                               | 2                                                   | 1        | Step 4   |
| Reduce the valencies to obtain the simplest ratio (if necessary) | 2                                                   | 1        | Step 5   |
| Write the formula of the compound                                | Na 2 O 1                                            | Na 2 O 1 | Step 6   |
| Disregard'1'in the formula                                       | Na 2 O                                              | Na 2 O   | Step 7   |

You will recall from Grade 8 that the subscript next to the symbol of an element in a formula represents the number of atoms of that particular element.

<!-- image -->

| Element   |   N umber of atoms |
|-----------|--------------------|
| Na        |                  2 |
| O         |                  1 |

<!-- image -->

You may have noticed that the term 'oxide' was used in the previous example. The term 'oxide' is the 2 nd  part of the name of the compound. The term  'oxide' refers to oxygen which has combined with another element.

Table 3 shows the terms used to represent other non-metals in compounds.

Table 3: Terms used to represent non-metals in compounds

| Term     | Element which has combined   |
|----------|------------------------------|
| Bromide  | Bromine                      |
| Chloride | Chlorine                     |
| Fluoride | Fluorine                     |
| Hydride  | Hydrogen                     |
| Iodide   | Iodine                       |
| Nitride  | Nitrogen                     |
| Sulfide  | Sulfur                       |

You will recall from Grade 8 that the names of compounds sometimes contain a roman number in brackets. A example is iron (II) chloride. Iron exhibits valencies 2 and 3. But in the case of iron (II) chloride, iron exhibits valency 2 only.

Name of compounds that contain roman number are examples of compounds having elements which exhibit more than one valency. The roman number refers to the valency of the element as used in the compound.

<!-- image -->

1. Work out the formula of each of the following compounds.

- (a)  Potassium chloride

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)    Sodium sulfide (Hint: In sulfide, the valency of sulfur is 2)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Sodium fluoride

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Phosphorus (III) oxide

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Calcium oxide

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f )  Lead (IV) oxide

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (g)  Magnesium nitride

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (h)  Copper (II) chloride

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (i)  Zinc iodide

- (j)  Iron (II) bromide

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

C

1

3

2. (a) Name the following compounds:
2. (vi) PbCl 2
3. (b)   Count the number of atoms of each element in the formulae given in part (a). Write the answers in your copybook.

- (i) KCl:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iv) ZnI 2 :

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) MgBr 2

:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (v) FeCl 3

:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii)  FeO:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

Sometimes compounds are named based on the number of oxygen atoms present in the molecule.

For example, in CO, there is one oxygen atom, therefore the name is carbon monoxide.

In CO 2 , the subscript 2 means that there are 2 oxygen atoms, therefore the name is carbon dioxide.

## Radicals

A radical is a group of atoms chemically combined together, having a formula and a valency. Thus, radicals have a combining power and combine with other elements to form compounds. Sometimes two radicals combine together to form a compound.  Table 4 shows the formulae and the respective valency of some radicals.

Table 4: Formulae and valencies of radicals

| Radical   | Formula   |   Valency |
|-----------|-----------|-----------|
| Hydroxide | OH        |         1 |
| Ammonium  | NH 4      |         1 |
| Nitrate   | NO 3      |         1 |
| Carbonate | CO 3      |         2 |
| Sulfate   | SO 4      |         2 |

## Formulae of compounds involving radicals

In the previous section, you have worked out the formulae of compounds that are made up of two elements only. Some compounds consist of more than two different elements. Very often, such compounds contain radicals. The formulae of compounds containing radicals can also be worked out by the 'swap valency' method.

<!-- image -->

## Working out the formula of copper (II) nitrate

|                                                                    |                                         | Element        | Radical   |
|--------------------------------------------------------------------|-----------------------------------------|----------------|-----------|
| Step 1 Identify the                                                | constituent element and radical: Copper | Nitrate        |           |
| Write the symbol of the element and the formula of the radical:    | Cu                                      | NO 3           | Step 2    |
| Write the valencies of the element and the radical:                | 2                                       | 1              | Step 3    |
| Swap the valencies of the element and the radical in the compound: | 1                                       | 2              | Step 4    |
| Reduce the valencies to obtain the simplest ratio (if necessary):  | 1                                       | 2              | Step 5    |
| Write the formula of the compound:                                 | Cu 1 (NO 3 ) 2                          | Cu 1 (NO 3 ) 2 | Step 6    |
| Disregard '1'in the formula:                                       | Cu(NO 3 ) 2                             | Cu(NO 3 ) 2    | Step 7    |

In the above formula, the NO 3 radical is placed between brackets with a subscript '2' outside the brackets as there are two units of NO 3 in the formula.

In this image, we can see a diagram. There are two lines, which are connected with a point.

<!-- image -->

| Element   | Total number of atoms in the formula Cu(NO 3 ) 2   |
|-----------|----------------------------------------------------|
| Cu        | 1                                                  |
| N         | 1 x 2 = 2                                          |
| O         | 3 x 2 = 6                                          |

## DICTIONARY CORNER

Swap: The act of exchanging one thing for another

<!-- image -->

1. Work out the formula of each of the following compounds.

- (a)  ammonium bromide

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  iron (III) hydroxide

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  calcium sulfate

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  potassium carbonate

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  sodium carbonate

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f )  ammonium sulfate

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. (a) Name the following compounds:

- (i) MgCO 3

:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iv)  ZnSO 4

:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Mg(NO 3 ) 2

: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (v) NH 4 NO 3

: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii)  Fe 2 (SO 4 ) 3

:  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (vi) NH 4

Cl: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)   Count the number of atoms of each element in the formulae given in part (a). Write your answers in your copybook.

## Chemical Reactions and Word Equations

You will recall from Grade 8 that a chemical reaction is a process which involves the formation of new substance(s). The starting substances in a chemical reaction are called reactants and the new substances formed are called products . In other words, reactants are converted into products during a chemical reaction.

<!-- image -->

A chemical reaction can be represented by a word equation . In a word equation, the reactants and the products are separated by an arrow. The reactants are placed on the left side of the arrow and the products are placed on the right side of the arrow. The head of the arrow points towards the product side of the equation, as illustrated below.

<!-- image -->

An example of a chemical reaction is when iron filings and sulfur powder are heated together. Iron chemically combines with sulfur on heating to form iron (II) sulfide.

<!-- image -->

<!-- image -->

Ì

sulfur powder

<!-- image -->

<!-- image -->

<!-- image -->

iron filings

iron filings and sulfur powder heated together

iron (II) sulfide

- (i) Identify the reac tants and product of this reaction.
- (ii) Write a word equation for this reaction.

Reactants: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ and \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Product: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

Write word equations to represent the following chemical reactions.

- (a)  Sulfur powder reacts with oxygen to form sulfur dioxide.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Zinc oxide is formed when zinc reacts with oxygen.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c)  Iron reacts with chlorine to form iron (III) chloride.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Magnesium reacts with hydrochloric acid to form magnesium chloride and hydrogen.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Sodium hydroxide reacts with sulfuric acid to form sodium sulfate and water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

C3

- (f )  Hydrogen burns in oxygen to form water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (g)  Butane burns in air to form carbon dioxide and water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In Grade 8, you learnt that the smallest indivisible part of an element is called an atom . You will recall that an element is made up of one kind of atom and the atoms of one element are different from the atoms of another element. A compound is made up of two or more kinds of atoms.

In the next section, you will understand that chemical reactions involve a rearrangement of atoms.

## Rearrangement of Atoms in a Chemical Reaction

In  a  chemical  reaction,  reactants  usually  combine  together  to  form  new  substances  called products. Have you ever thought what happens to the atoms as the reactants combine to form products?

According to the law of conservation of mass, mass can neither be created nor destroyed in a chemical reaction. Therefore, the total mass of products is equal to the total mass of reactants in a chemical reaction.

In this image we can see a scale.

<!-- image -->

<!-- image -->

The  law  of  conservation  of  mass  was  popularised  by  the  French scientist Antoine Lavoisier in 1789. Lavoisier carried out a number of experiments and showed that the overall mass remained constant during chemical reactions.

Antoine Lavoisier (1743-1794)

<!-- image -->

Let us consider the reaction between carbon and oxygen to form carbon dioxide.

carbon + oxygen  carbon dioxide

A carbon atom can be represented as

<!-- image -->

Oxygen is a diatomic element having formula O 2 . A molecule of oxygen can be represented as

<!-- image -->

Carbon dioxide has formula CO 2 .  A  molecule of carbon dioxide can be represented as

<!-- image -->

<!-- image -->

<!-- image -->

Note: Generally the central atom in a molecule is the one that has the least number of atoms in the formula.

Let us see what happens to the atoms of carbon and oxygen as they combine to form carbon dioxide.

<!-- image -->

carbon

+

oxygen



carbon dioxide

+



<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Reactant side (LHS)                                                        | Product side (RHS)                                   |
|----------------------------------------------------------------------------|------------------------------------------------------|
| • The two oxygen atoms are joined chemically together (diatomic molecule). | • The carbon atom is joined to the two oxygen atoms. |

From the above example, we have seen that the carbon atom and the oxygen atoms are present on both the reactant side and the product side. There has been a rearrangement of the atoms.

## IMPORTANT NOTE

In a chemical reaction, the atoms of the reactants are rearranged to form products. Every atom present at the start of the reaction is present at the end of the reaction.

C

3

1

<!-- image -->

## Chemical Equations

Chemical reactions can be represented by word equations as well as chemical equations .

A chemical equation is a symbolic representation of a chemical reaction in the form of symbols and formulae. In a chemical equation, the reactants are placed on the left side of the arrow and the products are placed on the right side.

Since  atoms  present  at  the  start  of  the  reaction  should  be  present  at  the  end  of  the reaction,  a  chemical  equation  should  be balanced .  In  a  balanced  chemical  equation, the number of atoms of each element on the reactant side is equal to the number of atoms on the product side.

Let us now find out how to write a chemical equation.

## Balancing Chemical Equations Using Visual Diagrams

## Reaction: Carbon burns in oxygen to form carbon dioxide.

The word equation for the reaction is

carbon

+

oxygen



carbon dioxide

To obtain the chemical equation, we use symbols and formulae to represent the substances in the word equation. The chemical equation for the reaction is

C

+

O 2



CO 2

Let us check whether the above chemical equation is balanced.

We will use particle diagrams to count the number of atoms.

C

+

O 2



CO 2

+



<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                   |   Reactant side (LHS) |   Product side (RHS) |
|-------------------|-----------------------|----------------------|
| Number of C atoms |                     1 |                    1 |
| Number of Oatoms  |                     2 |                    2 |

- There is one carbon atom on the reactant side and one carbon atom on the product side. Thus the number of carbon atoms is balanced.
- The number of oxygen atoms is also balanced since there are 2 oxygen atoms on each side of the equation.
- C  + O 2  CO 2 is, therefore, a balanced chemical equation.

<!-- image -->

## ACTIVITY 3.1 - Balancing chemical equations using particle diagrams

<!-- image -->

Answer the following questions which will guide you to balance a chemical equation.

## Reaction 1: Hydrogen reacts with chlorine to form hydrogen chloride.

- (i)  Write the word equation for the above reaction.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) The reactants and product in the word equation can be represented by the following symbols and formulae:

H 2

+

Cl 2



HCl

- (iii) Representing the substances by particle diagrams:

<!-- image -->

+



<!-- image -->

<!-- image -->

- (iv)   Count the number of atoms on each side of the equation and write your answers in the table below.

|                    | Reactant side (LHS)   | Product side (RHS)   |
|--------------------|-----------------------|----------------------|
| Number of Hatoms   |                       |                      |
| Number of Cl atoms |                       |                      |

C

3

1

Unit

C

3

- (v)    After completing the table, you will notice that:
- There are two hydrogen atoms on the reactant side whereas there is only one hydrogen atom on the product side.
- There are two chlorine atoms on the reactant side while there is one chlorine atom on the product side.
- (vi)   Thus, the equation is not balanced.

<!-- image -->

To balance the equation, we increase the number of hydrogen and chlorine atoms on the product side.

<!-- image -->

(vii)   Count the number of atoms on each side of the equation and write your answers in the table below.

|                    | Reactant side (LHS)   | Product side (RHS)   |
|--------------------|-----------------------|----------------------|
| Number of Hatoms   |                       |                      |
| Number of Cl atoms |                       |                      |

(viii)  After completing the table, you will notice that:

- there are two hydrogen atoms on both sides of the equation.
- there are two chlorine atoms on both sides of the equation.

Thus, every atom present at the start of the reaction is present at the end of the reaction. The balanced chemical equation is:

H 2

+

Cl

2



2 HCl

<!-- image -->

The coefficient '2' is added in front of HCl to show that there are two molecules of HCl on the right-hand side of the equation.

When balancing equations, you must never modify the formula of a substance. You must always add coefficients to balance the number of atoms.

## Reaction 2: Hydrogen reacts with oxygen to form water.

- (i) Write the word equation for the above reaction.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) Convert the word equation into a chemical equation by representing the reactants and product with symbols and formulae.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Representing the substances in the equation by particle diagrams:

<!-- image -->

- (iii) Count the number of atoms of each element on the reactant side and on the product side. Write your answers in the table below.
- (iv) You will see the number of oxygen atoms is not balanced in the equation. Add one water molecule on the product side to increase the number of oxygen atoms. Draw the particle diagrams in the space below.
- (v) Again, count the atoms of each element on the reactant side and on the product side. Write your answers in the table below.
- (vi) By adding one water molecule on the product side, the number of oxygen atoms is  balanced.  But  the  number  of  hydrogen  atoms  is  no  longer  balanced.  Add  one hydrogen molecule on the reactant side to increase the number of hydrogen atoms. Draw the particle diagrams in the space below.

|                  | Reactant side (left-hand side)   | Product side (right-hand side)   |
|------------------|----------------------------------|----------------------------------|
| Number of Hatoms |                                  |                                  |
| Number of Oatoms |                                  |                                  |

|                  | Reactant side (left-hand side)   | Product side (right-hand side)   |
|------------------|----------------------------------|----------------------------------|
| Number of Hatoms |                                  |                                  |
| Number of Oatoms |                                  |                                  |

<!-- image -->

(vii) Once more, count the atoms of each element on the reactant side and on the product side. Write your answers in the table below.

|                  | Reactant side (left-hand side)   | Product side (right-hand side)   |
|------------------|----------------------------------|----------------------------------|
| Number of Hatoms |                                  |                                  |
| Number of Oatoms |                                  |                                  |

(viii) Referring to the table in part (vii), state whether the chemical equation is balanced. Justify your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ix) Referring to your answers in parts (vi) and (vii), write down the balanced chemical equation.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Visual  representations  of  the  atoms  involved  in  a  chemical  reaction  have  helped  you  to understand the concept of balancing equations. In the next section, you will learn how to balance equations without the use of particle diagrams.

## Balancing Chemical Equations Without Using Visual Diagrams

## Reaction 1: Adding sodium oxide to water produces sodium hydroxide.

<!-- image -->

Sodium oxide

+

water



sodium hydroxide

Na 2 O

+

H 2 O



NaOH

|                    |   Reactant side (left-hand side) |   Product side (right-hand side) |
|--------------------|----------------------------------|----------------------------------|
| Number of Na atoms |                                2 |                                1 |
| Number of Oatoms   |                                2 |                                1 |
| Number of Hatoms   |                                2 |                                1 |

The number of sodium, hydrogen and oxygen atoms on the right hand side must be increased to  2 in the above equation. This can be done by adding a coefficient '2' in front of NaOH.

## Remember that you cannot change the subscripts in the formulae while balancing equations.

<!-- image -->

Na 2 O

+

H 2 O



2 NaOH

By adding a coefficient '2' in front of NaOH, it means that there are 2 units of NaOH. Therefore, there are 2 atoms of sodium, 2 atoms of oxygen and 2 atoms of hydrogen.

|                    |   Reactant side | Product side   |
|--------------------|-----------------|----------------|
| Number of Na atoms |               2 | 1 2            |
| Number of Oatoms   |               2 | 1 2            |
| Number of Hatoms   |               2 | 1 2            |

The balanced chemical equation is:

$$N _ { 2 } O \ + \quad H _ { 2 } O \ \to \quad 2 \, N a O H$$

## Reaction 2: Chlorine reacts with sodium bromide to form bromine and sodium chloride.

| Chlorine   | +   | sodium bromide   |    | bromine   | +   | sodium chloride   |
|------------|-----|------------------|-----|-----------|-----|-------------------|
| Cl 2       | +   | NaBr             |    | Br 2      | +   | NaCl              |

|                    |   Reactant side |   Product side |
|--------------------|-----------------|----------------|
| Number of Cl atoms |               2 |              1 |
| Number of Na atoms |               1 |              1 |
| Number of Br atoms |               1 |              2 |

The number of chlorine atoms can be balanced by placing a coefficient '2' in front of NaCl on the product side.

Cl

2

+

NaBr



Br

2

+

2 NaCl

<!-- image -->

|                    |   Reactant side | Product side   |
|--------------------|-----------------|----------------|
| Number of Cl atoms |               2 | 1 2            |
| Number of Na atoms |               1 | 1 2            |
| Number of Br atoms |               1 | 2              |

By doing so, the number of Cl atoms is balanced but the number of Na and Br atoms is no longer balanced.  They can be balanced by placing the coefficient '2' in front of NaBr on the reactant side.

Cl

2

+

2 NaBr



Br

2

+

2 NaCl

<!-- image -->

|                    | Reactant side   |   Product side |
|--------------------|-----------------|----------------|
| Number of Cl atoms | 2               |              2 |
| Number of Na atoms | 1 2             |              2 |
| Number of Br atoms | 1 2             |              2 |

Now the equation is balanced. The balanced chemical equation is:

Cl

2

+

2 NaBr



Br

2

+

2 NaCl

<!-- image -->

## Writing a balanced chemical equation involves the following steps:

<!-- image -->

- Step 1: Write the word equation for the reaction

- Step 2: Work out the formulae of compounds in the word equation

- Step 3: Write the chemical equation by using symbols of elements and  the formulae of the compounds in the word equation

- Step 4: Count the number of atoms of each element on the reactant and product side to check if the equation is balanced

- Step 5: Add coefficients (in front of symbols and formulae) to balance the number of atoms

- Step 6: Count the atoms of each element on each side to verify if the equation is balanced. If the equation is not yet balanced, re-adjust the coefficients

TEST YOURSELF 3.6

## Balance the following chemical equations.

(a)

Mg      +

Fe 2 O 3



MgO

+

Fe

## Reactant side

Product side

Number of Mg atoms

Number of Fe atoms

Number of O atoms

(b)

Al        +

HCl



H 2

+

AlCl 3

## Reactant side

Product side

Number of Al atoms

Number of H atoms

Number of Cl atoms

(c)

(d)

(e)

P +

Number of P atoms

Number of O atoms

CuCO 3 +

HCl 

CuCl 2 +

CO 2 +

|                    | Reactant side   | Product side   |
|--------------------|-----------------|----------------|
| Number of Cu atoms |                 |                |
| Number of C atoms  |                 |                |
| Number of Oatoms   |                 |                |
| Number of Hatoms   |                 |                |
| Number of Cl atoms |                 |                |

Ca(OH) 2

+

HCl



CaCl

2

+

H 2 O

Reactant side

Product side

Number of Ca atoms

Number of O atoms

Number of H atoms

Number of Cl atoms

O 2 

## Reactant side

P 4 O 10

Language of Chemistry

## Product side

H 2 O

<!-- image -->

## Balancing equations involving radicals

Reaction 1: Copper reacts with silver nitrate to form copper (II) nitrate and silver.

| Copper   | + silver   | nitrate    | copper (II) nitrate   | + silver   |
|----------|------------|-------------|-----------------------|------------|
| Cu       | + AgNO 3   |            | Cu(NO 3 ) 2           | + Ag       |

In the above equation, the radical NO 3 appears on both sides of the equation. In such cases, the radical is counted as one unit, instead of counting the N and O separately.

<!-- image -->

|      |   Reactant side |   Product side |
|------|-----------------|----------------|
| Cu   |               1 |              1 |
| Ag   |               1 |              1 |
| NO 3 |               1 |              2 |

The number of Cu atoms and Ag atoms is balanced whereas the number of NO 3 radical is not balanced. It can be balanced by adding the coefficient '2' in front of AgNO 3 .

$$C u \quad + \quad 2 \, A g N O _ { 3 } \quad \Rightarrow \quad C u ( N O _ { 3 } ) _ { 2 } \quad + \quad A g$$

<!-- image -->

|      | Reactant side   |   Product side |
|------|-----------------|----------------|
| Cu   | 1               |              1 |
| Ag   | 1 2             |              1 |
| NO 3 | 1 2             |              2 |

By doing so, the number of NO 3 radical is balanced but the number of Ag atoms is no longer balanced. The number of Ag atoms can be balanced by adding the coefficient '2' in front of Ag on the product side.

$$C u \quad + \quad 2 \, A g N O _ { 3 } \quad \to \quad C u ( N O _ { 3 } ) _ { 2 } \quad + \quad 2 \, A g$$

<!-- image -->

|      |   Reactant side | Product side   |
|------|-----------------|----------------|
| Cu   |               1 | 1              |
| Ag   |               2 | 1 2            |
| NO 3 |               2 | 2              |

The equation is now balanced. The balanced equation is:

$$C u \quad + \quad 2 \, A g N O _ { 3 } \quad \to \quad C u ( N O _ { 3 } ) _ { 2 } \quad + \quad 2 \, A g$$

<!-- image -->

Balance the following equations.

(a)

ZnSO

4

+

Na 2 CO 3



ZnCO 3

+                   Na 2 SO 4

Reactant side

Product side

Zn

SO 4

Na

CO 3

(b)

Pb(NO 3 )

2

+                KI



PbI 2

+

KNO 3

Reactant side

Product side

Pb

NO 3

K

I

(c)

Al(NO 3 ) 3

+                NaOH



Al(OH) 3

+

NaNO 3

Reactant side

Product side

Al

NO 3

Na

O

H

(d)

H 2 SO 4

+                 KOH



K 2 SO 4

+

H 2 O

Reactant side

Product side

H

SO 4

K

O

## Summary of unit

- A symbol is a short-hand way to represent an element.
- A formula is a short-hand way to represent a molecule or a compound.
- The valency of an element is its combining power.
- A diatomic molecule consists of 2 atoms of non-metals chemically joined together.
- A radical is a group of atoms chemically combined together, having a formula and a valency.
- In a chemical reaction, the starting substances are called reactants and the new substances formed are called products .
- In a chemical reaction, the atoms of the reactants are rearranged to form products.
- A chemical reaction may be represented by a word equation or by a chemical equation .
- In a chemical reaction, the total mass of products is same as the total mass of reactants.
- Every atom present at the start of a reaction is present at the end of the reaction. Thus, a chemical equation must always be balanced.
- While balancing a chemical equation, atoms must NEVER BE REMOVED from the equation. Atoms must ALWAYS BE ADDED to balance chemical equations.
- ONLY the value of the coefficient in front of an element or compound can be changed while balancing a chemical equation. The symbols and formulae must NEVER be changed.
- Equations involving radicals can be balanced by considering radicals as whole units. For instance, SO 4 can be considered as one unit instead of counting the number of oxygen and sulfur atoms separately.
- The steps involved while writing a balanced chemical equation are:
- -Step 1: Write the word equation for the reaction
- -Step 2: Work out the formulae of the compounds
- -Step 3: Write the chemical equation by using symbols of elements and formulae of compounds as per the word equation
- -Step 4: Count the number of atoms of each element on the reactant side and on the product side to check if the equation is balanced
- -Step 5: Add coefficients to balance the number of atoms
- -Step 6: Count the number of atoms again to confirm if every atom present at the start of the reaction is still present at the end of the reaction. If not, keep on re-adjusting the coefficients until the equation is balanced

• Unit C3 • Language of Chemistry

1

In this image, we can see a chart.

<!-- image -->

<!-- image -->

## Multiple choice questions

## Circle the correct answer.

1. What does the Roman number (II) indicate in iron (II) sulfate?
2. A The number of iron atoms in the formula
3. B The number of sulfate radicals in the formula
4. C The valency of iron in iron (II) sulfate
5. D The valency of sulfate in iron (II) sulfate
2. Which chemical formula represents aluminium sulfate?
7. A AlSO 4

B

Al(SO

4

)

3

C

Al

2

SO

4

- D Al 2 (SO 4 ) 3
3. What is the valency of copper, Cu, in the compound having formula CuCl 2 ?

A

1

B 2

C 3

D 4

4. What is the valency of iron, Fe, in the compound having formula Fe 2 O 3 ?

A 1

B 2

C 3

D 4

5. What is the name of the compound having formula Fe(NO 3 ) 3 ?
2. A Iron (II) nitrate
3. B Iron (III) nitrate
4. C Iron (II) nitride
5. D Iron (III) nitride
6. The given equation represents the reaction of sodium with water.

Sodium + Water  Sodium hydroxide + Hydrogen

- Which chemical equation represents the balanced chemical equation for the given word equation?
- A 2Na + H 2 O  2NaOH + H 2
- B Na + 2H 2 O  NaOH +2H 2
- C 2Na + H 2 O  2NaOH + 2H 2
- D 2Na + 2H 2 O  2NaOH + H 2

## STRUCTURED QUESTIONS

1. Work out the formulae of the following compounds:
2. (a) Magnesium fluoride
3. (b) Sodium oxide
4. (d) Copper (II) iodide
5. (g) Iron (III) oxide
6. (e) Potassium bromide
7. (h) Tin (II) bromide
8. (j) Phosphorus (V) chloride
9. (k) Gold (III) chloride
2. Work out the formulae of the following compounds:
11. (a) Ammonium chloride
12. (b) Sodium hydroxide
13. (d) Tin (II) sulfate
14. (e) Magnesium hydroxide
15. (g) Sodium carbonate
16. (h) Iron (II) carbonate
3. Name the compounds having the following formulae:
18. (a) Na 2 SO 4

(b) SnCl

2

(c) CaCO

3

(d) PbI

2

(e) Cu(OH) 2

4. Count the number of atoms of each element in the following formulae:
2. (a) ZnCl 2

(b) H

2

SO

4

(c) MgCO 3

(d) Al

2

(SO

4

)

3

(e) NH

4

NO 3

5. Balance the following equations:
2. (a) AgCl  Ag + Cl 2
3. (b) Zn + O 2  ZnO
4. (c) Na + O 2  Na 2 O
5. (d) K 2 O + H 2 O  KOH
6. (e) CaO + H 2 O  Ca(OH) 2
7. (f) Mg + Al 2 O 3  MgO + Al
8. (g) Na + H 2 O  NaOH + H 2
9. (c) Aluminium chloride
10. (f) Iron (II) oxide
11. (i) Hydrogen sulfide
12. (l) Mercury (II) chloride
13. (c) Copper (II) nitrate
14. (f) Aluminium sulfate
15. (i) Potassium sulfate

(f ) Cu(OH)

2

- (h) Fe 2 O 3 + Al  Al 2 O 3 + Fe
- (i) CuSO 4 + NaOH  Cu(OH) 2 + Na 2 SO 4
- (j) KOH + H 2 SO 4  K 2 SO 4 + H 2 O
- (k) Ca(OH) 2 + HCl  CaCl 2 + H 2 O
- (l) NH 3 + H 2 SO 4  (NH 4 ) 2 SO 4
- (m) BaCl 2 + Na 2 SO 4  BaSO 4 + NaCl
- (n) FeCl 2 +  Cl 2  FeCl 3

6. Write balanced chemical equations for the following reactions:
2. (a) Iron reacts with chlorine to form iron (III) chloride.
3. (b) Iron burns in oxygen to form iron (II) oxide.
4. (c) Calcium hydroxide reacts with nitric acid to form calcium nitrate and water.
5. (d) Sodium hydroxide reacts with copper (II) sulfate to form copper (II) hydroxide and sodium sulfate.
6. (e) Barium nitrate reacts with potassium sulfate to form barium sulfate and potassium nitrate.
7. (f) Ammonium sulfate reacts with sodium hydroxide to form sodium sulfate, ammonia and water.
8. (g) Methane (CH 4 ) burns in oxygen to form carbon dioxide and water.

( Hint: In  this  combustion  reaction,  you  will  notice  that  there  are  only  three  elements involved.  The  elements  are  carbon,  hydrogen  and  oxygen.  In  such  equations, balance the number of carbon atoms first, followed by number of hydrogen atoms and finally balance the number of oxygen atoms).

Metals and Reactivity Series

Language of Chemistry

Unit

Unit

1

C5 4

Unit

## Metals and Reactivity Series

## Learning Outcomes

## At the end of this unit, you should be able to:

- Describe and compare the reaction of copper, iron and magnesium with oxygen in air
- Describe and compare the reaction of calcium, copper, magnesium and sodium with water
- Describe and compare the reaction of copper and magnesium with steam
- Describe  and  compare  the  reaction  of  copper,  iron,  magnesium  and  zinc  with  dilute hydrochloric acid
- Predict the product(s) formed and write the balanced chemical equation for the reactions of metals with oxygen, water, steam, and dilute acids
- Infer through experiments that different metals differ in chemical reactivity
- Place metals in order of reactivity by reference to their reactions, if any, with oxygen, water, steam, and dilute acids
- Use the reactivity series of metals to describe and compare reactions of metals with air, water and dilute acids

Metals play important roles in our daily life. In Physics, you learn that metals are conductors of electricity and in Biology, you study the importance of metals as minerals in our body. In this unit, you will investigate the chemical properties of metals and classify the metals in order of their chemical reactivity.

<!-- image -->

## DICTIONARY CORNER

Chemical property is a characteristic of a substance that can be observed during a chemical reaction.

Chemical reactivity is a measure of how readily a substance undergoes a chemical reaction.

C 4

<!-- image -->

## Metals

In previous grades, you learnt how elements are classified in the Periodic Table. The elements on the left-hand side of the red zigzag line in the Periodic Table (Figure 1) are metals and the elements on the right-hand side of the line are non-metals.

In this image there is a table with some text on it.

<!-- image -->

Figure 1: Simplified version of the Periodic Table

<!-- image -->

Complete Table 1 by writing the name, symbol and valency(ies) of each metal.

Table 1: Name, symbol and valency(ies) of metals

| Metal   | Symbol   | Valency(ies)   |
|---------|----------|----------------|
| Sodium  |          |                |
|         | Mg       |                |
| Calcium |          |                |
|         | Fe       |                |
| Copper  |          |                |
|         | Zn       |                |

<!-- image -->

## DID YOU KNOW…

A few metals such as gold or silver can be found uncombined in nature. These metals are easier to obtain compared to other metals that exist as compounds in rocks. For example, iron mainly exists as iron (III)  oxide and is present in the ore haematite. Such metals tend to react with oxygen, water and dilute acids.

<!-- image -->

Iron ore (haematite)

<!-- image -->

Gold ore

## Reaction of Metals

In Grade 8, you learnt that many metals react with dilute acids to form salts and hydrogen. However, these metals differ in the ease with which they react. Some metals tend to be more reactive than others. In the following activities, you will compare and describe the ease with which some metals react with oxygen, water, steam, and dilute acids.

## Reaction of Metals with Oxygen

Most metals react with oxygen in air to form metal oxides.

## metal + oxygen metal oxide

However, the chemical reactivity of the metals differs. In the following activity, you will compare and describe the reactions of copper, iron and magnesium with oxygen when heated in air.

<!-- image -->

## ACTIVITY  4.1  Investigating  the  reactions  of  copper,  iron  and magnesium with oxygen

This activity will be carried out by your teacher. Observe carefully and record your observation in Table 2.

## Materials needed:

- Clean copper wire, iron wool, magnesium ribbon, a pair of tongs, a watch glass, safety goggles and a Bunsen burner

## Procedure:

1. Hold a piece of copper wire with a pair of tongs.

PRECAUTION: Avoid looking at any flame directly.

2. Observe the metal carefully.

<!-- image -->

3. Place the copper wire in the blue flame of a Bunsen burner and observe carefully.
4. Transfer the hot metal to a watch glass and observe the product.
5. Record your observation for steps 2, 3 and 4 in Table 2.
6. Repeat the experiment with iron wool and magnesium ribbon.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 2: Observation for the reactions of copper, iron and magnesium with oxygen

| Metal            | Appearance of metal   | Observation for the reaction of metal with oxygen   | Appearance of product   |
|------------------|-----------------------|-----------------------------------------------------|-------------------------|
| Copper wire      |                       |                                                     |                         |
| Iron wool        |                       |                                                     |                         |
| Magnesium ribbon |                       |                                                     |                         |

7. After completing Table 2, answer the questions that follow.
2. (a)  Based on how readily the three metals react with oxygen, state which metal is:
3. (i) most reactive.
4. (ii)  least reactive.

Justify your answer.

- (b) (i)   What class of compound is formed when a metal reacts with oxygen?
- (ii)  Match the reaction with the corresponding product.

| Reaction                     | Reaction   | Product             |
|------------------------------|------------|---------------------|
| Magnesium reacts with oxygen | •          | • Copper (II) oxide |
| Iron reacts with oxygen      | •          | • Magnesium oxide   |
| Copper reacts with oxygen    | •          | • Iron (III) oxide  |

<!-- image -->

When iron is heated in air, the product can be iron (II) oxide (FeO), iron (III) oxide (Fe 2 O 3 )  or  a mixture of both (FeO.Fe 2 O 3 or Fe 3 O 4 ).

- (c)  Write the word equation and balanced chemical equation for the following reactions.
- (i) Copper reacts with oxygen

Word equation:                                    +

Chemical equation:

- (ii) Iron reacts with oxygen

Word equation:                                     +

Chemical equation:

<!-- image -->

## (iii) Magnesium reacts with oxygen

Word equation:                                     +

Chemical equation:

- d)  Arrange copper, iron and magnesium in decreasing order of reactivity.

,                                                    and

Most reactive                                                                                least reactive

From  Activity  4.1,  you  learnt  that  the  ease  with  which  metals  react  with  oxygen  differs. Magnesium burns readily in air whereas copper does not burn when heated.

<!-- image -->

## WHAT I HAVE LEARNT

- Most metals react with oxygen in air to form metal oxides.
- Copper, iron and magnesium show different reactivity with oxygen.
- Magnesium burns readily in air with a white flame to produce a white ash of magnesium oxide.
- Hot iron glows red when heated in air to form iron (III) oxide.
- Copper does not burn or glow when heated. On strong heating, copper reacts slowly with oxygen to form black copper (II) oxide.
- The  reactivity  of  copper,  iron  and  magnesium  in  decreasing  order  is  as  follows: magnesium, iron and copper.

## Reaction of Metals with Water

In Activity 4.1, you investigated the reaction of metals with oxygen. Now you are going to study the reaction of metals with water.

Some metals react with water to form metal hydroxides and hydrogen gas.

metal + water metal hydroxide + hydrogen

<!-- image -->

In Activity 4.2, you will compare and describe the reaction of calcium, copper, magnesium and sodium with (cold) water.

This activity consists of two parts - Part A and Part B.

<!-- image -->

## ACTIVITY 4.2 - Part A - Investigating the reaction of sodium with water

Sodium reacts with water to form a colourless solution of sodium hydroxide and hydrogen gas.

Observe Figures 2 and 3 carefully and answer the questions that follow.

<!-- image -->

<!-- image -->

1.  Figure 2 shows pieces of sodium metal. Describe the physical appearance of the sodium metal.

3. Suggest a reason why this experiment should not be performed in the school lab.

Figure 3: Sodium reacting with water

2.    A  reaction  takes  place  when  a  piece  of  sodium  metal  is placed in a trough containing water, as shown in Figure 3. Describe the reaction.

Figure 2: Sodium metal

4.   Write the word equation and balanced chemical equation for the reaction of sodium with water.

Word equation:

Chemical equation:

<!-- image -->

5.   Suggest a reason why sodium is stored in paraffin oil (Figure 4).

<!-- image -->

Figure 4: Sodium stored in paraffin oil

<!-- image -->

## ACTIVITY 4.2 - Part B -   Investigating the reactions of calcium, copper and magnesium with water

You will work in groups of four in this activity. Observe carefully and record your observation in Table 3.

## Safety:

## Materials needed:

Wear lab gloves and lab coat.

- One 500 ml beaker, funnel, boiling tube,  water,  pieces  of  calcium granules, copper wire (4 cm length) and magnesium ribbon (4 cm length)

## Procedure:

1. Fill the 500 ml beaker with water to four fifths its capacity.
2. Fill a boiling tube with water.
3. Add a few pieces of calcium granules in the beaker of water.
4. Cover the metal with a funnel.
5. Invert the boiling tube filled with water over the funnel as shown in Figure 5.
6. Observe the reaction. Record your observation in Table 3.
7. Repeat the experiment with copper wire and magnesium ribbon.

Figure 5: Experiment setting

<!-- image -->

Table 3: Observation for the reaction of calcium, copper and magnesium with water

In this image, we can see a table with some text and images.

<!-- image -->

| Metal   | Reaction of metal with water        | Describe your observation   |
|---------|-------------------------------------|-----------------------------|
| Calcium | bubble of gas gas water calcium     |                             |
| Copper  | water copper tube filled with water |                             |
|         | bubble of gas gas water magnesium   | Magnesium                   |

8. After completing Table 3, answer the questions that follow.
2. (a)  Based on how readily the three metals, namely calcium, copper and magnesium react with water, state which metal is:

- (i) most reactive.

- (ii)  least reactive.

Justify your answer.

<!-- image -->

- (b) (i)  What products are formed when a metal reacts with water?
- (ii) Match the reaction with the corresponding products.
- (c)  Write the word equation and balanced chemical equation for each of the following reactions.

| Reaction             | Reaction   | Products                           |
|----------------------|------------|------------------------------------|
| Calcium with water   | .          | . No reaction products             |
| Copper with water    | .          | . Magnesium hydroxide and hydrogen |
| Magnesium with water | .          | . Calcium hydroxide and hydrogen   |

## (i) Calcium reacts with water

Word equation:

Chemical equation:

- (ii) Magnesium reacts with water

Word equation:

Chemical equation:

<!-- image -->

Describe how you would test for the products from the reactions of metals with water.

9. After completing Activity 4.2 ( Part A and Part B), arrange calcium, copper, magnesium and sodium in decreasing order of reactivity.

,                                      ,                                       and

Most reactive                                                                                      least reactive

## Reaction of Metals with Steam

From Activity 4.2, you learnt that sodium is more reactive than calcium. Magnesium reacts very slowly and copper shows no reaction with water. In Activity 4.3, you will compare and describe the reaction of copper and magnesium with steam.

<!-- image -->

## ACTIVITY 4.3 - Investigating the reactions of copper and magnesium with steam

A piece of magnesium ribbon is placed in a boiling tube containing cotton wool soaked in water. The boiling tube is heated as shown in Figure 6. Observe Figure 6 carefully and answer the questions that follow.

In this image, we can see a machine. There is a pipe. We can see a metal object. There is a text.

<!-- image -->

1. (i)   Name the liquid present in the soaked cotton wool.
2. (ii)  What happens to this liquid when the boiling tube is heated?
2. After some time, the magnesium ribbon becomes hot and burns with a white flame. What can you infer from this statement?
3. During the reaction, a white ash is formed. Name the product.

<!-- image -->

4. The gas which is produced during the reaction ignites in air. Name the gas.

5. Write the word equation and the balanced chemical equation for the reaction.

Word equation:

Chemical equation:

6. There is no reaction when the experiment is repeated with copper. What can you conclude about the reactivity of copper?

<!-- image -->

## WHAT I HAVE LEARNT

- When metals react with water, metal hydroxides and hydrogen gas are formed.
- Calcium,  copper,  magnesium  and  sodium  show  different  reactivity  with  water  and steam.
- Sodium reacts violently with water to form sodium hydroxide and hydrogen gas.
- To prevent sodium from coming in contact with oxygen or moisture present in air, the metal is safely kept under paraffin oil.
- Calcium  reacts  readily  with  water  to  form  calcium  hydroxide  and  many  bubbles  of hydrogen gas.
- Magnesium reacts slowly with water to form magnesium hydroxide and a few bubbles of hydrogen gas. However, hot magnesium reacts violently with steam to form magnesium oxide and hydrogen.
- Copper does not react with water and steam.
- The reactivity  of  calcium,  copper,  magnesium and sodium in decreasing order is as follows: sodium, calcium, magnesium and copper.

## Reactions of Metals with Dilute Acids

In  Grade  8,  you  identified  hydrochloric  acid,  nitric  acid  and  sulfuric  acid  in  your  Chemistry laboratory. You also learnt the chemical properties of acids, such as the reactions of acids with metals to produce a salt and hydrogen gas.

In the previous activities, you learnt about the reactions of metals with oxygen, water and steam. In Activity 4.4, you will compare and describe the reactions of copper , iron , magnesium and zinc with dilute hydrochloric acid .

<!-- image -->

## ACTIVITY 4.4 - Investigating the reactions of copper, iron, magnesium and zinc with dilute hydrochloric acid

Read the information given in the textbox carefully and observe the reactions of the metals with dilute hydrochloric acid.

When metals react with dilute hydrochloric acid, hydrogen gas is formed as one of the products. The hydrogen gas can be observed as bubbles. In general, more reactive metals produce more bubbles of hydrogen gas at the initial stage of reaction.

metal + hydrochloric acid metal chloride + hydrogen

1. Four metals are placed separately in a test-tube containing dilute hydrochloric acid as shown in Table 4. Observe the pictures carefully and complete Table 4.

Table 4: Observation for the reaction of copper, iron, magnesium and zinc with dilute hydrochloric acid

<!-- image -->

<!-- image -->

<!-- image -->

|                                                 | Copper   | Iron   | Magnesium   | Zinc   |
|-------------------------------------------------|----------|--------|-------------|--------|
| Reaction of metal with dilute hydrochloric acid |          |        |             |        |
| Amount of bubbles produced                      |          |        |             |        |
| Describe the reaction                           |          |        |             |        |

<!-- image -->

2. After completing Table 4, answer the questions that follow.
2. (a)  The amount of bubbles of gas produced indicates how readily the metals react with dilute hydrochloric acid. State which metal is:
3. (i) most reactive.
4. (ii)  least reactive.

Justify your answer.

- (b) What are the products formed when a metal reacts with dilute hydrochloric acid?
- (c)  Match the reaction, if any, with the corresponding products.
- (d) Write the word equation and the balanced chemical equation for each of the following reactions.

| Reactions                              | Reactions   | Products                          |
|----------------------------------------|-------------|-----------------------------------|
| Copper and dilute hydrochloric acid    | •           | • Zinc chloride and hydrogen      |
| Iron and dilute hydrochloric acid      | •           | • Magnesium chloride and hydrogen |
| Magnesium and dilute hydrochloric acid | •           | • No reaction products            |
| Zinc and dilute hydrochloric acid      | •           | • Iron (II) chloride and hydrogen |

## (i) Reaction of iron and dilute hydrochloric acid

Word equation:

Chemical equation:

- (ii) Reaction of magnesium and dilute hydrochloric acid

Word equation:

Chemical equation:

## (iii) Reaction of zinc and dilute hydrochloric acid

Word equation:

Chemical equation:

- (e)  Arrange copper, iron, magnesium and zinc in decreasing order of reactivity.

,                                       ,                                      and

Most reactive                                                                                     Least reactive

<!-- image -->

## WHAT I HAVE LEARNT

- Some metals react with dilute hydrochloric acid to form metal chlorides and hydrogen gas.
- Copper shows no reaction with dilute acids.
- Iron reacts slowly with dilute hydrochloric acid to form a pale green solution of iron (II) chloride and hydrogen gas.
- Magnesium reacts very fast with dilute hydrochloric acid to form a colourless solution of magnesium chloride and hydrogen gas.
- Zinc reacts moderately fast with dilute hydrochloric acid to form a colourless solution of zinc chloride and hydrogen gas.
- The reactivity of copper, iron, magnesium and zinc in decreasing order is as follows: magnesium, zinc, iron and copper.

## Reactivity Series

From previous activities, you learnt that the reactivity of metals with oxygen, water, steam, and dilute hydrochloric acid differs. Hence, metals can be arranged in a particular order with respect to their reactivity. This arrangement is referred to as the reactivity series . In Activity 4.5, you will place the metals in order of reactivity by reference to their reactions, if any, with oxygen, water, steam, and dilute acids.

<!-- image -->

## ACTIVITY 4.5 - Constructing the reactivity series of metals

A reactivity series is a list of metals arranged in order of reactivity .

In this activity, you will analyse Table 5(a), Table 5(b) and Table 5(c) to construct the reactivity series of metals in Table 5(d).

## (a) Reaction of copper, magnesium and iron with oxygen in air

Table 5(a): Reactivity series of copper, iron and magnesium

<!-- image -->

<!-- image -->

## (b) Reaction of calcium, copper, magnesium and sodium with water and/or steam

Table 5(b): Reactivity series of calcium, copper, magnesium and sodium

The image shows a horizontal bar chart with two categories: "Increasing reactivity" and "Copper." The x-axis represents the "Increasing reactivity" category, while the y-axis represents the "Copper" category. The bars are colored blue and white, indicating that they are meant to be visually represented.

The "Increasing reactivity" category has a horizontal bar extending from the left to the right, indicating that the bar is increasing in value. The "Copper" category has a horizontal bar extending from the left to the right, indicating that the bar is increasing in value.

The bars are labeled with the following text:
- "Increasing reactivity"
- "Copper"

The chart is labeled as "Increasing reactivity" and "Copper" on the x-axis, and "Increasing reactivity" and "Copper" on the y-axis.

The bar chart is visually appealing and easy to read, with clear and concise labels and a

<!-- image -->

## (c) Reaction of copper, iron, magnesium and zinc with dilute acids

Table 5(c): Reactivity series of copper, iron, magnesium and zinc

In this image there is a table with few items on it.

<!-- image -->

|            |            | Metals                     |
|------------|------------|----------------------------|
| Increasing | reactivity | Magnesium Zinc Iron Copper |

Use Tables 5(a), 5(b) and 5(c) to arrange the following metals namely: calcium, copper, iron, magnesium, sodium and zinc in order of reactivity in Table 5(d).

Table 5(d): Reactivity series of calcium, copper, iron, magnesium, sodium and zinc

In this image there is a paper with some lines and a text written on it.

<!-- image -->

Use the mnemonic to write the missing metals to complete the reactivity series in Table 6: ' P lease S end C harlie's M onkeys A nd Z ebras I n L ead C ages S ecurely G uarded' .

Table 6: The reactivity series

## Reactivity series of metals

( P lease)

P OTASSIUM

( S end)

(C harlie's)

( M onkey)

( A nd)

A LUMINIUM

( Z ebras)

( I n)

( L ead)

L EAD

( C ages)

( S ecurely)

S ILVER

( G uarded)

G OLD

<!-- image -->

1. Given that the metal tin (Sn) is more reactive than lead but less reactive than iron , put a hashtag (#) to show its position in Table 6.
2. What do you understand by the term 'reactivity series'?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## ACTIVITY 4.6 Comparing the reactions of metals

Depending on their position in the reactivity series, metals have different ease of reaction with oxygen, water, steam and dilute acids. Hydrochloric acid is used to represent dilute acids.

Table 7 shows the trend of the reactivity of the metals.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 7: Summary on the reaction of metals with oxygen, water, steam and dilute hydrochloric acid

| Metals in order of reactivity series      | Reaction with oxygen   | Reaction with water                                                                                                                                         | Reaction with steam                                                             | Reaction with dilute hydrochloric acid                                                    |
|-------------------------------------------|------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|
| Calcium Magnesium Iron Lead s i n g r e a |                        |                                                                                                                                                             |                                                                                 | Potassium                                                                                 |
| Calcium Magnesium Iron Lead s i n g r e a |                        |                                                                                                                                                             |                                                                                 | Sodium                                                                                    |
| c t i v i t y                             |                        | *Aluminium is covered with a thin layer of aluminium oxide that prevents the metal from reacting.When this oxide layer is removed, the reaction will occur. | *The protective aluminium oxide layer prevents reaction of the metal with acid. | Aluminium                                                                                 |
| c t i v i t y                             |                        |                                                                                                                                                             |                                                                                 | Zinc                                                                                      |
| c t i v i t y                             |                        |                                                                                                                                                             | after to in                                                                     | *The reaction stops some time due formation of insoluble lead (II) chloride (see unit 5). |
| Copper                                    |                        |                                                                                                                                                             |                                                                                 |                                                                                           |
| Silver                                    |                        |                                                                                                                                                             |                                                                                 |                                                                                           |
| Gold                                      |                        |                                                                                                                                                             |                                                                                 |                                                                                           |

Analyse Table 7 and attempt the questions that follow.

1. List the metals that react with steam but not with water.
2. Name a metal that shows no reaction with oxygen, water, steam and dilute acids.
3. Name a metal that reacts slowly with water but vigorously with steam.
4. Name three metals that do not react with dilute acids.
5. Which of the following metal will react more readily with dilute hydrochloric acid, calcium or zinc? Justify your answer.
6. Given that dilute sulfuric acid is used, which metal will react more readily, magnesium or iron? Justify your answer.
7. Given that dilute nitric acid is used, which metal will react more readily, magnesium or silver? Justify your answer.
8. Why does aluminium show poor reactivity with dilute acids?
9. When lead reacts with dilute hydrochloric acid, the reaction stops after some time. Identify the salt that prevents the reaction to reach completion.
10. Suggest a reason why silver jewels tarnish with time.

<!-- image -->

<!-- image -->

## WHAT I HAVE LEARNT

- Metals higher in the reactivity series are more reactive than those lower in the series.
- Copper, silver and gold do not react with dilute acids.
- A reactivity series is a list of metals arranged in order of reactivity .

<!-- image -->

## DID YOU KNOW…

- The reactivity series can be used to predict whether displacement reactions will occur.
- A displacement reaction occurs when a more reactive metal displaces a less reactive one from its salt solution.
-  For  example, zinc displaces copper from copper (II) sulfate solution to form zinc sulfate and copper because zinc is more reactive than copper. But copper cannot displace zinc from zinc sulfate solution because copper is less reactive than zinc.

Figure 7: Zinc (grey metal) reacts with copper (II) sulfate solution (blue) to form copper (reddish brown) and zinc sulfate solution (colourless)

In this image, we can see a glass with a blue liquid in it.

<!-- image -->

## Summary of unit

- Most metals react with oxygen to form metal oxides.

metal + oxygen metal oxide

- Many metals react with water to form metal hydroxides and hydrogen.

metal + water metal hydroxide + hydrogen

- Some metals react with steam to form metal oxides and hydrogen.

metal + steam metal oxide + Hydrogen

- Many metals react with dilute acids to form salts and hydrogen.

metal + hydrochloric acid metal chloride + hydrogen

- Different metals differ in the ease with which they react.
- A reactivity series is a list of metals arranged in order of reactivity.
- The reactivity series of metals helps to predict the ease of the reactions of metals with air, with water, with steam and with dilute acids.

| Reactivity series of metals   | Reactivity series of metals   |
|-------------------------------|-------------------------------|
| ( P lease)                    | P OTASSIUM                    |
| ( S end)                      | S ODIUM                       |
| (C harlie's)                  | C ALCIUM                      |
| ( M onkey)                    | M AGNESIUM                    |
| ( A nd)                       | A LUMINIUM                    |
| ( Z ebras)                    | Z INC                         |
| ( I n)                        | I RON                         |
| ( L ead)                      | L EAD                         |
| ( C ages)                     | C OPPER                       |
| ( S ecurely)                  | S ILVER                       |
| ( G uarded)                   | G OLD                         |

The image is a diagram of a chemical reaction, which is a process involving the transfer of atoms or molecules. The diagram is labeled with the names of the elements and their chemical properties. The elements are represented by different colors, and the chemical properties are represented by their atomic weights.

The diagram is divided into several sections, each representing a different element. The elements are connected by arrows, which indicate the direction of the reaction. The arrows are labeled with the names of the elements, and the arrows are connected to the elements by a line.

The elements are:
- Magnesium (Mg)
- Iron (Fe)
- Copper (Cu)
- Sodium (Na)
- Calcium (Ca)
- Iron (Fe)
- Zinc (Zn)
- Iron (Fe)
- Copper (Cu)
- Sodium (Na)
- Calcium (Ca)
- Iron (Fe)
- Zinc (Zn)
- Iron

<!-- image -->

## Multiple choice questions

## Circle the correct answer.

1. Which metal produces a white flame on burning in air?

- A Copper

- B Iron

- C Magnesium

- D Silver

2. Which metal does not burn or glow when it reacts with oxygen in air?

- A Copper

- B Sodium

- C Magnesium

- D Iron

3. Which gas is produced when calcium reacts with water?

- A Carbon dioxide

- B Hydrogen

- C Oxygen

- D Nitrogen

4. Which chemical equation  is a balanced chemical equation for the reaction of potassium with water?
2. A 2K + H 2 O KOH  + H 2
3. B 2K + 2H 2 O 2KOH  + H 2
4. C K + 2H 2 O KOH  + 2H 2
5. D K + H 2 O KOH  + H 2
5. Which compound is formed when magnesium reacts with steam?
7. A Magnesium hydroxide
8. B Magnesium chloride
9. C Magnesium nitrate
10. D Magnesium oxide
6. Which metal does not react with dilute nitric acid?
12. A Calcium
13. B Iron
14. C Silver
15. D Zinc
7. Which metal produces most bubbles of hydrogen gas when placed in hydrochloric acid?
17. A Calcium
18. B Iron
19. C Lead
20. D Zinc
8. Four metals, iron, zinc, copper and magnesium were placed in separate test tubes containing equal volume of dilute hydrochloric acid at room temperature as shown in the diagrams below.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Place the metals in order of reactivity with the most reactive metal first:

- A Copper, iron, magnesium, zinc
- B Magnesium, zinc, iron, copper
- C Copper, iron, zinc, magnesium
- D Magnesium, iron, zinc, copper

## STRUCTURED QUESTIONS

1. What do you understand by the term reactivity series?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- 2 . A student carried out some experiments to investigate the reactivity of three different metals A , B and C .

| Metal   | With cold water   | With hot water           | With steam               |
|---------|-------------------|--------------------------|--------------------------|
| A       | slow reaction     | rapid reaction           | very vigorous reaction   |
| B       | vigorous reaction | experiment not attempted | experiment not attempted |
| C       | no reaction       | no reaction              | no reaction              |

Use the Table to deduce the order of the reactivity of the three metals.

most reactive

least reactive

Justify your answer.

3. Describe what is observed when:

- (a) a piece of copper wire is heated in air.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  a piece of sodium is added to a trough containing water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Some metals are shown below.

silver

aluminium

calcium

- magnesium

potassium

zinc

Choose from the list to answer the following questions (a metal can be used once, more than once or not at all)

- (a)  Name the most reactive metal.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  Name the least reactive metal.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Name one metal which does not react with dilute sulfuric acid.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Name a metal which burns with a white flame.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (e)  Name a metal which reacts explosively with cold water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (f ) Name a metal which has an unreactive oxide layer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (g)  Name a metal which reacts vigorously with steam but very slowly with cold water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (h)  Name a metal which reacts neither with cold water nor with steam.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

5. In the laboratory, an experiment was set up using magnesium metal.

<!-- image -->

## Experiment I

- (a) What would you observe when magnesium reacts with dilute hydrochloric acid?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) Magnesium is replaced by zinc in Experiment II. How would the observation of the reaction differ? Draw diagrams to illustrate this difference.

- (c)  Write a balanced chemical equation for the reaction between magnesium and hydrochloric acid.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) When a piece of aluminium foil is added to hydrochloric acid, there is no reaction. Suggest why.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

magnesium

motal

dilute

## Learning Outcomes

## At the end of this unit, you should be able to:

- Define neutralisation as a chemical reaction between an acid and a base to form a salt and water
- Describe the application of neutralisation reaction in the treatment of indigestion, insect stings, soil and acidic gases
- Describe the general rules of solubility for common salts to include nitrates, chlorides (including  silver  and  lead),  sulfates  (including  barium,  calcium  and  lead),  carbonates, potassium, sodium and ammonium salts
- State  the  applications  of  the  following  salts  in  everyday  life:  sodium  chloride  (for enhancement  of  taste),  ammonium  sulfate  and  potassium  nitrate  (as  fertilisers), magnesium sulfate and sodium sulfate (as laxatives), sodium bicarbonate (in baking), sodium carbonate (for making glass) and calcium sulfate (in plaster of Paris)

An important chemical reaction involving acids and bases is neutralisation reaction. In this unit, you will learn the applications of neutralisation reaction and the uses of salts in everyday life.

## Acids

You learnt in Grade 8 that acids usually contain hydrogen combined with another element or radical. Table 1 shows the names and formulae of common acids, the formula and name of the other element/radical present and the name of the salt formed from the acids.

Table 1: Common acids

| Acid              | Formula   | Formula of the other element/radical   | Nameofthe other element/ radical   | Nameofsalt formed   |
|-------------------|-----------|----------------------------------------|------------------------------------|---------------------|
| Hydrochloric acid | HCl       | Cl                                     | chlorine                           | chloride            |
| Nitric acid       | HNO 3     | NO 3                                   | nitrate                            | nitrate             |
| Sulfuric acid     | H 2 SO 4  | SO 4                                   | sulfate                            | sulfate             |

Salts

Unit

Unit

Unit

C5

1

Measurement in Science

1

Salts Unit

C 5

<!-- image -->

## Bases and Alkalis

You also learnt in Grade 8 that metal oxides and metal hydroxides are bases. When a base is soluble in water, the solution formed is an alkali .  Alkalis  contain the hydroxide radical (OH) combined with another element or radical. Table 2 shows the names and formulae of alkalis and  their element/radical present.

Table 2: Common alkalis

| Alkali                               | Formula   | Formula of other element/ radical   | Nameofother element/radical   |
|--------------------------------------|-----------|-------------------------------------|-------------------------------|
| Potassium hydroxide                  | KOH       | K                                   | Potassium                     |
| Sodium hydroxide                     | NaOH      | Na                                  | Sodium                        |
| Calcium hydroxide                    | Ca(OH) 2  | Ca                                  | Calcium                       |
| Ammonium hydroxide (aqueous ammonia) | NH 4 OH   | NH 4                                | Ammonium                      |

## Neutralisation Reaction

A solution can be acidic, neutral or alkaline. When the right quantity (or volume) of an alkali is added to an acid or vice versa, the resulting solution becomes neutral . A neutral solution is  neither  acidic  nor  alkaline  in  nature.  This  reaction  is  called neutralisation  reaction .  A neutralisation reaction is when an acid and a base react to form a salt and water.

i.e

ACID + METAL OXIDE                    SAL T + WATER

or

ACID + METAL HYDROXIDE                 SAL T   + WATER

ACID + BASE            SALT + WATER

<!-- image -->

Table  3  provides  a  list  of  word  equations.  Study  Table  3  carefully  and  identify  which of these word  equations are examples of neutralisation reaction by placing a tick (          ) or a cross (        ) in Table 3 where it is appropriate.

Table 3: Identifying neutralisation reaction

| Chemical reactions                                           | Neutralisation Reaction   |
|--------------------------------------------------------------|---------------------------|
| magnesium +hydrochloric acid magnesium chloride +hydrogen    |                           |
| magnesium oxide +hydrochloric acid magnesium chloride +water |                           |
| sulfur +oxygen sulfur dioxide                                |                           |
| hydrogen +oxygen water                                       |                           |
| potassium hydroxide +sulfuric acid potassium sulfate +water  |                           |
| zinc oxide +nitric acid zinc nitrate +water                  |                           |

<!-- image -->

## WHAT I HAVE LEARNT

- Neutralisation reaction is a chemical reaction between an acid and a base to form a salt and water.

<!-- image -->

## Importance of Neutralisation Reaction

Neutralisation reaction is an important chemical reaction because of its daily life applications in various fields such as health, agriculture and industries. In this activity, you will apply your understanding of neutralisation to explain its importance in treatment of indigestion, insect stings, soil and acidic gases.

<!-- image -->

## ACTIVITY 5.1 - Appreciating the importance of neutralisation reaction

Read each scenario and information sheet to answer the questions that follow.

## Scenario 1: Treatment of indigestion

<!-- image -->

Gastric  juice  is  released  by  the  wall  of  the stomach  during  digestion  of  food.  Gastric juice  contains  hydrochloric  acid.  Overeating and  stress  can  produce  excess  acid  in  the stomach which may cause a pain commonly known as indigestion.

## Information sheet

<!-- image -->

In order to treat indigestion, antacids are used as medicines. One example of antacids is milk of magnesia which contains  magnesium hydroxide.

- (a)  What substance causes indigestion in the stomach?
- (b)   What is the active ingredient in antacids?
- (c)  What type of reaction occurs during the treatment of indigestion? Justify your answer.

## Scenario 2: Treatment of insect stings

<!-- image -->

Bee and wasp stings are common and painful. The venom released may develop into severe allergic reactions if not treated.

<!-- image -->

## Information sheet

<!-- image -->

Bee sting can be neutralised using a paste of baking  soda  (sodium  hydrogen  carbonate, NaHCO 3 ) which is basic.

Wasp sting can be neutralised using vinegar (ethanoic acid) or lemon juice.

<!-- image -->

- (a)  Are the constituents of bee and wasp venom the same?

Justify your answer.

- (b) Is bee venom acidic or basic?

Justify your answer.

- (c)  Is wasp venom acidic or basic? Justify your answer.

<!-- image -->

## Scenario 3: Treatment of soil

In this image we can see the sky, trees, plants, grass, and the clouds.

<!-- image -->

Most plants grow best when the soil is neutral or  slightly  acidic. These  plants  will  not  grow if the soil is too acidic. Soil tends to be more acidic  due  to  the  use  of  excess  fertilisers  or due to acid rain.

## Information sheet

<!-- image -->

When the soil is too acidic, it can be treated with bases such as calcium oxide (quicklime) or calcium hydroxide (slaked lime). This process is called 'liming' of soil.

However,  if  excess  lime  is  added,  the  soil becomes  alkaline  and  unsuitable  for  plant growth.

- (a)  Why is it important to control the acidity or alkalinity of soil?
- (b) What is the effect of adding excess fertiliser to soil?
- (c)  Name the process which reduces the acidity of soil.
- (d) State a precaution that needs to be taken during the process you mentioned in part (c).

## Scenario 4: Treatment of acidic gases

<!-- image -->

Sulfur dioxide and nitrogen dioxide  react with oxygen  and  moisture  in  the  atmosphere  to form sulfuric acid and nitric acid respectively. This leads to acid rain.

## Information sheet

<!-- image -->

Sulfur dioxide and nitrogen dioxide are acidic gases.  Thus,  calcium  carbonate  (limestone), calcium oxide or calcium hydroxide can be  used  to  absorb  the  acidic  gases  and reduce the emission of acidic gases into the atmosphere.

- (a)  Identify a major source of sulfur dioxide.
- (b) Why must acidic gases be treated before they are released into the atmosphere?
- (c)  (i) Give two substances that can be used to reduce emissions of acidic gases.
- (ii)   Why the two substances mentioned in (c)(i) can be used to reduce the emission of acidic gases?

<!-- image -->

## WHAT I HAVE LEARNT WHAT I HAVE LEARNT

- Neutralisation reaction has important applications in our daily life. For example:
- -To treat indigestion, the excess of acid in the stomach can be neutralised by a weak base such as magnesium hydroxide present in antacids.
- -Bee sting is acidic and can be neutralised by a base such as baking soda.
- -Wasp sting is alkaline and can be neutralised by lemon or vinegar as they are acidic.
- -Soil acidity is reduced by adding lime (calcium oxide) or slaked lime (calcium hydroxide).
- -Acidic gases that can be neutralised  with a base.

Unit

C5

## Solubility of Salts

Some salts dissolve in water while others do not. For example, sodium chloride dissolves in water to form a clear solution whereas lead (II) chloride does not dissolve in water and forms a suspension. In Grade 8, you learnt how to distinguish between solution and suspension.

The ability of a solute to dissolve in a solvent is referred to as its solubility .  In the following activity, you will predict the solubility of salts in water at room temperature using Figure 1.

Figure 1: The solubility rules

In this image, we can see a chart. In this chart, we can see some text.

<!-- image -->

<!-- image -->

## ACTIVITY 5.2  - Classifying salts as soluble and insoluble

Use the solubility rules in Figure 1 to classify the following salts as soluble or insoluble in water by encircling the correct word. The first one has been done for you.

In this image I can see a bowl and a black color bowl.

<!-- image -->

soluble / insoluble

soluble / insoluble

soluble / insoluble

<!-- image -->

## zinc chloride

soluble / insoluble

<!-- image -->

## iron (II) sulfate

soluble / insoluble

<!-- image -->

## ammonium carbonate

soluble / insoluble

<!-- image -->

## silver chloride

soluble / insoluble

<!-- image -->

## barium sulfate

soluble / insoluble

<!-- image -->

## copper (II) carbonate

soluble / insoluble

<!-- image -->

## lead (II) chloride

soluble / insoluble

<!-- image -->

## copper (II) sulfate

soluble / insoluble

<!-- image -->

## potassium carbonate

soluble / insoluble

<!-- image -->

Unit

C5

## Uses of Salts

Salts have many commercial uses as shown in Table 4 .

Table 4: Uses of Salts

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| SALTS                                            | APPLICATION                      |
|--------------------------------------------------|----------------------------------|
| • Magnesium sulfate • Sodium sulfate             | Used as laxative                 |
| • Calcium sulfate                                | Used to make plaster of Paris    |
| • Sodium carbonate                               | Used in the manufacture of glass |
| • Sodium chloride                                | Add taste to food                |
| • Ammonium sulfate • Potassium nitrate           | Used as fertilisers              |
| • Sodium hydrogen carbonate (sodium bicarbonate) | Used for baking                  |

<!-- image -->

## DID YOU KNOW…

Chemical fertilisers are  compounds  containing high concentration of nutrients required for plant growth.  Apart  from  the  three  main  constituent elements,  carbon,  oxygen  and  hydrogen,  plants require  a  substantial  quantity  of  nutrients.  These nutrients are classified as primary nutrients (nitrogen, phosphorus and potassium), secondary nutrients  (calcium,  magnesium  and  sulfur),  and micronutrients (chlorine, zinc, iron and copper).

## DICTIONARY CORNER

A laxative is a substance that eases evacuation of the bowels.

<!-- image -->

## WHAT I HAVE LEARNT

- A soluble salt can dissolve completely in water to form a clear solution.
- An insoluble salt does not dissolve in water.
- Solubility rules can be used to identify soluble and insoluble salts.
- Salts have various applications. For example:
- -for enhancement of taste (sodium chloride)
- -as fertilisers (ammonium sulfate and potassium nitrate)
- -as laxatives (magnesium sulfate and sodium sulfate)
- -in baking (sodium bicarbonate)
- -for making glass (sodium carbonate)
- -in plaster of Paris (calcium sulfate)

Unit

C5

## Summary of unit

- Neutralisation reaction is a chemical reaction between an acid and a base to form a salt and water.
- Neutralisation reactions have important applications such as:
- -To treat indigestion, excess acid in the stomach is neutralised by a weak base such as magnesium hydroxide present in antacids
- -Bee sting can be neutralised by a base such as baking soda (sodium hydrogen carbonate)
- -Wasp sting can be neutralised by vinegar as it contains ethanoic acid
- -The emission of sulfur dioxide and nitrogen dioxide can be reduced by the reaction of these gases with a base
- A  soluble  salt  dissolves  completely  in  water  to  form  a  clear  solution  whereas  an insoluble salt forms a suspension.
- Solubility rules can be used to identify soluble and insoluble salts.
- Salts have various applications:
- -for enhancement of taste (sodium chloride)
- -as fertilisers (ammonium sulfate and potassium nitrate)
- -as laxatives (magnesium sulfate and sodium sulfate)
- -in baking (sodium bicarbonate)
- -for making glass (sodium carbonate)
- -in plaster of Paris (calcium sulfate)

In this image we can see a chart with some text and some images.

<!-- image -->

## Multiple choice questions

## Circle the correct answer.

1. What are the products of neutralisation reaction?
2. A A metal hydroxide and water
3. B A salt and hydrogen
4. C A salt and water
5. D A metal oxide and carbon dioxide
2. Which chemical equation represents a neutralisation reaction?
7. A Ca + 2H 2 O           Ca(OH) 2 + H 2
8. B 2Mg + O 2 2MgO
9. C NaOH + HCl         NaCl + H 2 O
10. D NH 4 Cl + NaOH         NaCl + H 2 O + NH 3
3. Which compound dissolves in water to form a blue solution?
12. A Copper (II) carbonate
13. B Lead (II) sulfate
14. C Copper (II) sulfate
15. D Lead (II) carbonate
4. Which compound dissolves in water to form a clear solution?
17. A Calcium carbonate
18. B Iron (II) carbonate
19. C Copper (II) carbonate
20. D Sodium carbonate
5. All \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ salts are soluble except that of silver and lead.
22. A carbonate
23. B chloride
24. C sulfate
25. D nitrate
6. Which compound can be used to treat wasp sting?
27. A Vinegar
28. B Water
29. C Kitchen salt
7. Which statement is true about 'liming' of soil?
31. A Decrease acidity of soil
32. B The soil is too alkaline
33. C Fertiliser is added to the soil
34. D Increase acidity of the soil
8. Which substance can be used to promote plant growth and increase crop yield?
36. A Magnesium sulfate
37. B Ammonium nitrate
38. C Sodium chloride
39. D Calcium carbonate
40. D Baking soda

## STRUCTURED QUESTIONS

1. (a) Write the chemical name of baking soda.

- (b)   Write the chemical formula of baking soda.

- (c) State a chemical property of baking soda.

- (d) State two uses of baking soda.

2. Many salts are useful and find their application in daily life. Fill in the blanks with the name of the appropriate salts.

- (a) is used as a laxative.

- (b) is used to enhance taste.

(c)

is used as fertilisers.

- (d) is used in the manufacture of glass.

(e)

is used in plaster of Paris.

3. (a) In your copybook, classify the following salts as soluble or insoluble in water.

- (b)  In your copybook, describe an experiment to determine whether calcium sulfate is soluble or insoluble in water at room temperature.

sodium carbonate      calcium carbonate       lead (II) chloride        lead (II) nitrate copper (II) carbonate         copper (II) chloride       silver chloride        zinc sulfate barium sulfate         lithium nitrate        ammonium sulfate

4. When lead is added to hydrochloric acid, a reaction occurs but stops after some time.

In this image, we can see a diagram with some text and a few lines.

<!-- image -->

- (a)  Suggest a reason why the reaction stops after some time.

- (b)  Suggest what happens when lead is added to sulfuric acid.

5. You are provided with a list of compounds below.

From the list, identify the following:

- (a) An acid   -

- (b)  An alkali   -

- (c) An insoluble base  -

- (d)  A white salt which is soluble in water   -

- (e)  A white insoluble salt  -

- (f ) A coloured insoluble salt  -

zinc chloride            copper (II) sulfate            lead (II) chloride          copper (II) carbonate

hydrochloric acid                        sodium hydroxide                           zinc oxide

dilute hydrochloric

acid

lead

layer  of lead (II) chloride

surrounding lead

In this image we can see a group of objects. There are some objects on the table. There are some objects on the table. There is a person's hand on the table. There are some objects on the table. There is a light.

<!-- image -->