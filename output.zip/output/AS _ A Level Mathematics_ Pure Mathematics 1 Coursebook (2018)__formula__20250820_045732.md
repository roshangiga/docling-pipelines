<!-- image -->

<!-- image -->

Sue Pemberton Series Editor: Julian Gilbey

Cambridge International AS &amp; A Level Mathematics:

## Pure Mathematics 1

Coursebook

Cambridge resources

Completely

1

Cambridge

## Sue Pemberton

Series Editor: Julian Gilbey

Cambridge International AS &amp; A Level Mathematics:

## Pure Mathematics 1 Coursebook

<!-- image -->

University Printing House, Cambridge CB2 8BS, United Kingdom

One Liberty Plaza, 20th Floor, New York, NY 10006, USA

477 Williamstown Road, Port Melbourne, VIC 3207, Australia

314-321, 3rd Floor, Plot 3, Splendor Forum, Jasola District Centre, New Delhi - 110025, India

79 Anson Road, #06-04/06, Singapore 079906

Cambridge University Press is part of the University of Cambridge.

It furthers the University's mission by disseminating knowledge in the pursuit of education, learning and research at the highest international levels of excellence.

www.cambridge.org

Information on this title: www.cambridge.org/9781108407144

## © Cambridge University Press 2018

This publication is in copyright. Subject to statutory exception and to the provisions of relevant collective licensing agreements, no reproduction of any part may take place without the written permission of Cambridge University Press.

First published 2018

20  19  18  17  16  15  14  13  12  11  10  9  8  7  6  5  4  3  2  1

Printed in the United Kingdom by Latimer Trend

A catalogue record for this publication is available from the British Library

## ISBN 978-1-108-40714-4 Paperback

Cambridge University Press has no responsibility for the persistence or accuracy of URLs for external or third-party internet websites referred to in this publication, and does not guarantee that any content on such websites is, or will remain, accurate or appropriate. Information regarding prices, travel timetables, and other factual information given in this work is correct at the time of first printing but Cambridge University Press does not guarantee the accuracy of such information thereafter.

## ® IGCSE is a registered trademark

Past exam paper questions throughout are reproduced by permission of Cambridge Assessment International Education. Cambridge Assessment International Education bears no responsibility for the example answers to questions taken from its past question papers which are contained in this publication.

The questions, example answers, marks awarded and/or comments that appear in this book were written by the author(s). In examination, the way marks would be awarded to answers like these may be different.

## NOTICE TO TEACHERS IN THE UK

It is illegal to reproduce any part of this work in material form (including photocopying and electronic storage) except under the following circumstances:

- (i)       where you are abiding by a licence granted to your school or institution by the Copyright Licensing Agency;
- (ii)    where no such licence exists, or where you wish to exceed the terms of a licence, and you have gained the written permission of Cambridge University Press;
- (iii)   where you are allowed to reproduce without permission under the provisions of Chapter 3 of the Copyright, Designs and Patents Act 1988, which covers, for example, the reproduction of short passages within certain types of educational anthology and reproduction for the purposes of setting examination questions.

## Contents

| Series introduction              | Series introduction                                           | vi   |
|----------------------------------|---------------------------------------------------------------|------|
| How to use this book             | How to use this book                                          | viii |
| Acknowledgements                 | Acknowledgements                                              | x    |
| 1 Quadratics                     | 1 Quadratics                                                  | 1    |
| 1.1                              | Solving quadratic equations by factorisation                  | 3    |
| 1.2                              | Completing the square                                         | 6    |
| 1.3                              | The quadratic formula                                         | 10   |
| 1.4                              | Solving simultaneous equations (one linear and one quadratic) | 11   |
| 1.5                              | Solving more complex quadratic equations                      | 15   |
| 1.6                              | Maximum and minimum values of a quadratic function            | 17   |
| 1.7                              | Solving quadratic inequalities                                | 21   |
| 1.8                              | The number of roots of a quadratic equation                   | 24   |
| 1.9                              | Intersection of a line and a quadratic curve                  | 27   |
| End-of-chapter review exercise 1 | End-of-chapter review exercise 1                              | 31   |
| 2 Functions                      | 2 Functions                                                   | 33   |
| 2.1                              | Definition of a function                                      | 34   |
| 2.2                              | Composite functions                                           | 39   |
| 2.3                              | Inverse functions                                             | 43   |
| 2.4                              | The graph of a function and its inverse                       | 48   |
| 2.5                              | Transformations of functions                                  | 51   |
| 2.6                              | Reflections                                                   | 55   |
| 2.7                              | Stretches                                                     | 57   |
| 2.8                              | Combined transformations                                      | 59   |
| End-of-chapter review exercise 2 | End-of-chapter review exercise 2                              | 67   |
| 3 Coordinate geometry            | 3 Coordinate geometry                                         | 70   |
| 3.1                              | Length of a line segment and midpoint                         | 72   |
| 3.2                              | Parallel and perpendicular lines                              | 75   |
| 3.3                              | Equations of straight lines                                   | 78   |
| 3.4                              | The equation of a circle                                      | 82   |
| 3.5                              | Problems involving intersections of lines and circles         | 88   |
| End-of-chapter review exercise 3 | End-of-chapter review exercise 3                              | 92   |

iv

| Cross-topic review exercise 1    | Cross-topic review exercise 1           |   95 |
|----------------------------------|-----------------------------------------|------|
| 4 Circular measure               | 4 Circular measure                      |   99 |
| 4.1                              | Radians                                 |  101 |
| 4.2                              | Length of an arc                        |  104 |
| 4.3                              | Area of a sector                        |  107 |
| End-of-chapter review exercise 4 | End-of-chapter review exercise 4        |  112 |
| 5 Trigonometry                   | 5 Trigonometry                          |  116 |
| 5.1                              | Angles between ° 0 and ° 90             |  118 |
| 5.2                              | The general definition of an angle      |  121 |
| 5.3                              | Trigonometric ratios of general angles  |  123 |
| 5.4                              | Graphs of trigonometric functions       |  127 |
| 5.5                              | Inverse trigonometric functions         |  136 |
| 5.6                              | Trigonometric equations                 |  140 |
| 5.7                              | Trigonometric identities                |  145 |
| 5.8                              | Further trigonometric equations         |  149 |
| End-of-chapter review exercise 5 | End-of-chapter review exercise 5        |  153 |
| 6 Series                         | 6 Series                                |  155 |
| 6.1                              | Binomial expansion of + a b n ( )       |  156 |
| 6.2                              | Binomial coefficients                   |  160 |
| 6.3                              | Arithmetic progressions                 |  166 |
| 6.4                              | Geometric progressions                  |  171 |
| 6.5                              | Infinite geometric series               |  175 |
| 6.6                              | Further arithmetic and geometric series |  180 |
| End-of-chapter review exercise 6 | End-of-chapter review exercise 6        |  183 |
| Cross-topic review exercise 2    | Cross-topic review exercise 2           |  186 |
| 7 Differentiation                | 7 Differentiation                       |  190 |
| 7.1                              | Derivatives and gradient functions      |  191 |
| 7.2                              | The chain rule                          |  198 |
| 7.3                              | Tangents and normals                    |  201 |
| 7.4                              | Second derivatives                      |  205 |
| End-of-chapter review exercise 7 | End-of-chapter review exercise 7        |  209 |

| 8 Further differentiation        | 8 Further differentiation                           |   211 |
|----------------------------------|-----------------------------------------------------|-------|
| 8.1                              | Increasing and decreasing functions                 |   213 |
| 8.2                              | Stationary points                                   |   216 |
| 8.3                              | Practical maximum and minimum problems              |   221 |
| 8.4                              | Rates of change                                     |   227 |
| 8.5                              | Practical applications of connected rates of change |   230 |
| End-of-chapter review exercise 8 | End-of-chapter review exercise 8                    |   235 |
| 9 Integration                    | 9 Integration                                       |   238 |
| 9.1                              | Integration as the reverse of differentiation       |   239 |
| 9.2                              | Finding the constant of integration                 |   244 |
| 9.3                              | Integration of expressions of the form ax b n ( ) + |   247 |
| 9.4                              | Further indefinite integration                      |   249 |
| 9.5                              | Definite integration                                |   250 |
| 9.6                              | Area under a curve                                  |   253 |
| 9.7                              | Area bounded by a curve and a line or by two curves |   260 |
| 9.8                              | Improper integrals                                  |   264 |
| 9.9                              | Volumes of revolution                               |   268 |
| End-of-chapter review exercise 9 | End-of-chapter review exercise 9                    |   276 |
| Cross-topic review exercise 3    | Cross-topic review exercise 3                       |   280 |
| Practice exam-style paper        | Practice exam-style paper                           |   284 |
| Answers                          | Answers                                             |   286 |
| Glossary                         | Glossary                                            |   317 |

Index

319

v

vi

## Series introduction

Cambridge International AS &amp; A Level Mathematics can be a life-changing course. On the one hand, it is a facilitating subject: there are many university courses that either require an A Level or equivalent qualification in mathematics or prefer applicants who have it. On the other hand, it will help you to learn to think more precisely and logically, while also encouraging creativity. Doing mathematics can be like doing art: just as an artist needs to master her tools (use of the paintbrush, for example) and understand theoretical ideas (perspective, colour wheels and so on), so does a mathematician (using tools such as algebra and calculus, which you will learn about in this course). But this is only the technical side: the joy in art comes through creativity, when the artist uses her tools to express ideas in novel ways. Mathematics is very similar: the tools are needed, but the deep joy in the subject comes through solving problems.

You might wonder what a mathematical 'problem' is. This is a very good question, and many people have offered different answers. You might like to write down your own thoughts on this question, and reflect on how they change as you progress through this course. One possible idea is that a mathematical problem is a mathematical question that you do not immediately know how to answer. (If you do know how to answer it immediately, then we might call it an 'exercise' instead.) Such a problem will take time to answer: you may have to try different approaches, using different tools or ideas, on your own or with others, until you finally discover a way into it. This may take minutes, hours, days or weeks to achieve, and your sense of achievement may well grow with the effort it has taken.

In addition to the mathematical tools that you will learn in this course, the problem-solving skills that you will develop will also help you throughout life, whatever you end up doing. It is very common to be faced with problems, be it in science, engineering, mathematics, accountancy, law or beyond, and having the confidence to systematically work your way through them will be very useful.

This series of Cambridge International AS &amp; A Level Mathematics coursebooks, written for the Cambridge Assessment International Education syllabus for examination from 2020, will support you both to learn the mathematics required for these examinations and to develop your mathematical problem-solving skills. The new examinations may well include more unfamiliar questions than in the past, and having these skills will allow you to approach such questions with curiosity and confidence.

In addition to problem solving, there are two other key concepts that Cambridge Assessment International Education have introduced in this syllabus: namely communication and mathematical modelling. These appear in various forms throughout the coursebooks.

Communication in speech, writing and drawing lies at the heart of what it is to be human, and this is no less true in mathematics. While there is a temptation to think of mathematics as only existing in a dry, written form in textbooks, nothing could be further from the truth: mathematical communication comes in many forms, and discussing mathematical ideas with colleagues is a major part of every mathematician's working life. As you study this course, you will work on many problems. Exploring them or struggling with them together with a classmate will help you both to develop your understanding and thinking, as well as improving your (mathematical) communication skills. And being able to convince someone that your reasoning is correct, initially verbally and then in writing, forms the heart of the mathematical skill of 'proof'.

Mathematical modelling is where mathematics meets the 'real world'. There are many situations where people need to make predictions or to understand what is happening in the world, and mathematics frequently provides tools to assist with this. Mathematicians will look at the real world situation and attempt to capture the key aspects of it in the form of equations, thereby building a model of reality. They will use this model to make predictions, and where possible test these against reality. If necessary, they will then attempt to improve the model in order to make better predictions. Examples include weather prediction and climate change modelling, forensic science (to understand what happened at an accident or crime scene), modelling population change in the human, animal and plant kingdoms, modelling aircraft and ship behaviour, modelling financial markets and many others. In this course, we will be developing tools which are vital for modelling many of these situations.

To support you in your learning, these coursebooks have a variety of new features, for example:

- ■ Explore activities: These activities are designed to offer problems for classroom use. They require thought and deliberation: some introduce a new idea, others will extend your thinking, while others can support consolidation. The activities are often best approached by working in small groups and then sharing your ideas with each other and the class, as they are not generally routine in nature. This is one of the ways in which you can develop problemsolving skills and confidence in handling unfamiliar questions.
- ■ Questions labelled as P , M or PS : These are questions with a particular emphasis on 'Proof', 'Modelling' or 'Problem solving'. They are designed to support you in preparing for the new style of examination. They may or may not be harder than other questions in the exercise.
- ■ The language of the explanatory sections makes much more use of the words 'we', 'us' and 'our' than in previous coursebooks. This language invites and encourages you to be an active participant rather than an observer, simply following instructions ('you do this, then you do that'). It is also the way that professional mathematicians usually write about mathematics. The new examinations may well present you with unfamiliar questions, and if you are used to being active in your mathematics, you will stand a better chance of being able to successfully handle such challenges.

At various points in the books, there are also web links to relevant Underground Mathematics resources, which can be found on the free undergroundmathematics.org website. Underground Mathematics has the aim of producing engaging, rich materials for all students of Cambridge International AS &amp; A Level Mathematics and similar qualifications. These high-quality resources have the potential to simultaneously develop your mathematical thinking skills and your fluency in techniques, so we do encourage you to make good use of them.

We wish you every success as you embark on this course.

Julian Gilbey London, 2018

Past exam paper questions throughout are reproduced by permission of Cambridge Assessment International Education. Cambridge Assessment International Education bears no responsibility for the example answers to questions taken from its past question papers which are contained in this publication.

The questions, example answers, marks awarded and/or comments that appear in this book were written by the author(s). In examination, the way marks would be awarded to answers like these may be different.

vii

viii

## How to use this book

Throughout this book you will notice particular features that are designed to help your learning. This section provides a brief overview of these features.

## In this chapter you will learn how to:

## PREREQUISITE KNOWLEDGE

- use the expansion of (a + b)" . where positive integer
- recognise arithmetic and geometric progressions
- solve problems involving arithmetic or gcometric progressions
- use the condition for the convergence of geometric progression, and the formula for the sum to infinity of convergent geometric progression.

Learning objectives indicate the important concepts within each chapter and help you to navigate through the coursebook.

## KEY POINT 1.4

If we multiply or divide both sides of an inequality by negative number then the inequality sign must be reversed.

In this image there is a table with some text and numbers.

<!-- image -->

| Where it comes [rom                    | What vou should be able to do             | Check vour skills   |
|----------------------------------------|-------------------------------------------|---------------------|
| IGCSE 0 Level Mathematics              | Solve quadratic equations by factorising. | Solve. 17 = 6 = 0   |
| IGCSE 0 Level Mathematics              |                                           | Solve. 5x = 8 > 2   |
| IGCSF 0 Level Mathematics              | Solve simultaneous linear equations,      | Solve. 2r + 3y = 13 |
| IGCSE / 0 Level Additional Mathematics | Carry out simple manipulation of surds.   | Simplify- v5)-      |

Key point boxes contain a summary of the most important methods, facts and formulae.

## completing the square

Key terms are important terms in the topic that you are learning. They are highlighted in orange bold. The glossary contains clear definitions of these key terms.

In this image, we can see a question paper with some numbers written on it.

<!-- image -->

Explore boxes contain enrichment activities for extension work. These activities promote group work and peerto-peer discussion, and are intended to deepen your understanding of a concept. (Answers to the Explore questions are provided in the Teacher's Resource.)

Prerequisite knowledge exercises identify prior learning that you need to have covered before starting the chapter. Try the questions to identify any areas that you need to review before continuing with the chapter.

In this image there is a text written on the right side.

<!-- image -->

Worked examples provide step-by-step approaches to answering questions. The left   side shows a fully worked solution, while the right side contains a commentary explaining each step in the working.

<!-- image -->

Tip boxes contain helpful guidance about calculating or checking your answers.

## REWIND

## FAST FORWARD

In Section 2.5 we learnt about the inverse of a function. Here we will look at the particular case of the inverse of a trigonometric function.

In the Pure Mathematics 2 and 3 Coursebook, Chapter 7, you will learn how to expand these expressions for any real value of n .

Rewind and Fast forward boxes direct you to related learning. Rewind boxes refer to earlier learning, in case you need to revise a topic. Fast forward boxes refer to topics that you will cover at a later stage, in case you would like to extend your study.

<!-- image -->

and latitude.  Horizontal' circles and vertical' circles form the `grid'\_ and latitude.

Did you know? boxes contain interesting facts showing how Mathematics relates to the wider world.

## Checklist of learning and understanding

Binomial expansions

- the lormulae

At the end of each chapter there is a Checklist of

## learning and understanding .

The checklist contains a summary of the concepts that were covered in the chapter. You can use this to quickly check that you have covered the main topics.

- car of mass 1500kg is on straight horizonta road The car accelerates from 20ms-1to 24ms-in IOs. The car has constant driving force and there is resistance of I0O Find the size of the driving force
- point and moves in straight line until 40s later it reaches point Y . which 145m from X For Os &lt;1 &lt;5s the particle accelerates at 30s remains at constant 40s decclcrates constant rate. but docs not

## Cross-topic review exercises appear aft  er

several chapters, and cover topics from across the preceding chapters.

E

Extension material goes beyond the syllabus. It is highlighted by a red line to the left   of the text.

## WEB LINK

Try the Sequences and Counting and Binomial resources on the Underground Mathematics website.

Web link boxes contain links to useful resources on the internet.

Throughout each chapter there are multiple exercises containing practice questions. The questions are coded:

- PS These questions focus on problem-solving.
- P These questions focus on proofs.
- M These questions focus on modelling.
- You should not use a calculator for these questions.
- You can use a calculator for these questions.
- These questions are taken from past examination papers.

The End-of-chapter review contains exam-style questions covering all topics in the chapter. You can use this to check your understanding of the topics you have covered. The number of marks gives an indication of how long you should be spending on the question. You should spend more time on questions with higher mark allocations; questions with only one or two marks should not need you to spend time doing complicated calculations or writing long explanations.

<!-- image -->

ix

x

## Acknowledgements

The authors and publishers acknowledge the following sources of copyright material and are grateful for the permissions granted. While every effort has been made, it has not always been possible to identify the sources of all the material used, or to trace all copyright holders. If any omissions are brought to our notice, we will be happy to include the appropriate acknowledgements on reprinting.

Past examination questions throughout are reproduced by permission of Cambridge Assessment International Education.

The following questions are used by permission of the Underground Mathematics website: Exercise 1F Question 9, Exercise 3C Question 16, Exercise 3E Questions 6 and 7, Exercise 4B Question 10.

Thanks to the following for permission to reproduce images:

Cover image iStock/Getty Images

Inside ( in order of appearance ) English Heritage/Heritage Images/Getty Images, Sean Russell/Getty Images, Gopinath Duraisamy/EyeEm/Getty Images, Frank Fell/robertharding/Getty Images, Fred Icke/EyeEm/Getty Images, Ralph Grunewald/Getty Images, Gustavo Miranda Holley/Getty Images, shannonstent/Getty Images, wragg/Getty Images, Dimitrios Pikros/EyeEm/Getty Images

In this image we can see a bridge, lights, buildings, water, and the sky.

<!-- image -->

## Chapter   1 Quadratics

## In this chapter you will learn how to:

- ■ carry out the process of completing the square for a quadratic polynomial 2 ax bx c + + and use a completed square form
- ■ solve quadratic equations, and quadratic inequalities, in one unknown
- ■ fi  nd the discriminant of a quadratic polynomial 2 ax bx c + + and use the discriminant
- ■ solve by substitution a pair of simultaneous equations of which one is linear and one is quadratic
- ■ understand the relationship between a graph of a quadratic function and its associated algebraic equation, and use the relationship between points of intersection of graphs and solutions of equations.
- ■ recognise and solve equations in x that are quadratic in some function of x

2

## PREREQUISITE KNOWLEDGE

| Where it comes from                   | What you should be able to do             | Check your skills                                                           |
|---------------------------------------|-------------------------------------------|-----------------------------------------------------------------------------|
| IGCSE ® / OLevel Mathematics          | Solve quadratic equations by factorising. | 1 Solve: a x x 12 0 2 + - = b x x 6 9 0 2 - + = c x x 3 17 6 0 2 - - =      |
| IGCSE / OLevel Mathematics            | Solve linear inequalities.                | 2 Solve: a 5 8 2 . x - b 3 2 7 ø x -                                        |
| IGCSE / OLevel Mathematics            | Solve simultaneous linear equations.      | 3 Solve: a x y 2 3 13 + = x y 7 5 1 - = - b x y 2 7 31 - = x y 3 5 31 + = - |
| IGCSE / OLevel Additional Mathematics | Carry out simple manipulation of surds.   | 4 Simplify: a 20 b ( 5) 2 c 8 2                                             |

## Why do we study quadratics?

At IGCSE / O Level, you will have learnt about straight-line graphs and their properties. They arise in the world around you. For example, a cell phone contract might involve a fixed monthly charge and then a certain cost per minute for calls: the monthly cost, y , is then given as y mx c = + , where c is the fixed monthly charge, m is the cost per minute and x is the number of minutes used.

Quadratic functions are of the form y ax bx c 2 = + + (where a 0 ≠ ) and they have interesting properties that make them behave very differently from linear functions. A quadratic function has a maximum or a minimum value, and its graph has interesting symmetry. Studying quadratics offers a route into thinking about more complicated functions such as y x x x x 7 4 3 5 4 2 = -+ + + .

You will have plotted graphs of quadratics such as y x 10 2 = -before starting your A Level course. These are most familiar as the shape of the path of a ball as it travels through the air (called its trajectory ). Discovering that the trajectory is a quadratic was one of Galileo's major successes in the early 17th century. He also discovered that the vertical motion of a ball thrown straight upwards can be modelled by a quadratic, as you will learn if you go on to study the Mechanics component.

<!-- image -->

## WEB LINK

Try the Quadratics resource on the Underground Mathematics website (www.underground mathematics.org).

## 1.1  Solving quadratic equations by factorisation

You already know the factorisation method and the quadratic formula method to solve quadratic equations algebraically.

This section consolidates and builds on your previous work on solving quadratic equations by factorisation.

## EXPLORE 1.1

This is Rosa's solution to the previous equation: Factorise the left-hand side: -+ = --+ = -= -x x x x x x x ( 1)(2 5) ( 1)( 2) 2 5 2 7 Divide both sides by ( 1) -x : Rearrange: Discuss her solution with your classmates and explain why her solution is not fully correct. Now solve the equation correctly. x x x x 2 3 5 ( 1)( 2) 2 + -= --

## WORKED EXAMPLE 1.1

```
Solve: a x x 6 5 17 2 + = b x x 9 39 30 0 2 --= Answer a 6 5 17 6 17 5 0 (2 5)(3 1) 0 2 5 0 or 3 1 0 2 2 x x x x x x x x + = -+ = --= -= -= Write in the form ax bx c 0 2 + + = . Factorise. Use the fact that if pq 0 = , then p 0 = or q 0 = . Solve. x x 5 2 or 1 3 = = b 9 39 30 0 3 13 10 0 (3 2)( 5) 0 3 2 0 or 5 0 2 2 x x x x x x x x --= --= + -= + = -= Divide both sides by the common factor of 3. Factorise. Solve. x x 2 3 or 5 = -=
```

TIP

Divide by a common factor first, if possible.

3

4

## WORKED EXAMPLE 1.2

$$\Big | \ \text{ Solve } \frac { 2 1 } { 2 x } - \frac { 2 } { x + 3 } = 1.$$

x x 2 3 . Answer x x x x x x x x x x x x 21 2 2 3 1 21( 3) 4 2 ( 3) 2 11 63 0 (2 7)( 9) 0 2 7 0 or 9 0 2 -+ = + -= + --= + -= + = -= Multiply both sides by x x 2 ( 3) + . Expand brackets and rearrange. Factorise. Solve. x x 7 2 or 9 = -=

## WORKED EXAMPLE 1.3

$$<_ObjectiveC_>$$

## WORKED EXAMPLE 1.4

<!-- image -->

A rectangle has sides of length x cm and x (6 7)cm - .

The area of the rectangle is 90 cm 2 .

Find the lengths of the sides of the rectangle.

## Answer

Area (6 7) 6 7 90 2 = - = - = x x x x

6 7 90 0 2 - - = x x

(2 9)(3 10) 0 - + = x x

2 9 0 or 3 10 0 - = + = x x

Rearrange.

Factorise.

Solve.

$$x = \frac { 9 } { 2 } \quad \text{or} \quad x = - \frac { 10 } { 3 } \quad \text{or}$$

Length is a positive quantity, so x 4 1 2 = .

When x 4 1 2 = , - = x 6 7 20.

The rectangle has sides of length 4 1 cm 2 and 20 cm.

6 x -7

x

## EXPLORE 1.2

<!-- image -->

- 1 Discuss with your classmates how you would solve each of these equations.
- 2 Solve:
- a equation A
- b equation B
- 3 State how many values of x satisfy:
- a equation A
- b equation B
- 4 Discuss your results.
- c equation C
- c equation C

TIP

Remember to check each of your answers.

5

6

## EXERCISE 1A

- 1 Solve by factorisation.
- a x x 3 10 0 2 + -=
- d x x 5 19 12 0 2 + + =
- 2 Solve:
- a x 6 0 -=
- c x x x 5 1 2 1 2 -=
- e 3 1 2 + =

$$& x - \frac { 6 } { x - 5 } = 0 \\ & \colon \frac { 5 x + 1 } { 4 } - \frac { 2 x - 1 } { 2 } = \colon \\ & \colon \frac { 3 } { x + 1 } + \frac { 1 } { x ( x + 1 ) } = \\ & \cdot \cdot \dots$$

- 3 Solve:
- a x x x x 3 10 7 6 0 2 2 + --+ =
- b x x 7 12 0 2 -+ =
- e x x 20 7 6 2 -=
- c x x 6 16 0 2 --=
- f x x (10 13) 3 -=

$$b \ \frac { 2 } { x } + \frac { 3 } { x + 2 } = 1$$

$$b & \ \frac { 2 } { x } + \frac { 3 } { x + 2 } = 1 \\ d & \ \frac { 5 } { x + 3 } + \frac { 3 x } { x + 4 } = 2 \\ f & \ \frac { 3 } { x + 2 } + \frac { 1 } { x - 1 } = \frac { 1 } { ( x + 1 ) ( x + 2 ) }$$

- b x x 6 0 2 2 + -=

$$\overline { \ x ^ { 2 } + 5 }$$

- d x x x x 2 8 7 10 0 2 2 --+ + =

$$\mathfrak { c } \ \frac { x ^ { 2 } - 9 } { 7 x + 1 0 } = 0 \\ \mathfrak { f } \ \frac { 2 x ^ { 2 } + 9 x - 5 } { x ^ { 4 } + 1 } =$$

- e x x x x 6 2 7 4 0 2 2 + -+ + =
- 4 Find the real solutions of the following equations.
- a = + -8 1 ( 2 15) 2 x x
- b = -+ 4 1 (2 11 15) 2 x x
- d = + + 3 1 9 (2 9 2) 2 x x
- e x x ( 2 14) 1 2 5 + -=
- 5 The diagram shows a right-angled triangle with sides x 2 cm, x (2 1) cm + and 29cm.
- a Show that x x 2 210 0. 2 + -=
- b Find the lengths of the sides of the triangle.
- 6 The area of the trapezium is 35.75cm 2 . Find the value of x .

$$\begin{matrix} 7 & \text{Solve } ( x ^ { 2 } - 1 1 x + 2 9 ) ^ { ( 6 x ^ { 2 } + x - 2 ) } = 1. \end{matrix}$$

<!-- image -->

## 1.2  Completing the square

Another method we can use for solving quadratic equations is completing the square .

The method of completing the square aims to rewrite a quadratic expression using only one occurrence of the variable, making it an easier expression to work with.

If we expand the expressions x d ( ) 2 + and x d ( ) 2 -, we obtain the results:

$$( x + d ) ^ { 2 } = x ^ { 2 } + 2 d x + d ^ { 2 } \text{ and } ( x - d ) ^ { 2 } = x ^ { 2 } - 2 d x + d ^ { 2 }$$

$$f \ \frac { 2 x ^ { 2 } + 9 x - 5 } { x ^ { 4 } + 1 } = 0$$

$$c _ { \ } 2 ^ { ( x ^ { 2 } - 4 x + 6 ) } = 8$$

- f x x ( 7 11) 1 2 8 -+ =

<!-- image -->

<!-- image -->

## TIP

Check that your answers satisfy the original equation.

## WEB LINK

Try the Factorisable quadratics resource on the Underground Mathematics website.

Rearranging these gives the following important results:

## KEY POINT 1.1

$$\Big | \quad x ^ { 2 } + 2 d x = ( x + d ) ^ { 2 } - d ^ { 2 } \text{ and } x ^ { 2 } - 2 d x = ( x - d ) ^ { 2 } - d ^ { 2 }$$

To complete the square for x x 10 2 + , we can use the first of the previous results as follows:

$$\begin{smallmatrix} \mu & \mu \\ 1 0 \div 2 = 5 \\ \swarrow & \searrow \\ x ^ { 2 } + 1 0 x = ( x + 5 ) ^ { 2 } - 5 ^ { 2 } \\ x ^ { 2 } + 1 0 x = ( x + 5 ) ^ { 2 } - 2 5 \end{smallmatrix}$$

To complete the square for

x

8

2

+

part, as follows:

$$r \dots, \dots \dots \dots. \\ 8 \div 2 = 4 \\ x ^ { 2 } + 8 x - 7 = ( x + 4 ) ^ { 2 } - 4 ^ { 2 } - 7 \\ x ^ { 2 } + 8 x - 7 = ( x + 4 ) ^ { 2 } - 2 3 \\.$$

2

To complete the square for x x 2 12 5 -+ , we must first take a factor of 2 out of the first two terms, so:

$$\begin{array} {$$

We can also use an algebraic method for completing the square, as shown in Worked example 1.5.

## WORKED EXAMPLE 1.5

Express x x 2 12 3 2 -+ in the form p x q r ( ) , 2 -+ where p , q and r are constants to be found.

## Answer

$$2 x ^ { 2 } - 1 2 x + 3 = p ( x - q ) ^ { 2$$

$$<_Python_> = p q ^ { 2 } + r \, \dots \, \d$$

Expanding the brackets and simplifying gives: x x px pqx pq r 2 12 3 2 2 2 2 -+ = -+ + Comparing coefficients of x x , coefficients of 2 and the constant gives p = 2 (1) pq -= -12 2 (2) Substituting = p 2  in equation (2) gives = q 3 Substituting = p 2  and = q 3 in equation (3) therefore gives = -r 15 x x x -+ = --2 12 3 2( 3) 15 2 2

x

-

7

, we again use the first result applied to the

x

2

+

8

x

7

8

## WORKED EXAMPLE 1.6

Express x x + + 4 20 5 2 in the form ax b c + + ( ) , 2 where a , b and c are constants to be found. Answer + + = + + 4 20 5 ( ) 2 2 x x ax b c Expanding the brackets and simplifying gives: + + = + + + 4 20 5 2 2 2 2 2 x x a x abx b c Comparing coefficients of , coefficients of 2 x x and the constant gives = 4 2 a (1) = 20 2 ab (2) = + 5 2 b c (3) Equation (1) gives = ± a 2. Substituting = 2 a into equation (2) gives = 5 b . Substituting = 5 b into equation (3) gives = -20 c . + + = + -4 20 5 (2 5) 20 2 2 x x x Alternatively: Substituting = -2 a into equation (2) gives = -5 b . Substituting = -5 b into equation (3) gives = -20 c . + + = ---= + -4 20 5 ( 2 5) 20 (2 5) 20 2 2 2 x x x x

## WORKED EXAMPLE 1.7

Use completing the square to solve the equation + = 5 3 1.

x x + -2 5

Leave your answers in surd form.

## Answer

+ + -= -+ + = + --+ = -    -    + = -    = -= ± = ± = ± 5 2 3 5 1 5( 5) 3( 2) ( 2)( 5) 11 9 0 11 2 11 2 9 0 11 2 85 4 11 2 85 4 11 2 85 2 1 2 (11 85) 2 2 2 2 x x x x x x x x x x x x x Multiply both sides by x x + -( 2)( 5). Expand brackets and collect terms. Complete the square.

## EXERCISE 1B

- 1 Express each of the following in the form x a b + + ( ) . 2
- a x x -6 2 b x x 8 2 +
- c x x 3 2 -
- e x x 4 8 2 + + f x x 4 8 2 --g x x 7 1 2 + +
- 2 Express each of the following in the form a x b c + + ( ) . 2
- a x x -+ 2 12 19 2 b x x --3 12 1 2 c x x + -2 5 1 2
- 3 Express each of the following in the form a x b -+ ( ) . 2
- a x x -4 2
- b x x -8 2
- c x x --4 3 2
- 4 Express each of the following in the form p q x r -+ ( ) . 2
- a x x --7 8 2 2 b x x --3 12 2 2 c x x + -13 4 2 2
- d x x 15 2 +
- h x x -+ 3 4 2
- d x x + + 2 7 5 2
- d x x + -9 5
- 2
- d x x + -2 5 3 2
- 5 Express each of the following in the form + + ( ) 2 ax b c .
- a --x x 9 6 3 2 b + + x x 4 20 30 2 c + -x x 25 40 4 2 d -+ x x 9 42 61 2
- 6 Solve by completing the square.
- a x x + -= 8 9 0 2 b x x + -= 4 12 0 2
- c x x --= 2 35 0 2
- d x x -+ = 9 14 0 2 e x x + -= 3 18 0 2
- f x x + -= 9 10 0 2
- 7 Solve by completing the square. Leave your answers in surd form.
- a x x + -= 4 7 0 2 b x x -+ = 10 2 0 2
- c x x + -= 8 1 0 2
- d x x --= 2 4 5 0 2 e x x + + = 2 6 3 0 2
- 8 Solve x x + + -= 5 2 3 4 2. Leave your answers in surd form.
- 9 The diagram shows a right-angled triangle with sides x m, x (2 5) m + and 10 m. PS

Find the value of x . Leave your answer in surd form.

- f x x --= 2 8 3 0 2
- 10 Find the real solutions of the equation x x + -= (3 5 7) 1. 2 4 PS
- 11 The path of a projectile is given by the equation y x x = -( 3) 49 9000 2 , where x and y are measured in metres. PS
- a Find the range of this projectile.
- b Find the maximum height reached by this projectile.

<!-- image -->

In this image, we can see a graph. There are two points on the graph.

<!-- image -->

## TIP

You will learn how to derive formulae such as this if you go on to study Further Mathematics  .

9

10

## 1.3  The quadratic formula

We can solve quadratic equations using the quadratic formula .

If ax bx c 0, 2 + + = where a , b and c are constants and a 0, ≠ then

## KEY POINT 1.2

$$x = \frac { - b \pm \sqrt { b ^ { 2 } - 4 a c$$

The quadratic formula can be proved by completing the square for the equation ax bx c

+ + = 0: 2

$$\begin{array} { l l l } \text{The quadratic formula can be proved by$$

## WORKED EXAMPLE 1.8

Solve the equation x x --= 6 3 2 0. 2

Write your answers correct to 3 significant figures.

## Answer

Using a = 6, b = -3  and c = -2  in the quadratic formula gives:

$$\begin{array} { c c c } & & \\ & x = \frac { - ( - 3 ) \pm \sqrt { - 3 } ^ { 2 } - 4 \times 6 \times ( - 2 ) } { 2 \times 6 } \\ & & & - & - & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & &  & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & \\ & & & & \\ & & & & \\ & & & \\ & & & \\ & & & & \\ & & & \\ & & & \\ & & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & & \\ & & \\ & & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & & \\ & & & \\ & & \\ & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & \\ & & \\ & & & \\ & & \\ & & \\ & & & \\ & & \\ & & \\ & & & \\ & \\ & & & \\ & & \\ & & \\ & & & \\ & \\ & & & \\ & & \\ & & \\ & & & \\ & \\ & & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & \\ & & \\ & & \\ & \\ & & \\ & & \\ & \\ & & \\ & & \\ & \\ & & \\ & & \\ & \\ & & \\ & \\ & & \\ & \\ & \\ & & \\ & \\ & & \\ & \\ & & \\ & \\ & \\ & & \\ & \\ & \\ & \\ & \\ & \\ & & \\ & \\ & \\ & \\ & & \\ & \\ & \\ & \\ & \\ & \\ & & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ &
 \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ &;$$

$$\begin{array} { c } | & & 3 + \sqrt { 5 7 } & 1 2 & 2 & 3 - \sqrt { 5 7 } & 1 2 \end{array}$$

x = 0.879 or x = -0.379  (to 3 significant figures)

Divide both sides by a .

Complete the square.

Rearrange the equation.

Write the right-hand side as a single fraction.

Find the square root of both sides.

$$<_SQL_> 	Subtract$$

Write the right-hand side as a single fraction.

## EXERCISE 1C

- 1 Solve using the quadratic formula. Give your answer correct to 2 decimal places.
- 2 A rectangle has sides of length x cm and x (3 2)cm -.
- The area of the rectangle is 63cm 2 .
- Find the value of x , correct to 3 significant figures.
- 3 Rectangle A has sides of length x cm and x (2 4)cm -.
- Rectangle B has sides of length x ( 1) cm + and x (5 ) cm -.
- Rectangle A and rectangle B have the same area.
- Find the value of x , correct to 3 significant figures.
- 4 Solve the equation + + = 5 2
- x x -3 1 1.
- Give your answers correct to 3 significant figures.
- 5 Solve the quadratic equation ax bx c -+ = 0 2 , giving your answers in terms of a , b and c .
- How do the solutions of this equation relate to the solutions of the equation ax bx c + + = 0 2 ?

- a x x - - = 10 3 0 2

- b x x + + = 6 4 0 2

- c x x + - = 3 5 0 2

- d x x + - = 2 5 6 0 2 e x x + + = 4 7 2 0 2

- f x x + - = 5 7 2 0 2

## 1.4  Solving simultaneous equations (one linear and one quadratic)

In this section, we shall learn how to solve simultaneous equations where one equation is linear and the second equation is quadratic.

In this image, we can see a diagram. There is a line, which is represented by a symbol. We can also see a point, which is represented by a symbol. We can also see a line, which is represented by a symbol. We can see a point, which is represented by a symbol. We can see a line, which is represented by a symbol. We can see a point, which is represented by a symbol. We can see a line, which is represented by a symbol. We can see a point, which is represented by a symbol. We can see a line, which is represented by a symbol. We can see a point, which is represented by a symbol. We can see a line, which is represented by a symbol. We can see a point, which is represented by a symbol. We can see a line, which is represented by a symbol. We can see a point, which is represented by a symbol. We can see a line, which

<!-- image -->

The diagram shows the graphs of y x = -4 2 and y x = -2 1.

The coordinates of the points of intersection of the two graphs are --( 1, 3) and (3, 5).

It follows that x y = -= -1, 3  and x y = = 3, 5  are the solutions of the simultaneous equations y x = -4 2 and y x = -2 1.

<!-- image -->

## WEB LINK

Try the Quadratic solving sorter resource on the Underground Mathematics website.

11

12

The solutions can also be found algebraically:

$$y & = x ^ { 2 } - 4 \, \dots \, \dots \, \dots \, ( 1 ) \\ y & = 2 x - 1 \, \dots \, \dots \, ( 2 )$$

Substitute for y from equation (2) into equation (1):

$$\begin{matrix} \cdot & \cdot \\ 2 x - 1 = x ^ { 2 } - 4 \\ x ^ { 2 } - 2 x - 3 = 0 \\ ( x + 1 ) ( x - 3 ) = 0 \\ x = - 1 \text{ or } x = 3 \\ \wedge \cdot & \cdot \cdot & \cdot \cdot \end{matrix}$$

Rearrange.

Factorise.

Substituting x = -1 into equation (2) gives y = --= -2 1 3.

Substituting x = 3  into equation (2) gives y = -= 6 1 5.

The solutions are: x y = -= -1, 3  and x y = = 3, 5.

In general, an equation in x and y is called quadratic if it has the form ax bxy cy dx ey f + + + + + = 0 2 2 , where at least one of a b , and c is non-zero.

Our technique for solving one linear and one quadratic equation will work for these more general quadratics, too. (The graph of a general quadratic function such as this is called a conic . )

## WORKED EXAMPLE 1.9

```
Solve the simultaneous equations. x y x y + = -= 2 2 7 4 8 2 2 Answer 2 2 7 (1) 4 8 (2) 2 2 x y x y + = -= From equation (1), x y = -7 2 2 . Substitute for x in equation (2): 7 2 2 4 8 49 28 4 4 4 8 49 28 4 16 32 12 28 17 0 (6 17)(2 1) 0 17 6 or 1 2 2 2 2 2 2 2 2 y y y y y y y y y y y y y y -    -= -+ -= -+ -= + -= + -= = -= Expand brackets. Multiply both sides by 4. Rearrange. Factorise. Substituting y = -17 6 in equation (1) gives = x 19 3 .
```

Substituting y = 1 2 into equation (1) gives x = 3. The solutions are: x y = = -19 3 , 17 6 and x y = = 3, 1 2 . Alternative method: From equation (1), y x = -2 7 2 . Substitute for y 2 in equation (2): (7 2 ) 8 49 28 4 8 3 28 57 0 (3 19)( 3) 0 19 3 or 3 2 2 2 2 2 x x x x x x x x x x x --= -+ -= -+ = --= = = Expand brackets. Rearrange. Factorise. The solutions are: x y = = -19 3 , 17 6 and = = x y 3, 1 2 .

## EXERCISE 1D

- 1 Solve the simultaneous equations.
- 2 The sum of two numbers is 26. The product of the two numbers is 153.
- a What are the two numbers?
- b If instead the product is 150 (and the sum is still 26), what would the two numbers now be?
- 3 The perimeter of a rectangle is 15.8cm and its area is 13.5 cm 2 . Find the lengths of the sides of the rectangle.

- a y x = - 6 y x = 2 b x y + = 4 6 x xy + = 2 8 2 c y x = + 3 10 x y + = 100 2 2 d y x = - 3 1 x xy - = 8 2 4 2 e x y - = 2 6 x xy - = 4 20 2 f x y - = 4 3 5 x xy + = 3 10 2 g x y + = 2 8 xy = 8 h y x - = 2 5 x y - = 2 3 15 2 2 i x y + = 2 6 x y xy + + = 4 24 2 2 j x y - = 5 2 23 x xy y - + = 5 1 2 2 k x y - = 4 2 xy = 12 l x y - = 2 14 y x = + 8 4 2 m x y + + = 2 3 19 0 x y + = 2 3 5 2 n x y + = 2 5 x y + = 10 2 2 o x y - = 12 30 y xy - = 2 20 2

13

14

- 4 The sum of the perimeters of two squares is 50 cm and the sum of the areas is 93.25cm 2 .
- Find the side length of each square.
- 5 The sum of the circumferences of two circles is 36 cm π and the sum of the areas is 170 cm 2 π .
- Find the radius of each circle.
- 6 A cuboid has sides of length 5cm, x cm and y cm. Given that x y + = 20.5  and the volume of the cuboid is 360 cm 3 , find the value of x and the value of y .
- 7 The diagram shows a solid formed by joining a hemisphere, of radius r cm, to a cylinder, of radius r cm and height h cm.
- The total height of the solid is 18 cm and the surface area is 205 cm 2 π .
- Find the value of r and the value of h .
- 8 The line y x x y = --= 2 cuts the curve 5 20 2 2 at the points A and B .
- a Find the coordinates of the points A and B .
- b Find the length of the line AB .
- 9 The line x y + = 2 5 1 meets the curve x xy y + -+ = 5 4 10 0 2 2 at the points A and B .
- a Find the coordinates of the points A and B .
- b Find the midpoint of the line AB .
- 10 The line x y + = -7 2 20  intersects the curve x y x y + + + -= 4 6 40 0 2 2 at the points A and B . Find the length of the line AB .
- 11 The line y x x y -= + = 7 25 cuts the curve 25 2 2 at the points A and B
- Find the equation of the perpendicular bisector of the line AB
- . .
- 12 The straight line y x = + 1 intersects the curve x y -= 5 2 at the points A and B . Given that A lies below the x -axis and the point P lies on AB such that AP PB : 4 : 1 = , find the coordinates of P .
- 13 The line x y 2 1 -= intersects the curve x y 9 2 + = at two points, A and B .
- Find the equation of the perpendicular bisector of the line AB .
- 14  a Split 10 into two parts so that the difference between the squares of the parts is 60. PS
- b Split N into two parts so that the difference between the squares of the parts is D .

<!-- image -->

## TIP

The surface area, A , of a sphere with radius r is A r = π 4 2 .

<!-- image -->

## WEB LINK

Try the Elliptical crossings resource on the Underground Mathematics website.

## 1.5  Solving more complex quadratic equations

You may be asked to solve an equation that is quadratic in some function of x .

## WORKED EXAMPLE 1.10

Solve the equation x x 4 37 9 0. 4 2 -+ = Answer Method 1: Substitution method 4 37 9 0 Let . 4 37 9 0 (4 1)( 9) 0 1 4 or 9 1 4 or 9 1 2 or 3 4 2 2 2 2 2 -+ = = -+ = --= = = = = = ± = ± x x y x y y y y y y x x x x Method 2: Factorise directly x x x x x x x x 4 37 9 0 (4 1)( 9) 0 1 4 or 9 1 2 or 3 4 2 2 2 2 2 -+ = --= = = = ± = ± Substitute x 2 for y .

## WORKED EXAMPLE 1.11

Solve the equation x x 4 12 0. --= Answer 4 12 Let . 0 4 12 0 ( 6)( 2) 0 6 or 2 6 or 2 2 --= = --= -+ = = = -= = -x x y x y y y y y y x x Substitute x for y . x ∴ = 36 x 2 = -has no solutions as x is never negative.

15

16

## WORKED EXAMPLE 1.12

Solve the equation  3(9 ) 28(3 ) 9 0. -+ = x x

## Answer

3(3 ) 28(3 ) 9 0 2 x x -+ =

- 3 28 9 0 2 y y -+ =

(3 1)( 9) 0 y y --=

- 1 3 or 9 y y = =
- 3 1 3 or 3 9 x x = =
- 1 or 2 x x = -=

## EXERCISE 1E

- 1 Find the real values of x that satisfy the following equations.
- 3 The curve y x 2 = and the line y x 3 8 = + intersect at the points A and B .
- a Write down an equation satis fied by the x -coordinates of A and B .
- b Solve your equation in part a and, hence, find the coordinates of A and B .
- c Find the length of the line AB .
- 4 The graph shows y ax b x c = + + for x ù 0. The graph crosses the x -axis at the points  1, 0 ( ) and 49 4 , 0     and it meets the y -axis at the point (0, 7). Find the value of a , the value of b and the value of c . PS

- a x x - + = 13 36 0 4 2

- b x x - - = 7 8 0 6 3

- c x x - + = 6 5 0 4 2

- d x x - + = 2 11 5 0 4 2

- e x x + - = 3 4 0 4 2

- f x x - + = 8 9 1 0 6 3

- g x x + - = 2 15 0 4 2

- h x x + + = 9 14 0 4 2

- i x x - - = 15 16 0 8 4

- j x x - - = 32 31 1 0 10 5 x x

- k + = 9 5 4 4 2

- l x x + = 8 7 1 6 3

- 2 Solve:

- a x x - + = 2 9 10 0

- b x x + = ( 1) 6

- c x x 6 17 5 0 - + =

- d x x 10 2 0 + - =

- e x x 8 5 14 + =

- f x x 3 5 16 + =

Let y x = 3 .

Substitute x 3  for y .

= -1 3 3 1 and = 9 3 2 .

<!-- image -->

<!-- image -->

- 5 The graph shows y a b c x x (2 ) (2 ) 2 = + +
- . The graph crosses the axes at the points (2, 0), (4, 0) and (0, 90). Find the value of a , the value of b and the value of c .

## 1.6  Maximum and minimum values of a quadratic function

The general form of a quadratic function is x ax bx c f( ) 2 = + + , where a , b and c are constants and a 0 ≠ .

The shape of the graph of the function x ax bx c f( ) 2 = + + is called a parabola . The orientation of the parabola depends on the value of a , the coef ficient of x 2 .

<!-- image -->

<!-- image -->

If 0 . a , the curve has a minimum point that occurs at the lowest point of the curve.

If 0 , a , the curve has a maximum point that occurs at the highest point of the curve.

In the case of a parabola, we also call this point the vertex of the parabola.

Every parabola has a line of symmetry that passes through the vertex.

One important skill that we will develop during this course is 'graph sketching'.

A sketch graph needs to show the key features and behaviour of a function.

When we sketch the graph of a quadratic function, the key features are:

- /uni25CF the general shape of the graph
- /uni25CF the axis intercepts
- /uni25CF the coordinates of the vertex.

Depending on the context we should show some or all of these.

The skills you developed earlier in this chapter should enable you to draw a clear sketch graph for any quadratic function.

<!-- image -->

## TIP

A point where the gradient is zero is called a stationary point or a turning point .

<!-- image -->

## WEB LINK

Try the Quadratic symmetry resource on the Underground Mathematics website for a further explanation of this.

17

18

## DID YOU KNOW?

<!-- image -->

If we rotate a parabola about its axis of symmetry, we obtain a three-dimensional shape called a paraboloid . Satellite dishes are paraboloid shapes. They have the special property that light rays are reflected to meet at a single point, if they are parallel to the axis of symmetry of the dish. This single point is called the focus of the satellite dish. A receiver at the focus of the paraboloid then picks up all the information entering the dish.

## WORKED EXAMPLE 1.13

For the function x x x f( ) 3 4 2 = --:

- a Find the axes crossing points for the graph of y x f( ) = .
- b Sketch the graph of y x f( ) = an d find the coordinates of the vertex.

## Answer

- a y x x 3 4 2 = --

When 0, 4 = = -x y

When

y

x

x

0,

3

2

=

-

(

x

-

x

1)(

4

4)

0

0

+

-

=

=

x

x

1or

4

= -

=

Axes crossing points are: (0, 4), ( 1, 0) and (4, 0). --

- b The line of symmetry cuts the x -axis midway between the axis intercepts of 1 -and 4.

<!-- image -->

Hence, the line of symmetry is x 3 2 = .

$$\text{When } x = \frac { 3 } { 2 }, y = \left ( \frac { 3 } { 2 } \right ) ^ { 2 } - 3 \left ( \frac { 3 } { 2 } \right ) - 4$$

$$y = - \frac { 2 5 } { 4 }.$$

Since 0, . a the curve is U-shaped.

$$<_Python_> Minimum point = ( \frac { 3 } { 2 }, - \frac { 2 5 } { 4 } )$$

TIP

Write your answer in fraction form.

Completing the square is an alternative method that can be used to help sketch the graph of a quadratic function.

Completing the square for x x 3 4 2 --gives:

$$x ^ { 2 } - 3 x - 4 & = \left ( \, x - \frac { 3 } { 2 } \right ) ^ { 2 } - \left ( \frac { 3 } { 2 } \right ) ^ { 2 } - 4 \\ & = \left ( \, x - \frac { 3 } { 2 } \right ) ^ { 2 } - \frac { 2 5 } { 4 } \\ & \, \stackrel { \bullet } { \bullet } \stackrel { \bullet } { \bullet } \stackrel { \bullet } { \bullet } \stackrel { \bullet } { \bullet } \stackrel { \bullet } { \bullet } \stackrel { \bullet } { \bullet } \stackrel { \bullet } \stackrel { \bullet } \stackrel { \bullet } \stackrel { \bullet } \,.$$

This part of the expression is a square so it will be at least zero. The smallest value it can be is 0. This occurs when x 3 2 = .

The minimum value of x 3 2 25 4 2 -    -is 25 4 -and this minimum occurs when x 3 2 = . So the function x x x f( ) 3 4 2 = --has a minimum point at 3 2 , 25 4 . -    The line of symmetry is 3 . x =

2

## KEY POINT 1.3

If x ax bx c f( ) 2 = + + is written in the form x a x h k f( ) ( ) , 2 = -+ then:

- /uni25CF the line of symmetry is x h b a 2 = = -
- /uni25CF if 0 . a , there is a minimum point at h k ( , )
- /uni25CF if 0 , a , there is a maximum point at h k ( , ).

## WORKED EXAMPLE 1.14

Sketch the graph of y x x 16 7 4 . 2 = --

## Answer

Completing the square gives:

x x x 16 7 4 9 4( 2) 2 2 --= --

The maximum value of x 9 4( 2) 2 --is 9 and this maximum occurs when x 2 = .

So the function x x x f( ) 16 7 4 2 = --has a maximum point at (2, 9).

The line of symmetry is x 2. =

When x 0 = , y 7 = -

When = --= y x 0, 9 4( 2) 0 2

$$( x - 2 ) ^ { 2 } = \frac { 9 } { 4 }.$$

x

-

=

±

2

$$x = 3 # 2 or x = \frac { 1 } { 2 }$$

This part of the expression is a square so x ù ( 2) 0 2 -. The smallest value it can be is 0. This occurs when x 2. = Since this is being subtracted from 9, the whole expression is greatest when x = 2.

In this image, we can see a graph. There is a number line.

<!-- image -->

3

2

19

20

## EXERCISE 1F

- 1 Use the symmetry of each quadratic function t o find the maximum or minimum points.
- Sketch each graph, showing all axes crossing points.
- a y x x 6 8 2 = -+
- b y x x 5 14 2 = + -
- c y x x 2 7 2 = + -
- 15
- 2 a Express x x 2 8 5 2 -+ in the form a x b c ( ) 2 + + , where a , b and c are integers.
- b Write down the equation of the line of symmetry for the graph of y x x 2 8 1 2 = -+ .
- 3 a Express x x 7 5 2 + -in the form a x b ( ) 2 -+ , where a , and b are constants.
- b Find the coordinates of the turning point of the curve y x x 7 5 2 = + -, stating whether it is a maximum or a minimum point.
- 4 a Express x x 2 9 4 2 + + in the form a x b c ( ) 2 + + , where a , b and c are constants.
- b Write down the coordinates of the vertex of the curve y x x 2 9 4 2 = + + , and state whether this is a maximum or a minimum point.
- 5 Find the minimum value of x x 7 8 2 -+ and the corresponding value of x .
- 6 a Write x x 1 2 2 + -in the form p x q 2( ) 2 --.
- b Sketch the graph of y x x 1 2 . 2 = + -
- 7 Prove that the graph of y x x 4 2 5 2 = + + does not intersect the x -axis.
- 8 Find the equations of parabolas A, B and C. PS

In this image, we can see a graph. There are two lines on the graph.

<!-- image -->

-8

- d y x x 12 2 = + -

- 9 The diagram shows eight parabolas. PS

The equations of two of the parabolas are y x x 6 13 2 = -+ and y x x 6 5. 2 = ---

- a Identify these two parabolas an d find the equation of each of the other parabolas.
- b Use graphing software to create your own parabola pattern.

y

In this image we can see a diagram. There are two lines and two points.

<!-- image -->

[This question is an adaptation of Which parabola? on the Underground Mathematics website and was developed from an original idea from NRICH.]

- 10 A parabola passes through the points (0, 24), ( 2, 0) --and (4, 0). PS

Find the equation of the parabola.

- 11 A parabola passes through the points ( 2, 3), (2, 9) --and (6, 5). PS

Find the equation of the parabola.

- 12 Prove that any quadratic that has its vertex at p q ( , ) has an equation of the form y ax apx ap q 2 2 2 = -+ + for some non-zero real number a . P

## 1.7  Solving quadratic inequalities

We already know how to solve linear inequalities.

The following text shows two examples.

Solve  2( 7) 4 , x + - .

Expand brackets.

2 14 4 , x + -

Subtract 14 from both sides.

2 18 , x -

Divide both sides by 2.

9 , x -

Solve 11 2 5 -x ù .

Subtract 11 from both sides.

2 6 --x ù

3 x ø

Divide both sides by 2 -.

21

22

The second of the previous examples uses the important rule that:

## KEY POINT 1.4

If we multiply or divide both sides of an inequality by a negative number, then the inequality sign must be reversed.

Quadratic inequalities can be solved by sketching a graph and considering when the graph is above or below the x -axis.

## WORKED EXAMPLE 1.15

Solve 5 14 0 2 . x x --.

## Answer

Sketch the graph of y x x 5 14 2 = --.

When y x x 0, 5 14 0 2 = --=

x x ( 2)( 7) 0 + -=

x x 2 or 7 = -=

So the x -axis crossing points are 2 -and 7.

For 5 14 0 2 . x x --we need t o find the range of values of x for which the curve is positive (above the x -axis).

The solution is 2 or 7 , . x x -.

## WORKED EXAMPLE 1.16

Solve x x ø 2 3 27 2 + .

## Answer

Rearranging: x x ø 2 3 27 0 2 + -

Sketch the graph of y x x 2 3 27. 2 = + -

When = + - = y x x 0, 2 3 27 0 2

+ - = x x (2 9)( 3) 0

= - = x x 4 or 3 1 2

So the x -axis intercepts are - 4 1 2 and 3.

For x x ø 2 3 27 0 2 + - we need to find the range of values of x for which the curve is either zero or negative (below the x -axis).

&lt; &lt; - x The solution is 4 3. 1 2

In this image, we can see a graph.

<!-- image -->

## TIP

For the sketch graph, you only need to identify which way up the graph is and where the x -intercepts are: you do not need to find the vertex or the y -intercept.

In this image, we can see a graph.

<!-- image -->

## EXPLORE 1.3

x ù 2 4 -

Ivan is asked to solve the inequality x 7. This is his solution: Multiply both sides by x : ù ù ø ---2 4 7 4 5 4 5 x x x x Subtract x 2  from both sides: Divide both sides by 5: Anika checks to see if x 1 = -sati sfies the original inequality. She writes: When = -x 1: --÷ -= (2( 1) 4) ( 1) 6 Hence, = -x 1 is a value of x that does not satisfy the original inequality. So Ivan's solution must be incorrect! Discuss Ivan's solution with your classmates and explain Ivan's error.

How could Ivan have approached this problem to obtain a correct solution?

## EXERCISE 1G

- 1 Solve:
- a x x ø ( 3) 0 -
- d (2 3)( 2) 0 , x x + -
- 2 Solve:
- a x ù 25 0 2 -
- d x x ø 14 17 6 0 2 + -
- 3 Solve:
- a 36 5 2 , x x -
- d 4 3( 2) 2 , x x x + +
- g x ù ( 4) 25 2 +
- 4 Find the range of values of x for which
- 5 Find the set of values of x for which:
- a x x ù 3 10 2 -and ( 5) 4 2 , x -
- b x x ø 4 21 0 2 + -and 9 8 0 2 . x x -+
- c 2 0 2 . x x + -and x x ù 2 3 0 2 --
- 6 Find the range of values of x for which --2 1 3 40 2 x x . .
- b ( 3)( 2) 0 . x x -+
- e x x ù (5 )( 6) 0 -+
- b x x ø 7 10 0 2 + +
- e 6 23 20 0 2 , x x -+
- b 15 56 2 , x x +
- e ( 3)(1 ) 1 , x x x + --
- h ( 2) 14 2 . x x --
- 5 2 15 0. 2 , x x + -
- c x x ø ( 6)( 4) 0 --
- f (1 3 )(2 1) 0 , x x -+
- c 6 7 0 2 . x x + -
- f 4 7 2 0 2 , x x --
- c ( 10) 12 ø x x x + -
- f (4 3)(3 1) 2 ( 3) , x x x x + -+
- i 6 ( 1) 5(7 ) , x x x + -

23

24

<!-- image -->

7 Solve:

$$\begin{bmatrix} 7 & \text{Solve} \colon \\ & a &$$

## 1.8  The number of roots of a quadratic equation

If x f( ) is a function, then we call the solutions to the equation x f( ) 0 = the roots of x f( ).

Consider solving the following three quadratic equations of the form ax bx c 0 2 + + =

$$\underset { \frac { \mu } { \text{using the formula } } x = \$$

$$\begin{array} {$$

The part of the quadratic formula underneath the square root sign is called the discriminant .

## KEY POINT 1.5

The discriminant of + + = 0 2 ax bx c is -4 . 2 b ac

The sign (positive, zero or negative) of the discriminant tells us how many roots there are for a particular quadratic equation.

| - b ac 4 2   | Nature of roots                                |
|--------------|------------------------------------------------|
| 0 .          | two distinct real roots                        |
| 0 =          | two equal real roots (or 1 repeated real root) |
| 0 ,          | no real roots                                  |

There is a connection between the roots of the quadratic equation + + = ax bx c 0 2 and the corresponding curve = + + y ax bx c 2 .

<!-- image -->

<!-- image -->

Copyright Material  - Review Only -  Not for Redistribution

| - b ac 4 2   | Nature of roots of + + + = ax bx c 0 2         | Shape of curve = = + + ax bx c y 2                         |
|--------------|------------------------------------------------|------------------------------------------------------------|
| 0 .          | two distinct real roots                        | The curve cuts the x -axis at two distinct points.         |
| 0 =          | two equal real roots (or 1 repeated real root) | The curve touches the x -axis at one point.                |
| 0 ,          | no real roots                                  | The curve is entirely above or entirely below the x -axis. |

## WORKED EXAMPLE 1.17

k for which the equation x kx 4 1 0 has two equal roots.

```
Find the values of 2 + + = Answer For two equal roots: b ac k k k k 4 0 4 4 1 0 16 4 or 4 2 2 2 -= -× × = = = -=
```

## WORKED EXAMPLE 1.18

Find the values of k for which x x k x 5 9 (5 ) 2 -+ = -has two equal roots.

## Answer

x x k x 5 9 (5 ) 2 -+ = -x x k kx 5 9 5 0 2 -+ -+ = x k x k ( 5) 9 5 0 2 + -+ -= For two equal roots: b ac 4 0 2 -= --× × -= -+ -+ = + -= + -= k k k k k k k k k ( 5) 4 1 (9 5 ) 0 10 25 36 20 0 10 11 0 ( 11)( 1) 0 2 2 2 k k 11 or 1 = -= Rearrange the equation into the form + + = 0 2 ax bx c .

## WORKED EXAMPLE 1.19

Find the values of k for which kx kx 2 8 0 2 -+ = has two distinct roots.

## Answer

$$\begin{array} { c } & k x ^ { 2 } - 2 k x + 8 =$$

For two distinct roots:

b

.

-

ac

4

2

(

2

-

k

)

2

0

-

.

×

×

k

4

8

0

. -k k 4 32 0 2

4

.

-

k k

(

8)

0

Critical values are 0 and 8.

Note that the critical values are where k k 4 ( 8) 0 -= .

Hence, 0 or 8 , . k k .

<!-- image -->

25

26

## EXERCISE 1H

- 1 Find the discriminant for each equation and, hence, decide if the equation has two distinct roots, two equal roots or no real roots.
- 2 Use the discriminant to determine the nature of the roots of x x 2 5 4 . -=
- 3 The equation x bx c 0 2 + + = has roots 5 -and 7. Find the value of b and the value of c .
- 4 Find the values of k for which the following equations have two equal roots.
- 5 Find the values of k for which the following equations have two distinct roots.
- 6 Find the values of k for which the following equations have no real roots.
- a kx x 4 8 0 2 -+ =
- b x x k 3 5 1 0 2 + + + =
- c x x kx 2 8 5 2 2 + -=
- d x k x 2 3( 2) 2 + = -
- e kx kx x 2 4 6 2 + = -
- f kx kx x 3 2 2 + = -
- 7 The equation kx px 5 0 2 + + = has repeated real roots.

- a x x 12 36 0 2 - + =

- b x x 5 36 0 2 + - =

- c x x 9 2 0 2 + + =

- d x x 4 4 1 0 2 - + = e x x 2 7 8 0 2 - + =

- f x x 3 10 2 0 2 + - =

- a x kx 4 0 2 + + =

- b x k x k 4 4( 2) 0 2 + - + =

- c k x k k x ( 2) 4 (4 2) 2 + + = +

- d x x k k 2 1 2 ( 2) 2 - + = -

- e k x kx k ( 1) 2 0 2 + + - =

- f x k x 4 ( 2) 9 0 2 - - + =

- a x x k 8 3 2 + + =

- b x x k 2 5 4 2 - = -

- c kx x 4 2 0 2 - + =

- d kx k x k 2( 1) 0 2 + - + =

- e x x k 2 2( 1) 2 = - +

- f kx k x k (2 5) 1 2 + - = -

Find

k

in terms of

p

.

- 8 Find the range of values of k for which the equation -+ = 5 2 0 2 kx x has real roots.
- 9 Prove that the roots of the equation kx x k 2 5 0 2 + -= are real and distinct for all real values of k . P
- 10 Prove that the roots of the equation x k x k ( 2) 2 0 2 + --= are real and distinct for all real values of k . P
- 11 Prove that x kx 2 0 2 + + = has real roots if k ù 2 2. P

For which other values of k does the equation have real roots?

<!-- image -->

## WEB LINK

Try the Discriminating resource on the Underground Mathematics website.

## 1.9  Intersection of a line and a quadratic curve

When considering the intersection of a straight line and a parabola, there are three possible situations.

In this image there is a graph.

<!-- image -->

| Situation 1                                     | Situation 2                                                                                  | Situation 3                            |
|-------------------------------------------------|----------------------------------------------------------------------------------------------|----------------------------------------|
| two points of intersection                      | one point of intersection                                                                    | no points of intersection              |
| The line cuts the curve at two distinct points. | The line touches the curve at one point. This means that the line is a tangent to the curve. | The line does not intersect the curve. |

We have already learnt that t o find the points of intersection of a straight line and a quadratic curve, we solve their equations simultaneously.

The discriminant of the resulting equation then enables us to say how many points of intersection there are. The three possible situations are shown in the following table.

| - b ac 4 2   | Nature of roots                       | Line and curve                                |
|--------------|---------------------------------------|-----------------------------------------------|
| 0 .          | two distinct real roots               | two distinct points of intersection           |
| 0 =          | two equal real roots (repeated roots) | one point of intersection (line is a tangent) |
| 0 ,          | no real roots                         | no points of intersection                     |

## WORKED EXAMPLE 1.20

Find the value of k for which y x k = + is a tangent to the curve y x x 5 2 2 = + + . Answer x x x k x x k 5 2 4 (2 ) 0 2 2 + + = + + + -= Since the line is a tangent to the curve, the discriminant of the quadratic must be zero, so: b ac k k k k 4 0 4 4 1 (2 ) 0 16 8 4 0 4 8 2 2 2 -= -× × -= -+ = = -= -

28

## WORKED EXAMPLE 1.21

Find the set of values of k for which y kx 1 = -intersects the curve y x x 2 2 = -at two distinct points.

## Answer

$$x ^ { 2 } - 2 x = k x - 1$$

$$\begin{array} { c } & \, \, \,$$

Since the line intersects the curve at two distinct points, we must have discriminant 0 . .

4 0 2 . b ac -

( 2) 4 1 1 0 2 . k + -× ×

4 0 2 . k k +

( 4) 0 . k k +

Critical values are 4 -and 0.

<!-- image -->

-

Hence, , k -4  or 0 . k .

This next example involves a more general quadratic equation. Our techniques fo r finding the conditions for intersection of a straight line and a quadratic equation will work for this more general quadratic equation too.

## WORKED EXAMPLE 1.22

Find the set of values of k for which the line x y k 2 + = does not intersect the curve xy 8 = .

## Answer

Substituting y k x 2 = -into xy 8 = gives:

x k x ( 2 ) 8 -=

x kx 2 8 0 2 -+ =

Since the line and curve do not intersect, we must have discriminant 0 , .

4 0 2 , b ac -

( ) 4 2 8 0 2 , k --× ×

64 0 2 , k -

( 8)( 8) 0 , k k + -

Critical values are 8 -and 8.

<!-- image -->

Hence, 8 8 -k , , .

-

## EXERCISE 1I

- 1 Find the values of k for which the line y kx 1 = + is a tangent to the curve y x x 7 2 2 = -+ .
- 2 Find the values of k for which the x -axis is a tangent to the curve y x k x k ( 3) (3 4) 2 = -+ + + .
+ = = 5
- ? (You may want to use graph-drawing
- 3 Find the value of k for which the line x ky 12 is a tangent to the curve -y x 2 . Can you explain graphically why there is only one such value of k software to help with this.)
- 4 The line y k x 3 = -is a tangent to the curve x xy 2 20 0 2 + -= .
- a Find the possible values of k .
- b For each of these values of k , find the coordinates of the point of contact of the tangent with the curve.
- 5 Find the values of m for which the line y mx 6 = + is a tangent to the curve y x x 4 7 2 = -+ .
- For each of these values of m , find the coordinates of the point where the line touches the curve.
- 6 Find the set of values of k for which the line y x 2 1 = -intersects the curve y x kx 3 2 = + + at two distinct points.
- 7 Find the set of values of k for which the line x y k 2 + = intersects the curve xy 6 = at two distinct points.
- 8 Find the set of values of k for which the line y k x = -cuts the curve y x x 5 3 2 = --at two distinct points.
- 9 Find the set of values of m for which the line y mx 5 = + does not meet the curve y x x 6 2 = -+ .
- 10 Find the set of values of k for which the line y x 2 10 = -does not meet the curve y x x k 6 2 = -+ .
- 11 Find the value of k for which the line y kx 6 = + is a tangent to the curve x y x y 10 8 84 2 2 + -+ = .
- 12 The line y mx c = + is a tangent to the curve y x x 4 4. 2 = -+ P

Prove that m m c 8 4 0. 2 + + =

- 13 The line y mx c = + is a tangent to the curve ax by c , 2 2 + = where a , b , c and m are constants. P
- Prove that m abc a b . 2 = -

29

30

## Checklist of learning and understanding

## Quadratic equations can be solved by:

- /uni25CF factorisation
- /uni25CF completing the square
- /uni25CF using the quadratic formula x b b ac a 4 2 2 = -± -.

## Solving simultaneous equations where one is linear and one is quadratic

- /uni25CF Rearrange the linear equation to make either x or y the subject.
- /uni25CF Substitute this for x or y in the quadratic equation and then solve.

## Maximum and minimum points and lines of symmetry

For a quadratic function x ax bx c f( ) 2 = + + that is written in the form x a x h k f( ) ( ) 2 = -+ :

- /uni25CF the line of symmetry is 2 x h b a = = -
- /uni25CF if 0 . a , there is a minimum point at h k ( , )
- /uni25CF if 0 , a , there is a maximum point at h k ( , ).

## Quadratic equation ax +bx+c= 0 2 and corresponding curve y = ax +bx+c 2

- /uni25CF b ac Discriminant 4 2 = -.
- /uni25CF If 4 0 2 . b ac -, then the equation ax bx c 0 2 + + = has two distinct real roots.
- /uni25CF If b ac 4 0 2 -= , then the equation ax bx c 0 2 + + = has two equal real roots.
- /uni25CF If 4 0 2 , b ac -, then the equation ax bx c 0 2 + + = has no real roots.
- /uni25CF The condition for a quadratic equation to have real roots is b ac ù 4 0. 2 -

## Intersection of a line and a general quadratic curve

- /uni25CF If a line and a general quadratic curve intersect at one point, then the line is a tangent to the curve at that point.
- /uni25CF Solving simultaneously the equations for the line and the curve gives an equation of the form ax bx c 0 2 + + = .
- /uni25CF b ac 4 2 -gives information about the intersection of the line and the curve.

| - b ac 4 2   | Nature of roots         | Line and parabola                             |
|--------------|-------------------------|-----------------------------------------------|
| 0 .          | two distinct real roots | two distinct points of intersection           |
| 0 =          | two equal real roots    | one point of intersection (line is a tangent) |
| 0 ,          | no real roots           | no points of intersection                     |

## END-OF-CHAPTER REVIEW EXERCISE 1

| 1   | Acurve has equation y xy 2 5 = + and a line has equation x y 2 5 1. + =                                                                                        |     |
|-----|----------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
|     | The curve and the line intersect at the points A and B . Find the coordinates of the midpoint of the line AB .                                                 | [4] |
| 2   | a Express x x 9 15 2 - in the form x a b (3 ) 2 - - .                                                                                                          | [2] |
|     | b Find the set of values of x that satisfy the inequality 9 15 6. 2 , x x -                                                                                    | [2] |
| 3   | Find the real roots of the equation x x 36 4 25 4 2 + = .                                                                                                      | [4] |
| 4   | Find the set of values of k for which the line y kx 3 = - intersects the curve y x x 9 2 = - at two distinct points.                                           | [4] |
| 5   | Find the set of values of the constant k for which the line y x k 2 = + meets the curve y kx x 1 2 = + - at two distinct points.                               | [5] |
| 6   | a Find the coordinates of the vertex of the parabola y x x 4 12 7. 2 = - +                                                                                     | [4] |
|     | b Find the values of the constant k for which the line y kx 3 = + is a tangent to the curve y x x 4 12 7. 2 = - +                                              | [3] |
| 7   | Acurve has equation y x x 5 2 2 = - + and a line has equation y x k 2 , = + where k is a constant.                                                             |     |
|     | a Show that the x -coordinates of the points of intersection of the curve and the line are given by the equation x x k 4 (5 ) 0. 2 - + - =                     | [1] |
|     | b For one value of k , the line intersects the curve at two distinct points, A and B , where the coordinates of A are ( 2, 13) - . Find the coordinates of B . | [3] |
|     | c For the case where the line is a tangent to the curve at a point C , find the value of k and the coordinates of C .                                          | [4] |
| 8   | Acurve has equation y x x 5 7 2 = - + and a line has equation y x 2 3. = -                                                                                     |     |
|     | a Show that the curve lies above the x -axis.                                                                                                                  | [3] |
|     | b Find the coordinates of the points of intersection of the line and the curve.                                                                                | [3] |
|     | c Write down the set of values of x that satisfy the inequality 5 7 2 3. 2 , x x x - + -                                                                       | [1] |
| 9   | Acurve has equation y x x 10 . 2 = -                                                                                                                           |     |
|     | a Express x x 10 2 - in the form a x b ( ) 2 - + .                                                                                                             | [3] |
|     | b Write down the coordinates of the vertex of the curve.                                                                                                       | [2] |
|     | c Find the set of values of x for which y ø 9.                                                                                                                 | [3] |
| 10  | Aline has equation y kx 6 = + and a curve has equation y x x k 3 2 , 2 = + + where k is a constant.                                                            |     |
|     | i For the case where k 2, = the line and the curve intersect at points A and B .                                                                               |     |
|     | Find the distance AB and the coordinates of the mid-point of AB .                                                                                              | [5] |
|     | ii Find the two values of k for which the line is a tangent to the curve.                                                                                      | [4] |

31

32

- 11 A curve has equation y x x 4 4 2 = -+ and a line has the equation y mx , = where m is a constant.
- i For the case where m 1, = the curve and the line intersect at the points A and B .
- Find the coordinates of the mid-point of AB .

[4]

- ii Find the non-zero value of m for which the line is a tangent to the curve, an d find the coordinates of the point where the tangent touches the curve.

[5]

- Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 June 2013
- 12 i Express x x 2 4 1 2 -+ in the form a x b c ( ) 2 + + and hence state the coordinates of the minimum point, A , on the curve y x x 2 4 1 2 = -+ . [4]
- The line x y 4 0 -+ = intersects the curve y x x 2 4 1 2 = -+ at the points P and Q .
- It is given that the coordinates of P are  (3, 7).
- ii Find the coordinates of Q .

[3]

- iii Find the equation of the line joining Q to the mid-point of AP
- . [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 June 2011

In this image we can see a bicycle wheel. In the background there is a wall.

<!-- image -->

## Chapter   2 Functions

## In this chapter you will learn how to:

- ■ understand the terms function, domain, range, one-one function, inverse function and composition of functions
- ■ determine whether or not a given function is one-one, and fi  nd the inverse of a one-one function in simple cases
- ■ identify the range of a given function in simple cases , and fi  nd the composition of two given functions
- ■ illustrate in graphical terms the relation between a one-one function and its inverse
- ■ understand and use the transformations of the graph f( ) = y x given by f( ) = + y x a , f( ), = + y x a f( ) y a x = , f( ) = y ax and simple combinations of these.

In this image we can see a part of a building.

<!-- image -->

34

## PREREQUISITE KNOWLEDGE

| Where it comes from        | What you should be able to do          | Check your skills                                          |
|----------------------------|----------------------------------------|------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Find an output for a given function.   | 1 If f( ) 3 2 = - x x , find f(4).                         |
| IGCSE / OLevel Mathematics | Find a composite function.             | 2 If f( ) 2 1 = + x x and g( ) 1 = - x x , find fg( ) x .  |
| IGCSE / OLevel Mathematics | Find the inverse of a simple function. | 3 If f( ) 5 4 = + x x , find f ( ). 1 - x                  |
| Chapter 1                  | Complete the square.                   | 4 Express 2 12 5 2 - + x x in the form ( ) 2 + + a x b c . |

## Why do we study functions?

At IGCSE / O Level, you learnt how to interpret expressions as functions with inputs and outputs an d find simple composite functions and simple inverse functions.

There are many situations in the real world that can be modelled as functions. Some examples are:

- /uni25CF the temperature of a hot drink as it cools over time
- /uni25CF the height of a valve on a bicycle tyre as the bicycle travels along a horizontal road
- /uni25CF the depth of water in a conical container as it is filled from a tap
- /uni25CF the number of bacteria present after the start of an experiment.

Modelling these situations using appropriate functions enables us to make predictions about real-life situations, such as: How long will it take for the number of bacteria to exceed 5 billion?

In this chapter we will develop a deeper understanding of functions and their special properties.

## 2.1  Definition of a function

A function is a relation that uniquely associates members of one set with members of another set.

An alternative name for a function is a mapping .

A function can be either a one-one function or a many-one function.

The function /arrowbarright x x + 2,  where /Rbb x ∈ is an example of a one-one function.

<!-- image -->

Copyright Material  - Review Only -  Not for Redistribution

<!-- image -->

## WEB LINK

Try the Thinking about functions and Combining functions resources on the Underground Mathematics website.

<!-- image -->

/Rbb x ∈ means that x belongs to the set of real numbers.

A one-one function has one output value for each input value. Equally important is the fact that for each output value appearing there is only one input value resulting in this output value.

We can write this function as /arrowbarright + f : 2 x x for /Rbb ∈ x or x x = + f( ) 2  for /Rbb x ∈ .

/arrowbarright + f : 2 x x is read as 'the function f is such that x is mapped to x + 2' or 'f maps x to x + 2'.

x f( ) is the output value of the function f when the input value is x . For example, when x x = + f( ) 2, = + = f(5) 5 2 7.

The function /arrowbarright 2 x x , where /Rbb ∈ x is a many-one function.

<!-- image -->

A many-one function has one output value for each input value but each output value can have more than one input value.

We can write this function as /arrowbarright x x f : 2 for ∈ x /Rbb or x x = f( ) 2 for /Rbb x ∈ .

/arrowbarright x x f : 2 is read as 'the function f is such that x is mapped to x 2 ' or 'f maps x to x 2 '.

If we now consider the graph of y x = 2 :

<!-- image -->

We can see that the input value shown has two output values. This means that this relation is not a function.

The set of input values for a function is called the domain of the function.

When de fining a function, it is important to also specify its domain.

The set of output values for a function is called the range (or codomain) of the function.

35

36

## WORKED EXAMPLE 2.1

x x = -f( ) 5 2 for /Rbb x ∈ , -4 5 x &lt; &lt; .

- a Write down the domain of the function f.
- b Sketch the graph of the function f.
- c Write down the range of the function f.

## Answer

- a The domain is -4 5 x &lt; &lt; .
- b The graph of 5 2 y x = -is a straight line with gradient 2 -and y -intercept 5.

When = -4 x , = --= 5 2( 4) 13 y

When 5 x = , 5 2(5) 5 y = -= -

<!-- image -->

- c The range is 5 f( ) 13 x -&lt; &lt; .

## WORKED EXAMPLE 2.2

The function f is de fined by x x = -+ f( ) ( 3) 8 2 for x &lt; &lt; -1 9.

Sketch the graph of the function.

Find the range of f.

## Answer

f( ) ( 3) 8 2 x x = -+ is a positive quadratic function so the graph

<!-- image -->

will be of the form

<!-- image -->

The minimum value of the expression is  0 8 8 + = and this minimum occurs when 3 x = .

So the function  f( ) ( 3) 8 2 x x = -+ will have a minimum point at the point (3, 8).

When 1 x = - , ( 1 3) 8 24 2 y = - - + =

When 9 x = , (9 3) 8 44 2 y = - + =

The circled part of the expression is a square so it will always be 0 &gt; .

The smallest value it can be is 0.

This occurs when 3 x = .

The image is a diagram showing a graph with two axes labeled as x and y. The x-axis is labeled as "Domain" and the y-axis is labeled as "Range". The graph is a line graph with a minimum value of 0 and a maximum value of 4. The line is drawn from the bottom left to the top right of the graph, with the minimum value at the bottom left and the maximum value at the top right.

<!-- image -->

## EXERCISE 2A

- 1 Which of these graphs represent functions? If the graph represents a function, state whether it is a one-one function or a many-one function.
- a y x = -2 3 for ∈ /Rbb x
- b y x = -3 2 for /Rbb x ∈
- c y x = -2 1 3 for /Rbb x ∈
- e y x = 10 for /Rbb x ∈ , x &gt; 0
- g y x = for /Rbb x ∈ , x &gt; 0
- 2 a Represent on a graph the function:

$$x \mapsto \begin{cases} 9 - x ^ { 2 }$$

- b State the nature of the function.
- 3 a Represent on a graph the relation:
- b Explain why this relation is not a function.
- 4 State the domain and range for the functions represented by these two graphs.
- d y x = 2 for /Rbb x ∈
- f y x = + 3 4 2 for /Rbb x ∈ , x &gt; 0

```
= + -     < < < < 1 for 0 2 2 3 for 2 4 2 y x x x x
```

Copyright Material  - Review Only -  Not for Redistribution

In this image, we can see a graph. There are two lines. On the left side, we can see a graph. On the right side, we can see a graph.

<!-- image -->

$$\mathbf h _ { \ } y ^ { 2 } = 4 x \$$

<!-- image -->

37

38

- 5 Find the range for each of these functions.
- a x x = + f( ) 4    for x &gt; 8
- c x x = -f( ) 7 2 for x &lt; &lt; -1 4
- e x x = f( ) 2 for x &lt; &lt; -5 4
- 6 Find the range for each of these functions.
- a x x = -f( ) 2 2 for /Rbb x ∈
- c x x = -f( ) 3 2 2 for x &lt; 2
- 7 Find the range for each of these functions.
- a x x = -+ f( ) ( 2) 5 2 for x &gt; 2
- b x x = -f( ) 2 7  for x &lt; &lt; -3 2 d /arrowbarright x x f : 2 2 for x &lt; &lt; 1 4 f x = f( ) 12 for x &lt; &lt; 1 8
- x
- b /arrowbarright x x + f : 3 2 for x &lt; &lt; -2 5 d x x = -f( ) 7 3 2 for x &lt; &lt; -1 2
- b x x = --f( ) (2 1) 7 2 for x &gt; 1 2
- c /arrowbarright x x --f : 8 ( 5) 2 for x &lt; &lt; 4 10
- d x x = + -f( ) 1 4         for x &gt; 4
- 8 Express each function in the form 2 a x b c ( ) + + , where a , b and c are constants and, hence, state the range of each function.
- a x x x = + -f( ) 6 11 2 for /Rbb x ∈
- b x x x = -+ f( ) 3 10 2 2 for /Rbb x ∈
- 9 Express each function in the form a b x c -+ ( ) 2 , where a , b and c are constants and, hence, state the range of each function.
- a x x x = --f( ) 7 8 2 for /Rbb x ∈
- b x x x = --f( ) 2 6 3 2 for /Rbb x ∈
- 10  a Represent, on a graph, the function:

$$\mathfrak { f } ( x ) = \begin{cases} 3$$

- b Find the range of the function.
- 11 The function /arrowbarright x x x k + + f : 6 2 , where k is a constant, is de fined for /Rbb x ∈ . Find the range of f in terms of k .
- 12 The function /arrowbarright x ax x --g : 5 2 2 , where a is a constant, is defined for /Rbb x ∈ . Find the range of g in terms of a .
- 13 x x x = --f( ) 2 3 2 for /Rbb x ∈ , a x a &lt; &lt; -If the range of the function f is x &lt; &lt; -4 f( ) 5, find the value of a .
- 14 x x x = + -f( ) 4 2 for /Rbb ∈ x , a x a &lt; &lt; + 3 If the range of the function f is x &lt; &lt; -2 f( ) 16, find the possible values of a .
- 15 x x x = -+ f( ) 2 8 5 2 for /Rbb x ∈ , x k &lt; &lt; 0
- a Express x f( ) in the form a x b c + + ( ) 2 .
- b State the value of k for which the graph of y x = f( ) has a line of symmetry.
- c For your value of k from part b , find the range of f.
- 16 Find the largest possible domain for each function and state the corresponding range.

```
a x x = -f( ) 3 1 b x x = + f( ) 2 2 c x x = f( ) 2 d x x = f( ) 1 e x x = -f( ) 1 2 f x x = --f( ) 3 2
```

## 2.2  Composite functions

Most functions that we meet can be described as combinations of two or more functions.

For example, the function /arrowbarright 3 7 -x x is the function 'multiply by 3 and then subtract 7'. It is a combination of the two functions g and f, where:

$$g \colon x \mapsto 3 x \quad \ \ ( \text{the function `multiply by $3$} )$$

f : 7 (the function 'subtract 7') - x x /arrowbarright

So, /arrowbarright 3 7 -x x can be described as the function 'first do g, then do f '.

<!-- image -->

When one function is followed by another function, the resulting function is called a composite function .

## KEY POINT 2.1

fg( ) x means the function g acts on x first, then f acts on the result.

There are three important points to remember about composite functions:

## KEY POINT 2.2

fg only exists if the range of g is contained within the domain of f.

In general,  fg( ) gf( ). x x ≠

ff( ) x means you apply the function f twice.

## EXPLORE 2.1

f(

)

2

5

=

-

x

x

for

/Rbb

∈

x

g(

)

3

1

=

-

x

x

for

Three students are asked t o find the composite function  gf( ) x .

Here are their solutions.

| Student A                    | Student B                | Student C              |
|------------------------------|--------------------------|------------------------|
| x x x = - - gf( ) (3 1)(2 5) | x x = - - gf( ) 2(3 1) 5 | x x = - - gf( ) 3(2 5) |
| x x 2                        | x = - 6 7                | x = - 6 16             |

=

-

+

6

17

5

Discuss these solutions with your classmates.

Which student is correct? What error has each of the other students made?

x

∈

/Rbb

39

40

## WORKED EXAMPLE 2.3

$$\text{WORKEDEXAMPLE}=273
\begin{array} {$$

## WORKED EXAMPLE 2.4

```
= + ∈ f( ) 2 3 for x x x /Rbb = -∈ g( ) 1 for 2 x x x /Rbb Find: a fg( ) x b gf( ) x c ff( ) x Answer a = -= -+ = + fg( ) f( 1) 2( 1) 3 2 1 2 2 2 x x x x g  acts on x first and  g( ) 1. 2 x x = -f  is the function 'double and add 3'. b = + = + -= + + -= + + gf( ) g(2 3) (2 3) 1 4 12 9 1 4 12 8 2 2 2 x x x x x x x f  acts on x first and  f( ) 2 3 x x = + . g  is the function 'square and subtract 1'. c = + = + + = + ff( ) f(2 3) 2(2 3) 3 4 9 x x x x f  is the function 'double and add 3'.
```

## WORKED EXAMPLE 2.5

```
x x x x x x x f : 5 2 for , 2 g( ) 3 for 2 /arrowbarright /Rbb /Rbb -∈ ≠ = -∈ Find: a fg( ) x b ff( ) x Answer a fg( ) f(3 ) 5 (3 ) 2 5 1 2 2 2 x x x x = -= --= -g  acts on x first and  g( ) 3 2 x x = -. f  is the function 'subtract 2 and then divide into 5'.
```

```
b ff ( ) f 5 2 5 5 2 2 5( 2) 5 2( 2) 5 10 9 2 x x x x x x x = -    = --= ---= --Multiply numerator and denominator by  ( 2) x -.
```

## WORKED EXAMPLE 2.6

= + ∈ f( ) 4 for 2 x x x x /Rbb

$$g ( x ) = 3 x - 1 \text{ for } x \in \mathbb { R }$$

Find the values of k for which the equation = fg( ) x k has real solutions.

```
Answer = -+ -= + -fg( ) (3 1) 4(3 1) 9 6 3 2 2 x x x x x Expand brackets and simplify. When = fg( ) x k , + -= + + --= x x k x x k 9 6 3 9 6 ( 3 ) 0 2 2 Rearrange and simplify. For real solutions: > > > > --× × --+ -b ac k k k 4 0 6 4 9 ( 3 ) 0 144 36 0 4 2 2
```

## EXERCISE 2B

- 1 /Rbb f( ) 6 for 2 = + ∈ x x x

Find: a fg(6)

/Rbb g(

)

3

2

for

,

=

+

-

∈

x

x

x

- b gf(4)
- 2 . + ∈ h : 5 for , 0 x x x x /arrowbarright /Rbb

. ∈ k : for , 0 x x x x /arrowbarright /Rbb

Express each of the following in terms of h and/or k.

- a /arrowbarright 5 + x x

b

/arrowbarright

x

x

- 3 x ax b x = + ∈ f( ) for /Rbb

Given that  f(5) 3 = and  f(3) 3 = -:

- a find the value of a and the value of b
- b solve the equation  ff( ) 4 = x .
- 4 /arrowbarright /Rbb f : 2 3 for + ∈ x x x
- a Find  gf( ) x .
- b Solve the equation  gf( ) 2 = x .

+

5

$$g \colon x \mapsto \frac { 1 2 } { 1 - x } \text{ for } x \in \mathbb { R }$$

x

&gt;

-

3

c ff( 3) -

c

x

/arrowbarright

x

+

10

41

42

- 5 /Rbb g( ) 2 for 2 = -∈ x x x
- a Find  gh( ) x .
- b Solve the equation  gh( ) 14 = x .
- 6 /Rbb f( ) 1 for 2 = + ∈ x x x

Solve the equation  fg( ) 5 = x .

- 7 g( ) 2 1 = + x x for /Rbb ∈ , x 1 ≠ -x

Solve the equation  hg( ) 11 = x .

- 8 /arrowbarright /Rbb f : 1 2 for + ∈ x x x

Solve the equation  gf( ) 1 = x .

$$\text{h} ( x ) = 2 x + 5 \text{ for } x \in \mathbb { R }$$

$$g ( x ) = \frac { 3 } { x - 2 } \text{ for } x \in \mathbb { R }, x \neq 2$$

$$h ( x ) = ( x + 2 ) ^ { 2 } - 5 \text{ for } x \in \mathbb { R }$$

$$g \colon x \mapsto \frac { 2 x + 3 } { x - 1 } \text{ for } x \in \mathbb { R }, x \neq 1$$

- 9 f( ) 1 2 5 = + + x x x for . ∈ , 0 x x /Rbb

Find an expression for  ff( ) x , giving your answer as a single fraction in its simplest form.

- 10 /arrowbarright /Rbb f : for 2 ∈ x x x

$$g \, \colon x \mapsto x + 1 \text{ for } x \in \mathbb { R }$$

Express each of the following as a composite function, using only f and/or g.

- a /arrowbarright ( 1) 2 + x x
- b /arrowbarright 1 2 + x x
- d /arrowbarright 4 x x
- e /arrowbarright 2 2 2 + + x x x
- 11 /Rbb f( ) 3 for 2 = -∈ x x x x

$$g ( x ) = 2 x + 5 \text{ for } x \in \mathbb { R }$$

Show that the equation  gf( ) 0 = x has no real solutions.

- 12 /Rbb f( ) 2 for = -∈ x k x x

$$\begin{array} {$$

Find the values of k for which the equation  fg( ) = x x has two equal roots.

- 13 /Rbb f( ) 3 for 2 = -∈ x x x x

$$g ( x ) = 2 x - 5 \text{ for } x \in \mathbb { R$$

Find the values of k for which the equation  gf( ) = x k has real solutions.

- 14 /Rbb f( ) 5 2 1 for , 1 2 = + -∈ ≠ x x x x x

Show that  ff( ) = x x .

- 15 /Rbb f( ) 2 4 8 for , 2 &gt; = + -∈ x x x x x k
- a Express  2 4 8 2 + -x x in the form ( ) 2 + + a x b c .
- b Find the least value of k for which the function is one-one.
- 16 /Rbb f( ) 2 4 for 2 = -+ ∈ x x x x
- a Find the set of values of x for which  f( ) 7 &gt; x .
- b Express 2 4 2 -+ x x in the form  ( ) 2 -+ x a b .
- c Write down the range of  f.
- 17 /Rbb f( ) 5 for 2 = -∈ x x x x
- a Find  fg( ) x .
- b Find the range of the function  fg( ) x .

$$g ( x ) = 2 x + 3 \text{ for } x \in \mathbb { R$$

- c /arrowbarright 2 + x x
- f /arrowbarright 2 1 4 2 + + x x x

PS

$$1 8 \ f ( x ) = \frac { 2 } { x + 1 } \text{ for$$

- a Find  ff( ) x and state the domain of this function.
- b Show that if  f( ) ff( ) = x x then 2 0. 2 + -= x x
- c Find the values of x for which  f( ) ff( ) = x x .

P(

x

x

)

1

2

=

-

for

/Rbb

x

∈

$$Q ( x ) = x + 2 \text{ for } x \in \mathbb { R }$$

$$\underbrace { R ( x ) = \frac { 1 } { x } \text{ for } x \in \mathbb { R }, x \neq 0 }$$

$$\Big ) \ \Big ( \ S ( x ) = \sqrt { x + 1 } - 1 \text{ for } x \in \mathbb { R }, \, x \geqslant - 1 \ \Big )$$

Functions P, Q, R and S are composed in some way to make a new function,  f( ) x .

For each of the following, write  f( ) x in terms of the functions P, Q, R and/or S, and state the domain and range for each composite function.

- a f( ) 4 3 2 = + + x x x
- b f( ) 1 2 = + x x
- c f( ) = x x

$$\mathfrak { d } _ { \ } f ( x ) = \frac { 1 } { x ^ { 2 } } + 1$$

- e f( ) 1 4 = + x x
- f f( ) 2 1 1 = -+ + x x x
- g f( ) 1 = -x x

## 2.3  Inverse functions

The inverse of a function f( ) x is the function that undoes what  f( ) x has done.

We write the inverse of the function  f( ) x as  f ( ) 1 -x .

## KEY POINT 2.3

= = --x x x ff ( ) f f( ) 1 1

The domain of -x f ( ) 1 is the range of f( ) x .

The range of -x f ( ) 1 is the domain of f( ) x .

It is important to remember that not every function has an inverse.

## KEY POINT 2.4

An inverse function -x f ( ) 1 exists if, and only if, the function f( ) x is a one-one mapping.

You should already know how t o find the inverse function of some simple one-one mappings.

We want to find the function f ( ) 1 x -, so if we write f ( ) 1 y x = -, then f( ) f(f ( )) 1 y x x = = -, because f and f 1 -are inverse functions. So if we write f( ) x y = and then rearrange it to get y = … , then the right-hand side will be f ( ) 1 x -.

19

<!-- image -->

43

44

W e find the inverse of the function  f( ) 3 1 = -x x by following these steps:

Step 1: Write the function as y

$$\begin{array} { c c c c c } & \cdot \cdot \cdot & \cdot & \cdot \\ \text{ion as $y=} & & \text{----} > & y = 3 x - 1 \\ e \, x \, and \, y \, variables. & \text{----} > & x = 3 y - 1 \\ \text{ake $y$ the subject.} & \text{----} > & y = \frac { x + 1 } { 3 } \\. &. &. & x + 1 \end{array}$$

Step 2: Interchange the x and y variables.

Step 3: Rearrange to make y

Hence, if  f( ) 3 1, x x = -then  f ( ) 1 3 1 = + -x x .

If f  and f 1 -are the same function, then f is called a self-inverse function .

$$\text{ple, if } f ( x ) = \frac { 1 } { \gamma } \text{ for } x \neq 0, \text{ then } f ^ { - 1 } ( x ) = \frac { 1 } { \gamma } \text{ for } x \neq 0.$$

$$\text{For example, if } f ( x ) = \frac { 1 } { x } \text{ for } x \neq 0, \text{ then } f ^ { - 1 } ( x ) = \frac { 1 } { x } \text{ for } x \neq 0. \\ \text{So } f ( x ) = \frac { 1 } { x } \text{ for } x \neq 0 \text{ is a self-inverse function.}$$

## EXPLORE 2.2

The diagram shows the function /Rbb f( ) ( 2) 1 for 2 = -+ ∈ x x x .

Discuss the following questions with your classmates.

- 1 What type of mapping is this function?
- 2 What are the coordinates of the vertex of the parabola?
- 3 What is the domain of the function?
- 4 What is the range of the function?
- 5 Does this function have an inverse?
- 6 If f  has an inverse, what is it? If not, then how could you change the domain of f so that the function does have an inverse?

<!-- image -->

## WORKED EXAMPLE 2.7

$$| \ f ( x ) = \sqrt { x + 2 } - 7 \text{ for } x \in \mathbb { R }, x \geqslant - 2$$

- a Find an expression for  f ( ) 1 -x .

## Answer

a

=

+

-

f(

)

2

7

x

x

Step 1: Write the function as = y

Step 2: Interchange the x and y variables.

Step 3: Rearrange to make y the subject.

= + --f ( ) ( 7) 2 1 2 x x

- b Solve the equation  f ( ) f(62) 1 = -x .

y

x

2

7

=

+

-

x

+

7

7)

2

y

=

=

=

=

y

y

y

+

(

x

2

2

+

+

2

+

7)

-

2

7

-

2

(

x

x

+

b = + -= + -= + = + = ± = -± = --= -+ f(62) 62 2 7 1 ( 7) 2 1 ( 7) 3 7 3 7 3 7 3 or 7 3 2 2 x x x x x x The range of f is -f( ) 7 &gt; x so the domain of -f 1 is -7 &gt; x . Hence, the only solution of = -f ( ) f(62) 1 x is = -+ 7 3 x .

## WORKED EXAMPLE 2.8

&lt; &lt; = --∈ f( ) 5 ( 2) for , 6 2 x x x k x /Rbb

- a State the smallest value of k for which  f  has an inverse.
- b For this value of k find an expression for  f ( ) 1 -x , and state the domain and range of  f 1 -.

## Answer

- a The vertex of the graph of = --5 ( 2) 2 y x is at the point (2, 5).

When = = -= -6, 5 4 11 2 x y

For the function f to have an inverse it must be a one-one function.

Hence, the smallest value of k is 2.

- b = --f( ) 5 ( 2) 2 x x

<!-- image -->

Step 1: Write the function as = y

Step 2: Interchange the x and y variables.

Step 3: Rearrange to make y the subject.

Hence, = + --f ( ) 2 5 1 x x .

The domain of -f 1 is the same as the range of  f .

Hence, the domain of -f 1 is -11 5 &lt; &lt; x .

The range of -f 1 is the same as the domain of  f .

Hence, the range of -f 1 is ) ( -2 f 6 1 &lt; &lt; x .

5 ( 2) 2 y x = --

5 ( 2) 2 x y = --

2)

5

2

x

=

-

-

2

y

=

=

5

+

-

x

5

(

y

-

y

2

-

x

45

46

## EXERCISE 2C

- 1 Find an expression for  f ( ) 1 -x for each of the following functions.
- a f( ) 5 8 = -x x for /Rbb ∈ x
- b f( ) 3 2 = + x x for /Rbb ∈ x , 0 &gt; x
- c f( ) ( 5) 3 2 = -+ x x for /Rbb ∈ x , 5 &gt; x
- e f( ) 7 2 = + + x x x for /Rbb ∈ x , 2 ≠ -x
- 2 /arrowbarright /Rbb f : 4 for , 2 2 &gt; + ∈ -x x x x x
- a State the domain and range of  f 1 -.
- b Find an expression for  f ( ) 1 -x .
- 3 /arrowbarright /Rbb f : 5 2 1 for , 2 &gt; + ∈ x x x x
- a Find an expression for  f ( ) 1 -x .
- b Find the domain of  f 1 -.
- 4 /arrowbarright /Rbb + -∈ f : ( 1) 4 for , 0 3 x x x x &gt;
- a Find an expression for  f ( ) 1 -x .
- b Find the domain of  f 1 -.
- 5 /arrowbarright /Rbb -+ ∈ g : 2 8 10 for , 3 2 x x x x x &gt;
- a Explain why g has an inverse.
- b Find an expression for  g ( ) 1 -x .
- 6 /arrowbarright /Rbb f : 2 12 14 for , 2 &gt; + -∈ x x x x x k
- a Find the least value of k for which f is one-one.
- b Find an expression for  f ( ) 1 -x .
- 7 /arrowbarright /Rbb f : 6 for 2 -∈ x x x x
- a Find the range of f.
- b State, with a reason, whether f  has an inverse.
- 8 /Rbb = --∈ f( ) 9 ( 3) for , 7 2 x x x k x &lt; &lt;
- a State the smallest value of k for which f has an inverse.
- b For this value of k :
- i find an expression for  f ( ) 1 -x
- ii state the domain and range of  f 1 -.
- d f( ) 8 3 = -x x for /Rbb ∈ x , 3 ≠ x
- f f( ) ( 2) 1 3 = --x x for /Rbb ∈ x , 2 &gt; x

<!-- image -->

The diagram shows the graph of f ( ) 1 = -y x , where  f ( ) 5 1 1 = --x x x for , &lt; ∈ , 0 3 x x /Rbb .

- a Find an expression for  f( ) x .
- b State the domain of  f.
- 10 /Rbb f( ) 3 for = + ∈ x x a x

$$g ( x ) = b - 5 x \text{ for } x \in \mathbb { R }$$

Given that  gf( 1) 2 -= and  g (7) 1 1 = -, find the value of a and the value of b .

- 11 /Rbb f( ) 3 1 for = -∈ x x x

$$g ( x ) = \frac { 3 } { 2 x - 4 } \text{ for } x \in \mathbb { R }, x \neq 2$$

- a Find expressions for  f ( ) 1 -x and  g ( ) 1 -x .
- b Show that the equation  f ( ) g ( ) 1 1 = --x x has two real roots.
- 12 /arrowbarright /Rbb --∈ f : (2 1) 3 for , 1 3 3 x x x x &lt; &lt;
- a Find an expression for  f ( ) 1 -x .
- b Find the domain of  f 1 -.
- 13 /arrowbarright /Rbb -∈ f : 10 for , 5 2 x x x x x &gt;
- a Express  f( ) x in the form  ( ) 2 --x a b .
- b Find an expression for  f ( ) 1 -x and state the domain of  f 1 -.
- 14 f( ) 1 1 = -x x for /Rbb ∈ x , 1 ≠ x
- a Find an expression for  f ( ) 1 -x .
- b Show that if  f( ) f ( ) 1 = -x x , then 1 0 2 --= x x .
- 1 -.
- c Find the values of x for which  f( ) f ( ) = x x Give your answer in surd form.
- 15 Determine which of the following functions are self-inverse functions.
- a f( ) 1 3 = -x x for /Rbb ∈ x , 3 ≠ x
- b f( ) 2 1 2 = + -x x x for /Rbb ∈ x , 2 ≠ x
- c f( ) 3 5 4 3 = + -x x x for /Rbb ∈ x , 3 4 ≠ x
- 16 /arrowbarright /Rbb f : 3 5 for -∈ x x x
- a Find an expression for  (fg) ( ) 1 -x .
- b Find expressions for:
- i f g ( ) 1 1 --x ii g f ( ) 1 1 --x .
- c Comment on your results in part b .

Investigate if this is true for other functions.

$$g \colon x \mapsto 4 - 2 x \text{ for } x \in \mathbb { R }$$

47

48

## 2.4  The graph of a function and its inverse

Consider the function de fined by  f( ) 2 1 = + x x for /Rbb ∈ x , 4 2 &lt; &lt; -x .

f( 4) 7 -= -and  f(2) 5 = .

The domain of f is 4 2 &lt; &lt; -x and the range is 7 f( ) 5. &lt; &lt; -x

The inverse of this function is  f ( ) 1 2 1 = --x x .

The domain of  f 1 -is the same as the range of  f.

Hence, the domain of  f 1 -is 7 5 &lt; &lt; -x .

The range of f 1 -is the same as the domain of  f.

Hence, the range of f 1 -is 4 f ( ) 2 1 &lt; &lt; --x .

The representation of f and f 1 -on the same graph can be seen in the diagram opposite.

<!-- image -->

It is important to note that the graphs of f and   f 1 -are reflections of each other in the line = y x . This is true for each one-one function and its inverse functions.

## KEY POINT 2.5

The graphs of f and f 1 -are reflections of each other in the line y x = .

This is because x x x ff ( ) f f( ) 1 1 = = --

When a function f is self-inverse, the graph of f will be symmetrical about the line y x = .

## WORKED EXAMPLE 2.9

&lt; &lt; = --∈ f( ) ( 1) 2 for , 1 4 2 x x x x /Rbb

On the same axes, draw the graph of f and the graph of -f 1 .

## Answer

<!-- image -->

When = = 4, 7 x y .

The function is one-one, so the inverse function exists.

The circled part of the expression is a square so it will always be 0 &gt; . The smallest value it can be is 0. This occurs when 1 x = . The vertex is at the point  (1, 2) -.

In this image, we can see a graph.

<!-- image -->

<!-- image -->

In this image we can see a graph.

<!-- image -->

## WORKED EXAMPLE 2.10

+ -∈ ≠ f : 2 7 2 for , 2 x x x x x /arrowbarright /Rbb a Find an expression for  f ( ) 1 -x . b State what your answer to part a tells you about the symmetry of the graph of f( ) = y x . Answer a /arrowbarright + -f : 2 7 2 x x x Step 1: Write the function as = y 2 7 2 y x x = + -Step 2: Interchange the x and y variables. 2 7 2 x y y = + -Step 3: Rearrange to make y the subject. 2 2 7 ( 2) 2 7 2 7 2 xy x y y x x y x x -= + -= + = + -Hence = + --f ( ) 2 7 2 1 x x x . b = -f ( ) f( ) 1 x x , so the function f is self-inverse. The graph of = f( ) y x is symmetrical about the line = y x .

## EXPLORE 2.3

<!-- image -->

<!-- image -->

Ali states that:

The diagrams show the functions  f  and  g, together with their inverse functions -f 1 and -g 1 .

Is Ali correct?

Explain your answer.

49

50

## EXERCISE 2D

- 1 On a copy of each grid, draw the graph of  f ( ) 1 -x if it exists.

<!-- image -->

-6

<!-- image -->

- 2 /arrowbarright /Rbb f : 2 1 for , 1 3 &lt; &lt; -∈ -x x x x
- a Find an expression for  f ( ) 1 -x .
- b State the domain and range of  f 1 -.
- c Sketch, on the same diagram, the graphs of f( ) = y x and f ( ) 1 = -y x , making clear the relationship between the graphs.
- 3 The diagram shows the graph of f( ) = y x , where /Rbb f( ) 4 2 for , 0 &gt; = + ∈ x x x x .
- a State the range of  f .
- b Find an expression for  f ( ) 1 -x .
- c State the domain and range of  f 1 -.
- d On a copy of the diagram, sketch the graph of f ( ) 1 = -y x , making clear the relationship between the graphs.
- 4 For each of the following functions , find an expression for  f ( ) 1 -x and, hence, decide if the graph of f( ) = y x is symmetrical about the line = y x .
- a /Rbb f( ) 5 2 1 for , 1 2 = + -∈ ≠ x x x x x
- b /Rbb f( ) 2 3 for , 5 = -∈ ≠ x x x x
- c /Rbb f( ) 3 1 2 3 for , 3 2 = --∈ ≠ x x x x x

<!-- image -->

$$\mathfrak { d } _ { \ } f ( x ) = \frac { 4 x + 5 } { 3 v - 4 } \text{ for } x \in \mathbb { R }, x \neq \frac { 4 } { 3 }$$

$$\iota ) & = \frac { 2 x - 2 } { x - 5 } \text{ for } x \in \mathbb { R }, x \neq 5 \\ \iota ) & = \frac { 4 x + 5 } { 3 x - 4 } \text{ for } x \in \mathbb { R }, x \neq \frac { 4 } { 3 }$$

b

<!-- image -->

<!-- image -->

- 5 a /Rbb f( ) 1 for , 1 = + -∈ ≠ x x a bx x x b , where a and b are constants. P
- Prove that this function is self-inverse.
- b /Rbb g( ) for , = + + ∈ ≠ -x ax b cx d x x d c , where , , a b c and d are constants.

Find the condition for this function to be self-inverse.

## 2.5  Transformations of functions

At IGCSE / O Level you met various transformations that can be applied to two-dimensional shapes. These included translations, reflections, rotations and enlargements. In this section you will learn how translations, reflections and stretches (and combinations of these) can be used to transform the graph of a function.

## EXPLORE 2.4

- 1 a Use graphing software to draw the graphs of , 2 2 2 y x y x = = + and 3 2 = -y x .
- Discuss your observations with your classmates and explain how the second and third graphs could be obtained from th e first graph.
- b Repeat part a using the graphs , 1 = = + y x y x and 2 = -y x .
- c Repeat part a using the graphs 12 , 12 5 y x y x = = + and 12 4 = -y x .
- d Can you generalise your results?
- 2 a Use graphing software to draw the graphs of , ( 2) 2 2 y x y x = = + and ( 5) 2 = -y x .
- Discuss your observations with your classmates and explain how the second and third graphs could be obtained from the first graph.
- b Repeat part a using the graphs , ( 1) 3 3 y x y x = = + and ( 4) 3 = -y x .
- c Can you generalise your results?
- 3 a Use graphing software to draw the graphs of 2 = y x and 2 = -y x .
- Discuss your observations with your classmates and explain how the second graph could be obtained from the first graph.
- b Repeat part a using the graphs 3 = y x and 3 = -y x .
- c Repeat part a using the graphs 2 = y x and 2 = -y x .
- d Can you generalise your results?
- 4 a Use graphing software to draw the graphs of 5 = + y x and 5 = -y x .
- Discuss your observations with your classmates and explain how the second graph could be obtained from the first graph.
- b Repeat part a using the graphs 2 = + y x and 2 = -y x .
- c Can you generalise your results?
- 5 a Use graphing software to draw the graphs of 2 = y x and 2 2 = y x and (2 ) 2 = y x .
- Discuss your observations with your classmates and explain how the second graph could be obtained from the first graph.
- b Repeat part a using the graphs , 2 = = y x y x and 2 = y x .
- c Repeat part a using the graphs 3 , 2 3 = = × y y x x and 3 2 = y x .
- d Can you generalise your results?

51

52

## Translations

The diagram shows the graphs of two functions that differ only by a constant.

$$y & = x ^ { 2 } - 2 x + 1 \\ y & = x ^ { 2 } - 2 x + 4$$

When the x -coordinates on the two graphs are the same  ( ) x x = the y -coordinates differ by 3  ( 3) y y = + .

This means that the two curves have exactly the same shape but that they are separated by 3 units in the positive y direction.

Hence, the graph of 2 4 2 = -+ y x x is a translation of the graph of 2 1 2 = -+ y x x

$$by the vector { \begin{pmatrix} 0 \\ 3 \end{pmatrix} }.$$

## KEY POINT 2.6





The graph of = + f( ) y x a is a translation of the graph = f( ) y x by the vector



Now consider the two functions:

$$y & = x ^ { 2 } - 2 x + 1 \\ y & = ( x - 3 ) ^ { 2 } - 2 ( x - 3 ) + 1$$

We obtain the second function by replacing x by 3 -x in th e first function.

The graphs of these two functions are:

In this image, we can see a graph.

<!-- image -->

The curves have exactly the same shape but this time they are separated by 3 units in the positive x -direction.

You may be surprised that the curve has moved in the positive x -direction. Note, however, that a way of obtaining y y = is to have 3 x x = -or equivalently 3. x x = + This means that the two curves are at the same height when the red curve is 3 units to the right of the blue curve.

0

a







.

In this image, we can see a graph.

<!-- image -->

Hence, the graph of ( 3) 2( 3) 1 2 = ---+ y x x is a translation of the graph of

```
  .
```

$$y = x ^ { 2 } - 2 x + 1 \text{ by the vector } \begin{pmatrix} 3 \\ 0 \end{pmatrix}.$$

## KEY POINT 2.7





The graph of = -f( ) y x a is a translation of the graph = f( ) y x by the vector



Combining these two results gives:

## KEY POINT 2.8

The graph of f( ) y x a b is a translation of the graph f( ) y x

```
= -+ = by the vector       a b .
```

## WORKED EXAMPLE 2.11

The graph of 5 2 = + y x x is translated 2 units to the right. Find the equation of the resulting graph. Give your answer in the form 2 = + + y ax bx c .

## Answer

y

=

+

5

2

x

x

= -+ -( 2) 5( 2) 2 y x x

= + -6 2 y x x

## WORKED EXAMPLE 2.12

The graph of 2 = y x is translated by the vector -      5 3 . Find the equation of the resulting graph. Answer = = + + = + + 2 2( 5) 3 2 10 3 y x y x y x Replace x by 5 x + , and add 3 to the resulting function.

Replace all occurrences of x by 2 x -.

Expand and simplify.

a

0







.

53

54

## EXERCISE 2E

- 1 Find the equation of each graph after the given transformation.
- 2 Find the translation that transforms the graph.
- 3 The diagram shows the graph of f( ) = y x .

- a 2 2 = y x

- after translation by       0 4

- b 5 y x

- =

- after translation by -       0 2

- c 7 2 2 = - y x x

- after translation by       0 1

- d 1 2 = - y x after translation by       0 2

- e 2 = y

- x after translation by -       5 0

- f = y

- 1 + x x after translation by       3 0

- g 2 y x x

- = +  

- after translation by -     1 0

- h 3 2 2 = - y x  

- after translation by     2 3

- a 5 2 2 y x x

- = + - to the graph 5 2 2 = + + y x x

- b 2 1 3 2 = + + y x x to the graph 2 4 3 2 = + - y x x

- c 3 2 = - y x x to the graph ( 1) 3( 1) 2 = + - + y x x

- d 6 y x

- = + x to the graph 2 6 2 = - + - y x x

- e 2 5 = + y x

to the graph

2

3

=

+

y

x

- f 5 3 2 = - y x x

to the graph

5

(

2)

3

10

2

=

-

-

+

y

x

x

Sketch the graphs of each of the following functions.

- a f( ) 4 = -y x
- b f ( 2) = -y x
- c f ( 1) 5 = + -y x

-4

<!-- image -->

- 4 a On the same diagram, sketch the graphs of 2 = y x and 2 2 = + y x .
- b 2 = y x can be transformed to 2 2 = + y x by a translation of       a 0 .
- Find the value of a .
- c 2 = y x can be transformed to 2 2 = + y x by a translation of       b 0 . Find the value of b .

- 5 A cubic graph has equation 3 2 5 y x x x ( )( )( ) = + --.

$$\text{Write, in a similar form, the equation of the graph after a translation of } \left ( \begin{matrix} 2 \\ 0 \end{matrix} \right ).$$

$$6 \text{ \ } \text{The graph of } y = x ^ { 2 } - 4 x + 1 \text{ is translated by the vector } \begin{pmatrix} 1 \\ 2 \end{pmatrix}.$$

Find, in the form , 2 y ax bx c

- . = + + the equation of the resulting graph.

$$\mathbb { S } \quad 7 \quad \text{The graph of } y = a x ^ { 2 } + b x + c \text{ is translated by the vector } \begin{pmatrix} 2 \\ - 5 \end{pmatrix}.$$

The resulting graph is 2 11 10 2 y x x = -+ . Find the value of a , the value of b and the value of c .

## 2.6  Reflections

The diagram shows the graphs of the two functions:

$$y & = x ^ { 2 } - 2 x + 1 \\ y & = - ( x ^ { 2 } - 2 x + 1 )$$

When the x -coordinates on the two graphs are the same  ( ) x x = , the y -coordinates are negative of each other  ( ) y y = -.

This means that, when the x -coordinates are the same, the red curve is the same vertical distance from the x -axis as the blue curve but it is on the opposite side of the x -axis.

Hence, the graph of ( 2 1) 2 = --+ y x x is a reflection of the graph of 2 1 2 = -+ y x x in the x -axis.

<!-- image -->

## KEY POINT 2.9

The graph of = -f( ) y x is a reflection of the graph = f( ) y x in the x -axis.

Now consider the two functions:

$$y & = x ^ { 2 } - 2 x + 1 \\ y & = ( - x ) ^ { 2 } - 2 ( - x ) + 1$$

$$1$$

We obtain the second function by replacing x by -x in th e first function.

The graphs of these two functions are demonstrated in the diagram.

<!-- image -->

<!-- image -->

## WEB LINK

Try the Between the lines resource on the Underground Mathematics website.

55

56

The curves are at the same height  ( ) y y = when x x = -or equivalently x x = -.

This means that the heights of the two graphs are the same when the red graph has the same horizontal displacement from the y -axis as the blue graph but is on the opposite side of the y -axis.

Hence, the graph of ( ) 2( ) 1 2 = ---+ y x x is a reflection of the graph of 2 1 2 = -+ y x x in the y -axis.

## KEY POINT 2.10

The graph of = -f( ) y x is a reflection of the graph = f( ) y x in the y -axis.

## WORKED EXAMPLE 2.13

The quadratic graph = f( ) y x has a minimum at the point -(5, 7). Find the coordinates of the vertex and state whether it is a maximum or minimum of the graph for each of the following graphs.

$$| \quad a _ { \ } y = - \tilde { f } ( x )$$

## Answer

- a f( ) y x = -is a reflection of = f( ) y x in the x -axis.

The turning point is  (5, 7). It is a maximum point.

- b = -f( ) y x is a reflection of = f( ) y x in the y -axis.

The turning point is --( 5, 7). It is a minimum point.

## EXERCISE 2F

- 1 The diagram shows the graph of g( ) = y x .

Sketch the graphs of each of the following functions.

- a g( ) y x = -
- b g( ) = -y x
- 2 Find the equation of each graph after the given transformation.
- a 5 2 = y x after reflection in the x -axis.
- b 2 4 = y x after reflection in the y -axis.
- c 2 3 1 2 = -+ y x x after reflection in the y -axis.
- d 5 2 3 2 = + -y x x after reflection in the x -axis.

<!-- image -->

y

-4

- 3 Describe the transformation that maps the graph:
- a 7 3 2 = + -y x x onto the graph 7 3 2 = --+ y x x
- b 3 4 2 = -+ y x x onto the graph 3 4 2 = + + y x x
- c 2 5 2 = -y x x onto the graph 5 2 2 = -y x x
- d 2 3 1 3 2 = + -+ y x x x onto the graph 2 3 1 3 2 = --+ -y x x x .

## 2.7  Stretches

The diagram shows the graphs of the two functions:

$$y & = x ^ { 2 } - 2 x - 3 \\ y & = 2 ( x ^ { 2 } - 2 x - 3 )$$

When the x -coordinates on the two graphs are the same  ( ) x x = , the y -coordinate on the red graph is double the y -coordinate on the blue graph  ( 2 ) y y = .

This means that, when the x -coordinates are the same, the red curve is twice the distance of the blue graph from the x -axis.

Hence, the graph of 2( 2 3) 2 = --y x x is a stretch of the graph of 2 3 2 = --y x x from the x -axis. We say that it has been stretched with stretch factor 2 parallel to the y -axis.

-4

Note: there are alternative ways of expressing this transformation:

- /uni25CF a stretch with scale factor 2 with the line y 0 = invariant
- /uni25CF a stretch with stretch factor 2 with the x -axis invariant
- /uni25CF a stretch with stretch factor 2 relative to the x -axis
- /uni25CF a vertical stretch with stretch factor 2.

In this image, we can see a graph.

<!-- image -->

## KEY POINT 2.11

The graph of = f( ) y a x is a stretch of the graph = f( ) y x with stretch factor a parallel to the y -axis.

Note: if a 0 , , then y a x f( ) = can be considered to be a stretch of y x f( ) = with a negative scale factor or as a stretch with positive scale factor followed by a reflection in the x -axis.

57

58

Now consider the two functions:

$$y & = x ^ { 2 } - 2 x - 3 \\ y & = ( 2 x ) ^ { 2 } - 2 ( 2 x ) \cdot$$

$$y = ( 2 x ) ^ { 2 } - 2 ( 2 x ) - 3$$

We obtain the second function by replacing x by 2 x in th e first function.

The two curves are at the same height  ( ) y y = when 2 x x = or equivalently = 1 2 x x .

This means that the heights of the two graphs are the same when the red graph has half the horizontal displacement from the y -axis as the blue graph.

Hence, the graph of (2 ) 2(2 ) 3 2 = --y x x is a stretch of the graph of

2 3 2 = --y x x from the y -axis. We say that it has been stretched with stretch factor 1 2 parallel to the x -axis.

In this image, we can see a graph.

<!-- image -->

-4

## KEY POINT 2.12

The graph of = f( ) y ax is a stretch of the graph = f( ) y x with stretch factor 1 a parallel to the x -axis.

## WORKED EXAMPLE 2.14

The graph of 5 1 2 2 = -y x is stretched with stretch factor 4 parallel to the y -axis.

Find the equation of the resulting graph.

## Answer

$$\begin{array} { c } & & \\ & Let f(x) = 5 - \frac { 1 } { 2 } x ^ { 2 } \end{array}$$

$$\begin{matrix} 1 \\ 1 \end{matrix}$$

$$<_OCaml_> Let I(x) = 2 - 2 x ^
    4f(x) = 20 - 2x^2$$

The equation of the resulting graph is = -20 2 2 y x .

## WORKED EXAMPLE 2.15

Describe the single transformation that maps the graph of 3 5 2 = --y x x to the graph of 4 6 5 2 = --y x x .

## Answer

$$<_Python_>         ------ ----$$

Express  4 6 5 2 x x --in terms of  f( ) x .

The transformation is a stretch parallel to the x -axis with stretch factor

1

2

.

-5

A stretch parallel to the y -axis, factor 4, gives the function x 4f( ).

## EXERCISE 2G

- 1 The diagram shows the graph of f( ) = y x .

Sketch the graphs of each of the following functions.

- a 3f( ) y x =
- b f(2 ) = y x

<!-- image -->

-6

- 2 Find the equation of each graph after the given transformation.
- a 3 2 = y x after a stretch parallel to the y -axis with stretch factor 2.
- b 1 3 = -y x after a stretch parallel to the y -axis with stretch factor 3.
- c 2 4 = + y x after a stretch parallel to the y -axis with stretch factor 1 2 .
- d 2 8 10 2 = -+ y x x after a stretch parallel to the x -axis with stretch factor 2.
- e 6 36 3 = -y x x after a stretch parallel to the x -axis with stretch factor 1 3 .
- 3 Describe the single transformation that maps the graph:
- a 2 5 2 = + -y x x onto the graph 4 4 5 2 = + -y x x
- b 3 2 2 = -+ y x x onto the graph 3 9 6 2 = -+ y x x
- c 2 1 = + y x onto the graph 2 2 1 y x = + +
- d 6 = -y x onto the graph 3 6 = -y x

## 2.8  Combined transformations

In this section you will learn how to apply simple combinations of transformations.

The transformations of the graph of f( ) = y x that you have studied so far can each be categorised as either vertical or horizontal transformations.

| Vertical transformations   | Vertical transformations    |
|----------------------------|-----------------------------|
| f( ) = + y x a             | translation       a 0 |
| f( ) y x = -               | reflection in the x -axis   |
| f( ) y a x =               | vertical stretch, factor a  |

| Horizontal transformations   | Horizontal transformations     |
|------------------------------|--------------------------------|
| f( ) = + y x a               | translation -       0 a  |
| f( ) = - y x                 | reflection in the y -axis      |
| f( ) = y ax                  | horizontal stretch, factor 1 a |

When combining transformations care must be taken with the order in which the transformations are applied.

59

60

## EXPLORE 2.5

Apply the transformations in the given order to triangle T and for each question comment on whether the final images are the same or different.

- 1 Combining two vertical transformations

$$\begin{array} { l l l } * & \text{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\empl{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emp{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\em[--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph$--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph
--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph<--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph.--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph'--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph}--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph	--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph''--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph`--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emphp{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\begin{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\empath{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emgh{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emg{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emn{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph{--\emph$$

$$|.$$

- b Investigate for other pairs of vertical transformations.

## 2 Combining one vertical and one horizontal transformation

$$\Big | \quad a \ i \ \text{ Reflect in the } x \text{-axis, then translate } \binom { - 2 } { 0 }.$$

$$\text{ii} \, \text{Translate} \begin{pmatrix} - 2 \\ 0 \end{pmatrix}, \text{then reflect in the $x$-axis}.$$

- b Investigate for other pairs of transformations where one is vertical and the other is horizontal.
- 3 Combining two horizontal transformations

$$\begin{array} { c c c } \, \underrightarrow { 1 } \, \text{Comming two non-journal reasons} \\ \, \quad a \, \text{ $i$ Stretch horizontally with factor $2$, then translate} \, \begin{pmatrix} 2 \\ 0 \end{pmatrix}.$$

$$\Big | \quad & \text{$i$ Translate} \left ( \begin{matrix} 2 \\ 0 \end{matrix} \right ) \text{then stretch horizontally with factor $2$}.$$

- b Investigate for other pairs of horizontal transformations.

From the Explore activity, you should have found that:

## KEY POINT 2.13

- When two vertical transformations or two horizontal transformations are combined, the order in which they are applied may affect the outcome.
- When one horizontal and one vertical transformation are combined, the order in which they are applied does not affect the outcome.

## Combining two vertical transformations

We will now consider how the graph of f( ) = y x is transformed to the graph f( ) . y a x k = +

This can be shown i n a flow diagram as:

<!-- image -->

<!-- image -->

This leads to the important result:

## KEY POINT 2.14

Vertical transformations follow the 'normal' order of operations, as used in arithmetic.

## Combining two horizontal transformations

Now consider how the graph of f( ) = y x is transformed to the graph f( ) = + y bx c .

$$f ( x ) \rightarrow \int \lim _ { \substack { \text{translate} \\ 0 \\ \text{replace} x with x + c } } \rightarrow f ( x + c ) \rightarrow \text{ stretch horizontally, factor } \frac { 1 } { b } \rightarrow f ( b x + c )$$

This leads to the important result:

## KEY POINT 2.15

Horizontal transformations follow the opposite order to the 'normal' order of operations, as used in arithmetic.

## WORKED EXAMPLE 2.16

The diagram shows the graph of f( ) y x = .

Sketch the graph of 2f( ) 3. y x = -

## Answer

2f( ) 3 y x = -is a combination of two vertical transformations of = f( ) y x , hence the transformations follow the 'normal' order of operations.

Step 1: Sketch the graph = y x 2f( ):

Stretch = f( ) y x vertically with stretch factor 2.

<!-- image -->

y

6

4

2

O

-2

-4

-6

y

4

x

= 2f(

6

)

x

-6

-4

-2

2

61

62

## Step 2: Sketch the graph = -y x 2f( ) 3:

Translate = y x 2f( )  by the vector





0



-







3

.

In this image, we can see a graph.

<!-- image -->

## WORKED EXAMPLE 2.17

The diagram shows the graph of 2 y x = and its image, g( ) y x = , after a combination of transformations.

y

<!-- image -->

- a Find two different ways of describing the combination of transformations.
- b Write down the equation of the graph g( ) = y x .

## Answer

a

Translation of





4









0

followed by a horizontal stretch, stretch factor

y

1

2

.

Copyright Material  - Review Only -  Not for Redistribution

In this image, we can see a graph.

<!-- image -->

- Horizontal stretch, factor 1 2 , followed by a translation of       2 0 .
- b Using th e first combination of transformations:
- Translation of       4 0 means 'replace x by -4 x '.

In this image, we can see a graph.

<!-- image -->

$$y = x ^ { 2 } \quad \text{becomes} \quad y = ( x - 4 ) ^ { 2 }$$

- Horizontal stretch, factor 1 2 means 'replace x by 2 x '.

( 4) becomes (2 4) 2 2 y x y x = -= -

Hence, = -g( ) (2 4) 2 x x .

## EXERCISE 2H

- 1 The diagram shows the graph of g( ) = y x .

Sketch the graph of each of the following.

- a g( 2) 3 = + + y x

- b = + y x 2g( ) 1

- c 2 g( ) = - y x

- d = - + y x 2g( ) 1

- e = - - y x 2g( ) 1

- f g(2 ) 3 = + y x

- g g(2 6) = - y x

- h g( 1) = - + y x

<!-- image -->

## TIP

The same answer will be obtained when using the second combination of transformations. You may wish to check this yourself.

63

64

- 2 The diagram shows the graph of f( ) = y x .

Write down, in terms of  f( ) x , the equation of the graph of each of the following diagrams.

<!-- image -->

<!-- image -->

<!-- image -->

c

-4

<!-- image -->

- 3 Given that 2 = y x , find the image of the curve 2 = y x after each of the following combinations of transformations.
- a a stretch in the y
- -direction with factor 3 followed by a translation by the vector       1 0
- b a translation by the vector       1 0 followed by a stretch in the y factor 3
- -direction with
- 4 Find the equation of the image of the curve 2 = y x after each of the following combinations of transformations and, in each case, sketch the graph of the resulting curve.
- a a stretch in the x -direction with factor 2 followed by a translation by the vector       5 0
- -direction with
- b a translation by the vector       5 0 followed by a stretch in the x

factor 2

- c On a graph show the curve 2 = y x and each of your answers to parts a and b .
- 5 Given that  f( ) 1 2 = + x x , find the image of f( ) = y x after each of the following combinations of transformations.
- a translation -      0 5 followed by a stretch parallel to the y -axis with stretch factor 2
- b translation       2 0 followed by a reflection in the x -axis

-4

- 6 a The graph of g( ) = y x is reflected in the y -axis and then stretched with stretch factor 2 parallel to the y -axis. Write down the equation of the resulting graph.
- b The graph of f( ) = y x is translated by the vector -      2 3 and then reflected in the x -axis. Write down the equation of the resulting graph.
- 7 Determine the sequence of transformations that maps f( ) = y x to each of the following functions.
- a = + y x 1 2 f ( ) 3 b f( ) 2 y x = -+ c f(2 6) = -y x d 2f( ) 8 y x = -
- 8 Determine the sequence of transformations that maps:
- a the curve 3 = y x onto the curve 1 2 ( 5) 3 = + y x
- b the curve 3 = y x onto the curve 1 2 ( 1) 2 3 = -+ -y x
- c the curve 3 = y x onto the curve 2 3 4 3 = --+ y x
- 9 Given that  f( ) = x x , write down the equation of the image of  f( ) x after:
- a reflection in the x -axis, followed by translation       0 3 , followed by translation
-       1 0 , followed by a stretch parallel to the x -axis with stretch factor 2
- b translation       0 3 , followed by a stretch parallel to the x -axis with stretch
- factor 2, followed by a reflection in the x -axis, followed by translation       1 0 .
- 10 Given that x x = g( ) 2 , write down the equation of the image of  g( ) x after:
- a translation -      4 0 , followed by a reflection in the y -axis, followed by translation
- 0 2       , followed by a stretch parallel to the y -axis with stretch factor 3
- b a stretch parallel to the y -axis with stretch factor 3, followed by translation
-       0 2 , followed by reflection in the y -axis, followed by translation -      4 0 .
- 11 Find two different ways of describing the combination of transformations that maps the graph of  f( ) = x x onto the graph  g( ) 2 = --x x and sketch the graphs of f( ) = y x and g( ) = y x . PS
- 12 Find two different ways of describing the sequence of transformations that maps the graph of f( ) = y x onto the graph of f(2 10) = + y x . PS

<!-- image -->

## WEB LINK

Try the Transformers resource on the Underground

Mathematics website.

65

66

## Checklist of learning and understanding

## Functions

- /uni25CF A function is a rule that maps each x value to just one y value f or a defined set of input values.
- /uni25CF A function can be either one-one or many-one.
- /uni25CF The set of input values for a function is called the domain of the function.
- /uni25CF The set of output values for a function is called the range (or image set) of the function.

## Composite functions

- /uni25CF fg( ) x means the function g acts on x first, then f acts on the result.
- /uni25CF fg only exists if the range of g is contained within the domain of f.
- /uni25CF In general, ≠ fg( ) gf( ) x x .

## Inverse functions

- /uni25CF The inverse of a function f( ) x is the function that undoes what f( ) x has done. = --f f ( ) = f f( ) 1 1 x x x or if = = -f( ) then f ( ) 1 y x x y
- /uni25CF The inverse of the function f( ) x is written as -f ( ) 1 x .
- /uni25CF The steps for finding the inverse function are:
- Step 1: Write the function as = y
- Step 2: Interchange the x and y variables.
- Step 3: Rearrange to make y the subject.
- /uni25CF The domain of -f ( ) 1 x is the range of f( ) x .
- /uni25CF The range of -f ( ) 1 x is the domain of f( ) x .
- /uni25CF An inverse function -f ( ) 1 x can exist if, and only if, the function f( ) x is one-one.
- /uni25CF The graphs of f and -f 1 are reflections of each other in the line = y x .
- /uni25CF If = -f( ) f ( ) 1 x x , then the function f is called a self-inverse function.
- /uni25CF If f is self-inverse then = ff( ) x x .
- /uni25CF The graph of a self-inverse function has = y x as a line of symmetry.

## Transformations of functions

- /uni25CF The graph of = + f( ) y x a is a translation of = f( ) y x by the vector       a 0 .
- /uni25CF The graph of f( ) y x a is a translation of f( ) y x
- = + = by the vector -      a 0 .
- /uni25CF The graph of = -f( ) y x is a reflection of the graph = f( ) y x in the x -axis.
- /uni25CF The graph of = -f( ) y x is a reflection of the graph = f( ) y x in the y -axis.
- /uni25CF The graph of = f( ) y a x is a stretch of = f( ) y x , stretch factor a , parallel to the y -axis.
- /uni25CF The graph of = f( ) y ax is a stretch of = f( ) y x , stretch factor 1 a , parallel to the x -axis.

<!-- image -->

## Combining transformations

- /uni25CF When two vertical transformations or two horizontal transformations are combined, the order in which they are applied may affect the outcome.
- /uni25CF When one horizontal and one vertical transformation are combined, the order in which they are applied does not affect the outcome.
- /uni25CF Vertical transformations follow the 'normal' order of operations, as used in arithmetic
- /uni25CF Horizontal transformations follow the opposite order to the 'normal' order of operations, as used in arithmetic.

## END-OF-CHAPTER REVIEW EXERCISE 2

- 1 Functions f and g ar e defined for /Rbb ∈ x by:

/arrowbarright -x x f : 3 1

/arrowbarright -x x x g : 5 2

Express  gf( ) x in the form ( ) 2 --a b x c , where a , b and c are constants.

<!-- image -->

The diagram shows a sketch of the curve with equation f( ) = y x .

- a Sketch the graph of = -    y x f 1 2 .
- b Describe fully a sequence of two transformations that maps the graph of f( ) = y x onto the graph of f(3 ) = -y x .
- 3 A curve has equation 6 8 2 = + + y x x .
- a Sketch the curve, showing the coordinates of any axes crossing points.

b

The curve is translated by the vector





2









0

, then stretched vertically with stretch factor 3.

Find the equation of the resulting curve, giving your answer in the form

2

=

+

y

ax bx

.

- 4 The function /arrowbarright f : 2 2 -x x is defined for the domain x 0 &gt; .
- a Find  f ( ) 1 -x and state the domain of  f 1 -.
- b On the same diagram, sketch the graphs of  f  and  f 1 -.
- 5 i Express 6 5 2 -+ -x x in the form ( ) , 2 + + a x b c where a , b and c

[5]

[3]

[2]

[2]

[4]

[3]

[3]

- are constants. [3]

The function

/arrowbarright

f

:

6

5

2

-

+

-

x

x

x

is defined for

&gt;

x

m

, where

m

is a constant.

- ii State the smallest possible value of m for which  f  is one-one.

iii

For the case where

[1]

=

5

m

, find an expression for  f

(

)

1

-

x

and state the domain of  f

1

-

.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 November 2015

- 6 The function /arrowbarright f : 4 2 -+ x x x k is defined for the domain &gt; x p , where k and p are constants.
- i Express  f( ) x in the form  ( ) 2 + + + x a b k , where a and b are constants.
- ii State the range of  f  in terms of k .

[2]

[1]

- iii State the smallest value of p for which  f  is one-one.

[1]

- iv For the value of p found in part iii , find an expression for  f ( ) 1 -x and state the domain of  f 1 -, giving your answer in terms of k . [4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 June 2012

2

67

68

7

1

<!-- image -->

The diagram shows the function f defined for 1 4 &lt; &lt; -x , where

$$f ( x ) = \begin{cases} 3 x - 2 & \text{ for } - 1 \leq x \leq 1, \\ \frac { 4 } { 5 - x } & \text{ for } 1 < x \leq 4. \end{cases}$$

- i
- State the range of  f. [1]
- ii Copy the diagram and on your copy sketch the graph of f ( ) y x . [2]
- 1 = -
- iii Obtain expressions to define the function f 1 -, giving also the set of values for which each expression is valid. [6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 June 2014

- 8 The function  f  is defined by  f( ) 4 24 11 2 = -+ x x x , for /Rbb ∈ x .
- i Express  f( ) x in the form ( ) 2 -+ a x b c graph of f( ) y x .
- and hence state the coordinates of the vertex of the = [4]

The function  g  is defined by  g(

)

4

24

11

2

=

-

+

x

x

x

, for

1

&lt;

x

.

- ii State the range of  g.

iii

[2]

Find an expression for  g

(

)

1

-

x

and state the domain of  g

1

-

.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 November 2012

- 9 i Express  2 12 13 2 -+ x x in the form ( ) 2 + + a x b c , where a , b and c are constants. [3]
- ii The function f is defined by  f( ) 2 12 13 2 = -+ x x x , for &gt; x k , where k is a constant. It is given that  f  is a one-one function. State the smallest possible value of k . [1]

The value of

k

is now given to be 7.

iii

Find the range of  f.

iv

Find the expression for  f

(

[1]

x

)

-

and state the domain of  f

1

-

.

[5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 June 2013

- 10 i Express 2 15 2 --x x in the form  ( ) 2 + + x a b .

[2]

The function  f  is defined for &lt; &lt; p x q , where p and q are positive constants, by

$$f \, \colon x \mapsto x ^ { 2 } - 2 x - 1 5.$$

The range of  f  is given by f( ) &lt; &lt; c x d , where c and d are constants.

- ii State the smallest possible value of c .

[1]

|    | For the case where 9 = c and 65 = d ,                                                                                                      |                                                                                  |
|----|--------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
|    | iii find p and q ,                                                                                                                         | [4]                                                                              |
|    | iv find an expression for f ( ) 1 - x .                                                                                                    | [3]                                                                              |
|    | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q10 November 2014                                                           | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q10 November 2014 |
| 11 | The function f is defined by /arrowbarright /Rbb f : 2 12 7 for 2 - + ∈ x x x x .                                                          |                                                                                  |
|    | i Express f( ) x in the form ( ) 2 - - a x b c .                                                                                           | [3]                                                                              |
|    | ii State the range of f.                                                                                                                   | [1]                                                                              |
|    | iii Find the set of values of x for which < x f( ) 21.                                                                                     | [3]                                                                              |
|    | The function g is defined by /arrowbarright /Rbb + ∈ x x k x g : 2 for .                                                                   |                                                                                  |
|    | iv Find the value of the constant k for which the equation gf( ) 0 = x has two equal roots.                                                | [4]                                                                              |
|    | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q9 June 2010                                                                | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q9 June 2010      |
| 12 | Functions f and g are defined for /Rbb ∈ x by                                                                                              |                                                                                  |
|    | + /arrowbarright f : 2 1, x x                                                                                                              |                                                                                  |
|    | - /arrowbarright g : 2. 2 x x                                                                                                              |                                                                                  |
|    | i Find and simplify expressions for fg( ) x and gf( ) x .                                                                                  | [2]                                                                              |
|    | ii Hence find the value of a for which fg( ) gf( ) = a a .                                                                                 | [3]                                                                              |
|    | iii Find the value of b ( ) ≠ b a for which g( ) = b b .                                                                                   | [2]                                                                              |
|    | iv Find and simplify an expression for x f g( ) 1 - .                                                                                      | [2]                                                                              |
|    | The function h is defined by                                                                                                               |                                                                                  |
|    | h : 2, 2 x x /arrowbarright - for 0 < x .                                                                                                  |                                                                                  |
|    | v Find an expression for h ( ) 1 - x .                                                                                                     | [2]                                                                              |
|    | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q11                                                                         | June 2011                                                                        |
| 13 | Functions f and g are defined by                                                                                                           |                                                                                  |
|    | /arrowbarright - + x x x f : 2 8 10 2 for 0 2 < < x ,                                                                                      |                                                                                  |
|    | /arrowbarright g : x x for 0 10 < < x .                                                                                                    |                                                                                  |
|    | i Express f( ) x in the form ( ) 2 + + a x b c , where a , b and c are constants.                                                          | [3]                                                                              |
|    | ii State the range of f.                                                                                                                   | [1]                                                                              |
|    | iii State the domain of f 1 - .                                                                                                            | [1]                                                                              |
|    | iv Sketch on the same diagram the graphs of f( ), g( ) = = y x y x and f ( ) 1 = - y x , making clear the relationship between the graphs. | [4]                                                                              |
|    | v Find an expression for f ( ) 1 - x .                                                                                                     | [3]                                                                              |
|    | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q11 November                                                                | 2011                                                                             |

69

In this image we can see a globe.

<!-- image -->

70

## Chapter   3

## Coordinate geometry

## In this chapter you will learn how to:

- ■ fi  nd the equation of a straight line when given suffi  cient information
- ■ understand that the equation -+ -= x a y b r ( ) ( ) 2 2 2 represents the circle with centre a b ( , ) and radius r
- ■ interpret and use any of the forms = + y mx c , -= -y y m x x ( ), 1 1 + + = ax by c 0  in solving problems
- ■ use algebraic methods to solve problems involving lines and circles
- ■ understand the relationship between a graph and its associated algebraic equation, and use the relationship between points of intersection of graphs and solutions of equations.

## PREREQUISITE KNOWLEDGE

| Where it comes from        | What you should be able to do                                                                   | Check your skills                                                                                                                               |
|----------------------------|-------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Find the midpoint and length of a line segment.                                                 | 1 Find the midpoint and length of the line segment joining ( 7, 4) - and ( 2, 8) - - .                                                          |
| IGCSE / OLevel Mathematics | Find the gradient of a line and state the gradient of a line that is perpendicular to the line. | 2 a Find the gradient of the line joining ( ) - 1, 3 A and ( ) 5, 2 B . b State the gradient of the line that is perpendicular to the line AB . |
| IGCSE / OLevel Mathematics | Interpret and use equations of lines of the form y mx c = + .                                   | 3 The equation of a line is = - 2 3 5. y x Write down: a the gradient of the line b the y -intercept c the x -intercept.                        |
| Chapter 1                  | Complete the square and solve quadratic equations.                                              | 4 a Complete the square for 8 5. 2 - - x x b Solve 8 5 0. 2 - - = x x .                                                                         |

## Why do we study coordinate geometry?

This chapter builds on the coordinate geometry work that you learnt at IGCSE / O Level. You shall also learn about the Cartesian equation of a circle. Circles are one of a collection of mathematical shapes called conics or conic sections.

A conic section is a curve obtained from the intersection of a plane with a cone. The three types of conic section are the ellipse, the parabola and the hyperbola. The circle is a special case of the ellipse. Conic sections provide a rich source of fascinating and beautiful results that mathematicians have been studying for thousands of years.

<!-- image -->

Conic sections are very important in the study of astronomy. We also use their reflective properties in the design of satellite dishes, searchlights, and optical and radio telescopes.

<!-- image -->

## WEB LINK

The Geometry of equations and Circles stations on the Underground Mathematics website have many useful resources for studying this topic.

71

72

## 3.1 Length of a line segment and midpoint

At IGCSE / O Level you learnt how t o find the midpoint, M , of a line segment joining the points P x y ( , ) 1 1 and Q x y ( , ) 2 2 and the length of the line segment, PQ , using the two formulae in Key point 3.1. You need to know how to apply these formulae to solve problems.

## KEY POINT 3.1

To find the midpoint, M , of the line segment PQ : = + +       2 , 2 1 2 1 2 M x x y y

To find the length of PQ : = -+ -( ) ( ) 2 1 2 2 1 2 PQ x x y y

P

(

x

1

,

y

1

)

## TIP

It is important to remember to show appropriate calculations in coordinate geometry questions. Answers from scale drawings are not accepted.

## WORKED EXAMPLE 3.1

The point M -    3 2 , 11 is the midpoint of the line segment joining the points -P ( 7, 4) and Q a b ( , ).

Find the value of a and the value of b .

Answer

Method 1: Using algebra

- ( 7, 4)

( , ) a b

↑

↑

↑ ↑

( , ) 1 1 x y

( , ) 2 2 x y

$$\Big | \, \text{ Using } \left ( \frac { x _ { 1 } + x _ { 2 } } { 2 }, \frac { y _ { 1 } + y _ { 2 } } { 2 } \right ) \, \text{ and midpoint} = \left ( \frac { 3 } { 2 }, -11 \right ) \\ \Big | \, \text{ Using } \left ( \frac { - 7 + a } { 2 }, \frac { 4 + b } { 2 } \right ) = \left ( \frac { 3 } { 2 }, -11 \right )$$

$$\begin{smallmatrix} \, \frac { 1 } { 2 } \, \frac { 1 } { 2 } \, \end{smallmatrix}$$

x Equating the -coordinates:

=

a

-

+

7

3

2

2

a -+ = 7 3

a = 10

Equating the y b + = --coordinates: 4 2 11

b + = -4 22

b = -26

= = -Hence, 10 and 26. a b

Q

(

x

2

,

y

M

2

)

Decide which values to use for x y x y , , , 1 1 2 2 .

Method 2: Using vectors

$$\begin{bmatrix} \text{ Method 2: Using vectors} \\ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \& \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ \\ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &\ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &\ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \
 \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ } \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \  & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &
 \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &
 & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &  & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ \ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &
 \\ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &

\ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ &\ \\ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & &\ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ \ & \ & \ & \ & \ & \ & \ & \ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ \ & \ & \ & \ & \ \ & \ \ & \ & \ & \ & \ & \ & \ \ & \ & \ & \ \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \ & \$$

<!-- image -->

## WORKED EXAMPLE 3.2

Three of the vertices of a parallelogram, , ABCD are --A ( 5 , 1), --B ( 1, 4) and -C (6, 2).

- a Find the midpoint of AC .
- b Find the coordinates of D .

## Answer

$$\Big | \ a \ M i d p o n t { \ A C } = \left ( \frac { - 5 + 6 } { 2 }, \frac { - 1 + - 2 } { 2 } = \left ( \frac { 1 } { 2 }, - \frac { 3 } { 2 } \right )$$

- b Let the coordinates of D be , m n ( ) .

Since ABCD is a parallelogram, the midpoint of BD is the same as the midpoint of AC .

$$\text{Midpoint of } B D = \left ( \frac { - 1 + m } { 2 }, \frac { - 4 + n } { 2 } \right ) = \left ( \frac { 1 } { 2 }, - \frac { 3 } { 2 } \right )$$

Equating the

$$<_Scheme_> ; the x-coordinates: ------------- 1 + m ------------- 1 ------------- 2 ------------- 2 ------------- 3 ------------- 4 ------------- 5 ------------- 6 ------------- 7 ------------- 8 ------------- 9 ------------- 9 ------------- 10 ------------- 11 ------------- 12 ------------- 13 ------------- 14 ------------- 15 ------------- 16 ------------- 17 ------------- 18 ------------- 19 ------------- 20 ------------- 21 ------------- 22 ------------- 23 ------------- 24 ------------- 25 ------------- 26 ------------- 27 ------------- 28 ------------- 29 ------------- 29 ------------- 30 ------------- 31 ------------- 32 ------------- 33 ------------- 34 ------------- 35 ------------- 36 ------------- 37 ------------- 38 ------------- 39 ------------- 40 ------------- 41 ------------- 42 ------------- 43 ------------- 44 ------------- 45 ------------- 46 ------------- 47 ------------- 48 ------------- 49 ------------- 50 ------------- 51 ------------- 52 ------------- 53 ------------- 54 ------------- 55 ------------- 57 ------------- 58 ------------- 59 ------------- 59 ------------- 61 ------------- 62 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 -------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63 ------------- 63$$

m

=

2

y Equating the -coordinates:

D is the point (2, 1).

## WORKED EXAMPLE 3.3

The distance between two points -P a ( 2, ) and ( ) --2, 7 Q a is 17.

Find the two possible values of a .

## Answer

$$\Big | \ ( - 2, a ) \quad ( a - 2, - 7 ) \quad \cdots \\ \uparrow \uparrow \quad \uparrow \uparrow \\ ( x _ { 1 }, y _ { 1 } ) \quad ( x _ { 2 }, y _ { 2 } )$$

-

-

4

+

2

4

+

n

n

n

= -

3

2

3

= -

=

1

<!-- image -->

Decide which values to use for x y x y , , , 1 1 2 2 .

73

74

= - + - = Using ( ) ( ) 17 2 1 2 2 1 2 PQ x x y y

- + + - - = ( 2 2) ( 7 ) 17 2 2 a a

+ - - = ( 7 ) 289 2 2 a a

+ + + = 49 14 289 2 2 a a a

+ - = 2 14 240 0 2 a a

+ - = 7 120 0 2 a a

- + = ( 8)( 15) 0 a a

- = + = 8 0 or 15 0 a a

= 8 or a

= - 15 a

Divide both sides by 2.

Collect terms on one side.

Expand brackets.

Square both sides.

Solve.

Factorise.

## EXPLORE 3.1

The triangle has sides of length 2 7 cm, 4 3 cm and 5 3 cm.

Tamar says that this triangle is right angled.

Discuss whether he is correct.

Explain your reasoning.

2√7

4√3

5√3

<!-- image -->

## EXERCISE 3A

- 1 Calculate the lengths of the sides of the triangle PQR .

Use your answers to determine whether or not the triangle is right angled.

- a -P ( 4, 6), Q (6, 1), R (2, 9)
- b -P ( 5, 2), Q (9, 3), -R ( 2, 8)
- 2 P (1, 6), -Q ( 2, 1) and -R (3, 2).

Show that triangle PQR is a right-angled isosceles triangle and calculate the area of the triangle.

- 3 The distance between two points, -P a ( , 1) and -( 5, ), Q a is 4 5.
- Find the two possible values of a .
- 4 The distance between two points, --P ( 3, 2) and ( , 2 ), Q b b is 10.

Find the two possible values of b .

- 5 The point --( 2, 3) is the midpoint of the line segment joining --P ( 6, 5) and Q a b ( , ).

Find the value of a and the value of b .

- 6 Three of the vertices of a parallelogram, , ABCD are -A ( 7, 3), --B ( 3, 11) and -C (3, 5).
- a Find the midpoint of AC .
- b Find the coordinates of D .
- c Find the length of the diagonals AC and BD .

- 7 The point P k k ( , 2 ) is equidistant from A (8, 11) and B (1, 12). Find the value of k .
- 8 Triangle ABC has vertices at -A ( 6, 3), B (3, 5) and -C (1, 4). Show that triangle ABC is isosceles and find the area of this triangle.
- 9 Triangle ABC has vertices at -A ( 7, 8), B k (3, ) and C (8, 5). Given that = AB BC 2 , find the value of k .
- 10 The line + = x y 4  meets the curve = -y x 8 5 at the points A and B . Find the coordinates of the midpoint of AB .
- 11 The line = -y x 3 meets the curve = y x 4 2 at the points A and B .
- a Find the coordinates of the midpoint of AB .
- b Find the length of the line segment AB .
- 12 In triangle ABC , the midpoints of the sides AB , BC and AC are (1, 4), (2, 0) and -( 4, 1), respectively. Find the coordinates of points A , B and C . PS

## 3.2 Parallel and perpendicular lines

At IGCSE / O Level you learnt how t o find the gradient of the line joining the points P x y ( , ) and Q x y ( , ) using the formula in Key point 3.2.

1 1 2 2

In this image, we can see a graph.

<!-- image -->

You also learnt the following rules about parallel and perpendicular lines.

In this image, we can see a diagram. There are two lines, one is parallel and the other is perpendicular.

<!-- image -->

75

76

We can also write the rule for perpendicular lines as:

## KEY POINT 3.3

If the gradients of two perpendicular lines are and , 1 2 m m then m m × = -1 1 2 .

You need to know how to apply the rules for gradients to solve problems involving parallel and perpendicular lines.

## WORKED EXAMPLE 3.4

The coordinates of three points are --A k ( 5, 15), B k (10, ) and -C k (6, ).

Find the two possible values of k if A , B and C are collinear.

## Answer

If A , B and C are collinear, then they lie on the same line.

= gradient of gradient of AB BC

- - - - = - - - ( 15) 10 ( 5) 6 10 k k k k

+ - = 15 15 2 k k k

+ = - 2( 15) (15 ) k k k

+ = - 2 30 15 2 k k k

- + = 13 30 0 2 k k

- - = ( 3)( 10) 0 k k

Simplify.

Cross-multiply.

Expand brackets.

Collect terms on one side.

Factorise.

Solve.

k k - = - = 3 0 or 10 0

3

or

10

∴

=

=

k

k

## WORKED EXAMPLE 3.5

The vertices of triangle ABC are A (11, 3), B k k (2 , ) and --C ( 1, 11).

- a Find the two possible values of k if angle ABC is ° 90 .
- b Draw diagrams to show the two possible triangles.

## Answer

- a Since angle ABC is ° 90 , × = -AB BC gradient of gradient of 1.

$$\frac { k - 3 } { 2 k - 1 1 } \times \frac { - 1 1 - k } { - 1 - 2 k } = - 1 \quad$$

-

+

Simplify the second fraction.

In this image, we can see a diagram.

<!-- image -->

## EXERCISE 3B

- 1 The coordinates of three points are -A ( 6, 4), B (4, 6) and C (10, 7).
- a Find the gradient of AB and the gradient of BC .
- b Use your answer to part a to decide whether or not the points A , B and C are collinear.
- 2 The midpoint of the line segment joining -P ( 4, 5) and Q (6, 1) is M .
- The point R has coordinates --( 3, 7).
- Show that RM is perpendicular to PQ .
- 3 Two vertices of a rectangle, , ABCD are --A ( 6, 4) and -B (4, 8).
- Find the gradient of CD and the gradient of BC .
- 4 The coordinates of three of the vertices of a trapezium, , ABCD are A (3, 5), -B ( 5, 4) and -C (1, 5).

AD is parallel to BC and angle ADC is ° 90 .

Find the coordinates of D .

- 5 The coordinates of three points are A (5, 8), B k ( , 5) and -C k ( , 4).

Find the value of k if A , B and C are collinear.

- 6 The vertices of triangle ABC are --A k ( 9, 2 8), B k (6, ) and C k ( , 12).

Find the two possible values of k if angle ABC is ° 90 .

77

78

- 7 A is the point (0, 8) and B is the point (8, 6).

Find the point C on the y -axis such that angle ABC is ° 90 .

- 8 Three points have coordinates A (7, 4), B (19, 8) and C k k ( , 2 ).

Find the value of the constant k for which:

- a C lies on the line that passes through the points A and B
- b angle CAB is ° 90 .
- 9 The line -= x a y b 1, where a and b are positive constants, meets the x -axis at P and the y -axis at Q .
- The gradient of the line PQ is 2 5 and the length of the line PQ is 2 29.

Find the value of a and the value of b .

- 10 P is the point -a a ( , 2) and Q is the point --a a (4 3 , ).
- a Find the gradient of the line PQ .
- b Find the gradient of a line perpendicular to PQ .
- c Given that the distance PQ is 10 5 , find the two possible values of a .
- 11 The diagram shows a rhombus ABCD .

M is the midpoint of BD .

- a Find the coordinates of M .
- b Find the value of a , the value of b and the value of c .
- c Find the perimeter of the rhombus.
- d Find the area of the rhombus.

<!-- image -->

## 3.3 Equations of straight lines

At IGCSE / O Level you learnt the equation of a straight line is:

<!-- image -->

## KEY POINT 3.4

- = + , y mx c where m is the gradient and c is the y -intercept, when the line is non-vertical. =
- x b when the line is vertical, where b is the x -intercept.

There is an alternative formula that we can use when we know the gradient of a straight line and a point on the line.

Consider a line, with gradient m , that passes through the known point A x y ( , ) 1 1 and whose general point is P x y ( , ).

<!-- image -->

$$\underline { y - y _ { 1 } }$$

$$\text{Gradient of } A P = m, \, \text{hence } \frac { y - y _ { 1 } } { x - x _ { 1 } } & = m \\ y - y _ { 1 } & = m ( x - x _ { 1 } )$$

## Multiply both sides by -( ) 1 x x .

## KEY POINT 3.5

The equation of a straight line, with gradient m , that passes through the point ( , ) x y is:

1 1 -= -( ) 1 1 y y m x x

## WORKED EXAMPLE 3.6

Find the equation of the straight line with gradient -2 that passes through the point (4, 1).

Answer

```
-= -= -= = -= ---= -+ + = Using ( ) with 2, 4 and 1: 1 2( 4) 1 2 8 2 9 1 1 1 1 y y m x x m x y y x y x x y
```

## WORKED EXAMPLE 3.7

Find the equation of the straight line passing through the points -( 4, 3) and -(6, 2).

Answer -( 4, 3) -(6, 2) ↑ ↑ ↑ ↑ x y ( , ) 1 1 Decide which values to use for x y x y , , , 1 1 2 2 . x y ( , ) 2 2 = = --= ----= -Gradient ( 2) 3 6 ( 4) 1 2 2 1 2 1 m y y x x -= -= -= -= -= -+ -= --+ = Using ( ) with 1 2 , 4 and 3: 3 1 2 ( 4) 2 6 4 2 2 1 1 1 1 y y m x x m x y y x y x x y

79

80

## WORKED EXAMPLE 3.8

Find the equation of the perpendicular bisector of the line segment joining -A ( 5, 1) and -B (7, 2).

Answer Gradient of = ----= -= -2 1 7 ( 5) 3 12 1 4 AB = Gradient of the perpendicular 4 Midpoint of ( ) = -+ + -      = -    5 7 2 , 1 2 2 1, 1 2 AB Use gradient = y y x x --2 1 2 1 . Use m m × = -1 1 2 . Use midpoint = x x y y + +     2 , 2 1 2 1 2 . ∴ The perpendicular bisector is the line with gradient 4 passing through the point -    1, 1 2 . -= -= = -= + = -= -= -Using ( ) with 1, 1 2 and 4: 1 2 4( 1) 4 4 2 8 9 1 1 1 1 1 2 y y m x x x y m y x y x y x Expand brackets and simplify. Multiply both sides by 2.

## EXERCISE 3C

- 1 Find the equation of the line with:
- a gradient 2 passing through the point (4, 9)
- b gradient -3 passing through the point -(1, 4)
- c gradient 2 3 -passing through the point -( 4, 3).
- 2 Find the equation of the line passing through each pair of points.
- a ( ) 1, 0 and (5, 6)
- b -(3, 5) and -( 2, 4)
- c -(3, 1) and --( 3, 5)
- 3 Find the equation of the line:
- a parallel to the line = -y x 3 5, passing through the point (1, 7)
- b parallel to the line + = x y 2 6, passing through the point -(4, 6)
- c perpendicular to the line = -y x 2 3, passing through the point (6, 1)
- d perpendicular to the line -= x y 2 3 12, passing through the point -(8, 3).
- 4 Find the equation of the perpendicular bisector of the line segment joining the points:
- a (5, 2) and -( 3, 6)
- b --( 2, 5) and (8, 1)
- c --( 2, 7) and -(5, 4).

- 5 The line l 1 passes through the points -P ( 10, 1) and Q (2, 10). The line l 2 is parallel to l 1 and passes through the point -(4, 1). The point R lies on , 2 l such that QR is perpendicular to l 2 . Find the coordinates of R .
- 6 P is the point -( 4, 2) and Q is the point -(5, 4).
- A line, l , is drawn through P and perpendicular to PQ to meet the y -axis at the point R .
- a Find the equation of the line l .
- b Find the coordinates of the point R .
- c Find the area of triangle PQR .
- 7 The line l 1 has equation -= x y 3 2 12  and the line l 2  has equation = -y x 15 2 . The lines l 1 and l 2 intersect at the point A .
- a Find the coordinates of A .
- b Find the equation of the line through A that is perpendicular to the line l 1 .
- 8 The perpendicular bisector of the line joining -A ( 10, 5) and --B ( 2, 1) intersects the x -axis at P and the y -axis at Q .
- a Find the equation of the line PQ .
- b Find the coordinates of P and Q .
- c Find the length of PQ .
- 9 The line l 1 has equation + = x y 2 5 10.

The line l 2  passes through the point --A ( 9, 6) and is perpendicular to the line l 1 .

- a Find the equation of the line l 2 .
- b Given that the lines l 1 and l 2 intersect at the point B , find the area of triangle ABO , where O is the origin.
- 10 The diagram shows the points E , F and G lying on the line + = x y 2 16.  The point G lies on the x -axis and = EF FG . The line FH is perpendicular to EG . Find the coordinates of E and F .
- 11 The coordinates of three points are --A ( 4, 1), -B (8, 9) and C k ( , 7). M is the midpoint of AB and MC is perpendicular to AB . Find the value of k .
- 12 The point P is the reflection of the point -( 2, 10) in the line -= x y 4 3 12. Find the coordinates of P .

<!-- image -->

81

82

- 13 The coordinates of triangle ABC are -A ( 7, 3), -B (3, 7) and C (8, 8). P is the foot of the perpendicular from B to AC .
- a Find the equation of the line BP .
- b Find the coordinates of P .
- c Find the lengths of AC and BP .
- d Use your answers to part c to find the area of triangle ABC .
- 14 The coordinates of triangle PQR are P (1, 1), Q (1, 8) and R (6, 6).
- a Find the equation of the perpendicular bisectors of:
- i PQ ii PR
- b Find the coordinates of the point that is equidistant from P , Q and R .
- 15 The equations of two of the sides of triangle ABC are + = x y 2 8  and + = x y 2 1. Given that A is the point -(2, 3) and that angle = ° ABC 90 ,  find: PS
- a the equation of the third side
- b the coordinates of the point B .
- 16 Find two straight lines whose x -intercepts differ by 7, whose y -intercepts differ by 5 and whose gradients differ by 2. PS
- Is your solution unique? Investigate further.
- [This question is based upon Straight line pairs on the Underground Mathematics website.]

## 3.4  The equation of a circle

In this section you will learn about the equation of a circle. A circle is defined as the locus of all the points in a plane that are a fixed distance (the radius) from a given point (the centre).

## EXPLORE 3.2

- 1 Use graphing software to draw each of the following circles. From your graphs find the coordinates of the centre and the radius of each circle, and copy and complete the following table.
- 2 Discuss your results with your classmates and explain how you can find the coordinates of the centre of a circle and the radius of a circle just by looking at the equation of the circle.

|    | Equation of circle           | Centre   | Radius   |
|----|------------------------------|----------|----------|
| a  | + = x y 25 2 2               |          |          |
| b  | - + - = x y ( 2) ( 1) 9 2 2  |          |          |
| c  | + + + = x y ( 3) ( 5) 16 2 2 |          |          |
| d  | - + + = x y ( 8) ( 6) 49 2 2 |          |          |
| e  | + + = x y ( 4) 4 2 2         |          |          |
| f  | + + = x y ( 6) 64 2 2        |          |          |

## WEB LINK

Try the following resources on the Underground

Mathematics website:

- Lots of lines!

- Straight lines

- Simultaneous squares

- Straight line pairs.

T o find the equation of a circle, we let P x y ( , ) be any point on the circumference of a circle with centre C a b ( , ) and radius r .

<!-- image -->

Using Pythagoras' theorem on triangle CQP gives + = CQ PQ r . 2 2 2

Substituting = -CQ x a and = -PQ y b into + = CQ PQ r 2 2 2 gives:

$$( x - a ) ^ { 2 } + ( y - b ) ^ { 2 } = r ^ { 2 }$$

## KEY POINT 3.6

The equation of a circle with centre ( , ) a b and radius r can be written in completed square form as:

$$( x - a ) ^ { 2 } + ( y - b ) ^ { 2 } = r ^ { 2 }$$

## EXPLORE 3.3

The completed square form for the equation of a circle with centre a b ( , ) and radius r is -+ -= x a y b r ( ) ( ) . 2 2 2 Use graphing software to investigate the effects of:

- a increasing the value of a
- b decreasing the value of a
- c increasing the value of b
- d decreasing the value of b .

## WORKED EXAMPLE 3.9

Write down the coordinates of the centre and the radius of each of these circles.

- a + = x y 4 2 2
- b -+ -= x y ( 2) ( 4) 100 2 2
- c + + -= x y ( 1) ( 8) 12 2 2

## Answer

- a = Centre (0, 0), = = radius 4 2
- b = Centre (2, 4), = = radius 100 10
- c = -Centre ( 1, 8), = = radius 12 2 3

<!-- image -->

## DID YOU KNOW?

In the 17th century, the French philosopher and mathematician René Descartes developed the idea of using equations to represent geometrical shapes. The Cartesian coordinate system is named after this famous mathematician.

83

84

## WORKED EXAMPLE 3.10

Find the equation of the circle with centre -( 4, 3) and radius 6.

## Answer

-+ -= = -= = Equation of circle is ( ) ( ) , where 4, 3 and 6. 2 2 2 x a y b r a b r

$$( x - ( - 4)) ^ { 2 } + ( y - 3 ) ^ { 2 } = 6 ^ { 2 } \\ ( x + 4 ) ^ { 2 } + ( y - 3 ) ^ { 2 } = 36$$

## WORKED EXAMPLE 3.11

A is the point (3, 0) and B is the point -(7, 4).

Find the equation of the circle that has AB as a diameter.

## Answer

<!-- image -->

The centre of the circle, C , is the midpoint of AB .

$$C = \left ( \frac { 3 + 7 } { 2 } \,, \frac { 0 + ( - 4 ) } { 2 } \right ) = ( 5, - 2 )$$

Radius of circle, r , is equal to AC .

$$r = \sqrt { 5 - 3 } ^ { 2 } + ( - 2 - 0 ) ^ { 2 } = \sqrt { 8 }$$

-+ -= = = -= Equation of circle is ( ) ( ) , where 5, 2 and 8. 2 2 2 x a y b r a b r

$$( x - 5 ) ^ { 2 } + ( y + 2 ) ^ { 2 } = { \sqrt { 8 } } ^ { 2 }$$

$$( x - 5 ) ^ { 2 } + ( y + 2 ) ^ { 2 } = 8$$

-+ -= Expanding the equation ( ) ( ) gives: 2 2 2 x a y b r

$$x ^ { 2 } - 2 a x + a ^ { 2 } + y ^ { 2 } - 2 b y + b ^ { 2 } = r ^ { 2 }$$

$$x ^ { 2 } - 2 a x + a ^ { 2 } + y ^ { 2 } - 2 b y + b ^ { 2 } = r ^ { 2 }$$

Rearranging gives:

$$x ^ { 2 } + y ^ { 2 } - 2 a x - 2 b y + ( a ^ { 2 } + b ^ { 2 } - r ^ { 2 } ) = 0$$

When we write the equation of a circle in this form, we can note some important characteristics of the equation of a circle. For example:

- /uni25CF the coef ficients of x 2 and y 2 are equal
- /uni25CF there is no xy term.

We often write the expanded form of a circle as:

## KEY POINT 3.7

+ + + + = 2 2 0 2 2 x y gx fy c where ( , ) g f

--is the centre and + -2 2 g f c is the radius.

This is the equation of a circle in expanded general form .

## WORKED EXAMPLE 3.12

Find the centre and the radius of the circle + + --= x y x y 10 8 40 0. 2 2

## Answer

We answer this question b y first completing the square.

+ + --= 10 8 40 0 2 2 x x y y

+ -+ ---= ( 5) 5 ( 4) 4 40 0 2 2 2 2 x y

+ + -= ( 5) ( 4) 81 2 2 x y a = -5

b = 4

r = 81 2

= -Centre ( 5, 4) and = radius 9.

It is useful to remember the three following right angle facts for circles.

In this image, we can see a diagram. There are lines and points.

<!-- image -->

From these statements we can conclude that:

- /uni25CF If triangle ABC is right angled at B , then the points A , B and C lie on the circumference of a circle with AC as diameter.
- /uni25CF The perpendicular bisector of a chord passes through the centre of the circle.
- /uni25CF If a radius and a line at a point, P , on the circumference are at right angles, then the line must be a tangent to the curve.

Complete the square.

Collect constant terms together.

Compare with -+ -= x a y b r ( ) ( ) 2 2 2 .

## TIP

You should not try to memorise the formulae for the centre and radius of a circle in this form, but rather work them out if needed, as shown in Worked example 3.12.

85

86

## WORKED EXAMPLE 3.13

A circle passes through the points -P Q ( 1, 4), (1, 6) and R (5, 4).

Find the equation of the circle.

Answer

<!-- image -->

The centre of the circle lies on the perpendicular bisector of PQ and on the perpendicular bisector of QR .

$$\Big |    Midpoint of P Q = \left ( \frac { - 1 + 1 } { 2 }, \frac { 4 + 6 } { 2 } \right ) = ( 0, 5 )$$

= ---= Gradient of 6 4 1 ( 1) 1 PQ

Gradient of perpendicular bisector of PQ = -1

Equation of perpendicular bisector of PQ is:

$$\begin{smallmatrix} & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & &
 \\ & & & & & & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & & \\ & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & & & \\ & & & & & & \\ & & & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & \\ & & & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & \\ & & & & & \\ & & & & & & \\ & & & & & \\ & & & & & \\ & & & & \\ & & & & & \\ & & & & & \\ & & & & \\ & & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & \\ & & & \\ & & & & \\ & & & & \\ & & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & & \\ & & \\ & & & \\ & & & & \\ & & & & \\ & & & \\ & & & & \\ & & & \\ & & & & \\ & & \\ & & & \\ & & & & \\ & & \\ & & & \\ & & & & \\ & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & & \\ & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & \\ & & & \\ & & & \\ & & \\ & & & \\ & & \\ & & \\ & & \\ & & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & & \\ & \\ & & \\ & & \\ & & \\ & \\ & & \\ & & \\ & & \\ & & \\ & \\ & & \\ & & \\ & \\ & & \\ & \\ & & \\ & \\ & & \\ & \\ & & \\ & \\ & \\ & & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ \\ & \\ & \\ \\ & \\ \\ & \\ & \\ \\ & \\ \\ & \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\
 & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ & \\ &$$

$$\Big | \ M i d p o n t { \, Q R } = \left ( \frac { 1 + 5 \, \frac { 6 + 4 } { 2 } \, \right ) = ( 3, 5 )$$

= --= -Gradient of 4 6 5 1 1 2 QR

Gradient of perpendicular bisector of QR = 2

Equation of perpendicular bisector of QR is:

$$<_Python_>                                                                                                                                                                                                        
                                                                                                                                                                                                       

                                                                                                                                                                                                        (y - 5) = 2(x - 3)$$

Solving equations (1) and (2) gives:

$$x = 2, y = 3$$

= Centre of circle (2, 3)

$$\begin{array} { c } & \text{Radius} = C R = \sqrt{(5 - 2) ^ { 2 } + (4 - 3) ^ { 2 } } = \sqrt{0 } \end{array}$$

Hence, the equation of the circle is x y -+ -= ( 2) ( 3) 10 2 2 .

## Alternative method:

The equation of the circle is x a y b r -+ -= ( ) ( ) 2 2 2 .

The points ( 1, 4), (1, 6) and (5, 4) lie on the circle, so substituting gives:

---+ -= ( 1 ) (4 ) 2 2 2 a b r

+ + -+ = 2 8 17 2 2 2 a a b b r (1)

and similar for the other two points, giving equations (2) and (3).

Then subtracting (1) -(3) and (2) -(3) gives two simultaneous equations for a and b , which can then be solved.

Finally, substituting into (1) gives r 2 .

## EXERCISE 3D

- 1 Find the centre and the radius of each of the following circles.
- 2 Find the equation of each of the following circles.
- a centre (0, 0), radius 8
- b centre -(5, 2), radius 4
- c centre -( 1, 3), radius 7

- a + = x y 16 2 2

- b + = x y 2 2 9 2 2

- c + - = x y ( 2) 25 2 2

- d - + + = x y ( 5) ( 3) 4 2 2

- e + + = x y ( 7) 18 2 2

- f - + + = x y 2( 3) 2( 4) 45 2 2

- g + - + + = x y x y 8 20 110 0 2 2

- h + - - - = x y x y 2 2 14 10 163 0 2 2

$$\mathfrak { d } \ \text{centre} \left ( \frac { 1 } { 2 } \,, \, - \frac { 3 } { 2 } \right ), \, \text{radius} \ \frac { 5 } { 2 }$$

- 3 Find the equation of the circle with centre (2, 5) passing through the point (6, 8).
- 4 A diameter of a circle has its end points at -A ( 6, 8) and -B (2, 4). Find the equation of the circle.
- 5 Sketch the circle -+ + = x y ( 3) ( 2) 9. 2 2
- 6 Find the equation of the circle that touches the x -axis and whose centre is -(6, 5).
- 7 The points -P (1, 2) and Q (7, 1) lie on the circumference of a circle. Show that the centre of the circle lies on the line + = x y 4 2 15.
- 8 A circle passes through the points (3, 2) and (7, 2) and has radius 2 2. Find the two possible equations for this circle.
- 9 A circle passes through the points O A (0, 0), (8, 4) and B (6, 6). Show that OA is a diameter of the circle an d find the equation of this circle.
- 10 Show that + -+ = x y x y 6 2 6 2 2 can be written in the form -+ -= ( ) ( ) , 2 2 2 x a y b r where a , b and r are constants to be found. Hence, write down the coordinates of the centre of the circle and also the radius of the circle.

87

88

- 11 The equation of a circle is -+ + = x y ( 3) ( 2) 25 2 2 . Show that the point -A (6, 6) lies on the circle an d find the equation of the tangent to the circle at the point A .
- 12 The line + = x y 2 5 20  cuts the x -axis at A and the y -axis at B . The point C is the midpoint of the line AB . Find the equation of the circle that has centre C and that passes through the points A and B . Show that this circle also passes through the point O (0, 0).
- 13 The points --P Q ( 5, 6), ( 3, 8) and R (3, 2) are joined to form a triangle.
- a Show that angle PQR is a right angle.
- b Find the equation of the circle that passes through the points P , Q and R .
- 14 Find the equation of the circle that passes through the points (7, 3) and -(11, 1) and has its centre lying on the line + = x y 2 7.
- 15 A circle passes through the points O P (0, 0), (3, 9) and Q (11, 11).
- Find the equation of the circle.
- 16 A circle has radius 10 units and passes through the point -(5, 16). The x -axis is a tangent to the circle. Find the possible equations of the circle.
- 17  a The design shown is made from four green circles and one orange circle. PS
- i The radius of each green circle is 1 unit. Find the radius of the orange circle.
- ii Use graphing software to draw the design.
- b The design in part a is extended, as shown.
- i The radius of each green circle is 1 unit. Find the radius of the blue circle.
- ii Use graphing software to draw this extended design.

<!-- image -->

## 3.5  Problems involving intersections of lines and circles

In Chapter 1 you learnt that the points of intersection of a line and a curve can be found by solving their equations simultaneously. You also learnt that if the resulting equation is of the form + + = ax bx c 0 2 , then -b ac 4 2 gives information about the line and the curve.

| - b ac 4 2   | Nature of roots         | Line and parabola                             |
|--------------|-------------------------|-----------------------------------------------|
| 0 .          | two distinct real roots | two distinct points of intersection           |
| = 0          | two equal real roots    | one point of intersection (line is a tangent) |
| 0 ,          | no real roots           | no points of intersection                     |

In this section you will solve problems involving the intersection of lines and circles.

<!-- image -->

## WEB LINK

Try the following resources on the Underground

Mathematics website:

- Olympic rings
- Teddy bear.

## TIP

We can also describe an equation that has 'two equal real roots' as having 'one repeated (real) root'.

## WORKED EXAMPLE 3.14

The line = + x y 3 10  intersects the circle + = x y 20 2 2 at the points A and B .

- a Find the coordinates of the points A and B .
- b Find the equation of the perpendicular bisector of AB and show that it passes through the centre of the circle.
- c The perpendicular bisector of AB intersects the circle at the points P and Q .

Find the exact coordinates of P and Q .

```
Answer a 20 (3 10) 20 6 8 0 ( 2)( 4) 0 2 2 2 2 2 + = + + = + + = + + = x y y y y y y y y y = -= -2 or 4 When y x = -= 2, 4 and when y x = -= -4, 2. A and B are the points ---( 2, 4) and (4, 2). b = -----= = = -+ -+ -      = --= ---= --Gradient of 2 ( 4) 4 ( 2) 1 3 So the gradient of the perpendicular bisector -3. Midpoint of 2 4 2 , 4 ( 2) 2 (1, 3) ( ) ( 3) 3( 1) 1 1 AB AB y y m x x y x Perpendicular bisector is y x = -3 . When x = 0, y = -= 3(0) 0. Hence, the perpendicular bisector of AB passes through the point (0, 0), the centre of the circle x y + = 20 2 2 . c x y x x + = = = ± 20 10 20 2 2 2 2 When x y = -= 2, 3 2  and when x y = = -2, 3 2. P and Q are the points ( ) ( ) --2, 3 2 and 2, 3 2 , respectively. Use m = -3, = x 1 1 and = -y 3 1 . Substitute -x 3 for y . Substitute + y 3 10 for x . Expand and simplify. Factorise.
```

89

90

## WORKED EXAMPLE 3.15

Show that the line = -y x 13  is a tangent to the circle + -+ + = x y x y 8 6 7 0. 2 2 Answer 8 6 7 0 ( 13) 8 6( 13) 7 0 14 49 0 ( 7)( 7) 0 7 or 7 2 2 2 2 2 + -+ + = + --+ -+ = -+ = --= = = x y x y x x x x x x x x x x The equation has one repeated root, hence y x = -13 is a tangent. Substitute -x 13  for y . Expand and simplify. Factorise.

## EXERCISE 3E

- 1 Find the points of intersection of the line = -y x 3 and the circle -+ + = x y ( 3) ( 2) 20. 2 2
- 2 The line -+ = x y 2 3 0  intersects the circle + -+ -= x y x y 4 6 12 0 2 2 at two points, D and E .
- Find the length of DE .
- 3 Show that the line + = x y 3 6  is a tangent to the circle + + + + = x y x y 4 16 28 0. 2 2
- 4 Find the set of values of m for which the line = + y mx 1 intersects the circle -+ -= x y ( 7) ( 5) 20 2 2 at two distinct points.
- 5 The line -= y x 2 12  intersects the circle + --+ = x y x y 10 12 36 0 2 2 at the points A and B .
- a Find the coordinates of the points A and B .
- b Find the equation of the perpendicular bisector of AB .
- c The perpendicular bisector of AB intersects the circle at the points P and Q .
- Find the exact coordinates of P and Q .
- d Find the exact area of quadrilateral APBQ .
- 6 Show that the circles x y + = 25 2 2 and x y x y + --+ = 24 18 125 0 2 2 touch each other. PS
- Find the coordinates of the point where they touch.
- [This question is taken from Can we show that these two circles touch? on the Underground Mathematics website.]
- 7 Two circles have the following properties: PS
- /uni25CF the x -axis is a common tangent to the circles
- /uni25CF the point (8, 2) lies on both circles
- /uni25CF the centre of each circle lies on the line + = x y 2 22.
- a Find the equation of each circle.
- b Prove that the line + = x y 4 3 88  is a common tangent to these circles.

[Inspired by Can we find the two circles that satisfy these three conditions? on the Underground Mathematics website.]

## Checklist of learning and understanding

## Midpoint, gradient and length of line segment

<!-- image -->

- /uni25CF Midpoint, M , of + +       is 2 , 2 1 2 1 2 PQ x x y y .
- /uni25CF Gradient of --is 2 1 2 1 PQ y y x x .
- /uni25CF Length of segment -+ -is ( ) ( ) 2 1 2 2 1 2 PQ x x y y

## Parallel and perpendicular lines

- /uni25CF If the gradients of two parallel lines are and , 1 2 m m then 1 2 = m m .
- /uni25CF If the gradients of two perpendicular lines are and , 1 2 m m then 1 1 2 × = -m m .

## The equation of a straight line is:

- /uni25CF ( ) 1 1 -= -y y m x x , where m is the gradient and  ( , ) 1 1 x y is a point on the line.

## The equation of a circle is:

- /uni25CF ( ) ( ) 2 2 2 -+ -= x a y b r , where ( , ) a b is the centre and r is the radius.
- /uni25CF 2 2 0 2 2 + + + + = x y gx fy c , where ( , ) --g f is the centre and + -2 2 g f c is the radius.

91

92

## END-OF-CHAPTER REVIEW EXERCISE 3

1

A line has equation

+

=

x

y

2

20  and a curve has equation

=

+

18

x

-

y

a

3

, where

Find the set of values of a for which the line does not intersect the curve.

<!-- image -->

The diagram shows the curve = y x 7 and the line = + y x k 6 , where k is a constant.

The curve and the line intersect at the points A and B .

- i For the case where = k 2 , find the x -coordinates of A and B . [4]
- ii Find the value of k for which y x k 6 is a tangent to the curve y x 7 . [2]
- = + =

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 June 2012

- 3 A is the point a ( , 3) and B is the point b (4, ).
- The length of the line segment AB is 4 5 units and the gradientis -1 2 .
- Find the possible values of a and b
- . [6]
- 4 The curve = -y x 3 2  and the line -+ = x y 3 4 3 0  intersect at the points P and Q .
- Find the length of PQ .
- 5 The line -= ax y 2 30  passes through the points A (10, 10) and B b b ( , 10 ), where a and b are constants.
- a Find the values of a and b .
- b Find the coordinates of the midpoint of AB .

[6]

[3]

[1]

- c Find the equation of the perpendicular bisector of the line AB
- . [3]
- 6 The line with gradient -2 passing through the point P t t (3 , 2 ) intersects the x -axis at A and the y -axis at B .
- i Find the area of triangle AOB in terms of t .

[3]

- The line through P perpendicular to AB intersects the x -axis at C .
- ii Show that the mid-point of PC lies on the line y x . [4]
- =

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q6 June 2015

- 7 The point P is the reflection of the point -( 7, 5) in the line -= x y 5 3 18.

Find the coordinates of P . Y ou must show all your working.

- 2

a

is a constant.

[4]

- 8 The curve = + -y x x 2 4 and the line -+ = x y 2 6 0  intersect at the points A and B .
- a Find the coordinates of these two points.
- b Find the perpendicular bisector of the line AB .
- 9 The line = + y mx 1 intersects the circle + --= x y x 19 51 0 2 2 at the point P (5, 11).
- a Find the coordinates of the point Q
- where the line meets the curve again. [4]
- b Find the equation of the perpendicular bisector of the line PQ
- . [3]
- c Find the x -coordinates of the points where this perpendicular bisector intersects the circle.

Give your answers in exact form.

<!-- image -->

The diagram shows a triangle ABC in which A is -(3, 2) and B is (15, 22). The gradients of AB , AC and BC are m 2 , -m 2 and m respectively, where m is a positive constant.

- i Find the gradient of AB and deduce the value of m
- . [2]
- ii Find the coordinates of C .

The perpendicular bisector of AB meets BC at D .

- iii Find the coordinates of D .

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 June 2010

- 11 The point A has coordinates -( 1, 6) and the point B has coordinates (7, 2).
- i Find the equation of the perpendicular bisector of AB , giving your answer in the form y mx c . [4]
- = +
- ii A point C on the perpendicular bisector has coordinates p q ( , ). The distance OC is 2 units, where O is the origin. Write down two equations involving p and q and henc e find the coordinates of the possible positions of C .

[5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 November 2013

[4]

- 10

[4]

[4]

[4]

94

- 12 The coordinates of A are -( 3, 2) and the coordinates of C are (5, 6).

The mid-point of AC is M and the   perpendicular bisector of AC cuts the x -axis at B .

- i Find the equation of MB and the coordinates of B
- . [5]
- ii Show that AB is perpendicular to BC .

[2]

- iii Given that ABCD is a square , find the coordinates of D and the length of AD . [2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 June 2012

- 13 The points -A (1, 2) and B (5, 4) lie on a circle with centre C p (6, ).
- a Find the equation of the perpendicular bisector of the line segment AB
- b Use your answer to part a to find the value of p .
- c Find the equation of the circle.

<!-- image -->

ABCD is a trapezium with AB parallel to DC and angle = ° BAD 90 .

- a Calculate the coordinates of D .
- b Calculate the area of trapezium ABCD .
- 15 The equation of a curve is = xy 12  and the equation of a line is + = x y k 3 , where k is a constant.
- a In the case where = k 20, the line intersects the curve at the points A and B .

Find the midpoint of the line

AB

.

- b Find the set of values of k for which the line + = x y k 3 intersects the curve at two distinct points.
- 16 A is the point -( 3, 6) and B is the point -(9, 10).
- a Find the equation of the line through A and B .

[3]

- b Show that the perpendicular bisector of the line AB is -= x y 3 4 17. [3]
- c A circle passes through A and B and has its centre on the line = x 15. Find the equation of this circle.

[4]

- 17 The equation of a circle is x y x y + -+ + = 8 4 4 0 2 2 .
- a Find the radius of the circle and the coordinates of its centre.
- b Find the x -coordinates of the points where the circle crosses the x -axis, giving your answers in exact form.

[4]

[4]

- c Show that the point -A (6, 2 3 2)  lies on the circle.

[2]

- d Show that the equation of the tangent to the circle at A is + = -x y 3 3 12 3 6. [4]
- . [4]

[1]

[4]

[7]

[2]

[4]

[4]

14

## CROSS-TOPIC REVIEW EXERCISE 1

- 1 Solve the equation 4 18 17 4 2 + = x x .

2

<!-- image -->

The diagram shows the graph of f( ) = y x for 4 4 -&lt; &lt; x .

Sketch on separate diagrams, showing the coordinates of any turning points, the graphs of:

- a f( ) 5 = + y x
- b 2f( ) = -y x
- 3 The graph of  f( ) = + x ax b is r eflected in the y -axis and then translated by the vector       0 3 . The resulting function is  g( ) 1 5 = -x x . Find the value of a and the value of b .
- 4 The graph of ( 1) 2 = + y x is transformed by the composition of two transformations to the graph of 2( 4) 2 = -y x . Find these two transformations.
- 5 The graph of 1 2 = + y x is transformed by applying a reflection in the x -axis followed by a translation of       3 2 . Find the equation of the resulting graph in the form 2 = + + y ax bx c .

6

-3

<!-- image -->

The diagram shows the graph of f( ) = y x for 3 3 -&lt; &lt; x .

Sketch the graph of 2 f( ) = -y x .

[4]

[2]

[2]

[4]

[4]

[4]

95

96

| 7   | The function f is such that f( ) 5 5 2 = - + x x x for /Rbb x ∈ .                                                                                                |                                                                                 |
|-----|------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------|
|     | a Find the set of values of x for which f( ) < x x .                                                                                                             | [3]                                                                             |
|     | b The line 11 = - y mx is a tangent to the curve f( ) = y x .                                                                                                    |                                                                                 |
|     | Find the two possible values of m .                                                                                                                              | [3]                                                                             |
| 8   | The line 0 2 + + = x ky k , where k is a constant, is a tangent to the curve 4 2 = y x at the point P .                                                          |                                                                                 |
|     | Find, in terms of k , the coordinates of P .                                                                                                                     | [6]                                                                             |
| 9   | A is the point (4, 6) - and B is the point (12, 10). The perpendicular bisector of AB intersects the x -axis at C and the y -axis at D . Find the length of CD . |                                                                                 |
|     |                                                                                                                                                                  | [6]                                                                             |
| 10  | The points A , B and C have coordinates (2, 8), (9, 7) A B and ( , 2) - C k k .                                                                                  |                                                                                 |
|     | a Given that = AB BC , show that a possible value of k is 4 and find the other possible value of k .                                                             | [3]                                                                             |
|     | b For the case where 4 = k , find the equation of the line that bisects angle ABC .                                                                              | [4]                                                                             |
| 11  | Acurve has equation 12 = + xy x and a line has equation 9 = - y kx , where k is a constant.                                                                      |                                                                                 |
|     | a In the case where 2 = k , find the coordinates of the points of intersection of the curve and the line.                                                        | [3]                                                                             |
|     | b Find the set of values of k for which the line does not intersect the curve.                                                                                   | [4]                                                                             |
| 12  | The function f is such that f( ) 2 3 = - x x for x k > , where k is a constant.                                                                                  |                                                                                 |
|     | The function g is such that g( ) 4 2 = - x x for 4 - > x .                                                                                                       |                                                                                 |
|     | a Find the smallest value of k for which the composite function gf can be formed.                                                                                | [3]                                                                             |
|     | b Solve the inequality gf( ) 45 . x .                                                                                                                            | [4]                                                                             |
| 13  | The functions f and g are defined by                                                                                                                             |                                                                                 |
|     | f( ) 4 2 = - x for 0 . x ,                                                                                                                                       |                                                                                 |
|     | x 4                                                                                                                                                              |                                                                                 |
|     | = for > x                                                                                                                                                        |                                                                                 |
|     | g( ) 5 2 + x x 0 .                                                                                                                                               |                                                                                 |
|     | i Find and simplify an expression for fg( ) x and state the range of fg.                                                                                         | [3]                                                                             |
|     | ii Find an expression for g ( ) 1 - x and find the domain of g 1 - .                                                                                             | [5]                                                                             |
|     | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q8 November 2016                                                                                  | Cambridge International AS & A Level Mathematics 9709 Paper 11 Q8 November 2016 |
| 14  | The equation 0 2 + + = x bx c has roots 2 - and 7.                                                                                                               |                                                                                 |
|     | a Find the value of b and the value of c .                                                                                                                       | [2]                                                                             |
|     | b Using these values of b and c , find:                                                                                                                          |                                                                                 |
|     | i the coordinates of the vertex of the curve 2 = + + y x bx c                                                                                                    | [3]                                                                             |
|     | ii the set of values of x for which 10 2 + + , x bx c .                                                                                                          | [3]                                                                             |

- 15 The line 1 L passes through the points ( 6, 10) -A and (6, 2) B . The line 2 L is perpendicular to 1 L and passes through the point ( 7, 2) -C .

|    | through the point ( 7, 2) - C .                                                                       |     |
|----|-------------------------------------------------------------------------------------------------------|-----|
|    | a Find the equation of the line 2 L .                                                                 | [4] |
|    | b Find the coordinates of the point of intersection of lines 1 L and 2 L .                            | [4] |
| 16 | Acurve has equation 12 2 = - y x x .                                                                  |     |
|    | a Express 12 2 - x x in the form ( ) 2 - + a x b , where a and b are constants to be determined.      | [3] |
|    | b State the maximum value of 12 2 - x x .                                                             | [1] |
|    | The function g is defined as g: 12 2 /arrowbarright - x x x , for 6 x ù .                             |     |
|    | c State the domain and range of g 1 - .                                                               | [2] |
|    | d Find g ( ) 1 - x .                                                                                  | [3] |
| 17 | a Express 3 12 1 2 + - x x in the form ( ) 2 + + a x b c , where a , b and c are constants.           | [3] |
|    | b Write down the coordinates of the vertex of the curve 3 12 1 2 = + - y x x .                        | [2] |
|    | c Find the set of values of k for which 3 12 1 4 2 + - = - x x kx has no real solutions.              | [4] |
| 18 | The function f is such that f( ) 2 1 = + x x for /Rbb ∈ x .                                           |     |
|    | The function g is such that g( ) 8 2 = - - x ax bx for > x k , where a , b and k are constants.       |     |
|    | The function fg is such that fg( ) 17 24 4 2 = - - x x x for > x k .                                  |     |
|    | a Find the value of a and the value of b .                                                            | [3] |
|    | b Find the least possible value of k for which g has an inverse.                                      | [4] |
|    | c For the value of k found in part b , find g ( ) 1 - x .                                             | [2] |
| 19 | Acircle has centre (8, 3) and passes through the point (13, 5) P .                                    |     |
|    | a Find the equation of the circle.                                                                    | [4] |
|    | b Find the equation of the tangent to the circle at the point P .                                     |     |
|    | Give your answer in the form + = ax by c .                                                            | [5] |
| 20 | The function f is such that f( ) 3 7 = - x x for /Rbb ∈ x .                                           |     |
|    | The function g is such that g( ) 18 5 = - x x for /Rbb ∈ x , 5 ≠ x .                                  |     |
|    | a Find the value of x for which fg( ) 5 = x .                                                         | [3] |
|    | b Find f ( ) 1 - x and g ( ) 1 - x .                                                                  | [3] |
|    | c Show that the equation f ( ) g ( ) 1 1 = - - x x has no real roots.                                 | [3] |
| 21 | Acurve has equation 2 3 2 = - - y x x .                                                               |     |
|    | a Express 2 3 2 - - x x in the form ( ) 2 - + a x b , where a and b are constants.                    | [2] |
|    | b Write down the coordinates of the maximum point on the curve.                                       | [1] |
|    | c Find the two values of m for which the line 3 = + y mx is a tangent to the curve 2 3 = - - y x x    | [3] |
|    | d For each value of m in part c , find the coordinates of the point where the line touches the curve. | [3] |

98

| 22   | Acircle, C , has equation 16 36 0 2 2 + - - = x y x .                                                                                                                                             |     |
|------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
|      | a Find the coordinates of the centre of the circle.                                                                                                                                               | [2] |
|      | b Find the radius of the circle.                                                                                                                                                                  | [2] |
|      | c Find the coordinates of the points where the circle meets the x -axis.                                                                                                                          | [2] |
|      | d The point P lies on the circle and the line L is a tangent to C at the point P . Given that the line L has gradient 4 3 , find the equation of the perpendicular to the line L at the point P . | [3] |
| 23   | The function f is such that f( ) 3 2 = - x x for 0 > x .                                                                                                                                          |     |
|      | The function g is such that g( ) 2 8 2 = - x x for < x k , where k is a constant.                                                                                                                 |     |
|      | a Find the greatest value of k for which the composite function fg can be formed.                                                                                                                 | [3] |
|      | b For the case where 3 = - k :                                                                                                                                                                    |     |
|      | i find the range of fg                                                                                                                                                                            | [2] |
|      | ii find (fg) ( ) 1 - x and state the domain and range of (fg) 1 - .                                                                                                                               | [4] |
| 24   | Acurve has equation 20 = xy and a line has equation 2 + = x y k , where k is a constant.                                                                                                          |     |
|      | a In the case where 14 = k , the line intersects the curve at the points A and B .                                                                                                                |     |
|      | Find:                                                                                                                                                                                             |     |
|      | i the coordinates of the points A and B                                                                                                                                                           | [3] |
|      | ii the equation of the perpendicular bisector of the line AB .                                                                                                                                    | [4] |
|      | b Find the values of k for which the line is a tangent to the curve.                                                                                                                              | [4] |

In this image we can see a pole with lights.

<!-- image -->

99

## Chapter   4 Circular measure

## In this section you will learn how to:

- ■ understand the defi  nition of a radian, and use the relationship between radians and degrees
- ■ use the formulae θ = s r and θ = 1 2 2 A r to solve problems concerning the arc length and sector area of a circle.

100

## PREREQUISITE KNOWLEDGE

<!-- image -->

<!-- image -->

| Where it comes from        | What you should be able to do                                                                                        | Check your skills                                                                             |
|----------------------------|----------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Find the perimeter and area of sectors.                                                                              | 1 Find the perimeter and area of a sector of a circle with radius 6cm and sector angle ° 30 . |
| IGCSE / OLevel Mathematics | Use Pythagoras' theorem and trigonometry on right-angled triangles.                                                  | 2 5cm 12cm y cm x ° Find the value of x and the value of y .                                  |
| IGCSE / OLevel Mathematics | Solve problems involving the sine and cosine rules for any triangle and the formula: = Area of triangle 1 2 sin ab C | 3 x cm 8cm 6cm 40 ° Find the value of x and the area of the triangle.                         |

## Another measure for angles

At IGCSE / O Level, you will have always worked with angles that were measured in degrees. Have you ever wondered why there are ° 360  in one complete revolution? The original reason for choosing the degree as a unit of angular measure is unknown but there are a number of different theories.

- /uni25CF Ancient astronomers claimed that the Sun advanced in its path by one degree each day and that a solar year consisted of 360 days.
- /uni25CF The ancient Babylonians divided the circle into 6 equilateral triangles and then subdivided each angle at O into 60 further parts, resulting in 360 divisions in one complete revolution.
- /uni25CF 360 has many factors that make division of the circle so much easier.

Degrees are not the only way in which we can measure angles. In this chapter you will learn how to use radian measure. This is sometimes referred to as the natural unit of angular measure and we use it extensively in mathematics because it can simplify many formulae and calculations.

<!-- image -->

## 4.1  Radians

In the diagram, the magnitude of angle AOB is 1 radian.

1 radian is sometimes written as 1 rad, but often no symbol at all is used for angles measured in radians.

## KEY POINT 4.1

An arc equal in length to the radius of a circle subtends an angle of 1 radian at the centre.

It follows that the circumference (an arc of length π 2 r ) subtends an angle of π 2 radians at the centre, therefore:

## KEY POINT 4.2

π = ° 2 radians 360

π = ° radians 180

When an angle is written in terms of π , we usually omit the word radian (or rad).

Hence, π = ° 180 .

## Converting from degrees to radians

Since ° = π 180 , then ° = π 90 2 , ° = π 45 4 etc.

We can convert angles that are not simple fractions of ° 180  using the following rule.

## KEY POINT 4.3

To change from degrees to radians, multiply by π 180 .

## Converting from radians to degrees

Since π = ° 180 , π = ° 6 30 , π = ° 10 18 etc.

We can convert angles that are not simple fractions of π using the following rule.

## KEY POINT 4.4

To change from radians to degrees, multiply by π 180 .

$$( I t \text{ is useful to remember that } 1 \text{ radian } = 1 \times \frac { 1 8 0 } { \pi } \approx 5 7 ^ { \circ }. )$$

<!-- image -->

101

102

## WORKED EXAMPLE 4.1

- a Change ° 30  to radians, giving your answer in terms of π . b Change π 5 9 radians to degrees. Answer a Method 1: Method 2: ° = π 180 radians ° = × π     30 30 180 radians     ° = π 180 6 6 radians ° = π 30 6 radians ° = π 30 6 radians b Method 1: Method 2: radians 180 π = ° π = π × π     ° 5 9 radians 5 9 180 9 radians 20 π = ° 5 9 radians 100 π = ° 5 9 radians 100 π = °

In Worked example 4.1, we found that ° = π 30 6 radians.

There are other angles, which you should learn, that can be written as simple multiples of π .

There are:

| Degrees   |   ° 0 | ° 30   | ° 45   | ° 60   | ° 90   | ° 180   | ° 270   | ° 360   |
|-----------|-------|--------|--------|--------|--------|---------|---------|---------|
| Radians   |     0 | π 6    | π 4    | π 3    | π 2    | π       | π 3 2   | π 2     |

We can quickl y find other angles, such as ° 120 , using these known angles.

## EXERCISE 4A

- 1 Change these angles to radians, giving your answers in terms of π .

| a   | ° 20                            | b                               | ° 40                            | c                               | ° 25                            | ° 50                            | e 5                             | °                               |                                 |
|-----|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|
| f   | ° 150                           | g                               | ° 135                           | h                               | ° 210                           | ° 225                           | j                               | ° 300                           |                                 |
| k   | ° 65                            | l                               | ° 540                           | m                               | ° 9                             | ° 35                            | o                               | ° 600                           |                                 |
| 2   | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. | Change these angles to degrees. |
| a   | π 2                             | b                               | π 3                             | c                               | π 6                             | π 12                            | e                               | π 4 3                           |                                 |
| f   | π 4 9                           | g                               | π 3 10                          | h                               | π 7 12                          | π 9 20                          | j                               | π 9 2                           |                                 |
| k   | π 7 5                           | l                               | π 4 15                          | m                               | π 5 4                           | π 7 3                           | o                               | π 9 8                           |                                 |

Copyright Material  - Review Only -  Not for Redistribution

- 3 Write each of these angles in radians, correct to 3 signi ficant figures.
- 5 Copy and complete the tables, giving your answers in terms of π .
- 6 Use your calculator to find:
- a sin(0.7)
- d π cos 2
- b tan(1.5)

- a ° 28 b ° 32

- c ° 47

- d ° 200

- e ° 320

- 4 Write each of these angles in degrees, correct to 1 decimal place.

- a 1.2 rad b 0.8rad

- c 1.34rad

- d 1.52 rad

- e 0.79rad

| a   | Degrees   |   0 | 45   | 90    | 135   | 180   | 225   | 270   | 315   | 360   |     |     |     |     |
|-----|-----------|-----|------|-------|-------|-------|-------|-------|-------|-------|-----|-----|-----|-----|
|     | Radians   |   0 |      |       |       | π     |       |       |       | π 2   |     |     |     |     |
| b   | Degrees   |   0 | 30   | 60 90 |       | 120   | 150   | 180   | 210   | 240   | 270 | 300 | 330 | 360 |
|     | Radians   |   0 |      |       |       |       |       | π     |       |       |     |     |     | π 2 |

e

sin

π

3

- 7 Calculate the length of QR .
- 8 PS

<!-- image -->

5cm

<!-- image -->

Robert is told the size of angle BAC in degrees and he is then asked to calculate the length of the line BC . He uses his calculator but forgets that his calculator is in radian mode. Luckily he still manages to obtain the correct answer. Given that angle BAC is between ° 10  and ° 15 , use graphing software to help you find the size of angle BAC , correct to 2 decimal places.

- c cos(0.9)

f

π

tan

5

## TIP

You do not need to change the angle to degrees. You should set the angle mode on your calculator to radians.

103

104

## EXPLORE 4.1

Discuss and explain, with the aid of diagrams, the meaning of each of these words.

<!-- image -->

segment sector

<!-- image -->

Explain what is meant by:

- /uni25CF minor arc and major arc
- /uni25CF minor sector and major sector
- /uni25CF minor segment and major segment.

Given that the radius of a circle is  cm r and that the angle subtended at the centre of the circle by the chord AB is θ ° , discuss and write down an expression, in terms of r and θ , for finding each of the following:

<!-- image -->

- /uni25CF length of minor arc AB
- /uni25CF length of chord AB
- /uni25CF perimeter of minor sector AOB
- /uni25CF area of minor sector AOB
- /uni25CF perimeter of minor segment AOB
- /uni25CF area of minor segment AOB .

What would the answers be if the angle θ was measured in radians instead?

<!-- image -->

## DID YOU KNOW?

<!-- image -->

A geographical coordinate system is used to describe the location of any point on the Earth's surface. The coordinates used are longitude and latitude. 'Horizontal' circles and 'vertical' circles form the 'grid'. The horizontal circles are perpendicular to the axis of rotation of the Earth and are known as lines of latitude. The vertical circles pass through the North and South poles and are known as lines of longitude.

## 4.2  Length of an arc

From the de finition of a radian, an arc that subtends an angle of 1 radian at the centre of the circle is of length r . Hence, if an arc subtends an angle of θ radians at the centre, the length of the arc is θ r .

## KEY POINT 4.5

θ = Arc length r

## WORKED EXAMPLE 4.2

π

An arc subtends an angle of 3 radians at the centre of a circle with radius 15 cm. Find the length of the arc in terms of π .

Answer

θ = Arc length r

$$<_Perl_> 1 - 1v
  = 15 \times \frac { 1 } { 3 }
  - 2 - 2v - 2v$$

= π 5 cm

<!-- image -->

## WEB LINK

Try the Where are you? resource on the Underground Mathematics website.

<!-- image -->

## WORKED EXAMPLE 4.3

A sector has an angle of 1.5 radians and an arc length of 12 cm.

Find the radius of the sector.

## Answer

Arc length θ = r

12 1.5 = × r

8cm = r

## WORKED EXAMPLE 4.4

Triangle ABC is isosceles with 8cm = = AC CB .

CD is an arc of a circle, centre B , and angle = 0.9 ABC radians. Find:

- a the length of arc CD
- b the length of AD
- c the perimeter of the shaded region.

## Answer

- a Arc length θ = r

=

8

0.9

×

7.2 cm =

b

AB

=

×

2

8cos0.9

= -AD AB DB

= …-9.9457 8

= 1.95cm (to 3 significant figures)

## EXERCISE 4B

- 1 Find, in terms of π , the arc length of a sector of:
- a radius 8cm and angle π 4
- c radius 16cm and angle π 3 8
- 2 Find the arc length of a sector of:
- a radius 10 cm and angle 1.3 radians
- 3 Find, in radians, the angle of a sector of:
- a radius 10 cm and arc length 5cm
- b radius 12 cm and arc length 9.6cm.
- 4 The High Roller Ferris wheel in the USA has a diameter of 158.5 metres.
- Calculate the distance travelled by a capsule as the wheel rotates through π 16 radians.

=

9.9457

…

<!-- image -->

- c = + + DC CA AD Perimeter

= + + … 7.2 8 1.945

= 17.1cm (to 3 significant figures)

- b radius 7 cm and angle π 3 7
- d radius 24cm and angle π 7 6 .
- b radius 3.5cm and angle 0.65 radians.

105

106

- 5 Find the perimeter of each of these sectors.

<!-- image -->

b

<!-- image -->

- 6 The circle has radius 6cm and centre O . PQ is a tangent to the circle at the point P . QRO is a straight line. Find:
- a angle POQ , in radians
- b the length of QR
- c the perimeter of the shaded area.
- 7 The circle has radius 7 cm and centre O .

AB is a chord and angle = 2 AOB radians. Find:

- a the length of arc AB
- b the length of chord AB
- c the perimeter of the shaded segment.
- 8 ABCD is a rectangle with 5cm = AB and 24cm = BC .
- O is the midpoint of BC .
- OAED is a sector of a circle, centre O . Find:
- a the length of AO
- b angle AOD , in radians
- c the perimeter of the shaded region.
- 9 The diagram shows a semicircle with radius 10 cm and centre O . Angle = θ BOC radians. The perimeter of sector AOC is twice the perimeter of sector BOC .
- a Show that θ = π 2 3 .
- b Find the perimeter of triangle ABC .
- 10 The diagram shows the cross-section of two cylindrical metal rods of radii cm x and cm y . A thin band, of length cm P , holds the two rods tightly together. PS

$$\text{Show that } P = 4 \sqrt { x y } + \pi ( x + y ) + 2 ( x - y ) \sin ^ { - 1 } \left ( \frac { x - y } { x + y } \right ).$$

[This question is based upon Belt on the Underground Mathematics website.]

A

The image contains a diagram with several lines and points. Here is a detailed description of the image:

### Diagram Description:

- **Circle**: The diagram consists of a circle with a diameter labeled as diameter.
- **Points**: There are two points labeled as A and B.
- **Line Segments**:
  - **Line Segment AB**: This is a segment of the circle that is marked as 8 cm.
  - **Line Segment BC**: This is a segment of the circle that is marked as 4 cm.
  - **Line Segment CD**: This is a segment of the circle that is marked as 2 cm.
  - **Line Segment OE**: This is a segment of the circle that is marked as 7 cm.
  - **Line Segment OE**: This is a segment of the circle that is marked as 6 cm.
  - **Line Segment OE**: This is a segment of the

<!-- image -->

## 4.3  Area of a sector

<!-- image -->

T o find the formula for the area of a sector, we use the ratio:

area of sector angle in the sector

area of circle

=

complete angle at the centre

When θ is measured in radians, the ratio becomes:

$$\frac { \ a r e a \, \text{of sector} } { \pi r ^ { 2 } } & = \frac { \theta } { 2 \pi } \\ \ a r e a \, \text{of sector} & = \frac { \theta } { 2 \pi } \times \pi r ^ { 2 }$$

## KEY POINT 4.6

$$A r e a \, o f \, \text{sector} = \frac { 1 } { 2 } \, r ^ { 2 } \theta$$

## WORKED EXAMPLE 4.5

Find the area of a sector of a circle with radius 9 cm and angle π 6 radians. Give your answer in terms of π .

Answer

$$<_Ruby_>     # sumv:

    Area of sector = {-1,2,2}$$

## WORKED EXAMPLE 4.6

The circle has radius 6cm and centre O . AB is a chord and angle = 1.2 AOB radians. Find:

- a the area of sector AOB
- b the area of triangle AOB
- c the area of the shaded segment.

<!-- image -->

108

## Answer

$$<_Python_>     Answer
        a     Area of sector AOB = \frac { 1 } { 2 } r ^ { 2 } \theta$$

b

=

AOB

ab

C

Area of triangle sin

=

1

2

1

2

×

×

×

6

6

sin1.2

=

…

16.7767

= 16.8cm (to 3 significant figures) 2

Area of shaded segment

=

-

AOB

area of sector area of triangle

=

-

…

21.6

16.7767

= 4.82 cm (to 3 significant figures) 2

## WORKED EXAMPLE 4.7

The diagram shows a circle inscribed inside a square of side length 10 cm.

A quarter circle, of radius  10 cm, is drawn with the vertex of the square as centre.

Find the shaded area.

## Answer

10cm = OQ

Radius of inscribed circle 5cm =

Pythagoras:

1

2

(diagonal of square)

=

5

+

-

(5

2)

10

2

2

Cosine rule: cos

α

=

×

×

2

5

5

2

$$<_Ruby_>$$

β α = π -= Hence, 2 2 2.4189 rad

$$<_Rust_>     Sine rule: = {$$

θ = 0.4867 rad

= -Shaded area area of segment area of segment PQR PQS

$$= \left ( \frac { 1 } { 2 } \times 5 ^ { 2 } \times \beta - \frac { 1 } { 2 } \times 5 ^ { 2 } \times \sin \beta \right ) - \left ( \frac { 1 } { 2 } \times 10 ^ { 2 } \times 2 \theta - \frac { 1 } { 2 } \times 10 ^ { 2 } \times \sin 2 \theta \right )$$

14.6cm (to 3 significant figures)

$$<_Python_>                                                                                                                                                                                                        
                                                                                                                                                                                                       

                                                                                                                                                                                                        <p>                                                                                                                                                                                                        </p>                                                                                                                                                                                                     
 
                                                                                                                                                                                                      <p><p>                                                                                                                                                                                                      <p></p>$$

c

1

2

2

(

10

2

+

10

2

)

=

5

2 cm

AOB

<!-- image -->

<!-- image -->

O

## EXERCISE 4C

- 1 Find, in terms of π , the area of a sector of:
- a radius 12 cm and angle π 6 radians
- c radius 4.5cm and angle π 2 9 radians
- 2 Find the area of a sector of:
- a radius 34cm and angle 1.5 radian
- 3 Find, in radians, the angle of a sector of:
- a radius 4cm and area 9cm 2
- 4 AOB is a sector of a circle, centre O , with radius 8 cm.
- The length of arc AB is  10 cm. Find:
- a angle AOB , in radians
- b the area of the sector AOB .
- 5 The diagram shows a sector, POQ , of a circle, centre O , with radius 4cm. The length of arc PQ is 7 cm. The lines PX and QX are tangents to the circle at P and Q , respectively.

4cm

- a Find angle POQ , in radians.
- b Find the length of PX .
- c Find the area of the shaded region.
- 6 The diagram shows a sector, POR , of a circle, centre O , with radius 8 cm and sector angle π 3 radians. The lines OR and QR are perpendicular and OPQ is a straight line.
- Find the exact area of the shaded region.
- 7 The diagram shows a sector, AOB , of a circle, centre O , with radius 5cm and sector angle π 3 radians. The lines AP and BP are tangents to the circle at A and B , respectively.
- a Find the exact length of AP .
- b Find the exact area of the shaded region.
- The diagram shows three touching circles with radii 6cm, 4cm and 2 cm. Find the area of the shaded region.

O

Q

P

P

π

3

O

A

5cm

<!-- image -->

- 8 PS
- b radius 10 cm and angle π 2 5 radians
- d radius 9cm and angle π 4 3 radians.
- b radius 2.6cm and angle 0.9 radians.
- b radius 6cm and area 27 cm 2 .

R

8cm

O

π

3

B

X

Q

P

109

110

- 9 The diagram shows a semicircle, centre O , with radius 8 cm.
- FH is the arc of a circle, centre E . Find the area of:
- a triangle EOF
- b sector FOG
- c sector FEH
- d the shaded region.
- 10 The diagram shows a sector, EOG , of a circle, centre O , with radius  cm r . The line GF is a tangent to the circle at G , and E is the midpoint of OF .
- a The perimeter of the shaded region is cm P .
- Show that = + + π 3 (3 3 3 ) P r .
- b The area of the shaded region is cm 2 A . Show that = -π 6 (3 3 ) 2 A r .
- 11 The diagram shows two circles with radius  cm r .

The centre of each circle lies on the circumference of the other circle.

Find, in terms of r , the exact area of the shaded region.

- 12 The diagram shows a square of side length 10 cm. PS

A quarter circle, of radius 10 cm, is drawn from each vertex of the square. Find the exact area of the shaded region.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- 13 The diagram shows a circle with radius 1cm, centre O . PS
- Triangle AOB is right angled and its hypotenuse AB is a tangent to the circle at P . Angle = BAO x radians.
- a Find an expression for the length of AB in terms of tan x .
- b Find the value of x for which the two shaded areas are equal.
- 14 The diagram shows a sector, AOB , of a circle, centre O , with radius R cm and sector angle π 3 radians. P
- An inner circle of radius cm r touches the three sides of the sector.
- a Show that = 3 R r .
- b Show that = area of inner circle area of sector 2 3 .

<!-- image -->

## Checklist of learning and understanding

## Radians and degrees

<!-- image -->

- /uni25CF One radian is the size of the angle subtended at the centre of a circle, radius r , by an arc of length r .
- /uni25CF π = ° radians 180
- /uni25CF To change from degrees to radians, multiply by π 180 .
- /uni25CF To change from radians to degrees, multiply by π 180

.

## Arc length and area of a sector

<!-- image -->

- /uni25CF When θ is measured in radians, the length of arc θ is AB r .
- /uni25CF When θ is measured in radians, the area of sector θ is 1 2 2 AOB r .

111

112

## END-OF-CHAPTER REVIEW EXERCISE 4

1

<!-- image -->

The diagram shows an equilateral triangle, PQR , with side length 5 cm. M is the midpoint of the line QR . An arc of a circle, centre P , touches QR at M and meets PQ at X and PR at Y . Find in terms of π and 3:

- a the total perimeter of the shaded region

[5]

- b
- the total area of the shaded region. [3]

<!-- image -->

In the diagram, OAB is a sector of a circle with centre O and radius 8cm. Angle BOA is α radians. OAC is a semicircle with diameter OA . The area of the semicircle OAC is twice the area of the sector OAB .

- i Find α in terms of π . [3]
- ii Find the perimeter of the complet e figure in terms of π .

[2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q3 June 2013

<!-- image -->

The diagram shows triangle ABC in which AB is perpendicular to BC . The length of AB is 4 cm and angle CAB is α radians. The arc DE with centre A and radius 2 cm meets AC at D and AB at E . Find, in terms of α ,

- i the area of the shaded region,

[3]

- ii the perimeter of the shaded region.

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q6 June 2014

- 2
- 3

4

<!-- image -->

5

<!-- image -->

The diagram represents a metal plate , OABC consisting of a   sector OAB of a circle with centre O and radius r , together with a triangle OCB which is right-angled at C . Angle = θ AOB radians and OC is perpendicular to OA .

- i Find an expression in terms of r and θ for the perimeter of the plate.

[3]

- 1 , find the area of the plate. [3]
- ii For the case where = 10 r and θ = π 5

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 November 2011

<!-- image -->

The diagram shows a sector OAB of a circle with centre O and   radius r . Angle AOB is θ radians. The point C on OA is such that BC is   perpendicular to OA . The point D is on BC and the circular arc AD has centre C .

- i Find AC in terms of r and θ . [1]
- ii Find the perimeter of the shaded region ABD when θ = π 1 3 and = 4 r , giving your answer as an exact value.

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q6 November 2012

- 6 A piece of wire of length 24cm is bent to form the perimeter of a   sector of a circle of radius  cm r .
- i Show that the area of the sector, cm 2 A , is given by 12 2 A r r
- = -. [3]
- ii Express A in the form --( ) 2 a r b , where a and b
- are constants. [2]
- iii Given that r can vary, state the greatest value of A and find the corresponding angle of the sector. [2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 June 2015

113

114

7

- 8
- 9

<!-- image -->

The diagram shows a circle with centre A and radius r . Diameters CAD and BAE are perpendicular to each other. A larger circle has centre B and passes through C and D .

- i Show that the radius of the larger circle is 2 r
- . [1]
- ii Find the area of the shaded region in terms of r .

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 November 2015

<!-- image -->

In the diagram, AOB is a quarter circle with centre O and radius r . The point C lies on the arc AB and the point D lies on OB . The line CD is parallel to AO and angle = θ AOC radians.

- i Express the perimeter of the shaded region in terms of r , and
- θ π . [4]
- ii For the case where 5cm = r and θ = 0.6 , find the area of the shaded region.

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 June 2016

<!-- image -->

In the diagram, AB is an arc of a circle with centre O and radius 4cm. Angle AOB is α radians. The point D on OB is such that AD is   perpendicular to OB . The arc DC , with centre O , meets OA at C .

<!-- image -->

- 10
- i Find an expression in terms of α for the perimeter of the shaded region ABDC .

[4]

- ii For the case where α = π 1 6 , find the area of the shaded region ABDC , giving your answer in the form π k , where k is a constant to be determined.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 November 2014

<!-- image -->

The diagram shows a metal plate made by fixing together two pieces, OABCD (shaded) and OAED (unshaded). The piece OABCD is a minor sector of a circle with centre O and radius 2 r . The piece OAED is a major sector of a circle with centre O and radius r . Angle AOD is α radians. Simplifying your answers where possible, find, in terms of α , π and r ,

- i the perimeter of the metal plate,

[3]

- ii the area of the metal plate.

It is now given that the shaded and unshaded pieces are equal in area.

- iii Find α in terms of π .

[2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q6 November 2013

[3]

115

In this image we can see an arch.

<!-- image -->

116

## Chapter   5 Trigonometry

## In this section you will learn how to:

- ■ sketch and use graphs of the sine, cosine and tangent functions (for angles of any size, and using either degrees or radians)
- ■ use the notations -sin 1 x , -cos , 1 x -tan 1 x to denote the principal values of the inverse trigonometric relations
- ■ use the exact values of the sine, cosine and tangent of ° 30 , ° 45 , ° 60 , and related angles
- ■ use the identities θ θ θ = sin cos tan and θ θ + = sin cos 1 2 2
- ■ fi  nd all the solutions of simple trigonometrical equations lying in a specifi  ed interval.

In this image we can see a wall.

<!-- image -->

## PREREQUISITE KNOWLEDGE

<!-- image -->

| Where it comes from        | What you should be able to do                                       | Check your skills                                                                                          |
|----------------------------|---------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Use Pythagoras' theorem and trigonometry on right-angled triangles. | 1 B A C 1cm r cm θ ° Find each of the following in terms of r . a BC b θ sin c θ cos                       |
| Chapter 4                  | Convert between degrees and radians.                                | d θ tan 2 a Convert to radians. i ° 45 ii ° 720 iii ° 150 b Convert to degrees. i 6 π ii 7 2 π iii 13 12 π |
| IGCSE / OLevel Mathematics | Solve quadratic equations.                                          | 3 a Solve - = 5 0. 2 x x b Solve + - = 2 7 15 0. 2 x x                                                     |

## Why do we study trigonometry?

## FAST FORWARD

You should already know how to calculate lengths and angles using the sine, cosine and tangent ratios. In this chapter you shall learn about some of the special rules connecting these trigonometric functions together with the special properties of their graphs. The graphs of = sin y x and = cos y x are sometimes referred to as waves.

Oscillations and waves occur in many situations in real life. A few examples of these are musical sound waves, light waves, water waves, electricity, vibrations of an aircraft wing and microwaves. Scientists and engineers represent these oscillations/waves using trigonometric functions.

<!-- image -->

## WEB LINK

Try the Trigonometry: Triangles to functions resource on the Underground Mathematics website.

In the Pure Mathematics 2 &amp; 3 Coursebook, Chapter 3 you shall learn about the secant, cosecant and cotangent functions, which are closely connected to the sine, cosine and tangent functions. Y ou shall also learn many more rules involving these six trigonometric functions.

117

118

## 5.1  Angles between 0° and 90°

You should already know the following trigonometric ratios.

<!-- image -->

$$\Big | _ { y } \quad & \sin \theta = \frac { \text{opposite} } { \text{hypotenuse} } \quad & \cos \theta = \frac { \text{adjacent} } { \text{hypotenuse} } \quad & \tan \theta = \frac { \text{opposite} } { \text{adjacent} } \\ \Big | _ { y } \quad & \sin \theta = \frac { y } { r } \quad & \cos \theta = \frac { x } { r } \quad & \tan \theta = \frac { y } { x }$$

## WORKED EXAMPLE 5.1

$$\Big | \ \cos \theta = \frac { \sqrt { 5 } } { 3 }, \, \text{where } \, 0 ^ { \circ } \leq \theta \leq 9 0 ^ { \circ }.$$

- a Find the exact values of:

$$i \ \cos ^ { 2 } \theta \quad \text{ii} \ \sin \theta \quad \text{iii} \ \tan \theta$$

$$\Big | \begin{array} { c c } i & \cos ^ { 2 } \theta \\ b & \text{Show that } \frac { 1 - \tan ^ { 2 } \theta } { \cos \theta + \sin \theta } = \frac { 3 \sqrt { 5 } - 6 } { 5 } \,. \end{array}$$

Answer

- a i θ θ θ = × cos cos cos 2





5

2

=

=





3

5

3

×

5

3

=

5

9

- ii A right-angled triangle with angle θ is shown in this diagram.

Using Pythagoras' theorem:

$$<_Forth_> x = \sqrt{3} - (\sqrt{3}^{2} = 2
: sin0 = \frac{2}$$

<!-- image -->

$$<_Python_>$$

b 1 tan cos sin 1 2 5 5 3 2 3 1 5 5 2 3 3 5 5 2 3 5 2 5 5 2 5 2 3 5 6 5 2 2 θ θ θ ( ) ( ) ( )( ) -+ = -      + =     +       = + = -+ -= -Simplify. Multiply the numerator and denominator by 15. Multiply the numerator and denominator by 5 2 -. ( )( ) + -5 2 5 2 5 2 5 2 5 4 1 ( ) = -+ -=





TIP

θ cos 2 means θ (cos ) 2

We can obtain exact values of the sine, cosine and tangent of 30 ° , 45 ° and 60 °

$$\left ( \, \text{or} \, \frac { \pi } { 6 } \,, \frac { \pi } { 4 } \, \text{and} \, \frac { \pi } { 3 } \, \right ) \, \text{from the following two triangles.}$$

## Triangle 1

Consider a right-angled isosceles triangle whose two equal sides are of length 1 unit.

W e find the third side using Pythagoras' theorem:

$$\sqrt { 1 ^ { 2 } + 1 ^ { 2 } } = \sqrt { 2 }$$

## Triangle 2

Consider an equilateral triangle whose sides are of length 2 units.

The perpendicular bisector to the base splits the equilateral triangle into two congruent right-angled triangles.

We can find the height of the triangle using Pythagoras' theorem:

$$\sqrt { 2 ^ { 2 } - 1 ^ { 2 } } = \sqrt { 3 }$$

These two triangles give the important results:

|                | sin θ   | cos θ   | tan θ   |
|----------------|---------|---------|---------|
| 30 6 θ π = ° = | 1 2     | 3 2     | 1 3     |
| 45 4 θ π = ° = | 1 2     | 1 2     | 1       |
| 60 3 θ π = ° = | 3 2     | 1 2     | 3       |

## WORKED EXAMPLE 5.2

Find the exact value of:

## Answer

$$\left | \begin{array} { c c c } \text{Find the exact value of:} \\ a$$

$$<_Perl_> Answer$$

$$= \frac { 1 } { 2 \sqrt { 2 } } \quad \, \, \,$$

<!-- image -->

<!-- image -->

1

<!-- image -->

119

120

In this image, we can see a diagram.

<!-- image -->

## EXERCISE 5A

- 1 Given that  cos 4 5 θ = and that θ is acute , find the exact value of:
- a sin θ
- b tan θ

d

5

tan

- 2 Given that  tan 2 5 θ = and that θ is acute, find the exact value of:

θ

- a sin θ

$$\mathrm e \ \frac { 1 - \sin ^ { 2 } \theta } { \cos \theta }$$

- b cos θ
- d cos θ

sin

- 3 Given that sin 1 4 θ = and that θ is acute, find the exact value of:

θ

- a cos θ

$$\mathrm e \ \frac { 2 } { \sin \theta + 1 }$$

- b tan θ
- d sin cos tan θ θ θ
- e 1 tan 1 sin θ θ +
- 4 Find the exact value of each of the following.
- a sin30 cos60 ° °
- b sin 45 2 °
- d sin60 sin30 ° °
- e sin 45 2 tan60 2 ° + °
- 5 Find the exact value of each of the following.

$$\begin{matrix} & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & && & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & - & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & ; & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & + & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & _ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &, & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & = & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & b & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & ^ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & | & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &$$

- c θ θ 2sin cos
- f 3 sin θ -+
- 3 cos θ
- c sin cos 2 2 θ θ +
- f 5 1 cos θ +
- c 1 sin 2 θ -
- f 5 tan sin θ θ -
- c sin 45 cos30 ° + °
- f ° + ° ° ° sin 30 cos 30 2 sin 45 cos45 2 2
- c 1 2 sin 6 2 -π

$$f \quad \frac { \cos \frac { \pi } { 3 } + \tan \frac { \pi } { 6 } } { \sin \frac { \pi } { 3 } }$$

<!-- image -->

$$\mathfrak { P } \mathfrak { C } \ \ 6 \ \ \text{In the table, } 0 \leqslant \frac { \pi } { 2 } \ \text{and the missing function is from the list } \sin \theta, \tan \theta, \frac { 1 } { \cos \theta } \ \text{and } \frac { 1 } { \tan \theta }.$$

Without using a calculator, copy and complete the table.

|         | θ =…   | θ =…   | θ =…   |
|---------|--------|--------|--------|
| ……      | 1      | 3      | 1 3    |
| cos θ   | 1 2    | 1 2    | ……     |
| 1 sin θ | ……     | ……     | 2      |

## 5.2  The general definition of an angle

We need to be able to use the three basic trigonometric functions for any angle.

To do this we need a general definition for an angle:

An angle is a measure of the rotation of a line segment OP about a fixed point O .

The angle is measured from the positive x -direction. An anticlockwise rotation is taken as positive and a clockwise rotation is taken as negative.

The Cartesian plane is divided into four quadrants , and the angle θ is said to be in the quadrant where OP lies. In the previous diagram, θ is in the first quadrant.

<!-- image -->

## WORKED EXAMPLE 5.3

Draw a diagram showing the quadrant in which the rotating line OP lies for each of the following angles. In each case , find the acute angle that the line OP makes with the x -axis.

a 120 °

b 430 °

c

$$d = - \frac { 2 \pi } { 3 }$$

## Answer

## a 120 ° is an anticlockwise rotation.

Acute angle made with x -axis 60 = °

<!-- image -->

3

π

4

## b 430 ° is an anticlockwise rotation.

Acute angle made with x -axis 70 = °

<!-- image -->

121

122

In this image, we can see a diagram. There are two lines and a point.

<!-- image -->

The acute angle made with the x -axis is sometimes called the basic angle or the reference angle .

## EXERCISE 5B

- 1 For each of the following diagrams , find the basic angle of θ .
- 2 Draw a diagram showing the quadrant in which the rotating line OP lies for each of the following angles. On each diagram, indicate clearly the direction of rotation and state the acute angle that the line OP makes with the x -axis.
- a ° 100
- b -° 100
- c ° 310
- e ° 400
- g 7 6 π
- i 13 9 π
- d -° 150
- f 2 3 π
- h -π 5 3

The image consists of a diagram with two lines intersecting at a point. The lines are drawn with a straight line, and the point where they intersect is labeled as point O. The lines are drawn with a straight line, and the point where they intersect is labeled as point A.

The diagram includes two lines, one of which is a straight line, and the other is a curved line. The curved line is drawn with a straight line, and the point where it intersects is labeled as point B. The curved line is also drawn with a straight line, and the point where it intersects is labeled as point C.

The lines are drawn with a straight line, and the point where they intersect is labeled as point O. The lines are drawn with a straight line, and the point where they intersect is labeled as point A.

The diagram includes two points, labeled as point A and point B. The point A is located at the bottom of the diagram, and the point

<!-- image -->

$$j = - \frac { 1 7 \pi } { 8 }$$

- 3 In each part of this question you are given the basic angle, b , the quadrant in which θ lies and the range in which θ lies. Find the value of θ .
- a = ° 55 , b second quadrant, θ ° ° 0 360 , ,
- b 20 , b = ° third quadrant, θ -° ° 180 0 , ,
- c = ° 32 , b fourth quadrant, θ ° ° 360 720 , ,
- d 4 , b = π third quadrant, θ π 0 2 , ,
- e 3 , b = π second quadrant, θ π π 2 4 , ,
- f 6 , b = π fourth quadrant, θ - π -π 4 2 , ,

## 5.3  Trigonometric ratios of general angles

In general, trigonometric ratios of any angle θ in any quadrant are defined as:

<!-- image -->

Where x and y are the coordinates of the point P and r is the length of OP , where = + r x y 2 2 .

You need to know the signs of the three trigonometric ratios in each of the four quadrants.

## EXPLORE 5.1

<!-- image -->

By considering whether x and y are positive or negative ( + or -) in each of the four quadrants, copy and complete the table. ( r is positive in all four quadrants.)

| sin θ         |               | cos θ         | tan θ        |
|---------------|---------------|---------------|--------------|
| y r = + + = + | x r = + + = + | y x = + + = + | 1st quadrant |
| y r =         | x r = - + =   | - y x =       | 2nd quadrant |
| y r =         | x r =         | y x = - - = + | 3rd quadrant |
| y r = - + = - | x r =         | y x =         | 4th quadrant |

On a copy of the diagram, record which ratios are positive in each quadrant.

Th e first quadrant has been completed for you.

(All three ratios are positive in the first quadrant.)

<!-- image -->

<!-- image -->

123

124

The diagram shows which trigonometric functions are positive in each quadrant.

We can memorise this diagram using a mnemonic such as

' A ll S tudents T rust C ambridge'.

## WORKED EXAMPLE 5.4

Express in terms of trigonometric ratios of acute angles:

a sin 140 °

## Answer

- a The acute angle made with the x -axis is 40 ° .

In the second quadrant, sin is positive.

sin 140 sin 40 ° = °

- b The acute angle made with the x -axis is 50 ° .

In the third quadrant only tan is positive, so cos is negative.

-° = -° cos( 130 ) cos 50

<!-- image -->

- b -° cos( 130 )

<!-- image -->

## WORKED EXAMPLE 5.5

Given that θ = -cos 3 5 and that 180 270 θ ° ° ø ø , find the value of sin θ and the value of tan θ .

## Answer

θ is in the third quadrant.

sin is negative and tan is positive in this quadrant.

$$\begin{array} { c c c } & & & & & & \\ & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & & \\ & & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & & &
 & & & & & & & & & & & \\ & & & & & & &
 & & & & & & & & & & & \\ & & & & & & &
 & & & & & & & & & & & & \\ & & & & & & & & \\ & & & & & & &
 & & & & & & & & & & & \\ & & & & & & & & \\ & & & & & & & \\ & & & & & & & \\ & & & & & &
 & & & & & & & & & & & & \\ & & & & & & & \\ & & & & & & &
 & & & & & & & & & & &
 & & & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & &
 & & & & & & & & & & & & &
 & & & & & & & & & & & & & \\ & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & & & &
 & & & & & & & & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & & & &
 & & & & & & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & & & & &
 & & & & & & & & & & & &
 & & & & & & & & & & & & & &
 & & & & & & & & & & & & &
 & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & &
\ & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &


\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &


\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &



\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & &$$

$$1 6$$

Since y y 0, 4 &lt; = -.

$$\Big |                                                                                                                                                                                                        
                                                                                                                                                                                                       

                                                                                                                                                                                                        <4                                                                                                                                                                                                        </4                                                                                                                                                                                                       <5                                                                                                                                                                                                        +                                                                                                                                                                                                        -3                                                                                                                                                                                                        >                                                                                                                                                                                                        }                                                                                                                                                                                                        |$$

<!-- image -->

## WORKED EXAMPLE 5.6

<!-- image -->

Without using a calculator , find the exact values of:

- a sin 120 °

## Answer

- a 120 ° lies in the second quadrant.
- ∴ ° sin 120 is positive.

Basic acute angle 180 120 60 = ° -° = °

$$<_Perl_>.: sin 120° = sin 60° = \frac { 2 }$$

- b 7 6 π lies in the third quadrant.

∴

π

7

6

cos is negative.

$$<_Python_>$$

## WORKED EXAMPLE 5.7

Given that sin 50 , b ° = express each of the following in terms of b .

- a sin 230 °

b cos 50 °

- c tan 40 °

## Answer

- a 230 ° lies in the third quadrant.
- ∴ ° sin 230 is negative.

Basic acute angle 230 180 50 = ° -° = °

∴ ° = -° = -sin 230 sin 50 b

$$b \ \cos \frac { 7 \pi } { 6 }$$

y

<!-- image -->

y

<!-- image -->

- d tan 140 °

y

<!-- image -->

125

126

- b Draw the right-angled triangle showing the angle 50 : °

$$\begin{smallmatrix}. \cos 50 ^ { \circ } = \frac { \sqrt { 1 - b ^ { 2 } } } { 1 } = \sqrt { 1 - b ^ { 2 } } \end{smallmatrix}$$

- c Show 40 ° on the triangle:

$$\begin{smallmatrix} \\ \end{smallmatrix}$$

- d 140 ° lies in the second quadrant.
- ∴ ° tan 140 is negative.

Basic acute angle 180 140 40 = ° -° = °

- ∴ ° = -° = --tan 140 tan 40 1 2 b b

<!-- image -->

<!-- image -->

<!-- image -->

## EXERCISE 5C

- 1 Express the following as trigonometric ratios of acute angles.
- a ° sin 190
- b ° cos 305
- c ° tan 125
- e cos 4 5 π
- f sin 9 8 π

$$\mathfrak { g } \ \cos \left ( - \frac { 7 \pi } { 1 0 } \ \right )$$

- 2 Without using a calculator , find the exact values of each of the following.
- a ° cos 120
- b ° tan 330
- c ° sin 225
- e sin 4 3 π
- f cos 7 3 π
- g -π     tan 6
- 3 Given that  sin 0 θ &lt; and  tan 0 θ &lt; , name the quadrant in which angle θ lies.
- 4 Given that  sin 2 5 θ = and that θ is obtuse, find the value of:
- a cos θ
- b θ tan
- 5 Given that θ = -cos 1 3 and that  180 270 θ ° ° ø ø , find the value of:
- a sin θ b θ tan
- 6 Given that θ = -tan 5 12 and that  180 360 θ ° ° ø ø , find the value of:
- a sin θ
- b θ cos
- 7 Given that ° = tan 25 , a express each of the following in terms of a .
- a ° tan 205
- b ° sin 25
- c ° cos 65
- d -° cos( 245 )
- h tan 11 9 π
- d -° tan( 300 )
- h cos 10 3 π
- d ° cos 245

- 8 Given that ° = cos 77 , b express each of the following in terms of b .
- a ° sin77
- b ° tan13
- c ° sin 257
- d ° cos347
- 9 Given that = sin 5 13 A and = -cos 4 5 B , where A and B are in the same quadrant , fi  nd the value of:
- a cos A
- b tan A
- c sin B
- d tan B

10

Given that tan

2

3

A

and cos

=

3

4

B

, where

A

and

B

are in the same quadrant, fi  nd the value of:

- a sin A
- b cos A
- c sin B
- d tan B
- 11 In the table,  0 360 θ ° ° ø ø and the missing function is from the list cos θ , tan , 1 sin θ θ and 1 tan θ . PS

Without using a calculator, copy and complete the table.

|         | θ = ° 120   | θ = ……   | θ = ° 210   |
|---------|-------------|----------|-------------|
| ……      | ……          | 1 -      | 1 3         |
| sin θ   | ……          | 1 2      | 1 2 -       |
| 1 cos θ | - 2         | - 2      | ……          |

## 5.4  Graphs of trigonometric functions

## EXPLORE   5.2

Consider taking a ride on a Ferris wheel with radius 50 metres that rotates at a constant speed.

You enter the ride from a platform that is level with the centre of the wheel and the wheel turns in an anticlockwise direction through one complete turn.

<!-- image -->

- 1 Sketch the following two graphs and discuss their properties.
- a The graph of your vertical displacement from the centre of the wheel plotted against the angle turned through .
- b The graph of your horizontal displacement from the centre of the wheel plotted against the angle turned through .
- 2 Discuss with your classmates what the two graphs would be like if you turned through two complete turns.

= -

128

## The graphs of = y x sin and = y x cos

Suppose that OP makes an angle of x with the positive horizontal axis and that P moves around the unit circle, through one complete revolution.

The coordinates of P will be  (cos , sin ). x x

<!-- image -->

The height of P above the horizontal axis changes from → → →- → 0 1 0 1 0.

The graph of sin x against x for x 0 360 &lt; &lt; ° ° is therefore:

<!-- image -->

The displacement of P from the vertical axis changes from → → - → → 1 0 1 0 1.

The graph of cos x against x for  0 360 x ° ° ø ø is therefore:

<!-- image -->

The graphs of = sin y x and = cos y x can be continued beyond  0 360 : x ° ° ø ø

In this image, we can see a diagram. There is a line in the image.

<!-- image -->

In this image we can see a graph.

<!-- image -->

The sine and cosine functions are called periodic functions because they repeat themselves over and over again.

The period of a periodic function is de fined as the length of one repetition or cycle.

The sine and cosine functions repeat every ° 360 .

We say they have a period of ° 360  (or 2 π radians).

The amplitude of a periodic function is defined as the distance between a maximum (or minimum) point and the principal axis.

The functions = sin y x and = cos y x both have amplitude 1.

The symmetry of the curve = sin y x shows these important relationships:

- /uni25CF -= -sin( ) sin x x
- /uni25CF ° -= sin(180 ) sin x x
- /uni25CF ° + = -sin(180 ) sin x x
- /uni25CF ° -= -sin(360 ) sin x x
- /uni25CF ° + = sin(360 ) sin x x

## EXPLORE 5.3

By considering the shape of the cosine curve, complete the following statements, giving your answers in terms of  cos . x

- 1 -= cos( ) x
- 2 ° -= cos(180 ) x
- 3 ° + = cos(180 ) x
- 4 ° -= cos(360 ) x
- 5 ° + = cos(360 ) x

## The graph of = tan y x

In this image, we can see a graph.

<!-- image -->

The tangent function behaves very differently to the sine and cosine functions.

The tangent function repeats its cycle every 180 ° so its period is 180 ° (or π radians).

The red dashed lines at = ± ° = ° = ° 90 , 270  and 450 x x x are called asymptotes . The branches of the graph get closer and closer to the asymptotes without ever reaching them.

The tangent function does not have an amplitude.

130

## EXPLORE 5.4

By considering the shape of the tangent curve, complete the following statements, giving your answers in terms of  tan . x

- 1 - = tan( ) x

- 2 ° - = tan(180 ) x

- 3 ° + = tan(180 ) x

- 4 ° - = tan(360 ) x

- 5 ° + = tan(360 ) x

## Transformations of trigonometric functions

These rules for the transformations of the graph f( ) y x = can be used to transform graphs of trigonometric functions. These transformations include = = f( ), f( ), y a x y ax = + y x a f( ) and ( ) = + y x a f and simple combinations of these.

## The graph of = sin y a x

<!-- image -->

The graph of = 2sin y x is a stretch of the graph of = sin . y x

It is a stretch, stretch factor 2, parallel to the y -axis.

The amplitude of = 2sin y x is 2 and the period is 360 ° .

## The graph of = y ax sin

<!-- image -->

The graph of = sin2 y x is a stretch of the graph of = sin . y x

It is a stretch, stretch factor 1 2 , parallel to the x -axis.

The amplitude of = sin2 y x is 1 and the period is 180°.

## REWIND

In Section 2.6, you learnt some rules for the transformation of the graph f( ). y x = Here we will look at how these rules can be used to transform graphs of trigonometric functions.

## The graph of = = + y a x sin

<!-- image -->

The graph of = + 1 sin y x is a translation of the graph of = sin . y x

$$\text{It is a translation of} \left ( \begin{array} { c } 0 \\ 1 \end{array} \right ).$$

The amplitude of = + 1 sin y x is 1 and the period is  360 ° .

## The graph of = = + y x a sin( )

<!-- image -->

-1

The graph of = + sin( 90) y x is a translation of the graph of = sin . y x

$$\text{It is a translation of } \begin{pmatrix} - 9 0 \\ 0 \end{pmatrix}.$$

The amplitude of = + y x sin( 90)  is 1 and the period is 360 ° .

## WORKED EXAMPLE 5.8

On the same grid, sketch the graphs of = sin y x and = -y x sin( 90)  for ° ° x 0 360 . &lt; &lt;

Answer

$$<_Python_>     Answer
    y = sin(x - 90)  is a translation of the graph  y = sin.x  by the vector {
        0
}$$

<!-- image -->

-1

132

To sketch the graph of a trigonometric function, such as = + + 2cos( 90) 1 y x for ° ° &lt; &lt; 0 360 x , we can build up the transformation in steps.

Step 1: Start with a sketch of = cos y x .

= ° Period 360

= Amplitude 1

Step 2: Sketch the graph of = + cos( 90). y x

$$\text{Translate $y=cos.x$ by the vector                                                                                                                                                                                                        
                                                                                                                                                                                                        0                                                                                                                                                                                                        "                                                                                                                                                                                                       '                                                                                                                                                                                                      .                                                                                                                                                                                                        -                                                                                                                                                                                                        +                                                                                                                                                                                                        :                                                                                                                                                                                                        ;                                                                                                                                                                                                        }                                                                                                                                                                                                       !                                                                                                                                                                                                        |                                                                                                                                                                                                       ,                                                                                                                                                                                                        1                                                                                                                                                                                                        <                                                                                                                                                                                                        >                                                                                                                                                                                                        (                                                                                                                                                                                                        )$$

= ° Period 360

= Amplitude 1

Step 3: Sketch the graph of = + 2cos( 90). y x

Stretch = + cos( 90) y x with stretch factor 2, parallel to the y -axis.

= ° Period 360

= Amplitude 2

Step 4: Sketch the graph of = + + 2cos( 90) 1. y x

$$\text{Translate } y = 2 \cos ( x + 90 ) \text{ by the vector } \left ( \begin{array} { c } 0 \\ 1 \end{array} \right ).$$

= ° Period 360

= Amplitude 2.

## WORKED EXAMPLE 5.9

= f( ) 3cos2 x x for  0 360 x &lt; &lt; ° ° .

- a Write down the period and amplitude of f.
- b Write down the coordinates of the maximum and minimum points on the curve f( ). y x =
- c Sketch the graph of f( ). y x =
- d Use your answer to part c to sketch the graph of = + 1 3cos2 y x .

<!-- image -->

y

-1

<!-- image -->

<!-- image -->

<!-- image -->

-2

## Answer

$$<_Python_> 

AISwers:
    a    Period =$$

- b y x cos = has its maximum and minimum points at:

(0 , 1), (180 , 1), (360 , 1), (540 , 1) ° ° -° ° -and 720 , 1 ) ( °

- Hence, = f( ) 3cos2 x x has its maximum and minimum points at:

(0 , 3), (90 , 3), (180 , 3), (270 , 3) ° ° -° ° -and  (360 , 3) °

<!-- image -->

- d = + 1 3cos2 y x is a translation of the graph = 3cos2 y x by the vector       0 1 .

<!-- image -->

## WORKED EXAMPLE 5.10

- a On the same grid, sketch the graphs of = sin2 y x and = + 1 3cos2 y x for  0 360 . x &lt; &lt; ° °
- b State the number of solutions of the equation = + sin2 1 3cos2 x x for  0 360 . x &lt; &lt; ° °

## Answer

<!-- image -->

- b The graphs of = sin2 y x and = + 1 3cos2 y x intersect each other at four points in the interval.

Hence, the number of solutions of the equation = + sin2 1 3cos2 x x is four.

133

134

## EXERCISE 5D

- 1 Write down the period of each of these functions.
- 2 Write down the amplitude of each of these functions.
- a = ° sin y x
- b = ° 5cos2 y x
- d = -° 2 3cos4 y x
- e = + ° 4sin(2 60) y x
- 3 Sketch the graph of each of these functions for  0 360 . x &lt; &lt; ° °
- a = 2cos y x
- b = sin 1 2 y x
- d = 3cos2 y x
- e = + 1 3cos y x
- g = -sin( 45) y x
- h = + 2cos( y x
- 60)
- 4 a Sketch the graph of each of these functions for x 0 2 &lt; &lt; π .

- a = ° cos y x

- b = ° sin2 y x

- d = + ° 1 2sin3 y x

- e = - ° tan( 30) y x

$$i \quad y = 2 \sin x$$

$$\text{ii} \ \ y = \cos \left ( \ x - \frac { \pi } { 2 } \right )$$

$$y = \cos \left ( x - \frac { \pi } { 2 } \right ) & & \text{iii} \ y = \sin \left ( 2 x + \frac { \pi } { 4 } \right )$$

- b Write down the coordinates of the turning points for your graph for part a iii .
- 5 a On the same diagram, sketch the graphs of = sin2 y x and = + 1 cos2 y x for  0 360 . x &lt; &lt; ° °
- b State the number of solutions of the equation = + sin2 1 cos2 x x for  0 360 . x &lt; &lt; ° °
- 6 a On the same diagram, sketch the graphs of = 2sin y x and = + 2 cos3 y x for  0 2 . &lt; &lt; x π
- b Hence, state the number of solutions, in the interval  0 2 , &lt; &lt; x π of the equation = + 2sin 2 cos3 . x x
- 7 a On the same diagram, sketch and label the graphs of = 3sin y x and = cos2 y x for the interval  0 2 . &lt; &lt; x π
- b State the number of solutions of the equation = 3sin cos2 x x in the interval  0 2 . &lt; &lt; x π

The image is a graph with a horizontal axis labeled as "x" and a vertical axis labeled as "y". The graph is a line graph with a minimum and maximum value of 8. The graph has a scale of range 0 to 6 on the x-axis, and the range of the y-axis is 0 to 6. The graph has a minimum value of 8 and a maximum value of 6. The graph is drawn with a black line.

<!-- image -->

Part of the graph = + sin y a bx c is shown above.

Find the value of a , the value of b and the value of c .

$$\mathfrak { c } _ { \quad y } & = 3 \tan \frac { 1 } { 2 } \, x ^ { \circ } \\ \mathfrak { f } _ { \quad y } & = 5 \cos ( 2 x + 4 5 ) ^ { \circ }$$

$$\mathfrak { c } _ { \quad y } & = 7 \sin \frac { 1 } { 2 } \, x ^ { \circ } \\ \mathfrak { f } _ { \quad y } & = 2 \sin ( 3 x + 1 0 ) ^ { \circ } + 5$$

- c = tan3 y x
- f = -2sin3 1 y x
- i = -tan( 90) y x

<!-- image -->

Part of the graph of = + cos y a b cx is shown above.

Write down the value of a , the value of b and the value of c .

- 10  a Sketch the graph of = 2sin y x for x . &lt; &lt; -π π

The straight line y kx = intersects this curve at the maximum point.

- b Find the value of k . Give your answer in terms of . π
- c State the coordinates of the other points where the line intersects the curve.

In this image, we can see a diagram. There is a line on the diagram. There is a point on the diagram. There is a line on the diagram. There is a text on the diagram.

<!-- image -->

Part of the graph of = + tan y a bx c is shown above.

The graph passes through the point π     4 , 8 . P

Find the value of a , the value of b and the value of c .

- 12 = + f( ) sin x a b x for x 0 2 &lt; &lt; π

$$\text{Given that } f ( 0 ) = 3 \text{ and that } f \left ( \frac { 7 \pi } { 6 } \right ) = 2, \text{find} \colon$$

- a the value of a and the value of b
- b the range of f.
- 13 = -f( ) cos x a b x for ° ° 0 360 , x &lt; &lt; where a and b are positive constants.

The maximum value of  f( ) x is 8 and the minimum value is 2 -.

- a Find the value of a and the value of b .
- b Sketch the graph of f( ). y x =
- 14 = + f( ) sin x a b cx for ° ° 0 360 , x &lt; &lt; where a and b are positive constants.

The maximum value of f( ) x is 9, the minimum value of f( ) x is 1 and the period is 120 ° . Find the value of a , the value of b and the value of c .

136

- 15 = + f( ) 5cos x A Bx for  0 120 x &lt; &lt; ° °

The maximum value of f( ) x is 7 and the period is 60 ° .

- a Write down the value of A and the value of B .
- b Write down the amplitude of f( ) x .
- c Sketch the graph of f( ) x .
- 16 The graph of = sin y x is reflected in the line x = π and then in the line 1. y = PS

Find the equation of the resulting function.

- 17 The graph of = cos y x is reflected in the line 2 x = π and then in the line 3. y = Find the equation of the resulting function. PS

## 5.5  Inverse trigonometric functions

The functions = = sin , cos y x y x and = tan y x for x R ∈ are many-one functions. If, however, we suitably restrict the domain of each of these functions, it is possible to make the function one-one and hence we can de fine each inverse function.

The graphs of the suitably restricted functions = = sin , cos y x y x and = tan y x and their inverse functions = = --sin , cos 1 1 y x y x and = -tan , 1 y x together with their domains and ranges are:

In this image, we can see a graph. On the graph, we can see some numbers.

<!-- image -->

In this image, we can see a diagram. There is a graph. We can see a line. There is a symbol.

<!-- image -->

<!-- image -->

## REWIND

In Section 2.5 you learnt about the inverse of a function. Here we will look at the particular case of the inverse of a trigonometric function.

## REWIND

In Chapter 2 you learnt about functions and that only one-one functions can have an inverse function. You also learnt that if f and f 1 -are inverse functions, then the graph of f 1 -is a reflection of the graph of f in the line y x = .

In this image, we can see a graph.

<!-- image -->

In this image, we can see a diagram. There is a graph. We can see a symbol and a number. We can see a text.

<!-- image -->

In this image, we can see a diagram. There is a graph. There is a text.

<!-- image -->

The image is a diagram with a graph. The graph is a curve that starts from the origin and extends to the right. The graph starts at the origin and extends to the right. The graph is a straight line. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right. The graph starts at the origin and extends to the right.

<!-- image -->

When solving the equation = sin 0.5 x for x 0 π &lt; &lt; , we ca n find one solution using the inverse functions:

sin 0.5 1 x = -

The angle that the calculator gives is the one that lies in the range of the function -sin 1 . (This is sometimes called the principal angle .)

Using a calculator gives = π x 6 .

The principal angle is the angle that lies in the range of the inverse trigonometric function.

There is a second angle, x 5 = π , that satisfies = sin 0.5 x with x 0 . &lt; &lt; π

6 We can find this second angle either by using skills learnt earlier in this chapter or by using the symmetry of the curve = sin y x .

138

## WORKED EXAMPLE 5.11

<!-- image -->

The output of the ---sin , cos and tan 1 1 1 functions can be given in degrees if that is needed. Without using a calculator, write down, in degrees, the value of:

$$\left | \quad a \ \sin ^ { - 1 } 0 \quad & b \ \cos ^ { - 1 } \left ( \frac { \sqrt { 3 } } { 2 } \ \right )$$

$$b \ \cos ^ { - 1 } \left ( \frac { \sqrt { 3 } } { 2 } \right ) \quad \text{c} \ \tan ^ { - 1 } ( - 1 )$$

## Answer

- a -sin 1 0 means the angle whose sine is 0, where 90 angle 90 &lt; &lt; -° ° .

Hence, = ° -sin 0 0 1 .

$$\begin{array} {$$

$$<_Scheme_>$$

- c --tan ( 1) 1 means the angle whose tangent is 1 -, where 90 angle 90 &lt; &lt; -° ° .

Hence,  tan ( 1) 45 1 -= -° -.

## WORKED EXAMPLE 5.12

The function =     -f( ) 3sin 2 1 x x is de fined for the domain x . &lt; &lt; -π π

- a Sketch the graph of f( ) y x = and explain why f has an inverse function.
- b Find the range of f.
- c Find f ( ) 1 x -and state its domain.

## Answer

<!-- image -->

f has an inverse function because f is a one-one function with this domain.

- b Range is x 4 f( ) 2. &lt; &lt; -

$$c _ f ( x ) = 3sin ( \frac { x } { 2 } ) - 1$$

Step 1: Write the function as y

Step 2: Interchange the x and y

Step 3: Rearrange to make y

$$\begin{array} { c c c c c c c } \ n { \text{tion as$$

The inverse function is = +     --f ( ) 2sin 1 3 1 1 x x for x 4 2 &lt; &lt; -.

## EXERCISE 5E

- 1 Without using a calculator, write down, in degrees, the value of:
- b -sin 1 1
- a -cos 1 1 2
- d sin 1 1
- ( ) --e ( ) --tan 3 1
- 2 Without using a calculator, write down, in terms of , π the value of:
- a -sin 1 0
- b -tan 1 1

$$\mathfrak { c } \ \cos ^ { - 1 } \left ( \frac { 1$$

$$\mathfrak { d } \ \tan ^ { - 1 } \left ( - \frac { 1 } { \sqrt { 3 } } \right ) & & \mathfrak { e } \ \cos ^ { - 1 } \left ( - \frac { 1 } { 2 } \right ) & & \mathfrak { f } \ \sin ^ { - 1 } \left ( - \frac { \sqrt { 3 } } { 2 } \right )$$

- 3 Given that cos 3 5 1 θ =       -, find the exact value of: a sin 2 θ b θ tan 2
- 4 The function = -f( ) 3sin 4 x x is defined for the domain -π π 2 2 . x &lt; &lt;
- a Find the range of f.
- b Find f ( ) x .
- 1 -
- 5 The function = -f( ) 4 2cos x x is defined for the domain  0 . &lt; &lt; x π
- a Find the range of f and sketch the graph of f( ). y x =
- b Explain why f has an inverse and find the equation of this inverse.
- c Sketch the graph of f ( ) 1 y x = -on your graph for part a .
- 6 The function = -f( ) 5 2sin x x is defined for the domain 2 . &lt; &lt; x p π
- a Find the largest value of p for which f has an inverse.
- b For this value of p , find f ( ) 1 x -and state the domain of f . 1 -
- 7 The function =     -f( ) 4cos 2 5 x x is defined for the domain  0 2 . &lt; &lt; x π
- a Find the range of f.
- b Find f ( ) 1 x -and state its range.

$$y = 3 \sin \left ( \frac { x } { 2 } \right ) - 1$$

- c -tan 3 1

$$f \ \cos ^ { - 1 } \left ( - \frac { 1 } { \sqrt { 2 } } \ \right )$$

139

140

## 5.6  Trigonometric equations

Consider solving the equation = sin 0.5 x for -° ° &lt; &lt; 360 360 x .

One solution is given by = = π -sin (0.5) 6 1 x (or ° 30 ).

There are, however, many more values of x for which  sin 0.5. x =

The graph of = sin y x for 360 360 x &lt; &lt; -° ° is:

In this image, we can see a graph.

<!-- image -->

The graph shows there are four values of , x between 360 -° and 360 , ° for which = sin 0.5 x .

We can use the calculator value of 30 x = ° , together with the symmetry of the curve t o find the remaining answers.

Hence, the solution of = -° ° = -° -° ° ° sin 0.5 for 360 360 is: 330 , 210 , 30 or 150 x x x &lt; &lt;

## WORKED EXAMPLE 5.13

<!-- image -->

Solve  cos 0.7 x = -for  0 360 . x &lt; &lt; ° °

## Answer

= -cos 0.7 x

= ° One solution is 134.4 x

Use a calculator to find  cos ( 0.7) 1 --, correct to 1 decimal place.

In this image, we can see a graph.

<!-- image -->

The sketch graph shows there are two values of x , between -  ° 0  and 360 , ° for which = -cos 0.7 x .

Using the symmetry of the curve, the second value is (360 134.4 ) 225.6 ° -° = ° .

Hence, the solution of = -° ° cos 0.7 for 0 360 is: x x &lt; &lt;

= ° ° 134.4 or 225.6 x

(correct to 1 decimal place)

## WORKED EXAMPLE 5.14

<!-- image -->

Solve  tan 2 2.1 A = -for ° ° &lt; &lt; 0 180 . A

## Answer

= -tan2 2.1 A

= -tan 2.1 x

= -° Asolution is 64.54 . x

In this image, we can see a diagram. There are two lines, one is a straight line and the other is an arc.

<!-- image -->

Using the symmetry of the curve:

= - ° 64.54 x

= Using 2 : A x

= - ° 2 64.54 A

= - ° 32.3 A

= - ° + ° ( 64.54 180 ) x

= ° 115.46

= ° 2 115.46 A

= ° 57.7 A

= ° + ° (115.46 180 ) x

= ° 295.46

= ° 2 295.46 A

= ° 147.7 A

Hence, the solution of A tan 2 2.1 = -for ° ° &lt; &lt; 0 180 A is:

A 57.7  or 147.7 = ° ° (correct to 1 decimal place)

## WORKED EXAMPLE 5.15

<!-- image -->

$$\begin{array} { c } \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{ $\text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$2$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \text{$1$} \end{array}$$

Let  2 A x = .

Use a calculator t o find --tan ( 2.1) 1 .

141

142

<!-- image -->

Using the symmetry of the curve:

= 0.6435 x

$$x = \pi - 0.6435
  = 2.498$$

$$\begin{array} { c c c c c c c c c c } & & & & & & = 2. 498 \\ & \text{Using } 2 A + \frac { \pi } { 6 } = x \colon \\ & & 2 A + \frac { \pi } { 6 } = 0. 6 4 3 5 & & & & 2 A + \frac { \pi } { 6 } = 2. 4 9 8 \\ & & A = \frac { 1 } { 2 } \left ( 0. 6 4 3 5 - \frac { \pi } { 6 } \right ) & & & A = \frac { 1 } { 2 } \left ( 2. 4 9 8 - \frac { \pi } { 6 } \right ) \\ & & A = 0. 0 6 0 0 & & & & A = 0. 9 8 7 \\ & & & & & / & \quad \end{array}$$

$$\Big |                                                                                                                                                                                                        
      Hence, the solution of sin { 2.4 + \frac { \pi } } = 0.6   for   0 \leq 4 \leq \pi  is:$$

= 0.0600 or 0.987 radians (correct to 3significant figures) A

Consider a right-angled triangle.

Two very important rules can be found using this triangle.

## Rule 1

$$\underline { y }$$

$$\tan \theta & = \frac { y } { x } \\ & = \frac { \left ( \frac { y } { r } \right ) } { \left ( \frac { x } { r } \right ) }$$

<!-- image -->

r .

$$<_VisualBasic_>$$

## KEY POINT 5.2

θ θ θ = tan sin cos for all θ with θ ≠ cos 0.

## Rule 2

$$x ^ { 2 } + y ^ { 2 } & = r ^ { 2 } \\ \left ( \frac { x } { r } \right ) ^ { 2 } + \left ( \frac { y } { r } \right ) ^ { 2 } & = 1$$

$$<_VisualBasic_> Divide both sides by r*.

Use cos@ = -a and sin@ = -a.
            r                r$$

## KEY POINT 5.3

θ θ + = cos sin 1 2 2 for all θ .

If we use the unit circle de finition of the trigonometric functions, we discover that these two important rules are true for all valid values of θ . We can use them to help solve more complicated trigonometric equations.

## WORKED EXAMPLE 5.16

Solve -= 3cos sin cos 0 2 x x x for  0 360 . x &lt; &lt; ° °

Answer

-= 3cos sin cos 0 2 x x x

-= cos (3cos sin ) 0 x x x

= -= cos 0 or 3cos sin 0 x x x x 90 , 270 = ° °

=

sin

3cos

x

= tan 3 x

x

=

+

71.6

or

180

71.6

= ° ° 71.6 or 251.6 x

<!-- image -->

2

-= ° ° = ° ° ° ° &lt; &lt; The solution of 3cos sin cos 0 for 0 360 is: 71.6 , 90 , 251.6  or 270 x x x x x

## WORKED EXAMPLE 5.17

Solve + -= 2sin 3cos 3 0 2 x x for  0 2 . &lt; &lt; x π

Answer

+ -= -+ -= -+ = --= 2 sin 3cos 3 0 2(1 cos ) 3cos 3 0 2cos 3cos 1 0 (2 cos 1)(cos 1) 0 2 2 2 x x x x x x x x Replace  sin 2 x with -1 cos 2 x . Expand brackets and collect terms. Factorise.

x

Factorise.

143

144

cos

x

x

1

2

π

3

=

=

or or

π -

2

π

3

cos

x

=

=

π

π

3

1

0 or 2

x

x

x

π

5

π

3

=

or

3

+ -= π x x x The solution of 2sin 3cos 1 0 for 0 2 is: 2 &lt; &lt;

<!-- image -->

$$x = 0, \frac { \pi } { 3 } \, \text{or } 2 \pi$$

## EXERCISE 5F

- 1 Solve each of these equations for  0 360 . x &lt; &lt; ° °
- a = tan 1.5 x
- b = sin 0.4 x
- e = -cos 0.6 x
- f = -tan 2 x
- 2 Solve each of the these equations for  0 2 . &lt; &lt; x π
- a = sin 0.3 x
- b = cos 0.5 x
- e = -tan 3 x
- f = -cos 0.5 x
- 3 Solve each of these equations for  0 180 . x &lt; &lt; ° °
- a = cos2 0.6 x
- b = sin3 0.8 x
- e = 3cos2 2 x
- f = -5sin2 4 x
- 4 Solve each of these equations for the given domains.
- a -° = ° ° &lt; &lt; sin( 60 ) 0.5 for 0 360 x x
- c + ° = ° ° &lt; &lt; cos(2 45 ) 0.8  for 0 180 x x
- e     + = ° ° &lt; &lt; 2tan 2 3 0 for 0 540 x x
- b + π     = -&lt; &lt; π cos 6 0.5 for 0 2 x x
- d -= &lt; &lt; π 3sin(2 4) 2 for 0 x x
- f + π     = &lt; &lt; π 2 sin 3 4 1 for 0 4 x x

- c = cos 0.7 x

- d = - sin 0.3 x

- g - = 2cos 1 0 x

- h + = 5sin 3 0 x

- c = tan 3 x

- d = - sin 0.7 x

- g = 4sin 3 x

- h + = 5tan 7 0 x

- c = tan2 4 x

- d = - sin2 0.5 x

- g + = 4 2tan2 0 x

- h - = 1 5sin2 0 x

- 5 Solve each of these equations for  0 360 . x &lt; &lt; ° °
- a = 2sin cos x x
- c + = 4sin 7cos 0 x x
- 6 Solve + -+ = π &lt; &lt; 4sin(2 0.3) 5cos(2 0.3) 0  for  0 . x x x
- 7 Solve each of these equations for  0 360 . x &lt; &lt; ° °
- a -= sin cos( 60) 0 x x
- c = tan 5tan 2 x x
- e = 2sin cos sin x x x
- 8 Solve each of these equations for  0 360 x &lt; &lt; ° ° .
- a = 4cos 1 2 x
- 9 Solve each of these equations for  0 360 . x &lt; &lt; ° °
- a + -= 2sin sin 1 0 2 x x
- c --= 3cos 2cos 1 0 2 x x
- e -= 3cos 3 sin 2 x x
- g ---= 2cos sin 2sin 1 0 2 2 x x x
- 10 Solve each of these equations for π x &lt; &lt; 0 2 .
- a = 4tan 3cos x x
- 11 Solve + + = sin 3sin cos 2cos 0 2 2 x x x x for π x &lt; &lt; 0 2 .

## 5.7  Trigonometric identities

2 x x x + = is called an identity because it is true for all values of x .

When writing an identity, we often replace the = symbol with a ≡ symbol to emphasise that it is an identity.

Two commonly used trigonometric identities are:

```
+ ≡ sin cos 1 2 2 x x and ≡ tan sin cos x x x
```

In this section you will learn how to use these two identities to simplify expressions and to prove other more complicated identities that involve sin , cos x x and tan . x

When proving an identity, it is usual to start with the more complicated side of the identity and prove that it simpli fies to the less complicated side.

- b -= 2sin 3cos 0 x x
- d -= 3cos2 4sin2 0 x x
- b -= 5sin 3sin 0 2 x x
- d + = sin 2sin cos 0 2 x x x
- f = sin tan 4sin x x x
- b = 4tan 9 2 x
- b + -= tan 2tan 3 0 2 x x
- d --= 2sin cos 1 0 2 x x
- f + = cos 5 6sin 2 x x
- h + = 1 tan cos 2cos 2 x x x
- b + = 2cos 5sin 4 2 x x

146

## WORKED EXAMPLE 5.18

Express -4cos 3sin 2 2 x x in terms of  cos . x

Answer

$$\begin{array} { c c c } & 4 \cos ^ { 2 } x - 3 \sin ^ { 2 } x \equiv 4 \cos ^ { 2 } x - 3 ( 1 - \cos ^ { 2 } x ) & \end{array} \end{array}$$

≡ -+ 4cos 3 3cos 2 2 x x

≡ -7cos 3 2 x

## WORKED EXAMPLE 5.19

Replace  sin 2 x with -1 cos 2 x .

## TIP

Prove the identity + + + ≡ 1 sin cos cos 1 sin 2 cos x x x x x .

Answer

LHS

1

sin

cos

cos

1 sin + x

(1 sin ) cos 2 2 + + x x

cos (1 sin ) + x x cos (1 sin ) + x x

≡

+

+

≡

x

x

x

Add the two fractions.

Expand the brackets in the numerator.

1 2sin sin cos 2 2 ≡ + + + x x x

cos (1 sin ) + x x

2 2sin + x

cos (1 sin ) + x x

$$<_Ruby_> = \frac { 2 ( 1 + sin x ) } { \cos x ( 1 + sin x ) }$$

2

cos x

RHS ≡

≡

≡

Use + ≡ sin cos 1 2 2 x x .

Factorise the numerator.

Divide numerator and denominator by + 1 sin x .

## WORKED EXAMPLE 5.20

$$\Big | \, \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{  } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{\ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text
 \, \Big | \, \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{  } \text{\ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{\ } \text{\ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text
 \, \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \text{ } \end{}$$

Answer

$$<_Awk_> IS = ( tan.x + -1 ) ^ { 2 }$$

$$<_Python_>     RHS = (tan.x + --)$$

(1

+

sin

)

2

LHS means left-hand side and RHS means right-hand side.

Use = tan sin cos x x x .

Add the two fractions.

≡

≡

≡

+

sin cos

x

2

+

-

(1

(1

1

(1

+

x

sin

x

sin

)

2

2

(1

x

+

sin sin

≡

+

1

sin

1

-

sin

≡ LHS

## EXPLORE 5.5

In this image, we can see a diagram.

<!-- image -->

## EXERCISE 5G

- 1 Express -+ 2sin 7cos 4 2 2 x x in terms of  sin . x
- 2 Prove each of these identities.
- a ≡ cos tan sin x x x
- c ≡ + cos 1 sin 2 x x
- e + cos sin sin cos x x x x
- -1 sin x -+ ≡ cos sin 2 2 x x

x

)(1

x

x

)

2

x

)

-

2

sin

x

)

Replace  cos 2 x with -1 sin 2 x in the denominator.

Use -= + -1 sin (1 sin )(1 sin ) 2 x x x .

Divide numerator and denominator by + 1 sin x .

- b -≡ x x x x 1 cos sin cos tan 2
- d + -≡ + 1 sin sin cos cos tan 2 x x x x x
- f + ≡ cos sin cos cos 4 2 2 2 x x x x

147

148

- 3 Prove each of these identities.
- a + ≡ + (sin cos ) 1 2sin cos 2 x x x x
- c -+ ≡ -2 (sin cos ) (sin cos ) 2 2 x x x x
- 4 Prove each of these identities.
- a -≡ -cos sin 2cos 1 2 2 2 x x x
- c -≡ tan sin tan sin 2 2 2 2 x x x x
- 5 Prove each of these identities.
- a --≡ + cos sin cos sin cos sin 2 2 x x x x x x
- c -≡ -x x x x cos sin cos 1 tan 4 4 2 2
- e -+ ≡ -+ sin cos sin cos tan 1 tan 1 x x x x x x
- g + + ≡ + tan 1 sin tan cos sin cos x x x x x x
- 6 Prove each of these identities.
- a -+ ≡ 1 cos cos 1 sin tan x x x x
- c -≡ 1 cos cos sin tan x x x x
- e -+ + ≡ sin 1 sin sin 1 sin 2tan cos x x x x x x
- tan sin cos x x x d + + + ≡ sin 1 cos 1 cos sin 2 sin x x x x x f + ---+ ≡ 1 cos 1 cos 1 cos 1 cos 4 sin tan x x x x x x
- 7 Show that + + -+ (1 cos ) (1 cos ) 2sin 2 2 2 x x x has a constant value for all x and state this value.
- 8 a Express + 7sin 4cos 2 2 x x in the form + sin . 2 a b x
- b State the range of the function = + f( ) 7sin 4cos 2 2 x x x , for the domain π 0 2 . x &lt; &lt;
- 9 a Express  4 sin cos 2 θ θ -in the form  (sin ) . 2 a b θ + +
- b Hence, state the maximum and minimum values of θ θ -4 sin cos 2 , for the domain θ π 0 2 . &lt; &lt;
- 10  a Given that θ θ = -1 sin 2cos a , show that 1 2(1 sin ) cos a θ θ = + . PS P
- b Hence , find sin θ and  cos θ in terms of a .
- b + -+ ≡ 2(1 cos ) (1 cos ) sin 2 2 x x x
- d --≡ + (cos 2) 3sin cos sin 2 2 2 4 2 x x x x
- b -≡ -cos sin 1 2 sin 2 2 2 x x x
- d + ≡ + cos sin sin cos 4 2 4 2 x x x x
- b -≡ -x x x sin cos 2 sin 1 4 4 2
- d ≡ + cos tan (1 sin ) 1 1 sin x x x x
- f -    ≡ -+ 1 sin 1 tan 1 cos 1 cos 2 x x x x

$$& \frac { \cos x } { \tan x ( 1 - \sin x ) } \equiv 1 \\ & \left ( \frac { 1 } { \sin x } - \frac { 1 } { \tan x } \right ) ^ { 2 } \equiv \\ & \sim 2 \sim \sim 1 \quad \sim 2 \sim \dots$$

- h --≡ x x x x x sin (1 cos ) cos (1 sin ) tan 2 2 2 2 4
- b + ≡ tan 1 1 x

## 5.8  Further trigonometric equations

This section uses trigonometric identities to help solve some more complex trigonometric equations.

## WORKED EXAMPLE 5.21

```
a Prove the identity 1 tan 1 tan 2 cos 1 2 2 2 θ θ θ -+ ≡ -. b Hence, solve the equation θ θ θ -+ = -1 tan 1 tan 5 cos 3 2 2 for  0 360 . < < θ ° ° Answer a LHS 1 tan 1 tan 1 sin cos 1 sin cos cos sin cos sin cos sin cos (1 cos ) 2 cos 1 RHS 2 2 2 2 2 2 2 2 2 2 2 2 2 θ θ θ θ θ θ θ θ θ θ θ θ θ θ θ ≡ -+ ≡ -      +       ≡ -+ ≡ -≡ --≡ -≡ Use θ θ θ = tan sin cos . Multiply numerator and denominator by θ cos 2 . Use θ θ + = sin cos 1 2 2 . Replace  sin 2 θ with θ -1 cos 2 . Simplify. b θ θ θ θ θ θ θ θ θ θ θ θ θ θ -+ = --= --+ = --= = = =     = ° = ° -° -1 tan 1 tan 5 cos 3 2 cos 1 5 cos 3 2 cos 5 cos 2 0 (2 cos 1)(cos 2) 0 cos 1 2 or cos 2 cos 1 2 60 or 360 60 2 2 2 2 1 Solution is 60  or 300 . θ θ = ° = ° Use the result from part a . Rearrange. Factorise. θ = cos 2  has no solutions.
```

149

150

## EXERCISE 5H

- 1 a Show that the equation θ θ θ + = cos sin 5cos can be written in the form  tan . k θ =
- b Hence, solve the equation θ θ θ + = cos sin 5cos for  0 360 . &lt; &lt; θ ° °
- 2 a Show that the equation θ θ θ θ + = 3sin 5sin cos 2cos 2 2 can be written in the form θ θ + -= 3tan 5tan 2 0. 2
- b Hence, solve the equation θ θ θ θ + = 3sin 5sin cos 2cos 2 2 for  0 180 . &lt; &lt; θ ° °
- 3 a Show that the equation θ θ θ + -= 8sin 2cos cos 6 2 2 can be written in the form θ θ + -= 6cos cos 2 0. 2
- b Hence, solve the equation θ θ θ + -= 8sin 2cos cos 6 2 2 for  0 360 . &lt; &lt; θ ° °
- 4 a Show that the equation θ θ + = 4sin 14 19cos 4 2 can be written in the form + -= 4 19 5 0, 2 x x where sin . 2 x θ =
- b Hence, solve the equation θ θ + = 4sin 14 19cos 4 2 for  0 360 . &lt; &lt; θ ° °
- 5 a Show that the equation  sin tan 3 θ θ = can be written in the form  cos 3 cos 1 0. 2 θ θ + -=
- b Hence, solve the equation  sin tan 3 θ θ = for  0 360 . &lt; &lt; θ ° °
- 6 a Show that the equation θ θ θ θ -= + 5(2sin cos ) 4(sin 2cos )  can be written in the form  tan 13 6 . θ =
- b Hence, solve the equation θ θ θ θ -= + 5(2sin cos ) 4(sin 2cos )  for  0 360 . &lt; &lt; θ ° °
- 7 a Prove the identity sin 1 cos 1 cos sin 2 sin θ θ θ θ θ + + + ≡ .
- b Hence, solve the equation sin 1 cos 1 cos sin 1 3 sin θ θ θ θ θ + + + = + for  0 360 . &lt; &lt; θ ° °
- 8 a Prove the identity cos tan (1 sin ) 1 sin 1 θ θ θ θ + ≡ -.
- b Hence, solve the equation cos tan (1 sin ) 1 θ θ θ + = for  0 360 . &lt; &lt; θ ° °
- 9 a Prove the identity 1 1 sin 1 1 sin 2 cos 2 θ θ θ + + -≡ .
- b Hence, solve the equation  cos 1 1 sin 1 1 sin 5 θ θ θ + + -      = for  0 360 . &lt; &lt; θ ° °
- 10  a Prove the identity 1 sin 1 tan 1 cos 1 cos 2 θ θ θ θ +       ≡ + -.
- b Hence, solve the equation 1 sin 1 tan 2 2 θ θ +       = for   0 360 . &lt; &lt; θ ° °
- 11  a Prove the identity  cos sin 2 cos 1 4 4 2 θ θ θ -≡ -.
- b Hence, solve the equation  cos sin 1 2 4 4 θ θ -= for  0 360 . &lt; &lt; θ ° °

## Checklist of learning and understanding

## Exact values of trigonometric functions

|                  | sin θ   | cos θ   | tan θ   |
|------------------|---------|---------|---------|
| θ = = ° = π 30 6 | 1 2     | 3 2     | 1 3     |
| θ = = π ° 45 4   | 1 2     | 1 2     | 1       |
| θ = = π ° 60 3   | 3 2     | 1 2     | 3       |

## Positive and negative angles

- /uni25CF Angles measured anticlockwise from the positive x -direction are positive.
- /uni25CF Angles measured clockwise from the positive x -direction are negative.

## Diagram showing where sin, cos and tan are positive

<!-- image -->

- /uni25CF Useful mnemonic: ' A ll S tudents T rust C ambridge'.

## Graphs of trigonometric functions

The image is a graph with two axes labeled as x and y. The x-axis is labeled as "1" and the y-axis is labeled as "1". The graph is a line graph with a positive slope. The line starts from the origin and goes up and down, with a positive slope.

<!-- image -->

152

In this image we can see a diagram.

<!-- image -->

## END-OF-CHAPTER REVIEW EXERCISE 5

1

<!-- image -->

The diagram shows part of the graph of = + sin y a b x .

State the values of the constants a and b .

[2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q1 June 2014

- 2 Find the value of x satisfying the equation  sin ( 1) tan (3). 1 1 x -= --
- [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q2 November 2014

- 3 Given that θ is an acute angle measured in radians and that  cos k θ = , find, in terms of k , an expression for:
- a sin θ
- b tan θ
- c θ π cos( )

[1]

[1]

[1]

- 4 Solve the equation x x cos (8 14 16) 1 4 2 + -= π -
- . [4]
- 5 Solve the equation = sin2 5cos2 x x , for  0 180 . x &lt; &lt; ° ° [4]
- 180 . [4]
- 6 Solve the equation θ θ θ + + = 13sin 2 cos cos 2 2 for  0 &lt; &lt; θ ° °

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q3 November 2014

- 7 Solve the equation = -2cos 5sin 1 2 x x for  0 360 . x &lt; &lt; ° °

[4]

- 8 i Sketch, on a single diagram, the graphs of θ = cos2 y and 1 2 y = for θ π 0 2 . &lt; &lt; [3]
- ii Write down the number of roots of the equation θ -= 2cos2 1 0  in the interval θ π 0 2 . &lt; &lt; [1]
- iii Deduce the number of roots of the equation θ -= 2cos2 1 0 in the interval θ π 10π 20 . &lt; &lt; [1]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q3 November 2011

- 9 i Show that the equation θ θ = 2tan sin 1 2 2 can be written in the form θ θ + -= 2sin sin 1 0. 4 2 [2]
- ii 360 . [4]
- Hence solve the equation  2tan sin 1 2 2 θ θ = for  0 &lt; &lt; θ ° °

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 June 2011

153

154

- 360 . [4]
- 10 i Solve the equation + -= 4sin 8cos 7 0 2 x x for  0 x &lt; &lt; ° °
- ii Henc e find the solution of the equation θ θ     +     -= 4sin 1 2 8cos 1 2 7 0 2 for  0 360 . &lt; &lt; θ ° ° [2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q4 November 2013

- 11 i Prove the identity ≡ + sin tan 1 1 . x x
- -1 cos cos x x [3]

ii

Hence solve the equation sin

tan

x

x

&lt;

&lt;

°

°

1

-

+

=

cos

2

0,

x

for  0

360 .

x

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q4 November 2010

- . [3]
- 12 a Solve the equation -+ = 2 sin 1 2sin 3 4 x x for π 0 2 x &lt; &lt;
- b Solve the equation ( ) -= -sin 2cos 2 2sin 3cos x x x x for -π π . x &lt; &lt; [4]
- 13 A function f  is defined by → -    f : 3 2tan 1 2 x x for π 0 . x &lt; &lt;
- i State the range of f.
- ii State the exact value of π     f 2 3

[1]

- . [1]
- iii Sketch the graph of y x f( ) = .

[2]

- iv Obtain an expression, in terms of x , for  f ( ). 1 x -

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 November 2010

- 14 i Solve the equation θ θ = 2cos 3sin , 2 for  0 360 . &lt; &lt; θ ° °

[4]

- θ θ = 2 is a positive integer,

[3]

- ii The smallest positive solution of the equation 2cos ( ) 3sin( ), n n where n is 10 ° . State the value of n and hence find the largest solution of this equation in the interval θ ° ° 0 360 . &lt; &lt;

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 November 2012

- 15 i Show that θ θ θ θ θ θ θ θ + + -≡ -sin sin cos cos sin cos 1 sin cos . 2 2 [3]
- ii Hence solve the equation sin sin cos cos sin cos 3, θ θ θ θ θ θ + + -= for  0 360 . &lt; &lt; θ ° ° [4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 June 2013

- 16 i Show that the equation θ θ + = 4cos tan 15 0  can be expressed as θ θ --= 4sin 15sin 4 0. 2 [3]

ii

Hence solve the equation

4 cos

θ

tan

15

0

θ

+

=

for  0

360 .

&lt;

&lt;

θ

°

°

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q4 November 2015

- 17 The function → +     f : 5 3cos 1 2 x x is defined for π 0 2 x &lt; &lt; .
- i Solve the equation f( ) 7, x giving your answer correct to  2  decimal places. [3]
- =
- ii Sketch the graph of y x f( ).
- = [2]
- iii Explain why f has an inverse.

[1]

- iv Obtain an expression for  f ( 1 x -
- ). [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 June 2015

In this image we can see a flower. The background is blurred.

<!-- image -->

## Chapter   6 Series

## In this chapter you will learn how to:

- ■ use the expansion of  ( ) a b n + , where n is a positive integer
- ■ use the formulae for the th n term and for the sum of the fi  rst n terms to solve problems involving arithmetic or geometric progressions
- ■ recognise arithmetic and geometric progressions
- ■ use the condition for the convergence of a geometric progression, and the formula for the sum to infi  nity of a convergent geometric progression.

In this image we can see the leaves.

<!-- image -->

156

## PREREQUISITE KNOWLEDGE

| Where it comes from        | What you should be able to do            | Check your skills                                                                           |
|----------------------------|------------------------------------------|---------------------------------------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Expand brackets.                         | 1 Expand: a x + (2 3) 2 b x x x - + - (1 3 )(1 2 3 ) 2                                      |
| IGCSE / OLevel Mathematics | Simplify indices.                        | 2 Simplify: a x (5 ) 2 3 b x - ( 2 ) 3 5                                                    |
| IGCSE / OLevel Mathematics | Find the n th term of a linear sequence. | 3 Find the n th term of these linear sequences. a … 5, 7, 9, 11, 13, b - - … 8, 5, 2, 1, 4, |

## Why study series?

At IGCSE / O Level you learnt how to expand expressions such as  (1 ) 2 x + . In this chapter you will learn how to expand expressions of the form  (1 ) x n + , where n can be any positive integer. Expansions of this type are called binomial expansions.

## FAST FORWARD

This chapter also covers arithmetic and geometric progressions. Both the mathematical and the real world are full of number sequences that have particular special properties. You will learn how t o find the sum of the numbers in these progressions. Some fractal patterns can generate these types of sequences.

## 6.1  Binomial exapansion of + ( ) a b n

Binomial means 'two terms'.

The word is used in algebra for expressions such as 3 x + and -5 2 x y .

You should already know that  ( ) 2 2 2 2 a b a ab b + = + + .

The expansion of + ( ) 2 a b can be used to expand + ( ) 3 a b :

+ = + + + ( ) ( )( 2 ) 3 2 2 a b a b a ab b

= + + + + + 2 2 3 2 2 2 2 3 a a b ab a b ab b

= + + + 3 3 3 2 2 3 a a b ab b

Similarly, it can be shown that + = + + + + ( ) 4 6 4 4 4 3 2 2 3 4 a b a a b a b ab b .

Writing the expansions of + ( ) a b n in full in order:

+ = ( ) 0 a b

1

( ) 1 + = a b 1 1 + a b

+ = ( ) 2 2 a b 1 2 1 2 2 + + a ab b

+ = ( ) 3 a b

3

( ) 4 4 + = a b 1 4 6 4 1 4 3 2 2 3 4 + + + + a a b a b ab b

1

1 3 3 1 3 2 2 3 + + + a a b ab b

In the Pure Mathematics 2 and 3 Coursebook, Chapter 7, you will learn how to expand these expressions for any real value of n .

## FAST FORWARD

Properties of binomial expansions are also used in probability theory, which you will learn about if you go on to study the Probability and Statistics 1 Coursebook, Chapter 7.

## WEB LINK

Try the Sequences and Counting and binomials resources on the Underground Mathematics website.

If you look at the expansion of + ( ) 4 a b , you should notice that the powers of a and b form a pattern.

- /uni25CF The first term is 4 a and then the power of a decreases by 1 while the power of b increases by 1 in each successive term.
- /uni25CF All of the terms have a total index of 4 ( 4 a , 3 a b , 2 2 a b , 3 ab and 4 b ).

There is a similar pattern in the other expansions.

The coefficients also form a pattern that is known as Pascal's triangle .

<!-- image -->

The next row is then:

= n 5: 1 5 10 10 5 1

This row can then be used to write down the expansion of + ( ) 5 a b :

+ = + + + + + ( ) 1 5 10 10 5 1 5 5 4 3 2 2 3 4 5 a b a a b a b a b ab b

## EXPLORE 6.1

<!-- image -->

1

There are many number patterns to be found in Pascal's triangle.

For example, the numbers 1, 4, 10 and 20 have been highlighted.

<!-- image -->

<!-- image -->

These numbers are called tetrahedral numbers.

- 1 What do you notice if you find the total of each row in Pascal's triangle? Can you explain your findings?
- 2 Can you find the Fibonacci sequence … (1, 1 , 2, 3, 5, 8, 13, ) in Pascal's triangle? You may want to add terms together.
- 3 Pascal's triangle has many other number patterns.

Which number patterns can you find?

## TIP

Each row always starts and finishes with a 1.

Each number is the sum of the two numbers in the row above it.

## DID YOU KNOW?

Pascal's triangle is named after the French mathematician Blaise Pascal (1623-1662).

157

158

## WORKED EXAMPLE 6.1

```
Use Pascal's triangle t o find the expansion of: a (3 2) 3 x + b (5 2 ) 4 x -Answer a + (3 2) 3 x The index is 3 so use the row for = 3 n in Pascal's triangle  (1, 3, 3, 1). + = + + + = + + + (3 2) 1(3 ) 3(3 ) (2) 3(3 )(2) 1(2) 27 54 36 8 3 3 2 2 3 3 2 x x x x x x x b (5 2 ) 4 -x The index is 4 so use the row for = 4 n in Pascal's triangle  (1, 4, 6, 4, 1). -= + -+ -+ -+ -= -+ -+ (5 2 ) 1(5) 4(5) ( 2 ) 6(5) ( 2 ) 4(5)( 2 ) 1( 2 ) 625 1000 600 160 16 4 4 3 2 2 3 4 2 3 4 x x x x x x x x x
```

## WORKED EXAMPLE 6.2

- a Use Pascal's triangle to expand  (1 2 ) 5 x -.
- b Find the coefficient of 3 x in the expansion of  (3 5 )(1 2 ) 5 x x + -.

## Answer

```
a -(1 2 ) 5 x The index is 5 so use the row for = 5 n in Pascal's triangle  (1, 5, 10, 10, 5, 1). (1 2 ) 1(1) 5(1) ( 2 ) 10(1) ( 2 ) 10(1) ( 2 ) 5(1)( 2 ) 1( 2 ) 1 10 40 80 80 32 5 5 4 3 2 2 3 4 5 2 3 4 5 -= + -+ -+ -+ -+ -= -+ -+ -x x x x x x x x x x x b + -= + -+ -+ -(3 5 )(1 2 ) (3 5 )(1 10 40 80 80 32 ) 5 2 3 4 5 x x x x x x x x The term in 3 x comes from the products: + -+ -+ -(3 5 )(1 10 40 80 80 32 ) 2 3 4 5 x x x x x x 3 ( 80 ) 240 3 3 × -= -x x and 5 40 200 2 3 × = x x x Coefficient of 240 200 40 3 = -+ = -x .
```

## EXERCISE 6A

- 1 Use Pascal's triangle to find the expansions of:
- a + ( 2) 3 x b -(1 ) 4 x c + ( ) 3 x y d -(2 ) 3 x e -( ) 4 x y f + (2 3 ) 3 x y g -(2 3) 4 x

$$\mathfrak { h } \ \left ( x ^ { 2 } + \frac { 3 } { 2 x ^ { 3 } } \right ) ^ { 3 }$$

- 2 Find the coef ficient of 3 x in the expansions of:

$$\begin{matrix} a & ( x + 3 ) ^ { 4 } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & && & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & _ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & - & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &   & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & . & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &.. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &$$

- 3 + + -≡ + + (3 ) (3 ) 5 5 2 4 x x A Bx Cx
- Find the value of A , the value of B and the value of C .
- 4 The coef ficient of 2 x in the expansion of + (3 ) 4 ax is 216. Find the possible values of the constant a .
- 5 a Expand + (2 ) 4 x .
- b Use your answer to part a to express + (2 3) 4 in the form + 3 a b .
- 6 a Expand + (1 ) 3 x .
- b Use your answer to part a to express:
- i + (1 5) 3 in the form + 5 a b
- ii -(1 5) 3 in the form + 5 c d .
- c Use your answers to part b to simplify + + -(1 5) (1 5) 3 3 .
- 7 Expand + + (1 )(2 3 ) 4 x x .
- 8 a Expand -( 1) 2 4 x .
- b Find the coef ficient of 6 x in the expansion of --(1 2 )( 1) 2 2 4 x x .
- 9 Find the coefficient of 2 x in the expansion of -    3 2 4 x x .
- 10 Find the term independent of x in the expansion of 3 2 2 4 x x -    .
- 11  a Find the first three terms, in ascending powers of y , in the expansion of + (1 ) 4 y .
- b By replacing y with -5 2 2 x x , find the coefficient of 2 x in the expansion of + -(1 5 2 ) 2 4 x x .
- 12 The coef ficient of 2 x in the expansion of + (1 ) 4 ax is 30 times the coefficient of x in the expansion of +     1 3 3 ax . Find the value of a .
- 13 Find the power of x that has the greatest coefficient in the expansion of +     3 1 4 4 x x .
- 14  a Write down the expansion of + ( ) 5 x y .
- b Without using a calculator and using your result from part a , find the value of 10 1 4 5     , correct to the nearest hundred.
- 15  a Given that 1 1 2 4 2 4 5 x x x x px q x +     --    = + , find the value of p and the value of q .
- b Hence, without using a calculator, find the exact value of +       --      2 1 2 2 1 2 4 4 .

159

160

```
16 = + 1 y x x a Express 1 3 3 x x + in terms of y . PS
```

- b Express 1 5 5 x x + in terms of y .

## 6.2  Binomial coefficients

Pascal's triangle can be used to expand + ( ) a b n for any positive integer n , but if n is large it can take a long time to write out all the rows in the triangle. Hence, we need a more ef ficient method to find the coefficients in the expansions. The coefficients in the binomial expansion of + (1 ) x n are known as binomial coefficients .

## EXPLORE 6.2

Consider the expansion:

$$( 1 + x ) ^ { 5 } = 1 + 5 x + 1 0 x ^ { 2 } + 1 0 x ^ { 3 } + 5 x ^ { 4 } + x ^ { 5 }$$

```
(1 ) 1 5 10 10 5 The coefficients are: 1 5 10 10 5 1
```

- Find the  C n r function on your calculator. On some calculators this may be n r C or       n r .
- 1 Use your calculator to find the values of:

$$\left ( \begin{array} { c } 5 \\ 0 \end{array} \right ), \left ( \begin{array} { c } 5 \\ 1 \end{array} \right ), \left ( \begin{array} { c } 5 \\ 2 \end{array} \right ), \left ( \begin{array} { c } 5 \\ 3 \end{array} \right ), \left ( \begin{array} { c } 5 \\ 4 \end{array} \right ) \text{and} \left ( \begin{array} { c } 5 \\ 5 \end{array} \right ).$$

- 2 What do you notice about your answers to question 1?
- 3 Complete the following four statements.

$$\begin{array} { c } \text{$w$n$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$i$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$o$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$ u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$t$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$tu$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$uh$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$ul$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$ur$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$un$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$ut$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$uc$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$lu$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$usu$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u`u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u$u\end{array} \\$$

We write the binomial expansion of  (1 ) x n + , where n is a positive integer as:

## KEY POINT 6.1

$$\left ( \begin{array} { c } \text{ If } n \text{ is a positive integer, then } ( 1 + x ) ^ { n } = \left ( \begin{array} { c } n \\ 0 \end{array} \right ) + \left ( \begin{array} { c } n \\ 1 \end{array} \right ) x + \left ( \begin{array} { c } n \\ 2 \end{array} \right ) x ^ { 2 } + \cdots + \left ( \begin{array} { c } n \\ n \end{array} \right ) x ^ { n }.$$

TIP

$$\begin{vmatrix} \text{To find} \left ( \begin{matrix} 5 \\ 2 \end{matrix} \right ), \text{key in} \\ \left [ 5 \end{matrix} \right ] \underline { n C r } \right ].$$

We can therefore write the expansion of  (1 ) x n + using binomial coef ficients; the result is known as the Binomial theorem .

We can use the Binomial theorem to expand ( ) a b n + , too. We can write  ( ) 1 a b a b a n n n + = +     (assuming that 0 a ≠ ).

## KEY POINT 6.2

$$\Big | \quad ( a + b ) ^ { n } = \left ( \begin{array} { c } n \\ 0 \end{array} \right ) a ^ { n } + \left ( \begin{array} { c } n \\ 1 \end{array} \right ) a ^ { n - 1 } b ^ { 1 } + \left ( \begin{array} { c } n \\ 2 \end{array} \right ) a ^ { n - 2 } b ^ { 2 } + \cdots + \left ( \begin{array} { c } n \\ n \end{array} \right ) b ^ { n }$$

## WORKED EXAMPLE 6.3

Find, in ascending powers of x , the first four terms in the expansion of:

$$\eta ^ { 1 0 }$$

$$| \quad a \ \ ( 1 + x ) ^ { 1 5 } \quad \ \ b \ \ ( 2 - 3 x ) ^ { 1 0 }$$

Answer

$$\Big | \ a _ { \ } ( 1 + x ) ^ { 1 5 } = \binom { 1 5 } { 0 } + \binom { 1 5 } { 1 } x + \binom { 1 5 } { 2 } x ^ { 2 } + \binom { 1 5 } { 3 } x ^ { 3 } + \cdots$$

1 15 105 455 2 3 x x x = + + + + …

$$\Big | \quad b \ ( 2 - 3 x ) ^ { 1 0 } = \left ( \begin{smallmatrix} 1 0 \\ 0 \end{smallmatrix} \right ) 2 ^ { 1 0 } + \left ( \begin{smallmatrix} 1 0 \\ 1 \end{smallmatrix} \right ) 2 ^ { 9 } ( - 3 x ) ^ { 1 } + \left ( \begin{smallmatrix} 1 0 \\ 2 \end{smallmatrix} \right ) 2 ^ { 8 } ( - 3 x ) ^ { 2 } + \left ( \begin{smallmatrix} 1 0 \\ 3 \end{smallmatrix} \right ) 2 ^ { 7 } ( - 3 x ) ^ { 3 } + \cdots$$

1024 15360 103680 414720 2 3 x x x = -+ -+ …

You should also know how to work out the binomial coef ficients without using a calculator.

$$\text{From Pascal} ^ { \ } s t i r a l g e, \, \text{we know that} \, \left ( \begin{array} { c } 5 \\ 0 \end{array} \right ) = 1 \text{ and } \left ( \begin{array} { c } 5 \\ 5 \end{array} \right ) = 1.$$

In general, we can write this as:

## KEY POINT 6.3

$$\Big | \ \left ( \begin{array} { c } n \\ 0 \end{array} \right ) = 1 \text{ and } \left ( \begin{array} { c } n \\ n \end{array} \right ) = 1$$

$$\text{We write } \left ( \begin{array} { c } 5 \\ 1 \end{array} \right ), \left ( \begin{array} { c } 5 \\ 2 \end{array} \right ), \left ( \begin{array} { c } 5 \\ 3 \end{array} \right ) \text{and} \left ( \begin{array} { c } 5 \\ 4 \end{array} \right ) \text{as} \colon$$

$$\left ( \begin{array} { c } 5 \\ 1 \end{array} \right ) = \frac { 5 } { 1 } = 5 \quad \left ( \begin{array} { c } 5 \\ 2 \end{array} \right ) = \frac { 5 \times 4 } { 2 \times 1 } = 1 0 \quad \left ( \begin{array} { c } 5 \\ 3 \end{array} \right ) = \frac { 5 \times 4 \times 3 } { 3 \times 2 \times 1 } = 1 0 \quad \left ( \begin{array} { c } 5 \\ 4 \end{array} \right ) = \frac { 5 \times 4 \times 3 \times 2 } { 4 \times 3 \times 2 \times 1 } = 5$$

161

162

In general, if r is a positive integer less than n , then:

## KEY POINT 6.4

$$\Big | \quad \left ( \begin{array} { c } n \\ r \end{array} \right ) = \frac { n \times ( n - 1 ) \times ( n - 2 ) \times \cdots \times ( n - r + 1 ) } { r \times ( r - 1 ) \times ( r - 2 ) \times \cdots \times 3 \times 2 \times 1 }$$

## WORKED EXAMPLE 6.4

<!-- image -->

```
a Without using a calculator , find the value of 8 4       . b Find an expression, in terms of n , for 4 n       . Answer a 8 4 8 7 6 5 4 3 2 1 70       = × × × × × × = b 4 ( 1) ( 2) ( 3) 4 3 2 1 ( 1)( 2)( 3) 24       = × -× -× -× × × = ---n n n n n n n n n
```

## WORKED EXAMPLE 6.5

When 1 3 -    x n is expanded in ascending powers of x , the coefficient of 2 x is 4. Given that n is the positive integer, find the value of n .

## Answer

$$<_OCaml_>     Answer
    Term in x^2 = { n \} { - \x \} ^ { 2 } = \n \x ( n - 1 ) \x ^ { 2 } = \n \x ( n - 1 ) \x ^ { 2 } \x ^ { 1 } \quad 9 \quad 18 \quad \n \times ( n - 1 ) \quad 12 \quad 9 \quad 18 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 18 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \ n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 2 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 6 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \rho \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \ \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \ times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( N - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 2 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 6 \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \nu \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \ times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 3 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 8 \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7\quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n \times ( n - 1 ) \quad 7 \quad \n\times ( n - 1 ) \quad 7 \quad \n$$

## WORKED EXAMPLE 6.6

When  (2 ) 8 kx + is expanded, the coefficient of 5 x is two times the coefficient of 4 x . Given that 0 k &gt; , find the value of k . Answer Term in =           = 8 5 (2) ( ) 448 5 3 5 5 5 x kx k x Term in =           = 8 4 (2) ( ) 1120 4 4 4 4 4 x kx k x Coefficient of 2 coefficient of 448 2 1120 448 2240 0 448 ( 5) 0 0 or 5 5 4 5 4 5 4 4 x x k k k k k k k k = × = × -= -= = = 0 or 5 As is a positive integer, 5 k k k k = = = .

## WORKED EXAMPLE 6.7

- a Obtain the first three terms in the expansion of  (2 )(1 2 ) 9 x x -+ .
- b Use your answer to part a to estimate the value of 1.99 1.02 9 × .

## Answer

$$\left | \, \ a \, \ ( 2 - x ) ( 1 + 2 x ) ^ { 9 } = ( 2 - x ) \left [ \left ( \, 9 \, \right ) + \left ( \, 9 \, \right ) ( 2 x ) ^ { 1 } + \left ( \, 9 \, \right ) ( 2 x ) ^ { 2 } + \cdots \, \right ]$$

$$( 1 + 2 x ) ^ { 9 } & = ( 2 - x ) \left [ \begin{matrix} 9 \\ 0 \end{matrix} \right ] + \left [ \begin{matrix} 9 \\ 1 \end{matrix} \right ] ( 2 x ) ^ { 1 } + \left [ \begin{matrix} 9 \\ 2 \end{matrix} \right ] ( 2 x ) ^ { 2 } + \cdots \right ] \\ & = ( 2 - x ) ( 1 + 18 x + 144 x ^ { 2 } + \cdots ) \\ & = 2 ( 1 + 18 x + 144 x ^ { 2 } + \cdots ) - x ( 1 + 18 x + 144 x ^ { 2 } + \cdots ) \\ & = 2 + ( 2 x 18 - 1 ) x + ( 2 x 144 - 18 ) x ^ { 2 } + \cdots \\ & = 2 + 35 x + 270 x ^ { 2 } + \cdots \end{matrix}$$

b

(2

)(1

2

)

2

35

270

9

2

x

x

x

x

-

+

=

+

+

+

…

Let

1.99

1.02

x

≈

2

35(0.01)

270(0.01)

9

×

+

+

1.99

1.02

2.377

9

×

≈

There is an alternative formula for calculating

n







r







. To be able to understand and apply the alternative formula, we need t o first know about factorial notation.

We write 6! to mean 6 5 4 3 2 1 × × × × × , and call it '6 factorial'.

2

=

0.01

.

163

164

In general, if n is a positive integer, then:

## KEY POINT 6.5

= × -× -× -× … × × × n n n n n ! ( 1) ( 2) ( 3) 3 2 1

$$\text{The formula for } \left ( \begin{array} { c } n \\ r \end{array} \right ) \text{then becomes} \colon$$

## KEY POINT 6.6

$$\Big | \ \left ( \begin{array} { c } n \\ r \end{array} \right ) = \frac { n! } { r! \left ( n - r \right )! }$$

## WORKED EXAMPLE 6.8

$$\Big | \ \ U { e } \, \text{the formula } \, \Big ( \begin{array} { c } n \\ r \end{array} \Big ) = \frac { n! } { r! \, \left ( n - r \right )! } \, \text{ to find the value of} \colon$$

$$\Big | \quad \ a \ \left ( \begin{array} { c } 8 \\ 4 \end{array} \right ) \quad \ \ \ b \ \left ( \begin{array} { c } 9 \\ 3 \end{array} \right )$$

Answer

$$\Big | \quad a \, \left ( \begin{array} { c } 8 \\ 4 \end{array} \right ) = \frac { 8! } { 4! ( 8 - 4 )! } = \frac { 8! } { 4! 4! }$$

$$\Big | \quad b \, \left ( \begin{array} { c } 9 \\ 3 \end{array} \right ) = \frac { 9! } { 3! ( 9 - 3 )! } = \frac { 9! } { 3! 6! }$$

## WORKED EXAMPLE 6.9

Find the term independent of x in the expansion of +     5 2 9 x x .

## Answer

$$\left | \ \left ( x + \frac { 5 } { x ^ { 2 } } \$$

The term that is independent of x is the term that when simplified does not involve x .

The x terms cancel each other out when the power of x is double the power of 5 2 x .

Also, the sum of these powers must be 9.

Hence, we are looking for powers of 6 and 3, respectively, and the corresponding binomial coefficient is 9 3       .

The term independent of x is:

$$\Big | \, \left ( \, \begin{array} { c } 9 \\ 3 \$$

## EXERCISE 6B

- 1 Without using a calculator , find the value of each of the following.

a

7











9





3









b

6













c

12

4





- 2 Express each of the following in terms of n .

$$a \left ( \begin{matrix} n \\ 2 \end{matrix} \right )$$

- 3 Use the formula ! ! ! n r n r n r ( )       = -to find the value of of each of the following.

$$a _ { 1 } \left ( \begin{smallmatrix} 1 0 \\ 2 \end{$$

- 4 Find, in ascending powers of x , the first three terms in each of the following expansions.

$$\begin{array} {$$

- 5 Find the coefficient of 3 x in each of the following expansions.

$$a _ { 0 } & ( 1 - x ) ^ { 9 } & b _ { 0 } & ( 1 + 3 x ) ^ { 1 / 2 } & c _ { 0 } & \left ( 2 + \frac { x } { 4 } \right ) ^ { 7 } & d _ { 0 } & \left ( 3 - \frac { x } { 3 } \right ) ^ { 1 0 } & 1 6 5$$

- 6 Find the coefficient of 4 x in the expansion of  (2 1) 12 x + .
- 7 Find the term in 5 x in the expansion of  (5 2 ) 8 -x .
- 8 Find the coefficient of 8 5 x y in the expansion of  ( 2 ) 13 x y -.
- 9 Find the term independent of x in the expansion of 3 2 12 x x -    .
- 10 Find, in ascending powers of x , the first three terms of each of the following expansions.

$$\tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { v } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \that { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu} \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde{ \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu } \tilde { \nu }$$

- 11  a Find, in ascending powers of x , the first three terms in the expansion of  (2 ) 10 x + .
- b By replacing x with  2 3 2 y y -, find the first three terms in the expansion of  (2 2 3 ) 2 10 y y + -.
- 12  a Find, in ascending powers of x , the first three terms in the expansion of -    1 2 8 x .
- b Hence, obtain the coefficient of 2 x in the expansion of + --    (2 3 ) 1 2 2 8 x x x .
- 13 Find the first three terms, in ascending powers of x , in the expansion of  (2 3 ) (1 2 ) 4 10 x x -+ .
- 14 The first four terms, in ascending powers of x , in the expansion of  (1 ) 2 7 ax bx + + are 1 14 91 2 3 x x px -+ + . Find the values of a , b and p .
- 15 The first two terms, in ascending powers of x , in the expansion of + -    (1 ) 2 4 x x n are 2 p qx + . Find the values of n , p and q . PS







d









15

6









165

166

## 6.3  Arithmetic progressions

At IGCSE / O Level you learnt that a number sequence is a list of numbers and that the numbers in the sequence are called the terms of the sequence.

A linear sequence such as 5, 8, 11, 14, 17, … is also called an arithmetic progression . Each term differs from the term before by a constant. This constant is called the common difference .

The notation used for arithmetic progressions is:

first term a =

common difference d =

last term l =

The common difference is also allowed to be zero or negative. For example, … 10, 6, 2, 2, -and … 5, 5, 5, 5, are both arithmetic progressions.

Th e first five terms of an arithmetic progression whose first term is a and whose common difference is d are:

a

a d +

2 a d +

3 a d +

4 a d +

term 1

term 2

term 3

term 4

term 5

From this pattern, you can see that the formula for the n th term is given by:

## KEY POINT 6.7

th term ( 1) n a n d = + -

## WORKED EXAMPLE 6.10

Find the number of terms in the arithmetic progression 3, 1, 5, 9, 13, , 237 -…

.

Answer n a n d th term ( 1) = + -

237

n

3

4(

1)

= -

+

-

n

1

60

-

=

n 61 =

## WORKED EXAMPLE 6.11

The fourth term of an arithmetic progression is 7 and the tenth term is 16. Find th e first term and the commo n difference.

## Answer

```
= ⇒ + = = ⇒ + = -= = a d a d d d 4th term 7 3 7 (1) 10th term 16 9 16 (2) (2) (1) gives 6 9 1.5 Substituting into (1) gives + = = 4.5 7 2.5 a a = First term 2.5, = common difference 1.5
```

Use 3, 4 a d = -= and th term 237 n = .

Solve.

## WORKED EXAMPLE 6.12

= - = - 1st term 5 6(1) 1

= - = - 2nd term 5 6(2) 7

= - = - Common difference 2nd term 1st term 6

Substitute 2 n = into n th term n 5 6 . = -

Substitute 1 n = into n th term n 5 6 . = -

The th n term of an arithmetic progression is 5 6 n - . Find th e first term and the common difference.

Answer

## The sum of an arithmetic progression

When the terms in a sequence are added together we call the resulting sum a series .

## EXPLORE 6.3

## 1 2 3 4 97 98 99 100 ? + + + + … + + + + =

It is said that, at the age of seven or eight, the famous mathematician Carl Gauss was asked to find the sum of the numbers from 1 to 100. His teacher expected this task to keep him occupied for some time but Gauss surprised him by writing down the correct answer almost immediately. His method involved adding the numbers in pairs: 1 100 101 + = ,  2 99 101 + = ,  3 98 101, … + =

- 1 Can you complete Gauss's method to find the answer?
- 2 Use Gauss's method to find the sum of:
- a 2 4 6 8 494 496 498 500 + + + + … + + + +
- b 5 10 15 2 0 185 190 195 200 + + + + … + + + +
- c 6 9 12 15 93 96 99 102 + + + + … + + + +
- 3 Use Gauss's method t o find an expression, in terms of n , for the sum: 1 2 3 4 ( 3) ( 2) ( 1) n n n n + + + + … + -+ -+ -+

The sum of an arithmetic progression, Sn , can be written as:

## KEY POINT 6.8

$$\Big | \ S _ { n } = \frac { n } { 2 } \left ( a + l \right ) \quad \text{or} \quad S _ { n } = \frac { n } { 2 } \left [ 2 a + ( n - 1 ) d \right ]$$

167

168

We can prove this result as follows, by writing out the series in full.

S

=

+

+

+

+

+ … +

-

+

(

)

(

2

)

(

2

)

a

a

d

a

d

l

d

n

Reversing:

Adding:

-

+

(

)

l

d

l

$$\colon \quad \ S _ { n } = \ \ l \ \ + ( l - d ) \ + ( l - 2 d ) \ + \cdots + ( a + 2 d ) + ( a + d ) + \ a$$

$$2 S _ { n } = ( a + l ) + ( a + l ) \, + ( a + l ) \ + \cdots + ( a + l ) \ + ( a + l ) \ + ( a + l )$$

= + 2 ( ), as there are terms in the series S n a l n n

$$\text{So } S _ { n } = \frac { n } { 2 } \left ( a + l \right ).$$

Using = + -l a n d ( 1) , this can be rewritten as = + -S n a n d n 2 [2 ( 1) ].

It is useful to remember the following rule that applies for all sequences.

## KEY POINT 6.9

= --n S S n n th term 1

## WORKED EXAMPLE 6.13

In an arithmetic progression, the 1st term is 12 -, the 17th term is 12 and the last term is 45. Find the sum of all the terms in the progression.

## Answer

$$<_Python_>$$

## WORKED EXAMPLE 6.14

The 10th term in an arithmetic progression is 14 and the sum of th e first 7 terms is 42.

Find the first term of the progression and the common difference.

## Answer

```
= + -= + = + -= + = + th term ( 1) 14 9 (1) 2 [2 ( 1) ] 42 7 2 (2 6 ) 6 3 (2) n a n d a d S n a n d a d a d n Use th term 14 n = when 10 n = . Use 7 n = and 42 7 S = . d d (1) (2) gives 6 8 4 3 -= = Substituting = 4 3 d into equation (1) gives = 2 a . = First term 2, = common difference 4 3
```

## WORKED EXAMPLE 6.15

The sum of the first n terms, Sn , of a particular arithmetic progression is given by 4 2 S n n n = + . a Find the first term and the common difference. b Find an expression for the th n term. Answer

```
a = + = 4(1) 1 5 1 2 S = + = 4(2) 2 18 2 2 S = -= Second term 18 5 13 First term 5, = = common difference 8 First term 5 = + = First term second term 18 b Method 1: th term ( 1) 5 8( 1) 8 3 = + -= + -= -n a n d n n Method 2: = -= + --+ -= + --+ + -= --n S S n n n n n n n n n n n n th term 4 [4( 1) ( 1)] 4 (4 8 4 1) 8 3 1 2 2 2 2 Use 5, 8 a d = = .
```

170

## EXERCISE 6C

- 1 Th e first term in an arithmetic progression is a and the common difference is d .

Write down expressions, in terms of a and d , for the seventh term and the 19th term.

- 2 Find the number of terms and the sum of each of these arithmetic series.
- a + + + … + 13 17 21 97
- b + + + … + 152 149 146 50
- 3 Find the sum of each of these arithmetic series.
- a 5 12 19 + + + … (17 terms)
- b 4 1 ( 2) + + -+ … (38 terms)
- c 1 3 1 2 2 3 + + + … (20 terms)
- d 5 9 x x x ----… (40 terms)
- 4 The first term of an arithmetic progression is 15 and the sum of the first 20 terms is 1630. Find the common difference.
- 5 In an arithmetic progression, the first term is 27 -, the 16th term is 78 and the last term is 169.
- a Find the common difference and the number of terms.
- b Find the sum of the terms in this progression.
- 6 The first two terms in an arithmetic progression are 146 and 139. The last term is 43 -. Find the sum of all the terms in this progression.
- 7 The first two terms in an arithmetic progression are 2 and 9. The last term in the progression is the only number that is greater than 150. Find the sum of all the terms in the progression.
- 8 The first term of an arithmetic progression is 15 and the last term is 27. The sum of the first five terms is 79. Find the number of terms in this progression.
- 9 Find the sum of all the integers between 100 and 300 that are multiples of 7.
- 10 The first term of an arithmetic progression is 2 and the 11th term is 17. The sum of all the terms in the progression is 500. Find the number of terms in the progression.
- 11 Robert buys a car for $8000 in total (including interest). He pays for the car by making monthly payments that are in arithmetic progression. The first payment that he makes is $200 and the debt is fully repaid after 16 payments. Find the fifth payment.
- 12 The sixth term of an arithmetic progression is 3 -and the sum of the first ten terms is 10 -.
- a Find the first term and the common difference.
- b Given that the th n term of this progression is 59 -, find the value of n .
- 13 The sum of the first n terms, Sn , of a particular arithmetic progression is given by 4 3 2 S n n n = + . Find the first term and the common difference.
- 14 The sum of the first n terms, Sn , of a particular arithmetic progression is given by 12 2 2 S n n n = -. Find the first term and the common difference.

- 15 The sum of th e first n terms, Sn , of a particular arithmetic progression is given by 1 4 (5 17 ) 2 S n n n = -. Find an expression for the th n term.
- 16 A circle is divided into ten sectors. The sizes of the angles of the sectors are in arithmetic progression. The angle of the largest sector is seven times the angle of the smallest sector. Find the angle of the smallest sector.
- 17 An arithmetic sequence has first term a and common difference d . The sum of the first 20 terms is seven times the sum of the first five terms.
- a Find d in terms of a .
- b Find the 65th term in terms of a .
- 18 The tenth term in an arithmetic progression is three times the third term. Show that the sum of the first ten terms is eight times the sum of the first three terms.
- 19 The first term of an arithmetic progression is x sin 2 and the second term is 1. P
- a Write down an expression, in terms of x sin , for the fifth term of this progression.
- b Show that the sum of the first ten terms of this progression is + 10 35 cos 2 x .
- 20 The sum of the digits in the number 67 is 13 (as 6 7 13). + = PS
- a Show that the sum of the digits of the integers from 19 to 21 is 15.
- b Find the sum of the digits of the integers from 1 to 99.

## 6.4  Geometric progressions

The sequence  2, 6, 18, 54, … is called a geometric progression . Each term is three times the preceding term. The constant multiplier, 3, is called the common ratio .

The notation used for a geometric progression is:

first term common ratio a r = =

The first five terms of a geometric progression whose first term is a and whose common ratio is r are:

a

ar

2 ar

3 ar

4

ar

term 1

term 2

term 3

term 4

term 5

This leads to the formula for the n th term of a geometric progression:

## KEY POINT 6.10

th n term = -ar n 1

## WORKED EXAMPLE 6.16

The fifth term of a geometric progression is 1 and the common ratio is 1 2 . Find the eighth term and an expression for th e th n term.

Answer

= - n ar n th term 1

Use

th term

1

n

=

when

5

n

=

and

1

2

r

=

.

171

172

```
=     = =     = = =     --a a n ar n n 1 1 2 16 8th term 16 1 2 1 8 th term 16 1 2 4 7 1 1
```

## WORKED EXAMPLE 6.17

The second and fifth terms in a geometric progression are 12 and 40.5, respectively. Find the first term and the common ratio. Hence, write down an expression for the th n term.

```
Answer = 12 (1) ar = 40.5 (2) 4 ar (2) ÷ (1) gives 40.5 12 27 8 3 2 4 3 ar ar r r = = = Substituting = 3 2 r into equation (1) gives = 8 a . = First term 8, = common ratio 3 2 , =     -n n th term 8 3 2 1 .
```

## WORKED EXAMPLE 6.18

The th n term of a geometric progression is  -   9 2 . Find th e first term and the common ratio.

This is also clear from the formula directly: each term is  - 2 times the previous one.

$$<_OCaml_>     WORKED EXAMPLE 6.18
    

    The nth term of a geometric progression is 9 { -2 } "
    
    Answer
        lst term = 9 { -2 } " = -6
    
    2nd term = 9 { -2 } " = 4
    
    Common ratio = -2nd term = -4 -2
                                                                                                                                                                                                        
    Common ratio = -2nd term = -6 -2
                                                                                                                                                                                                    
   This is also clear from the formula directly: each term is { -2 } times the j
    
    First term = -6, common ratio = -2$$

## EXPLORE 6.4

<!-- image -->

In this Explore activity you are not allowed to use a calculator.

- 1 Consider the sum of th e first 10 terms, 10 S , of a geometric progression with 1 a = and 3 r = .

$$\mathcal { H } _ { 1 0 } = 1 + 3 + 3 ^ { 2 } + 3 ^ { 3 } + \dots + 3 ^ { 7 } + 3 ^ { 8 } + 3 ^ { 9 }$$

- a Multiply both sides of the previous equation by the common ratio, 3, and complete the following statement.

$$3 \mathcal { H } _ { 1 0 } = 3 + 3 ^ { 2 } + 3 \cdots + 3 \cdots + 3 \cdots + 3 \cdots + 3 \cdots$$

- b How does this compare to the original expression? Can you use this to find a simpler way of expressing the sum 10 S ?
- 2 Use the method from question 1 t o find an alternative way of expressing each of the following.

a r r 1 2 + + + … (10 terms) b a ar ar 2 + + + … (10 terms) c a ar ar 2 + + + … ( n terms)

You will have discovered in Explore 6.4 that the sum of a geometric progression, Sn , can be written as:

## KEY POINT 6.11

$$\Big | \ S _ { n } = \frac { a ( 1 - r ^ { n } ) } { 1 - r } \quad \text{or} \quad S _ { n } = \frac { a ( r ^ { n } - 1 ) } { r - 1 }$$

Either formula can be used but it is usually easier to:

- /uni25CF Use the first formula when 1 1 r &lt; &lt; -.
- /uni25CF Use the second formula when 1 r &gt; or when -1 r ø .

$$\bullet \ \text{Use the second formula when } r > 1 \ \text{or when } r \lesssim - 1. \\ \text{This is the proof of the formulae in Key point $6.11$.} \\ S _ { n } & = a + a r + a r ^ { 2 } + \cdots + a r ^ { n - 3 } + a r ^ { n - 2 } + a r ^ { n - 1 } \ \text{------------} ( 1 ) \\ r \times ( 1 ) & = \frac { a r + a r ^ { 2 } + \cdots + a r ^ { n - 3 } + a r ^ { n - 2 } + a r ^ { n - 1 } + a r ^ { n } } { 2 } \\ ( 2 ) - ( 1 ) & = r S _ { n } - S _ { n } & = a r ^ { n } - a \\ & \quad ( r - 1 ) S _ { n } & = a ( r ^ { n } - 1 ) \\ S _ { n } & = \frac { a ( r ^ { n } - 1 ) } { r - 1 }$$

$$S _ { n } = \frac { a ( r ^ { n } - 1 ) } { r - 1 }$$

Multiplying the numerator and the denominator by -1 gives the alternative formula

$$S _ { n } = \frac { \mu _ { \lambda } \lambda _ { \lambda } ^ { \mu _ { \lambda } } } { 1 - r }.$$

Can you see why this formula does not work when = 1 r ?

## TIP

These formulae are not defined when = 1 r .

173

174

## WORKED EXAMPLE 6.19

Find the sum of the first 12 terms of the geometric series  3 6 12 24 + + + + … . Answer

$$S _ { n } & = \frac { a ( r ^ { n } - 1 ) } { r - 1 } \\ S _ { 1 2 } & = \frac { 3 ( 2 ^ { 1 2 } - 1 ) } { 2 - 1 } \\ & = 1 2 2 8 5$$

```
12285 n -= Use 3 a = , 2 r = and 12 n = . Simplify.
```

## WORKED EXAMPLE 6.20

The third term of a geometric progression is nine times the first term. The sum of the first six terms is k times the sum of the first two terms. Find the value of k .

## Answer

= × = = ± ar a r 3rd term 9 first term 9 3 2 Use ( 1) 1 ( 1) 1 1 1 6 2 6 2 6 2 = --= --= --S kS a r r ka r r k r r Divide both sides by a (which we assume is non-zero) and solve. Rearrange to make k the subject. When = 3 r , = 91 k and when 3 = -r , 91 = k . Hence, = 91 k .

## EXERCISE 6D

- 1 Identify whether the following sequences are geometric.

If they are geometric, write down the common ratio and the eighth term.

```
a 2, 4, 8, 14, … b 7, 21, 63, 189, … c 81, 27, 9, 3, --… d 1 9 , 2 9 , 4 9 , 7 9 , … e 1, 0.4, 0.16, 0.64, … f 1, 1, 1 , 1, --…
```

- 2 Th e first term in a geometric progression is a and the common ratio is r . Write down expressions, in terms of a and r , for the sixth term and the 15th term.
- 3 The first term of a geometric progression is 270 and the fourth term is 80. Find the common ratio.
- 4 The first term of a geometric progression is 50 and the second term is 30 -. Find the fourth term.
- 5 The second term of a geometric progression is 12 and the fourth term is 27. Given that all the terms are positive, find the common ratio and the first term.
- 6 The sum of the second and third terms in a geometric progression is 84. The second term is 16 less than the first term. Given that all the terms in the progression are positive, find the first term.

- 7 Three consecutive terms of a geometric progression are x , 4 and 6 x + . Find the possible values of x .
- 8 Find the sum of th e first eight terms of each of these geometric series.
- a 3 6 12 24 + + + + …
- b 128 64 32 16 + + + + …
- c 1 2 4 8 -+ -+ …
- d 243 162 108 72 + + + + …
- 9 The first four terms of a geometric progression are 0.5, 1, 2 and 4. Find the smallest number of terms that will give a sum greater than 1000 000.
- 10 A ball is thrown vertically upwards from the ground. The ball rises to a height of 8 m and then falls and bounces. After each bounce it rises to 3 4 of the height of the previous bounce.
- a Write down an expression for the height that the ball rises after the th n impact with the ground.
- b Find the total distance that the ball travels from the first throw to the fifth impact with the ground.
- 11 The second term of a geometric progression is 24 and the third term is 12( 1) x + .
- a Find, in terms of x , the first term of the progression.
- b Given that the sum of the first three terms is 76, find the possible values of x .
- 12 The third term of a geometric progression is nine times the first term. The sum of the first four terms is k times the first term. Find the possible values of k .
- 13 A company makes a donation to charity each year. The value of the donation increases exponentially by 10% each year. The value of the donation in 2010 was $10 000.
- a Find the value of the donation in 2016.
- b Find the total value of the donations made during the years 2010 to 2016, inclusive.
- 14 A geometric progression has first term a , common ratio r and sum to n terms Sn . P

$$\text{Show that } \frac { S _ { 3 n } - S _ { 2 n } } { S _ { n } } = r ^ { 2 n }.$$

- 15 Consider the sequence 1, 1, 3, 1 3 , 9, 1 9 , 27, 1 27 , 81, 1 81 , … . P

Show that the sum of the first 2 n terms of the sequence is + --n n 1 2 (2 3 3 ) 1 .

- 16 Let 1 11 111 1111 11111 Sn = + + + + + … to n terms. P

$$\text{Show that } S _ { n } = \frac { 1 0 ^ { n + 1 } - 1 0 - 9 n } { 8 1 }.$$

## 6.5  Infinite geometric series

An infinite sequence is a sequence whose terms continue forever.

Consider the infinite geometric progression where 2 a = and 1 2 r = , so it begins

- … 2, 1, 1 2 , 1 4 , 1 8 , . We can work out the sum of the first n terms of this:

$$S _ { 1 } = 2, \, S _ { 2 } = 3, \, S _ { 3 } = 3 \frac { 1 } { 2 }, \, S _ { 4 } = 3 \frac { 3 } { 4 }, \, S _ { 5 } = 3 \frac { 7 } { 8 }, \, \text{and so on.}$$

These sums are getting closer and closer to 4.

175

176

The diagram of the 2 by 2 square is a visual representation of this series. If the pattern of rectangles inside the square is continued, the total area of the rectangles approximates the area of the whole square (which is 4) increasingly well as more rectangles are included.

We therefore say that the sum of the in finite geometric series 2 1 1 1 1 + + + + + …

2 4 8 is 4, because the sum of the first n terms gets as close to 4 as we like as n gets larger. We write 2 1 1 2 1 4 1 8 4 + + + + + … = . We also say that the sum to infinity of this series is 4, and that the series converges to 4. A series that converges is also known as a convergent series .

You might be wondering why we can say this, as no matter how many terms we add up, the answer is always less than 4. The simplest answer is because it works. Mathematicians and philosophers have struggled with the idea of infinity for thousands of years, and whether something like '2 1 1 2 1 4 1 8 + + + + + … ' even makes sense. But over the past few

hundred years, we have worked out that writing '2 1 1 2 1 4 1 8 4 + + + + + … = ' turns out to be very useful, and gives us answers that work consistently when we try to do more mathematics with them.

You are probably also familiar with a very important example of an infinite geometric series without realising it! What do we mean by the recurring decimal … 0.3333 ?

We can write this as a series: … = + + + … 0.3333 3 10 3 100 3 1000 . If we work out the sum of the first n terms of this geometric series, we find = = 3 10 0.3, 1 S = = 33 100 0.33, 2 S

$$\stackrel { \dots } { s } S _ { 3 } = \frac { 3 3 3 } { 1 0 0 0 } = 0. 3 3 3 \, \text{and so on. These sums are getting as close as we like to } \stackrel { \dots } { s } S _ { 1 } = 0. 3 3 3 \, \text{and so we say that}$$

the sum of the infinite series is equal to 1 3 , and we write … = 1 3 0.3333 . This justifies what you have been writing for many years. Using the formula we will be working out shortly, we can easily write any recurring decimal as an exact fraction.

<!-- image -->

## DID YOU KNOW?

The first person to introduce infinite decimal numbers was Simon Stevin in 1585. He was an influential mathematician who popularised the use of decimals more generally as well, through a publication called De Thiende ('The tenth').

## EXPLORE 6.5

- 1 Investigate whether these infinite geometric series converge or not. You could use a spreadsheet to help with the calculations. If they converge, state their sum to infinity.

$$\begin{smallmatrix} b & a = 3, r = - \frac { 1 } { 5 } \\ \delta & a = - \frac { 1 } { 2 }, r = - 2 \\ \end{smallmatrix}$$

$$\begin{array} {$$

- 2 Find other convergent geometric series of your own. In each case, find the sum to infinity.
- 3 Can you find a condition for r for which a geometric series is convergent?

<!-- image -->

2

Consider the geometric series + + + + … + -a ar ar ar ar n 2 3 1 .

(1 ) n -.

If 1 1 r &lt; &lt; -, then as n gets larger and larger, r n gets closer and closer to 0.

The sum, Sn , is given by the formula 1 S a r r n = -

We say that as n tends to infinity, r n tends to zero, and we write 'as , 0 n r n →∞ → '.

$$\text{Hence, as } n \to \infty, \, \frac { a ($$

This gives the result:

## KEY POINT 6.12

$$\Big | \ S _ { \infty } = \frac { a } { 1 - r }$$

If 1 r ù or 1 r ø , then r n

So an infinite geometric series converges when and only when 1 r

-does not converge, and so the series itself does not converge. 1. -&lt; &lt;

## WORKED EXAMPLE 6.21

Th e first four terms of a geometric progression are 5, 4, 3.2 and 2.56.

- a Write down the common ratio.
- b Find the sum to infinity.

Answer

$$<_Haskell_> |        a   Common ratio = \frac {$$

$$\cdot \cdot \ U s e _ { \ } a = 5 \, \text{$$

$$<_Python_>         a   Common ratio =                                                                                                                                                                                                        
        b   S _ _ =$$

```
25 = 5 .
```

## WORKED EXAMPLE 6.22

A geometric progression has a common ratio of -2 3 and the sum of the first three terms is  63.

- a Find the first term of the progression.
- b Find the sum to infinity.

## Answer

```
a = --= --          --    S a r r a (1 ) 1 63 1 2 3 1 2 3 3 3 3 Use 63 3 S = and = -r 2 3 . Simplify.
```

177

178

In this image there is a table with some numbers written on it.

<!-- image -->

## EXERCISE 6E

- 1 Find the sum to in finity of each of the following geometric series.
- a 2 2 3 2 9 2 27 + + + + … b 1 0.1 0.01 0.001 + + + + … c 40 20 10 5 -+ -+ … d 64 48 36 27 -+ -+ -…
- 2 The first four terms of a geometric progression are 1, 0.5 2 , 0.5 4 and 0.5 6 . Find the sum to infinity.
- 3 The first term of a geometric progression is 8 and the second term is 6. Find the sum to infinity.
- 4 The first term of a geometric progression is 270 and the fourth term is 80. Find the common ratio and the sum to infinity.
- 5 a Write the recurring decimal 0.57 /dotnosp /dotnosp as the sum of a geometric progression.
- b Use your answer to part a to show that 0.57 /dotnosp /dotnosp can be written as 19 33 .
- 6 The first term of a geometric progression is 150 and the sum to infinity is 200. Find the common ratio and the sum of the first four terms.
- 7 The second term of a geometric progression is 4.5 and the sum to infinity is 18. Find the common ratio and the first term.
- 8 Write the recurring decimal … 0.315151515 as a fraction.
- 9 The second term of a geometric progression is 9 and the fourth term is 4. Given that the common ratio is positive, find:
- a the common ratio and the first term
- b the sum to infinity.
- 10 The third term of a geometric progression is 16 and the sixth term is -1 4 .
- a Find the common ratio and the first term.
- b Find the sum to infinity.

- 11 Th e first three terms of a geometric progression are 135, k and 60. Given that all the terms in the progression are positive, find:
- a the value of k
- b the sum to infinity.
- 12 The first three terms of a geometric progression are 12 k + , k and 9 k -, respectively.
- a Find the value of . k
- b Find the sum to infinity.
- 13 The fourth term of a geometric progression is 48 and the sum to infinity is five times the first term. Find the first term.
- 14 A geometric progression has first term a and common ratio r . The sum of the first three terms is 3.92 and the sum to infinity is 5. Find the value of a and the value of r .
- 15 The first term of a geometric progression is 1 and the second term is x 2cos , where  0 2 &lt; &lt; π x . Find the set of values of x for which this progression is convergent.
- 16 A circle of radius 1cm is drawn touching the three edges of an equilateral triangle. PS
- Three smaller circles are then drawn at each corner to touch the original circle and two edges of the triangle.
- This process is then repeated an infinite number of times, as shown in the diagram.
- a Find the sum of the circumferences of all the circles.
- b Find the sum of the areas of all the circles.

<!-- image -->

<!-- image -->

pattern 1

<!-- image -->

pattern 3

<!-- image -->

<!-- image -->

We can construct a Koch snow flake as follows.

Starting with an equilateral triangle (pattern 1), we perform the following steps to produce pattern 2.

Step 1: Divide each line segment into three equal segments.

- Step 2: Draw an equilateral triangle, pointing outwards, that has the middle segment from step 1 as its base.

Step 3: Remove the line segments that were used as the base of the equilateral triangles in step 2.

These three steps are then repeated to produce the next pattern.

- a Let pn be the perimeter of pattern n . Show that the sequence , , , 1 2 3 p p p … tends to in finity.
- b Let An be the area of pattern n . Show that the sequence , , , 1 2 3 A A A … tends to 8 5 times the area of the original triangle.
- c The Koch snow flake is the limit of the patterns. It has in finite perimeter but an area of 8 5 of the original triangle, as you have shown. This snow flake pattern is an example of a fractal. Use the internet t o find out about the Sierpinski triangle fractal.
- 17 P

180

## 6.6  Further arithmetic and geometric series

## EXPLORE 6.6

$$a, b, c, \dots$$

- 1 Given that a , b and c are in arithmetic progression , find an equation connecting a , b and c .
- 2 Given that a , b and c are in geometric progression, find an equation connecting a , b and c .

## WORKED EXAMPLE 6.23

Th e first, second and third terms of an arithmetic series are x , y and 2 x . The first, second and third terms of a geometric series are x , 2 x and y . Given that 0 x &lt; , find:

- a the value of x and the value of y
- b the sum to infinity of the geometric series
- c the sum of the first 20 terms of the arithmetic series.

## Answer

```
a Arithmetic series is: 2 x y x + + + … 2 (1) 2 2 y x x y y x x -= -= + Use common differences. Geometric series is: 2 x x y + + + … (2) 2 2 3 y x x x y x = = Use common ratios. (1) and (2) give 2 2 1 0 (2 1)( 1) 0 3 2 2 x x x x x x x = + --= + -= Divide by x (since 0 x ≠ ) and rearrange. = -x 1 2 or = 1 x Hence, = -x 1 2 and = -y 1 8 . 1 x ≠ since x 0 < . b = -= ---    = -∞ ∞ S a r S 1 1 2 1 1 2 1 3 Use = -a 1 2 and = -r 1 2 . c 2 [2 ( 1) ] 20 2 1 19 3 8 61.25 20 = + -= -+           = S n a n d S n Use 20 n = , = -a 1 2 , = ---    = d 1 8 1 2 3 8 . Factorise and solve.
```

## DID YOU KNOW?

Georg Cantor (1845-1918) was a German mathematician who is famous for his work on set theory and for formalising many ideas about infinity. He developed the theory that there are infinite sets of different sizes. He showed that the set of natural numbers (1, 2, 3, ...) and the set of rational numbers (all fractions) are actually the same size, whereas the set of real numbers is actually larger than either of them.

## EXERCISE 6F

- 1 Th e first term of a progression is 16 and the second term is 24. Find the sum of the first eight terms given that the progression is:
- a arithmetic

b

geometric

- 2 The first term of a progression is 20 and the second term is 16.
- a Given that the progression is geometric, find the sum to infinity.
- b Given that the progression is arithmetic, find the number of terms in the progression if the sum of all the terms is 160 -.
- 3 The first, second and third terms of a geometric progression are the first, fourth and tenth terms, respectively, of an arithmetic progression. Given that the first term in each progression is 12 and the common ratio of the geometric progression is r , where 1 r ≠ , find:
- a the value of r
- b the sixth term of each progression.
- 4 A geometric progression has eight terms. The first term is 256 and the common ratio is 1 .
- An arithmetic progression has 51 terms and common difference 2
- 2 1 .
- The sum of all the terms in the geometric progression is equal to the sum of all the terms in the arithmetic progression. Find the first term and the last term in the arithmetic progression.
- 5 The first, second and third terms of a geometric progression are the first, sixth and ninth terms, respectively, of an arithmetic progression. Given that the first term in each progression is 100 and the common ratio of the geometric progression is r , where 1 r ≠ , find:
- a the value of r
- b the fifth term of each progression.
- 6 The first term of an arithmetic progression is 16 and the sum of the first 20 terms is 1080.
- a Find the common difference of this progression.
- The first, third and th n terms of this arithmetic progression are the first, second and third terms, respectively, of a geometric progression.
- b Find the common ratio of the geometric progression and the value of n .
- 7 The first term of a progression is 2 x and the second term is 2 x .
- a For the case where the progression is arithmetic with a common difference of 15, find the two possible values of x and corresponding values of the third term.
- b For the case where the progression is geometric with a third term of -1 16 , find the sum to infinity.

181

182

## Checklist of learning and understanding

## Binomial expansions

Binomial coef ficients, denoted by  C n r or       n r , can be found using:

- /uni25CF Pascal's triangle

$$\bullet \text{ the formulae} \, \left ( \begin{array} { c } n \\ r \end{array} \right ) = \frac { n! } { r! ( n - r )! } \text{ or } \left ( \begin{array} { c } n \\ r \end{array} \right ) = \frac { n \times ( n - 1 ) \times ( n - 2 ) \times \cdots \times ( n - r + 1 ) } { r \times ( r - 1 ) \times ( r - 2 ) \times \cdots \times 3 \times 2 \times 1 }.$$

If n is a positive integer, the Binomial theorem states that:

$$\Sigma ( 1 + x ) ^ { n } = \left ( \begin{array} { c } n \\ 0 \end{array} \right ) + \left ( \begin{array} { c } n \\ 1 \end{array} \right ) x + \left ( \begin{array} { c } n \\ 2 \end{array} \right ) x ^ { 2 } + \dots + \left ( \begin{array} { c } n \\ n \end{array} \right ) x ^ { n }, \text{ where the } ( r + 1 ) t h \text{ term} = \left ( \begin{array} { c } n \\ r \end{array} \right ) x ^ { r }.$$

We can extend this rule to give:

$$( a + b ) ^ { n } = \left ( \begin{array} { c } n \\ 0 \end{array} \right ) a ^ { n } + \left ( \begin{array} { c } n \\ 1 \end{array} \right ) a ^ { n - 1 } b ^ { 1 } + \left ( \begin{array} { c } n \\ 2 \end{array} \right ) a ^ { n - 2 } b ^ { 2 } + \dots + \left ( \begin{array} { c } n \\ n \end{array} \right ) b ^ { n }, \, \text{where the } ( r + 1 ) \text{th term} = \left ( \begin{array} { c } n \\ r \end{array} \right ) a ^ { n - r } b ^ { r }.$$

We can also write the expansion of  (1 ) + x n as:

$$( 1 + x ) ^ { n } = 1 + n x + \frac { n ( n - 1 ) } { 2! } \, x ^ { 2 } + \frac { n ( n - 1 ) ( n - 2 ) } { 3! } \, x ^ { 3 } + \dots + x ^ { n }$$

## Arithmetic series

For an arithmetic progression with first term a , common difference d and n terms:

- /uni25CF the + -th term is ( 1) k a k d
- /uni25CF the = + -last term is ( 1) l a n d
- /uni25CF the = + = + -sum of the terms is 2 ( ) 2 [2 ( 1) ] S n a l n a n d n .

## Geometric series

For a geometric progression with first term a , common ratio r and n terms:

- /uni25CF the -k ar k th term is 1
- /uni25CF the -ar n last term is 1
- /uni25CF = --= --sum of the terms is (1 ) 1 ( 1) 1 S a r r a r r n n n .

The condition for an infinite geometric series to converge is r 1 1 &lt; &lt; -.

When an infinite geometric series converges, S a r 1 = -∞ .

## END-OF-CHAPTER REVIEW EXERCISE 6

| 1   | Find the coef ficient of 2 x in the expansion of 2 3 2 5 x +     .                                                                         | [3]   |
|-----|------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| 2   | In the expansion of ( 2 ) 6 a x + , the coefficient of x is equal to the coefficient of 2 x . Find the value of the constant a .               | [3]   |
| 3   | In the expansion of 1 (5 ) 6 x a x -       + , the coefficient of 2 x is zero. Find the value of a .                                     | [3]   |
| 4   | Find the term independent of x in the expansion of -     3 2 5 6 x x .                                                                     | [3]   |
| 5   | In the expansion of (2 ) 7 ax + , where a is a constant, the coefficient of x is 2240 - . Find the coefficient of 2 x .                        | [4]   |
| 6   | Find the coefficient of 5 x in the expansion of 2 3 2 x x +     .                                                                          | [4]   |
| 7   | Find the term independent of x in the expansion of 3 1 2 2 3 5 x x -     .                                                                 | [4]   |
| 8   | a Find the first three terms in the expansion of ( 3 ) 2 8 x x - , in descending powers of x .                                                 | [3]   |
|     | b Find the coefficient of 15 x in the expansion of (1 )( 3 ) 2 8 x x x - - .                                                                   | [2]   |
| 9   | a Find the first three terms in the expansion of (1 ) 8 px + , in ascending powers of x .                                                      | [3]   |
|     | b Given that the coefficient of 2 x in the expansion of (1 2 )(1 ) 8 x px - + is 204, find the possible values of p .                          | [4]   |
| 10  | a Find the first three terms, in ascending powers of x , in the expansion of:                                                                  |       |
|     | i (1 2 ) 5 x +                                                                                                                                 | [2]   |
|     | ii (3 ) 5 x -                                                                                                                                  | [2]   |
|     | b Find the coefficient of 2 x in the expansion of [(1 2 )(3 )] 5 x x + - .                                                                     | [3]   |
| 11  | The first term of an arithmetic progression is 1.75 and the second term is 1.5. The sum of the first n terms is n - . Find the value of n .    | [4]   |
| 12  | The second term of a geometric progression is 1458 - and the fifth term is 432. Find:                                                          |       |
|     | a the common ratio                                                                                                                             | [3]   |
|     | b the first term                                                                                                                               | [1]   |
|     | c the sum to infinity.                                                                                                                         | [2]   |
| 13  | An arithmetic progression has first term a and common difference d . The sum of the first 100 terms is 25 times the sum of the first 20 terms. |       |
|     | a Find d in terms of a .                                                                                                                       | [3]   |
|     | b Write down an expression, in terms of a , for the 50th term.                                                                                 | [2]   |
| 14  | The tenth term of an arithmetic progression is 17 and the sum of the first five terms is 190.                                                  |       |
|     | a Find the first term of the progression and the common difference.                                                                            | [4]   |
|     | b Given that the th n term of the progression is 19 - , find the value of n .                                                                  | [2]   |

183

184

- 15 a The fifth term of an arithmetic progression is 18 and the sum of the first eight terms is 186. Find the first term and the common difference.

[4]

- b The first term of a geometric progression is 32 and the fourth term is 1 2 . Find the sum to infinity of the progression. [3]
- 16 a The seventh term of an arithmetic progression is 19 and the sum of the first twelve terms is 224. Find the fourth term.

[4]

- b A geometric progression has first term 3 and common ratio r . A second geometric progression has first term 2 and common ratio 1 5 r . The two progressions have the same sum to in finity, S . Find the value of r and the value of S .
- 17 a A geometric progression has first term a , common ratio r and sum to infinity S .
- A second geometric progression has first term 5 a , common ratio 3 r and sum to infinity 10 S . Find the value of r .
- b An arithmetic progression has first term 4 -. The th n term is 8 and the (2 )th n term is 20.8. Find the value of n .
- 18 A television quiz show takes place every day. On day 1 the prize money is $1000. If this is not won the prize money is increased for day 2. The prize money is increased in a similar way every day until it is won. The television company considered the following two different models for increasing the prize money.
- Model 1: Increase the prize money by $1000 each day.

Model 2: Increase the prize money by 10% each day.

On each day that the prize money is not won the television company makes a donation to charity. The amount donated is 5% of the value of the prize on that day. After 40 days the prize money has still not been won. Calculate the total amount donated to charity

- i if Model 1 is used,
- ii if Model 2 is used.

[3]

[3]

[4]

[4]

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 June 2011

- 19  a The first two terms of an arithmetic progression are 1 and x cos 2 respectively. Show that the sum of the first ten terms can be expressed in the form -a b x sin , 2 where a and b are constants to be found. [3]
- b The first two terms of a geometric progression are 1 and θ 1 3 tan 2 respectively, where θ π 0 1 2 &lt; &lt; .
- i Find the set of values of θ for which the progression is convergent. [2]
- ii Find the exact value of the sum to infinity when θ = π 1 6
- . [2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 June 2012

- 20 The first term of a progression is 4 x and the second term is 2 x .
- i For the case where the progression is arithmetic with a common difference of 12, find the possible values of x and the corresponding values of the third term.

[4]

- ii For the case where the progression is geometric with a sum to infinity of 8, find the third term.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 November 2015

- 21  a The third and fourth terms of a geometric progression are 1 3 and 2 9 respectively. Find the sum to infinity of the progression.

[4]

- b A circle is divided into 5 sectors in such a way that the angles of the sectors are in arithmetic progression. Given that the angle of the largest sector is 4 times the angle of the smallest sector, find the angle of the largest sector.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 June 2015

- 22  a In an arithmetic progression the sum of the first ten terms is 400 and the sum of the next ten terms is 1000. Find the common difference and the first term.

[5]

- b A geometric progression has first term a , common ratio r and sum to infinity 6. A second geometric progression has first term 2 a , common ratio 2 r and sum to infinity 7. Find the values of a and r .

[5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 November 2013

185

186

## CROSS-TOPIC REVIEW EXERCISE 2

| 1   | Find the highest power of x in the expansion of + + - -     (5 3) (1 3 ) (4 5 ) 4 8 3 5 2 5 6 4 x x x x .                                                                                                                                                                                                  | [2]      |
|-----|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
| 2   | Find the term independent of x in the expansion of x x 4 1 2 -       .                                                                                                                                                                                                                                   | [3]      |
| 3   | a Find the first three terms in the expansion of x x 3 2 2 6 -       , in descending powers of x .                                                                                                                                                                                                       | [3]      |
|     | b Hence, find the coefficient of 2 x in the expansion of x x x 1 2 3 2 +       -       .                                                                                                                                                                                                           | [2]      |
| 4   | a Find the first three terms when (1 2 ) 5 - x is expanded, in ascending powers of x .                                                                                                                                                                                                                         | [3]      |
| 5   | Find the value of a .                                                                                                                                                                                                                                                                                          | [2]      |
|     | The first term of a geometric progression is 50 and the second term is 40 - . a Find the fourth term.                                                                                                                                                                                                          | [3]      |
| 6   | The first three terms of a geometric progression are 3 14, 14 + + k k and k , respectively. All the terms in the progression are positive. a Find the value of k .                                                                                                                                             | [3]      |
| 7   | b Find the sum to infinity. The sum of the 1st and 2nd terms of a geometric progression is 50 and the sum of the 2nd and 3rd terms is 30. Find the sum to infinity. Cambridge International AS & A Level Mathematics 9709 Paper 11 Q5 November                                                                 | [2] 2016 |
| 8   | i Show that ≡ - + x x x cos 1 2sin sin 4 2 4 . find this stationary value of A .                                                                                                                                                                                                                               | [6] [1]  |
|     | ii Hence, or otherwise, solve the equation + = x x x 8sin cos 2cos 4 4 2 for 0 360 ° ° < < x . Cambridge International AS & A Level Mathematics 9709 Paper 11 Q6 November Asector of a circle, radius r cm, has a perimeter of 60cm. a Show that the area, A cm 2 , of the sector is given by 30 2 = - A r r . | [5]      |
|     | Express 30 2 - r r in the form ( ) 2 - - a r b , where a and b are that r can vary:                                                                                                                                                                                                                            | 2016     |
| 9   |                                                                                                                                                                                                                                                                                                                | [2]      |
|     | b constants.                                                                                                                                                                                                                                                                                                   | [2]      |
|     | Given                                                                                                                                                                                                                                                                                                          |          |
|     | c find the value of r at which A is a maximum                                                                                                                                                                                                                                                                  |          |
|     | d                                                                                                                                                                                                                                                                                                              | [1]      |
|     |                                                                                                                                                                                                                                                                                                                | [1]      |

10

11

<!-- image -->

x

The diagram shows a metal plate consisting of a rectangle with sides cm x and  cm r and two identical sectors of a circle of radius  cm r . The perimeter of the plate is 100 cm.

- a Show that the area, cm 2 A , of the plate is given by 50 2 = -A r r
- . [2]
- b Express 50 2 -r r in the form ( ) 2 --a r b , where a and b
- are constants. [2]

Given that r can vary:

- c find the value of r at which A is a maximum

[1]

- . [1]
- d find this stationary value of A

<!-- image -->

The diagram shows a running track. The track has a perimeter of 400 m and consists of two straight sections of length  m l and two semicircular sections of radius  m r .

- a Show that the area, m 2 A , of the region enclosed by the track is given by = -π A r r 400 2 . [2]
- b Express - π 400 2 r r in the form π - π -π     2 a r b , where a and b are constants. [3]

Given that l and r can vary:

- c show that A has a maximum value when 0 = l

[2]

- . [1]
- d find this stationary value of A

187

188

<!-- image -->

12

- 13

The image depicts a geometric figure consisting of a circle, a line segment, and a point labeled as "p". The circle is positioned at the center of the image, and the line segment is positioned on the circumference of the circle. The point labeled as "p" is located on the line segment.

### Description of the Figure:
- **Circle**: The circle is a circle with a diameter of 8 units.
- **Line Segment**: The line segment is labeled as "p".
- **Point**: The point labeled as "p" is located on the line segment.

### Analysis:
1. **Circle**: The circle is a circle with a diameter of 8 units.
2. **Line Segment**: The line segment is labeled as "p".
3. **Point**: The point labeled as "p" is located on the line segment.

### Geometric Properties:
- **Diameter**: The diameter

<!-- image -->

The diagram shows two circles, 1 C and 2 C , touching at the point T . Circle 1 C has centre P and radius 8cm; circle 2 C has centre Q and radius 2 cm. Points R and S lie on 1 C and 2 C respectively, and RS is a tangent to both circles.

- i Show that = 8cm RS .
- ii Find angle RPQ in radians correct to 4 significant figures.

[2]

[2]

- iii Find the area of the shaded region.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 November 2010

<!-- image -->

In the diagram, OAB is an isosceles triangle with = OA OB and angle 2 θ = AOB radians. Arc PST has centre O and radius r , and the line ASB is a tangent to the arc PST at S .

- i Find the total area of the shaded regions in terms of r and θ .

[4]

- ii In the case where θ = π 1 3 and 6 = r , find the total perimeter of the shaded regions, leaving your answer in terms of 3 and π .

[5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 June 2011

- 14 The function f is such that = -x x x f( ) 2sin 3cos 2 2 for π 0 &lt; &lt; x .
- i Express  f( ) x in the form a b x cos 2 , stating the values of a and b
+ . [2]
- ii State the greatest and least values of  f( ) x .

[2]

- iii Solve the equation  f( ) 1 0 + = x .

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 June 2010

- 15 i Prove the identity θ -≡ sin 1 1
- . [4]
- .
- θ θ θ -1 cos sin tan ii θ θ θ -sin 1 cos 1 sin
- Hence solve the equation θ -= 4tan for  0 180 θ ° ° , ,

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 June 2014

- 16 The function f is defined by /arrowbarright -x x f : 4sin 1 for -π π x 1 2 1 2 &lt; &lt; .
- i State the range of f.

[2]

- ii Find the coordinates of the points at which the curve f( ) = y x intersects the coordinate axes. [3]
- iii Sketch the graph of f( ) = y x .

[2]

- 1 --1
- iv Obtain an expression for  f ( ) x , stating both the domain and range of f . [4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 June 2016

- 17 a The first term of a geometric progression in which all the terms are positive is 50. The third term is 32. Find the sum to infinity of the progression. [3]
- b The first three terms of an arithmetic progression are x 2sin , x 3cos and + x x (sin 2cos )  respectively, where x is an acute angle.
- i Show that = x tan 4 3 .

[3]

- ii
- Find the sum of the first twenty terms of the progression. [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 June 2016

189

In this image we can see a wave. In the background there is a sea and a hill.

<!-- image -->

190

## Chapter   7 Diff   erentiation

## In this chapter you will learn how to:

- ■ understand that the gradient of a curve at a point is the limit of the gradients of a suitable sequence of chords
- ■ use the derivative of x n (for any rational n ), together with constant multiples, sums, differences of functions, and of composite functions using the chain rule
- ■ use the notations f ( ) x ′ ,  f ( ) x ′′ , d d y x and d d 2 2 y x f or the fi  rst and second derivatives
- ■ apply differentiation to gradients, tangents and normals.

In this image, we can see a watermark.

<!-- image -->

## PREREQUISITE KNOWLEDGE

| Where it comes from        | What you should be able to do                                                    | Check your skills                                                                                |
|----------------------------|----------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Use the rules of indices to simplify expressions to the form ax n .              | 1 Write in the form ax n : a x x 3 b 5 2 3 x c x x 2 d x 1 2 e 3 2 x f - x x 2 5 2 3             |
| IGCSE / OLevel Mathematics | Write k ax b n + ( ) in the form k ax b n + - ( ) .                              | 2 Write in the form + - ( ) k ax b n : a x - 4 ( 2) 3 b x + 2 (3 1) 5                            |
| Chapter 3                  | Find the gradient of a perpendicular line.                                       | 3 The gradient of a line is 2 3 . Write down the gradient of a line that is perpendicular to it. |
| Chapter 3                  | Find the equation of a line with a given gradient and a given point on the line. | 4 Find the equation of the line with gradient 2 that passes through the point (2, 5).            |

## Why do we study differentiation?

Calculus is the mathematical study of change. Calculus has two basic tools, differentiation and integration, and it has widespread uses in science, medicine, engineering and economics. A few examples where calculus is used are:

- /uni25CF designing effective aircraft wings
- /uni25CF the study of radioactive decay
- /uni25CF the study of population change
- /uni25CF modelling the financial world.

In this chapter you will be studying the first of the two basic tools of calculus. You will learn the rules of differentiation and how to apply these to problems involving gradients, tangents and normals. In Chapter 8 you will then learn how to apply these rules of differentiation to more practical problems.

## 7.1  Derivatives and gradient functions

At IGCSE / O Level you learnt how to estimate the gradient of a curve at a point by drawing a suitable tangent and then calculating the gradient of the tangent. This method only gives an approximate answer (because of the inaccuracy of drawing the tangent) and it is also very time consuming.

In this chapter you will learn a method for finding the exact gradient of the graph of a function (which does not involve drawing the graph). This exact method is called differentiation .

<!-- image -->

## WEB LINK

Try the Calculus resources on the Underground Mathematics website.

191

192

## EXPLORE 7.1

Consider the quadratic function 2 y x = and a point ( , ) 2 P x x on the curve.

- 1 Let P be the point (2, 4).

The points (2.2, 4.84) A , (2.1, 4.41) B and (2.01, 4.0401) C also lie on the curve and are close to the point (2, 4) P .

- a Calculate the gradient of:
- i the chord PA
- ii the chord PB
- iii the chord PC .
- b Discuss your results with those of your classmates and make suggestions as to what is happening.
- c Suggest a value for the gradient of the curve 2 y x = at the point (2, 4).
- 2 Let P be the point (3, 9).

The points (3.2, 10.24) A , (3.1, 9.61) B and (3.01, 9.0601) C also lie on the curve and are close to the point (3, 9) P .

- a Calculate the gradient of:
- i the chord PA
- ii the chord PB
- iii the chord PC .
- b Discuss your results with those of your classmates and make suggestions as to what is happening.
- c Suggest a value for the gradient of the curve 2 y x = at the point (3, 9).
- 3 Use a spreadsheet to investigate the value of the gradient at other points on the curve 2 y x = .
- 4 Can you suggest a general formula for the gradient of the curve 2 y x = at the point ( , ) 2 a a ? What would be the gradient at ( , ) 2 x x ?

The general formula for the gradient of the curve = at the point ( , ) 2 2 y x x x can be proved algebraically.

<!-- image -->

Take a point ( , ) P x y on the curve 2 y x = and a point A that is close to the point P .

<!-- image -->

The coordinates of A are + δ + δ x x y y ( , ), where δ x is a small increase in the value of x and δ y is the corresponding small increase in the value of y .

## WEB LINK

There are other ways of thinking about the gradient of a curve. Try the following resources on the Underground Mathematics website Zooming in and Mapping a derivative .

<!-- image -->

We can also write the coordinates of P and A as ( , ) 2 x x and ( ) ( ) + δ + δ x x x x , . 2

-y y

$$\begin{array} { l l } \text{We can also write the coordinates of $P$ and $A$ as $(x,x)$} \colon \\ \\ \text{Gradient of chord $PA$} & = \frac { y _ { 2 } - y _ { 1 } } { x _ { 2 } - x _ { 1 } } \\ & = \frac { \left ( x + \delta x \right ) ^ { 2 } - x ^ { 2 } } { \left ( x + \delta x \right ) - x } \\ & = \frac { x ^ { 2 } + 2 x \delta x + \left ( \delta x \right ) ^ { 2 } - x ^ { 2 } } { \delta x } \\ & = \frac { 2 x \delta x + \left ( \delta x \right ) ^ { 2 } } { \delta x } \\ & = 2 x + \delta x \\ \\ \text{As $dx$ tends towards $0$} \,. \, A$ tends to $P$ and the gradient of} \end{array}$$

As δ x tends towards 0, A tends to P and the gradient of the chord PA tends to a value. We call this value the gradient of the curve at P .

In this case, therefore, the gradient of the curve at P is 2 x .

This process o f finding the gradient of a curve at any point is called differentiation.

Later in this chapter, you will learn some rules for differentiating functions without having to calculate the gradients of chords as we have done here. The process of calculating gradients using the limit of gradients of chords is sometimes called differentiation fro m first principles .

## Notation

There are three different notations that are used to describe the previous rule.

$$1. \text{ If } y = x ^ { 2 }, \text{ then } \frac { d y } { d x } = 2 x.$$

2. If = f( ) 2 x x , then  f ( ) 2 x x ′ = .

$$3. \ \frac { d } { d x } \left ( x ^ { 2 } \right ) = 2 x$$

If y is a function of x , then d y is called the derivative of y with respect to x d x . Likewise ′ f ( ) x is called the derivative of f( x ).

If = f( ) y x is the graph of a function, then d d y x or ′ f ( ) x is sometimes also called the gradient function of this curve.

d d ( ) 2 2 x x x = means 'if we differentiate 2 x with respect to x , the result is x 2 '.

You do not need to be able to differentiate from first principles but you are expected to understand that the gradient of a curve at a point is the limit of a suitable sequence of chords.

## EXPLORE 7.2

- 1 Use a spreadsheet to investigate the gradient of the curve 3 y x = .
- 2 Can you suggest a general formula for the gradient of the curve 3 y x = at the point ( , ) 3 x x ?
- 3 Differentiate 3 y x = fro m first principles to confirm your answer to question 2 .

<!-- image -->

## TIP

We use the Greek symbol delta, δ , to denote a very small change in a quantity.

<!-- image -->

## DID YOU KNOW?

Gottfried Wilhelm Leibniz and Isaac Newton are both credited with developing the modern calculus that we use today. Leibniz's notation for derivatives

was d d y x . Newton's notation for d d y x was y /dotnosp . The notation f ( ) x ′ is known as

Lagrange's notation.

193

194

## Differentiation of power functions

$$\text{We now know that } \frac { d } { d x } ^ { \bullet } ( x ^ { 2 } ) = 2 x \text{ and that } \frac { d } { d x } \left ( x ^ { 3 } \right ) = 3 x ^ { 2 }. \\. \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \colon \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \cdot \, \epsilon.$$

Investigating the gradient of the curves , 4 5 y x y x = = and 6 y x = would give the results:

$$\frac { d } { d x } \left ( x ^ { 4 } \right ) = 4 x ^ { 3 } \quad \ \frac { d } { d x } \left ( x ^ { 5 } \right ) = 5 x ^ { 4 } \quad \ \frac { d } { d x } \left ( x ^ { 6 } \right ) = 6 x ^ { 5 }$$

This leads to the general rule for differentiating power functions:

## KEY POINT 7.1

$$\frac { d } { d x } \left ( x ^ { n } \right ) = n x ^ { n - 1 }$$

This is true for any real power n , not only for positive integer values of n .

You ma y find it easier to remember this rule as:

'Multiply by the power n and then subtract one from the power.'

$$\begin{array} { c } \text{numpy} \, \text{y} \, \text{in power} \, n \, \text{and} \, \text{in source} \, \text{in} \\ \text{So for the earlier example where} \, \text{y} & = x ^ { 2 } \colon \\ \frac { d y } { d x } & = 2 \times x ^ { 2 - 1 } \\ & = 2 x ^ { 1 } \\ & = 2 x \\ \end{array}$$

## WORKED EXAMPLE 7.1

Find the derivative of each of the following. a 7 x b 1 2 x c f( ) x x = d 2 y = Answer a = = -x x x x d d ( ) 7 7 7 7 1 6 Multiply by the power 7 and then subtract one from the power. b     = = -= -= -----x x x x x x x d d 1 d d ( ) 2 2 2 2 2 2 1 3 3 Write 1 2 x as x -2 . Multiply by the power -2 and then subtract one from the power. c = = ′ = = = --x x x x x x x x f( ) f( ) f ( ) 1 2 1 2 1 2 1 2 1 2 1 1 2 Write x as 1 2 x . Multiply by the power 1 2 and then subtract one from the power.

d = = = = -y y x y x x 2 2 d d 0 0 0 0 1 Write 2 as 2 0 x . Multiply by the power and then subtract one from the power.

You need to know and be able to use the following two rules.

## Scalar multiple rule

If k is a constant and f( ) x is a function then:

## KEY POINT 7.2

$$\Big | \ \frac { d } { d x } \left [ k \mathfrak { f } ( x ) \right ] = k \, \frac { d } { d x } \left [ \mathfrak { f } ( x ) \right ]$$

## Addition/subtraction rule

If f( ) x and g( ) x are functions then

## KEY POINT 7.3

$$\Big | \ \frac { d } { d x } \left [ f ( x ) \pm g ( x ) \right ] = \frac { d } { d x } \left [ f ( x ) \right ] \pm \frac { d } { d x } \left [ g ( x ) \right ]$$

## WORKED EXAMPLE 7.2

Differentiate  3 1 2 4 5 4 2 x x x -+ + with respect to x .

Answer

$$\begin{array} { c } \text{Answer} \\ \frac { d } { d x$$

## TIP

It is worth remembering that when you differentiate a constant, the answer is always 0.

195

196

## WORKED EXAMPLE 7.3

Find the gradient of the tangent to the curve (2 1)( 3) y x x x = -+ at the point (1, 4). Answer = -+ = + -= + -= = + -(2 1)( 3) 2 5 3 d d 6 10 3 When 1, d d 6(1) 10(1) 3 3 2 2 2 y x x x y x x x y x x x x y x Expand brackets and simplify. Gradient of curve at (1, 4) is 13. = d 13 x

## WORKED EXAMPLE 7.4

The curve 4 2 y ax bx x = + + has gradient 3 when 1 x = and gradient -51 when 2. x = -Find the value of a and the value of b . Answer = + + = + + d d 4 2 1 4 2 3 y ax bx x y x ax bx Since = d d 3 y x when = x 1: + + = + = + = 4 (1) 2 (1) 1 3 4 2 2 2 1 3 a b a b a b (1) Since = -d d 51 y x when = -x 2: -+ -+ = ---= -+ = 4 ( 2) 2 ( 2) 1 51 32 4 52 8 13 3 a b a b a b (2) -(2) (1)  gives Substitute = 2 a into (1): + = ∴ = -4 1 3 b b = ∴ = a a 6 12 2

## EXERCISE 7A

- 1 The points A (0, 0), B (0.5, 0.75), C (0.8, 1.44), D (0.95, 1.8525), E (0.99, 1.9701) and F (1, 2) lie on the curve = f( ) y x .
- a Copy and complete the table to show the gradients of the chords CF , DF and EF .
- b Use the values in the table to predict the value of d d y x when = 1 x .
- 2 By considering the gradient of a suitable sequence of chords , find a value for the gradient of the curve at the given point.

| Chord    |   AF |   BF | CF   | DF   | EF   |
|----------|------|------|------|------|------|
| Gradient |    2 |  2.5 |      |      |      |

$$\lambda _ { \ } y & = x ^ { 4 } \, \text{at} \$$

- 3 Differentiate with respect to x :

$$\begin{array} {$$

- 4 Find f ( ) x ′ for each of the following.

$$\begin{array} { l$$

- 5 Find d d y x for each of the following.

$$\begin{array} {$$

- 6 Find the value of d d y x for each curve at the given point.
- a 4 2 y x x = + -at the point (1, 2) -b 5 2 y x = -at the point (2, 4) -
- c = 3 2 2 y x x at the point ( 2, 2) --
- 7 Find the gradient of the curve (2 5)( 4) y x x = -+ at the point (3, 7) .
- 8 Given that 12 xy = , find the value of d d y x when 2. x =
- 9 Find the gradient of the curve 5 8 3 2 y x x = -+ at the point where the curve crosses the y -axis.

198

- 10 Find the coordinates of the points on the curve 3 8 3 y x x = --where the gradient is 9.
- 11 Find the gradient of the curve = -5 10 2 y x x at the point where the curve crosses the x -axis.
- 12 The curve = --4 5 2 y x x and the line = -1 3 y x meet at the points A and B .
- a Find the coordinates of the points A and B .
- b Find the gradient of the curve at each of the points A and B .
- 13 The gradient of the curve 2 y ax bx = + at the point (3, 3) -is 5. Find the value of a and the value of b .
- 14 The gradient of the curve 7 3 2 y x ax bx = + + + at the point (1, 5) is 5 -. Find the value of a and the value of b .
- 15 The curve = + 2 y ax b x has gradient 16 when 1 x = and gradient 8 -when 1. x = -Find the value of a and the value of b .
- 16 Given that the gradient of the curve 3 3 2 y x ax bx = + + + is zero when 1 x = and when 6, x = find the value of a and the value of b .
- 17 Given that 2 3 36 5 3 2 y x x x = --+ , find the range of values of x for which y x d d 0. ,
- 18 Given that 4 3 6 9 3 2 y x x x = + --, find the range of values of x for which d d 0. y x &gt;
- 19 A curve has equation 3 6 4 5. 3 2 y x x x = + + -Show that the gradient of the curve is never negative.

## 7.2  The chain rule

To differentiate (3 2) 7 y x = -, we could expand the brackets and then differentiate each term separately. This would take a long time to do. There is a more efficient method available that allows us to find the derivative without expanding.

Let 3 2 u x = -, then (3 2) 7 y x = -becomes 7 y u = .

This means that y has changed from a function in terms of x to a function in terms of u .

We can find the derivative of the composite function (3 2) 7 y x = -using the chain rule :

## KEY POINT 7.4

= × d d d d d d y x y u u x

<!-- image -->

## WEB LINK

Try the following resources on the Underground

Mathematics website:

- Slippery slopes
- Gradient match.

<!-- image -->

## WEB LINK

Try the Chain mapping resource on the Underground Mathematics website.

## WORKED EXAMPLE 7.5

```
Find the derivative of (3 2) 7 y x = -. Answer = -(3 2) 7 y x u x u x y x y u u x u x x = -= = × = × = -× = -Let 3 2 d d 3 d d d d d d 7 3 7(3 2) 3 21(3 2) 6 6 6 so and d d 7 7 6 y u y u u = = Use the chain rule.
```

With practice you will be able to do this mentally.

Consider the 'inside' of   (3 2) 7 x -to be   3 2. x -

To differentiate   (3 2) 7 x -:

Step 1 : Differentiate the 'outside': 7(3 2) 6 x -

Step 2

: Differentiate the 'inside': 3

Step 3 : Multiply these two expressions:  21(3 2) 6 x -

## WORKED EXAMPLE 7.6

```
Find the derivative of = + 2 (3 1) . 2 5 y x Answer = + = + = = = -= × = -× = -+ × = -+ ----2 (3 1) Let 3 1 so 2 d d 6 and d d 10 d d d d d d 10 6 10(3 1) 6 60 (3 1) 2 5 2 5 6 6 2 6 2 6 y x u x y u u x x y u u y x y u u x u x x x x x Use the chain rule.
```

200

Alternatively, to differentiate the expression mentally: Write 2 (3 1) 2 5 x + as   2(3 1) 2 5 x + -. Step 1 : Differentiate the 'outside': 10(3 1) 2 6 x -+ -Step 2 : Differentiate the 'inside': 6 x Step 3 : Multiply the two expressions: 60 (3 1) 60 (3 1) 2 6 2 6 x x x x -+ = -+ -

## WORKED EXAMPLE 7.7

The curve y ax b = + passes through the point (12, 4) and has gradient 1

```
4 at this point. Find the value of a and the value of b . Answer 4 12 ( ) 1 2 = + = + = + y ax b a b y ax b (1) Substitute 12 x = and 4 y = . Write ax b + in the form + ( ) 1 2 ax b . = + = = × = × = + = + = + -Let so d d d d d d d d 1 2 d d 2 1 4 2 12 2 12 1 2 u ax b u x a y x y u u x u a y x a ax b a a b a a b (2) Use the chain rule. Substitute 12 x = and d d 1 4 y x = . (1) and (2) give = = 2 4 2 a a Substituting = 2 a into (1) gives: = + = + = -4 24 16 24 8 b b b ∴ = = -2, 8 a b y u = 1 2 and y u u = -d d 1 2 1 2
```

## EXERCISE 7B

- 1 Differentiate with respect to x :
- a ( 4) 6 x
+ +
- b (2 3) 8 x
- e (5 2) 8 x -
- 4 f 5(2 1) 5 x -
- i ( 3) 2 5 x +

j

(2

)

2

8

x

-

- c (3 4 ) 5 x -
- g 2(4 7 ) 4 x -
- k ( 4 ) 2 3 x x +
- d 1 2 1 9 x +    
- h 1 5 (3 1) 7 x -
- l 5 2 5 x x -   
- 2 Differentiate with respect to x :
- a 1 2 x + b 3 5 x -c 8 3 2 x -d 16 2 2 x + e + 4 (3 1) 6 x f + 3 2(3 1) 5 x g + 8 2 2 x x h -7 (2 5 ) 2 7 x x
- 3 Differentiate with respect to x :
- a 5 x -
- b 2 3 x +
- e 5 2 3 x -

$$\mathfrak { c } \quad \sqrt { 2 x ^ { 2 } - 1 } \\ \mathfrak { g } \quad \frac { 1 } { \sqrt { 2 x - 5 } }$$

- f 2 3 1 x +
- 2 5 x -
- h -2 3 3 x
- 4 Find the gradient of the curve (2 3) 5 y x = -at the point (2, 1).
- 5 Find the gradient of the curve = -6 ( 1) 2 y x at the point where the curve crosses the y -axis.
- 6 Find the gradient of the curve 3 2 y x x = -+ at the points where the curve crosses the x -axis.
- 7 Find the coordinates of the point on the curve ( 10 26) 2 y x x = -+ where the gradient is 0.
- 8 The curve 1 y a bx = -passes through the point (2, 1) and has gradient -3 5 at this point. Find the value of a and the value of b .

## 7.3  Tangents and normals

<!-- image -->

The line perpendicular to the tangent at the point A is called the normal at A .

If the value of d d y x at the point A ( , ) 1 1 x y is m , then the equation of the tangent at A is given by:

## KEY POINT 7.5

-= -( ) 1 1 y y m x x

- d 5 3 x x -6

## TIP

We use the numerical form for m in this formula (not the derivative formula).

201

202

The normal at the point ( , ) 1 1 x y is perpendicular to the tangent, so the gradient of the normal is 1 -m and the equation of the normal is given by:

## KEY POINT 7.6

$$\Big | \ \ y - y _ { 1 } = - \frac { 1 } { m } \left ( x - x _ { 1 } \right )$$

This formula only makes sense when ≠ 0 m . If = 0 m , it means that the tangent is horizontal and the normal is vertical, so it has equation = 1 x x instead.

## WORKED EXAMPLE 7.8

Find the equation of the tangent and the normal to the curve = + -2 8 9 2 2 y x at the point where 2 x =

x . Answer 2 8 9 2 2 = + --y x x d d 4 16 3 y x x x = --When 2 = x , 2(2) 8(2) 9 1 2 2 = + -= -y and d d 4(2) 16(2) 6 3 = -= -y x Tangent: passes through the point (2, 1) and gradient 6 = 1 6( 2) 6 11 -= -= -y x y x Normal: passes through the point (2, 1) = -and gradient 1 6 -= --+ = y x x y 1 1 6 ( 2) 6 8

## WORKED EXAMPLE 7.9

A curve has equation ( ) = -4 3 y x .

The normal at the point (4, 8) P and the normal at the point (9, 1) Q intersect at the point R .

- a Find the coordinates of R .
- b Find the area of triangle PQR .

## Answer

$$\begin{array} { l l l } & & \text{Answer} \\ & & & & y = ( 4 - \sqrt { x } ) ^ { 3 } \\ & & & & \underline { d y } _ { \d x } = 3 ( 4 - \sqrt { x } ) ^ { 2 } \left ( - \frac { 1 } { 2 } x ^ { - \frac { 1 } { 2 } } \right ) = - \frac { 3 ( 4 - \sqrt { x } ) ^ { 2 } } { 2 \sqrt { x } } \\ & & & \text{When} \ x = 4, \frac { d y } { d x } = - \frac { 3 ( 4 - \sqrt { 4 } ) ^ { 2 } } { 2 \sqrt { 4 } } = - 3 \\ & & & \text{When} \ x = 9, \frac { d y } { d x } = - \frac { 3 ( 4 - \sqrt { 9 } ) ^ { 2 } } { 2 \sqrt { 9 } } = - \frac { 1 } { 2 } \\ & & & & & & & & \text{Copyright Material} \ - Review Only \ - Not for Re \end{array}$$

Copyright Material  - Review Only -  Not for Redistribution

Normal at

P

: passes through the point (4, 8) and gradient

1

3

=

$$y - 8 = \frac { 1 } { 3 } \\ y = x + 20 \dots$$

$$( 1 )$$

Normal at Q : passes through the point (9, 1) and gradient 2 =

$$y - 1 = 2 ( x - 9 ) \\ y = 2 x - 17 \c--- (2)$$

Solving equations (1) and (2) gives:

$$<_Scala_> (2.x - 17) = x + 20
            x = 14.2$$

When 14.2, 2(14.2) 17 11.4 = = -= x y

Hence, R is the point (14.2, 11.4).

<!-- image -->

x

Area of triangle area of rectangle sum of areas of outside triangles = -PQR

$$\stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \sim } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \end{ \quad } \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \strut \\ \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \textrel { \null } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel \null } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } \\ \, \stackrel { \null } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \null } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim    \, \stackrel { \null } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } & \, \stackrel { \null } { \sim } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \ null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \not } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \return } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \{ } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \sub } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \ undefined } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \null } & \, \stackrel { \$$

## EXERCISE 7C

- 1 Find the equation of the tangent to each curve at the given point.
- a 3 2 2 y x x at the point (3, 2)
- b (2 5) y x at the point (2, 1)
- c y = at the point ( 1, 6) -
- d 2 5 y x at the point (9, 4)
- 2 Find the equation of the normal to each curve at the given point.
- a 3 4 1 3 2 y x x x = + -+ at the point (0, 1)
- b = + 3 1 3 y x at the point ( 2, 3) --
- c (5 2 ) 3 y x = -at the point (3, 1) -
- d = + 20 1 2 y x at the point (3, 2)

```
= -+ 4 = -5 3 x x -= -
```

203

204

- 3 A curve passes through the point     2, 1 2 A and has equation = + 8 ( 2) 2 y x .
- a Find the equation of the tangent to the curve at the point A .
- b Find the equation of the normal to the curve at the point A .
- 4 The equation of a curve is 5 3 2 . 2 y x x = --
- a Show that the equation of the normal to the curve at the point ( 2, 3) -is 5 13. x y + =
- b Find the coordinates of the point at which the normal meets the curve again.
- 5 The normal to the curve 5 3 3 y x x = -+ at the point ( 1, 7) -intersects the y -axis at the point P .
- Find the coordinates of P .
- 6 The tangents to the curve 5 3 2 y x x = --at the points ( 1, 7) -and ( 4, 1) -meet at the point Q .
- Find the coordinates of Q .
- 7 The normal to the curve 4 2 y x = -at the point (16, 4) P -meets the x -axis at the point Q .
- a Find the equation of the normal PQ .
- b Find the coordinates of Q .
- 8 The equation of a curve is 2 10 8 2 y x x = -+ .
- b Show that the normal to the curve at the point --    4, 5 8 meets the y -axis at the point (0, 3) -.
- a Find d d y x .
- 9 The normal to the curve 6 2 y x = -at the point (3, 6) meets the x -axis at P and the y -axis at Q .
- Find the midpoint of PQ .
- 10 A curve has equation 8 16 5 3 y x x x = -+ . The normal at the point (1, 9) P and the tangent at the point ( 1, 9) Q --intersect at the point R .
- Find the coordinates of R .
- 11 A curve has equation ( ) = -+ y x 2 1 2 3 . The normal at the point (4, 4) P and the normal at the point (9, 18) Q intersect at the point R .
- a Find the coordinates of R .
- b Find the area of triangle PQR .
- 12 A curve has equation 3 12 y x = + and passes through the points (2, 12) A
- x and (6, 20) B . At each of the points C and D on the curve, the tangent is parallel to AB
- a Find the coordinates of the points C and D . Give your answer in exact form.
- b Find the equation of the perpendicular bisector of CD .

.

- 13 The curve ( 1)( 2) y x x x = -+ crosses the x -axis at the points (0, 0) O , (1, 0) A and ( 2, 0) B -. The normals to the curve at the points A and B meet at the point C . Find the coordinates of the point C .
- 14 A curve has equation 5 2 3 y x = -and passes through the points ( 1, 1) P -. Find the equation of the tangent to the curve at P an d find the angle that this tangent makes with the x -axis.
- 15 The curve 12 2 3 4 y x = --intersects the x -axis at P . The tangent to the curve at P intersects the y -axis at Q . Find the distance PQ .
- 16 The normal to the curve 2 3 2 y x kx = + -at the point (3, 6) -is parallel to the line 5 10. x y + =
- a Find the value of k .
- b Find the coordinates of the point where the normal meets the curve again.

## 7.4  Second derivatives

d d y x is called the first derivative of y with respect to x .

If we differentiate y with respect to x we obtain d d . y x

$$\begin{smallmatrix} \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Psi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi\Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phis \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \ Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi \Phi
 \end{smallmatrix}$$

$$\text{written as } \frac { d ^ { 2 } y } { d x ^ { 2 } }.$$

d d 2 2 y x is called the second derivative of y with respect to x .

$$a x ^ { - } \\ \text{So for } y & = x ^ { 3 } + 5 x ^ { 2 } - 3 x + 2 \quad \text{ or } \quad \text{ if} ( x ) = x ^ { 3 } + 5 x ^ { 2 } - 3 x + 2 \\ \frac { d y } { d x } & = 3 x ^ { 2 } + 1 0 x - 3 \quad \text{ or } \quad \text{ if} ( x ) = 3 x ^ { 2 } + 1 0 x - 3 \\ \frac { d ^ { 2 } y } { d x ^ { 2 } } & = 6 x + 1 0 \quad \text{ or } \quad \text{ if} ( x ) = 6 x + 1 0$$

## WORKED EXAMPLE 7.10

$$\Big | \ \ G i v e n \, \text{that } y = \frac { 5 } { ( 2 x - 3 ) ^ { 3 } }, \, \text{find } \frac { d ^ { 2 } y } { d x ^ { 2 } }.$$

$$\begin{array} { c } \text{Given that $y = \frac{5}{2x-3}$, find $\frac{d^2y}{d^2}$} \\ \end{array} \\ \text{Answer} \\ \quad y = 5(2x-3)-3 \\ \quad \text{d} \\ \quad \text{$d} = -15(2x-3)-4 \times 2 \\ \quad \quad = -30(2x-3)-4 \\ \quad \text{d}^2 \\ \quad \text{d}^2 = 120(2x-3)-5 \times 2 \\ \quad \quad = \frac{240}{2x-3}$}$$

<!-- image -->

## WEB LINK

Try the Tangent or normal resource on the Underground Mathematics website.

205

206

## WORKED EXAMPLE 7.11

A curve has equation = + -+ 3 9 2. 3 2 y x x x

- a Find the range of values of x for which d d y x and d d 2 2 y x are negative.
- b Show that ≠       d d d d . 2 2 2 y x y x

## Answer

$$a = x ^ { 3 } + 3 x ^ { 2 } - 9 x + 2 \\ d y = 3 x ^ { 2 } + 6 x - 9 \\ d x$$

$$<_Perl_> dy = < 0  when:     3x2 + 6x - 9 < 0
dx                       x2 + 2x - 3 < 0
                        (x + 3)(x - 1) < 0
                              -3 < x < 1                                                                                                                                                                                                        
                                                                                                                                                                                                        -3 < x < 1$$

d

2

y

d

=

+

6

6

2

x

x

$$<_Python_>    ...
    d2 y$$

Combining (1) and (2) on a number line:

$$- 4 \ - 3 \ - 2 \ - 1 \ 0 \ 1 \ 2$$

$$\Big | \quad b \frac { d ^ { 2 } y } { d x ^ { 2$$

$$<_Python_>    .: -3 < x < -1

  b$$

## EXERCISE 7D

- 1 Find d d 2 2 y x for each of the following functions.

$$\begin{array} {$$

- 2 Find ′′ f ( ) x for each of the following functions.

$$\text{$find t^{\prime}(x)$ for each of the following functions.} \\ \text{a} \quad \text{$f(x) = \frac{5}{x^2} - \frac{3}{2x^5}$} \quad \text{$b$} \quad \text{$f(x) = \frac{4x^2 - 3}{2x}$} \quad \text{$c$} \quad \text{$f(x) = \frac{2x - 3\sqrt{x}$} } { x^2} \\ \text{d} \quad \text{$f(x) = \sqrt{1-3x}$} \quad \text{$e$} \quad \text{$f(x) = x^2 \left ( \sqrt{x} - 3 \right ) } \quad \text{$f$} \quad \text{$f(x) = \frac{1 5}{\sqrt{2x+1}$} }$$

Copyright Material  - Review Only -  Not for Redistribution

<!-- image -->

- 3 Given that 4 (2 1) , 4 y x x = --find d d y x and d d 2 2 y x .
- 4 Given that  f( ) 2 3 1 3 2 x x x x = + --, find:
- a f(1)

$$b _ { \ } f ( 1 ) \, \quad \, \quad \, c _ { \ } f ^ { \prime \prime } ( 1 )$$

- 5 Given that x x ′ = -f ( ) 3 (2 1) 8 , find ′′ f ( ) x .
- 6 Given that  f( ) 2 1 2 x x = -, find the value of ′′ -f ( 4).
- 7 A curve has equation 2 21 60 5. 3 2 y x x x = -+ + Copy and complete the table to show whether d d y x and d d 2 2 y x are positive ( ) + , negative ( ) -or zero (0) for the given values of x .
- 8 A curve has equation 6 15 7. 3 2 y x x x = ---Find the range of values of x for which both d d y x and d d 2 2 y x are positive.
- 9 Given that 2 5 2 y x x = -+ , show that  4 d d ( 1) d d 2 . 2 2 y x x y x y + -=
- 10 Given that 4 y x = , show that + = 4 d d 4 d d . 2 2 2 x y x x y x y
- 11 A curve has equation 2 4 6 3 2 y x x x = + -+ .
- a Show that d d 0 y x = when 2  and when 2 3 x x = -= .
- b Find the value of d d 2 2 y x when 2  and when 2 3 x x = -= .
- 12 A curve has equation = + 2 y ax b x . Given that d d 0 y x = and
- = = d d 1 2 when 2, 2 2 y x x find the value of a and the value of b .

| x           | 0   | 1   | 2   | 3   | 4   | 5   | 6   | 7   |
|-------------|-----|-----|-----|-----|-----|-----|-----|-----|
| y x d d     |     |     |     |     |     |     |     |     |
| y x d d 2 2 |     |     |     |     |     |     |     |     |

## WEB LINK

Try the Gradients of gradients resource on the Underground Mathematics website.

208

## Checklist of learning and understanding

## Gradient of a curve

- /uni25CF d d y x represents the gradient of the curve = f( ) y x .

## The four rules of differentiation

- /uni25CF Power rule:
- /uni25CF Scalar multiple rule:
- /uni25CF Addition/subtraction rule:
- /uni25CF Chain rule:

$$\frac { d } { d x } \left ( x ^ { n } \right ) = n x ^ { n - 1 }$$

$$\frac { d } { d x } \left [ k \mathfrak { f } ( x ) \right ] = k \, \frac { d } { d x } \left [ \mathfrak { f } ( x ) \right ]$$

$$\text{le} \colon \quad \frac { d } { d x } \left [ \mathfrak { f } ( x ) \pm g ( x ) \right ] = \frac { d } { d x } \left [ \mathfrak { f } ( x ) \right ] \pm \frac { d } { d x } \left [ g ( x ) \right ]$$

$$\frac { d y } { d x } = \frac { d y } { d u } \times \frac { d u } { d x }$$

## Tangents and normals

If the value of d d y x at the point  ( , ) 1 1 x y is m , then:

- /uni25CF the equation of the tangent at that point is given by -= -( ) 1 1 y y m x x
- /uni25CF the equation of the normal at that point is given by -= --1 ( ) 1 1 y y m x x .

## Second derivatives

- /uni25CF     = d d d d d d 2 2 x y x y x

## END-OF-CHAPTER REVIEW EXERCISE 7

| 1   | Differentiate 3 7 4 5 x x - with respect to x .                                                                                                     | [3]   |
|-----|-----------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| 2   | Find the gradient of the curve 8 4 5 y x = - at the point where 2. x =                                                                              | [3]   |
| 3   | Acurve has equation 3 3 7. 3 2 y x x x = - + - Show that the gradient of the curve is never negative.                                               | [3]   |
| 4   | The equation of a curve is (3 5 ) 2 . 3 y x x = - - Find d d y x and d d 2 2 y x .                                                                  | [3]   |
| 5   | Find the gradient of the curve = - 15 2 2 y x x at the point where 5. x =                                                                           | [4]   |
| 6   | The normal to the curve 5 y x = at the point (4, 10) P meets the x -axis at the point Q .                                                           |       |
|     | a Find the equation of the normal PQ .                                                                                                              | [4]   |
|     | b Find the coordinates of Q .                                                                                                                       | [1]   |
| 7   | The equation of a curve is = + 5 12 2 y x x .                                                                                                       |       |
|     | a Find d d y x .                                                                                                                                    | [2]   |
|     | b Show that the normal to the curve at the point (2, 13) meets the x -axis at the point (28, 0).                                                    | [3]   |
| 8   | The normal to the curve 12 y x = at the point (9, 4) meets the x -axis at P and the y -axis at Q .                                                  |       |
|     | Find the length of PQ , correct to 3 significant figures.                                                                                           | [6]   |
|     | The curve ( 3)( 5) y x x x = - - crosses the x -axis at the points (0, 0) O , (3, 0) A and (5, 0) B . The tangents to the curve at the points A and |       |
|     | Find the coordinates of the point C .                                                                                                               |       |
| 9   | B meet at the point C .                                                                                                                             | [6]   |
| 10  | Acurve passes through the point (4, 2) A and has equation = - 2 ( 3) 2 y x .                                                                        |       |
|     | a Find the equation of the tangent to the curve at the point A .                                                                                    | [5]   |
|     | b Find the equation of the normal to the curve at the point A .                                                                                     | [2]   |
| 11  | Acurve passes through the point (5, 1) P and has equation 3 10 y x = - .                                                                            |       |
|     | a Show that the equation of the normal to the curve at the point P is 5 2 27. x y + =                                                               | [4]   |
|     | The normal meets the curve again at the point Q .                                                                                                   |       |
|     | b i Find the coordinates of Q .                                                                                                                     | [3]   |
|     | ii Find the midpoint of PQ .                                                                                                                        | [1]   |
| 12  | Acurve has equation 3 4 y x x = - and passes through the points (1, 1) A - and (4, 11) B .                                                          |       |
|     | At each of the points C and D on the curve, the tangent is parallel to AB . Find the equation of the perpendicular bisector of CD .                 | [7]   |

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 June 2016

209

210

13

- 15

<!-- image -->

The diagram shows part of the curve 2 18 2 3 , y x = -+ which crosses the x -axis at A and the y -axis at B .

The normal to the curve at A crosses the y -axis at C .

- i Show that the equation of the line AC is  9 4 27. x y + = [6]
- ii Find the length of BC .

[2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 June 2010

- 14 The equation of a curve is 3 4 2 y x x = + -.
- i Show that the equation of the normal to the curve at the point (3, 6) is  2 9 y x = + .

[4]

- ii Given that the normal meets the coordinate axes at points A and B , find the coordinates of the mid-point of AB . [2]
- iii Find the coordinates of the point at which the normal meets the curve again.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 November 2010

The image consists of a geometric figure with several lines and points. Here is a detailed description of the image:

### Description of the Image:
1. **Points and Lines**:
   - There are two lines labeled as \( y \) and \( x \).
   - The line \( y \) is drawn from point \( A \) to point \( B \).
   - The line \( x \) is drawn from point \( A \) to point \( C \).

2. **Geometric Figures**:
   - The figure consists of a triangle \( A \), a quadrilateral \( B \), and a parallelogram \( C \).
   - The parallelogram \( C \) is formed by two diagonals of the parallelogram \( B \).

3. **Geometric Properties**:
   - The line \( y \) is perpendicular to the line \( x \).

<!-- image -->

1

The diagram shows the curve (6 2) 3 y x = + and the point (1, 2) A which lies on the curve. The tangent to the curve at A cuts the y -axis at B and the normal to the curve at A cuts the x -axis at C .

- i Find the equation of the tangent AB and the equation of the normal AC
- . [5]
- ii Find the distance BC . [3]
- iii Find the coordinates of the point of intersection, E , of OA and BC , and determine whether E is the mid-point of OA .

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 November 2012

In this image we can see a few paint brushes.

<!-- image -->

211

## Chapter   8 Further diff  erentiation

## In this chapter you will learn how to:

- ■ apply differentiation to increasing and decreasing functions and rates of change
- ■ locate stationary points and determine their nature, and use information about stationary points when sketching graphs.

In this image we can see a bowl and a hammer.

<!-- image -->

212

## PREREQUISITE KNOWLEDGE

| Where it comes from   | What you should be able to do                  | Check your skills                                                                               |
|-----------------------|------------------------------------------------|-------------------------------------------------------------------------------------------------|
| Chapter 1             | Solve quadratic inequalities.                  | 1 Solve: a x x 2 3 0 2 - - . b x x 6 0 2 + - .                                                  |
| Chapter 7             | Find the first and second derivatives of x n . | 2 Find y x d d and y x d d 2 2 for the following. a y x x 3 2 2 = - + b y x 3 2 2 = c y x x 3 = |
| Chapter 7             | Differentiate composite functions.             | 3 Find y x d d for the following. a y x (2 1) 5 = - b y x 3 (1 3 ) 2 = -                        |

## Why do we study differentiation?

## FAST FORWARD

In Chapter 7, you learnt how to differentiate functions and how to use differentiation to find gradients, tangents and normals.

In this chapter you will build on this knowledge and learn how to apply differentiation to problems that involve finding when a function is increasing (or decreasing) or when a function is at a maximum (or minimum) value. You will also learn how to solve practical problems involving rates of change.

There are many situations in real life where these skills are needed. Some examples are:

- manufacturers of canned food and drinks needing to minimise the cost of their manufacturing by minimising the amount of metal required to make a can for a given volume
- economists might use these tools to advise a company on its pricing strategy
- doctors calculating the time interval when the concentration of a drug in the bloodstream is increasing
- scientists calculating the rate at which the area of an oil slick is increasing.

In the Mechanics Coursebook,

Chapter 6 you will learn to apply these skills to problems concerning displacement, velocity and time.

<!-- image -->

## WEB LINK

Explore the Calculus meets functions station on the Underground Mathematics website.

## EXPLORE 8.1

## Section A: Increasing functions

Consider the graph of f( ) y x = .

- 1 Complete the following two statements about f( ) y x = .
- ' As the value of x increases the value of y …'
- 'The sign of the gradient at any point is always …'
- 2 Sketch other graphs that satisfy these statements.

These types of functions are called increasing functions .

## Section B: Decreasing functions

Consider the graph of g( ) y x = .

- 1 Complete the following two statements about g( ) y x = .
- ' As the value of x increases the value of y …'
- 'The sign of the gradient at any point is always …'
- 2 Sketch other graphs that satisfy these statements.

These types of functions are called decreasing functions .

## 8.1  Increasing and decreasing functions

As you probably worked out from Explore 8.1, an increasing function x f( ) is one where the x f( ) values increase whenever the x value increases. More precisely, this means that a b f f ( ) ( ) &lt; whenever a b &lt; .

Likewise, a decreasing function x f( ) is one where the x f( ) values decrease whenever the x value increases, or a b f f ( ) ( ) &gt; whenever a b &lt; .

Sometimes we talk about a function increasing at a point, meaning that the function values are increasing around that point. If the gradient of the function is positive at a point, then the function is increasing there.

In the same way, we can talk about a function decreasing at a point. If the gradient of the function is negative at a point, then the function is decreasing there.

Now consider the function y x h( ) = , shown on the graph.

We can divide the graph into two distinct sections:

- h( ) x is increasing when x a . , i.e. y x d d 0 . for x a . .
- h( ) x is decreasing when x a , , i.e. y x d d 0 , for x a , .

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## WEB LINK

Try the Choose your families resource on the Underground Mathematics website.

213

214

## WORKED EXAMPLE 8.1

Find the set of values of x for which y x x = --8 3 2 is decreasing. Answer is decreasing.

```
8 3 d d 3 2 2 y x x y x x = --= --When d d 0 , y x , y x x x 3 2 0 2 3 3 2 ----, . .
```

## WORKED EXAMPLE 8.2

For the function  f( ) 4 15 72 8 3 2 x x x x = ---:

- a Find ′ ( ) f . x
- b Find the range of values of x for which  f( ) 4 15 72 8 3 2 x x x x = ---is increasing.
- c Find the range of values of x for which  f( ) 4 15 72 8 3 2 x x x x = ---is decreasing.

## Answer

- a f( ) 4 15 72 8 f 12 30 72 3 2 2 x x x x x x x = ---′( ) = --
- b When f 0 x ′( ) &gt; , f( x ) is increasing.

12

x

x

30

72

0

2

-

-

&gt;

2

x

x

5

12

0

2

-

-

&gt;

(2

x

x

3)(

4)

0

+

-

&gt;

- Critical values are -3 2 and 4.

∴

x

&lt; -

3

2

and

x

&gt;

4.

- c When f 0 x ′ ( ) &lt; , f( x ) is decreasing.
- x ∴-&lt; &lt; 3 2 4

<!-- image -->

-

## WORKED EXAMPLE 8.3

A function f is defined as x x = -f( ) 5 2 3 for x 3 2 . . Find an expression for x ′( ) f and determine whether f is an increasing function, a decreasing function or neither.

## Answer

$$\begin{array} { c c c } & & \\ & & f ( x ) = \frac { 5 } { 2 x - 3 } \\ & & & = 5 ( 2 x - 3 ) ^ { - 1 } \end{array}$$

f

x

x

′

(

)

= -

-

-

5(2

3)

(2)

2

$$<_Python_> = - \frac { 1 0 } { ( 2 x - 3 ) ^ { 2 } }$$

If 3 2 x . , then -(2 3) 0 2 x . for all values of x .

Hence, x f 0 ′ ( ) , for all values of x in the domain of f.

- ∴ f is a decreasing function.

## EXERCISE 8A

- 1 Find the set of values of x for which each of the following is increasing.
- a = -+ f( ) 8 2 2 x x x
- b = -+ f( ) 2 4 7 2 x x x
- c = --f( ) 5 7 2 2 x x x
- d = -+ f( ) 12 2 3 2 x x x
- e = -+ + f( ) 2 15 24 6 3 2 x x x x
- f = + --f( ) 16 16 2 3 x x x x
- 2 Find the set of values of x for which each of the following is decreasing.
- a = -+ f( ) 3 8 2 2 x x x
- b = + -f( ) 10 9 2 x x x
- c = -+ -f( ) 2 21 60 5 3 2 x x x x
- d = --+ f( ) 3 9 5 3 2 x x x x
- e = -+ -f( ) 40 13 2 3 x x x x
- f = + --f( ) 11 24 3 2 3 x x x x
- 3 Find the set of values of x for which ( ) = -+ f( ) 1 6 5 2 4 3 x x x is increasing.
- 4 A function f is de fined as = -f( ) 4 1 2 x x for 1. x &gt; Find an expression for ′ ( ) f x and determine whether f is an increasing function, a decreasing function or neither.
- 5 A function f is defined as = + -+ f( ) 5 ( 2) 2 2 2 x x x for 0 x &gt; . Find an expression for ′( ) f x and determine whether f is an increasing function, a decreasing function or neither.
- 6 Show that = -f( ) 4 2 x x x is an increasing function.
- 7 A function f is defined as = + -f( ) (2 5) 3 2 x x for x 0. ù Find an expression for ′ ( ) f x and explain why f is an increasing function.
- 8 It is given that = -f( ) 2 4 2 x x x for x 0 . . Show that f is a decreasing function.
- 9 A manufacturing company produces x articles per day. The profit function, P( ) x , can be modeled by the function = -+ P( ) 2 81 840 3 2 x x x x . Find the range of values of x for which the profit is decreasing.

Write in a form ready for differentiating.

Differentiate using the chain rule.

215

216

## 8.2  Stationary points

Consider the following graph of the function = f( ) y x .

<!-- image -->

The red sections of the curve show where the gradient is negative (where f( ) x is a decreasing function) and the blue sections show where the gradient is positive (where f( ) x is an increasing function). The gradient of the curve is zero at the points P , Q and R .

A point where the gradient is zero is called a stationary point or a turning point.

## Maximum points

The stationary point Q is called a maximum point because the value of y at this point is greater than the value of y at other points close to Q .

At a maximum point:

- /uni25CF = d d 0 y x
- /uni25CF the gradient is positive to the left of the maximum and negative to the right.

## Minimum points

The stationary points P and R are called minimum points.

At a minimum point:

- /uni25CF = y x d d 0
- /uni25CF the gradient is negative to the left of the minimum and positive to the right.

<!-- image -->

<!-- image -->

## Stationary points of inflexion

0

There is a third type of stationary point (turning point) called a point of inflexion .

<!-- image -->

<!-- image -->

At a stationary point of inflexion:

- /uni25CF = d d 0 y x











from positive to zero and then to positive again or

from negative to zero and then to negative again.

- /uni25CF the gradient changes

## WORKED EXAMPLE 8.4

Find the coordinates of the stationary points on the curve 12 5 3 y x x = -+ and determine the nature of these points. Sketch the graph of 12 5 3 y x x = -+ .

## Answer

$$y = x ^ { 3 } - 12 x + 5$$

$$\underline { d y } = 3 x ^ { 2 } - 12$$

For stationary points:

$$\underline { d y } = 0
\underline { d x }$$

-= 3 12 0 2 x

x

-

=

4

0

2

+ -= ( 2)( 2) 0 x x

x

= -

=

2  or

2

x

= -When 2, x y ( 2) 12( 2) 5 21 3 = ---+ =

= When 2, x y (2) 12(2) 5 11 3 = -+ = -

The stationary points are -( 2, 21) and -(2, 11).

Now consider the gradient on either side of the points -( 2, 21) and -(2, 11):

| x                    | 2.1 -                       | 2 -   | 1.9 -                       |
|----------------------|-----------------------------|-------|-----------------------------|
| y x d d              | 3( 2.1) 12 positive 2 - - = | 0     | 3( 1.9) 12 negative 2 - - = |
| direction of tangent |                             |       |                             |
| shape of curve       |                             |       |                             |

In this image, we can see a table with some numbers and a blue color symbol.

<!-- image -->

| x                    | 1.9                      | 2   | 2.1                      |
|----------------------|--------------------------|-----|--------------------------|
| y x d d              | 3(1.9) 12 negative 2 - = | 0   | 3(2.1) 12 positive 2 - = |
| direction of tangent |                          |     |                          |
| shape of curve       |                          |     |                          |

So -( 2, 21) is a maximum point and -(2, 11) is a minimum point.

The sketch graph of = -+ 12 5 3 y x x is:

<!-- image -->

<!-- image -->

217

218

## Second derivatives and stationary points

Consider moving from left to right along a curve, passing through a maximum point.

<!-- image -->

The gradient, d d y x , starts as a positive value, decreases to zero at the maximum point and then decreases to a negative value.

Since d d y x decreases as x increases, then the rate of change of d d y x is negative.

$$\underset { d ^ { 2 } v } { \text{The rate of change of } \frac { d y } { d x } } \text{ is written as } \frac { d } { d x } \left ( \frac { d y } { d x } \right ) = \frac { d ^ { 2 } y } { d x ^ { 2 } }.$$

d d 2 2 y x is called the second derivative of y with respect x .

This leads to the rule:

## KEY POINT 8.1

$$\Big | \text{ if } \frac { d y } { d x } = 0 \text{ and } \frac { d ^ { 2 } y } { d x ^ { 2 } } < 0 \text{, then the point is a maximum point.}$$

Now, consider moving from left to right along a curve, passing through a minimum point.

<!-- image -->

The gradient, d d , y x starts as a negative value, increases to zero at the minimum point and then increases to a positive value.

Since d d y x increases as x increases, then the rate of change of d d y x is positive.

This leads to the rule:

## KEY POINT 8.2

$$\Big | \text{ if } \frac { d y } { d x } = 0 \text{ and } \frac { d ^ { 2 } y } { d x ^ { 2 } } > 0 \text{, then the point is a minimum point.}$$

If = d d 0 y x and = d d 0 2 2 y x , then the nature of the stationary point can be found using the first derivative test.

## REWIND

In Chapter 7, Section 7.4 we learnt ho w to find a second derivative. Here we will look at how second derivatives can be used to determine the nature of a stationary point.

## WORKED EXAMPLE 8.5

Find the coordinates of the stationary points on the curve 9 2 y x x = + and use the second derivative to determine the nature of these points. Answer = + = + = -= ---9 9 d d 1 9 1 9 2 1 2 2 y x x x x y x x x For stationary points: = -= -= + -= = -= d d 0 1 9 0 9 0 ( 3)( 3) 0 3  or 3 2 2 y x x x x x x x x = -When 3, = -+ -= -= + = ( 3) 9 3 6 3 9 3 6 2 2 y y The stationary points are --( 3, 6) and (3, 6). , . y x x x x y x x y x = = = -= -= = -d d 18 18 When 3, d d 18 ( 3) 0 When 3, d d 18 3 0 2 2 3 3 2 2 3 2 2 3 ∴ --( 3, 6) is a maximum point and (3, 6) is a minimum point. x = When 3,

## EXPLORE 8.2

The graph of the function f( ) y x = passes through the point (1, 35) -and the point (6, 90).

The following graphs show = ′( ) f y x and = ′′( ) f y x .

<!-- image -->

<!-- image -->

- 1 Discuss the properties of these two graphs and the information that can be obtained from them.
- 2 Withou t finding the equation of the function f( ) y x = , determine, giving reasons:
- a the coordinates of the maximum point on the curve
- b the coordinates of the minimum point on the curve.
- 3 Sketch the graph of the function f( ) y x = .

219

220

## EXERCISE 8B

- 1 Find the coordinates of the stationary points on each of the following curves and determine the nature of each stationary point. Sketch the graph of each function and use graphing software to check your graphs.
- 2 Find the coordinates of the stationary points on each of the following curves and determine the nature of each stationary point.

- a = - + 4 8 2 y x x

- b = + - (3 )(2 ) y x x

- c = - + 12 6 3 y x x

- d = + - - 10 9 3 2 3 y x x x

- e = + - 4 1 4 y x x

- f = - - (2 3) 6 3 y x x

$$& \text{ determine the nature of each stationary point.} \\ & \text{a} \quad y = \sqrt { x } + \frac { 9 } { \sqrt { x } } & b & y = 4 x ^ { 2 } + \frac { 8 } { x } \\ & c & y = \frac { ( x - 3 ) ^ { 2 } } { x } & d & y = x ^ { 3 } + \frac { 4 8 } { x } + 4 \\ & e & y = 4 \sqrt { x } - x & f & y = 2 x + \frac { 8 } { x ^ { 2 } } \\ & \text{The equation of a curve is } \nu - \frac { x ^ { 2 } - 9 } { }$$

- Find d d y x and, hence, explain why the curve does not have a stationary point.
- 3 The equation of a curve is = -9 2 2 y x x .
- 4 A curve has equation = --+ 2 3 36 . 3 2 y x x x k
- a Find the x -coordinates of the two stationary points on the curve.
- b Hence , find the two values of k for which the curve has a stationary point on the x -axis.
- 5 The curve = + -+ 9 2 3 2 y x ax x has a maximum point at = -3 x .
- a Find the value of a .
- b Find the range of values of x for which the curve is a decreasing function.
- 6 The curve = + + -2 30 3 2 y x ax bx has a stationary point when = 3 x . The curve passes through the point (4, 2).
- a Find the value of a and the value of b .
- b Find the coordinates of the other stationary point on the curve and determine the nature of this point.
- 7 The curve = + + -2 30 3 2 y x ax bx has no stationary points. Show that a b 6 . 2 ,
- 8 A curve has equation = + + -1 2 2 3 2 y x k x , where k is a positive constant. Find, in terms of k , the values of x for which the curve has stationary points and determine the nature of each stationary point.
- 9 Find the coordinates of the stationary points on the curve = -+ + 4 4 1 4 3 2 y x x x and determine the nature of each of these points. Sketch the graph of the curve.
- 10 The curve = + + 3 2 y x ax b has a stationary point at -(4, 27).
- a Find the value of a and the value of b .
- b Determine the nature of the stationary point -(4, 27).

- c Find the coordinates of the other stationary point on the curve and determine the nature of this stationary point.
- d Find the coordinates of the point on the curve where the gradient is minimum and state the value of the minimum gradient.
- 11 The curve = + 2 y ax b x has a stationary point at (2, 12).
- a Find the value of a and the value of b .
- b Determine the nature of the stationary point (2, 12).
- c Find the range of values of x for which + ax b x 2 is increasing.
- 12 The curve = + + 2 y x a x b has a stationary point at (3, 5).
- a Find the value of a and the value of b .
- b Determine the nature of the stationary point (3, 5).
- c Find the range of values of x for which + + x a x b 2 is decreasing.
- 13 The curve = + + + 2 7 3 2 y x ax bx has a stationary point at the point -(2, 13).
- a Find the value of a and the value of b .
- b Find the coordinates of the second stationary point on the curve.
- c Determine the nature of the two stationary points.
- d Find the coordinates of the point on the curve where the gradient is minimum and state the value of the minimum gradient.

## 8.3  Practical maximum and minimum problems

There are many problems for which we need to find the maximum or minimum value of an expression. For example, the manufacturers of canned food and drinks often need to minimise the cost of their manufacturing. To do this they need to find the minimum amount of metal required to make a container for a given volume. Other situations might involve finding the maximum area that can be enclosed within a shape.

## WORKED EXAMPLE 8.6

The surface area of the solid cuboid is 100 cm 2 and the volume is V cm 3 .

- a Express h in terms of x .
- b Show that = -V x x 25 1 2 3 .
- c Given that x can vary , find the stationary value of V and determine whether this stationary value is a maximum or a minimum.

x cm

<!-- image -->

## Answer

$$<_Python_> 

a:
        Surface area = 2x$$

<!-- image -->

## WEB LINK

Try the following resources on the Underground Mathematics website:

- Floppy hair
- Two-way calculus
- Curvy cubics
- Can you find… curvy cubics edition.

221

222

$$\begin{array} {$$

## WORKED EXAMPLE 8.7

The diagram shows a solid cylinder of radius r cm and height h 2 cm cut from a solid sphere of radius 5cm. The volume of the cylinder is C cm 3 .

- a Express r in terms of h .
- b Show that = π -π 50 2 3 V h h .
- c Find the value for h for which there is a stationary value of V .
- d Determine the nature of this stationary value.

## Answer

```
a + = = -5 25 2 2 2 2 r h r h Use Pythagoras' theorem. b ( ) = π = π -= π -π (2 ) 25 (2 ) 50 2 2 2 3 V r h h h h h Substitute for r . c = π π d d 50 6 2 V h h Stationary values occur when = d d 0: V h π π = = π π = 50 6 0 50 6 5 3 2 2 h h h
```

```
3
```

<!-- image -->

$$\frac { d ^ { 2 } V } { d h ^ { 2 } } = - 12 \$$

$$\Big | \quad \text{When $h=\frac{3}{3}$,$$

The stationary value is a maximum value.

## WORKED EXAMPLE 8.8

The diagram shows a hollow cone with base radius 12 cm and height 24cm.

A solid cylinder stands on the base of the cone and the upper edge touches the inside of the cone.

The cylinder has base radius  cm r , height cm h and volume cm 3 V .

- a Express h in terms of r .
- b Show that = π -π 24 2 2 3 V r r .
- c Find the volume of the largest cylinder that can stand inside the cone.

<!-- image -->

## Answer

a

r

12

24

-

24

=

2

r

h

24

=

-

$$h = 24 - 2 r$$

b = π 2 V r h

= π

-

(24

2 )

2

r

r

$$= 24 \pi r ^ { 2 } - 2 \pi r ^ { 3 }$$

- c = π -π d d 48 6 2 V r r r

= Stationary values occur when d 0: V

$$<_Cuda_> :cur when$$

$$W hen r = 8, V = 24 \pi ( 8 ) ^ { 2 } - 2 \pi ( 8 ) ^ { 3 } = 512 \pi$$

$$\frac { d ^ { 2 } V } { d r ^ { 2 } } = 48 \pi - 12 \pi r \\ \frac { 2 v } { 2 v }$$

$$\uð
When r = 8, \frac { d ^ V } { d x ^ { 2 } } = 48 \pi - 12 \pi (8),  which is < 0.$$

The stationary value is a maximum value.

Volume of the largest cylinder is π 512 cm 3 .

h

Use similar triangles.

Substitute for h .

<!-- image -->

## DID YOU KNOW?

Differentiation can be used in business to find how to maximise company profits and to find how to minimise production costs.

223

224

## EXERCISE 8C

- 1 The sum of two real numbers, x and y , is 9.
- a Express y in terms of x .
- b i Given that = 2 P x y , write down an expression for P , in terms of x .
- ii Find the maximum value of P .
- c i Given that = + 3 2 2 2 Q x y , write down an expression for Q , in terms of x .
- ii Find the minimum value of Q .
- 2 A piece of wire, of length 40 cm, is bent to form a sector of a circle with radius r cm and sector angle θ radians, as shown in the diagram. The total area enclosed by the shape is A cm 2 .
- a Express θ in terms of r .
- b Show that = -20 2 A r r .
- c Find the value of r for which there is a stationary value of A .
- d Determine the magnitude and nature of this stationary value.
- 3 The diagram shows a rectangular enclosure for keeping animals.

There is a fence on three sides of the enclosure and a wall on its fourth side.

- The total length of the fence is 50 m and the area enclosed is m 2 A .
- a Express y in terms of x .
- b Show that = -1 2 (50 ) A x x .
- c Find the maximum possible area enclosed and the value of x for which this occurs.
- 4 The diagram shows a rectangle, ABCD , where 20cm = AB and 16cm = BC . PQRS is a quadrilateral where 2 cm = = PB AS x , cm = BQ x and 4 cm = DR x .
- a Express the area of PQRS in terms of x .
- b Given that x can vary , find the value of x for which the area of PQRS is a minimum and find the magnitude of this minimum area.

<!-- image -->

2

- 5 The diagram shows the graph of + = 3 2 30 x y . OPQR is a rectangle with area cm 2 A . The point O is the origin, P lies on the x -axis, R lies on the y -axis and Q has coordinates ( , ) x y and lies on the line + = 3 2 30 x y .
- a Show that = -15 3 2 2 A x x .
- b Given that x can vary, find the stationary value of A and determine its nature.
- 6 PQRS is a rectangle with base length 2 p units and area units 2 A .
- The points P and Q lie on the x -axis and the points R and S lie on the curve = -9 2 y x .
- a Express QR in terms of p .
- b Show that ( ) = -2 9 . 2 A p p
- c Find the value of p for which A has a stationary value.
- d Find this stationary value and determine its nature.

<!-- image -->

<!-- image -->

<!-- image -->

r

<!-- image -->

<!-- image -->

24cm

The diagram shows a 24cm by 15cm sheet of metal with a square of side cm x removed from each corner. The metal is then folded to make an open rectangular box of depth cm x and volume cm 3 V .

- a Show that = -+ 4 78 360 3 2 V x x x .
- b Find the stationary value of V and the value of x for which this occurs.
- c Determine the nature of this stationary value.
- 8 The volume of the solid cuboid shown in the diagram is 576cm 3 and the surface area is cm 2 A .
- a Express y in terms of x .
- b Show that = + 4 1728 2 A x x .
- c Find the maximum value of A and state the dimensions of the cuboid for which this occurs.
- 9 The diagram shows a piece of wire, of length 2 m, is bent to form the shape PQRST .
- PQST is a rectangle and QRS is a semicircle with diameter SQ .

= PT x m and = = PQ ST y m.

The total area enclosed by the shape is m 2 A .

- a Express y in terms of x .
- b Show that = --π A x x x 1 2 1 8 2 2 .
- c Find d d A x and d d 2 2 A x .
- d Find the value for x for which there is a stationary value of A .
- e Determine the magnitude and nature of this stationary value.
- 10 The diagram shows a window made from a rectangle with base 2 m r and height m h and a semicircle of radius  m r . The perimeter of the window is 5 m and the area is m 2 A .
- a Express h in terms of r .
- b Show that A r r r 5 2 1 2 2 2 = --π .
- c Find d d A r and d d 2 2 A r .
- d Find the value for r for which there is a stationary value of A .
- e Determine the magnitude and nature of this stationary value.

<!-- image -->

<!-- image -->

<!-- image -->

225

226

- 11 A piece of wire, of length 100 cm, is cut into two pieces.

One piece is bent to make a square of side cm x and the other is bent to make a circle of radius  cm r . The total area enclosed by the two shapes is cm 2 A .

- a Express r in terms of x .
- x x π + -+ ( 4) 200 2500 2
- b Show that A = π .
- c Find the value of x for which A has a stationary value and determine the nature and magnitude of this stationary value.
- 12 A solid cylinder has radius  cm r and height cm h .

The volume of this cylinder is π 432 cm 3 and the surface area is cm 2 A .

- a Express h in terms of r .
- b Show that = π + π 2 864 2 A r r .
- c Find the value for r for which there is a stationary value of A .
- d Determine the magnitude and nature of this stationary value.

13

<!-- image -->

The diagram shows an open water container in the shape of a triangular prism of length cm y .

The vertical cross-section is an isosceles triangle with sides 5 cm x , 5 cm x and 6 cm x .

The water container is made from 500 cm 2  of sheet metal and has a volume of V cm 3 .

- a Express y in terms of x .
- b Show that = -600 144 5 3 V x x .
- c Find the value of x for which V has a stationary value.
- d Show that the value in part c is a maximum value.
- 14 The diagram shows a solid formed by joining a hemisphere of radius cm r to a cylinder of radius  cm r and height cm h . The surface area of the solid is π 320 cm 2 and the volume is V cm 3 . PS
- a Express h in terms of r .
- b Show that = π -π V r r 160 5 6 3 .
- c Find the exact value of r such that V is a maximum.
- 15 The diagram shows a right circular cone of base radius  cm r and height cm h cut from a solid sphere of radius 10 cm. The volume of the cone is V cm 3 . PS
- a Express r in terms of h .
- b Show that V h h 1 3 (20 ) 2 = π -.
- c Find the value for h for which there is a stationary value of V .
- d Determine the magnitude and nature of this stationary value.

<!-- image -->

<!-- image -->

## 8.4 Rates of change

## EXPLORE 8.3

<!-- image -->

<!-- image -->

<!-- image -->

Consider pouring water at a constant rate of -10cm s 3 1 into each of these three large containers.

- 1 Discuss how the height of water in container A changes with time.
- 2 Discuss how the height of water in container B changes with time.
- 3 Discuss how the height of water in container C changes with time.
- 4 On copies of the following axes, sketch graphs to show how the height of water in a container ( cm) h varies with time t ( seconds) for each container.
- 5 What can you say about the gradients?

<!-- image -->

You should have come to the conclusion that:

- /uni25CF the height of water in container A increases at a constant rate
- /uni25CF the height of water in containers B and C does not increase at a constant rate.

The (constant) rate of change of the height of the water in container A can be found by finding the gradient of the straight-line graph.

The rate of change of the height of the water in containers B and C at a particular time, t seconds, can be estimated by drawing a tangent to the curve and then finding the gradient of the tangent. A more accurate method is to use differentiation if we know the equation of the graph.

## WORKED EXAMPLE 8.9

Given that = 1 5 2 h t , find the rate of change of h with respect to t when = 2. t

## Answer

$$<_Awk_>$$

Differentiate to obtain d d h t (the rate of change of h with respect to t ).

228

## WORKED EXAMPLE 8.10

Variables V and t are connected by the equation = -+ 2 3 8. 2 V t t

Find the rate of change of V with respect to t when = 4 t .

## Answer

$$\begin{array} { c } & \text{When } t = 4, \frac { d V } { d t } = 4 ( 4 ) - 3 = 13 \end{array}$$

$$\begin{array} { c } V = 2 t ^ { 2 } - 3 t + 8 \\ \frac { d V } { d } = 4 t - 3 \\ \text{When } t = 4, \frac { d V } { d } \end{array}$$

## Connected rates of change

When two variables, x and y , both vary with a third variable, t , we can connect the three variables using the chain rule.

## KEY POINT 8.3

The chain rule states:

$$\frac { d y } { d t } = \frac { d y } { d x } \times \frac { d x } { d t }$$

We may also need to use the rule:

## KEY POINT 8.4

$$\frac { d x } { d y } = \frac { 1 } { \underline { d y } }$$

d x

We can deduce this as: if we set = t y in the chain rule, we get

$$\text{Since } \frac { d y } { d y } = 1, \text{ the rule follows.}$$

$$\frac { d y } { d y } = \frac { d y } { d x } \times \frac { d x } { d y }$$

## WORKED EXAMPLE 8.11

A point with coordinates ( , ) x y moves along the curve = + + 2 3 y x x in such a way that the rate of increase of x has the constant value 0.06 units per second. Find the rate of increase of y at the instant when = 3 x . State whether the y -coordinate is increasing or decreasing.

## Answer

$$<_Haskell_>$$

$$0.06$$

Differentiate to obtain d d V t (the rate of change of V with respect to t ).

$$\varepsilon \text{ Differentiate to find } \frac { d y } { d x }.$$

## REWIND

In Chapter 7, Section 7.2 we learnt how to differentiate using the chain rule. Here we will look at how the chain rule can be used for problems involving connected rates of change.

The y -coordinate is increasing (since is a positive quantity).

When = 3 x , ( ) = + + = d d 1 1 2 3 3 4 3 y x Using the chain rule: Rate of change of y is 0.08 units per second. d d y t = × = × = d d d d d d 4 3 0.06 0.08 y t y x x t

## EXERCISE 8D

- 1 A point is moving along the curve = -3 2 3 y x x in such a way that the x -coordinate is increasing at 0.015 units per second. Find the rate at which the y -coordinate is changing when = 2 x , stating whether the y -coordinate is increasing or decreasing.
- 2 A point with coordinates ( , ) x y moves along the curve = + 1 2 y x in such a way that the rate of increase of x has the constant value 0.01 units per second. Find the rate of increase of y at the instant when = 4 x .
- 3 A point is moving along the curve = -8 2 2 y x in such a way that the x -coordinate is increasing at a constant rate of 0.005 units per second. Find the rate of change of the y -coordinate as the point passes through the point (2, 4).
- 4 A point is moving along the curve = -3 5 y x x in such a way that the x -coordinate is increasing at a constant rate of 0.02 units per second. Find the rate of change of the y -coordinate when = 1 x .
- 5 A point, P , travels along the curve = + 3 1 y x x in such a way that the x -coordinate of P is increasing at a constant rate of 0.5 units per second. Find the rate at which the y -coordinate of P is changing when P is at the point (1, 4).
- 6 A point is moving along the curve = + 2 5 y x x in such a way that the x -coordinate is increasing at a constant rate of 0.02 units per second. Find the rate at which the y -coordinate is changing when = 2 x , stating whether the y -coordinate is increasing or decreasing.
- 7 A point moves along the curve y x = -8 7 2 . As it passes through the point P , the x -coordinate is increasing at a rate of 0.125 units per second and the y -coordinate is increasing at a rate of 0.08 units per second. Find the possible x -coordinates of P .
- 8 A point, P , travels along the curve = -2 3 2 3 y x in such a way that at time t minutes the x -coordinate of P is increasing at a constant rate of 0.012 units per minute. Find the rate at which the y -coordinate of P is changing when P is at the point -(1, 1).
- 9 A point, ( , ) P x y , travels along the curve = -+ 5 5 3 2 y x x x in such a way that the rate of change of x is constant. Find the values of x at the points where the rate of change of y is double the rate of change of x . PS

229

230

## 8.5  Practical applications of connected rates of change

## WORKED EXAMPLE 8.12

Oil is leaking from a pipeline under the sea and a circular patch is formed on the surface of the sea. The radius of the patch increases at a rate of 2   metres per hour. Find the rate at which the area is increasing when the radius of the patch is 25 metres. Answer We need to find A t d d when = 25 r . Radius increasing at a rate of 2 metres per hour, so r t = d d 2. A A r A r r = = π = π Let area of circular oil patch, in m . d d 2 2 2 Differentiate with respect to r . When = 25 r , = π d d 50 A r Using the chain rule, The area is increasing at a rate of π 100 m 2 per hour. = × = π × = π d d d d d d 50 2 100 A t A r r t

## WORKED EXAMPLE 8.13

A solid sphere has radius  cm r , surface area cm 2 A and volume V cm 3 .

The radius is increasing at a rate of π -1 5 cms 1 .

- a Find the rate of increase of the surface area when = 3. r
- b Find the rate of increase of the volume when = 5. r

## Answer

```
a We need t o find d d A t when = 3 r . Radius increasing at a rate of π -1 5 cms 1 , so r t = π d d 1 5 . = π = π 4 d d 8 2 A r A r r When = 3 r , = π d d 24 A r Using the chain rule, = × = π × π = d d d d d d 24 1 5 4.8 A t A r r t
```

The surface area is increasing at a rate of -4.8cm s 2 1 . Differentiate with respect to r .

$$\begin{array} {$$

d t = π 4 3 3 V r = π d d 4 2 V r r When = 5 r , = π d d 100 V r Using the chain rule, = × = π × π = d d d d d d 100 1 5 20 V t V r r t The volume is increasing at a rate of -20cm s 3 2 . Differentiate with respect to r .

## WORKED EXAMPLE 8.14

Water is poured into the conical container shown, at a rate of π -2 cm s 3 1 .

After t seconds, the volume of water in the container, cm 3 V , is given by = π 1 12 3 V h , where cm h is the height of the water in the container.

- a Find the rate of change of h when = 5 h .
- b Given that the container has radius 10 cm and height 20 cm, find the rate of change of h when the container is half full. Give your answer correct to 3 significant figures.

<!-- image -->

## Answer

$$<_Haskell_>         a   We need to find a$$

$$\Big |$$

$$\begin{array} { c } V = \frac { 1 } { 1 2 } \pi h$$

$$dh = 4$$

$$\text{When} \,h = 5, \frac { d V } { d h } =$$

$$\begin{array} { c c c c } d h & 4 \\ \text{Using the chain$$

The height is increasing at a rate of -0.32 cms 1 .

Differentiate with respect to h .

231

232

```
b Volume when half full ( ) = π       = π       = π h 1 2 1 12 1 2 1 12 20 1000 3 3 3 = π π = π = = Using 1 12 , 1 12 1000 3 4000 15.874 3 3 3 V h h h h When = 15.874 h , = π = d d 1 4 (15.874) 197.9 2 V h Using the chain rule, d d d d d d 1 197.9 2 0.0317 cms 1 = × = × π = -h t h V V t
```

## EXERCISE 8E

- 1 A circle has radius  cm r and area cm 2 A .
- The radius is increasing at a rate of 0.1cm s 1 -.
- Find the rate of increase of A when = 4 r .
- 2 A sphere has radius  cm r and volume V cm 3 .
- The radius is increasing at a rate of π -1 2 cms 1 .
- Find the rate of increase of the volume when = π 36 V .
- 3 A cone has base radius  cm r an d a fixed height of 30 cm.
- The radius of the base is increasing at a rate of 0.01cm s 1 -.
- Find the rate of change of the volume when = 5 r .
- 4 A square has side length cm x and area cm 2 A .
- The area is increasing at a constant rate of 0.03cm s 2 1 -.
- Find the rate of increase of x when = 25 A .
- 5 A cube has sides of length cm x and volume V cm 3 .
- The volume is increasing at a rate of 1.5 cm s 3 1 -.
- Find the rate of increase of x when = 8 V .
- 6 A solid metal cuboid has dimensions cm x by cm x by 4 cm x .
- The cuboid is heated and the volume increases at a rate of 0.15cm s 3 1 -.
- Find the rate of increase of x when = 2 x .
- 7 A closed circular cylinder has radius r cm and surface area cm 2 A , where = π + π 2 400 2 A r r . -

Given that the radius of the cylinder is increasing at a rate of 0.25 cm s 1 , find the rate of change of A when = 10 r .

- 8 The diagram shows a water container in the shape of a triangular prism of length 120 cm.
- The vertical cross-section is an equilateral triangle.

Water is poured into the container at a rate of -24cm s 3 1 .

- a Show that the volume of water in the container, V cm 3 , is given by = 40 3 2 V h , where cm h is the height of the water in the container.
- b Find the rate of change of h when = 12 h .
- 9 Water is poured into the hemispherical bowl of radius 5cm at a rate of π -3 cm s 3 1 .
- After t seconds, the volume of water in the bowl, V cm 3 , is given by = π -π 5 1 2 3 V h h , where cm h
- 3 is the height of the water in the bowl.
- a Find the rate of change of h when = 1 h .
- b Find the rate of change of h when = 3 h .
- The diagram shows a right circular cone with radius 10 cm and height 30 cm.
- 10 The cone is initially completel y filled with water.
- Water leaks out of the cone through a small hole at the vertex at a rate of 4 cm s 3 1 -.
- a Show that the volume of water in the cone, V cm 3 , when the height of the water is cm h is given by the formula = π 3 V h .
- 27
- b Find the rate of change of h when = 20 h .
- 11 Oil is poured onto a flat surface and a circular patch is formed.
- The radius of the patch increases at a rate of 2 cms 1 -r .
- Find the rate at which the area is increasing when the circumference is π 8 cm.
- 12 Paint is poured onto a flat surface and a circular patch is formed.

The area of the patch increases at a rate of 5 cm s 2 1 -.

- a Find, in terms of π , the radius of the patch after 8 seconds.
- b Find, in terms of π , the rate of increase of the radius after 8 seconds.
- 13 A cylindrical container of radius 8cm and height 25cm is completely filled with water. PS

The water is then poured at a constant rate from the cylinder into an empty inverted cone.

- The cone has radius 15cm and height 24cm and its axis is vertical.

It takes 40 seconds for all of the water to be transferred.

- a If V represents the volume of water, in cm 3 , in the cone at time t seconds, find d d V t in terms of π .
- b When the depth of the water in the cone is 10 cm, find:
- i the rate of change of the height of the water in the cone
- ii the rate of change of the horizontal surface area of the water in the cone.

<!-- image -->

<!-- image -->

<!-- image -->

233

234

## Checklist of learning and understanding

## Increasing and decreasing functions

- = f( ) y x is increasing for a given interval of x if d d 0 y x . throughout the interval.
- = f( ) y x is decreasing for a given interval of x if d d 0 y x , throughout the interval.

## Stationary points

- Stationary points (turning points) of a function = f( ) y x occur when = d d 0 y x .

## First derivative test for maximum and minimum points

At a maximum point:

- = d d 0 y x
- the gradient is positive to the left of the maximum and negative to the right.

## At a minimum point:

- = d d 0 y x
- the gradient is negative to the left of the minimum and positive to the right.

## Second derivative test for maximum and minimum points

- If = d d 0 y x and d d 0 2 2 y x , , then the point is a maximum point.
- If = d d 0 y x and d d 0 2 2 y x . , then the point is a minimum point.
- If = d d 0 y x and = d d 0 2 2 y x , then the nature of the stationary point can be found using the

first derivative test.

## Connected rates of change

- be connected using the chain rule: = × d d d d d d y t y x x t .
- When two variables, x and y , both vary with a third variable, t , the three variables can
- You may also need to use the rule: = d d 1 d d x y y x .

## END-OF-CHAPTER REVIEW EXERCISE 8

- 1 The volume of a spherical balloon is increasing at a constant rate of 40 cm 3 per second. Find the rate of increase of the radius of the balloon when the radius is 15 cm.

$$\begin{array} {$$

- 2 An oil pipeline under the sea is leaking oil and a circular patch of oil has formed on the surface of the sea.

At midday the radius of the patch of oil is 50 m and is increasing at a rate of 3 metres per hour.

Find the rate at which the area of the oil is increasing at midday.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q3 November 2012

- 3 A curve has equation = -+ 27 4 ( 2) 2 y x x . Show that the curve has a stationary point at x = -8 3 and
- determine its nature. [5]
- 4 A watermelon is assumed to be spherical in shape while it is growing. Its mass, kg M , and radius,  cm r , are related by the formula = , 3 M kr where k is a constant. It is also assumed that the radius is increasing at a constant rate of 0.1 centimetres per day. On a particular day the radius is 10 cm and the mass is 3.2 kg. Find the value of k and the rate at which the mass is increasing on this day. [5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q4 June 2012

- 5
- 6

<!-- image -->

2

The diagram shows the curve = 2 2 y x and the points -( 2, 0) X and ( , 0) P p . The point Q lies on the curve and PQ is parallel to the y -axis.

- i Express the area, A , of triangle XPQ in terms of p .

[2]

The point P moves along the x -axis at a constant rate of 0.02 units per second and Q moves along the curve so that PQ remains parallel to the y -axis.

- . [3]
- ii Find the rate at which A is increasing when = 2 p

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q2 June 2015

<!-- image -->

A farmer divides a rectangular piece of land into 8 equal-sized rectangular sheep pens as shown in the diagram. Each sheep pen measures  m x by  m y and is fully enclosed by metal fencing. The farmer uses 480 m of fencing.

- i Show that the total area of land used for the sheep pens, m 2 A , is given by = -384 9.6 2 A x x . [3]
- ii Given that x and y can vary , find the dimensions of each sheep pen for which the value of A is a maximum. (There is no need to verify that the value of A is a maximum.) [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 June 2016

[4]

235

236

- 7 The variables x , y and z can take only positive values and are such that = + 3 2 z x y and = 600. xy
- i Show that = + 3 1200 z x x
- . [1]
- ii Find the stationary value of z and determine its nature. [6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q6 June 2011

<!-- image -->

The diagram shows the dimensions in metres of an L-shaped garden. The perimeter of the garden is 48 m.

- i Find an expression for y in terms of x .

[1]

- ii Given that the area of the garden is m 2 A , show that = -48 8 2 A x x . [2]
- iii Given that x can vary , find the maximum area of the garden, showing that this is a maximum value rather than a minimum value. [4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 November 2011

- 9 A curve has equation = + 8 2 y x x .
- i Find d d y x and d d 2 2 y x
- . [3]
- ii Find the coordinates of the stationary points and state, with a reason, the nature of each stationary point. [5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q5 November 2015

<!-- image -->

The diagram shows a metal plate consisting of a rectangle with sides cm x and cm y and a quarter-circle of radius cm x . The perimeter of the plate is 60 cm.

- i Express y in terms of x .

[2]

- ii Show that the area of the plate, A cm 2 , is given by = -30 2 A x x . [2]

Given that x can vary,

- iii find the value of x at which A
- is stationary, [2]
- iv find this stationary value of A , and determine whether it is a maximum or a minimum value. [2]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 November 2010

- 8
- 10

- 11 A curve has equation = + -+ 5 7. 3 2 y x x x
- a Find the set of values of x for which the gradient of the curve is less than 3.
- b Find the coordinates of the two stationary points on the curve and determine the nature of each stationary point.

[4]

[5]

<!-- image -->

The inside lane of a school running track consists of two straight sections each of length x metres, and two semicircular sections each of radius r metres, as shown in the diagram. The straight sections are perpendicular to the diameters of the semicircular sections. The perimeter of the inside lane is 400 metres.

- i Show that the area, m 2 A , of the region enclosed by the inside lane is given by = -π 400 . 2 A r r [4]
- ii Given that x and r can vary, show that, when A has a stationary value, there are no straight sections in the track. Determine whether the stationary value is a maximum or a minimum. [5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 November 2013

- 13 The equation of a curve is = + 3 2 y x px , where p is a positive constant.
- i Show that the origin is a stationary point on the curve an d find the coordinates of the other stationary point in terms of p .
- ii Find the nature of each of the stationary points.

Another curve has equation = + + . 3 2 y x px px

- iii Find the set of values of p for which this curve has no stationary points.

[3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 June 2015

[4]

[3]

- 12

237

In this image we can see a cactus.

<!-- image -->

238

## Chapter   9 Integration

## In this chapter you will learn how to:

- ■ understand integration as the reverse process of differentiation, and integrate  ( ) ax b n + (for any rational n except 1 -), together with constant multiples, sums and differences
- ■ evalua te defi  nite integrals
- ■ solve problems involving the evaluation of a constant of integration
- ■ use defi  nite integration to fi  nd the:
- volume of revolution about one of the axes.
- area of a region bounded by a curve and lines parallel to the axes, or between a curve and a line, or between two curves

In this image we can see a collage of different colors.

<!-- image -->

## PREREQUISITE KNOWLEDGE

| Where it comes from        | What you should be able to do                                                                             | Check your skills                                                                                                                                                                               |
|----------------------------|-----------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| IGCSE / OLevel Mathematics | Substitute values for x and y into equations of the form = + y x c f( ) and solve to find c .             | 1 a Given that the line = + y x c 5 passes through the point - (3, 4), find the value of c . b Given that the curve = - + y x x c 2 2 passes through the point - ( 1, 2), find the value of c . |
| IGCSE / OLevel Mathematics | Find the x -coordinates of the points where a curve crosses the x -axis.                                  | 2 Find the x -coordinates of the points where the curve crosses the x -axis. a = - - y x x 3 13 10 2 b = - y x x 3                                                                              |
| Chapter 7                  | Differentiate constant multiples, sums and differences of expressions containing terms of the form ax n . | 3 Find d d y x . a = - - y x x 3 13 10 8 b = - + y x x x 5 4 10 2                                                                                                                               |

## Why do we study integration?

In Chapters 7 and 8 you studied differentiation, which is th e first basic tool of calculus. In this chapter you will learn about integration, which is the second basic tool of calculus. We often refer to integration as the reverse process of differentiation. It has many applications; for example, planning spacecraft flight paths, or modelling real-world behaviour for computer games.

Isaac Newton and Gottfried Wilhelm Leibniz formulated the principles of integration independently, in the 17th century, by thinking of an integral as an infinite sum of rectangles of infinitesimal width.

## 9.1  Integration as the reverse of differentiation

In Chapter 7, you learnt about the process of obtaining d d y x when y is known. We call this process differentiation.

You learnt the rule for differentiating power functions:

## KEY POINT 9.1

$$\Big | \text{ If } y = x ^ { n }, \text{ then } \$$

Applying this rule to functions of the form 3 y x c = + , we obtain:

<!-- image -->

Copyright Material  - Review Only -  Not for Redistribution

<!-- image -->

## WEB LINK

Explore the Calculus meets functions station on the Underground Mathematics website.

239

240

This shows that there are an in finite number of functions that when differentiated give the answer 3 2 x . They are all of the form 3 y x c = + , where c is some constant.

d y is known.

In this chapter you will learn about the reverse process of obtaining y when d x

We can call this reverse process antidifferentiation .

There is a seemingly unrelated problem that you will study in Section 9.6: what is the area under the graph of = 3 ? 2 y x The process used to answer that question is known as integration . There is a remarkable theorem due to both Newton and Leibniz that says that integration is essentially the same as antidifferentiation . This is now known as the Fundamental theorem of Calculus.

Because of this theorem, we do not need to use the term antidifferentiation. So from now on, we will only talk about integration , whether we are reversing the process of differentiation o r finding the area under a graph.

## EXPLORE 9.1

- 1 Find d d y x for each of the following functions.

$$\left | \begin{array} { c c c c c c c c } & & \math$$

- 2 Discuss your results with those of your classmates and try to find a rule for obtaining y if d d y x x n = .
- 3 Describe your rule, in words.
- 4 Discuss with your classmates whether your rule works for finding y when

From the class discussion we can conclude that:

## KEY POINT 9.2

$$\text{ If } \frac { d y } { d x } = x ^ { n }, \text{ then } y = \frac { 1 } { n + 1 } \, x ^ { n + 1 } + c \, ( \text{where } c \, is an arbitrary constant and } n \neq - 1 ).$$

You may find it easier to remember this in words:

'Increase the power n by 1 to obtain the new power, then divide by the new power.

Remember to add a constant c at the end.'

Using function notation we write this rule as:

## KEY POINT 9.3

$$\text{ If } f ^ { \prime } ( x ) = x ^ { n }, \text{ then } f ( x ) = \frac { 1 } { n + 1 } x ^ { n + 1 } + c \text{ (where } c \text{ is an arbitrary constant and } n \neq -1).$$

The special symbol

∫

is used to denote integration.

d

y

d

x

=

1

x

.

When we need to integrate x 3 , for example, we write:

$$\int x ^ { 3 } d x = \frac { 1 } { 4 } \, x ^ { 4 } + c$$

∫ 3 d x x is called the indefinite integral of 3 x with respect to x .

We call it 'inde finite' because it has infinitely many solutions.

Using this notation, we can write the rule for integrating powers as:

## KEY POINT 9.4

$$\Big | \quad \int x ^ { n } d x = \frac { 1 } { n + 1 } \, x ^ { n + 1 } + c \, \text{ (where $c$ is a constant and $n\neq -1$).}$$

We write the rule for integrating constant multiples of a function as:

## KEY POINT 9.5

$$\Big | \quad \int k f ( x ) d x = k \int f ( x ) d x, \, \text{where} \, k \, \text{is a constant.}$$

We write the rule for integrating sums and differences of two functions as:

## KEY POINT 9.6

$$\Big | \quad \int \left [ \, f ( x ) \pm g ( x ) \, \right ] d x = \int f ( x ) \, d x \pm \int g ( x ) \, d x$$

## WORKED EXAMPLE 9.1

$$\begin{array} { l l l } & \text{Find $y$ in terms of $x$ for each of the following.} \\ & a & \frac { d y } { d x } = x ^ { 3 } & b & \frac { d y } { d x } = \frac { 1 } { x ^ { 2 } } & c & \frac { d y } { d x } = x \sqrt { x } \\ & \text{Answer} \end{array}$$

$$<_Python_>$$

$$\begin{matrix} 2 \\ \end{matrix}$$

$$\begin{matrix} = \frac { 1 } { 4 } x ^ { 4 } + c & & = - x ^ { - 1 } + c & & = \frac { 1 } { 2 } x ^ { 2 } + c \\ & & = - 1 + c & & = \frac { 2 } { 3 } x ^ { 2 } + c \\ & & & = \frac { 5 } { 3 } x ^ { 2 } + c \end{matrix}$$

$$\begin{matrix} b \widetilde { \underline { x } } = x ^ { - 2 } & & & c \, \frac { d y } { d x } = x ^ { \frac { 3 } { 2 } } \\ y = \frac { 1 } { - 2 + 1 } x ^ { - 2 + 1 } + c & & y = \frac { 1 } { \frac { 3 } { 2 } + 1 } x ^ { \frac { 3 } { 2 } + c } \\ = - x ^ { - 1 } + c & & & = \frac { 1 } { \frac { 5 } { 2 } } x ^ { \frac { 5 } { 2 } } + c \\ = - \frac { 1 } { x } + c & & & = \frac { 2 } { 5 } x ^ { \frac { 5 } { 2 } } + c \end{matrix}$$

241

242

## WORKED EXAMPLE 9.2

Find x f( ) in terms of x for each of the following. a x x x ′ = -+ f ( ) 4 2 4 3 2 b x x x x ′ = -+ f ( ) 8 1 2 2 2 4 c x x x x ′ = + -f ( ) ( 3)( 1) Answer a x x x x x x x x c x x x c x x x c ′ = -+ = --+ + = + + + = + + + ---f ( ) 4 2 4 f( ) 4 4 2 ( 1) 4 1 2 4 2 4 3 2 0 4 1 1 4 1 4 Write in index form ready for integration. b x x x x x x x x c x x x c x x x c ′ = -+ = --+ + = + + + = + + + ---f ( ) 8 1 2 2 f( ) 8 3 1 2( 3) 2 2 8 3 1 6 8 3 1 6 2 4 1 3 3 2 3 3 2 3 3 2 Write in index form ready for integration. c ( ) ( ) ( ) ′ = + -= + -= + -+ = + -+ -f ( ) 2 3 2 3 f( ) 1 2 3 2 5 4 3 6 2 3 2 1 2 1 2 5 2 5 2 3 2 3 2 1 2 1 2 5 2 3 2 x x x x x x x x x x x c x x x c Write in index form ready for integration.

## WORKED EXAMPLE 9.3

Find:

$$\left | \quad & \text{a} \quad \int _ { x ( 2 x - 1 ) ( 2 x + 3 ) d x } \text{b} \quad \int \frac { 4 x ^ { 2 } - 3 \sqrt { x } } { x } d x$$

Answer

$$\begin{array} { l l l } & & \text{answer} \\ & & & \int x ( 2 x - 1 ) ( 2 x + 3 ) d x = \int ( 4 x ^ { 3 } + 4 x ^ { 2 } - 3 x ) d x \\ & & & & & & = \frac { 4 x ^ { 4 } } { 4 } + \frac { 4 x ^ { 3 } } { 3 } - \frac { 3 x ^ { 2 } } { 2 } + c \\ & & & & & & = x ^ { 4 } + \frac { 4 x ^ { 3 } } { 3 } - \frac { 3 x ^ { 2 } } { 2 } + c \end{array}$$

$$\begin{array} { c } b & \int \cfrac { 4 x ^ { 2 } - 3 \sqrt { x } } { x } d x = \int \left ( 4 x - 3 x ^ { - \frac { 1 } { 2 } } \right ) d x \\ & & = \frac { 4 } { 2 } x ^ { 2 } - \cfrac { 3 } { \cfrac { 1 } { 2 } } x ^ { 2 } + c \\ & & = 2 x ^ { 2 } - 6 x ^ { 2 } + c \\ & & = 2 x ^ { 2 } - 6 \sqrt { x } + c \end{array}$$

## EXERCISE 9A

- 1 Find y in terms of x for each of the following.
- a d d 15 2 y x x =
- b d d 14 6 y x x =
- d d 3 2 y =
- d x x d 2 x x
- e d 1 3 y =
- 2 Find f( ) x in terms of x for each of the following.
- a x x x ′ = -+ f ( ) 5 2 2 4 3
- b x x x x ′ = + -f ( ) 3 2 5 2
- c x x x x ′ = + + f ( ) 2 8 6 3 2
- d x x x ′ = --f ( ) 9 3 4 7 2
- 3 Find y in terms of x for each of the following.
- a d d ( 5) y x x x = +
- b d d 2 (3 1) 2 y x x x = +
- d d d 2 5 2 4 3 y x x x x = -+
- 4 Find each of the following.
- a ∫ 12 5 d x x
- d ∫ 4 d 3 x x
- 5 Find each of the following.
- a ∫ + + ( 1)( 4)d x x x
- d ∫ + ( 1)d 3 2 x x x
- g ∫ + 2 3 d 2 x x x x
- e ( ) = -d d 3 2 y x x x
- b ∫ 20 3 d x x
- e ∫ 2 3 d x x
- b ∫ -( 3) d 2 x x
- e ∫ -1 2 d 2 2 x x x
- h ∫ -10 d 4 x x x x
- c d d 12 3 y x x =
- f d d 4 y x x =
- c d d ( 2)( 8) y x x x x = + -
- f d d 5 3 1 2 y x x x x = + +
- c ∫ -3 2 d x x
- f ∫ 5 d x x x
- c ∫ -(2 1) 2 d x x
- f ∫ + 6 2 d 3 3 x x x
- i ∫ -      2 3 d 2 2 x x x x

243

244

## 9.2  Finding the constant of integration

The next two examples show how we ca n find the equation of a curve if we know the gradient function and the coordinates of a point on the curve.

## WORKED EXAMPLE 9.4

```
A curve is such that = -y x x x d d 6 18 , 5 3 and  (1, 6)  is a point on the curve. Find the equation of the curve. Answer = -= -= + + = + + --d d 6 18 6 18 2 9 2 9 5 3 2 3 3 2 3 2 y x x x x x y x x c x x c Write in index form ready for integration. When 1, 6 = = x y . = + + = + + = -6 2(1) 9 (1) 6 2 9 5 3 2 c c c The equation of the curve is 2 9 5 3 2 = + -y x x .
```

## WORKED EXAMPLE 9.5

The function f is such that  f ( ) 15 6 4 ′ = -x x x and -= f( 1) 1. Find x f( ). Answer x x x x x x c ′ = -= -+ f ( ) 15 6 f( ) 3 3 4 5 2 -= = ---+ = --+ = ∴ = -+ Using f( 1) 1 gives: 1 3( 1) 3( 1) 1 3 3 7 f( ) 3 3 7 5 2 5 2 c c c x x x

## WORKED EXAMPLE 9.6

A curve is such that = + y x x k d d 6 , where k is a constant. The gradient of the normal to the curve at the point -(1, 3) is 1 . Find the equation of the curve.

2

## Answer

d d 6 3 2 = + = + + y x x k y x kx c Integrate. When x y = = -1, 3. -= + + + = -k c c k 3 3(1) (1) 6 2 (1) When = = + = + x y x k k 1, d d 6(1) 6 k k = = -+ = -= -Gradient of normal 1 2 so gradient of tangent 2 6 2 8 Substituting for k into (1) gives 2 = c .

The equation of the curve is 3 8 2 2 = -+ y x x .

## EXERCISE 9B

- 1 Find the equation of the curve, given d d y x and a point P on the curve.
- a = + d d 3 1, 2 y x x (1, 4) P =
- = -d 2 (3 1), y x x ( 1, 2) P = -
- c = d d 4 , 2 y x x (4, 9) P =
- d = d 2 6 , 3 2 y x (3, 7) P =
- e = -d d 2 1, y x x (4, 6) P =

$$b \quad & \frac { d y } { d x } = 2 x ( 3 x - 1 \\ d \quad & \frac { d y } { d x } = \frac { 2 x ^ { 3 } - 6 } { x ^ { 2 } }, \\ f \quad & \frac { d y } { d x } = \frac { ( 1 - \sqrt { x } ) ^ { \cdot } } { \sqrt { x } }$$

- f = -d (1 ) , 2 y x (9, 5) P =
- 2 A curve is such that d d 2 y x k x = -, where k is a constant. Given that the curve passes through the points (6, 2.5) and ( 3, 1) -, find the equation of the curve.
- 3 A curve is such that d d 12 5 2 y x kx x = -+ , where k is a constant. Given that the curve passes through the points (1 , 3) -and (3, 11) , find the equation of the curve.
- 4 A curve is such that d d 6 2 3 y x kx x = -, where k is a constant. Given that the curve passes through the point (1 , 6) P and that the gradient of the curve at P is 9 , find the equation of the curve.

245

246

- 5 A curve is such that d d 5 2 y x x x = + . Given that the curve passes through the point  (1, 3) , find:
- a the equation of the curve
- b the equation of the tangent to the curve when 4 x = .
- 6 A curve is such that d d 3 y x kx = + , where k is a constant. The gradient of the normal to the curve at the point (1 , 2) -is -1 7 . Find the equation of the curve.
- 7 A function f( ) y x = has gradient function x x ′ = -f ( ) 8 2 . The maximum value of the function is  20. Find f( ) x and sketch the graph of f( ) y x = .
- 8 A curve is such that d d 3 10 2 y x x x = + -. Given that the curve passes through the point  (2, 7) -find:
- a the equation of the curve
- b the set of values of x for which the gradient of the curve is positive.
- 9 A curve is such that d d 12 12 2 2 y x x = + . The gradient of the curve at the point  (0, 4)  is 10. PS
- a Express y in terms of x .
- b Show that the gradient of the curve is never less than 4.
- 10 A curve is such that d d 6 4 . 2 2 y x x = --Given that the curve has a minimum point at  ( 2, 6) --, find the equation of the curve.
- 11 A curve f( ) y x = has a stationary point at (2 , 13) P -and is such that ′ = + -f ( ) 2 3 2 x x x k , where k is a constant.
- a Find the x -coordinate of the other stationary point, Q , on the curve f( ) y x = .
- b Determine the nature of each of the stationary points P and Q .
- 12 A curve is such that d d , y x k x = + where k is a constant. PS
- a Given that the tangents to the curve at the points where 5 x = and 7 x = are perpendicular , find the valu e of k .
- b Given also that the curve passes through the point -(10, 8) , find the equation of the curve.
- 13 A curve f( ) y x = has a stationary point at (1 , 1) -and is such that ′′ = + x x f ( ) 2 4 3 . Find x ′ f ( ) and f( ) x .
- 14 A curve is such that d d 2 8 2 2 y x x = + . Given that the curve has a minimum point at (3, 49) -, find the coordinates of the maximum point.
- 15 A curve is such that = -y x x d d 3 2 and (1, 11) is a point on the curve.
- a Find the equation of the curve.
- b A line with gradient 1 5 is a normal to the curve at the point (4, 5). Find the equation of this normal.
- 16 A curve is such that d d 3 6 y x x = -and the point (1 , 6) P is a point on the curve.
- a Find the equation of the curve.
- b Find the coordinates of the stationary point on the curve and determine its nature.

17 A curve is such that d d 2 12 2 2 3 y x x = -. The curve has a stationary point at P where 1 x = . Given that the curve passes through the point  (2, 5) , find the coordinates of the stationary point P and determine its nature.

- 18 A curve is such that d d 2 5 y x x = -and the point (3 , 4) P -is a point on the curve. The normal to the curve at P meets the curve again at Q .
- a Find the equation of the curve.
- b Find the equation of the normal to the curve at P .
- c Find the coordinates of Q .

## 9.3  Integration of expressions of the form ( ) ax b + n

In Chapter 7 you learnt that:

$$\frac { d } { d x } \left [ \frac { 1 } { 3 \times 7 } \left ( 3 x - 1 \right ) ^ { 7 } \right ] = ( 3 x - 1 ) ^ { 6 }$$

$$\text{Hence}, \, \int ( 3 x - 1 ) ^ { 6 } \, d x = \frac { 1 } { 3 \times 7 } \, ( 3 x - 1 ) ^ { 7 } + c$$

This leads to the general rule:

## KEY POINT 9.7

$$\Big | \text{ if } n \neq - 1 \text{ and } a \neq 0, \text{ then } \int ( a x + b ) ^ { n } \, d x = \frac { 1 } { a ( n + 1 ) } \, ( a x + b ) ^ { n + 1 } + c$$

It is very important to note that this rule only

For example, ax b x ∫ + ( ) d 2 6 is not equal to + + 1 3 ( ) 2 3 a ax b c expression to see why.)

works for powers of linear functions. . (Try differentiating the latter

## WORKED EXAMPLE 9.7

Find:

$$\mathbf a \ \Big | \, ( 2 x - 3 ) ^ { 4 } \, d x$$

$$\int$$

$$\mathfrak { b } \quad & \int \frac { 2 0 } { ( 1 - 4 x ) ^ { 6 } } \, d x & \mathfrak { c } \quad & \int \frac { 5 } { \sqrt { 2 x + 7 } } \, d x$$

Answer

$$\Big | \begin{array} { c } \, \stackrel { \, \sim } { \, \int } ( 2 x - 3 ) ^ { 4 } d x = \frac { 1 } { 2 ( 4 + 1 ) } \, ( 2 x - 3 ) ^ { 4 + 1 } + c \\ \, \quad \, = \frac { 1 } { 1 0 } \, ( 2 x - 3 ) ^ { 5 } + c \end{array}$$

$$\begin{smallmatrix} 0 \end{smallmatrix}$$

$$<_Python_> = \frac { 1 } { 1 0 } ( 2 x - 3 ) ^ { 5 } + c$$

$$\begin{array} { c c c c } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &  & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & && & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \\ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & \ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & _ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & - & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &	 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & } & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &.
 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &

 & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &.. & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &. = & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & = & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & &$$

247

248

$$\begin{array} { c } c \int \frac { 5 } { \sqrt { 2$$

## EXERCISE 9C

- 1 Find:

$$\begin{array} {$$

- 2 Find the equation of the curve, given y x d d and a point P on the curve.
- = + d 2 5, y x = P (2, 2)
- a = -d d (2 1) , 3 y x x =       P 3 2 , 4
- c y x x = -d d 1 2 , = P (3, 7)

$$\mathbf b & \ \frac { d y } { d x } = \sqrt { 2$$

- d = d d 4 , 2 y x = P (2, 4)
- 3 A curve is such that = -y x k x d d ( 5) 3 , where k is a constant. The gradient of the normal to the curve at the point (4, 2) is 1 12 . Find the equation of the curve.
- 4 A curve is such that = -y x x d d 5 2 3 .

Given that the curve passes through the point P (2, 1) , find:

- a the equation of the normal to the curve at P
- b the equation of the curve.
- 5 A curve is such that = + --y x x x d d 12 3 1 4 2.
- a Show that the curve has a stationary point when = x 1 and determine its nature.
- b Given that the curve passes through the point (0, 13) , find the equation of the curve.
- 6 A curve is such that = + y x x k d d 4 2 , where k is a constant. The point P (3 , 2) lies on the curve and the normal to the curve at P is + = x y 4 11. Find the equation of the curve. PS

$$c$$

## 9.4  Further indefinite integration

In this section we use the concept that integration is the reverse process of differentiation to help us integrate some more complicated expressions.

## KEY POINT 9.8

- [ ] = If d d F( ) f( ) x x x , then ∫ = + f( ) d F( ) x x x c

## WORKED EXAMPLE 9.8

- a Show that ( ) ( ) -      = -x x x d 3 4 48 3 4 2 8 2 7 .

$$\text{$\emph{$w$ that $\frac{d}{dx} \left$$

## Answer

- a y x = -Let (3 4) 2 8

Use the chain rule.

$$\frac { d y } { d x } = ( 6 x ) ( 8 ) ( 3 x ^ { 2 } - 4 ) ^ { 8 - 1 } \\ \quad \quad \quad \, - \quad$$

$$= 48.x(3.x^2 - 4)^7$$

- b ∫ ∫ -= -= -+ 6 (3 4) d 1 8 48 (3 4) d 1 8 (3 4) 2 7 2 7 2 8 x x x x x x x c

## EXERCISE 9D

- 1 a Differentiate + x ( 2) 2 4 with respect to x .
- b Hence , find ∫ + ( 2) d 2 3 x x x .
- 2 a Differentiate -x (2 1) 2 5 with respect to x .
- b Hence, find x x x ∫ -(2 1) d 2 4 .
- 3 a Given that = -y x 1 5 2 , show that = -y x kx x d d ( 5) 2 2 , and state the value of k .
- b Hence, find x x x ∫ -4 ( 5) d 2 2 .
- 4 a Differentiate -x 1 4 3 2 with respect to x .
- b Hence, find x x x ∫ -3 (4 3 ) d 2 2 .
- 5 a Differentiate -+ x x ( 3 5) 2 6 with respect to x .
- b Hence, find ∫ --+ 2(2 3)( 3 5) d 2 5 x x x x .
- 6 a Differentiate + x ( 3) 8 with respect to x .
- b Hence, find x x x ∫ + ( 3) d 7 .

249

250

- 7 a Differentiate -x x (2 1) 5 with respect to x .

$$b \text{ Hence, find } \int 3 \sqrt { x } ( 2 x \sqrt { x } - 1 ) ^ { 4 } \, d x.$$

## 9.5  Definite integration

In the remaining sections of this chapter, you will be learning how t o find areas and volumes of various shapes. To do this, you will be using a technique known as definite integration, which is an extension of the indefinite integrals you have been using up to now. In this section, you will learn this technique, before going on to apply it in the next section.

Recall that

$$\int x ^ { 3 } \, d x = \frac { 1 } { 4 } x ^ { 4 } + c,$$

where c is an arbitrary constant, is called the indefinite integral of x 3 with respect to x .

We can integrate a function between two specified limits.

We write the integral of the function x 3 with respect to x between the limits = x 2  and = x 4 as:

$$\int _ { 2 } ^ { 4 } x ^ { 3 } d x$$

The method for evaluating this integral is:

$$\ e m e n o { \, \text{for evaluation} \, \text{in} \, \text{in} \, \text{integral} \, \text{is} } \colon \\ \int _ { 2 } ^ { 4 } x ^ { 3 } \, d x & = \left [ \frac { 1 } { 4 } \, x ^ { 4 } + c \, \right ] _ { 2 } ^ { 4 } \\ & = \left ( \frac { 1 } { 4 } \times 4 ^ { 4 } + c \, \right ) - \left ( \frac { 1 } { 4 } \times 2 ^ { 4 } + c \, \right ) \\ & = 6 0 \\ \text{at that the $\ell c$ concat out} \, \text{co the noncoce} \, \text{can be} \, \text{sim} }$$

Note that the ' c 's cancel out, so the process can be simplified to:

$$\i e t n a t \, t n e \, c s \, c a n c e \, \text{out}, \, \text{so} \, t n e \, \text{process} \, c a n \\ \int _ { 2 } ^ { 4 } x ^ { 3 } \, d x & = \left [ \frac { 1 } { 4 } \, x ^ { 4 } \, \right ] _ { 2 } ^ { 4 } \\ & = \left ( \frac { 1 } { 4 } \times 4 ^ { 4 } \, \right ) - \left ( \frac { 1 } { 4 } \times 2 ^ { 4 } \, \right ) \\ & = 6 0 \\. 3 \, a \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \, \dots \end{array}$$

∫ x x 3 d 2 4 is called the definite integral of x 3 with respect to x between the limits 2 and 4.

Hence, we can write the evaluation of a de finite integral as:

## KEY POINT 9.9

$$\Big | \quad \int _ { a } ^ { b } \mathfrak { f } ( x ) \, \mathfrak { d } x = \left [ \mathit F ( x ) \right ] _ { a } ^ { b } = \mathit F ( b ) - \mathit F ( a )$$

The following rules for definite integrals may also be used.

## TIP

The limits of integration are always written either to the right of the integral sign, as printed, or directly below and above it. They should never be written to the left of the integral sign.

## KEY POINT 9.10

$$\int _ { a } ^ { b } k f ( x ) d x & = k \int _ { a } ^ { b } f ( x ) d x, \, \text{where $k$ is a constant} \\ \int _ { a } ^ { b } \left [ f ( x ) \pm g ( x ) \right ] d x & = \int _ { a } ^ { b } f ( x ) d x \pm \int _ { a } ^ { b } g ( x ) d x \\ \int _ { a } ^ { b } f ( x ) d x & = - \int _ { b } ^ { a } f ( x ) d x$$

## KEY POINT 9.11

$$\Big | \quad \int _ { a } ^ { b } \mathfrak { f } ( x ) \, \mathfrak { d } x + \int _ { b } ^ { c } \mathfrak { f } ( x ) \, \mathfrak { d } x = \int _ { a } ^ { c } \mathfrak { f } ( x ) \, \mathfrak { d } x$$

## WORKED EXAMPLE 9.9

Evaluate:

$$\left | \begin{array} { c c c c } a & \int _ { 1 } ^ { 2 } \frac { 6 x ^ { 4 } - 1 } { x ^ { 2 } } d x & b & \int _ { 0 } ^ { 3 } \sqrt { 5 x + 1 } \, d x & c & \int _ { - 2 } ^ { 1 } \frac { 8 } { \left ( 5 - 2 x \right ) ^ { 2 } } \, d x \end{array} \right |$$

Answer

$$\begin{array} { l l l } \text{Answer} \\ \quad a \quad \int _ { 1 } ^ { 2 } \frac { 6 x ^ { 4 } - 1 } { x ^ { 2 } } d x = \int _ { 1 } ^ { 2 } ( 6 x ^ { 2 } - x ^ { - 2 } ) d x \\ & & = \left [ \frac { 6 } { 3 } \, x ^ { 3 } + x ^ { - 1 } \right ] _ { 1 } ^ { 2 } \\ & & = ( 2 ( 2 ) ^ { 3 } + ( 2 ) ^ { - 1 } ) - ( 2 ( 1 ) ^ { 3 } + ( 1 ) ^ { - 1 } ) \\ & & = \left ( 1 6 + \frac { 1 } { 2 } \right ) - ( 2 + 1 ) \\ & & = 1 3 \frac { 1 } { 2 } \end{array}$$

$$\begin{array} { c } & & - 1 \sqrt { 2 } \\ & & & & \\ & & & & \\ & b _ { 0 } ^ { 3 } \sqrt { 5 x + 1 } d x = \int _ { 0 } ^ { 3 } ( 5 x + 1 ) ^ { 2 } d x \\ & & & & = \left [ \frac { 1 } { ( 5 ) \left ( \frac { 3 } { 2 } \right ) } ^ { 3 } \\ & & & = \left [ \frac { 2 } { 1 5 } ( 5 x + 1 ) ^ { 2 } \right ] _ { 0 } \\ & & & & = \left ( \frac { 2 } { 1 5 } x 1 6 ^ { 2 } \right ) - \left ( \frac { 2 } { 1 5 } x 1 2 \right ) \\ & & & & = \left ( \frac { 1 2 8 } { 1 5 } \right ) - \left ( \frac { 2 } { 1 5 } \right ) \\ & & & & = 8 ^ { 2 } _ { 3 } \\ & & & & & \\ & & & & & \end{array}$$

251

252

$$\begin{array} { c c c } & \int _ { - 2 } ^ { 1 } \frac { 8 } { ( 5 - 2 x ) ^ { 2 } } d x = \int _ { - 2 } ^ { 1 } 8 ( 5 - 2 x ) ^ { - 2 } d x \\ & & = \left [ \frac { 8 } { ( - 2 ) ( - 1 ) } ( 5 - 2 x ) ^ { - 1 } \right ] _ { - 2 } \\ & & = \left [ \frac { 4 } { 5 - 2 x } \right ] _ { - 2 } \\ & & = \left ( \frac { 4 } { 3 } \right ) - \left ( \frac { 4 } { 9 } \right ) \\ & & = \frac { 8 } { 9 } \end{array}$$

## EXERCISE 9E

- 1 Evaluate:
- a ∫ x x 3 d 2 1 2
- d ∫ ( ) -x x 10 d 2 0 3
- 2 Evaluate:
- a x x x ∫ -+     3 2 1 d 2 2 1 2
- d ∫ -x x x (1 ) d 0 1
- 3 Evaluate:
- a ∫ ( ) + -x x 2 3 d 3 1 0
- d x x ∫ ( ) --6 2 d 2 1 1
- 4 a Given that = + y x 2 5 2 , find y x d d .
- b Hence, evaluate ∫ ( ) + x x x 2 5 d 2 2 0 2 .
- 5 a Given that ( ) = -y x 2 3 5 , find y x d d .
- b Hence, evaluate x x x ∫ ( ) -2 d 2 3 4 0 1 .
- 6 a Given that ( ) = + y x 1 10 5 , find y x d d .
- b Hence, evaluate ∫ ( ) + x x x 1 d 4 1 4 .
- b ∫ x x 4 d 3 1 3
- e ∫ ( ) --x x x 4 2 d 2 1 2
- b x x x ∫ -      --8 d 2 2 2 1
- e x x x x ∫ -+ (3 )(8 ) d 4 1 2
- b ∫ + x x 2 1 d 0 4
- e x x ∫ ( ) -9 2 3 d 3 2 3
- c ∫ --x x (2 3) d 1 1
- f ∫ -    x x 2 6 d 2 2 4
- c ∫ + -x x x ( 3)(7 2 ) d 1 2
- f x x x ∫ +       3 2 d 1 4
- c x x ( ) -1 d 3 2

$$\int _ { 1 } ^ { 2 }$$

- f x x ∫ --4 5 2 d 2 2

## 9.6  Area under a curve

Consider the area bounded by the curve = y x 2 , the x -axis and the lines = x 2  and = x 5.

In this image, we can see a graph. There is a line on the graph. There is a number on the graph.

<!-- image -->

The area, A , of the region can be approximated by a series of rectangular strips of thickness x δ (corresponding to a small increase in x ) and height y (corresponding to the height of the function).

In this image, we can see a diagram. There is a graph and a line.

<!-- image -->

This leads to the general rule:

## KEY POINT 9.12

If = f( ) y x is a function with 0, y ù then the area, A , bounded by the curve = f( ) y x , the x -axis and the lines = x a and = x b is given by the formula A y x b = d .

$$\int _ { a } ^ { b }$$

254

## WORKED EXAMPLE 9.10

Find the area of the shaded region.

## Answer

$$\begin{matrix} 1 \\ 1 \end{matrix}$$

(64)

$$<_Python_>     """
    Area = \int _4$$

In Worked example 9.10, the required area is above the x -axis.

If the required area lies below the x -axis, then ∫ f( ) d x x a b will have a negative value. This is because the integral is summing the y values, and these are all negative.

## WORKED EXAMPLE 9.11

Find the area of the shaded region.

## Answer

$$\begin{array} {$$

Area is 36units 2 .

<!-- image -->

<!-- image -->

The required region could consist of a section above the x -axis and a section below the x -axis.

If this happens we must evaluate each area separately.

This is illustrated in Worked example 9.12.

## WORKED EXAMPLE 9.12

Find the total area of the shaded regions.

## Answer

$$I \text{ } & \text{Answer } & \text{$I$ $I$}$$

$$\begin{array} { c c c c c c } & & & = ( 6 ) ^ { 2 } ) - ( 0 ) \\ & & & & = 6 ^ { 2 } _ { 3 } \\ \\ \int _ { 2 } ^ { 6 } x ( x - 2 ) ( x - 6 ) d x = \int _ { 2 } ^ { 6 } \left ( x ^ { 3 } - 8 x ^ { 2 } + 12 x \right ) d x \\ & & & = \left [ - x ^ { 4 } - \frac { 8 } { 3 } x ^ { 3 } + 6 x ^ { 2 } \right ] _ { 2 } ^ { 6 } \\ & & & = \left ( \frac { 1 } { 4 } ( 6 ) ^ { 4 } - \frac { 8 } { 3 } ( 6 ) ^ { 3 } + 6 ( 6 ) ^ { 2 } \right ) - \left ( \frac { 1 } { 4 } ( 2 ) ^ { 4 } - \frac { 8 } { 3 } ( 2 ) ^ { 3 } + 6 ( 2 ) ^ { 2 } \right ) \\ & & & & = ( - 3 6 ) - \left ( 6 ^ { 2 } _ { 3 } \right ) \\ & & & & = - 4 2 ^ { 2 } _ { 3 } \\ \end{array}$$

Hence, the total area of the shaded regions = + = 6 42 49 units 2 3 2 3 1 3 2 .

## Area enclosed by a curve and the y -axis

<!-- image -->

<!-- image -->

255

256

## KEY POINT 9.13

If = f( ) x y is a function with 0, x ù then the area, A , bounded by the curve = f( ) x y , the y -axis

$$\text{ and the lines } y = a \text{ and } y = b \text{ is given by the formula } A = \int _ { a } ^ { b } x d y \text{ when } x \geq 0.$$

## WORKED EXAMPLE 9.13

Find the area of the shaded region.

## Answer

$$\begin{array} { l l l } & & \text{Answer} \\ & & \text{Area} = \int _ { 0 } ^ { 4 } x d y \\ & & & = \int _ { 0 } ^ { 4 } ( 4 y - y ^ { 2 } ) d y \\ & & & = \left [ \frac { 4 } { 2 } y ^ { 2 } - \frac { 1 } { 3 } y ^ { 3 } \right ] _ { 0 } ^ { 4 } \\ & & & = \left ( 2 ( 4 ) ^ { 2 } - \frac { 1 } { 3 } ( 4 ) ^ { 3 } \right ) - \left ( 2 ( 0 ) ^ { 2 } - \frac { 1 } { 3 } ( 0 ) ^ { 3 } \right ) \\ & & & = \int _ { 3 } ^ { 2 } \\ & & \text{Area} is \int _ { 3 } ^ { 2 } \text{ units} ^ { 2 }. \end{array}$$

Area is 10 units 2 3 2 .

## EXERCISE 9F

- 1 Find the area of each shaded region.

<!-- image -->

<!-- image -->

<!-- image -->

O

<!-- image -->

1

3

<!-- image -->

<!-- image -->

The diagram shows the curve = --y x x x ( 2)( 4)  that crosses the x -axis at the points O A (0, 0), (2, 0)  and B (4, 0).

Show by integration that the area of the shaded region R 1 is the same as the area of the shaded region R 2 .

- 3 Sketch the curve an d find the total area bounded by the curve and the x -axis for each of these functions.
- 4 Sketch the curve and find the enclosed area for each of the following.
- a = -+ y x x 6 9 4 2 , the x -axis and the lines = x 0  and = x 1
- b = + y x x 2 5 2 , the x -axis and the lines = x 1 and = x 2
- c = + y x 5 8 3 , the x -axis and the lines = x 2  and = x 5
- d = y x 3 , the x -axis and the lines = x 1 and = x 4
- e = y x 4 , the x -axis and the lines = x 1 and = x 9
- f = + y x 2 3, the x -axis and the line = x 3
- 5 Sketch the curve an d find the enclosed area for each of the following.
- a = y x 3 , the y -axis and the lines = y 8  and = y 27
- b = + x y 1 2 , the y -axis and the lines = -y 1 and = y 2

- a = - + y x x x ( 3)( 1)

- b ( ) = - y x x 9 2

- c = - + y x x x (2 1)( 2)

- d = - + - y x x x ( 1)( 1)( 4)

The diagram shows the curve = + y x 2 1. The shaded region is bounded by the curve, the y -axis and the line = y 3. Find the area of the shaded region.

In this image, we can see a graph.

<!-- image -->

258

7

In this image, we can see a graph.

<!-- image -->

Find the area of the region bounded by the curve = + y x 2 1 2 , the line = y 9  and the y -axis.

- 8 a Find the area of the region enclosed by the curve = y x 12 2 , the x -axis and the lines = x 1 and = x 4.
- b The line = x p divides the region in part a into two parts of equal area. Find the value of p .
- b Use your result from part a to evaluate the area of the shaded region.

In this image, we can see a diagram. There are some lines and points.

<!-- image -->

10

<!-- image -->

Find the shaded area enclosed by the curve = y x 2 ,  the  line + = x y 8 and the x -axis.

- 11 The tangent to the curve = -y x x 8 2 at the point (2, 12) cuts the x -axis at the point P .
- a Find the coordinates of P .
- b Find the area of the shaded region.

<!-- image -->

<!-- image -->

<!-- image -->

13

14

<!-- image -->

The diagram shows the curve = + y x 2 1  that intersects the x -axis at A . The normal to the curve at B (4, 3) meets the x -axis at C . Find the area of the shaded region.

<!-- image -->

, 12) lie

Th e figure shows part of the curve = y x f( ). The points P (2, 4) and Q (7 on the curve. Given that y x ∫ = d 42 2 7 , find the value of x y ∫ d . 4 12

In this image, we can see a diagram. There is a line, which is drawn on the ground. There is a point named A, which is located at the bottom of the image.

<!-- image -->

The figure shows part of the curve g( ) y x . The points A (2, 8) and B

= (6, 1) lie

$$\text{on the curve. Given that } \int _ { 2 } ^ { 6 } y d x = 1 6, \, \text{find the value of } \int _ { 1 } ^ { 8 } x d y.$$

## WEB

Try the following resources on the Underground

Mathematics website:

- What else do you know?
- Slippery areas.

260

## 9.7  Area bounded by a curve and a line or by two curves

The following example shows a possible method fo r finding the area enclosed by a curve and a straight line.

## WORKED EXAMPLE 9.14

The diagram shows the curve = -+ -y x x 8 5 2 and the line = + y x 1 that intersect at the points (1, 2) and (6, 7).

Find the area of the shaded region.

## Answer

= -Area area under curve area of trapezium

- x x x ∫ ( ) = -+ --× + × 8 5 d 1 2 (2 7) 5 2 1 6
- x x x = -+ -      -1 3 4 5 22 3 2 1 6 1 2

$$\Big | \quad = \left ( - \frac { 1 } { 3 } ( 6 ) ^ { 3 } + 4 ( 6 ) ^ { 2 } - 5 ( 6 ) \right ) - \left ( - \frac { 1 } { 3 } ( 1 ) ^ { 3 } + 4 ( 1 ) ^ { 2 } - 5 ( 1 ) \right ) - 2 2 \frac { 1 } { 2 }$$

- = 20 units 5 6 2

There is an alternative method for finding the shaded area in Worked example 9.14.

<!-- image -->

If two functions, x f( ) and x g( ), intersect at = x a and = x b , then the area, A , enclosed between the two curves is given by:

## KEY POINT 9.14

$$\Big | \quad A = \int _ { a } ^ { b } \mathfrak { f } ( x ) \, d x - \int _ { a } ^ { b } g ( x ) \, d x \quad \text{ or } \quad A = \int _ { a } ^ { b } \left [ \mathfrak { f } ( x ) - g ( x ) \right ] d x$$

$$x$$

<!-- image -->

So for the area enclosed by = -+ -y x x 8 5 2 and = + y x 1:

<!-- image -->

Using = -+ -x x x f( ) 8 5 2 and = + x x g( ) 1 gives:

$$\mathbb { m } g \, \iota ( \lambda ) - \lambda ^ { 2 } \, \mathbb { m } g ( \lambda ) - \lambda ^ { 2 } \, \mathbb { m } g ( \lambda ) - \lambda ^ { 2 } \, \mathbb { m } g ( \lambda ). \\ \intertext { A e a } = \int _ { 1 } ^ { 6 } f ( x ) \, d x - \int _ { 1 } ^ { 6 } g ( x ) \, d x \\ = \int _ { 1 } ^ { 6 } \left ( - x ^ { 2 } + 8 x - 5 \right ) d x - \int _ { 1 } ^ { 6 } ( x + 1 ) \, d x \\ = \int _ { 1 } ^ { 6 } \left ( - x ^ { 2 } + 7 x - 6 \right ) d x \\ = \left [ - \frac { 1 } { 3 } \, x ^ { 3 } + \frac { 7 } { 2 } \, x ^ { 2 } - 6 x \right ] _ { 1 } ^ { 6 } \\ = \left ( - \frac { 1 } { 3 } \, ( 6 ) ^ { 3 } + \frac { 7 } { 2 } \, ( 6 ) ^ { 2 } - 6 ( 6 ) \right ) - \left ( - \frac { 1 } { 3 } \, ( 1 ) ^ { 3 } + \frac { 7 } { 2 } \, ( 1 ) ^ { 2 } - 6 ( 1 ) \right ) \\ = \, 2 0 \frac { 6 } { 6 } \, \text{units} ^ { 2 } \\ \intertext { This alternative method is the easiest method to use in the next example }$$

This alternative method is the easiest method to use in the next example.

## WORKED EXAMPLE 9.15

The diagram shows the curve = --y x x 6 2 2 and the line = -y x 2 9, which intersect when = x 1 and = x 7.

Find the area of the shaded region.

## Answer

$$\begin{array} { l l l } & & \text{Answer} \\ & & \text{Area} = \int _ { 1 } ^ { 7 } ( 2 x - 9 ) \, d x - \int _ { 1 } ^ { 7 } ( x ^ { 2 } - 6 x - 2 ) \, d x \\ & & & \int _ { 1 } ^ { 7 } ( - x ^ { 2 } + 8 x - 7 ) \, d x \\ & & & \left [ - \frac { 1 } { 3 } x ^ { 3 } + 4 x ^ { 2 } - 7 x \right ] _ { 1 } ^ { 7 } \\ & & & \left ( - \frac { 1 } { 3 } ( 7 ) ^ { 3 } + 4 ( 7 ) ^ { 2 } - 7 ( 7 ) \right ) - \left ( - \frac { 1 } { 3 } ( 1 ) ^ { 3 } + 4 ( 1 ) ^ { 2 } - 7 ( 1 ) \right ) \\ & & & \text{$row units} ^ { 2 } \end{array}$$

- = 36 units 2

<!-- image -->

262

## EXERCISE 9G

1

<!-- image -->

Find the area of the region bounded by the curve = + -y x x 5 6 2 , the line = x 4  and the line = y 5.

<!-- image -->

The diagram shows the curve ( ) = -y x 3 2 and the line = -y x 2 3  that intersect at points A and B . Find the area of the shaded region.

In this image we can see a diagram. There are two lines and a point.

<!-- image -->

2

3

The diagram shows the curve = -+ -y x x 11 18 2 and the line + = x y 2 12 . Find the area of the shaded region.

- 4 Sketch the following curves and lines an d find the area enclosed between their graphs.
- a = -y x 3 2 and = y 6
- b = -+ -y x x 12 20 2 and = + y x 2 1
- c = -+ y x x 4 4 2 and + = x y 2 12
- 5 Sketch the curves = y x 2 and = -y x x (2 )  and find the area enclosed between the two curves.

7

8

<!-- image -->

The diagram shows the curve = + y x 4  and the line = + y x 1 2  meeting at the points -( 4, 0)  and (0, 2).

2

Find the area of the shaded region.

In this image, we can see a diagram. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a point, which is in white color. There is a line, which is in blue color. There is a

<!-- image -->

x

The curve = + y x 2 3  meets the y -axis at the point Q .

The tangent at the point P (3, 3) to this curve meets the y -axis at the point R .

- a Find the equation of the tangent to the curve at P .
- b Find the exact value of the area of the shaded region PQR .

In this image, we can see a diagram. There is a line in the image. There is a point on the line. There is a symbol.

<!-- image -->

The diagram shows the curve = + -y x x 10 9 2 . Points P (6, 28) and Q (10, 0) lie on the curve. The tangent at P intersects the x -axis at R .

- a Find the equation of the tangent to the curve at P .
- b Find the area of the shaded region.

264

9

10

In this image, we can see a diagram. There is a line in the image. There is a point on the line. There is a point on the line. There is a line. There is a point on the line.

<!-- image -->

The diagram shows the curve = -y x x 4 3 .

The point P has coordinates (2 , 0) and the point Q has coordinates ( 4, 48). -

- a Find the equation of the tangent to the curve at P .
- b Find the area of the shaded region.

<!-- image -->

The diagram shows part of the curve = --y x 5 10 and the tangent to the curve at P (9, 4).

- a Find the equation of the tangent to the curve at P .
- b Find the area of the shaded region. Give your answer correct to 3 signi ficant figures.

## 9.8  Improper integrals

In this section, we will consider what happens if some part of a de finite integral becomes infinite. These are known as improper integrals , and we will look at two different types.

## Type 1

These are definite integrals that have either one limit infinite or both limits infinite.

$$\text{Examples of these are } \int _ { 1 } ^ { \infty } \frac { 1 } { x ^ { 2 } } d x \text{ and } \int _ { - \infty } ^ { - 2 } \frac { 1 } { x ^ { 3 } } d x.$$

## KEY POINT 9.15

We can evaluate integrals of the form ∫ ∞ f( ) d x x a by replacing the infinite limit with a finite value, , X and then taking the limit as → ∞ X , provided the limit exists.

## KEY POINT 9.16

We can evaluate integrals of the form f(

) d

x

x

by replacing the infinite limit with a finite value,

-∞

∫

and then taking the limit as → -∞ , X provided the limit exists.

## WORKED EXAMPLE 9.16

Show that the improper integral 1 d 2 1 x x ∫ ∞ ha s a finite value and find this value.

## Answer

$$\begin{array} { c } \text{Answer} \\ \int _ { 1 } ^ { X _ { 1 } } \frac { 1 } { 2 } d x = \int _ { 1 } ^ { X } x ^ { 2 } d x \\ \quad & = [ - x ^ { - 1 } ] _ { 1 } ^ { X } \\ \quad & = ( - \frac { 1 } { X } ) - ( - \frac { 1 } { 1 } ) \\ \quad & = 1 - \frac { 1 } { X } \\ \end{array} \\ \text{As} \, X \rightarrow \infty, \frac { 1 } { X } \rightarrow 0 \\ \,. \int _ { 1 } ^ { \infty } \frac { 1 } { 2 } d x = 1 - 0 = 1 \\ \int _ { 1 } ^ { \infty } \frac { 1 } { X } \end{array}$$

$$\begin{smallmatrix} \infty & 1 \\ \end{smallmatrix}$$

Hence, the improper integral 1 d 2 1 x x ∫ ∞ ha s a finite value of 1.

## WORKED EXAMPLE 9.17

$$\Big | \, \text{ The diagram shows part of the curve } y = \frac { 1 } { \left ( 1 - x \right ) ^ { 3 } } \,.$$

Show that as , p → -∞ the shaded area tends t o a finite value and find this value.

## Answer

<!-- image -->

<!-- image -->

Write the integral with an upper limit X .

b

X

,

265

266

<!-- image -->

Hence, as , p → -∞ the shaded area tends to a finite value of 1 2 .

## Type 2

These are integrals where the function to be integrated approaches an in finite value (or approaches ± infinity) at either or both end points in the interval (of integration).

$$\text{For example, } \int _ { - 1 } ^ { 1 } \frac { 1 } { x ^ { 2 } } d x \text{ is an invalid integral because } \frac { 1 } { x ^ { 2 } } \text{ is not defined when } x = 0.$$

However, 1 d 2 0 x x ∫ is an improper integral because 1 2 x tends to infinity as 0 x →

∫ -0. 1 and it is well-defined everywhere else in the interval of integration.

For this section we will consider only those improper integrals where the function is not defined at one end of the interval.

## KEY POINT 9.17

We can evaluate integrals of the form ∫ f( ) d x x a b where f( ) x is not defined when = x a can be evaluated by replacing the limit a with an X and then taking the limit as → X a , provided the limit exists.

## KEY POINT 9.18

We can evaluate integrals of the form ∫ f( ) d x x a b where f( ) x is not defined when = x b by replacing the limit b with an X and then taking the limit as → , X b provided the limit exists.

## WORKED EXAMPLE 9.18

Find the value, if it exists, of 5 d 2 0 2 ∫ x x . Answer The function  f( ) 5 2 = x x is not de fined when 0 = x . x x x x x X X X X X ∫ ∫ = = -    = -    --    = ---5 d 5 d 5 5 2 5 5 5 2 2 2 2 2 1 2 Write the integral with a lower limit X .

$$\Big |   As \, X \to 0 \,, \, \frac { 5 } { X } \, tends \, to \,infinity.$$

$$\begin{array} { c } & & \\ & & \\ & & \\ & & \\ & &$$

## WORKED EXAMPLE 9.19

The diagram shows part of the curve = -y x 3 2 .

Show that as → p 2  the shaded area tends to a finite value and find this value.

## Answer

$$\begin{array} { c } \cdot \cdot \cdot \cdot \cd$$

$$\Big | \text{ } As \, p \rightarrow 2, \, \int _ {$$

Hence, as p → 2 the shaded area tends t o a finite value of  6 2.

## EXERCISE 9H

- 1 Show that each of the following improper integrals ha s a finite value and, in each case, find this value.
- a 2 d 2 1 x x ∫ ∞ b 4 d 5 4 x x ∫ ∞ c 10 d 3 2 x x ∫ -∞ -d 4 d 4 x x x ∫ ∞ e 5 d 0 25 x x ∫ f 4 4 d 4 8 x x ∫ -g 3 3 d 0 3 x x ∫ -h 1 (1 ) d 2 2 x x ∫ -∞ i 2 4 ( 2) d 2 3 1 x x x ∫ + +       ∞

<!-- image -->

267

268

In this image, we can see a diagram. There is a text on the image.

<!-- image -->

Show that as →∞ p , the shaded area tends to the value 2.

- 3 Show that none of the following improper integrals exists.
- a d x
- d d x

$$\begin{array} {$$

## 9.9  Volumes of revolution

Consider the area bounded by the curve = y x 2 , the x -axis, and the lines = x 2  and = x 5.

<!-- image -->

When this area is rotated about the x -axis through ° 360  a solid of revolution is formed. The volume of this solid is called a volume of revolution .

<!-- image -->

We can approximate the volume, V , of the solid by a series of cylindrical discs of thickness x δ (corresponding to a small increase in x ) and radius y (corresponding to the height of the function).

The volume of each cylindrical disc is π δ 2 y x . An approximation for V is then ∑ π δ 2 y x .

<!-- image -->

$$\overline { A s } \, \delta x \to 0, \text{ then }$$

This leads to a general formula:

## KEY POINT 9.19

The volume, V , obtained when the function = f( ) y x is rotated through ° 360  about the x -axis between

$$\text{ the boundary values } x = a \text{ and } x = b \text{ is given by the formula } V = \int _ { a } ^ { b } \pi y ^ { 2 } d x.$$

## WORKED EXAMPLE 9.20

Find the volume obtained when the shaded region is rotated through ° 360  about the x -axis.

## Answer

$$\begin{array} { c } \text{Answer} \\ \text{Volume} = \pi \int _ { 1 } ^ { 2 } y ^ { 2 } d x = \pi \int _ { 1 } ^ { 2 } \left ( \frac { 9 } { 3 x + 2 } \right ) ^ { 2 } d x \\ & = \pi \int _ { 1 } ^ { 2 } 8 1 ( 3 x + 2 ) ^ { - 2 } d x \\ & = \pi \left [ \frac { 8 1 } { 3 ( - 1 ) } ( 3 x + 2 ) ^ { - 1 } \right ] _ { 1 } ^ { 2 } \\ & = \pi \left [ \frac { - 2 7 } { ( 3 x + 2 ) } \right ] _ { 1 } ^ { 2 } \\ & = \pi \left [ \left ( \frac { - 2 7 } { 8 } \right ) - \left ( \frac { - 2 7 } { 5 } \right ) \right ] \\ & = \frac { 8 1 \pi } { 4 0 } \text{ units} ^ { 3 } \\ \end{array}$$

Sometimes a curve is rotated about the y -axis. In this case the general rule is:

## KEY POINT 9.20

The volume, V , obtained when the function = f( ) x y is rotated through ° 360  about the y -axis between

$$\text{ the boundary values } y = a \text{ and } y = b \text{ is given by the formula } V = \int _ { a } ^ { b } \pi x ^ { 2 } d y.$$

<!-- image -->

<!-- image -->

269

270

## WORKED EXAMPLE 9.21

Find the volume obtained when the shaded region is rotated through ° 360 about the y -axis.

<!-- image -->

## Answer

$$\begin{array} { c } \text{Answer} \\ \text{Volume} = \pi \int _ { 2 } ^ { 5 } x ^ { 2 } d y = \pi \int _ { 2 } ^ { 5 } y d y \\ \quad = \pi \left [ \frac { y ^ { 2 } } { 2 } \right ] _ { 2 } ^ { 5 } \\ \quad = \pi \left [ \left ( \frac { 2 5 } { 2 } \right ) - \left ( \frac { 4 } { 2 } \right ) \right ] \\ \quad = \frac { 2 1 \pi } { 2 } \text{ units} ^ { 3 } \end{array}$$

Using the given = 2 y x .

## WORKED EXAMPLE 9.22

Find the volume of the solid obtained when the shaded region is rotated through ° 360  about the x -axis.

## Answer

When the shaded region is rotated about the x -axis, a solid with a cylindrical hole is formed.

The radius of the cylindrical hole is 1 unit and the length of the hole is 2 units.

<!-- image -->

$$<_C_>     The radius of the cylindrical hole is 1  unit and the length (
                                                                                                                                                                                                        
    Volume of solid = \pi \n ^ { 2 } d x - volume of cylinder$$

- 1 Find the volume obtained when the shaded region is rotated through ° 360  about the x -axis.
- 2 Find the volume obtained when the shaded region is rotated through ° 360  about the y -axis.
- 3 The diagram shows part of the curve = y a x , where . 0 a . The volume obtained when the shaded region is rotated through ° 360  about the x -axis is π 18 .   Find the value of a .

In this image, we can see a graph. On the graph, we can see the numbers.

<!-- image -->

In this image, we can see a graph. On the graph, we can see the numbers.

<!-- image -->

<!-- image -->

<!-- image -->

y

- 4 The diagram shows part of the curve = + + + 4 3 2 3 2 y x x x . Find the volume obtained when the shaded region is rotated through ° 360 about the x -axis.

In this image, we can see a diagram. There is a line on the diagram. There is a text on the image.

<!-- image -->

272

- 5 The diagram shows part of the line + = 3 8 24 x y . Rotating the shaded region through ° 360  about the x -axis would give a cone of base radius 3 and perpendicular height 8.

Find the volume of the cone using:

- a integration
- b the formula for the volume of a cone.
- 6 a Sketch the graph of = -( 2) 2 y x .
- b Find the volume of the solid formed when the enclosed region bounded by the curve, the x -axis and the y -axis is rotated through ° 360  about the x -axis.
- 7 The diagram shows part of the curve = -5 y x x .

The curve meets the x -axis at O and P .

- a Find the coordinates of P .
- b Find the volume obtained when the shaded region is rotated through ° 360  about the x -axis.
- 8 The diagram shows part of the curve = -x y 9 1 2 that intercepts the y -axis at the point P . The shaded region is bounded by the curve, the y -axis and the line = y 1.
- a Find the coordinates of P .
- b Find the volume obtained when the shaded region is rotated through ° 360  about the y -axis.
- 9 The diagram shows part of the curve = + y x x 3 2 .

<!-- image -->

The line = y 7  intersects the curve at the points P and Q .

- a Find the coordinates of P and Q .
- b Find the volume obtained when the shaded region is rotated through ° 360  about the x -axis.
- 10 The diagram shows part of the curve = + 2 2 1 y x . The shaded area is rotated through ° 360  about the x -axis between = 0 x and = x p . Show that as →∞ p , the volume approaches the value π 2 .
- 11 The diagram shows part of the curve 25 2 y x = -. The point (4, 3) P lies on the curve.
- a Find the volume obtained when the shaded region is rotated through ° 360  about the y -axis.
- b Find the volume obtained when the shaded region is rotated through ° 360  about the x -axis.

<!-- image -->

<!-- image -->

O

<!-- image -->

<!-- image -->

<!-- image -->

- 12 The diagram shows the curve y x = -4 and the line + = 2 4 x y that intersect at the points (4, 0) and  (0, 2).
- a Find the volume obtained when the shaded region is rotated through ° 360  about the x -axis.
- b Find the volume obtained when the shaded region is rotated through ° 360  about the y -axis.
- 13 A mathematical model for the inside of a bowl is obtained by rotating the curve + = 100 2 2 x y through ° 360  about the y -axis between = -8 y and = 0 y . Each unit of x and y represents 1cm.
- a Find the volume of the bowl.

The bowl i s filled with water to a depth of 3cm.

- b Find the volume of water in the bowl.
- 14 Use integration to prove that the volume, V cm 3 , of a sphere with radius P

r

cm is given by the formula

=

π

4

3

3

V

r

.

## Checklist of learning and understanding

## Integration as the reverse of differentiation

- /uni25CF x x x [ ] = If d d F( ) f( ), then ∫ = + f( ) d F( ) x x x c .

## Integration formulae

- /uni25CF x x n x c n n ∫ = + + + d 1 1 1 (where c is a constant and ≠ -1 n )
- /uni25CF ax b x a n ax b c n n n ∫ + = + + + ≠ -+ ( ) d 1 ( 1) ( ) ( 1 1 and ≠ 0) a

## Rules for indefinite integration

- /uni25CF ∫ ∫ = f( ) d f( ) d k x x k x x , where k is a constant
- /uni25CF ∫ ∫ ∫ [ ] ± = ± f( ) g( ) d f( ) d g( ) d x x x x x x x

## Rules for definite integration

- /uni25CF ∫ ∫ [ ] = + = = -If f( ) d F( ) ,  then f( ) d F( ) F( ) F( ) x x x c x x x b a a b a b .
- /uni25CF ∫ ∫ = f( ) d f( ) d k x x k x x a b a b , where k is a constant.

<!-- image -->

<!-- image -->

274

- /uni25CF ∫ ∫ ∫ [ ] ± = ± f( ) g( ) d f( ) d g( ) d x x x x x x x a b a b a b
- /uni25CF ∫ ∫ = -f( ) d f( ) d x x x x a b b a

## Area under a curve

<!-- image -->

O

- /uni25CF The area, A , bounded by the curve y x = f( )  , the x -axis and the lines x a = and x b = is given by the formula:

$$A = \int _ { a } ^ { b } y d x \text{ when } y \geq 0$$

$$( \text{or } A = \int _ { a } ^ { b } \text{f} ( x ) \, d x \text{ when } \text{f} ( x ) \geq 0 \, ).$$

<!-- image -->

x

- /uni25CF The area, A , bounded by the curve x y = f( ), the y -axis and the lines y a = and y b = is given by the formula:

In this image we can see a diagram. In the diagram we can see a graph.

<!-- image -->

- /uni25CF The area, A , enclosed between y x = f( )  and y x = g( )  is given by the formula:

$$A = \int _ { a } ^ { b } \left [ \mathfrak { f } ( x ) - g ( x ) \right ] \mathfrak { d } x$$

where a and b are the x -coordinates of the points of intersection of the functions f and g.

## Improper integrals

- /uni25CF Integrals of the form ∫ ∞ f( ) d x x a can be evaluated by r eplacing the infinite limit with a finite value, X , and then taking the limit as X → ∞ , provided the limit exists.
- /uni25CF Integrals of the form ∫ -∞ f( ) d x x b can be evaluated by replacing the infinite limit with a finite value, X , and then taking the limit as X → -∞ , provided the limit exists.
- /uni25CF Integrals of the form ∫ f( ) d x x a b where x f( ) is not defined when x a = can be evaluated by replacing the limit a with an X and then taking the limit as X a → , provided the limit exists.
- /uni25CF Integrals of the form ∫ f( ) d x x a b where x f( ) is not defined when x b = can be evaluated by replacing the limit b with an X and then taking the limit as X b → , provided the limit exists.

## Volume of revolution

- /uni25CF The volume, V , obtained when the function y x = f( )  is rotated through ° 360  about the x -axis between the boundary values x a = and x b = is given by the formula V y x a b ∫ = π 2 d .
- /uni25CF The volume, V , obtained when the function x y = f( )  is rotated through ° 360  about the y -axis between the boundary values y a = and y b = is given by the formula V x y a b ∫ = π 2 d .

276

## END-OF-CHAPTER REVIEW EXERCISE 9

- 1 The function f is such that ′ = + f ( ) 12 10 3 x x x and -= f ( 1) 1  . Find f( ) x .

[3]

- 2 Find ∫ -      x x x 5 2 d 2
- . [3]
- 3 A curve is such that = -d d 6 5 2 y x x x and the point (3, 5.5) lies on the curve. Find the equation of the curve. [4]
- 4 A curve has equation = f( ) y x . It is given that ′ = + -f ( ) 3 2 8 3 x x x and that = f(2) 3. Find f( ) x . [5]

5

O

<!-- image -->

The diagram shows part of the curve = + 6 1 2 x y . The shaded region is bounded by the curve, the y -axis, and the lines = 1 y and = 3 y . Find the volume, in terms of π , when this shaded region is rotated through ° 360 about the y -axis. [5]

- 6 A function is defined for x ∈  and is such that ′ = -x x f ( ) 6 6. The range of the function is given by ù f( ) 5 x .
- has a stationary value. [1]
- a State the value of x for which f( ) x
- b Find an expression for f( ) x in terms of x .

[4]

<!-- image -->

The diagram shows the curve 6 2 y x x = -and the line 5 y = . Find the area of the shaded region. [6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q4 June 2010

- 8 a Sketch the curve ( 3) 2 2 y x = -+ .

[1]

- b The region enclosed by the curve, the x -axis, the y -axis, the line 3 x = is rotated through 360 ° about the x -axis. Find the volume obtained, giving your answer in terms of π . [6]
- 7

<!-- image -->

9

- 10
- 11

<!-- image -->

The diagram shows the curve 2 1 2 y x = -and the straight line  3 2 1 y x = -.

The curve and straight line intersect at

1

x

=

and

x

a

=

, where

a

is a constant.

- i Show that 5 a = .

[2]

- ii Find, showing all necessary working, the area of the shaded region.

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q8 November 2012

<!-- image -->

The diagram shows the curve 1 2 y x meeting the x -axis at A and the y -axis at B

= + .

The y -coordinate of the point C on the curve is 3.

- i Find the coordinates of B and C . [2]
- ii Find the equation of the normal to the curve at C .

[4]

- iii Find the volume obtained when the shaded region is rotated through 360 ° about the y -axis. [5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 November 2011

<!-- image -->

The diagram shows the line 1 y = and part of the curve 2 1 y x = + .

- i Show that the equation 2 1 y x = can be written in the form 4 1. 2 x y = -
+ [1]
- ii Find y y ∫ -      4 1 d 2 1 2 . Henc
- e find the area of the shaded region. [5]
- iii The shaded region is rotated through 360 ° about the y -axis. Find the exact value of the volume of revolution obtained. [5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 June 2012

2

277

278

- 12 A curve has equation f( ) y x = and is such that ′ = + --f ( ) 3 3 10 1 2 1 2 x x x .

1

- i By using the substitution 2 u x = , or otherwise , find the values of x for which the curve f( ) y x = has stationary points.

[4]

- ii Find x ′′ f ( )  and hence, or otherwise, determine the nature of each stationary point. [3]
- iii It is given that the curve f( ) y x = passes through the point  (4, 7) -. Find  f( ) x .

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 June 2013

<!-- image -->

The diagram shows part of the curve 8 3 4 y x = + . The curve intersects the y -axis at (0, 4 ) A . The normal to the curve at A intersects the line 4 x = at the point B .

- i Find the coordinates of B .

[5]

- ii Show, with all necessary working, that the areas of the regions P and Q are equal.

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 June 2015

<!-- image -->

The diagram shows the curve (3 2 ) 3 y x = -and the tangent to the curve at the point 1 2 , 8       .

- i Find the equation of this tangent, giving your answer in the form y mx c = + .

[5]

- ii Find the area of the shaded region.

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 November 2013

- 13
- 14

<!-- image -->

15

The diagram shows parts of the curves (4 1) 1 2 y x = + and 1 2 1 2 y x = + intersecting at points (0, 1) P and

In this image, we can see a diagram with a line and a point.

<!-- image -->

(2, 3) Q . The angle between the   tangents to the curves at Q is α .

- i Find , α giving your answer in degrees correct to 3 signi
- ficant figures. [6]
- ii Find by integration the area of the shaded region.

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 November 2014

279

280

## CROSS-TOPIC REVIEW EXERCISE 3

- 1 A curve is such that d d 2 3 2 = -y x x . Given that the curve passes through the point ( 3, 2) --, find the equation of the curve. [4]
- 2 A curve is such that d d 2 8(3 4) 1 2 = -+ -y x x .
- i A point P moves along the curve in such a way that the x -coordinate is increasing at a constant rate of 0.3 units per second. Find the rate of change of the y -coordinate as P crosses the y -axis. [2]
- The curve intersects the y -axis where 4 3 = y .
- ii Find the equation of the curve.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q4 June 2016

- 3 A curve is such that d d 3 6 1 2 = -y x x and the point (9, 2) lies on the curve.
- i Find the equation of the curve.

[4]

- ii Find the x -coordinate of the stationary point on the curve and determine the nature of the stationary point. [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q6 June 2010

- 4 A curve is such that d d 3 (1 2 ) 2 = + y x x and the point 1, 1 2     lies on the curve.
- i Find the equation of the curve.

[4]

- ii Find the set of values of x for which the gradient of the curve is less than 1 3 . [3]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 June 2011

<!-- image -->

The diagram shows parts of the curves (2 1) 2 = -y x and 1 2 2 = -y x , intersecting at points A and B .

- i State the coordinates of A .

[1]

- ii Find, showing all necessary working, the area of the shaded region.

[6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q7 November 2016

- 5

- 6 A curve has equation f( ) = y x and it is given that  f 3 2 1 2 1 2 ′( ) = --x x x .

The point A is the only point on the curve at which the gradient is 1 -.

- i Find the x -coordinate of A .

[3]

- ii Given that the curve also passes through the point (4, 10) , find the y -coordinate of A , giving your answer as a fraction. [6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 November 2016

<!-- image -->

The diagram shows a metal plate. The plate has a perimeter of 50 cm and consists of a rectangle of width 2 cm r and height x cm, and a semicircle of radius r cm.

- a Show that the area, cm 2 A , of the plate is given by = --π 50 2 1 2 2 2 A r r r . [4]

Given that

x

and

r

can vary:

- b show that A has a stationary value when = + π 50 4 r
- [4]
- c find this stationary value of A and determine the nature of this stationary value. [2]
- 8 A line has equation 2 = + y x c and a curve has equation 8 2 2 = --y x x .
- i For the case where the line is a tangent to the curve, find the value of the constant c
- . [3]
- ii For the case where 11 = c , find the x -coordinates of the points of intersection of the line and the curve. Find also, by integration, the area of the region between the line and the curve. [7]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 June 2014

- 9 The equation of a curve is 9 2 = -y x .
- i Find an expression for d d y x and determine, with a reason, whether the curve has any stationary points. [3]
- ii Find the volume obtained when the region bounded by the curve, the coordinate axes and the line 1 = x is rotated through 360 ° about the x -axis. [4]
- iii Find the set of values of k for which the line = + y x k intersects the curve at two distinct points. [4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 November 2010

7

281

282

- 10 A function f is defined as  f( ) 4 2 1 = + x x for 0 &gt; x .
- a Find an expression, in terms of x , for  f ′( ) x and explain how your answer shows that  f  is a decreasing function. [3]
- ( ) . [4]
- b Find an expression, in terms of x , for -f 1 x and find the domain of f 1 -
- c On a diagram, sketch the graph of f( ) = y x and the graph of f ( ) 1 = -y x , making clear the relationship between the two graphs. [4]
- 11 A curve is such that d d 1 2 1 2 = --y x x x . The curve passes through the point 4, 2 3     .
- i Find the equation of the curve. [4]
- ii Find d d 2 2 y x .

[2]

- iii Find the coordinates of the stationary point and determine its nature. [5]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q12 June 2014

- 12 The function f is defined for 0 . x and is such that  f 2 2 2 ′( ) = -x x x . The curve f( ) = y x passes through the point (2, 6) P .
- i Find the equation of the normal to the curve at P .

[3]

- ii Find the equation of the curve.
- [4]
- iii Find the x -coordinate of the stationary point and state with a reason whether this point is a maximum or a minimum. [4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q9 November 2014

- 13 The point (3, 5) P lies on the curve 1 1 9 5 = ---y x x .
- i Find the x -coordinate of the point where the normal to the curve at P intersects the x -axis. [5]
- ii Find the x -coordinate of each of the stationary points on the curve and determine the nature of each stationary point, justifying your answers. [6]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 November 2016

<!-- image -->

The diagram shows part of the curve ( 2) 4 = -y x and the point (1, 1) A on the curve.

The tangent at A cuts the x -axis at B and the normal at A cuts the y -axis at C .

- i Find the coordinates of B and C .

[6]

- ii Find the distance AC , giving your answer in the form a b , where a and b are integers. [2]

iii Find the area of the shaded region.

[4]

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q10 June 2013

- 14

<!-- image -->

15

<!-- image -->

1

The diagram shows part of the curve (1 4 ) 2 = + y x and a point (6, 5) P lying on the curve. The line PQ intersects the x -axis at (8, 0) Q .

- i Show that PQ is a normal to the curve.

[5]

- ii Find, showing all necessary working, the exact volume of revolution obtained when the shaded region is rotated through 360 ° about the x -axis. [7]

[ In part ii you ma y find it useful to apply the fact that the volume, V , of a cone of base radius r and vertical

1

$$\text{height} \, h, \, \text{is given by } V = \frac { 1 } { 3 } \, \i r ^ { 2 } h. ]$$

Cambridge International AS &amp; A Level Mathematics 9709 Paper 11 Q11 November 2015

283

284

## PRACTICE EXAM-STYLE PAPER

Time allowed is 1 hour 50 minutes (75 marks).

- 1 It is given that f( ) 2 5 3 x x x = -, for x 0 .
- . Show that f is an increasing function. [2]
- 2 The graph of 3 3 y x = -is transformed by applying a translation of 2 0       followed by a r eflection in the x -axis.
- Find the equation of the resulting graph in the form 3 2 y ax bx cx d = + + + . [3]
- 3 Prove the identity -≡ -x x 1 tan 2cos 1 2 2 2
+ x 1 tan . [4]

4

a

Find the first three terms in the expansion of (3

2

)

7

x

-

, in ascending powers of

x

.

[3]

- b Find the coefficient of 2 x in the expansion of (1 5 )(3 2 ) 7 x x + -. [3]

<!-- image -->

5

The diagram shows sector OAB of a circle with centre O , radius 6 cm and sector angle π 3 radians. The point X lies on the line OA and BX is perpendicular to OA .

| a   | Find the exact area of the shaded region.                                                                                                        | [4]   |
|-----|--------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| b   | Find the exact perimeter of the shaded region.                                                                                                   | [3]   |
| 6   | Acircle has centre (3, 2) - and passes through the point (5, 6) P - .                                                                            |       |
| a   | Find the equation of the circle.                                                                                                                 | [3]   |
| b   | Find the equation of the tangent to the circle at the point P , giving your answer in the form ax by c + = .                                     | [4]   |
| 7 a | The sum, S n , of the first n terms of an arithmetic progression is given by 11 4 2 S n n n = - . Find the first term and the common difference. | [3]   |
| b   | The first term of a geometric progression is 2 1 4 and the fourth term is 1 12 . Find:                                                           |       |
|     | i the common ratio                                                                                                                               | [3]   |
|     | ii the sum to infinity.                                                                                                                          | [2]   |
| 8   | The equation of a curve is 3 12 2 2 y x x = + - .                                                                                                |       |
| a   | Express 3 12 2 2 x x + - in the form 2( ) 2 a x b - + , where a and b are constants to be found.                                                 | [3]   |
| b   | Find the coordinates of the stationary point on the curve.                                                                                       | [2]   |
| c   | Find the set of values of x for which 5 y - ø .                                                                                                  | [3]   |

| 9                                                                                  | The function /arrowbarright - x x f : 6 5cos is defined for the domain π 0 2 x ø ø .                                                                                                               |     |
|------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| a                                                                                  | Find the range of f.                                                                                                                                                                               | [1] |
| b                                                                                  | Sketch the graph of f( ) y x = .                                                                                                                                                                   | [2] |
| c                                                                                  | Solve the equation f( ) 3 x = .                                                                                                                                                                    | [3] |
| The function /arrowbarright - x x g : 6 5cos is defined for the domain π 0 x ø ø . | The function /arrowbarright - x x g : 6 5cos is defined for the domain π 0 x ø ø .                                                                                                                 |     |
| d                                                                                  | Find g ( ) 1 x - .                                                                                                                                                                                 | [2] |
| 10                                                                                 | Acurve has equation 6 9 2 y x = - and (3, 2) A is a point on the curve.                                                                                                                            |     |
| a                                                                                  | Find the equation of the normal to the curve at the point A .                                                                                                                                      | [5] |
| b                                                                                  | Apoint ( , ) P x y moves along the curve in such a way that the y -coordinate is increasing at a constant rate of 0.05 units per second. Find the rate of increase of the x -coordinate when 4 x = | [5] |
| 11                                                                                 | Acurve has equation 16 2 y x x = - .                                                                                                                                                               |     |
| a                                                                                  | Find d d y x and d d 2 2 y x in terms of x .                                                                                                                                                       | [3] |
| b                                                                                  | Find the coordinates of the stationary point on the curve and determine its nature.                                                                                                                | [4] |
| c                                                                                  | Find the volume of the solid formed when the region enclosed by the curve, the x -axis, and the lines 1 x = and 2 x = is rotated about the x -axis.                                                | [5] |

285

286

## Answers

## 1  Quadratics

## Prerequisite knowledge

1 a - 4, 3

b

3

c

1

3

, 6

-

- 2 a . x 2

b

&gt;

-

x

2

- 3 a = = x y 2, 3

b

= -

= -

x

y

2,

5

- 4 a 2 5

b

5

c

4

2

## Exercise 1A

- 1 a - 5, 2

b 3, 4

c

-

2, 8

d 3, 4 5 - -

- e 5 2 , 1 1 3 -

f 1 5 , 3 2 -

- 2 a - 1, 6

- b - 1, 4

- c 3 4 , 1 -

- d ± 2

- e 1 2 , 1 -

- f 1 2 , 0 -

- 3 a - 2, 5 3

- b - 3, 2

- c ± 3

- d 4

- e 2 3 , 1 2 -

- f - 5, 1 2

- 4 a - 5, 3

- b 5 2 , 3

- c 1, 3

- d 4, 1 2 - -

- e - 5, 3

- f 2, 3, 4, 5

- 5 a Proof

- b 20cm, 21cm, 29cm

- 6 5 1 2

- 7 2 3 , 1 2 , 4, 6, 7 -

## Exercise 1B

$$\text{Exercise 1B} \\ \text{$a=(x-3)^{2}-9$} \quad \text{$b=(x+4)^{2}-16$} \\ \text{$c=(x-\frac{3}{2})\right)^{2}-\frac{9}{4} \quad \text{$d$} \ \left ( x + \frac{15}{2} \right )^{2}-\frac{2225}{4} \\ \text{$e=(x+2)^{2}+4$} \quad \text{$f=(x-2)^{2}-12$} \\ \text{$g=(x+\frac{7}{2})\right)^{2}-\frac{45}{4} \quad \text{$h$} \ \left ( x - \frac{3}{2} \right )^{2}+\frac{7}{4} \\ \text{$2=(x-3)^{2}+1$} \quad \text{$b=(3(x-2)^{2}-13$} \\ \text{$c=(2\left(x+\frac{5}{4})\right)^{2}-\frac{33}{8} \quad \text{$d$} \ \left ( x + \frac{7}{4} \right )^{2}-\frac{9}{8}$$

- 3 a --x 4 ( 2) 2
- c -+     x 25 4 3 2 2

4

a

-

+

x

15

2(

2) 2

c

-

-

x

15

2(

1)

2

- 5 a --(3 1) 4 2 x
- c + -(5 4) 20 2 x
- 6 a -9, 1

b

-

- b --x 16 ( 4) 2
- d --    x 61 4 5 2 2

b

-

+

x

21

2(

3)

2

- d --    x 49 12 3 5 6 2
- b + + (2 5) 5 2 x
- d -+ (3 7) 12 2 x

6, 2

c -5, 7

- d 2, 7

e

-

6, 3

f -10, 1

- 7 a -± 2 11 b 5 23 ±

c -± 4 17

$$\Big | \quad \text{d} \ 1 \pm \sqrt { \frac { 7 } { 2 } } \quad \ e \ \frac { - 3 \pm \sqrt { 3 } } { 2 } \quad \ f \ \ 2 \pm \sqrt { \frac { 1 1 } { 2 } }$$

- 8 ± 3 10
- 9 -19 2
- 10 8 3 , 1 , 1 6 ( 5 97), 1 6 ( 97 5) ----

$$\left | \ 1 1 \ \text{a} \ \frac { 9 0 0 0 \sqrt { 3 } } { 4 9 } \approx 3 1 8 \, m \quad b \ \frac { 9 0 0 0 \sqrt { 3 } } { 9 8 } \approx 1 5 9 \, m$$

## Exercise 1C

- 1 a - 0.29, 10.29

b - - 5.24, 0.76

- c - 4.19, 1.19

d - 3.39, 0.89

- e - - 1.39, 0.36

f - 1.64, 0.24

- 2 4.93

- 3 3.19

- 4 - 0.217, 9.22

5

=

±

-

4

2

2

x

b

b

ac

a

; the solutions each increase by

b

a

## Exercise 1D

- 1 a -( 3, 9), (2, 4) b -  8, 7 , (2, 1)
-   2
- c -( 10, 0), (8, 6) d --( 2, 7), (1, 2)
- e -(2, 2), (10, 2)

f --( 1, 3), (2, 1)

- g (2, 4)
- i -(2, 2), (10, 2)
- k ( ) --( 6, 2), 8, 1 1 2

h -( 3, 1), (9, 7)

j --( 5, 24), (5, 1)

l

-

(4,

6), (12, 10)

- m 3, 4 , (4, 1 ( ) ---
- 9) 3 n -( 1, 3), (3, 1)
- o --(6, 2), (18, 1)
- 2 a 9 and 17
- 3 2 1 cm 2 and 5 2 cm 5
- 4 3 1 cm 2 and 9cm

b -13 19 and + 13 19

.

- 5 7cm and 11cm
- 6 = 4 1 2 x and = y 16 or = x 16 and = 4 1 2 y
- 7 = = r h 5, 13
- 8 a -( 3, 5) and (2, 0) b 5 2
- 9 a -( 2, 1) and -(3, 1) b     1 2 , 0
- 10 2 53
- 11 + = x y 7 0
- 12 (2, 3)
- 13 = --y x 2 3
- 14 a 2, 8

b + -N D N N D N 2 2 , 2 2

## Exercise 1E

- 1 a ± ± 2, 3 -

- b 1, 2

- c ± ± 5, 1 d ± ± 2 , 5

- 2

- e ± 1 f 1, 1

- 2

- g 3 h No solutions

- ±

- i ± 2 2

- j - 1 , 1

- k 3 2 ±

- l - 1, 2

- 2 a 4, 6 1 4

- b 4

- c 1 9 , 6 1 4

- d 4 25

- e 1 4 , 1 9 16

- f 1 9 , 25

- 3 a - + = x x 6 8 0 c 4 10

- b (4, 4), (16, 8)

- 4 = = - = a b c 2, 9, 7

- 5 = = -= a b c 2, 40, 128

## Exercise 1F

- 1 a ∪ -shaped curve, minimum point: -(3, 1), axes crossing points: (2, 0), (4, 0), (0, 8)
- b ∪ -shaped curve, minimum point: ( ) --2 , 20 1 2 1 4 , axes crossing points: --( 7, 0), (2, 0), (0, 14)
- ,
- c ∪ -shaped curve, minimum point: 1 , 21 3 4 1 8 ( ) --axes crossing points: ( ) --( 5, 0), 1 , 0 , (0, 15) 1 2
- d ∩ -shaped curve, maximum point:

$$\left ( \frac { 1 } { 2 } \,, 1 2 \frac { 1 } { 4 } \right ), axes crossing points:$$

-( 3, 0), (4, 0), (0, 12)

- 2 a --x 2( 2) 3 2
- b = x 2
- 3 a --    x 53 4 5 2 2
- b ( ) 2 , 13 1 2 1 4 , maximum
- 4 a +     -x 2 9 4 49 8 2
- b ( ) --2 , 6 1 4 1 8 , minimum
- 5 -4 1 4 when = 3 1 2 x
- 6 a --    x 9 8 2 1 4 2
- b ∩ -shaped curve, maximum point:
-     1 4 , 1 1 8 , axes crossing points:

$$\left ( - \frac { 1 } { 2 } \,, \, 0 \right ), \, ( 1, \, 0 ), \, ( 0, \, 1 )$$

- 7 Proof
- 8 A: = -+ y x ( 4) 2 2 or -+ x x 8 18 2 B: = + -y x 4( 2) 6 2 or + + x x 4 16 10 2 C: = --y x 8 1 ( 2) 2 or + -x x 6 2 1 2

$$\lambda _ { 2 } ^ { 2 \lambda _ { 2 } ^ { 2 } \lambda _ { 2 } ^ { 2 } \lambda _ { 2 } \lambda _ { 2 } ^ { 2 } }$$

- 9 a
- A = -+ y x x 6 13 2
- B = -+ y x x 6 5 2
- C = -+ -y x x 6 5 2
- D = -+ -y x x 6 13 2
- E = + + y x x 6 13 2
- F = + + y x x 6 5 2
- G = ---y x x 6 5 2
- H = ---y x x 6 13 2
- b Student's own answers
- 10 = --y x x 3 6 24 2
- 11 = + -y x x 5 3 1 2 2
- 12 Proof

287

288

## Exercise 1G

- 1 a &lt; &lt; x 0 3
- c &lt; &lt; x 4 6
- e &lt; &lt; -x 6 5
- 2 a &lt; &gt; -x x 5 or 5

c

.

x

x

1

7 or

&lt; -

- e , , x 4 3 5 2
- 3 a , , -x 9 4

c

&lt;

&lt;

x

1

12

-

e

g

,

&lt;

x

x

x

4 or

-

-

9 or

i

x

,

,

-

.

x

5

3

7

2

- 4 , , -x 3 5 2
- 5 a &lt; , x 5 7
- c -x x 2 or 3 , &gt;
- 6 -x x 5 or 8 , .

7

b

d

f

b

d

f

b

d

f

h

b

b

,

&lt;

3

2

x

a

1

- c &lt; , &gt; -x x 1 1 or 5
- d &lt; , &gt; -x x 3 2 or 5
- e --x x 5 2 or 1 2 &lt; , &lt; ,

f

5

1

2

x

4 or

&lt;

,

x

,

-

## Exercise 1H

- 1 a Two equal roots
- c Two distinct roots
- e No real roots
- 2 No real roots
- 3 = -= -b c 2, 35
- 4 a = ± k 4
- c = k 1 4
- e 0 or 8 9 = = -k k
- 5 a -k 13 .
- c , k 2
- e . k 3 2

1

&gt;

1

x

-

x

-

-

x

x

-

-

x

,

-

3

2

,

,

-

5

&lt;

3

2

&lt;

,

2 or

x

x

,

1

2

x

x

or

&lt;

2

x

.

-

&lt;

-

4

,

or

7 or

3

,

1

2

x

x

,

,

2

2

7

x

.

,

x

-

7

-

-

&lt;

1

,

,

2 or

x

,

x

,

2

3

5

x

1

0

,

,

.

.

3

1

3

1

2

.

8

5

- b Two distinct roots
- d Two equal roots
- f Two distinct roots
- b = k 4 or = k 1

d = = k k 0 or 2

f

=

= -

10 or

k

k

b

d

f

k

k

k

,

57

8

1

2

25

16

14

- 6 a . k 1 2

c

k

e

5

-

f

7

-

2

- 7 = k p 20 2
- 8 &lt; k 25 8
- 9 Proof
- 10 Proof
- 11 &lt; -k 2 2

## Exercise 1I

- 1 --5, 9
- 2 -1, 7
- 3 5
- 4 a ± 10
- 5 ---6, 2, ( 1, 12), (1, 4)
- 6 -k 2 , or . k 6
- 7 -k 4 3 , or . k 4 3
- 8 , k 6
- 9 , , -m 3 1
- 10 . k 6

11

1

2

- 12 Proof
- 13 Proof

## End-of-chapter review exercise 1

- 1     1 2 , 0 2 a -    -x 3 5 2 25 4 2 b 1 3 2 -x , , 3 = ± = ± x x 2, 3 2 4 --x 9 2 3 , or -+ x 9 2 3 . 5 , k 1 or . k 2

.

26

5

21

,

k

10

,

,

5

k

,

+

7

+

- b . k 13 12

d

.

-

k

21

2

b

39

8

10

(2, 4), (

-

2,

-

4)

- 6 a ( ) - 1 , 2 1 2

- b = - = - k k 4 or 20

- 7 a Proof

- b (6, 29)

- c = = k C 1, (2, 5)

- 8 a Proof

- b (2, 1), (5, 7),

- c , , x 2 5

- 9 a - - x 25 ( 5) 2 b (5 ,  25) c &lt; x 1 or &gt; x 9

- 10 i 3 5, 1 2 , 5 -    

- ii = k

- 3 or 11

- 11 i ( ) 2 , 2 1 2 1 2

ii 8, ( 2, 16) = - - m

- 12 i - - - x 2( 1) 1, (1 , 1) 2 ii 1 2 , 3 1 2 -    

- iii 3 1 5 ( 2) - = - - y x

## 2  Functions

## Prerequisite knowledge

- 1 10
- 2 -x 3 2
- 3 = --x x f ( ) 4 5 1
- 4 --x 2( 3) 13 2

## Exercise 2A

- 1 a function, one-one
- c function, one-one
- e function, one-one
- b function, many-one
- d function, one-one
- f function, one-one
- g function, one-one
- h not a function

In this image, we can see a graph.

<!-- image -->

2

<!-- image -->

- b each input does not have a unique output
- 4 a domain: &lt; &lt; R ∈ -x x , 1 5 range: &lt; &lt; R ∈ -x x f( ) , 8 f( ) 8
- b domain: &lt; &lt; R ∈ -x x , 3 2 range: &lt; &lt; R ∈ -x x f( ) , 7 f( ) 20
- 5 a . x f( ) 12

b &lt; &lt; --x 13 f( ) 3

- c &lt; &lt; -x 1 f( ) 9 d &lt; &lt; x 2 f( ) 32
- 1 16 f x &lt; &lt; f( )
- e &lt; &lt; x 32 f( )
- 3 2 12
- 6 a &gt; -x f( ) 2
- b &lt; &lt; x 3 f( ) 28
- c &lt; x f( ) 3
- d &lt; &lt; -x 5 f( ) 7
- 7 a &gt; x f( ) 5
- b &gt; -x f( ) 7
- c -17 f( ) 8 x &lt; &lt; d &gt; x f( ) 1
- 8 a &gt; -x f( ) 20
- b f( ) 6 1 3 -x &gt;
- 9 a &lt; x f( ) 23
- b &lt; x f( ) 5
- 10 a y
- b &lt; &lt; -x 1 f( ) 5
- 11 &gt; -x k f( ) 9
- 12 + g( ) 8 5 2 x a &lt;
- 13 = a 2
- 14 = a 1 or = -a 5
- 15 a ( ) --2 2 3 2 x b = k 4 c R x x &lt; &lt; ∈ -, 3 5

<!-- image -->

289

290

- 16 a domain: R ∈ x range: R ∈ x f( )
- b domain: R ∈ x range: &gt; R ∈ x x f( ) , f( ) 2
- c domain: R ∈ x range: R ∈ x f( ) , . x f( ) 0
- d domain: R ∈ x , ≠ x 0, range: R ∈ x f( ) , ≠ x f( ) 0
- e domain: R ∈ x , ≠ x 2, range: R ∈ x f( ) , ≠ x f( ) 0
- f domain: R ∈ x , &gt; x 3, range: R ∈ x f( ) , &gt; -x f( ) 2

## Exercise 2B

- 1 a 7

b 3

c 231

- 2 a hk

b kh

c hh

- 3 a = = - a b 3, 12 b 5 7 9

- 4 a - + x 6 1

b - 4

- 5 a + - x (2 5) 2 2 b - 4 1 2 or - 1 2

- 6 1 2 or 3 1 2

- 7 4 3 - or 0

- 8 - 9

- 9 + + x x 2 4 9

- 10 a fg

b gf

c gg

d

ff

e gfg

f fgf

- 11 Proof

- 12 ± 4

- 13 - k 19 2 &gt;

- 14 Proof

- 15 a + - x 2( 1) 10 2 b -1

- 16 a &lt; &gt; - x x 1 or 3 b - + x ( 1) 3 2 c &gt; x f( ) 3

- 17 a + - x x 4 2 6 2 b - fg( ) 6 1 4 x &gt;

- 18 a = + + ff ( ) 2( 1) 3 x x x for R ∈ x , ≠ - x 3

- b Proof c - 2 or 1

- 19 a x PQ( ), domain is R ∈ x , range is &gt; R ∈ - x x f( ) , f( ) 1

- b x QP( ), domain is R ∈ x , range is &gt; R ∈ x x f( ) , f( ) 1

- c x RR( ), domain is R ∈ x , ≠ x 0, range is R ∈ ≠ x x f( ) , f( ) 0
- d x QPR( ), domain is R ∈ x , ≠ x 0, range is R ∈ x f( ) , . x f( ) 1
- e x RQQ( ), domain is R ∈ x , ≠ -x 4, range is R ∈ x f( ) , ≠ x f( ) 0
- f x PS( ), domain is R ∈ x , &gt; -x 1, range is R ∈ x f( ) , &gt; -x f( ) 1
- g x SP( ), domain is R ∈ x , &gt; -x 1, range is R ∈ x f( ) , -f( ) 1 x &gt;

## Exercise 2C

- 1
- a = + -x x f ( ) 8 5 1 b = --x x f ( ) 3 1
- c = + --x x f ( ) 5 3 1 d = + -x x x f ( ) 3 8 1
- e = ---x x x f ( ) 7 2 1 1 f = + + -x x f ( ) 2 1 1 3
- 2 a Domain is &gt; -x 4, range is &gt; --x f ( ) 2 1
- b = -+ + -x x f ( ) 2 4 1
- 3 a = --x x x f ( ) 5 2 1 b &lt; x 1
- 4 a = -+ + -x x f ( ) 1 4 1 3 b &gt; -x 3
- 5 a g is one-one for &gt; x 3, since vertex = ( ) 2, 2
- b = + --x x g ( ) 2 2 2 1
- 6 a -3
- 7 a &gt; -x f( ) 9

$$\mathfrak { b } _ { \ } f ^ { - 1 } ( x ) = - 3 + \sqrt { \frac { x + 3 2 } { 2 } }$$

- b No inverse since it is not one-one
- 8 a = k 3
- b i = + --x x f ( ) 3 9 1

ii Domain is &lt; x 9, range is &lt; &lt; -x 3 f ( ) 7 1

- 9 a = x f( ) 1
- -x 5 b Domain is 4 2 3 x &lt;
- 10 = = a b 5, 12
- 11 a = + -x x f ( ) 1 3 1 , = + -x x x g ( ) 4 3 2 1
- b Proof
- 12 a ( ) = + + -x x f ( ) 1 2 1 3 1 3
- b Domain is &lt; &lt; -x 2 122
- 13 a = --x x f( ) ( 5) 25 2
- b = + + -x x f ( ) 5 25 1 , domain is &gt; -x 25

- 14 a = + -x x x f ( ) 1 1 b Proof

$$\mathfrak { c } \ \frac { 1 \pm \sqrt { 5 } } { 2 }$$

- 15 b and c
- 16 a -x 7 6

b

i

-

x

14

6

ii

- c = ---x x (fg) ( ) g f ( ) 1 1 1

## Exercise 2D

1

a

In this image, we can see a graph.

<!-- image -->

In this image, we can see a diagram. There are numbers written on the graph.

<!-- image -->

-6

7

-

6

x

<!-- image -->

- d -f 1 does not exist since f is not one-one
- 2 a = + -x x f ( ) 1 2 1
- b Domain is &lt; &lt; -x 3 5, range is &lt; &lt; -x 1 3

c

-4

In this image, we can see a graph. There are two lines on the graph.

<!-- image -->

- 3 a , &lt; x 0 f( ) 2

b

=

x

-

-

x

4

2

1

x

f

(

)

- c Domain is , &lt; x 0 2, range is &gt; -x f ( ) 0 1
- 4 a Symmetrical about = y x
- b Not symmetrical about = y x
- c Symmetrical about = y x
- d Symmetrical about = y x
- 5 a Proof b = -d a

<!-- image -->

292

## Exercise 2E

- 1 a = + y x 2 4 2 b = -y x 5 2

c

=

-

+

y

x

x

7

2

1

2

d

=

+

y

x

1

2

e

=

2

-

x

3

x

+

y

5

f

=

-

y

x

2

- g = + + + y x x ( 1) 1 2 h = -+ y x 3( 2) 1 2
- 2 a Translation   0 4
-     b Translation -      0 5
- c Translation -      1 0
- d Translation       2 0
- e Translation       1 0
- f Translation     2 4

a

y

-4

-  

<!-- image -->

<!-- image -->

-4

<!-- image -->

-4

3

In this image, we can see a graph. On the graph, we can see two lines.

<!-- image -->

## Exercise 2F

- 1 a

-4

<!-- image -->

<!-- image -->

-4

- 2 a = -y x 5 2

b

=

y

x

2

- c = + + y x x 2 3 1 2

d

- 3 a Reflection in the x -axis
- b Reflection in the y -axis
- c Reflection in the x -axis
- d Reflection in the x -axis

y

=

4

x

2

3

-

2

x

-

5

## Exercise 2G

In this image, we can see a graph.

<!-- image -->

-6

In this image, we can see a graph.

<!-- image -->

- 2 a = y x 6 2
- c = + -y x 2 2 1

$$\mathbf b & \ y & = 3 x ^ { 3 } - 3 \\ \mathbf d & \ y & = \frac { 1 } { 2 } \ x ^ { 2 } - 4 x + 1 0$$

- e = -y x x 162 108 3
- 3 a Stretch parallel to the x -axis with stretch factor 1 2
- b Stretch parallel to the y -axis with stretch factor 3
- c Stretch parallel to the y -axis with stretch factor 2
- d Stretch parallel to the x -axis with stretch factor 1 3

## Exercise 2H

<!-- image -->

<!-- image -->

<!-- image -->

-4

<!-- image -->

294

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

-4

- 2 a = - 2f( ) y x

b = - y x 2 f( )

- c = - + 2f( 1) 1 y x

- 3 a = - y x 3( 1) 2

- b = - y x 3( 1) 2

In this image, we can see a graph.

<!-- image -->

- b Reflection in the x -axis followed by a
- translation       0 2
- c Translation       6 0 followed by a stretch parallel 1
- 2 d Stretch parallel to the y -axis with stretch factor 2 followed by a translation -      0 8

to the

x

-axis with stretch factor

- 8 a Translation -      5 0
- followed by a stretch

parallel to the y -axis with stretch factor 1 2

- b Translation -      1 0 , stretch parallel to the

y

-axis with stretch factor

1

2

, reflection in the

- x -axis, translation -      0 2
- c Translation       3 0 , stretch parallel to the

y

-axis with stretch factor 2, reflection in the

$$\begin{smallmatrix} 0 \\ x \text{-axis, translation} \begin{pmatrix} 0 \\ 4 \end{pmatrix}$$

- 9 a = --+ 1 2 1 3 y x b = ---1 2 ( 1) 3 y x

10

a

=

-

+

+

=

-

+

y

x

x

3[(

4)

2]

3(4

)

6

2

2

b

y

=

3[(

-

(

x

+

4))

2

]

+

2

=

3(

x

+

4)

2

+

2

- 11 Translation       2 0 followed by reflection in the

y -axis or reflection in the y -axis followed by

$$\text{translation} \left ( \begin{matrix} - 2 \\ 0 \end{matrix} \right )$$

<!-- image -->

Translation

-





10









0

followed by a stretch parallel to the

x

-axis with stretch factor

1

2

or stretch parallel to the

x

-axis with stretch factor followed by translation

1



-



5









0

## End-of-chapter review exercise 2

$$1 \quad \frac { 2 5 } { 4 } - 9 \left ( x - \frac {$$

2

a

<!-- image -->

- b Translation -      3 0
- followed by a reflection in the y -axis or reflection in the y -axis followed

$$\text{by translation} \begin{pmatrix} 3 \\ 0 \end{pmatrix$$

<!-- image -->

2

12

In this image, we can see a graph.

<!-- image -->

- 5 i x ( 3) 4 2
- --+ ii 3 iii = + --x x f ( ) 3 4 , 1 domain is &lt; x 0
- 6 i --+ x k ( 2) 4 2

ii

&gt;

-

x

k

f(

)

4

iii

=

p

2

- iv = + + --x x k f ( ) 2 4 1 , domain is &gt; -x k 4
- 7 i &lt; &lt; -x 5 f( ) 4

ii

<!-- image -->

$$\begin{array} {$$

- 8 i --x 4( 3) 25 2 , vertex is -(3, 25) ii &gt; -x g( ) 9 iii = -+ -x x g ( ) 3 1 2 25 1 , domain is &gt; -x 9

9

i

-

-

x

2(

3)

5

2

ii

3

iii

&gt;

x

f(

)

27

$$\mathbf i v \ f ^ { - 1 } ( x ) = 3 + \sqrt {$$

$$\left | \begin{array} { c c c c } 1 0 & \text{i}$$

295

296

```
11 i --x 2( 3) 11 2 ii > -f 11 iii , , -x 1 7 iv = k 22 12 i = -x x fg( ) 2 3, 2 = + -x x x gf( ) 4 4 1 2 ii = -a 1 iii = b 2 iv -1 2 ( 3) 2 x v = -+ -x x h ( ) 2 1 13 i -+ x 2( 2) 2 2 ii < < x 2 f( ) 10 iii < < x 2 10 iv x f( ): half parabola from (0, 10) to (2, 2); x g( ): line through O at 45°; -x f ( ): 1 reflection of x f( ) in x g( ) v f ( ) 2 1 ( 2) 1 = ---x x
```

- 2

## 3  Coordinate geometry

## Prerequisite knowledge

- 1 ( ) --4 , 2 , 13 1

```
2 2 a 1 6 -b 6 3 a 2 3 b -5 c 7 1 2 4 a --x ( 4) 21 2 b -+ 4 21, 4 21
```

## Exercise 3A

- 1 a = = = PQ QR PR 5 5, 4 5, 3 5, right-angled triangle b = = = PQ QR PR 197, 146, 3 5, not right angled 2 17 units 2 3 = = -a a 3 or 9 4 = = -3 or 5 4 5 b b 5 = = -a b 2, 1 6 a --( 2, 1) b -( 1, 9) c 2 41, 2 101 7 = k 4 8 38 1 2 units 2 9 = k 2 10 -( 2, 6)
- 11 a (5, 2) b 8 2 12 -A ( 5, 5), B (7, 3), --C ( 3, 3) Exercise 3B 1 a 1 5 , 1 6 b Not collinear 2 Proof 3 -2 5 , 5 2 4 -(7, 1) 5 = k 5 7 6 = = k k 2 or 3 7 -(0, 26) 8 a 1 b 5 9 = = a b 10, 4 10 a 1 2 b -2 c = = -a a 6 or 4 11 a (6, 6) b = -= = a b c 4, 16, 11 c 4 145 d 100 Exercise 3C 1 a = + y x 2 1 b = --y x 3 1 c + = x y 2 3 1 2 a = -y x 2 3 3 b + = x y 9 5 2 c -= x y 2 3 9 3 a = + y x 3 4 b + = -x y 2 8 c + = x y 2 8 d + = x y 3 2 18 4 a = + y x 2 2 b + = x y 5 3 9 c + = -x y 7 3 6 5 (8, 2) 6 a 3 2 8 = + y x b (0, 8) c 39 7 a (6, 3) b = -+ y x 2 3 7 8 a y x = + 4 3 10 b ( ) -7 , 0 , (0, 10) 1 2 c 12 1 2 9 a y x = + 2 5 33 b 33

```
10 E F (4, 6), (10, 3) 11 10 12 -(14, 2) 13 a y x = -+ 3 2 b ( 1, 5) -c 5 10, 4 10 d 100 14 a i = 4 1 2 y ii + = x y 7 b ( ) 2 , 4 1 2 1 2 15 a = -y x 2 7 b ( ) 4 , 1 2 5 4 5 16 + = x y 8, + = x y 3 3. Other solutions possible.
```

## Exercise 3D

- 1 a (0, 0), 4
- b (0, 0), 3 2 2
- c (0, 2), 5

d

-

(5,

3), 2

- e -( 7, 0), 3 2 f -(3, 4), 3 10 2
- g -(4, 10), 6 h ( ) 3 , 2 , 10 1 2 1 2
- 2 a + = x y 64 2 2 b -+ + = x y ( 5) ( 2) 16 2 2
- c + + -= x y ( 1) ( 3) 7 2 2
- d -    + +     = x y 1 2 3 2 25 4 2 2
- 3 -+ -= x y ( 2) ( 5) 25 2 2
- 4 + + -= x y ( 2) ( 2) 52 2 2
- 6 -+ + = x y ( 6) ( 5) 25 2 2
- 7 Proof
- 8 -+ = x y ( 5) 8 2 2 and -+ -= x y ( 5) ( 4) 8 2 2
- 9 -+ -= x y ( 4) ( 2) 20 2 2
- 10 -+ + = -x y ( 3) ( 1) 16, (3, 1), 4 2 2 11 = -y x 3 4 21 2 12 -+ -= x y ( 5) ( 2) 29 2 2 13 a Proof b + + -= x y ( 1) ( 4) 20 2 2 14 -+ + = x y ( 5) ( 3) 40 2 2 15 -+ -= x y ( 9) ( 2) 85 2 2 16 + + + = x y ( 3) ( 10) 100 2 2 , -+ + = x y ( 13) ( 10) 100 2 2 17 a i + 1 2 ii Student's own answer b i + 3 2 2 ii Student's own answer

<!-- image -->

## Exercise 3E

- 1 --( 1, 4), (5, 2)
- 2 2 5
- 3 Proof
- 4 -m 2 29 2 , ,
- 5 a (0, 6), (8, 10) b y x = -+ 2 16
- c 5 5, 6 2 5 , 5 5, 6 2 5 ( ) ( ) -+ + -
- d 20 5
- 6 (4, 3)
- 7 a x y -+ -= ( 12) ( 5) 25 2 2 and x y -+ -= ( 2) ( 10) 100 2 2
- b Proof

## End-of-chapter review exercise 3

- 1 , , a 2 26 2 i 4 9 and 1 4 ii 49 24 3 a b a b = -= -= = 4, 1 or 12, 7 4 10 5 a a b = = -5, 2 b -(4, 5) c = --y x 2 5 3 2 5 6 i t 16 2 ii Proof 7 -(13, 7) 8 a -( 2, 2), (4, 5) b = -+ 2 5 1 2 y x

297

298

- 9 a --( 2, 3)

b

= -

y

1

2

- c -+ 19 2 113, 19 2 113
- 10
- i m = 2, 1 ii -( 1, 6) iii (5, 12)
- 11 i y x = -2 2 ii (0, 2), 8 5 , 6 5 -   
- 12 i y x = -+ 2 6, (3, 0) ii Proof iii -( 1, 8), 2 10
- 13 a = -+ y x 2 3 3 b p = -1
- c x y -+ + = ( 6) ( 1) 26 2 2
- 14 a (19, 13) b 104
- 15 a       10 3 , 10 b -k k 12, 12 , .
- a = -+ y x 4
- 16 3 2 b Proof
- c x y -+ -= ( 15) ( 7) 325 2 2
- 17 a 4, -(4, 2)
- b -+ 4 2 3, 4 2 3
- c Proof
- d Proof

## Cross-topic review exercise 1

x

+

4 3

4

- 3 a b = = -5, 2
- 4 Translation       5 0 , vertical stretch with stretch factor 2
- 5 y x x = -+ -6 8 2
- 8 -( , 2 ) 2 k k
- 9 6 5
- 10 a k = 14 b = + y x 1 4
- 3
- 11 a --( 1, 11), (6, 3) b -k 25 12 ,
- 12 a = -k 1 2

In this image, we can see a graph.

<!-- image -->

In this image we can see a graph.

<!-- image -->

b

.

x

5

- 13 i &gt; x x x = fg( ) 5 , range is fg( ) 0
- ii = --x x x x g ( ) 4 2 5 , domain is 0 2 1 , &lt;
- 14 a b c = -= -5, 14
- b i -(2.5, 20.25) ii , , x -3 8
- 15 a y x = + 2 3 25 b -( 3, 8)
- 16 a x --36 ( 6) 2 b 36
- c &lt; &gt; x x -36, g ( ) 6 1 d x x = + --g ( ) 6 36 1
- 17 a x + -3( 2) 13 2 b --( 2, 13)
- c , , x 6 18
- 18 a a b = = 12, 2 b -3
- c x x = -+ --g ( ) 3 26 2 1
- 19 a x y -+ -= ( 8) ( 3) 29 2 2

Copyright Material  - Review Only -  Not for Redistribution

- b x y + = 5 2 75

- 20 a x = 1 2
- b = + = ---x x x x f ( ) 7 3 , g ( ) 5 18 1 1
- c Proof
- 21 a x -+       17 4 3 2 2 b -    3 2 , 17 4
- c -5 and -1 d --(1, 2), ( 1, 4)
- 22 a (8, 0)

b

10

- c -( 2, 0), (18, 0)
- 23 a k = -2
- d = -+ y x 3 4 6
- b i &gt; x fg( ) 28
- ii x x = -+ -(fg) ( ) 26 6 1 , domain is &gt; x 28,

range is x &lt; --(fg) ( ) 3 1

- 24 a i (4, 5), (10, 2) ii x y -= 4 2 21
- b k = ± 4 10

## 4  Circular measure

## Prerequisite knowledge

- 1 + π (12 ) cm, π 3 cm 2
- 2 13, 67.4
- 3 5.14, 15.4cm 2

## Exercise 4A

| a   | 9 π     |        | b   | 2 9 π   |         |         |
|-----|---------|--------|-----|---------|---------|---------|
| c   | 5 36 π  |        | d   | 5 18 π  |         |         |
|     | π       |        |     | 5 π     |         |         |
| e   | 36 3 π  |        | f   | 6       |         |         |
| g i | 4 5 4 π |        | h   | 7 6 π   |         |         |
| k   | 13 π    |        | j   | 5 3 π   |         |         |
|     | 36 π    |        | l   | 3 π 7 π |         |         |
| m o | 20 10 π |        | n   | 36      |         |         |
| a   | 3 ° 90  | b ° 60 |     | c       | ° 30    | d ° 15  |
| e   | ° 240   | f ° 80 |     | g       | ° 54    | h ° 105 |
| i m | ° 81    | j 810  | °   | k       | ° 252   | l ° 48  |
|     | 225     | n 420  |     | o       | ° 202.5 |         |
|     | °       |        | °   |         |         |         |

- 3 a 0.489

- b 0.559

- c 0.820

- d 3.49

- e 5.59

- 4 a ° 68.8

- b ° 45.8

- c ° 76.8

- d ° 87.1

- e ° 45.3

- 5 a.
- 7 7.79cm
- 8 ° 12.79

| Degrees   |   0 | 45   | 90   | 135   | 180   | 225   | 270   | 315   | 360   |
|-----------|-----|------|------|-------|-------|-------|-------|-------|-------|
| Radians   |   0 | π 4  | π 2  | π 3 4 | π     | π 5 4 | π 3 2 | π 7 4 | π 2   |

In this image, we can see a table with some numbers.

<!-- image -->

## Exercise 4B

- 1 a π 2 cm
- c π 6 cm
- 2 a 13cm
- 3 a 0.5rad
- 4 15.6 m
- 5 a 19.2 cm
- c 50.4cm
- 6 a 0.927rad
- c 17.6cm
- 7 a 14cm
- c 25.8cm
- 8 a 13cm
- c 56.6cm
- 9 a Proof
- 10 Proof
- b π 3 cm
- d π 28 cm
- b 2.275cm
- b 0.8rad
- b 20.5cm
- b 4cm
- b 11.8cm
- b 2.35rad
- b 43.4cm

299

300

## Exercise 4C

- 1 a π 12 cm 2

c

π

9

4

cm 2

- 2 a 867cm 2
- 3 a 1.125rad
- 4 a 1.25rad
- 5 a 1.75rad
- c 5.16cm 2
- 6 -π     32 3 32 3 cm 2
- 7 a 5 3 3 cm
- 8 1.86cm 2
- 9 a 29.1cm 2
- c 51.7 cm 2
- 10 a Proof

$$\mathbf 1 \left ( \frac { 2 \pi r ^ { 2 } } { 3 } - \frac { \sqrt { 3 } r ^ { 2 } } { 2 } \right ) \mathbf c m ^ { 2 }$$

$$\Big | \quad 1 2 \ \ 1 0 0 \left ( 1 + \frac { \pi } { 3 } - \sqrt { 3 } \, \right ) \text{cm} ^ { 2 }$$

$$\mathfrak { a } \ \left ( \tan x + \frac { 1 } { \tan x } \right ) \mathfrak { c } m \mathfrak { b } \ 0. 2 1 9 \, r a d$$

- 14 a Proof

b Proof

## End-of-chapter review exercise 4

$$1 \quad \mathbf a \ 1 5 - 5 \sqrt { 3 } + \frac { 5 \sqrt { 3 } \pi } { 6 } \quad \mathbf b \ \frac { 2 5 \sqrt { 3 } } { 4 } - \frac { 2 5 \pi } { 8 }$$

- 2 i 8 α = π

+

π

5

8

ii

- 3 i α α -8 tan 2

4

cos ii

4 tan

α

α

+

- 4 i r (1 cos sin )
- θ θ θ + + + ii 55.2
- 5 i AC r r θ = -cos ii 7 3 2 3 2 π + -
- 6 i Proof

-

-

(

6)

36

ii

r

2

iii

=

36,

A

- 7 i Proof

8









ii

π

2

r

2

-





θ

θ

θ

θ

i

ii cos

=

1

2

-

sin

r

+

+

9

i

α

α

α

α

+

+

-

4

cos

4

8

8 cos ii

- 10 i r r r α π + + 2 2 ii r r α + π 3 2 2 2

$$\i i i \ \alpha = \frac { 2 } { 5 } \ \pi$$

- b π 20 cm 2
- d π 54 cm 2
- b 3.042cm 2
- b 1.5rad
- b 40cm 2
- b 4.79cm
- b ( ) - π 25 6 2 3 cm 2
- b 36.5cm 2
- d 13.9cm 2
- b Proof

6.31

π

3

+

α

2

## 5  Trigonometry

## Prerequisite knowledge

|         | 4 θ = π   | 3 θ = π   | 6 θ = π   |
|---------|-----------|-----------|-----------|
| tan θ   | 1         | 3         | 1 3       |
| cos θ   | 1 2       | 1 2       | 3 2       |
| 1 sin θ | 2         | 2 3       | 2         |

In this image we can see a table. In the table we can see numbers.

<!-- image -->

## Exercise 5B

- 1 a ° 70
- c ° 20
- 2 a 2nd quadrant, ° 80
- c 4th quadrant, ° 50
- e 1st quadrant, ° 40

g

3rd quadrant,

π

6

- i 3rd quadrant, π 4 9
- 3 a ° 125
- c ° 688

e

π

8

3

## Exercise 5C

- 1 a -° sin 10
- c -° tan 55
- e -π cos 5
- g -π cos 3 10
- 2 a -1 2
- c -2 2
- e -3 2
- g -3 3
- 3 4th quadrant
- 4 a -21 5
- 5 a -2 3 6 a -5 13
- 7 a a
- c a a + 1 2
- 8 a b -1 2
- c b --1 2
- b ° 40
- d ° 40
- b 3rd quadrant, ° 80
- d 3rd quadrant, ° 30

f

2nd quadrant,

- h 1st quadrant, π 3

j

4th quadrant,

- b -° 160

d

π

5

4

f

-

π

13

6

- b ° cos 55
- d -° cos 65
- f -π sin 8
- h π tan 2 9

b

-

d

f

1

2

h

-

3

3

3

1

2

- b -2 21
- b 2

b

12

13

- b a a + 1 2
- d -+ a a 1 2
- b b b -1 2
- d b -1 2

π

8

π

3

|         | 120 θ = = °   | 135 θ = = °   | 210 θ = = °   |
|---------|---------------|---------------|---------------|
| tan θ   | - 3           | - 1           | 1 3           |
| sin θ   | 3             | 1 2           | - 1 2         |
|         | 2             | - 2           | 2 3           |
| θ 1 cos | - 2           |               | -             |

In this image we can see a graph.

<!-- image -->

301

302

In this image, we can see a diagram.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

-4

In this image, we can see a graph.

<!-- image -->

<!-- image -->

4

In this image, we can see a graph.

<!-- image -->

h

y

3

2

1

O

-1

-2

-3

i

y

a   i ii

y

3

2

1

O

-1

-2

-3

y

2

1

O

-1

-2

Copyright Material  - Review Only -  Not for Redistribution

60

90

120

π

2

π

2

180

180

π

π

240

270

300

3

π

2

3

π

2

360

360

x

2

π

2

π

x

x

x

In this image, we can see a graph.

<!-- image -->

b

π





π





π





π





5

9

13









-

















-









8

, 1

,

8

,

1

,

8

, 1

,

8

,

1

In this image, we can see a diagram. There are two lines, one is blue and the other is red. We can also see some text.

<!-- image -->

b

4

In this image, we can see a graph. On the graph, we can see two lines. On the left side, we can see a number. On the right side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side, we can see a number. On the left side, we can see a number. On the right side

<!-- image -->

b

2

In this image, we can see a graph. On the graph, we can see two lines. On the left side, we can see a symbol. On the right side, we can see a symbol.

<!-- image -->

-4

b 2

Copyright Material  - Review Only -  Not for Redistribution

- 8 a b c = = = 4, 2, 5
- 9 a b c = = = 3, 2, 3

In this image, we can see a graph.

<!-- image -->

-3

$$\begin{array} { c c c } & \mathbf b & k = \frac { 4 } { \pi } \\ & & \mathbf c & ( 0, 0 ), \left ( - \frac { \pi } { 2 }, - 2 \right ) \\. & & \mathbf c &. & \mathbf c \end{array}$$

- 11 a b c = = = 3, 1, 5
- 12 a a b = = 3, 2

b &lt; &lt; x 1 f( ) 5

- 13 a a b = = 3, 5

The image depicts a graph with a horizontal axis labeled as "b" and a vertical axis labeled as "x". The graph is a line graph, and it shows the values of the variable "b" over time. The graph is drawn with a blue line that starts at the bottom of the graph and extends upwards to the top. The line is relatively straight, indicating that the values of "b" are constant over time.

The graph has a scale of range from 0 to 360, which is the range of the variable "b". The x-axis is labeled as "x" and the y-axis is labeled as "b". The graph is drawn with a simple, clear, and straightforward style, with no additional decorations or embellishments.

### Analysis and Description:

#### Graph Description:
1. **Title and Axis Labels**:
   - The title of the graph is "b" and the axis labels are "x" and

<!-- image -->

-4

- 14 a b c = = = 5, 4, 3
- 15 a A B = = 2, 6

b

5

304

In this image, we can see a graph.

<!-- image -->

- 16 y x = + 2 sin
- 17 y x = + 6 cos

## Exercise 5E

- 1 a ° 0 b 30
- °
- c ° 60
- d -° 90
- e -° 60
- 2 a 0
- c π 4
- e π 2 3
- 3 a 16 25
- 4 a &lt; &lt; x --7 f( ) 1
- f ° 135
- b π 4
- d -π 6
- f -π 3
- b 16 9
- b = +     --f ( ) sin 4 3 1 1 x x
- 5 a &lt; &lt; x 2 f( ) 6
- b f  is one-one, = -    --f ( ) cos 4 2 1 1 x x
- 6 a 3
- b =     --f ( ) sin 5 , 3 7 1 1 x x x &lt; &lt;
- π 2 -2
- 7 a &lt; &lt; x --9 f( ) 1
- b = +     --f ( ) 2 cos 5 4 1 1 x x , &lt; &lt; x π -0 f ( ) 2 1

<!-- image -->

## Exercise 5F

- 1 a ° ° 56.3 , 236.3 b ° ° 23.6 , 156.4

- c ° ° 45.6 , 314.4

- d ° ° 197.5 , 342.5

- e ° ° 126.9 , 233.1 f ° ° 116.6 , 296.6

- g ° ° 60 , 300

- h ° ° 216.9 , 323.1

- 2 a 0.305, 2.84 3 3

- b , 5 π π

- c 1.25, 4.39 d 3.92, 5.51

- e 1.89, 5.03

- f 2 3 , 4 3 π π

- g 0.848, 2.29

- h 2.19, 5.33

- 3 a ° ° 26.6 , 153.4
- b ° ° ° ° 17.7 , 42.3 , 137.7 , 162.3
- c ° ° 38.0 , 128.0 d ° ° 105 , 165
- e ° ° 24.1 , 155.9
- f ° ° 116.6 , 153.4
- g ° ° 58.3 , 148.3
- h ° ° 5.77 , 84.2
- 4 a ° ° 90 , 210
- b π π 2 , 7 6
- c ° ° 139.1 , 175.9 d 0.0643, 2.36, 3.21, 5.51
- e ° 278.2
- f 0, π 3 2
- 5 a ° ° 26.6 , 206.6
- b ° ° 56.3 , 236.3
- c ° ° 119.7 , 299.7
- d ° ° ° ° 18.4 , 108.4 , 198.4 , 288.4
- 6 0.298, 1.87
- 7 a ° ° ° ° ° 0 , 150 , 180 , 330 , 360
- b ° ° ° ° ° 0 , 36.9 , 143.1 , 180 , 360
- c ° ° ° ° ° 0 , 78.7 , 180 , 258.7 , 360
- d ° ° ° ° ° 0 , 116.6 , 180 , 296.6 , 360
- e ° ° ° ° ° 0 , 60 , 180 , 300 , 360
- f ° ° ° ° ° 0 , 76.0 , 180 , 256.0 , 360
- 8 a ° ° ° ° 60 , 120 , 240 , 300
- b ° ° ° ° 56.3 , 123.7 , 236.3 , 303.7
- 9 a ° ° ° 30 , 150 , 270
- b ° ° ° ° 45 , 108.4 , 225 , 288.4
- c ° ° ° ° 0 , 109.5 , 250.5 , 360
- d ° ° ° 60 , 180 , 300
- e ° ° ° ° ° 0 , 180 , 199.5 , 340.5 , 360
- f ° ° ° ° 70.5 , 120 , 240 , 289.5
- g ° ° ° 19.5 , 160.5 , 270
- h ° ° ° 30 , 150 , 270

- 10 a 0.565, 2.58

- b π π 6 , 5 6

$$\mathbf 1 = 2. 0 3, \frac { 3 \pi } { 4 } \,, \, 5. 1 8, \frac { 7 \pi } { 4 }$$

## Exercise 5G

- 1 x -9 sin 3 2

- 2 a Proof

- b Proof

- c Proof

- d Proof

- e Proof

- f Proof

- 3 a Proof

- b Proof

- c Proof

- d Proof

- 4 a Proof

- b Proof

- c Proof

- d Proof

- 5 a Proof b Proof

- c Proof d Proof

- e Proof

- f Proof

- g Proof

- h Proof

- 6 a Proof

- b Proof

- c Proof

- d Proof

- e Proof

- f Proof

- 7 4

- 8 a x + 4 3 sin 2

b &lt; &lt; x 4 f( ) 7

- 9 a θ + - (sin 2) 5 2

- b - 4, 4

- 10 a Proof

- b a a a a θ θ = - + = + sin 1 4 1 4 , cos 4 1 4 2 2 2

## Exercise 5H

- 1 a Proof

b ° ° 76.0 , 256.0

- 2 a Proof

b ° ° 18.4 , 116.6

- 3 a Proof

- b ° ° ° ° 60 , 131.8 , 228.2 , 300

- 4 a Proof

b ° ° ° ° 30 , 150 , 210 , 330

- 5 a Proof

b ° ° 72.4 , 287.6

- 6 a Proof

b ° ° 65.2 , 245.2

- 7 a Proof

b ° ° ° 41.8 , 138.2 , 270

- 8 a Proof

- b ° ° 30 , 150

- 9 a Proof

- b ° ° 66.4 , 293.6

- 10 a Proof

- b ° ° 70.5 , 289.5

- 11 a Proof

- b ° ° ° ° 30 , 150 , 210 , 330

## End-of-chapter review exercise 5

- 1 a b = = 1, 2
- 2 1.95
- b k -1 2
- 3 a k -1 2 k
- c k -
- 4 x = ± 3 2
- 5 ° ° 39.3 or 129.3
- 6 ° ° 30 or 150
- 7 ° ° 30 or 150
- ii 4

<!-- image -->

iii

20

- 9 i Proof
- 10 i ° ° 60 or 300
- 11 i Proof
- 12 a 6 , 5 6 π π
- ii ° ° ° ° 45 , 135 , 225 , 315
- ii ° 120
- ii ° ° 109.5 or 250.5
- b -2.21, 0.927
- 13 i &lt; x f( ) 3
- ii -3 2 3
- iv x x = -      --f ( ) 2 tan 3 2 1 1
- 14 i ° ° 30 or 150

<!-- image -->

ii θ = = ° 3, 290 n

- 15 i Proof
- ii ° ° ° ° 54.7 , 125.3 , 234.7 , 305.3
- 16 i Proof

ii ° ° 194.5 or 345.5

- 17 i 1.68

305

306

In this image, we can see a graph.

<!-- image -->

## 6  Series

## Prerequisite knowledge

- 1 a x x + + 4 12 9 2

b x x x - - + 9 9 1 3 2

- 2 a x 125 6

b x - 32 15

- 3 a n + 2 3

- b n - 11 3

## Exercise 6A

- 1 a x x x + + + 6 12 8 3 2 b x x x x - + - + 1 4 6 4 2 3 4 c x x y xy y + + + 3 3 3 2 2 3 d x x x - + - 8 12 6 2 3 e x x y x y xy y - + - + 4 6 4 4 3 2 2 3 4 f x x y xy y + + + 8 36 54 27 3 2 2 3 g x x x x - + - + 16 96 216 216 81 4 3 2 h x x x x + + + 9 2 27 4 27 8 6 4 9 2 a 12 b 10 c - 90 d 16 e 40 f - 32 g 768 h - 5 2 3 A B C = = = 486, 540, 30 4 ± 2 5 a x x x x + + + + 16 32 24 8 2 3 4 b + 97 56 3 6 a x x x + + + 1 3 3 2 3 b i + 16 8 5 ii - 16 8 5 c 32

- 7 x x x x x + + + + + 16 112 312 432 297 81 2 3 4 5 8 a x x x x -+ -+ 4 6 4 1 8 6 4 2 b -16 9 -216 10 54 11 a y y + + 1 4 6 2 b 142 12 5 13 x 11 14 a x x y x y x y xy y + + + + + 5 10 10 5 5 4 3 2 2 3 4 5 b 113100 15 a p q = = 8, 8 b 36 2 16 a y y -3 3 b y y y -+ 5 5 5 3

## Exercise 6B

- 1 a 35

- b 84

- c 495

- d 5005

- 2 a n n - ( 1) 2

- b n

- c n n n - - ( 1)( 2) 6

- 3 a 45

- b 56

- c 364

- d 792

- 4 a x x + + 1 16 112 2

- b x x - + 1 30 405 2

- c x x + + 1 7 2 21 4 2

- d x x + + 1 12 66 2 4

- e x x + + 2187 5103 2 5103 4 2

- f - + x x 8192 53248 159744 2

- g x x + + 256 1024 1792 2 4

- h x x + + 512 1152 1152 2 4

- 5 a - 84 b 5940

c

35

4

- d - 9720

- 6 7920
- 7 -224000
- 8 -41184
- 9 40095
- 10 a x x + + 128 320 224 2 b x x -+ 1 28 345 2
- c x x -+ 1 3 3 2
- 11 a + + x x 1024 5120 11520 2
- b + + y y 1024 10240 30720 2

- 12 a x x - + 1 4 7 2 b 1

- 13 x x + + 16 224 1176 2

- 14 a b p = - = = - 2, 1, 364

- 15 n p q = = = - 8, 256, 144

## Exercise 6C

- 1 a d a d + + 6 , 18
- 2 a 22, 1210

b 35, 3535

- 3 a 1037

b -1957

- c 38 1 3 d x -3160
- 4 7
- 5 a 7, 29 b 2059
- 6 1442
- 7 1817
- 8 31
- 9 5586
- 10 25
- 11 $360
- 12 a -17, 4 b 20
- 13 7, 8
- 14 -10, 4
- 15 n ( ) -1 2 5 11
- 16 ° 9
- 17 a a d = 8
- 18 Proof
- 19 a -x 4 3 sin 2
- 20 a Proof

## Exercise 6D

- 1 a No
- c --1 3 , 1 27
- e No
- 2 ar ar , 5 14
- 3 2 3
- 4 -10.8
- 5 3 2 , 8
- 6 64
- b a 9
- b Proof

b 900

b 3, 15309

- d No
- f --1, 1
- 7 -8, 2
- 8 a 765
- c -85
- b 255
- d 700 5 9
- 9 21
- a n 8 3  
- 10 4   b 48.8125 m
- 11 a x + 48 1
- b 2, 1 3
- 12 -40, 20
- 13 a $17715.61
- 14 Proof
- 15 Proof
- 16 Proof

## Exercise 6E

- 1 a 3
- c 26 2 3
- 2 4 3
- 3 32
- 4 2 3 , 810
- 5 a 0.57 57 100 57 10000 57 1000000 = + + + … /dotnosp /dotnosp
- b Proof
- 6 0.25, 199.21875
- 7 0.5, 9

8

52

165

- 9 a 2 3 , 13.5
- 10 a -0.25, 256

11 a 90

12 a 36

- 13 93.75
- 14 a r = = 2, 3 5
- 15 , , x π π 3 2
- 16 a π 5
- 17 a Proof
- c Proof
- b $94 871.71
- b 1 1 9

d -36 4 7

b 40.5

b 204.8

b 405

- b 192
- b π 11 8
- b Proof

307

308

## Exercise 6F

1 a 352

- b 788.125

2 a 100

b 16

3 a 2

b 384, 32

4 - 2.5, 22.5

5

a

3

5

b 12.96, 68

- 6 a 4

b 3 2 , n = 6

- 7 a x = - = 3 or 5, 3rd term 24 or 40

b

-

4

5

## End-of-chapter review exercise 6

- 1 240

- 2 5

- 3 2

4

-

864

25

- 5 16800

- 6 40

- 7 135

2

- 8 a x x x - + 6561 17496 20412 16 15 14 b - 37908

- 9 a px p x + + 1 8 28 2 2 b - 17 7 , 3

- 10 a i x x + + 1 10 40 2 ii x x - + 243 405 270 2 b 5940

- 11 23

12

a

-

2

3

b 2187

c 1312.2

13 a d a = 2

b a 99

14 a a d = = - 44, 3

b n = 22

15 a a d = = - 60, 10.5 b 42 2 3

16 a 17

b = - = r S 5 7 , 7 4

- 17 a 1 5

b 16

18 i 41000

ii 22100

- 19 a a b = = 10, 45

- b i , , θ π 0 3

ii 1.125

20

i

x

= -

=

2 or 6, 3rd term

16 or 48

ii

16

27

21 a 2 1 4

b ° 115.2

22 a d a = = 6, 13

b = = a r 12 7 , 5 7

## Cross-topic review exercise 2

1 x 180

- 2 3840
- 3 a x x -+ 729 2916 4860 6 3 b -5832

4 a x x -+ 1 10 40 2

b 12

- 5 a -25.6
- 6 a 14

7

625

8

- 8 i Proof

- ii ° ° ° ° 35.3 , 144.7 , 215.3 , 324.7

- 9 a Proof

- b r - - 225 ( 15) 2

- c 15

- d 225, maximum

- 10 a Proof

b r - - 625 ( 25) 2

c 25

- d 625, maximum

- 11 a Proof

- b π - π - π     r 40000 200 2

- c Proof

- d π 40000 , maximum

- 12 i Proof

ii 0.9273

iii 5.90 cm 2

13 i r θ θ - (tan ) 2

ii + + π 12 12 3 4

- 14 i x - 2 5 cos 2

ii - 3 and 2

iii 0.685, 2.46

- 15 i Proof

ii ° ° 26.6 , 153.4

- 16 i &lt; &lt; x - 5 f( ) 3

ii - (0.253, 0), (0, 1)

iii

<!-- image -->

b 27 7 9

b 112

$$\text{iv} \ \text{f} ^ { - 1 } ( x ) = \sin ^ { - 1 } \left ( \frac { x + 1 } { 4 } \right ), \, \text{domain is } - 5 \leq x \leq 3, \\ \text{range is } - \frac { 1 } { 2 } \, \pi \leq f ^ { - 1 } ( x ) \leq \frac { 1 } { 2 } \, \pi \\ \text{a} \ \text{250} \ \text{a} \ \text{250} \ \text{b} \ \text{i} \ \text{Proof} \ \text{ii} \ \text{70}$$

## 7  Di fferentiation

## Prerequisite knowledge

- 1 a x 3 3 2 c x 1 2 1 2
- e x -3 2
- 2 a x --4( 2) 3

3

-

3

2

- 4 y x = + 2 1

## Exercise 7A

| a Chord         | AF   | BF   | CF        | DF        | EF        |
|-----------------|------|------|-----------|-----------|-----------|
| Gradient        | 2    | 2.5  | 2.8       | 2.95      | 2.99      |
| b 3             |      |      |           |           |           |
| a 4 c           |      | b    | - 2       |           |           |
| 1 2             |      | d    | - 3       |           |           |
| a x 5 4         |      | b    | x 9 8     |           |           |
| c - x 4 5       |      | d    | - x 1 2   |           |           |
| e 0             |      | f    | x 2 3 3   |           |           |
| g x 5 4         |      | h    | x 3 2     |           |           |
| a x 8 3         |      | b    | x 15 4    |           |           |
| c x 3 5         |      | d    | x - 3 2   |           |           |
| e - x 10 3 3    |      | f h  | 0         |           |           |
| g x 2           |      |      | - x 1 5   |           |           |
| a x - 10 1      |      | b    | x + 6 8 2 | x + 6 8 2 | x + 6 8 2 |
| c x - 10 3      |      | d    | x + 2 1   |           |           |
| e x x - 16 24 3 |      | f    | x - 10 3  | x 2 2     |           |

- b x 5 2 3
- d x -1 2 1
- f -x 2 5 5 3
- b x + -2(3 1) 5

$$& \text{$g$ - 1 4 x + \frac{3}{x^{2}} - \frac{4}{x^{3}}$} \quad \text{$hh$ - 3 - \frac{5}{x^{2}} + \frac{1}{4\sqrt{x^{3}}$} } \\ & \text{$i$ - 6 \sqrt{x} + \frac{3}{2\sqrt{x}} + \frac{1}{\sqrt{x^{3}}$} } \\ \text{$k$ - 2 3 } & \text{$hh$ - 0 \, \infty$}$$

$$\begin{vmatrix} & & & & & & \cdots & & \\ & 6 & a & 3 & & & & b & 0. 5 \\ & & & c & - \frac { 5 } { 4 } & & & & \\ & & & & & & & \\ & - & \cdots & & & & & & \\ \end{vmatrix}$$

- 7 15
- 8 -3
- 9 -8
- 10 ---( 2, 10), (2, 6)

11

5

4

- 12 a --( 2, 7), (3, 8)
- 13 a b = = -2, 7
- 14 a b = -= 5, 2
- 15 a b = = -4, 6
- 16 a b = -= 10.5, 18
- 17 , , x -2 3
- 18 &lt; x -1 and &gt; x 1 2
- 19 Proof

## Exercise 7B

- 1 a x + 6( 4) 5

- b x + 16(2 3) 7

- c x - - 20(3 4 ) 4

- d x 9 2 1 2 1 8 +    

- e x - 10(5 2) 7

- f x - 50(2 1) 4

- g x - - 56(4 7 ) 3

- h x - 21 5 (3 1) 6

- i x x + 10 ( 3) 2 4

- j x x - - 16 (2 ) 2 7

- k x x x + + 6 ( 2)( 4) 2 2

- l x x x - + 5( 5) (2 5) 3 4 3 6

- 2 a - + x 1 ( 2) 2

- b - - x 3 ( 5) 2

- c x - 16 (3 2 ) 2 72

- d - + x x 32 ( 2) 2 2

e

-

+

x

(3

1)

7

- f ( ) - + x 45 2 3 1 6

- g - + + x x x 16( 1) ( 2) 2 2

- h - - - x x x 49(4 5) (2 5) 8 8

- 3 a x - 1 2 5

- b x + 1 2 3

- c x x - 2 2 1 2

- d x x x - - 3 5 2 5 2 3

b

8, 2

-

309

310

e

g

- 4 10
- 5 12
- 6 4, 4 3
- 7 (5, 1)
- 8 a b = = 5, 3

## Exercise 7C

- 1 a y x = -3 7
- c y x = + 3 9
- 2 a y x = + 4 4
- c x y -= 6 9
- 3 a x y + = 4 4
- 4 a Proof
- 5 (0, 7.5)
- 6 -( 2.5, 8.5)
- 7 a y x = -4 68
- 8 a x + 2 20 3
- 9 -( 7.5, 2.5)
- 10 -( 6.2, 6.6)
- 11 a -( 32.6, 28.4) b 317.2 units 2
- 12 a --(2 3, 8 3), ( 2 3, 8 3)
- b x y + = 4 0
- 13 -(4, 1)
- 14 y x = + 0.6 1.6, 30.96 °
- 15 73
- 16 a -7

## Exercise 7D

$$\text{Exercise 7D} \\ \text{$a$} & \text{$2$} \\ \text{$c$} & \text{$-\frac{36}{x^{4}}$} \\ \text{$e$} & \text{$-\frac{4}{\sqrt{(4x-9)^{3}}$} \\ \text{$g$} & \text{$\frac{4x-30}{x^{4}}$} \\ \text{$i$} & \text{$-\frac{5x+12}{4\sqrt{x^{5}}$} }$$

-

-

3

3

(5

(2

2

-

1

x

-

2

x

)

5)

3

2

$$f = \frac { 3 } { \sqrt { 3 x + 1 } } \\ \mathbf h = \frac { 6 } { \sqrt { ( 2 - 3 x ) ^ { 4 } } }$$

- b x y + = 8 17
- d y x = -2 1
- b y x = -1
- d x y -= 5 6 3
- b y x = -4 7.5
- b (0.6, 2.48)
- b (17, 0)
- b Proof

b -(0.4, 5.48)

- b x -30 14
- d x -48(2 3) 2
- f x + 27 2 (3 1) 5
- h x x -+ 24 36 20 2
- 8 . x 5
- 9 Proof
- 10 Proof
- 11 a Proof b -8, 8
- 12 a b = -= 4, 4

In this image, we can see a graph.

<!-- image -->

## End-of-chapter review exercise 7

- 1 x x + 3 7 4 3 2
- 2 -3 5 9
- 3 Proof
- 4 x x ----15(3 5 ) 2, 150(3 5 ) 2
- 5 -8 15
- 6 i x y + = 4 5 66 ii (16.5, 0)
- 7 i -5 24 3
- x ii Proof
- 8 37.4
- 9 -(4.25, 7.5)
- 10 a y x = -+ 4 18 b y x = + 1
- 4 1
- 11 a Proof

b

i

-

(

0.8, 15.5)

$$\begin{matrix} | & & \\ & 1 2 & y = - \frac { 1 } { 2 } \, x \end{matrix}$$

Copyright Material  - Review Only -  Not for Redistribution

ii

(2.1, 8.25)

$$i \ \text{Proof} \quad \ \text{ii} \ \left ( - \frac { 9 } { 2 } \,, \, \frac { 9 } { 4 } \right ) \\ i i \ \left ( \frac { 1 } { 2 } \,, \, 4 ^ { 3 } _ { 4 } \right ) \\ i \ \, y - 2 = \frac { 1 } { 2 } \left ( x - 1 \right ), \, y - 2 = - 2 ( x - 1 ) \\ i i \ \, 2 ^ { 1 } _ { 2 } \\ i i \ \left ( \frac { 6 } { 1 1 }, \, \frac { 12 } { 1 1 } \right ), \, E \ \text{not midpoint of OA} \\ \text{Further differentiation}$$

## 8  Further di fferentiation

## Prerequisite knowledge

- 1 a -x x 1and 3 , . b , , x -2 3
- 2 a x -6 1, 6 b -x x 3 , 9 3 4

c

x

9

9

2

x

,

4

- 3 a x -10(2 1) 4 b -18 (1 3 ) 3 x

## Exercise 8A

- 1 a . x 4 b . x 1
- c -x 1.75 , d , x 0 and . x 8
- e , x 1 and . x 4 f 2 2 2 x , ,

-3

- 2 a 1 1 3 x ,
- b x 4.5 .
- c x 2 5 , , d -x 1 3 , ,
- e x 2 , and 6 2 3 x . f -x 4 , and 2 x .
- 3 1.5 3.5 x , ,
- 4 -8 (1 2 ) 2 x , increasing
- 5 -+ 2 6 ( 2) 3 x x , neither
- 6 Proof
- 7 + + x x x 8 20, 8 20 0, if 0 ù ù
- 8 Proof
- 9 7 20 x , ,

## Exercise 8B

- 1 a (2, 4) minimum
- b -( 0.5, 6.25) maximum
- c -( 2, 22) maximum; -(2, 10) minimum
- d --( 3, 17) minimum; (1, 15) maximum
- e --( 1, 4) minimum
- f (1, 7) -maximum; -(2, 11) minimum
- 2 a (9, 6) minimum b (1, 12) minimum
- c --( 3, 12) maximum; (3, 0) minimum
- d --( 2, 28) maximum; (2, 36) minimum
- e (4, 4) maximum f (2, 6) minimum
- 3 ≠ 18 , 18 0 3 3 x x
- 4 a -
- 2, 3 b -44, 81
- 5 a = 3 a
- b -3 1 x , ,
- 6 a = -= 15, 36 a b b -(2, 2), maximum
- 7 Proof
- 8 = + 3 2 x k , minimum; = -3 2 x k , maximum
- 9 (0, 1), minimum; (1, 2), maximum;
- (2, 1), minimum
- 10 a = -= 6, 5 a b
- b minimum
- c (0, 5), maximum
- 11 a = = 4, 16 a b
- d --(2, 11), 12
- b minimum
- c 0 and 2 x x , .
- 12 a = = -54, 22 a b b minimum
- c 0 and 0 3 x x , , ,
- 13 a = -= -3, 12 a b b -( 1, 14)
- c -= -= (2, 13) minimum, ( 1, 14) maximum
- d -(0.5, 0.5), 13.5

<!-- image -->

## Exercise 8C

- 1 a = - y x 9 b i = - P x x 9 2 3 ii 108 c i = - + Q x x 5 36 162 2 ii 97.2

- 2 a θ = - r 40 2

r

- b Proof

- c = r 10

- d = A 100, maximum

- 3 a = - y x 50 2

- b Proof

- c = = A x 312.5, 25

- 4 a - + x x 3 10 160 2

- b = 1 , 151 cm 2 3 2 3 2 x

- 5 a Proof

- b = A 37.5, maximum

- 6 a = - QR p 9 2

- b Proof

- c = p 3

- d = A 12 3, maximum

311

312

- 7 a Proof
- c Maximum
- 8 a = 288 2 y

$$\nu = \frac { 2 \circ \circ } { x ^ { 2 } } \quad \ \ \ b \text{ Proof}$$

- c 432, 12 cm by 6cm by 8cm
- 9 a = --π y x x 1 1 2 1 4 b Proof

A

d

1

d

A

2

c

d

x

4

d

x

2

=

-

= -

1

,

1

x

x

-

π

d

4

4

+ π

1

4

-

2

+ π

4

=

e

A

- 10 a = --π h r r 5 2 2 b Proof
- c = -- π = -- π A r r r A r d d 5 4 , d d 4 2 2
- d + π 5 4 e + π 25 8 2 , maximum
- 11 a = -r x 50 2
- π c π + = + π ) = 100 ( 4) 14.0, 2500 (4 350, minimum

Proof

b

- 12 a = h r 432 2
- b Proof
- c = r 6
- 13 a = -y x x 500 24 10 2
- c 5 10 6
- 14 a = -h r r 160 3 2

c

=

8

r

- 15 a = -r h h 20 2 13 1
- c 3
- d = π A 216 , minimum
- b Proof
- d Proof
- b Proof
- b Proof
- d 1241, maximum

## Exercise 8D

- 1 -0.315 units per second, decreasing
- 2 1 300 units per second
- 3 -0.04 units per second
- 4 0.08 units per second
- 5 1.25 units per second
- 6 0.09 units per second, increasing
- 7 1, 6
- 8 0.016 units per second
- 9 1 3 , 3

π

, maximum

- b = = V x 486, 3

## Exercise 8E

- 1 π -4 5 cm s 2 1
- 2 -18 cm s 3 1
- 3 π -cm s 3 1
- 4 -0.003 cms 1
- 5 -0.125 cms 1
- 6 -1 320 cms 1
- 7 π -9 cm s 2 1
- 8 a Proof
- 9 a -1 3 cms 1
- 10 a Proof
- 11 π -32 cm s 2 1
- 12 a π 2 10 cm
- 13 a π -40 cm s 3 1
- b i -1.024 cms 1
- ii π -8 cm s 2 1

## End-of-chapter review exercise 8

- 1 π -2 45 cms 1
- 2 π -300 m hr 2 1
- 3 Maximum
- 4 = 0.0032kgcm , 0.096kgday 3 -1 k
- 5 i = + A p p 2 2 3
- ii 0.4
- 6 i Proof
- 7 i Proof
- ii 20 m by 24m
- ii 120, minimum
- 8 i = -y x 4(6 )
- 3 ii Proof
- iii = A 72
- 9 i = -+ = d d 8 2, d d 16 2 2 2 3 y x x y x x
- ii (2, 8), minimum since d d 0 2 2 y x . when = x 2

$$\Big | \quad ( - 2, - 8 ), \max \text{sum since } \frac { d ^ { 2 } y } { d x ^ { 2 } } < 0 \text{ when } x = - 2$$

$$\left | \begin{array} { c c c } & & a x ^ { - } \\ & 1 0 & i \quad y = 3 0 - x - \frac { \i x } { 4 } & & i i \ \text{Proof} \\ & & i i i \ x = 1 5 & & i v \ \text{Maximum} \end{array} \right |$$

- b -3 cms 1
- b --9 cms 1

$$b \frac { \sqrt { 5 } } { 1 2 0 } \, c m s ^ { - 1 } \\ \frac { 1 } { 7 } \, c m s ^ { - 1 } \\ - \frac { 9 } { 1 0 0 \pi } \, c m$$

$$\mathbf b = \frac { 5 } { 4 \pi } \sqrt { \frac { \pi } { 1 0 } } \, \mathbf c m s ^ { - 1 }$$

- a -x 2 4 , ,
- 11 3 b Maximum at 5 3 , 364 27 -    , minimum at (1, 4) 12 i Proof ii Maximum 13 i 2 3 , 4 27 3 -      p p ii (0, 0) minimum, 2 3 , 4 27 3 -      p p maximum iii p 0 3 , ,

## 9  Integration

## Prerequisite knowledge

$$\text{Prerequisite knowledge} \\ 1 \quad a \ \ - 1 9 \ \quad b \ \ - 1 \\ 2 \quad a \ \left ( - \frac { 2 } { 3 } \,, \, 5 \right ) \ \quad b \ \ ( 0, 9 ) \\ 3 \quad a \ \ 2 4 x ^ { 7 } - 1 3 \ \quad b \ \ 1 0 x - 4 + \frac { 5 } { \sqrt { x } } \\ \text{$\dots$} \ \ - a$$

## Exercise 9A

- 1 a = + 5 3 y x c
- c = + 3 4 y x c

c

x

y

b

2

7

+

=

d

c

y

= -

+

- e = -+ y x c 1 4 2

3

x

- f = + 8 y x c
- 2 a = -+ + f( ) 2 2 5 4 x x x x c

=

2

x

x

6

3

b

3

2

x

x

c

)

f(

+

-

+

- c = --+ f( ) 3 1 8 2 2 x x x x c
- d = -+ -+ x x x x c f( ) 3 2 3 4 6
- 3 a = + + 3 5 2 3 2 y x x c

=

x

x

3

2

3

4

b

3

2

c

y

+

+

=

3

2

x

4

c

4

y

c

x

x

8

2

-

+

-

- d = -+ + 4 5 4 1 2 2 y x x x c

7

3

5

e

y

=

2

x

7

2

5

f

=

y

x

2

2

- 4 a + x c 2 6 c -+ x c 3

-

+

12

x

5

3

2

2

+

+

2

6

x

2

x

+

b

d

2

x

+

c

5

x

c

4

-

2

x

2

+

c

+

c

In this image, we can see a graph.

<!-- image -->

## Exercise 9B

- 1 a = + + y x x 2 3

c

=

-

y

4

x

10

b

d

y

y

e

=

-

+

y

x

x

4

2

$$\mathfrak { f } _ { \quad y } = 2 \sqrt { x } -$$

- 2 = + y x 3 2
- 3 = -+ -y x x x 2 6 5 4 3 2
- 4 = + -5 3 2 3 2 y x x
- 5 a = + -y x x x 2 2 1 2
- 6 = + -y x x 2 3 7 2
- 7 = + -x x x f( ) 4 8 2
- 8 a = + -+ y x x x 1 2 10 3 3 2
- b -x 2 , and . 1 2 3 x
- 9 a = + + + 2 6 10 4 3 2 y x x x
- 10 = + --2 4 2 2 3 y x x x
- 11 a -3.5
- b = P minimum, = Q maximum

<!-- image -->

<!-- image -->

=

-

+

x

x

2

5

3

2

=

+

-

x

6

2

x

4

b = -y x 42 97

- b Proof

313

314

- 14 ( ) -11, 408 1 3
- 15 a = + -9 3 2 y x x b = + 5 21 y x
- 16 a = -+ 2 6 10 y x x x b (4, 2), minimum
- 17 (1, 7), maximum
- 18 a = -+ 5 2 2 y x x b + = -1 x y c -(1, 2)

## Exercise 9C

- 1 a -+ 1 18 (2 7) 9 x c
- c -+ 2 45 (5 2) 9 x c

3

4

e

3

16

x

(5

)

4

+

-

-

- g -+ 4 3 3 2 x c
- i -+ 5 32(7 2 ) 4 x c
- 2 a = -+ 1 8 (2 1) 2 4 y x

c

y

x

5

2

2

-

=

+

- 3 = --3( 5) 1 4 y x
- 4 a 5 7 x y
+ = b = --5 2 3 4 y x
- 5 a Maximum
- b = + --+ 8 3 1 2 2 5 2 y x x x
- 6 = --4 2 5 2 y x

## Exercise 9D

- 1 a + 8 ( 2) 2 3 x x b + + 1 8 ( 2) 2 4 x c
- 2 a -20 (2 1) 2 4 x x b -+ 1 20 (2 1) 2 5 x c
- 3 a = -2 k b --+ x c 2 5 2

4

a

6

x

1

(4

-

3

)

2

2

x

b

+

c

- 5 a --+ 6(2 3)( 3 5) 2 5 x x x
- b -+ + ( 3 5) 3 2 6 x x c

4(

+

3)

7

6

a

x

x

- 7 a -15 (2 1) 4 x x x
- b + + 1 4 ( 3) 8 x c

b

1

5

5

(2

x

x

-

1)

+

8

-

6

x

2

b

d

f

h

b

d

1

18

-

1

5

-

y

y

1

4

x

(3

+

(1

(2

-

x

+

2

x

(2

=

=

+

1

3

3

1)

1)

6

2

x

)

5

1)

2

2

(2

+

6

+

+

x

2

-

2

+

x

c

+

c

c

c

3

5)

+

6

2

c

-

c

7

| Exercise9E   | Exercise9E            | Exercise9E   | Exercise9E   |
|--------------|-----------------------|--------------|--------------|
| 1            | a 7                   | b            | 16 9         |
|              | c - 6                 | d            | 21           |
|              | e 9                   | f            | 5            |
|              |                       |              | 2            |
| 2            | a 11 2                | b            | 3            |
|              | c                     | 107 6 d      | 4 15         |
|              | e 37 8                | f            | 18           |
| 3            | a 10                  | b            | 26 3         |
|              | c 2 5                 | d            | 4            |
|              | e                     | 2 f          | 8            |
| 4            | a - x 4               | b            | 4            |
|              | + x ( 5) 2 2          |              | 45           |
| 5            | a - 15 ( 2) 2 3 4 x x | b            | 2 1 15       |
| 6            | a + ( 1) 4 x x        | 4 b          | 84 2 5       |
| Exercise 9F  | Exercise 9F           | Exercise 9F  | Exercise 9F  |
| 1            | a 21 1 3              | b            | 8            |
|              | c                     | 20 5 6 d     | 5 1 3        |
| 2 Proof      | 2 Proof               | 2 Proof      | 2 Proof      |
| 3            | a 11 5                | b            | 40 1 2       |
|              | c                     | 6 4 3 32 d   | 21 1 12      |
| 4            | a 7 1 5               | b            | 5 1 2        |
|              | c                     | 15.84 d      | 14           |
|              | e                     | 16 f         | 9            |
| 5            | a 48 3                | b            | 6            |
| 4 6 3 1 3    | 4 6 3 1 3             | 4 6 3 1 3    | 4 6 3 1 3    |
| 7 10 2 3     | 7 10 2 3              | 7 10 2 3     | 7 10 2 3     |
| 8            | a 9                   | b            | 1.6          |
| 9            | a Proof               | b            | - 3          |
| 10 18 2 3    | 10 18 2 3             | 10 18 2 3    | 10 18 2 3    |
| 11           | a - ( 1, 0)           | b            | 90           |
| 12 10 1 2    | 12 10 1 2             | 12 10 1 2    | 12 10 1 2    |
| 34           | 34                    | 34           | 34           |
| 14 26        | 14 26                 | 14 26        | 14 26        |

## Exercise 9G

- 1 26 2 3

- 2 10 2 3

- 3 57 1 6

- 4 a 36

b 10 2 3

- c 36

- 5 1 3

- 6 1 1 3

- 7 a = + 1 3 2 y x

- b - 1 2 (2 3 3)

- 8 a = - + 3 46 y x

b 64

9 a = - + 8 16 y x

b 108

10 a = - 2 1 y x

b 8.83

## Exercise 9H

1 a 2

- b 1 256

c

-

5

4

d 4

e 50

f 16

g 6 3

h 1

i

20

9

- 2 Proof

- 3 a Proof

- b Proof

- c Proof

d Proof

- e Proof

- f Proof

## Exercise 9I

- 1 a π 71 5
- c π 15 8
- 2 a π 81 2
- 3 6
- 4 π 39 4
- 5 a π 24

b π 24

- 6 a ∪ -shaped curve, y -intercept vertex = (2, 0)
- b 32 5
- = 4, π
- b π 16 3
- d π 25 4
- b π 124 15

7 a (25, 0)

- b π 3125 6

8 a (0, 3)

- b π 16

- 9 a       1 3 , 7 , (2, 7)

- b π 250 9

- 10 Proof

- 11 a π 52 3

- b π 128 3

- 12 a π 8 3

- b π 32 5

- 13 a π 1888 3 cm 3

- b π 171 cm 3

- 14 Proof

## End-of-chapter review exercise 9

- 1 = + -f( ) 3 5 7 4 2 x x x
- 2 --+ x x x c 25 3 20 4 3
- 3 = --30 6 5 2 2 y x x
- 4 = + + -f( ) 6 2 4 10 2 x x x

5

π

194

9

- 6 a 1

b = -+ f( ) 3 6 8 2 x x x

- 7 10 2 3
- 8 a ∪ -shaped curve, y -intercept (0 , 11), vertex at (3, 2)
- b π 483

5

- 9 i Proof
- 10 i (0, 1), (4, 3) B C

iii

π

2

15

- 11 i Proof
- 12 i 1 9 or 9

ii

x

x

ii 9 4

ii = -+ 3 15 y x

- ii 1 iii π 5 3

-

1

9

3

x

f

(

)

3

2

3

2

′′

=

-

at

x

x

=

9

min

- iii = + -+ f( ) 2 6 10 5 3 2 1 2 x x x x

$$\begin{array} {$$

2

=

max, at

-

1

2

315

316

## Cross-topic review exercise 3

$$1 \quad y = \frac { 2 } { 3 } x ^ { 3 } - 3 x +$$

- 2 i -0.6

$$\text{i} \rightarrow y = 2 x - \frac { 1 6 } { 3 }$$

- 3 i = -+ 2 6 2 3 2 y x x ii = 4, x minimum
- 4 i = -+ + 3 2(1 2 ) 1 y x ii -x x 1, 2 . ,
- 5 i       1 2 , 0 ii 1 6
- 6 i 4 9 ii -2 27
- 7 a Proof
- b Proof

c

1250

(

π +

=

4)

175(3 s.f.), maximum

- 8 i 12 ii = -= -1 or 3 x x ,  1 1 3
- 9 i = -d d 9 (2 ) 2 y x x , no turning points since ≠ d d 0 y x
- ii 81 2 π iii -k k 8, 4 , .
- 10 a ′ = -+ + &lt; x x x f ( ) 8 (2 1) , 8 (2 1) 0 2 2 b = --f ( ) 4 2 1 x x x , , &lt; 0 4 x

<!-- image -->

4

- 11 i = --2 3 2 2 3 3 2 1 2 y x x ii + --1 2 1 2 1 2 3 2 x x iii -(1, 2), minimum
- 12
- i -= --y x 6 2 7 ( 2) ii = + + 2 1 2 y x x iii = 1, x minimum since . ′′ f (1) 0
- 13 i 13
- ii x x = -= 1(max), 2 (min)

$$\begin{array} { c c c c c c } 1 4 & \mathfrak { i$$

## Practice exam-style paper

- 1 ′ = + f ( ) 2 15 0 4 x x . for all x
- 2 = -+ -+ y x x x 6 12 11 3 2
- 3 Proof
- 4 a -+ 2187 10206 20412 2 x x b -30618
- 5 a π 3 2 (4 3 3) cm 2
- b π + + (2 3 3 3) cm

b 2 17 x y

- 6 a -+ + = ( 3) ( 2) 20 2 2 x y -=
- 7 a -7, 8

b

i

1

27

3

ii

8

- 8 a --21 2( 3) 2 x b (3, 21)
- c &lt; &gt; -+ 3 13, 3 13 x x
- 9 a &lt; &lt; 1 f( ) 11 x
- c 0.927 rad, 5.36 rad
- d = -      --g ( ) cos 6 5 1 1 x x 10 a + = 3 4 17 x y b 1 240 units per second 11 a ---x x x 16 2 , 32 2 2 3 b --( 2, 12), maximum c π 431 5

<!-- image -->

## Glossary

## A

Amplitude: the distance between a maximum (or minimum) point and the principal axis of a sinusoidal function

Arithmetic progression: each term in the progression differs from the term before by a constant

Asymptote: a straight line such that the distance between a curve and the line approaches zer o as they tend to infinity

## B

Basic angle: the acute angle made with the x -axis

Binomial: a polynomial with two terms

Binomial coefficients: the coefficients in a binomial expansion Binomial theorem: the rule for expanding + + (1 ) or ( ) x a b n n

## C

Chain rule: the rule for computing the derivative of the composition of two functions

Common difference: the difference between successive terms in an arithmetic progression

Common ratio: the constant ratio of successive terms in a geometric progression

Completed square form: the equation

-+ -= ( ) ( ) 2 2 2 x a y b r , where ( , ) a b is the centre and r is the radius of the circle

Completing the square: writing the expression + + 2 ax bx c in the form + + ( ) 2 d x e f

Composite function: a function obtained from two given functions by applying first one function and then applying the second function to the result

Convergent series: a sequence that tends to a finite number

## D

Decreasing function: a function whose value decreases as x increases

Definite integral: an integral between limits whose result does not contain a constant of integration

Derivative: denoted by d d of f( ) y x x ; gives the gradient of a curve

Differentiation: the process of finding the gradient of a curve

Differentiation from first principles: the process of finding the gradient of a curve using small increments

Discriminant: the part of the quadratic formula underneath the square root sign

Domain: the set of input values for a function

## F

Factorial: × = 6 5 4 3 2 1 6 !  (read as '6 factorial')

× × × × First derivative: see Derivative

Function: a rule that maps each x value to just one y value for a defined set of input ( x ) values

## G

General form of a circle: the equation + + + + = 2 2 --

2 2 0 x y gx fy c , where ( , ) g f is the centre and + -2 2 g f c is the radius of the circle

Geometric progression: each term in the progression is a constant multiple of the preceding term

Gradient function: the derivative f ( ) ′ x is also known as the gradient function of the curve = f( ) y x

## I

Identity: a mathematical relationship equating one quantity to another

Improper integrals: a definite integral that has either one limit or both limits are infinite, or a definite integral where the function to be integrated approaches an infinite value at either or both endpoints in the interval (of integration)

Increasing function: a function whose value increases as x increases

Indefinite integral: an integral without limits whose result contains a constant of integration

Integration: the reverse process of differentiation

Inverse function: the inverse of a function, -f ( ) 1 x , is the function that undoes what f( ) x has done

## M

Many-one: a function which has one output value for each input value but each output value can have more than one input value

Mapping: a diagram to show how the numbers in the domain and range are paired

Maximum point: a point, P , on a curve where the value of y at this point is greater than the value of y at other points close to P

Minimum point: a point, Q , on a curve where the value of y at this point is less than the value of y at other points close to Q

## N

Normal: the line perpendicular to the tangent at a point on a curve

318

## O

One-one: a function where exactly one input value gives rise to each value in the range

## P

Parabola: the graph of a quadratic function

Pascal's triangle: a triangular array of the binomial coef ficients, where each number is the sum of the two numbers above

Period: the length of one repetition or cycle of a periodic function

Periodic functions: a function that repeats its values in regular intervals or periods

Point of inflexion: a point on a curve at which the direction of curvature changes

Principal angle: the angle that the calculator gives is called the principal angle

Q

Quadrant: the Cartesian plane is divided into four quadrants

Quadratic formula: the formula = -± -4 2 2 x b b ac a , which is used to solve the equation + + = 0 2 ax bx c

## R

Radian: one radian is the angle subtended at the centre of a circle by an arc that is equal in length to the radius of a circle

Range: the set of output values for a function

Reference angle: the acute angle made with the x -axis

Roots: if f( ) x is a function, then the solutions to the equation = f( ) 0 x are called the roots of the equation

## S

Second derivative: denoted by ″ x d d or f ( ) 2 2 y x and is used to determine the nature of stationary points on a curve

Series: the sum of the terms in a sequence

Self-inverse function: a function f    where = -f ( ) f( ) 1 x x for all x

Solid of revolution: the solid formed when an area is rotated through ° 360  about an axis

Stationary point: a point on a curve where the gradient is zero, also known as a turning point

## T

Tangent: a straight line that touches a curve at a point Term: a number in a sequence

Turning point: a point on a curve where the gradient is zero, also known as a stationary point

## V

Vertex: the vertex of a parabola is the maximum or minimum point

Volume of revolution: the volume of the solid formed when an area is rotated through ° 360  about an axis

## Index

| addition/subtraction rule, differentiation 195 amplitude of a periodic                                                                                                                |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| function 129 angles                                                                                                                                                                   |
| degrees 100 general de finition of 121-2 radians 101-2 length of 104-5                                                                                                                |
| arcs, area bounded by a curve and a line 260-1 area bounded by two curves 260-1 area enclosed by a curve and the y- 255-6 area under a curve 253-5 arithmetic progressions 166-7, 180 |
| axis                                                                                                                                                                                  |
| sum of 167-9                                                                                                                                                                          |
| asymptotes 129                                                                                                                                                                        |
| basic angle (reference angle) 121-2                                                                                                                                                   |
| binomial coefficients 160-4                                                                                                                                                           |
| binomial expansions 156-8 binomial theorem 161                                                                                                                                        |
| calculus 191 see also differentiation; integration Cantor, Georg 181                                                                                                                  |
| Cartesian coordinate system 83 quadrants of 122                                                                                                                                       |
| chain rule, differentiation                                                                                                                                                           |
| 198-200 connected rates of change 228-9                                                                                                                                               |
| circles                                                                                                                                                                               |
| area of a sector 107-8                                                                                                                                                                |
| equation of 82-7 intersection with a line                                                                                                                                             |
| 88-90 length of an arc 104-5                                                                                                                                                          |
| right-angle facts 85                                                                                                                                                                  |
| (range) of a function                                                                                                                                                                 |
| codomain inverse functions 43, 45                                                                                                                                                     |
| combined transformations of functions 59-60 trigonometric functions 132 two horizontal transformations                                                                                |
| 61-3 two vertical transformations 60-1                                                                                                                                                |
| difference, arithmetic                                                                                                                                                                |
| progressions 166                                                                                                                                                                      |
| geometric progressions                                                                                                                                                                |
| common                                                                                                                                                                                |
| commonratio,                                                                                                                                                                          |
| 171 communication vi                                                                                                                                                                  |
| 35-7                                                                                                                                                                                  |

| completing the square 6-8 graph sketching 19 proof of the quadratic formula 10 composite functions 39-41                                 |
|------------------------------------------------------------------------------------------------------------------------------------------|
| trigonometric identities 145-7, 149 decreasing functions 213-15 definite integration 250-2 area bounded by a curve and a line 260-1      |
| area bounded by two curves 260-1 area enclosed by a curve and the y- axis 255-6 area under a curve 253-5 improper integrals 264-7 268-70 |
| degrees 100 converting to and from radians 101-2                                                                                         |
| derivatives 193 first and second 205-6 see also differentiation                                                                          |
| Descartes, René 83                                                                                                                       |
| differentiation 191-6                                                                                                                    |
| volumes of revolution                                                                                                                    |
| addition/subtraction 195                                                                                                                 |
| chain rule 198-200                                                                                                                       |
| rule constants 195                                                                                                                       |
| increasing and decreasing functions                                                                                                      |
| 213-15                                                                                                                                   |
| notation 193                                                                                                                             |
| practical applications of connected rates of change 230-2 practical                                                                      |
| problems 221-3                                                                                                                           |
| rates of change                                                                                                                          |
| maximum and                                                                                                                              |
| minimum                                                                                                                                  |
| 227-9                                                                                                                                    |
| real life uses of 212                                                                                                                    |

| scalar multiple rule 195 second derivatives 205-6 stationary points 216-19 tangents and normals 201-3 differentiation from first principles 193 discriminant 24   |                      |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------|
| equation of a circle 82-3, 86-7 completed square form 83-4 expanded general form 84-5 equation of a straight line 78-80 tangents and normals 202                  |                      |
| first derivative test 217 first derivatives 205 functions composite 39-41 definitions 34 domain and range 35-7                                                    |                      |
| graph of a function and its inverse 48-9 increasing and decreasing 213-15 inverse of 43-5, 48-9                                                                   |                      |
| many-one 35 one-one 34-5 quadratic see quadratic functions self-inverse 44 transformations of 51 combined transformations                                         |                      |
| 59-63 re flections 55-6 stretches 57-8 translations 52-3 trigonometric see cosine; sine;                                                                          |                      |
| tangent; trigonometry use in modelling 34                                                                                                                         |                      |
| Galileo Galilei 2 Gauss, Carl 167 geometric progressions 171-2, 180                                                                                               |                      |
| infinite geometric series 175-8                                                                                                                                   |                      |
| sum of 173-4                                                                                                                                                      |                      |
| 75, 192-3                                                                                                                                                         |                      |
| and equation of a                                                                                                                                                 |                      |
| straight                                                                                                                                                          |                      |
| line                                                                                                                                                              |                      |
| gradients                                                                                                                                                         |                      |
| 78-80 of tangents and normals 201-3                                                                                                                               |                      |
|                                                                                                                                                                   | also differentiation |
| see                                                                                                                                                               |                      |

320

| gradients of parallel and perpendicular lines 75-7 graph of a function and its inverse 48-9 graph sketching 17-19 quadratic inequalities 22 graphs of trigonometric functions transformations 130-3                                                                                                                                                                                                        |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| horizontal transformations, combination of 61-3                                                                                                                                                                                                                                                                                                                                                            |
| infinite geometric series 175-8 infinity 181 improper integrals 264-7 inflexion, points of 216 integration 239, 249 area bounded by a curve and a line 260-1 area bounded by two curves 260-1 area enclosed by a curve and the y- axis 255-6 area under a curve 253-5 definite 250-2 of expressions of the form ( ax + b ) 247-8 finding the constant of 244-5 formulae for 241-3 improper integrals 264-7 |
| n                                                                                                                                                                                                                                                                                                                                                                                                          |
| identities, trigonometric 145-7, 149 image set of a function see range (codomain) of a function improper integrals type 1 264-6 type 2 266-7                                                                                                                                                                                                                                                               |
| increasing functions 213-15                                                                                                                                                                                                                                                                                                                                                                                |
| indefinite integrals 241                                                                                                                                                                                                                                                                                                                                                                                   |
| inequalities, quadratic 21-3                                                                                                                                                                                                                                                                                                                                                                               |
| notation 240                                                                                                                                                                                                                                                                                                                                                                                               |
| as the reverse of                                                                                                                                                                                                                                                                                                                                                                                          |
| differentiation 239-40                                                                                                                                                                                                                                                                                                                                                                                     |
| volumes of revolution of a line and a                                                                                                                                                                                                                                                                                                                                                                      |
| 268-70 parabola                                                                                                                                                                                                                                                                                                                                                                                            |
| intersection 27-8 functions 43-5                                                                                                                                                                                                                                                                                                                                                                           |
| inverse graphs of 48-9                                                                                                                                                                                                                                                                                                                                                                                     |
| trigonometric functions                                                                                                                                                                                                                                                                                                                                                                                    |
| notation 193                                                                                                                                                                                                                                                                                                                                                                                               |
| 104                                                                                                                                                                                                                                                                                                                                                                                                        |
| Lagrange's latitude                                                                                                                                                                                                                                                                                                                                                                                        |
| Gottfried 193, 239                                                                                                                                                                                                                                                                                                                                                                                         |
| of a line segment                                                                                                                                                                                                                                                                                                                                                                                          |
| 72-4                                                                                                                                                                                                                                                                                                                                                                                                       |
| Leibnitz, length                                                                                                                                                                                                                                                                                                                                                                                           |
| 136-9                                                                                                                                                                                                                                                                                                                                                                                                      |

limits of integration 250

| line segments gradient 75 length and mid-point 72-4 parallel and perpendicular 75-7 see also straight lines lines of symmetry, quadratic functions 17-19 longitude 104 many-one functions 35 mappings see functions maximum points 17-19, 216-17 practical problems 221-3 and second derivatives 218-19 mid-point of a line segment 72-4 minimum points 17-19, 216-17 practical problems 221-3 218-19   |              |       |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|-------|
| normals, gradient 201-3 n th term of a geometric progression 171-2 progression                                                                                                                                                                                                                                                                                                                          |              |       |
| one-one functions 34-5 oscillations 117                                                                                                                                                                                                                                                                                                                                                                 |              |       |
| parabolas 17-19 intersection with a line 27-8 lines of symmetry 17-19 maximum and minimum values 17-19 paraboloids 18                                                                                                                                                                                                                                                                                   |              |       |
| parallel lines 75 Pascal's triangle 157-8 periodic functions 129                                                                                                                                                                                                                                                                                                                                        |              |       |
| perpendicular lines 75                                                                                                                                                                                                                                                                                                                                                                                  |              |       |
| points of inflexion 216 power rule,                                                                                                                                                                                                                                                                                                                                                                     |              | 194-5 |
| differentiation principal angle 137, 138 problem solving vi                                                                                                                                                                                                                                                                                                                                             |              |       |
| quadrants of the Cartesian                                                                                                                                                                                                                                                                                                                                                                              | 121          |       |
| and second derivatives modelling vi-vii                                                                                                                                                                                                                                                                                                                                                                 |              |       |
| Newton, Isaac 193, 239                                                                                                                                                                                                                                                                                                                                                                                  |              |       |
| n th term of an arithmetic                                                                                                                                                                                                                                                                                                                                                                              |              |       |
| 166-7                                                                                                                                                                                                                                                                                                                                                                                                   |              |       |
| quadratic curves, a                                                                                                                                                                                                                                                                                                                                                                                     |              |       |
| line 27-8                                                                                                                                                                                                                                                                                                                                                                                               |              |       |
| quadratic equations                                                                                                                                                                                                                                                                                                                                                                                     |              |       |
| completing the square                                                                                                                                                                                                                                                                                                                                                                                   |              |       |
| functions of x 15-16                                                                                                                                                                                                                                                                                                                                                                                    |              |       |
| number of roots 24-5                                                                                                                                                                                                                                                                                                                                                                                    |              |       |
| simultaneous equations                                                                                                                                                                                                                                                                                                                                                                                  |              |       |
| 6-8                                                                                                                                                                                                                                                                                                                                                                                                     |              |       |
| 11-13                                                                                                                                                                                                                                                                                                                                                                                                   |              |       |
|                                                                                                                                                                                                                                                                                                                                                                                                         | intersection |       |
|                                                                                                                                                                                                                                                                                                                                                                                                         | with         |       |
|                                                                                                                                                                                                                                                                                                                                                                                                         |              | plane |

| quadratic formula 10                                          |
|---------------------------------------------------------------|
| quadratic functions 2                                         |
| graph sketching 17-19                                         |
| lines of symmetry 17-19                                       |
| maximum and minimum values                                    |
| 17-19                                                         |
| quadratic inequalities 21-3                                   |
| radians 101                                                   |
| area of a sector 107-8                                        |
| converting to and from degrees 101-2                          |
| length of an arc 104-5                                        |
| simple multiples of π 102 range (codomain) of a function 35-7 |
| inverse functions 43, 45                                      |
| rates of change 227-8                                         |
| connected 228-9                                               |
| practical applications 230-2                                  |
| recurring decimals 176                                        |
| reference angle (basic angle) 121-2 reflections 55-6          |
| revolution, volumes of 268-70                                 |
| right-angle facts for circles 85                              |
| roots of a quadratic equation 24-5                            |
| scalar multiple rule, differentiation 195                     |
| second derivatives 205-6 and stationary points 218-19         |
| area of 107-8                                                 |
| sectors,                                                      |
| self-inverse functions 44 graphs of 48                        |
| sequences                                                     |
| arithmetic progressions geometric progressions                |
| 166-9 171-4 infinite geometric series 175-8                   |
| 156, 167                                                      |
| series                                                        |
| binomial coefficients 160-4 binomial expansion of ( a +       |
| b ) n 156-8                                                   |
| simultaneous equations 11-13                                  |
| sine angles between 0 ° and 90 ° 118-20                       |
| general angles 123-6                                          |
| graph of 128-9 inverse of 136, 138-9                          |
| transformations of                                            |
| 130-1 trigonometric equations                                 |
| 140-4 trigonometric identities 145-7,                         |
| 149 a graph 17-19                                             |
| quadratic inequalities 22                                     |
| of revolution 268                                             |
| solids                                                        |
| sphere, surface area of 14                                    |
| sketching                                                     |

| stationary points 17-19, 216-17 practical maximum and minimum problems 221-3 and second derivatives 218-19                                                                                                                                                                                                                                |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Stevin, Simon 176 straight lines equation of 78-80 intersection with a circle 88-90 intersection with a quadratic curve 27-8 see also line segments stretch factors 57-8 stretches 57-8 trigonometric functions 130 sum of an arithmetic progression 167-9 sum of a geometric progression 173-4 sum of an infinite geometric series 175-8 |

| tangent (trigonometric ratio) angles between 0 ° and 90 ° 118-20 general angles 123-6 graph of 129 inverse of 137   |
|---------------------------------------------------------------------------------------------------------------------|
| trigonometric equations 141-3 trigonometric identities 145-7,                                                       |
| 149 tangents to a curve 27                                                                                          |
| gradient 201-3 terms of a sequence 166 trajectories 2                                                               |
| transformations of functions 51                                                                                     |
| combined transformations 59-63 reflections 55-6 stretches 57-8                                                      |
| translations 52-3 trigonometric functions 130-3 52-3                                                                |
| trigonometric functions 131                                                                                         |
| equations 140-4, 149                                                                                                |
| trigonometric                                                                                                       |
| translations                                                                                                        |

| trigonometric identities 145-7, 149                                                                                                                                                                     |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| trigonometry 117 angles between 0 ° and 90 ° 118-20 general definition of an angle 121-2 graphs of functions 127-33 inverse functions 136-9 ratios of general angles 123-6 transformations of functions |
| Underground Mathematics                                                                                                                                                                                 |
| vii                                                                                                                                                                                                     |
| 130-3 turning points 17-19, 216 see also stationary points                                                                                                                                              |
| vertex of a parabola 17-19                                                                                                                                                                              |
| vertical transformations, combination of 60-1                                                                                                                                                           |
| volumes of revolution 268-9 rotation around the x -axis                                                                                                                                                 |
| 269-70                                                                                                                                                                                                  |
| rotation around the y -axis 268-9                                                                                                                                                                       |

waves 117

321