## PHYSICS GRADE 9

In this image we can see a picture of a machine.

<!-- image -->

In this image, we can see a poster with some text and images.

<!-- image -->

- -Head Curriculum Implementation,Textbook Development and Evaluation

## PHYSICS TEXTBOOK DEVELOPMENT PANEL

## MAURITIUS INSTITUTE OF EDUCATION

Dr Sarojiny Saddul-Hauzaree

- Coordinator, Associate Professor, MIE

Mohun Cyparsade

- Associate Professor, MIE

Priya Darshini Lollchund

- Educator

Maneeshah Ramkurrun

- Educator

Sandeep Seebaluck

- Educator

John Harry Tan Wee

- Educator (Rodrigues)

Design

Leveen Nowbotsing

Rakesh Sookun

Acknowledgements

The Science textbook panel wishes to thank:

-   Dr Anwar Bhai Ramjaun (Associate Professor, MIE), Dr Ravhee Bholah (Associate Professor, MIE) and Dr Fawzia Narod (Associate Professor, MIE) for their contribution.
- -Dr Helina Hookoomsing (Senior Lecturer, MIE), Majhegy Murden -Louise (Lecturer, MIE),

Suryakanti Anu Fulena (Lecturer, MIE), Kamini Moteea (Lecturer, MIE)  for proofreading.

- -Prakash Roopun (Senior Laboratory Technician, MIE) for taking photos that have been used in the textbook.

## GRADE 9 PHYSICS TEXTBOOK REVIEW PANEL

Mohun Cyparsade

- Overall Coordinator, Associate Professor, MIE

Dr Khemanand Moheeput

- Lecturer, MIE

Charlotte Pierre Brune

- Educator

Mouvish Jhummun

- Educator

Design

Karnesh Ramful

- Graphic Designer, MIE

Acknowledgements

The Science (Physics) textbook panel wishes to thank:

- Dr Yesha Devi Mahadeo-Doorgakant (Lecturer, MIE) for proofreading.

- © Mauritius Institute of Education (2023)

ISBN: 978-99949-75-29-7

Consent  from  copyright  owners  has  been  sought.  However,  we  extend  our  apologies  to  those  we  might  have  overlooked. All materials should be used strictly for educational purposes.

- Graphic Designer, MIE
- Graphic Designer, MIE

## FOREWORD

The  MIE  produced  a  set  of  new  textbooks  for  Grades  1-9  based  on  the National  Curriculum  Framework  and Teaching  and  Learning  Syllabus  for  the implementation of the Nine Year Continuous Basic Education (NYCBE) reform. These  have  been  key  to  curriculum  transaction  in  the  classroom.  However, curriculum  development  is  a  dynamic  enterprise  that  constitutes  constant review and readjustment in relation to the evolving contextual factors and needs of Educators and learners. As such the Grade 9 Science textbook was reviewed taking  into  consideration  the  insights  and  views  of  stakeholders  as  well  the emerging trends in Science Education. Even though dedicated textbooks are now available for each of the Science subjects, namely Biology, Chemistry and Physics, for ease of use, the guiding philosophy has remained unchanged. The content  is  contextualized,  incremental  and  founded  on  basic  scientific  skills developed in Grades 7 and 8.

As in all curriculum endeavours, a number of contributors have been involved in  the  review of the Grade 9 textbook. I remain appreciative of the efforts of the panel who, at the inception, gave the textbook its orientation. I thank the review team for finetuning the resource in the light of feedback obtained to enhance teaching and learning experiences. The Educators who were part of the validation  process  have  also  played  an  important  role  in  ensuring  that  the reviewed  Science  textbooks  are  sound.  Last,  but  not  the  least,  the  Graphic Designers are to be thanked  for their continuous  collaboration in the development of apt educational resources.

I wish all users of the Science textbooks an enriching and enjoyable experience.

Dr Hemant Bessoondyal Director Mauritius Institute of Education

## PREFACE

The Grade 9 physics textbook is in compliance with the National Curriculum Framework (NCF, 2017) and the Teaching and Learning Syllabus (TLS, 2017) for science. The textbook ensures a smooth transition from the earlier grades by building upon content learnt up to Grade 8.

The  textbook  is  conceptualised  in  such  a  way  that  it  includes  a  number  of inquiry-based activities and accompanying tasks for learners. In line with the constructivist approach, the activities will enable learners to build and reinforce understanding of science concepts. As such, a conscious effort must be made to  actively  engage  pupils  in  all  activities  and  to  allow  them  to  manipulate specimens,  materials,  simple  equipment  and  apparatus  safely  and  under supervision.

The use of everyday experiences and contexts that students can easily relate to  is  favoured.  Care  is  taken  to  incorporate  learner-centred  strategies  like project-based learning and concept mapping to actively engage the learners in the learning process and to provide for independent learning. Furthermore, whenever  relevant,  applications  of  the  physical  concepts  learnt  in  real  life situations are highlighted.

Additionally,  the  activities  seek  to  develop  in  students  the  necessary  skills, attitudes and values for scientific inquiry. Students must be given ample time to actively engage in the activities, communicate their findings and observations in  multiple  ways,  discuss  with  their  friends  and  teachers  and  think  before writing down their answers. Though many questions are incorporated within the  activities,  educators  are  encouraged  to  prompt  learners  with  additional questions while implementing them in the classroom.

The textbook includes important features that support effective assessment. ' Test  yourself '  is  for  formative  purposes  and  are  meant  to  reinforce  and consolidate understanding of the concepts learnt and the inquiry skills that students have developed. At the end of each unit, the questions are scaffolded so that students can apply their knowledge and understanding to solve simple as well as challenging questions.

More  importantly,  for  Grade  9,  the  textbook  seeks  to  provide  relevant  and authentic  assessment  materials  for  the  purpose  of  the  National  Certificate of  Education  (NCE)  assessment  at  the  end  of  the  NYBCE  cycle.  The ' End  of Unit  Exercises '  provides  educators  with  opportunities  to  assess  learners' understanding  of  concepts  addressed  in  the  units  and  to  provide  timely feedback  and  support.  This  section  comprises  a  variety  of  exercises,  such as  fill-in-the-blanks,  matching,  multiple  choice  and  structured  questions, amongst others.  It is recommended to encourage learners to develop higher order thinking skills and to justify their answers as and when appropriate as this promotes critical analysis and deeper conceptual understanding. Using a differentiated approach, educators are expected to develop more assessment exercises or to adapt those provided to assess learners of different abilities.

The ' What  I  have  learnt '  icon  summarises  the  concepts  learnt  through  the inquiry-based activities. The 'Find out' icon aims at encouraging students to look  for  information  beyond  the  scope  of  the  textbook  and  to  develop  the habit and skills of looking for information from various sources. The ' Did you know ?' icon is included to trigger students' interest and curiosity about science. This  section  not  only  provides  them  with  interesting  information  related  to the concepts being addressed but it also helps to stimulate their curiosity and stretch  their  imagination  further.  Suggestions  are  made  for ' Project work '  to promote cooperative learning.

A ' Summary of unit ' and ' Concept map ' are incorporated at the end of each unit to clearly summarise all the key and relevant concepts learnt. With the visual impact that graphic organisers afford, students can make connections among concepts in the hope that learning is aided, consolidated and eventually a high retention rate is ensured.

It  is  sincerely  hoped  that  the  textbook  helps  motivate  learners,  stimulates their interest in science and develops the habits of mind and skills for scientific inquiry.

Dr (Mrs) Sarojiny Saddul-Hauzaree Coordinator The Science Panel

In this image, we can see a diagram.

<!-- image -->

LR; +R

FR

720

Measurement in Science

Unit

Unit

P1

1

Unit

## Measurement in Science

## Learning Outcomes

## At the end of this unit, you should be able to:

- State the SI units of length, mass, volume, time and temperature
- Describe how to measure a variety of lengths with appropriate accuracy using tapes and rulers
- Recognise  the  types  of  errors  associated  with  the  measurement  of  length,  namely, parallax error and zero error
- Describe how to use a measuring cylinder to measure the volume of a liquid
- Discuss the experimental determination of the volume of an irregular solid
- Read balances to record mass in its correct unit
- Describe how to measure a variety of time intervals using stopwatches and a simple pendulum
- Record the temperature from laboratory and clinical thermometers

The foundation of Physics rests upon physical quantities in terms of which the laws of Physics are  expressed.  Therefore,  these  quantities  have  to  be  measured  and  expressed  accurately.

## A physical quantity is one that can be measured and it consists of a magnitude and a unit.

Example:

In this image we can see a ruler. On the right side of the image we can see a small object.

<!-- image -->

Measuring length of a pencil

<!-- image -->

P 1

<!-- image -->

## ACTIVITY 1.1 - Identifying physical quantities

1. Study the pictures below and identify the physical quantities. Record your answers in Table 1.
2.  Study the list below and circle the one which is NOT a physical quantity.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 1

| volume   | time   | newton           | temperature   | area   | kelvin   |
|----------|--------|------------------|---------------|--------|----------|
| density  | speed  | electric current | length        | joule  | metre    |
| kilogram | watt   | stopwatch        | balance       | force  | energy   |

## Measurement of Length

In Grade 8, you learnt about measurement of length. In Grade 9, we will emphasise more on the techniques of measurement  for better accuracy during scientific activities.

Length is the distance between any two points. The SI unit of length is the metre (m).

Other units of length are: millimetre (mm) centimetre (cm) kilometre (km)

<!-- image -->

## Conversion of length

1 km = 1000 m

1 m = 100 cm

1cm  = 10 mm

x 1000

x 100

x 10

<!-- image -->

## ACTIVITY 1.2 - Measuring the length of a rod

In this image, we can see a graph.

<!-- image -->

Write down the values of x 1 and x 2 as shown in the above picture.

x

1

= \_\_\_\_\_\_\_ cm

$$x _ { _ { 2 } } = \cfrac { } { } \cmath m$$

The distance from one end of the rod to the other end of the rod is \_\_\_\_\_\_\_ cm.

Length of rod = \_\_\_\_\_\_\_ cm.

<!-- image -->

## 1. Convert the following:

| 1km   | =   | _________   | m   |
|-------|-----|-------------|-----|
| 1km   | =   | _________   | cm  |
| 1km   | =   | _________   | mm  |
| 1m    | =   | _________   | cm  |
| 1m    | =   | _________   | mm  |
| 1mm   | =   | _________   | cm  |
| 1 cm  | =   | _________   | m   |
| 1mm   | =   | _________   | m   |

## Some words used to describe length are:

<!-- image -->

<!-- image -->

## Circumference, Radius and Diameter

diameter = 2 x radius

In this image we can see a diagram.

<!-- image -->

## 2. Convert the following:

| a)2m=        | ________ cm   |
|--------------|---------------|
| b)25mm=      | ________ cm   |
| c) 4.5km=    | ________m     |
| d) 0.028km=  | ________ cm   |
| e) 52.0 cm = | ________m     |
| f)280mm=     | ________m     |

## Instruments used to measure length are:

- Measuring tape
- Metre rule
- Half metre rule
- Ruler

<!-- image -->

Match the instrument's name in Table 2 to its picture.

Table 2

| Instrumentname   | Picture   |
|------------------|-----------|
| Measuring tape   |           |
| Metre rule       |           |
| Ruler            |           |

<!-- image -->

Unit

Unit

P1

1

## Reading the scale of a ruler

When making a measurement, read the instrument to its smallest scale division.

<!-- image -->

## Determining the smallest division on the ruler:

10 divisions = 1 cm

1 division

$$= \frac { 1 } { 1 0 } \text{cm}$$

= 0.1 cm = 1 mm

Since each smallest division on the ruler corresponds to 0.1 cm, the measurements recorded with a ruler are expressed in cm to 1 decimal place . So the accuracy of the ruler is 0.1 cm (or 1 mm).

## Write down the value shown on each scale at the mark as shown by the arrow.

In this image, we can see a graph.

<!-- image -->

<!-- image -->

## ACTIVITY 1.3B - Measuring the length of various items

In this activity, you will use a metre rule, a half metre rule, a ruler or a measuring tape to measure the lengths of objects given in the table below.

## Procedure:

Use appropriate instruments to measure the lengths listed below and record your results in the table.

Table 3

| Quantity to be measured   | Instrument used   | Length recorded / unit   |
|---------------------------|-------------------|--------------------------|
| Length of physics book    |                   |                          |
| Height of your chair      |                   |                          |
| Length of your classroom  |                   |                          |
| Width of door             |                   |                          |
| Length of an eraser       |                   |                          |

## ACTIVITY 1.4A - Measuring the diameter of a coin

<!-- image -->

## Materials required:

- 2 set-squares (wooden blocks)
- a coin
- a ruler

In this image, we can see a diagram. There are numbers and symbols on the diagram.

<!-- image -->

## Procedure:

1. Place the ruler along the edge of the table.  Along the edge of the scale, place the set-square P and then the coin. Place set-square Q on the other side of the coin so that it touches the coin.
2. Then, looking vertically downwards, note the readings from the scale from the two sides of the coin.
3. Diameter of coin = X 2 - X 1 cm.

Unit

P1

## ACTIVITY 1.4B - Measuring the diameter of a coin using ten identical coins

<!-- image -->

## Materials required:

- 2 set-squares (wooden blocks),
- 10 identical coins,
- a ruler.

In this image we can see a ruler and a paper. On the paper we can see some numbers and some text.

<!-- image -->

## Procedure:

1. Place the half metre rule along the edge of the table.  Along the edge of the scale, place the set-square P and then the ten coins, such that there is no gap between the coins.  Place setsquare Q on the other side of the coins, such that it touches the coin.
2. Then looking straight and vertically downwards, note the readings from the scale from the sides of the coin at x 1 and x 2 .
3. Diameter of ten coins = X 2 - X 1
4. Diameter of one coin = X 2 - X 1 10

Suggest which of the two methods, A or B, gives a more accurate value for the diameter.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Conclusion:

Averaging reduces error in measurement. Hence, method B is more accurate than method A.

<!-- image -->

## 1. Name the instrument used to measure the:

- a. Length of your school bag: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b. Circumference of a football: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- c. Length of the teacher demonstration table: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- d. Thickness of 500 sheets of paper: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. Describe how you would determine the thickness of a sheet of paper, given that you have 100 sheets of paper available.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Accuracy in measurement

- Accuracy is important in all scientific activities. Accuracy describes how close a measurement is to its true value.

- Errors such as parallax error and zero error make the measurement greater or smaller than the true value.

- Therefore, avoiding these errors will make a measurement more accurate.

Unit

P1

## Parallax Error

In Grade 8, you have learnt that parallax error occurs when the eye is not correctly positioned. Parallax error causes the measured quantity to be greater or smaller than the true value .

## How to avoid parallax error

Parallax error is avoided by placing the eyes directly opposite and perpendicular to the mark being read. The correct position of an observer's eye while reading scales are shown below.

In this image, we can see a diagram. There are two persons in the image.

<!-- image -->

In this image, we can see a ruler. On the right side, we can see a person's hand.

<!-- image -->

<!-- image -->

A student has 50 small identical glass beads in a jar.

<!-- image -->

In this image there is a table. On the table there is a paper. On the paper there is a text.

<!-- image -->

The student is provided with a 30 cm ruler and two rectangular wooden blocks.

- a. Draw a diagram to show clearly how the student could arrange the apparatus to accurately measure the diameter of one of the beads.

## Investigating zero error in the measurement of length

## A. Using a ruler whose extremity does not coincide with the zero mark.

Study diagram 1A and write down the length of the block as shown.

Diagram 1A

Length of block = \_\_\_\_\_\_\_ cm

Unit

P1

Now, the same block is repositioned as shown in diagram 2A.  Write down the length of the block.

<!-- image -->

Diagram 2A

Length of block = \_\_\_\_\_\_\_ cm

Why are different values obtained for the same block?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Which value, between diagrams 1A and 2A, is correct?  Explain your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Zero error occurs when measurement is taken from the extremity of a ruler which does not coincide with the zero mark.  Therefore, to avoid zero error, the block should be placed on the zero mark.

## B. Using a ruler whose end is damaged.

Study diagram 1B and write down the length of the pencil as shown.

Diagram 1B

<!-- image -->

Length of pencil = \_\_\_\_\_\_\_ cm

Now, the same pencil is repositioned as shown in diagram 2B.  Write down the length of the pencil.

In this image, we can see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpener. We can also see a pencil and a pencil sharpen

<!-- image -->

## Why are different values obtained for the same pencil?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Which value, between diagrams 1B and 2B, is correct?  Explain your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

To avoid zero error, the pencil is placed on a clearly visible division and the end readings are taken.  The correct length of the pencil is obtained from the difference in the two readings.

## Measurement of Volume

Volume is the amount of space occupied by an object. The SI unit of volume is the cubic metre (m 3 ).

Other units of volume are:

- cubic centimetre (cm 3 )
- millilitres (ml)
- centilitre (cl)
- litre ( l )

## Volume of liquids

The volume of a liquid can be determined using a measuring cylinder. The liquid is gently poured into the measuring cylinder and the volume of liquid in the  measuring  cylinder  is  read  and  recorded.  The curved  surface  formed  by  a  liquid  is  known  as  a meniscus .

1 cm 3 = 1 ml

The image shows a bar chart titled "Reading the Meniscus at Eye Level." The chart is titled "Reading the Meniscus at Eye Level" and is designed to measure the meniscus, a cushion-like structure that cushions the knee. The meniscus is located at the top of the image and is shown to be slightly curved, indicating that it is a cushion-like structure.

The x-axis represents the height of the meniscus, ranging from 0 to 100 ml. The y-axis represents the amount of liquid in ml, ranging from 0 to 80 ml. The chart is labeled with the title "Reading the Meniscus at Eye Level" and has a legend on the right side of the chart that explains the meaning of the numbers on the y-axis.

The chart includes two sections: the upper section and the lower section. The upper section is labeled "Reading the Meniscus at Eye Level" and contains a bar chart

<!-- image -->

## Precautions to be taken:

When reading the measuring cylinder,

<!-- image -->

<!-- image -->

1. The eyes must be placed level with the meniscus of the liquid and perpendicular to the scale.
2. The measuring cylinder is placed on a flat horizontal surface.
3. The scale should face the observer.

<!-- image -->

## Reading the scales of a measuring cylinder

Consider the 3 different measuring cylinders below. Draw the line of sight for each measuring cylinder shown below and record the volume of each liquid.

Measuring cylinders

In this image we can see a flask and a liquid in it.

<!-- image -->

## Volume of regular-shaped solids

In this image, we can see a few cubes. There are some objects in the image.

<!-- image -->

sphere

The volumes of the above objects are obtained by taking measurements such as length, height, width, diameter and then calculating the volume using their respective formula.

## Volume of irregular-shaped solids

Volumes of irregular solids cannot be obtained by using formulas. They are determined by other methods such as the displacement method.

When an object is immersed in water, it displaces a volume of water that is equal to its own volume. This method is known as the displacement method.

<!-- image -->

## ACTIVITY 1.5 - Determining the volume of a small irregular object

In this experiment, you will use the displacement method to find the volume of a small stone using a measuring cylinder.

## Materials required:

- a measuring cylinder
- a small irregular object (key)
- a beaker of coloured water
- thin non-absorbent thread

Unit

P1

## Procedure:

1. The measuring cylinder is half filled with water and the volume of water in the measuring cylinder is recorded as V 1 .

V

1

= \_\_\_\_\_\_\_\_\_ cm 3

2. The key is tied with the piece of thread and gently immersed into the measuring cylinder. The new volume is recorded as V 2 .

V

2

= \_\_\_\_\_\_\_\_\_ cm 3

3. The volume of the key is calculated using:

Volume of key = (V 2 - V 1 ) cm 3

3

= \_\_\_\_\_\_\_\_\_\_\_\_\_\_ cm

## Precautions to be taken:

1. The measuring cylinder is placed on a flat horizontal surface when reading the volumes.
2. The line of sight must be perpendicular to the scale, and level with the meniscus of water.
3. The key is gently immersed to avoid the splashing of water.

## Further investigation

The key is submerged so that it is at the base, and the level of water in the measuring cylinder is observed. The key is raised slowly so that it is still completely submerged just below the water, and the level of water in the measuring cylinder is recorded. What do you observe?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

## Volume of a large irregular object

The volume of a large irregular solid can be determined using the displacement can.

<!-- image -->

## ACTIVITY 1.6 - Determining the volume of a large irregular object using a displacement can

## Materials required:

- a large irregular stone
- thin non-absorbent thread
- a displacement can
- a beaker of water
- an empty beaker
- an empty measuring cylinder
- a wooden block

The displacement method

In this image we can see a diagram of a stone block.

<!-- image -->

## Procedure:

1. The displacement can is placed on a wooden block on the table with the empty beaker at its spout.
2. The displacement can is completely filled with water until the excess water overflows into the beaker.
3. The beaker is replaced with the empty measuring cylinder and the stone, tied to the piece of thread, is gently immersed into the displacement can. The stone should be completely immersed in the water.
4. The  volume  of  water  collected  in  the  measuring  cylinder  is recorded.

The displacement method

<!-- image -->

## Volume of water displaced into the measuring cylinder = Volume of the stone

Why is it important to ensure that the water is levelled with the spout before immersing the stone?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

## Web link:

A TEDEd video which tells the story about Archimedes' discovery of the way to measure volume of an irregular solid.

https://www.youtube.com/watch?time\_continue=89&amp;v=ijj58xD5fDI

<!-- image -->

## Materials required:

- a beaker of water
- a small measuring cylinder
- a dropper

<!-- image -->

## Procedure:

1. Add 100 drops of water carefully to the empty measuring cylinder, without splashing.
2. Read the volume of the 100 drops.

Volume of 100 drops of water = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Determine the volume of one drop of water.
2. Volume of 1 drop of water = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Why should you avoid splashing while adding water?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Why was the volume of one drop of water not measured directly?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

- A group of students is determining the volume of a sample of cards. Each student has a stack of ten cards. The diagram is drawn to scale.
- (i) In the figure shown, measure the height (h) of the stack of cards.

h = \_\_\_\_\_\_\_\_\_\_\_\_ cm

- (ii) Calculate the average thickness (t) of one piece of card.

t = \_\_\_\_\_\_\_\_\_\_\_\_ cm

- (iii) Why was a stack of ten cards used to calculate the thickness of one card instead of measuring the thickness of one card directly?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b (i) Measure the length (l) and width (w) of the top piece of card.

l = \_\_\_\_\_\_\_\_\_\_\_\_ cm w = \_\_\_\_\_\_\_\_\_\_\_\_ cm

- (ii) Calculate the volume (V) of one card .

V = \_\_\_\_\_\_\_\_\_\_\_\_ cm 3

## Measurement of Mass

Mass is a measure of the amount of matter. The SI unit of mass is the kilogram (kg) .

Other units of mass are: milligram (mg), gram (g), tonne (t).

## Conversion of mass

1 t = 1000 kg

1 kg = 1000 g

The instruments used to measure mass are:

In this image we can see a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale, a scale

<!-- image -->

Unit

P1

<!-- image -->

## ACTIVITY 1.8 - Measuring the mass of various objects

## Materials required:

- an electronic balance
- a paper clip
- a pencil
- a protractor
- a 30cm plastic ruler
- a small fruit

An electronic balance

<!-- image -->

## Procedure:

1. The electronic balance is placed on a flat, horizontal surface and then switched on. Wait for the balance to show zeroes on the digital screen.
2. Place the objects listed in Table 4 on the balance.
3. Read and record its mass in Table 4.

| Table 4         | Table 4     |
|-----------------|-------------|
| Object          | Mass / Unit |
| A paper clip    |             |
| A pencil        |             |
| A protractor    |             |
| A plastic ruler |             |
| A coin          |             |
| A small fruit   |             |

<!-- image -->

## FIND OUT

1. How is the mass of water, kept in a measuring cylinder, determined?
2. Why is the mass of an object on Earth the same as its mass on Moon?

## Measurement of Time

Time is the interval between two events. The SI unit of time is the second(s).

Other units of time are:

- minute,
- hour,
- day,
- week,
- month,
- year,
- decade,
- century.

The instruments used to measure time are:

In this image we can see a hand holding a watch. There is a digital watch on the right side.

<!-- image -->

## Reading an analogue stopwatch

The analogue stopwatch can have a second or minute scale or both as shown below.

In this image, we can see a scale.

<!-- image -->

| Conversion of time    |
|-----------------------|
| 1 day = 24 hours      |
| 1 hour = 60 minutes   |
| 1 minute = 60 seconds |
| 1 hour = 3600 seconds |

Unit

P1

<!-- image -->

1. Write down the readings of the following digital stopwatches.
2. The first one has been done for you.

<!-- image -->

Reading =  37.22 s

Reading = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Reading = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## A simple pendulum

The simple pendulum consists of a small mass (called the pendulum bob) attached to a string, which is suspended from a rigid support as shown.

Displace the bob slightly and observe what happens.

One oscillation is the complete to-and-fro motion of the bob.

The time period is  the  time  taken  by  the  bob  to  make  one  complete oscillation.

<!-- image -->

Shorten the length of the pendulum bob. Let it oscillate. What do you observe?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Conclusion: The time period of a simple pendulum depends on the length of the pendulum. As the length of the pendulum increases, the time period increases.

<!-- image -->

## Materials required:

- a pendulum bob
- two wooden blocks
- 90 cm of cotton thread
- a stopwatch
- a retort stand, a boss and a clamp

## Procedure:

One complete oscillation

<!-- image -->

1. The pendulum bob, attached to a thread, is held in the clamp using two wooden blocks.
2. The bob is made to swing by moving it to one side and then released.  The time for the period of 20 oscillations is measured using a stopwatch.

Time, t = \_\_\_\_\_\_\_\_\_\_\_\_s

1

3. The time taken for 20 oscillations is measured again and the results are recorded.

Time, t 2

= \_\_\_\_\_\_\_\_\_\_\_\_s

4. The average time &lt;t&gt; for 20 oscillations is calculated.

&lt;t&gt; = \_\_\_\_\_\_\_\_\_\_\_\_s

5. The time period, T of the pendulum is calculated using:

T = \_\_\_\_\_\_\_\_\_\_\_\_s

6. Why is it better to measure the time for 20 oscillations when calculating the time period?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

&lt;t&gt;

20

## Conclusion:

More accurate value of time period is obtained when it is calculated using larger number of oscillations. Thus, human reaction time is reduced.

<!-- image -->

Watch this video from YouTube to understand more about human reaction time. Web link: https://www.youtube.com/watch?v=Ez4-Dt9AQQg&amp;t=15s

Unit

P1

## Using the simple pendulum to measure a time interval

A simple pendulum of known period, such as 2s, is taken. It is set into oscillation.

A person is asked to walk from a point A to another point B which is 10 m away. The number of oscillations during this event is noted. If we assume it takes 20 oscillations to cover this distance.

One oscillation of the bob takes 2s. Hence, 20 oscillations take 20 x 2s = 40s.

Thus, the person takes 40s to walk through a distance of 10 m.

## Measurement of temperature

Temperature  is  a  measure  of  the  degree  of  hotness  or  coldness  of  a  body.  The  SI  unit  of temperature is the kelvin, K.

Other units of temperature are: degree Celsius ( o C) degree Fahrenheit ( o F)

A thermometer is the instrument used to measure temperature. The table below shows the different types of thermometers used.

## Laboratory thermometer

<!-- image -->

1. A laboratory thermometer is used to measure temperature in a science laboratory.
2. It reads temperature from -10°C to 110°C.
3. Alcohol and Mercury are two thermometric liquids used in laboratory thermometers. Mercury is silvery grey in colour.
4. Alcohol is transparent and therefore, it has to be dyed to be visible.
4. The capillary bore is narrow so that the thermometric liquid can move a longer distance along the capillary tube for a small change in temperature.
5. The bulb is made up of thin glass to allow heat to reach the thermometric liquid quickly.

## Clinical thermometer

<!-- image -->

1. A clinical thermometer is used to measure human body temperature.
2. It has a shorter scale around 35°C to 42°C because this is the range within which human body temperature can vary.
3. There is  a  special  marking  at  37°C  which  is  the  approximate  temperature  of  a  healthy person.
4. The bulb of the thermometer is generally placed under the armpit or in the mouth of the patient.
5. The bulb is made up of thin glass to reach the mercury quickly.
6. The constriction in the thermometer prevents the backflow of the mercury into the bulb when the thermometer is taken out from the patient's mouth or any part of the body.
7. The stem is triangular in shape so that the mercury is seen clearly.

## Digital clinical thermometer

<!-- image -->

1. It is used to measure human body temperature
2. It is easier to read as it has a digital display. Hence, there is no possibility of parallax error.
3. It does not use mercury, which is a poisonous liquid.
4. It needs batteries in order to work.

<!-- image -->

Nowadays, infra-red thermometers are being used increasingly. This is because they are fast, easy-to-read and can measure temperature at a safe distance.

<!-- image -->

Unit

P1

## Reading a liquid-in-glass thermometer

Part of a thermometer scale in degrees Celsius is shown below.

In this image, we can see a scale. On the right side, we can see a graph.

<!-- image -->

<!-- image -->

1. The figure below shows the upper part of the thermometer.

<!-- image -->

## Draw

- (i) a vertical line to show the position of the mercury thread when the temperature is 650C on the figure above.
- (ii)   a second vertical line to show an increase of temperature by around 10.50C.
2.    The diagram below shows a clinical thermometer.
- a. Label the parts A, B, C, D and E of the thermometer.
- b. State the range of the clinical thermometer. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- c. What is the function of feature B on the clinical thermometer?

In this image, we can see a graph.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. A student measures room temperature using the instrument shown below.
2. (a)  State the range of the thermometer. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
3. (b)  Record the room temperature shown on the thermometer. \_\_\_\_\_\_\_\_\_\_\_\_\_
4. (c) State one error that must be avoided while taking the measurement.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d)  Why is the capillary tube of the thermometer thin?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Summary of unit

- A physical quantity is one that can be measured and has a magnitude and a unit.
- Length is the distance between two points. The SI unit of length is the metre (m). Other units of length are the millimetre (mm), centimetre (cm) and kilometre (km).
- The metre rule and the measuring tape are used to measure the length of an object.
- Parallax error occurs when the observer places his eyes at an angle to the mark being read.  Parallax error can be avoided by placing the eyes perpendicular and in line with the mark being read on the scale.
- Zero error in a rule occurs when the object is not placed on a clearly visible division or is placed on the damaged end of a rule.
- Zero error is avoided by placing the object between two clearly visible marks and the end readings are noted. The measured quantity is calculated using the difference between the two end readings.
- Volume is the amount of space occupied by an object. The SI unit of volume is the cubic metre (m 3 ).
- The volume of an irregular solid is found by the displacement method.
- Mass is a measure of the amount of matter. The SI unit of mass is the kilogram (kg). A balance is used to measure the mass of an object.
- The  digital  and  the  analogue  stopwatches  are  commonly  used  to  measure  time intervals in a laboratory. The SI unit of time is the second (s).
- Temperature is a measure of the degree of hotness or coldness of a body. The SI unit of temperature is the kelvin (K).
- A thermometer is used to measure temperature.

In this image, we can see a chart with some data.

<!-- image -->

<!-- image -->

## Multiple choice questions

1. The diagram shows four identical spheres placed between two wooden blocks.

<!-- image -->

What is the diameter of one sphere?

- A 1.0 cm

- B 2.0 cm

- C 3.0 cm

- D 4.0 cm

2. Which of the following are physical quantities?
3. The diagram shows a measuring instrument.

| A   | temperature   | length   | electric current   | mass         |
|-----|---------------|----------|--------------------|--------------|
| B   | mass          | time     | speed              | metre        |
| C   | area          | joule    | force              | acceleration |
| D   | volume        | power    | thermometer        | mass         |

<!-- image -->

Which physical quantity does this instrument measure?

- A Area
- B Density
- C Mass
- D Volume

Unit

P1

4. A measuring cylinder contains 20 cm 3  of water. A stone is placed in the water and the water level rises to 38 cm 3 . What is the volume of the stone?
5. Which instrument is used to measure mass?
3. A Balance
4. B Metre rule
5. C Measuring cylinder
6. D Stopwatch
6. A block of metal is placed on an electronic balance to record its mass. What is the unit of the reading on the electronic balance?
7. A pendulum is set in motion and 20 complete swings are timed. The time measured is 10 s. What is the time for one complete swing of the pendulum?
9. A 2 s
10. B 0.75 s
11. C 0.5 s
12. D 3 s
8. The smallest reading that can be recorded by a metre rule is
14. A 1 mm
15. B 1 cm
16. C 1 m
17. D 0.01 cm

In this image, we can see a diagram with two objects. The diagram is in black and white.

<!-- image -->

In this image, we can see a table. On the table, we can see a number.

<!-- image -->

9. One  condition  required  to  measure  the  volume  of  an  object  using  the  displacement method is
2. A the object should sink to the bottom of the container.
3. B the object should float in the liquid.
4. C the object should absorb the liquid
5. D the object should be completely (fully) immersed in the liquid.
10. One oscillation of a swinging pendulum occurs when the bob moves from X to Y and back to X again.

<!-- image -->

Using a stopwatch, which would be the most accurate way to measure the time for one oscillation of the pendulum?

- A Time 20 oscillations and multiply by 20.
- B Time 20 oscillations and divide by 20.
- C Time one oscillation.
- D Time the motion from X to Y, and double it.
11. Which of the following is used to measure the temperature of a sick patient?
- A alcohol-in-glass laboratory thermometer
- B clinical thermometer
- C mercury-in-glass laboratory thermometer
- D pendulum clock

## 12. The diagram shows an electronic balance.  The balance is said to have

<!-- image -->

- A a parallax error

- B an end error

- C no error

- D a zero error

## STRUCTURED QUESTIONS

1. Fill in the blanks with the correct words from the list given below:
2. The statements given below are incorrect. Write the correct statements.
1. One kilometre is equal to 100 metres.

|    | mass measuring cylinder second length                           |
|----|-----------------------------------------------------------------|
|  1 | ______________ is a measure of the distance between two points. |
|  2 | ______________ is the amount of matter in a given body.         |
|  3 | A ______________ is used to measure the volume of a liquid.     |
|  4 | The SI unit of time is the ______________                       |

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. The degree of hotness or coldness is called heat energy.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. A clinical thermometer can measure the temperature of boiling water.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. Zero error is avoided by placing the eye directly opposite and perpendicular to the mark being read.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Here is a list of instruments.

<!-- image -->

ruler          stopwatch        measuring tape     electronic balance

Choose  the  correct  instrument  for  the  measurement  of the following quantities:

Time to boil rice:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The mass of a pen:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Length of your trousers:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. The figure below shows a measuring cylinder containing a small irregular object.  A student pours 60 cm 3  of water into the measuring cylinder. She, then, gently lowers the object into the water. Using the information in the figure, calculate the volume of the irregular object.
5. A displacement can is a container with a spout and used to determine the volume  of an irregular object. The figures below show a displacement can and its cross-section. The can is filled with water to the level of its spout.
- a.   (i) Explain how the displacement can is used to measure the volume of an irregular object such as a sea shell. State any additional apparatus that is required.

In this image, we can see a diagram. There is a diagram of a cylinder. There is a text on the image.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) State one possible difficulty in using a can that has:
1. a very small diameter.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. a spout that is attached near the middle of the can.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii) Write down two precautions that can be taken to make the measurement more accurate.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

6. A beaker contains water at 38.5 °C. A student is looking at a thermometer from the position marked by the eye in the diagram below.
- a. Explain  why  the  temperature  appears  to  be different from  38.5  °C  when  seen  by  the student.
3. You may draw on the diagram.

In this image, we can see a diagram.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- b. To describe the correct use of a thermometer, a student wrote: 'The line of sight must be vertical to the thermometer' . This is wrongly described. Write the correct description.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- c. Draw the correct position of the eye on the diagram.

7. The diagram below shows a rectangular box.
- a)  Calculate the area of the shaded region.

Area of shaded region = \_\_\_\_\_\_\_\_\_\_

<!-- image -->

- b)  Define 'volume' of an object.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- c)   Is the box a regular or irregular object?  Explain your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- d)  Hence, calculate the volume of the box.

Volume of box = \_\_\_\_\_\_\_\_\_\_

- e)  Hence, how many cubes of length 3 cm will be needed to fill completely the box?

Number of cubes needed = \_\_\_\_\_\_\_\_\_\_

8. A student wants to find the circumference of a cylindrical can.  He rolls the cylindrical can three times along a ruler as shown below.
- a)  Record the reading at the starting position and at the final position.

In this image, we can see a chart. There are two circles and there is a text.

<!-- image -->

Starting position = \_\_\_\_\_\_\_\_ cm

Final position = \_\_\_\_\_\_\_\_ cm

- b)  Calculate the circumference of the can.

Circumference of can = \_\_\_\_\_\_\_\_\_\_ cm

- c)   Name another measuring instrument that can be used to measure the circumference of the can.  Support your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In this image, we can see a picture of a car. At the bottom, we can see some text.

<!-- image -->

## At the end of this unit, you should be able to:

- Investigate the importance of light for vision
- Differentiate between luminous and non-luminous objects by giving examples
- Recognise that stars produce their own light
- Recognise that planets and moons reflect light received from the sun
- Describe a simple experiment to show that light travels in straight lines
- Describe the reflection of light
- State the laws of reflection
- Use ray diagrams to demonstrate reflection

We certainly see with our eyes but, as you may have noticed, even with our eyes wide open, vision is not possible when there is no light! In fact, light is a vital form of energy that has an important role to play in all aspects of our lives.. In the absence of light, plants would not be able to manufacture their food as sunlight is required for the process of photosynthesis to occur.

Light  comes from a number of different sources that may be natural or artificial. Our main natural light source is the Sun.

Apart from the Sun, other sources of natural light include stars, flame from a combustion process and artificial light sources such as electric light-bulbs and torches operated with batteries.

37

Unit

P2

## Importance of Light

Light is required for vision. Light allows us to see.

<!-- image -->

## ACTIVITY 2.1 - Investigating the importance of light for vision

## Materials required:

- a small box (for example a shoe box)
- a pair of scissors or a cutter
- a small object

## Procedure:

1. Make a central hole in the top face (lid) of the box and another central hole in one face of the box as shown below.
2. Remove the lid and place the small object inside the box at its centre.
3. Cover the box with the lid.
4. Cover  the  hole  on  the  lid  of  the  box  with  one hand as shown and observe the object from the hole on the side of the box.

In this image, we can see a box with a cut-out of a hole.

<!-- image -->

<!-- image -->

<!-- image -->

What do you observe? Can you see the object inside the box?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Now, remove your hand from the lid and again look at the object through the side hole of the box.

<!-- image -->

Can you see the object inside the box?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

From Activity 2.1, we have learnt that nothing can be seen without light. In fact, light is essential for vision. The visual ability of humans and other animals is the result of the interaction of light, eyes and the brain. We are able to see because light from an object can move through space and reach our eyes. Once light reaches our eyes, signals are sent to our brain. Our brain translates these information in order to interpret the appearance, location and movement of the objects we are looking at.

The whole process would not be possible without light coming from different sources.

<!-- image -->

If you are in a room at night and you close all the windows, doors and draw the curtains shut, do you see any objects? Do you see yourself in the mirror? Why? Discuss.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

Light arrives on Earth from the Sun after a trip that covers  a  distance  of  about  149  million  kilometres travelling at the fastest speed known to us!

<!-- image -->

Given that light travels at 300 thousand kilometres per second and that the distance between the Sun and the Earth is 149 000 000 km, calculate the time taken for light to travel from the Sun to the Earth.

## Luminous and Non-Luminous Objects

We can see objects around us because of the presence of light. Only some of these objects have the ability to emit light while most objects do not emit light. They just reflect light.

<!-- image -->

## ACTIVITY 2.2 - Identifying luminous and non-luminous bodies

In the table below, there are objects which emit light and objects which do not emit light. Put a tick (     ) in the appropriate column according to whether the object emits light or not.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 1

| Object                | Emits light   | Does not emit light   |
|-----------------------|---------------|-----------------------|
| 1. Lighted matchstick |               |                       |
| 2. Mirror             |               |                       |
| 3. Sun                |               |                       |
| 4. Tree               |               |                       |
| 5. Star               |               |                       |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| 6. Cloud                       |
|--------------------------------|
| 7. Traffic light (switched on) |
| 8. Moon                        |
| 9. Lighted torch               |
| 10. Lighted candle             |
| 11. Glow-worm                  |
| 12. Crystal Jelly              |

<!-- image -->

Light is a form of energy that is emitted by certain living and non-living things.

Luminous objects are objects that emit light.

Examples: Sun, star, traffic lights (on), lighted torch and lighted candle

## Non-luminous objects are objects that do not emit light.

Examples: matchstick, mirror, tree, cloud and moon

Sources of light can also be natural or man-made .

<!-- image -->

In Table 2, put a tick in the appropriate column according to whether you consider each object as luminous or non-luminous and a natural source or artificial source of light. Support your answer with a short justification.

<!-- image -->

<!-- image -->

<!-- image -->

Table 2

| Object                | Luminous   | Non- luminous   | Natural   | Artificial   | Justification   |
|-----------------------|------------|-----------------|-----------|--------------|-----------------|
| 1. Candle             |            |                 |           |              |                 |
| 2. Lighted matchstick |            |                 |           |              |                 |
| 3. Planets            |            |                 |           |              |                 |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| 4. Angler fish              |
|-----------------------------|
| 5. Diamond                  |
| 6. Stainless steel          |
| 7. Screen of a mobile phone |
| 8. Chair                    |
| 9. Firefly                  |
| 10. Lava                    |

<!-- image -->

## Light Travels in Straight Lines

Once light has been emitted from a source, it will keep travelling away from the source until it hits something along its path.

When you wear a hat on a sunny day, you actually apply this idea. The brim of the hat blocks the sunlight from hitting your eyes. Similarly, we are able to avoid the heat of the Sun by standing in the shade of a tree as the sunlight is blocked by the leaves of the tree.

Brim of a hat blocking sunlight

<!-- image -->

<!-- image -->

Trees blocking light rays from the sun

<!-- image -->

## Materials required:

- 2 filament lamps
- 2 retort stands with clamps
- a black bristol paper
- sticky tape

## Procedure:

1. Roll the chart paper to make a paper cylinder that is about 40 cm long and of diameter about 5 cm. Stick the paper tube with the sticky tape.
2. Suspend the filament lamp from the clamp of one retort stand.
3. Clamp the paper tube horizontally in the second retort stand and on the same level as the filament lamp, with one end of the tube pointing directly towards the lamp as shown on the figures on the following page.

In this image we can see a wooden wall and a wooden floor. On the wooden floor there is a wooden object. On the wooden object there is a light. On the light there is a bulb.

<!-- image -->

<!-- image -->

<!-- image -->

4. Check that the lamp is visible when looking at it through the opposite end of the tube.
5. Switch on the lamp and observe through the tube.
6. Can you see the light from the lamp? \_\_\_\_\_\_\_\_\_\_\_
7. Do you think that the appearance would be the same if the tube was bent? \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
8. Switch off the lamp. Now bend the end of the tube near the lamp at an angle of about 90 0 .

9. Keeping the tube bent, switch on the lamp and look through the tube.

10. Can you see the light of the lamp? \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

11. What do you conclude from this experiment?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Reflection of light

A few general properties of light are given below:

1. Light is a form of energy.
2. Light travels in straight lines.
3. A ray of light is the path along which light travels. It is represented using a straight line with an arrow to show the direction of travel.
4. A group of light rays travelling together is called a beam of light. There are three types of light beams: parallel, converging and diverging.

A ray of light

In this image there is a black color line.

<!-- image -->

In this image, we can see a table with some text and numbers.

<!-- image -->

## Parallel beam

## Converging beam

## Diverging beam

Rays of light travelling parallel to each other

Rays of light travelling towards a common point

<!-- image -->

Rays of light starting from a point and travelling in

various directions

The process by which light rays falling on the surface of an object bounce back is called the reflection of light. Thus, when light falls on the surface of an object, the latter reflects back the light. Reflection is what allows us to see non-luminous objects. Light, from a source such as the Sun, strikes the objects and is reflected back to our eyes.

A ray of light reflected by the object

In this image, we can see a tree and the sun.

<!-- image -->

## Ray Diagrams

A ray diagram can be drawn to show the path that light takes when it travels in a given situation.

The ray diagram below illustrates the reflection of light on a plane mirror.

<!-- image -->

## DID YOU KNOW…

Light travels at an exact speed of 299,792,458 m/s (that is nearly 300,000 km/s!) .  The distance around the Earth is 40,000 km, so in 1 second, an object travelling at the speed of light could go around the world seven and a half times!

Sound only travels at about 330 m/s through the air; so light is nearly a million times faster than sound.

Unit

P2

In this image, we can see a diagram. There is a diagram with a line and a point. There is a text at the top of the image.

<!-- image -->

## Terms used in the study of reflection of light

1. Normal

- imaginary line perpendicular to the reflecting surface

2. Incident ray

- ray of light falling onto the reflecting surface

3. Reflected ray

- ray of light bouncing off the reflecting surface

4. Point of incidence

- point where the normal, incident ray and reflected ray meet

5. Angle i

- angle of incidence (measured from the normal to the incident ray)

6. Angle r

- angle of reflection (measured from the normal to the reflected ray)

<!-- image -->

## ACTIVITY 2.4 - Investigating the reflection of light

CAUTION: A dark room is required for the observations of this experiment to be easily visible.

## Materials needed:

- a transparent container of cuboid shape (e.g. a small aquarium)
- a small mirror
- a ray box
- protractor
- markers
- a pinch of powdered milk

## Procedure:

1.   On one flat face of the transparent container, draw lines to represent the incident and reflected rays of light at angles of  70 o and  50 o measured  between  the  ray  of  light  and the normal as shown below. A blank sheet of paper can be  placed  behind  the  container  for  improved  visibility.

In this image we can see a poster with some text and a red color line.

<!-- image -->

2.   Place  the  mirror  flat  at  the  bottom  of  the  container  with  the  reflecting  surface  facing upwards.
3.   Place the container on a flat surface (the laboratory bench is suitable) and fill it with water.
4.   Add the pinch of powdered milk to the water and stir gently to give the water a cloudy appearance. The cloudy water will make the path of the light visible.
5.   Now, the ray box is switched on and the beam is aligned with the line drawn at the angle of 50 o .
6. What do you observe about the angles of incidence and reflection? \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
7. Repeat step (5) above for the angle of incidence of 70 o .

In this image we can see a pink color object. There are some objects on the left side of the image.

<!-- image -->

In this image we can see a poster.

<!-- image -->

8. What do you conclude about the angles of incidence and reflection?

9. What do you conclude from this experiment?

## Therefore, the two laws of reflection are:

1. The angle of incidence equals to the angle of reflection.
2. The incident ray, the reflected ray and the normal at the point of incidence all lie in the same plane.

Unit

P2

<!-- image -->

In this image, we can see a line graph. On the graph, we can see the numbers.

<!-- image -->

1.   A ray of light is incident at an angle of 35 o  onto a plane mirror as shown above.
2. (a)  Complete the diagram by drawing and labelling the normal and the reflected ray.
3. (b)  Label the angle of incidence and the angle of reflection as i and r on the diagram.
4. (c)  Calculate the angle of incidence.
5. (d)  Deduce the angle of reflection? \_\_\_\_\_\_\_\_\_\_

Give a reason for your answer.

2.  The diagram shows a light ray incident on a plane mirror. What must be the angle of incidence if the sum of the angles between the incident and reflected rays is 90 o ?
3. A mirror is tilted at an angle of 20 o  with respect to the bench.

<!-- image -->

A light ray is directed so that it hits the mirror at an angle of 25 o to the surface of the mirror.

<!-- image -->

- (i) Draw and label the normal and the reflected ray.
- (ii) What is the angle of reflection?  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Formation of an Image in a Plane Mirror

A plane mirror forms the image of objects in front of it by reflection. These images appear to be behind the plane in which the mirror lies, that is, inside the mirror. But how do the rays of light actually travel to form the image?

## Procedure for drawing a ray diagram for reflection in a plane mirror:

1. Draw a plane mirror at the centre of a blank page.
2. Draw the letter L at a measured distance from the plane mirror as shown below.
3. Draw the reflection of the letter L at the same measured distance as in step 2, but behind the plane mirror, exactly opposite to the object.
4. Next, draw two rays of light from the lower right tip of the letter L to the surface of the plane mirror. The two rays must be sloping downwards and diverge slightly away from each other.
5. Now, draw the reflection of the two rays of light from the lower left tip of the image of the letter L.
6. The rays must be drawn as broken lines behind the mirror, then extended as continuous lines  in  front  of  the  plane  mirror.  Again,  the  two  rays  must  be  sloping  downwards  and diverge slightly away from each other.
7. Finally, note that the rays of light that are real (in front of the mirror) represent the incident and reflected rays and the arrowheads are drawn as appropriate to indicate their respective directions.
8. The rays of light behind the mirror are virtual and are not drawn with arrowheads.

In this image, we can see a light ray. There is a reflection of a light ray on the surface of a mirror.

<!-- image -->

Unit

P2

## The image formed in the plane mirror has the following characteristics:

1. The image is of the same size as the object.
2. The image is virtual (that is, it cannot be projected on a screen).
3. The image is laterally inverted (that is, the right side of object appears as left side of image, and vice versa).
4. The image is upright.
5. The image distance behind the mirror is the same as the object distance in front of it.

## Some uses of reflection:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| 1. Aplane mirror is used by people to see their own reflection. This is useful when shaving or dressing up.                                                                             |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2. Therear-view mirror of a vehicle enables the driver to see the traffic behind the vehicle.                                                                                           |
| 3. Amicroscope uses a mirror to reflect light to the specimen under the microscope.                                                                                                     |
| 4. Mirrors are used by dentists to examine patients'teeth.                                                                                                                              |
| 5. Mirrors are used in periscope to view objects which are not at the same level as the observer. For example, the other side of a highwall or the surface of the sea from a submarine. |

<!-- image -->

## FIND OUT

If you have ever seen an ambulance, the word 'AMBULANCE' is written in the form of a mirror image in vehicles (that is, the word is laterally inverted). Why is it so?

<!-- image -->

<!-- image -->

1. The image formed by a plane mirror is virtual and laterally inverted.
2. (a) Explain what is meant by:
3. (i) A virtual image
4. (ii) A laterally inverted image
5. (b) List three other characteristics of an image formed by a plane mirror.
2. The figure shows a domino placed in front of a plane mirror.
7. (a) Draw the image of the domino.
8. (b) Complete the diagram to show how the observer is able to see the image of the domino.

<!-- image -->

3. Car X is following car Y. The registration number of car X is FEL9Z as shown on the diagram. Write down the registration number of car X as seen by the driver of car Y in the rear view mirror.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. A man sits on a chair and views the reflection of a painting which is found behind him at a distance of 3 m. The mirror is at a distance of 1 m in front of the man.
2. (i) What is the distance between the man and his image?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) What is the distance between the man and the image of the painting?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii) The man moves back 1 m. What is the new distance between the man and the image of the painting?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

<!-- image -->

painting

<!-- image -->

<!-- image -->

1. Which of the following emits light?
2. A Moon
3. B Sun
4. C Mars
2. A ray of light hits a surface of a plane mirror at 900 as shown below.

In this image, we can see a line.

<!-- image -->

What is the angle of reflection?

A

90

o

- B 180 o
3. The image formed by a plane mirror is
- A In front of the mirror
- B Real
- C Smaller
- D Laterally inverted
4. A ray of light strikes a mirror as shown below. What is the angle of reflection?

In this image, we can see a graph.

<!-- image -->

C

o

45

- D Earth

D

o

0

Light

Unit

Unit

P2

1

Unit

P2

Light

5. The light phenomenon by which the incident light falling on a surface is sent back into the same medium is known as
2. A Deformation
3. B Reflection
4. C Diffusion
5. D Repulsion
6. An object is placed 2 m from a plane mirror and then shifted by 0.5 m away from the mirror.

In this image, we can see a diagram. There is a line in the image.

<!-- image -->

What is the final distance between the object and its image?

- A 2 m
- B 5 m
- C 2.5 m
7. A ray of light is reflected between two glass panes as shown below.

<!-- image -->

What is the value of the angle a in the diagram?

A 30 o

B 90 o

C 60 o

- D 4.5 m
- D 45 o

Light

Unit

Unit

P2

1

8. An object O is placed in front of a plane mirror. A person looks into the mirror as shown in the diagram. At which position is the image of O seen?
9. A boy stands beside a girl in front of a large plane mirror. They are both the same distance from the mirror, as shown below.  Where does the boy see the girl's image?
10. An image is formed in a plane mirror.

In this image, we can see a line.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In this image, we can see a diagram. There are two arrows on the diagram. We can see the text on the image.

<!-- image -->

Which statement must be correct?

|       | angles                  | distances   |
|-------|-------------------------|-------------|
| w = y | d O = d I               | A           |
| w = z | d O is greater than d I | B           |
| x = y | d O = d I               | C           |
| x = z | d O is greater than d I | D           |

Unit

P2

## STRUCTURED QUESTIONS

<!-- image -->

1. State whether each the following statement is TRUE or FALSE.

1. A luminous body absorbs light energy.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2. The Moon is a body that emits light energy.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. Light does not travel in straight lines.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. The angle of incidence is not always the angle of reflection.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

5. The image formed by plane mirror is always virtual.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2.   (a) What is a ray of light?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b) The diagram below shows a ray of light being reflected at the surface of a plane mirror.

- (i) Write down the names of the lines labelled A, B and C.

A: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

B: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

C: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) What is the value of the angle of reflection?

A

410

mirror

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3. A student tries to reflect the word TEST in a plane mirror.
2. (i) Draw the appearance of the image that the student will see below.

TEST

<!-- image -->

- (ii) State three characteristics of the image formed in the plane mirror.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

4. (a) Complete the following diagrams by drawing two rays of light to show how the image of each object is formed in the plane mirror and is viewed by the observer.

In this image, we can see a diagram.

<!-- image -->

Unit

P2

Light

5. The figure below shows a ray of light being shone onto a plane mirror.
2. (a) State the laws of reflection.

In this image there is a diagram.

<!-- image -->

\_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_

\_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_ \_

- (b) Record the angle of incidence.

i = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (c) Hence, write down the angle of reflection.

r = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (d) On the figure, complete the path of the ray of light after being reflected by the plane mirror.
- (e) Add an arrow to show the direction of the reflected ray.
6. A ray of light is incident on a mirror and is reflected as shown.

In this image, we can see a diagram. There is a diagram with a line and a point.

<!-- image -->

Calculate the angle of incidence and hence deduce the angle of reflection.

Angle of incidence = \_\_\_\_\_\_\_\_\_ °

Angle of reflection = \_\_\_\_\_\_\_\_\_  °

<!-- image -->

- Watch this video from Youtube to understand the basic idea about luminous and non-luminous objects: https://www.youtube.com/watch?v=3qJ8D-t6qNo
- https://www.youtube.com/watch?v=CBcGxaxopok

## Summary of unit

## Reflection

- Light is an important form of energy for vision.
- Luminous objects emit light whereas non-luminous objects do not emit light.
- Stars are luminous whereas moons and planets are non-luminous.
- Light travels in straight lines.
- Reflection of light is the bouncing off of light from a reflecting surface.
- There are two laws of reflection:
- (i)   The angle of incidence is equal to the angle of reflection.
- (ii)   The incident ray, the reflected ray and the normal at the point of incidence all lie on the same plane.
- Ray diagrams are used to demonstrate reflection. They are used to show the formation of image in a plane mirror.
- The image formed in a plane mirror is virtual, upright, the same size as the object, laterally inverted and as far behind the mirror as the object is in front of it.

Unit

P2

• Unit P2 • Light

1

Light

In this image we can see a diagram, which is in white color.

<!-- image -->

<!-- image -->

## Multiple choice questions

- 1.
- Objects that do not emit light are called ……………………… objects.
- A transparent
- B opaque
- C luminous
- D non-luminous
2. Many rays of light coming from different directions and meeting at one point are called
- …………………………..
- A parallel rays
- B convergent rays
- C divergent rays
- D normal
3. An optician's test card is fixed 80 cm behind the eyes of a patient, who looks into a plane mirror 300 cm in front of him, as shown in the diagram.

In this image there is a person standing on the floor. There is a board on the floor. There is a text on the board.

<!-- image -->

The distance from his eyes to the image of the card is

- A 300 cm
- B 380 cm
- C 600 cm
- D 680 cm
4. A boy is running at a speed of 0.7 m/s towards a plane mirror.  The boy and his image in the mirror are moving
- A towards each other at a speed of 1.4 m/s
- B away from each other at a speed of 1.4 m/s
- C away from each other at a speed of 0.7 m/s
- D towards each other at a speed of 0.7 m/s

Unit

P2

- The figure below shows a ray of light from an object O being reflected from a plane mirror.
5. At which of the following positions will the image be found?
- 6.
- A periscope works by ……………………….
- A reflecting light
- B absorbing light
- C converging light

In this image, we can see a diagram. There are some lines and symbols.

<!-- image -->

## STRUCTURED QUESTIONS

1. The diagram below shows an experiment carried out by a student.

In this image, we can see a person standing and holding a torch. We can also see a flame and a pillar.

<!-- image -->

Three cardboards with holes at their centres are aligned as shown above.  A candle whose flame is at the same height as the holes is viewed beyond cardboard C.

- (i) Can the student observe the flame when the three holes are aligned?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)  What would happen if the holes are made smaller?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii) Any one of the cardboards is displaced sideways.  Can the student still see the flame? Explain your answer.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- D emitting light

<!-- image -->

## Web link

Watch the following video from Youtube about an experiment to show that light travels in a straight line:   https://www.youtube.com/watch?v=9gqWzKI-tXI

2. (a) State the meaning of the following terms:
2. (i) laterally inverted image

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) virtual image

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (b)  A girl is sitting in front of a plane mirror at a distance of 150 cm.  There is a photo frame hanging 2.5 metres behind her on the wall.
- (i)   What is the distance between the photo frame and its image?
- (ii)    What is the distance between the girl and the image of the photo frame?
- (iii) If the girl moves towards the mirror by 50 cm, what will be the distance between her image and the photo frame?

In this image, we can see a girl sitting on the floor. We can also see a wall.

<!-- image -->

Unit

P2

3. Diagram 1 shows a boy hiding behind a sofa. He uses a periscope to look at  an  object  found  on  the  other  side of  the  sofa. Diagram 2 shows  a  magnified  view  of  the cross-section of the periscope.
2. (a)  Using a protractor, draw the normal at the point where the light ray from the distant object strikes the mirror U on diagram 2.
3. (b)  On diagram 2, continue the ray of light to show how the light comes out of the eye piece of the periscope.  Indicate the direction of the light ray with arrows.

Diagram 1

In this image we can see a boy sitting on the sofa. He is holding a pipe. In the background there is a shelf with books and other objects.

<!-- image -->

Diagram 2

In this image, we can see a diagram.

<!-- image -->

In this image we can see a board and a sun.

<!-- image -->

## At the end of this unit, you should be able to:

- Explain the concept of work and solve problems using W= Fd, where d is the distance moved in the direction of the force
- Relate power to work done and time
- State the principle of conservation of energy
- Solve problems related to the conservation of energy in simple systems including falling objects and the simple pendulum
- Describe the production of electricity using renewable and non-renewable sources of energy
- Classify the polluting and non-polluting sources of energy for electricity production
- List the advantages and disadvantages of producing electricity using renewable and non-renewable sources of energy

In Grade 8, you learnt about  work, energy and power. You learnt how to solve simple problems related to work done and power using appropriate formulas. You also learnt about kinetic and potential energies and how to calculate them.

In this unit, you will review some of these concepts and you will extend your knowledge about energy conversions.

You will also learn about the production of electricity using renewable and non-renewable energy sources.

In addition, you will develop an understanding of heat and temperature.

67

## Work

In Grade 8, you learnt that work is done when a force moves a body in the direction of the applied  force.    Hence,  work  depends  on  the force applied and  the distance moved in the direction of the force .  In other words, work is said to be done when a force produces motion in the direction of the force.

## ACTIVITY 3.1 - Recalling when work is done in Physics

<!-- image -->

Complete the table below.  The first two situations have been done for you.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Situation                                       | Direction of applied force   | Direction of motion   | Work or Nowork? Support your answer.                                                                                        |
|-------------------------------------------------|------------------------------|-----------------------|-----------------------------------------------------------------------------------------------------------------------------|
| A woman pushing a wall.                         |                              | No motion             | No, work is not done by the woman on the wall as the wall is not moving in the direction of the force applied by the woman. |
| Two men pushing a car.                          |                              |                       | Yes, work is done by the men on the car as the car moves in the direction of the force applied by the men.                  |
| A fisherman holding his catch above the ground. |                              |                       |                                                                                                                             |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| A man climbing up a tree.                                 |
|-----------------------------------------------------------|
| A man standing.                                           |
| Two oxen pulling a cart.                                  |
| A cane cutter carrying a bundle of sugarcane on her head. |

We observe that there are some examples where work is done, especially where a force is applied to move a body.

<!-- image -->

## Definition of Work Done

Work done is defined as the product of the applied force on a body and the distance moved by the body in the direction of the applied force.  The SI unit of work is joule (J).

## Work done = Force × distance moved in the direction of the force Wd = F × d

where W d is work done by a force and is measured in joule (J),

F is the applied force measured in newton (N) and d is the distance moved in the direction of the force and is measured in metre (m).

<!-- image -->

## DID YOU KNOW…

Sometimes, the kilojoule (kJ) is used, which is a larger unit.

1 kJ = 1000 J

## ACTIVITY 3.2 Calculating work done

<!-- image -->

The picture below shows a young man pushing a trolley in a supermarket.  The force exerted by him on the trolley is 30 N and the trolley moves through a distance of 5 m in the direction of the force.

In this image, we can see two people. One person is holding a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trolley. We can also see a trol

<!-- image -->

- (a)  State the distance moved by the trolley, d = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (b)  State the force exerted on the trolley,  F = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_
- (c)  Write down the formula used to calculate the work done.
- (d)  Hence, calculate the work done by the force on the trolley.

<!-- image -->

Mass is the amount of matter contained in a body whereas weight is the force of gravity acting on that body. Weight is calculated using:

Weight = mass × acceleration due to gravity W = mg

where W is measured in newton (N), m is measured in kilogram (kg), and g is equal to 10 m/s 2 on Earth.

<!-- image -->

1. Calculate the missing values in the table below.
2. An electric motor lifts a body of mass 20 kg to a height of 15 m.
3. (a)  What is the weight of the body?
4. (b)  Calculate the work done in lifting the body.

| Force (N)   | Distance moved(m) in the direction of the force   | Work done (J)   |
|-------------|---------------------------------------------------|-----------------|
| 1000        | 4                                                 |                 |
| 15000       | 40                                                |                 |
| 100         |                                                   | 600             |
|             | 25                                                | 5000            |

## Power

In this section, you will recall the concept of power that you learnt in Grade 8.

## ACTIVITY 3.3 - Recalling what is meant by power

<!-- image -->

Study the given example.

Sam and John have equal masses. They are standing at the foot of a tall building. Sam takes only 5 minutes to climb the stairs to reach the fifth floor of the building while John takes 10 minutes to climb the same height.

1. Discuss in groups and state who has done more work. Explain your answer.
2. Who is more powerful among the two boys? Explain your answer.

Conclusion : Both Sam and John have done the same amount of work in climbing the stairs through the same vertical distance.

Sam is more powerful than John because he has done the same amount of work in less time.

Hence, the rate of doing work is greater for Sam than for John.

## Definition of power

Power is defined as the rate of doing work.

Power is also defined as the amount of work done per unit time. The SI unit of power is the watt (W).

<!-- image -->

work done time taken

James Watt

power

=

$$\boxed { \ P \, = \, \frac { w _ { d } } { t } }$$

(19 January 1736 - 25 August 1819) was a Scottish inventor, mechanical engineer, and chemist.

Where P is measured in watt (W), W d is measured in joule (J), and t is measured in second (s).

Power is also calculated using:

<!-- image -->

Note: 1 W = 1 J/s

<!-- image -->

DID YOU KNOW…

Sometimes, the kilowatt (kW) is used, which is a larger unit.

1 kW = 1000 W

<!-- image -->

1. Calculate the power developed if 2000 J of work is done in 50 s.
2. Calculate the power developed by an electrical appliance if 4800 J of electrical energy is converted to heat energy in 120 s.

Power developed = \_\_\_\_\_\_\_\_\_\_\_\_\_

Power developed = \_\_\_\_\_\_\_\_\_\_\_\_\_

Unit

Unit

P3

1

3. A crane lifts a load of 6000 N through a vertical distance of 15 m in 30 s. What is the power during this operation?

<!-- image -->

Power developed = \_\_\_\_\_\_\_\_\_\_\_\_\_

4. A 40 kg girl takes 20 s to run the flight of stairs.  Use information from the diagram below to calculate the power developed by the girl.

<!-- image -->

Power developed = \_\_\_\_\_\_\_\_\_\_\_\_\_

## Power Rating of  Electrical Appliances

## ACTIVITY 3.4 Understanding the meaning of power rating

<!-- image -->

Observe the three electrical devices shown below.

<!-- image -->

40 W bulb                     500 W drilling machine               6 W mobile phone

<!-- image -->

<!-- image -->

3. Hence, which appliance among the three listed above uses more power?

1. What is the meaning of a 40 W bulb? Discuss in your group and state a possible answer.

2. Explain what 500 W and 6 W represent for the drill and the mobile phone respectively.

<!-- image -->

## ACTIVITY 3.5 Calculating the power exerted by cranes from given data

The table below shows information about four cranes A, B, C and D, lifting some load.

| Crane   |   Load (N) |   Vertical distance (m) |   Time (s) | Work done/ J   | Power/W   |
|---------|------------|-------------------------|------------|----------------|-----------|
| A       |        500 |                       5 |         10 |                |           |
| B       |       1000 |                      10 |         10 |                |           |
| C       |       1000 |                      10 |          8 |                |           |
| D       |       1500 |                      12 |         12 |                |           |

1. Compare cranes B and C. Without doing any calculation, state which one is more powerful. Give a reason for your answer.
2. Complete the table by calculating the work done and the power exerted in each case.
3. Among the four cranes, which one exerts more power?

Unit

P3

<!-- image -->

1. A boy, who weighs 50 N, runs up a flight of stairs 6.5 m high in 7 seconds. How much power does he develop?

2. When the driver of a car applies the brakes, a force of 4000 N brings the car to a stop over a distance of 50 m.

- (a)  Calculate the work done by the braking force.

- (b) Calculate the braking power if the time taken to stop the car is 5.0 s. Give your answer in kilowatts (kW).

## Energy

In Grade 8, you learnt about the different forms and sources of energy.

In this unit, you will learn more about energy conversions and conservation in various real-life situations.

You have learnt that energy is needed to perform our daily activities. For example, an athlete needs energy to be able to run a 200 m race. From where does the athlete get this energy that he needs? In which form is this energy available? Let us find out.

## ACTIVITY 3.6 Recalling the various forms of energy

<!-- image -->

Table 1 shows various forms of energy.

Study the table and discuss in groups to find out the form(s) of energy involved in each case.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 1

| energy is stored in the food.           | The stretched rubber band possesses energy.                | A dry cell stores energy.                      |
|-----------------------------------------|------------------------------------------------------------|------------------------------------------------|
| energy comes from the drum.             | The hot coffee possesses energy.                           | A bird sitting on the branch possesses energy. |
| The lighting bulb gives out and energy. | Radioactive particles have energy after nuclear reactions. | energy in the circuit lights the bulb.         |

Unit

P3

## Kinetic Energy and Potential Energy

In this section, you will recall about kinetic and potential energy that you learnt in Grade 8.

## Kinetic Energy

Kinetic energy is the energy possessed by a moving body. Its SI unit is the joule (J). The pictures below show instances where kinetic energy is involved.

<!-- image -->

Figure 1

In this image we can see two airplanes flying in the sky.

<!-- image -->

Figure 2

The runners in Figure 1 possess kinetic energy as they are in motion. The faster a body moves, the more kinetic energy it has.

The two airplanes in Figure 2 are moving with the same speed. However, the bigger airplane possesses more kinetic energy as it has a greater mass.

## Calculation of Kinetic Energy

If a body of mass (m) is moving with a constant speed (v), its kinetic energy is calculated using the formula:

$$\left | \text{Kinetic energy } = \frac { 1 } { 2 } \, x \, \text{mass of the body } \, x \, (speed ) ^ { 2 } \, \right |$$

$$\sqrt { \ K. E } = \frac { 1 } { 2 } \ m v ^ { 2 }$$

$$2$$

where,  m is the mass of the body in kilogram (kg), and v is the speed of the body in m/s.

In this image, we can see a diagram. In the diagram, we can see a boy hitting a ball with a stick.

<!-- image -->

<!-- image -->

1. A man fires a gun and a bullet leaves the gun at a speed of 100 m/s. Calculate the kinetic energy of the bullet given that it has a mass of 40 g. (Note 1 kg = 1000g)
2. A vehicle moving at a speed of 8 m/s has kinetic energy of 64000 J. Calculate its mass.

## Potential Energy

Potential energy is the energy possessed by a body due to its position above the ground or its state.

Potential energy can be classified into:

1. Gravitational potential energy
2. Elastic potential energy

Unit

P3

## Gravitational Potential Energy

Gravitational potential energy is defined as the energy possessed by a body due to its position above the ground.  Its SI unit is the joule (J).

The diagram below shows a ball at three different heights during a game.  At position 1, the ball has maximum gravitational potential energy.  It is because its position is highest above the ground.

<!-- image -->

2

State and explain at which position the ball will have the least potential energy.

## Calculation of gravitational potential energy

If a body of mass (m) is placed at a height (h) above the ground, gravitational potential energy is calculated using:

Gravitational potential energy = mass of body × acceleration due to gravity × height of body

GPE = m × g × h GPE = mgh

But,

Hence,

GPE = weight × h where, GPE is the gravitational potential energy and is measured in joule (J), m is the mass of the body in kilogram (kg), g = 10 m/s 2  on Earth, and h is the height above the ground in metre (m).

weight = mg

## Worked example

Rita runs up a flight of 30 stairs, each of height 20 cm. If she has a mass of 60 kg, calculate the gravitational potential energy gained by her body.

Given,

Mass, m = 60 kg Vertical height, h = 30 × 0.2 = 6 m g = 10 m/s 2

Using gravitational potential energy = m × g × h

= 60  × 10 × (30 × 0.2)

= 3600 J

<!-- image -->

1. What is the gravitational potential energy of a body having a mass of 50 kg held at a height of 4 m above the ground level?
2. Mike is at the top of a ladder and his gravitational potential energy is 4000 J. Given that he is 5 m vertically above the ground, calculate his mass.

## Elastic Potential Energy

Elastic  potential  energy  is  defined  as  the  energy  stored  in  a  body  due  to  its  deformation. It happens when the body has an elastic nature. For example, a bent ruler or a stretched spring.

<!-- image -->

<!-- image -->

The bent ruler and the stretched spring have stored elastic potential energy.

Unit

P3

## Energy Conversions and Conservation

In  Grade  8,  you  were  introduced  to  the  idea  of  energy  conversions. You  learnt  that  energy changes from one form to another. So let us recall what you learnt.

## ACTIVITY 3.7 Investigating energy conversions

<!-- image -->

The diagram below shows an apple falling from a tree.

<!-- image -->

1. Observe the diagram and discuss.

- (a)  What form of energy is stored in the fruit hanging on a tree?

- (b) What form of energy decreases as the fruit falls?

- (c)  What form of energy increases as the fruit falls?

- (d) What happens to the energy stated in part (c) as the fruit hits the ground?

- (e)  Write down the energy changes that occur as the fruit falls and hits the ground.

2. Suggest other examples of energy conversions.

## Conclusion

The apple stores gravitational potential energy when it is on the tree. As it falls, the gravitational potential energy is converted gradually into kinetic energy. The gravitational potential energy goes on decreasing until it is zero, while the kinetic energy goes on increasing until it becomes maximum just before it hits the ground.

On hitting the ground, the kinetic energy of the apple is turned into sound energy and some heat energy.

This shows that we can always keep track of the energy conversion in any example. There is no energy lost and the total energy remains the same. The energy can only change form but it cannot be created or destroyed. This fact is known as the Principle of Conservation of Energy .

## Principle of Conservation of Energy

The principle of conservation of energy states that energy can neither be created nor destroyed, but it can be converted from one form to another.

It also means that the total amount of energy remains constant.

The following examples illustrate the conservation of energy.

## The simple pendulum

Figure A shows a simple pendulum.

In this image, we can see a diagram. There is a text at the bottom of the image.

<!-- image -->

In Figure B, when the bob is pulled to one side and released, it swings. The to-and-fro motion of the pendulum is called an oscillation.

Figure  B

The image is a diagram of a circuit with two circular objects connected by a line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line. The objects are connected by a line, which is a straight line. The line is drawn with a black line

<!-- image -->

## The path taken by the pendulum

An oscillating simple pendulum is a very good example to illustrate the transformation of gravitational potential energy to kinetic energy and vice versa.

As  the  pendulum  oscillates,  there  is  a  continuous  interchange  of  energy  as  shown  in  the diagram below.

In this image, we can see a diagram. There are two lines, one is labeled as "PE=Max" and the other is labeled as "PE=K=Max".

<!-- image -->

- Positions 1 and 5 are the extreme positions. At these positions, the gravitational potential energy is maximum, as the bob is at its highest position.
- When the pendulum moves from position 1 to 3, its gravitational potential energy decreases and kinetic energy increases.
- At position 3, the pendulum has the maximum kinetic energy and minimum gravitational potential energy, being the lowest position.
- From position 3 to 5, the pendulum bob gains gravitational potential energy, as it moves higher.

At any instant, the sum of the kinetic energy and potential energy is constant. This means that the total energy remains constant.

<!-- image -->

## ACTIVITY 3.8 - Investigating energy conservation in a simple pendulum

1. With reference to the pendulum, discuss in groups and complete the table below.

|   Positions | Kinetic energy /J   | Gravitational potential energy/J   | Total energy /J (Kinetic + Potential)   |
|-------------|---------------------|------------------------------------|-----------------------------------------|
|           1 | 0                   | 40                                 |                                         |
|           2 | 20                  |                                    |                                         |
|           3 |                     |                                    | 40                                      |
|           4 |                     | 20                                 |                                         |
|           5 |                     |                                    | 40                                      |

What conclusion can be drawn from the values observed in the table? Write it.

Unit

Unit

P3

1

<!-- image -->

<!-- image -->

<!-- image -->

1. Write the energy changes that take place in the following:

- (a)  An electric bulb that is lit:

- (b) Charging the battery of a mobile phone:

- (c)  Climbing a ladder:

- (d) A moving car braking to stop completely:

- (e)  A lift going down:

Consider a ball being dropped from a table to the ground.

1. Discuss in groups and then answer the questions that follow.

- (a)  What form of energy does the ball possess at the top of the table?

- (b) What happens to this energy mentioned in part (a) as the ball falls?

- (c)  State the energy conversion that occurs when the ball hits the ground.

It is found that the conservation of energy for the falling ball follows the same pattern as the apple falling from the tree.

TEST YOURSELF

ball

ground

<!-- image -->

2. (a) (i) Define kinetic energy.
2. (ii)   What is the difference between kinetic energy and potential energy?
3. (b) A tennis ball is tested before a tennis match. It is dropped onto a concrete surface from position A as shown below. It rebounds and rises to position B, at a height of 60 cm. The mass of the ball is 50 g.
4. (i) Write down the formula needed to calculate the gravitational potential energy of a body.
5. (ii) Determine the gravitational potential energy of the ball at position A.
6. (iii)  Write down the kinetic energy of the ball just before impact with the concrete surface.
7. (iv)  Calculate the velocity with which the ball strikes the  concrete surface.
8. (c) It is observed that the ball reaches a height of 25 cm after first impact with the surface. (i) Calculate the gravitational potential energy of the ball at B.
9. (ii) Calculate the energy loss on impact with the surface.
10. (iii)  State two types of energy into which the gravitational potential energy is converted upon impact with the surface.

<!-- image -->

## Renewable and Non-renewable Energy Sources

In this section, you will learn about renewable and non-renewable sources of energy and how they can be used in the production of electricity.

In lower grades, you learnt about various sources of energy such as:

- Sun
- Wind
- Falling water
- Firewood
- Food
- Bagasse
- Fossil fuels

Energy sources can be classified into two groups:

1.  renewable
2.  non-renewable sources

<!-- image -->

## ACTIVITY 3.10 - Comparing renewable and non-renewable sources of energy

1. Observe the two pictures below and answer the questions that follow.
- a) State and explain which one is a renewable source.
- b)  What is the difference between a renewable and a non-renewable energy source?
- c) State two renewable and two non-renewable sources of energy used in Mauritius and Rodrigues.

<!-- image -->

<!-- image -->

<!-- image -->

A renewable energy source is one that can be replaced or replenished naturally after it has been used.

A non-renewable energy source is  one that cannot be replaced or replenished after it has been used, and it will eventually run out.

<!-- image -->

## ACTIVITY 3.11 -  Classifying sources of energy as renewable or nonrenewable

1. Study the list of sources of energy given below.

biogas,  heavy  oil,  coal,  wind,  falling  water,  natural  gas,  geothermal,  sun,  food, batteries, firewood, charcoal, saw dust, ethanol, domestic waste, gasoline, diesel

2. Discuss in groups and classify each one of the list as being renewable or non-renewable in the table below.

It is observed that all the sources of energy that we use are either renewable or non-renewable.

These  sources  can  further  be  classified  as  being  polluting  or  non-polluting.  For  example, bagasse is a renewable source of energy but it is a polluting one, whereas falling water is a non-polluting renewable source of energy. Fossil fuels are polluting non-renewable sources of energy.

<!-- image -->

Coal, oil and natural gas are called fossil fuels.

Fossil fuels were formed from the decomposition of dead plants and animals millions of year ago.

## Production of Electricity using Renewable and Non-renewable Sources of Energy

In this section, we will investigate how renewable and non-renewable sources of energy are used in the production of electricity. We will study their advantages and disadvantages on the environment.

In Mauritius and Rodrigues, falling water, sun, wind, biogas, and coal are some main sources of energy for the production of electricity. In Agalega, electricity is generated from fossil fuel.

## Production of Electricity using Falling Water

Electricity generated using falling water is called hydro-electricity.

To store the water, dams are built across large rivers to form a reservoir.

In this image there is a water reservoir and a turbine.

<!-- image -->

The water stored behind the dam possesses gravitational potential energy. The water is made to flow downwards through large pipes to turn a turbine. Then, the turbine turns a generator. The kinetic energy of the moving water is transformed into electrical energy.

The energy conversion for a hydroelectric power station is represented as follows:

Gravitational Potential Energy

Kinetic Energy

Electrical Energy

## Production of Electricity using Coal

In this image we can see a steam turbine, a coal, a fuel, a water pipe, a chimney, a chimney, a coal, a power line, a pipe, a building, a roof, a roof, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney, a chimney

<!-- image -->

In the coal power station, the coal (fuel) which stores chemical energy is burnt so as to release heat energy. The heat energy is used to heat water in a boiler to produce high pressure steam. The kinetic energy of the steam turns the turbines to generate electricity.

<!-- image -->

The energy conversion for a coal power station is represented as follows:

Chemical Energy Heat Energy Kinetic Energy Electrical Energy

<!-- image -->

## ACTIVITY 3.12 -   Comparing the advantages and disadvantages of using renewable and non-renewable sources of energy

In lower grades, you learnt about the advantages and disadvantages of using renewable and non-renewable sources of energy.

1. Discuss in your groups about the advantages and disadvantages of using renewable and non-renewable sources of energy to produce electricity.
2. Then fill in the table below. One example is given.
3. Add other examples to this list.

| Production of electricity   | Advantages                          | Disadvantages   |
|-----------------------------|-------------------------------------|-----------------|
| Solar energy                | No pollution Renewable Free of cost |                 |
| Wind                        |                                     |                 |
| Hydro electric energy       |                                     |                 |
| Fossil fuels                |                                     |                 |
| Geothermal                  |                                     |                 |

<!-- image -->

1. The figure below shows a block diagram of a power station.

The three boxes represent different parts of the power station. The first box is labelled.

<!-- image -->

Each box should contain one of the items from the list below:

## generator, turbine

- (a)  On the figure, label the boxes using the correct items from the list.
- (b) State one environmental problem caused by burning oil to produce electricity.
- (c)  Oil is a non-renewable energy source.
- (i)  State why oil is described as a non-renewable energy source.
- (ii)  State one renewable energy source.
2. When electricity is needed, the water in the high reservoir is allowed to flow to the low level reservoir. The flowing water generates electricity.

In this image we can see a water flow, a pipe, a machine, a pipe, a water tank, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe, a pipe,

<!-- image -->

Use the correct items from the box to complete each sentence.

electrical         gravitational potential        sound      kinetic       turbine

- (a)  The water in the high level reservoir stores                                                     energy.
- (b) The flowing water has

energy.

- (c)  The water turns the
- (d) The generator produces some

which is connected to the generator.

that is wasted energy.

<!-- image -->

3. Fill in the blanks with a word of your own .

- (i) Bagasse is a renewable but \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ source of energy.

- (ii)  The source of energy used by a sailing boat is from the\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (iii)  Electricity generated using falling water is called \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(iv)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ energy is an eco-friendly source of energy taken from the

Earth's crust.

- (v)  The burning of fossil fuels to produce electricity is \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ for the

- environment.

## Summary of unit

- Work is defined as the product of the applied force (F) on a body and the distance moved (d) by the body in the direction of the applied force.
- The SI unit of energy is the joule (J).
- Power is defined as the rate of doing work and its SI unit is the watt (W).
- Energy is the ability to do work and its SI unit is the joule (J).
- There are various forms of energy namely: wind, electrical, chemical, geothermal, light, sound, nuclear, tidal, kinetic and potential energy.
- Kinetic energy is the energy possessed by a body due to its motion.
- Potential energy is the energy possessed by a body due to its position or state.
- Gravitational potential energy is defined as the energy stored in a body due to its position.
- Elastic potential energy is defined as the energy stored in a body due to its state.
- The principle of conservation of energy states that energy can neither be converted nor destroyed but it can be converted from one form to another and the total amount of energy remains constant.
- A renewable energy source is one that can be replaced or renewed naturally after it has been used whereas a non-renewable energy source is one that cannot be replaced or renewed after use and it will eventually run out.
- The energy conversion for a hydroelectric power station is represented as follows: gravitational potential energy kinetic energy electrical energy
- The energy conversion for a coal power station is represented as follows: chemical energy heat energy kinetic energy electrical energy

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

<!-- image -->

## END OF UNIT QUESTIONS

## Multiple choice questions

1. What is the source of the energy converted by a hydro-electric power station?

A Hot rocks

- B Falling water

C

Oil

- D Waves
2. The diagram shows a man diving into water.

<!-- image -->

Which form of energy is increasing as he falls?

A Chemical

- B Gravitational

- C Kinetic

- D Elastic

3. A boy and a girl run up a hill in the same time.

<!-- image -->

weighs 6OON boy

<!-- image -->

The boy weighs more than the girl.

Which statement is true about the power developed?

- A The boy develops more power.
- B The girl develops more power.
- C They both develop the same power.
- D It is impossible to tell who develops more power.
4. Energy is stored in a battery and in a box of matches. Which type of energy is stored in each of them?

|    | Abattery   | Aboxof matches   |
|----|------------|------------------|
| A  | Chemical   | Chemical         |
| B  | Chemical   | Heat             |
| C  | Electrical | Chemical         |
| D  | Electrical | Heat             |

5. Which movement will require the greatest amount of work to be done?
2. A A force of 10 N moving an object a distance of 3.0 m
3. B A force of 10 N moving an object a distance of 5.0 m
4. C A force of 15 N moving an object a distance of 3.0 m
5. D A force of 15 N moving an object a distance of 5.0 m
6. Energy from uranium is transferred to electrical energy in a nuclear power station. What is the correct order of the stages of this process?
7. A boiler generator reactor turbine
8. B generator boiler turbine reactor
9. C reactor boiler turbine generator
10. D reactor turbine boiler generator
7. The list contains three energy resources P , Q and R.

P: geothermal energy from hot rocks Q: nuclear fission in reactors R: sunlight on solar panels

Which of these resources are renewable?

- A P and Q only
- B P and R only
- C Q and R only
- D P , Q and R
8. The diagram shows a ball hanging on a string. The ball swings from point W to point Z and back to point W.

<!-- image -->

Which statement about the ball is correct?

- A The kinetic energy of the ball is greatest at point W.
- B The kinetic energy of the ball is greatest at point X.
- C The kinetic energy of the ball is greatest at point Y.
- D The kinetic energy of the ball is the same at all points of the swing.

- A student who weighs 500 N climbs up a flight of stairs 10 metres high in 5 seconds.
9. What power does she develop?
- A 500 x 10 x 5 W
- B 500 x 10 W 5
- C 500 x 5 W 10
- D 5 W 500 x 10
10. A rock of mass 20 kg is travelling in space at a speed of 6 m/s. What is its kinetic energy?
- A 60 J
- B 120 J
- C 360 J
- D 720 J
11. Which represents the main energy changes that take place in a coal power station?
- A chemical heat kinetic electrical
- B chemical heat light electrical
- C chemical kinetic electrical potential
- D kinetic heat light electrical
12. An object is falling from the top of a building. What is the principal energy conversion taking place?
- A kinetic energy gravitational potential energy.
- B kinetic energy thermal energy (heat)
- C gravitational potential energy kinetic energy
- D gravitational potential energy chemical energy
13. The box contains the names of eight different energy resources. How many of these energy resources are renewable?
- A 3

| natural gas   | geothermal   | solar   | waves   |
|---------------|--------------|---------|---------|
| hydroelectric | oil          | wind    | coal    |

B 4

- C 5

D

6

14. The diagram shows part of a thermometer. What is the reading on the thermometer?
2. A 17.2° C
3. B 17.4 °C
4. C 17.7°C
5. D 18.3 °C
15. Which situation is an example of work?
7. A a person holding several books
8. C a boy pushing a trolley
16. What uses non-renewable energy?
10. A a geothermal heating system
11. C a solar panel
12. B a person sitting in a parked car
13. D a person applying a force on a wall
14. B a nuclear power station
15. D a wind turbine

In this image I can see the white color line.

<!-- image -->

## Structured Questions

1. The figure below illustrates the journey of a cyclist from point A to point B. Points A and B are at the same height.

In this image, we can see a person riding a bicycle. There is a line on the right side of the image.

<!-- image -->

The cyclist starts from rest at A and pedals up and over a hill. Near the bottom of the hill, she starts to brake and comes to rest at B.

- (a)  Describe the energy changes that take place as she pedals up the hill at constant speed.
- (b) Explain how the law of conservation of energy applies to the complete journey from A to  B.
- (c) At one point in the journey, the gravitational potential energy of the cyclist has increased by 5400 J. The mass of the cyclist is 60 kg. The gravitational field strength is 10 N / kg. Calculate the height above A of the cyclist at this point.
2. A tidal barrage (dam) produces electricity using tides. The figure below shows a diagram of a tidal barrage (simplified).

In this image there are two hills. On the left side there is a water body. On the right side there is a river.

<!-- image -->

<!-- image -->

- (a) The water behind the barrage (dam) is a store of energy. State the name of this stored energy.

- (b) Explain how the tidal barrage (dam) produces electricity.

3. The figure below shows a battery-operated alarm clock.

Use words from the box to complete the sentences.

The battery stores energy. When the battery is first connected, electrical energy is transferred to energy of the clock's hands. Some of the electrical energy is transferred to the surroundings as energy. When the alarm bell rings, electrical energy is transferred to energy.

4.

- (a)  State the Principle of Conservation of Energy.

chemical          electrical         kinetic           light         sound         heat

12

41

9

3

8

4

6

5

Unit

P4

3

- (b) A body of mass 400 g is raised to a height of 6.2 m.  It is then released.  Calculate:

- (i)  its gravitational potential energy at 6.2 m from the ground.

Gravitational potential energy = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii)  its gravitational potential energy and its kinetic energy when the body is at 4 m above the ground.

Gravitational potential energy = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Kinetic energy = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(iii) its speed before it hits the ground.

Speed before hitting the ground = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Learning Outcomes

## At the end of this unit, you should be able to:

- Distinguish between scalars and vectors and give examples of each
- Define distance and displacement
- Calculate distance and displacement in different situations
- Define speed and velocity
- Calculate speed using the equation speed =                                         and velocity using the equation velocity = distance travelled time taken displacement
- Define acceleration

time taken change in velocity

time taken

- Calculate acceleration using the equation acceleration =
- Demonstrate an understanding that deceleration is a negative acceleration
- Plot and interpret speed-time graph for motion in a straight line
- Recognise from the shape of a speed-time graph when a body is:
- at rest
- moving at constant speed
- moving with changing speed
- Interpret speed-time graphs

Motion is a very important aspect of our lives. Many bodies such as cars, buses, animals or even people move from one place to another. We move to go to school, to work and in order to perform our day-to-day activities. Motion is also an integral part of our leisure, since many activities such as athletics, football or racing depend on motion.

In this unit,  you will gain an understanding of various aspects of the motion of bodies.

Unit

Motion

Motion

Unit

Unit

P4

1

Energy

3

P 4

## Scalar and Vector Quantities

In  Unit  1  -  Measurement,  you  have  learnt  the  term 'physical  quantity' . You  have  learnt  that a  physical  quantity  is  described  using  a  magnitude  and  a  unit.  However,  for  some  physical quantities, we must provide an additional information, namely, direction.

## ACTIVITY 4.1 - Understanding different types of physical quantities

<!-- image -->

A person is going to Grand Gaube by car. He reaches a junction and sees the road sign as shown below.

<!-- image -->

1. What important information is missing on the road sign for the person to be able to reach Grand Gaube?
2. Study the table below and tick (√) the quantities which have a direction.

|    | Quantity     | Has a direction   |
|----|--------------|-------------------|
|  1 | Mass         |                   |
|  2 | Time         |                   |
|  3 | Force        |                   |
|  4 | Volume       |                   |
|  5 | Distance     |                   |
|  6 | Displacement |                   |

<!-- image -->

There are some quantities that have a direction. The direction needs to be specified along with the numerical value (magnitude).

Below are some examples of how quantities are expressed:

| Quantities that require a direction           | Quantities that do not require a direction   |
|-----------------------------------------------|----------------------------------------------|
| A force of 10 Nto the left                    | A mass of 10 kg                              |
| A velocity of 40 km/h in a westerly direction | A temperature of 10 o C                      |
| A displacement of 40 mdownwards               | A speed of 10 m/s                            |

A scalar quantity is a physical quantity that has a magnitude only, while a vector quantity is a physical quantity that has both magnitude and direction.

## Examples:

| Scalar quantities   | Vector quantities   |
|---------------------|---------------------|
| Mass                | Weight              |
| Temperature         | Acceleration        |
| Speed               | Force               |
| Distance            | Velocity            |
| Time                | Displacement        |
| Work                |                     |
| Power               |                     |
| Energy              |                     |

In the next section, you will learn about the difference between two quantities i.e., distance and displacement.

<!-- image -->

## Distance and Displacement

## ACTIVITY 4.2 - Differentiating between distance and displacement

<!-- image -->

The diagram below illustrates the top view of a rectangular shaped park.

The image depicts a straight line segment labeled as **D** with a length of **40 meters**. This line segment is positioned at the bottom of the image. The line segment is drawn with a straight line, which means it is a straight line without any curves or bends.

### Description of the Line Segment:
- **D**: The line segment is a straight line.
- **40**: The length of the line segment is 40 meters.

### Analysis:
- **Line Segment**: The line segment is a straight line.
- **Length**: The length of the line segment is 40 meters.

### Additional Information:
- **Directional Information**: The line segment is a straight line, which means it is a straight line without any curves or bends.
- **Position**: The line segment is located at the bottom of the image.

### Chain of Thought (CoT) Analysis:
1.

<!-- image -->

A student is running in the park along the track on the borders of the park.  She starts at point A and walks towards point B and finally to point C.  The path is indicated by the arrows in the diagram.  The length of the path from A to B and then from B to C is called the distance .

1. Determine the distance moved by the student.

Distance moved = \_\_\_\_\_\_\_\_\_\_

However, there is another path that the student can take if she wants to move from point A to point C.  This path is shown by the red arrow.

In this image, we can see a diagram. There is a line on the right side of the image. There is a text on the image.

<!-- image -->

This path is a straight line from the point A to point C. This straight line from an initial position to a final position is called the displacement . Displacement is a vector quantity, as it has both magnitude and direction .

2. Determine the displacement of the student.

<!-- image -->

Displacement = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The  meaning  of  the  distance  of  an  object  is  different  from  the  meaning  of  the displacement of the object. This is explained below.

## Definitions of Distance and Displacement

The distance of a body is the path taken by a body when moving from an initial position to a final position. Distance is a scalar quantity. Its Sl unit is the metre (m).

The displacement of a body is the distance travelled in a straight line from the initial position to the final position, and in a specific direction. Displacement is a vector quantity. Its SI unit is the metre (m).

<!-- image -->

The diagram below illustrates the top view of a rectangular shaped park. Emily takes her dog for a walk along the track on the borders of the park.

She starts at the entrance W, and walks towards X, Y, Z and finally back to W.

The image depicts two right triangles, labeled as W and Z. The vertices of the right triangles are marked as W and Z, and the lengths of the sides of the triangles are given as 10 and 50, respectively. The area of the right triangle WZ is 10, and the area of the right triangle WZ is 50.

<!-- image -->

120 m

Unit

P4

Motion

Determine the distance and displacement of Emily when she

(i) reaches point Y:

Distance = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Displacement = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

- (ii) is back at entrance W:

Distance = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Displacement = \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Speed

A student running in a rectangular shaped park, moves from point A to point B and travels a distance of 40 m. However, moving from one point to another takes time.

If the student travels this distance in a time of 10 seconds, then it means that she travels, on average, a distance of 4 metres in 1 second. So, she travels a distance of 4 metres per second (m/s). This distance that is travelled in 1 second is called the speed .

In this image, we can see a diagram.

<!-- image -->

## Definition of speed

Speed is defined as the distance travelled per unit time.

Speed is also defined as the rate of change of distance . The SI unit of speed is the metre per second (m/s).

<!-- image -->

Speed is a scalar quantity as it has magnitude only .

## Other units of speed are:

millimetre per second (mm/s) centimetre per second (cm/s) kilometre per hour (km/h)

<!-- image -->

If the magnitude of speed changes throughout the journey, then,

Average speed  =    Total distance travelled

T otal time taken

## Note:

Average speed gives us a general indication of the speed maintained during the motion. At times, the body may move at a slower pace and at other times, at a faster pace.

In this image there is a table with a few things on it.

<!-- image -->

## Constant Speed

A body has a constant speed if it covers the same distance in the same interval of time (e.g. every second).

For example, the skater, below, covers 3 metres in each second.  Therefore, he is moving at a constant speed of 3 m/s.

In this image, we can see a person standing and holding a skateboard.

<!-- image -->

## Velocity

Speed is a scalar quantity and it has only a magnitude. However, velocity is a vector quantity and it has both magnitude and direction.

<!-- image -->

## Definition of velocity

Velocity is defined as the distance moved by a body per unit time in a specified direction.

Velocity is also defined as the rate of change of displacement.

velocity  =    displacement time taken

Velocity is a vector quantity, as it has both magnitude and direction .  The SI unit of velocity is the metre per second (m/s).

## Worked example

A student runs from point P to point R in 50 s.

The image depicts a line diagram with two points labeled P and S. The line is drawn from point P to point S, with a slight arrow indicating the direction of the line. The line is drawn from point P to point S, with a slight arrow pointing from point P to point S. The line is drawn with a dashed line, indicating that it is not a straight line.

The diagram includes a small amount of text, which is located at the bottom of the image. The text is in a sans-serif font and is in black. The text reads:

"P = 80 m"

This text is likely a measurement or reference for the line.

### Analysis and Description:

- **Line Segment**: The line segment from point P to point S is a straight line.
- **Point P**: The point P is located at the bottom of the line.
- **Point S**: The point S is located

<!-- image -->

## Calculate

- (a) magnitude of the displacement when the student is at point R.
- (b) velocity of the student during his motion from point P to point R.

## Solution

- (a)  Recall: Displacement is the distance moved in a straight line. So, displacement is along the red arrow shown in the diagram.

$$\begin{smallmatrix} D i s p l a c e m e n t = \sqrt { 8 0 ^ { 2 } + 6 0 ^ { 2 } } \\ = \sqrt { 6 4 0 0 + 3 6 0 0 } \\ = \sqrt { 1 0 0 0 0 } \end{smallmatrix}$$

$$\begin{array} { c c c } & ( b ) \text{ velocity} = \frac { \text{ displacement} } { \text{ time taken} } \\ & & = \frac { 1 0 0 } { 5 0 } \\ & & &.. \end{array}$$

- = 2  m/s from P to R

<!-- image -->

## WHAT I HAVE LEARNT

It is noted that though speed and velocity appear to be the same, the main difference is that speed is the rate of change of distance whereas velocity is the rate of change of displacement. Speed is a scalar quantity whereas velocity is a vector quantity.

## Acceleration

A body experiences an acceleration when its velocity changes. The change in velocity can be either an increase or a decrease.

It should be noted that even if the speed remains constant, a change in direction means that there is an acceleration.

## Definition of acceleration

Acceleration is defined as the rate of change of velocity .  The SI unit of acceleration is the metre per second squared (m/s 2 ).

Change in velocity

Time taken

Acceleration    =

Acceleration    =

Final  velocity - Initial velocity

Time taken

$$a = \frac { v - u } { t }$$

where a is the acceleration in metre per second squared (m/s 2 ), v is the final velocity in metre per second (m/s), u is the initial velocity in metre per second (m/s), and t is the time taken in second (s).

Acceleration is a vector quantity, as it has both magnitude and direction .

## Worked example 1

A car starts from rest (0 m/s) and accelerates for 10 s to reach a speed of 25 m/s.

Calculate the acceleration of the car.

## Solution

Initial speed, u = 0 m/s

Final speed, v = 25 m/s

Time taken, t = 10 s

$$\Big | \quad \text{Hence acceleration}, \ a = \frac { v - u } { t }$$

$$\Big | \quad a \ = \ \frac { 2 5 \, \text{$-} \, 0 } { 1 0 } \ = \ \frac { 2 5 } { 1 0 } \ = \ 2. 5 \, \text{m/s} ^ { 2 }$$

## Worked example 2

A car moving at a speed of 20 m/s decelerates to stop in 4 s.

Calculate the acceleration experienced by the car.

## Solution

Initial speed, u = 20 m/s

Final speed, v = 0 m/s

Time taken, t = 4 s

$$v - u$$

$$\Big | \quad a \ = \ \frac { 0 \, \mu \, 2 0 } { 4 } \ = \ \frac { \mu \, 2 0 } { 4 } \ = \ \mu \, \mu \, \mu \, \nu \, \nu ^ { 2 }$$

$$\Big | \begin{array} { c } & \text{Hence acceleration}, \ a = \frac { v - u } { t } \\ & a \ = \frac { 0 \, - 2 0 } {. } \ = \frac { \, - 2 0 } {. } \ = \, - 5 \, \text{m/s} ^ { 2 } \end{array}$$

Negative acceleration means deceleration, i.e. the car is slowing down.

<!-- image -->

1. A car starts from rest and accelerates uniformly for 10 s until it reaches a speed of 20 m/s. The car then decelerates to rest in a further 5 s.
2. (a)  Calculate the acceleration of the car during the first 10 s.
3. (b)  Calculate the acceleration of the car during the last 5 s.

<!-- image -->

## WHAT I HAVE LEARNT

A body whose velocity is changing is said to undergo an acceleration. A change in velocity can be in terms of a change in magnitude or a change in direction . A change in magnitude can either be, an increase or a decrease.

## Deceleration

As we have seen in the previous section, an acceleration can either be negative or positive. If the velocity is increasing, the acceleration is positive. If the velocity is decreasing, then the acceleration is negative.

Another way to describe a decreasing velocity is to use the term deceleration . If deceleration is used, then the negative is not used since the term deceleration already implies a decreasing velocity.

## Worked example

A boy is running at a speed of 10 m/s. He decelerates uniformly to stop in 4 s.

Calculate the deceleration experienced by the boy.

## Solution

The acceleration must first be calculated.

Initial speed, u =10 m/s

Final speed, v = 0 m/s

Time taken, t = 4 s

Hence acceleration

v

-

u

a =

t

$$\Big | \quad a \ = \frac { 0 \, \text{-} 1 0 } { 4 } \ = \frac { \, \text{-} 1 0 } { 4 } \ = \, - 2. 5 \, \text{m/s} ^ { 2 }$$

acceleration = -2.5

deceleration =  2.5 m/s 2

<!-- image -->

1. A car is moving at a constant speed of 50 m/s for 20 s. The driver, then, applies the brakes and as a result, the car decelerates to come to rest in 25 s.

Calculate the deceleration of the car.

## Speed-Time Graph

The speed-time graph is a graph that shows how a body is moving. It describes the motion of an object or person.

## Sketching a Speed-Time Graph

For sketching the speed - time graph, two sets of values are required. These are the values of the speeds at various intervals of time, as shown below.

|    | Speed/m/s   | Time/s   |
|----|-------------|----------|
|  1 |             |          |
|  2 |             |          |
|  3 |             |          |
|  4 |             |          |

## ACTIVITY 4.3 - Sketching a speed-time graph from a table of data

<!-- image -->

Study the example given below.

A car starts from rest at t = 0 s and accelerates uniformly for 10 s until it reaches a speed of 10 m/s. The car, then, travels at this constant speed for a further 10 s. The car, then, decelerates uniformly for another 5 s until it comes to rest.

1. Discuss in your groups and answer the questions that follow.
2. (i)  What is the total time taken by the car to complete its motion?
3. (ii)  Complete the table below by indicating the speed of the car at different times.
4. (c) Sketch a speed-time graph on the axes shown below.

|   Time/s | Speed/m/s   |
|----------|-------------|
|        0 |             |
|       10 |             |
|       20 |             |
|       25 |             |

Speed/m/s

In this image, we can see a graph.

<!-- image -->

<!-- image -->

<!-- image -->

## WHAT I HAVE LEARNT

A speed-time graph can be plotted using given values of speed and time.

## Types of Speed-Time Graphs

## 1. An object is at rest.

The speed of the object is zero at all times. So, it is at rest.

The graph is a horizontal line on the x-axis.

## 2.   The body has a constant speed.

The graph is a horizontal line parallel to the x-axis.

For example: The body is moving with a constant speed of 25 m/s.

The acceleration of the body is zero as there is no change in speed.

## 3.   The body moves with increasing speed.

The body is said to have a constant acceleration.

This is shown by a straight line sloping up.

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

In this image, we can see a graph.

<!-- image -->

4.   The body moves with decreasing speed.

The body is said to have a constant deceleration.

This is shown by a straight line sloping down.

In this image, we can see a graph. There is a line on the graph. There is a text on the graph.

<!-- image -->

From a speed-time graph, the following can be deduced:

1. whether the speed is uniform
2. whether the speed is increasing or decreasing.
3. the distance travelled

## Extracting information from a speed-time graph

Study the example given below, discuss in your groups.

A car starts from rest and accelerates uniformly for 10 s until it reaches a speed of 20 m/s. The car, then, travels at this constant speed for a further 20 s. Then, it decelerates to come to rest in a further 10 s.

The speed-time graph obtained is as shown below.

The image depicts a graph with two axes labeled "speed" and "time." The x-axis is labeled "time" and the y-axis is labeled "speed." The graph shows a downward trend, indicating that as the time increases, the speed decreases.

The graph has a linear scale from 0 to 40 on the x-axis, and a linear scale from 0 to 10 on the y-axis. The graph has a horizontal line that is slightly above the y-axis, indicating that the graph is not perfectly horizontal.

The graph has a scale from 0 to 10 on the x-axis, and a scale from 0 to 40 on the y-axis, indicating that the range of values on the x-axis is from 0 to 40, and the range of values on the y-axis is from 0 to 10.

The graph has a title at the top

<!-- image -->

From this graph, the following information is obtained:

1. The nature of the motion: The car has uniform acceleration, then uniform speed and finally uniform deceleration (or retardation).
2. The values of speed at different times can be read.

## Summary of unit

- A  scalar  quantity  is  a  physical  quantity  that  has  a  magnitude  only,  while  a  vector quantity is a physical quantity that has both magnitude and direction.
- The distance of a body is the path taken by a body when moving from an initial position to a final position. Distance is a scalar quantity.
- The displacement of a body is the distance travelled in a straight-line from the initial position  to  the  final  position,  and  in  a  specific  direction.  Displacement  is  a  vector quantity.
- Speed is defined as the rate of change of distance.

Speed  =   Distance travelled

Time taken

- A body has a constant speed if it covers the same distance in the same interval of time (e.g. every second).
- Velocity is defined as the rate of change of displacement.
- Acceleration is defined as the rate of change of velocity.

Velocity  =

Displacement

Time taken

Change in velocity

Time taken

- Acceleration    =

Unit

Unit

P4

1

In this image, we can see a diagram.

<!-- image -->

<!-- image -->

<!-- image -->

## Multiple choice questions

1. Which one of the following quantities is a scalar quantity?
2. A Speed
3. B Velocity
4. C Displacement
2. What additional information is provided by a vector quantity?
6. A Size
7. B Colour
8. C Direction
3. Which of the following consists of a pair of vector quantities?
10. A Speed and distance
11. B Time and distance
12. C Acceleration and mass
13. D Displacement and Force
4. Which of the following describes a scalar quantity?
15. A 4 m
16. B 4 m/s 2 to the right
17. C 6 m/s in a southerly direction
18. D 6 m in a northerly direction
5. Which of the following is the formula for speed?
20. D Acceleration
21. D Thickness

- A

- Speed =    Distance travelled × Time taken

- B Speed =

- C Speed =

- D

- Speed =    Acceleration × Time taken

Distance travelled

Time taken

Time taken

Distance travelled

6. Which of the following is the formula for velocity?
2. A Velocity =    Distance  travelled × Time taken

- B Velocity =

- C Velocity =

- D Velocity =

Distance travelled

Time taken

Time taken

Distance travelled

Displacement

Time taken

The following diagram is to be used for questions 7, 8, 9, 10 and 11.

Three cars move from point X to point Z. They follow three different paths as shown in the diagram below.

The image shows a diagram with two labeled points labeled as Car A and Car B. Car A is located at the top of the diagram and Car B is located at the bottom. Both points are connected by a line segment. The line segment connecting Car A and Car B is labeled as x.

The diagram is labeled as a parabola. A parabola is a type of graph that is defined by the equation x^2 = y. In this diagram, the equation of the parabola is x^2 = y.

### Analysis and Description:
1. **Points and Lines**:
   - Car A is located at the top of the diagram.
   - Car B is located at the bottom of the diagram.
   - Car A and Car B are connected by a line segment.

2. **Graph Representation**:
   - The graph is a parabola.
   - The equation of the parabola is x^2 = y.

3. **Relationships**:

<!-- image -->

7. What is the distance travelled by car A when it moves from point X to point Z?
2. A 50 m
3. B 75 m
4. C 100 m
5. D 137 m
8. If car A takes 10 s to move from point X to point Y, what is the average speed of car A?
7. A 5 m/s
8. B 8 m/s
9. C 10 m/s
10. D 13.7 m/s

9. What is the distance travelled and the displacement of car C?

| Distance travelled   | Displacement   |
|----------------------|----------------|
| 125m                 | 100m           |
| 125m                 | 125m           |
| 100m                 | 125m           |
| 100m                 | 100m           |

## 10. Which of the following statements is correct?

- A All three cars have the same distance travelled.
- B The three cars have the same displacement.
- C Car A has the smallest displacement.
- D Car B has the greatest displacement.

## 11. Car C moved from point X to point Z in 25 s. What is the speed of the car C?

- A 4 m/s
- B 5 m/s
- C 9 m/s
- D 15 m/s
12. Which one of the following is the formula of acceleration?
13. A toy accelerates from 5 m/s to 10 m/s in 10 s. What is the acceleration of the toy?
- A 0.5 m/s 2
- B 1.0 m/s 2
- C 1.5 m/s 2
- D 2.0 m/s 2
14. A truck starts from rest and accelerates for 10 s at a rate of 5 m/s 2 . What is the final speed of the car?
- A 10 m/s
- B 20 m/s
- C 40 m/s
- D 50 m/s

| A   | Acceleration =   | Distance ×Time taken   |
|-----|------------------|------------------------|
| B   | Acceleration =   | Speed Time taken       |
| C   | Acceleration =   | Time taken             |
| D   | Acceleration =   | Velocity Time taken    |

- A lorry is travelling at a constant speed of 40 m/s. It decelerates for 10 s until it comes to rest.
15. What is the deceleration of the lorry?
- A 1.5 m/s 2
- B 2.0 m/s 2
- C 3.0 m/s 2
- D 4.0 m/s 2
16. Which is an appropriate unit to show the speed of a snail moving on a wall?
- A mm/s
- B m/s
- C km/s
- D km/h

In this image, we can see a graph. There is a text on the image.

<!-- image -->

## Structured Questions

- 1 .(a ) Differentiate between a scalar quantity and vector quantity.

- (b) List  two scalar quantities and two vector quantity.

2. Rita leaves for school in the morning at 7.00 am. She walks a distance of 600 m and reaches her friend's house at 7.10 am. She and her friend then walk a distance of 1200 m to school. They reach school at 7.40 am.
2. (c) Calculate the speed of Rita in m/s
3. (i) during the first part of her walk.
4. (ii) during the whole walk.

- (a)   Suggest an instrument used to measure the distance walked by Rita.

- (b)  How long does Rita take to walk to school in the morning?

3. A car accelerates uniformly from rest for 10 s to reach a speed of 15 m/s. The car, then, remains at that speed for a further 10 s. It, then, decelerates uniformly to come to rest in 5 s.
2. (a)  Define the term acceleration.
3. (b) Use the axes below in order to sketch the speed-time graph of the car.
4. A car travels the first 12 km of a journey in 10 minutes.  The car, then, travels the remaining 18 km in 20 minutes.  Calculate:
5. (i)   the total distance travelled.
6. (ii)  the total time taken in hours.

In this image, we can see a graph.

<!-- image -->

(iii) the average speed of the car in km/h.

5. A car starts from rest and accelerates uniformly to reach a speed of 10 m/s in 20 s. The car, then, travels at this constant speed of 10 m/s for another 20 s.  Finally, the brakes are applied and the car decelerates uniformly to rest in 5 s.

Sketch the speed-time graph for the whole motion.

6. Consider the speed-time graph below. Describe the motion of the body.

In this image, we can see a graph.

<!-- image -->

Time / s

## Learning Outcomes

## At the end of this unit, you should be able to:

- Identify symbols of electrical components
- Show an understanding that current is the rate of flow of charge and use the formula Q = It to solve problems
- Measure current using an ammeter
- Define potential difference as the work done per unit charge moved between two points in an electric circuit
- Measure potential difference using a voltmeter
- Define e.m.f. as the work done per unit charge moved round a whole circuit
- Use the formula W = QV to solve problems
- Define resistance as the ratio of the potential difference across a conductor to the current flowing through it and use the formula R = V/I to solve problems
- Draw electric circuits in series using appropriate circuit symbols
- Determine the combined resistance of a combination of resistors arranged in series
- Solve problems related to electric circuits

In our daily life, we are surrounded by one of the most significant discoveries of all time, that is, electricity.  Electrical energy is the most versatile form of energy that exists and it plays a pivotal role in our life.  Almost all the devices at homes and in industries operate with electricity.

When your mobile phone displays a 'low battery' warning, what do you do to charge it?  What makes machines in factories operate?  Obviously, the answer is electrical energy.

In fact, it is really hard to imagine our life without electricity!

In Grade 7, you learnt about the importance of electricity and some simple electric circuits.  In Grade 9, you are going to learn more on electric circuits and how to solve simple problems related to these circuits.

Motion

Electricity

Unit

Electricity

P 5

Unit

Unit

Unit

Unit

P4

P5

1

1

## Symbols of Electrical Components

As you have learnt in Grade 7, each circuit component can be represented by a symbol. The circuit symbol is used to represent electrical components more conveniently when drawing electrical circuit diagrams.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Electrical Component                                                                     | Symbol (s)   | Use (s)                                      |
|------------------------------------------------------------------------------------------|--------------|----------------------------------------------|
| 1) Cell                                                                                  |              | supplies electrical energy                   |
| 2) Battery (when more than 1 cell is used) Note : The cells are placed in a cell holder. | + -          |                                              |
| 3) Power supply                                                                          |              | supplies electrical energy                   |
| 4) ConnectionWire                                                                        |              | conducts current across a circuit            |
| 5) Open switch                                                                           |              | breaks a circuit (stops the flow of current) |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| 6) Closed switch                                          |    | completes a circuit (allows current to flow)                                                                          |
|-----------------------------------------------------------|----|-----------------------------------------------------------------------------------------------------------------------|
| 7) Bulb/lamp (placed on a bulb holder)                    | or | converts electrical energy to light energy and heat energy                                                            |
| 8) Ammeter (a) Analogue ( b) Digital ammeter ammeter      |    | measures current                                                                                                      |
| 9) Voltmeter (a) Analogue (b) Digital voltmeter voltmeter |    | measures: 1. the potential difference between two points in a circuit 2. the electromotive force of a cell or battery |
| 10) Resistor                                              |    | limits the amount of current flowing in a circuit                                                                     |

Since the terminals of a cell are bare, it is difficult to connect wires to them. Therefore, the cell has to be placed in a cell holder for facilitating connections to its ends. A cell holder has NO circuit symbol. The figure beside shows a typical cell holder.

<!-- image -->

## Electric Current

An electric current consists of the flow of charges (electrons) through a conductor.  Since we cannot see electrons, it is helpful to have an analogy of electric circuits to help us understand circuits better.  For instance, water flowing through a pipe is a mechanical system that can be compared to an electrical circuit .

A mechanical system consisting of a pump pushing water through a closed pipe.

In this image there is a diagram, in the diagram there is a water pump, there is a tap, there is a soil, there is a soil with water flow, there is a soil with water, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water flow, there is a soil with water

<!-- image -->

<!-- image -->

A simple electric circuit consisting of a battery driving a current through it.

If you imagine that the electric current is similar to the water flowing through the pipe, then the following comparisons can be made:

| Analogy                                    | Explanation                                                                                                                                                                             |
|--------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| pump → battery                             | The battery is like the pump . It provides energy.                                                                                                                                      |
| pipe → connecting wire                     | The connecting wire in the electric circuit is like the pipe . It is the pathway for the charges to move through.                                                                       |
| water flow → current flow                  | The current flow in the wire is like the water flow in the pipe.                                                                                                                        |
| pressure → potential difference difference | The potential difference generated by the battery which drives electrons through the circuit is like the pressure difference generated by the pump which drives water through the pipe. |
| deposit → resistor of dirt particles       | The resistor in the circuit resists the flow of charges, similarly to how the deposit of dirt particles resists the flow of water inside the pipe.                                      |

## Definition of electric current

An electric current is defined as the flow of charges per unit time .  The SI unit for current is the ampère (A).

Note: The term 'per unit time' means to divide by time.  'Rate' is another word to express the same idea.  Thus, another way of defining electric current is:

## An electric current is defined as the rate of flow of charges.

<!-- image -->

where  I is current measured in ampères (A), Q is charge measured in coulombs (C), and t is time taken measured in seconds (s).

Current  flows  from  the positive to  the negative terminal  of  a cell or battery through a circuit.  This is illustrated by the green arrows.  As from now, we will only consider the current flow.

<!-- image -->

## Worked example

Calculate the current which flows when a charge of 10 C passes through a lamp in 5 s.

## Solution

charge, Q = 10 c time taken, t = 5 s

$$I \, = \, \frac { Q } { t }$$

$$I \ = \frac { 1 0 \, C } { 5 \, s }$$

$$I \, = \, 2 A$$

<!-- image -->

1.   A conductor carries a current of 4 A in an electrical circuit.
2. (i) What do you understand by a current of 4 A?
3. (ii)  Calculate the charge that flows through a point in 40 s.
2. A current of 0.5 A flows in a circuit.  How long does it take for 100 C to flow past a given point in the circuit?
3. The current in an electric heater is 10 A.  It is switched on for five minutes.  How much charge flows through the heater?

## Measurement of Electric Current

An ammeter is used to measure electric current.

An ammeter has a positive (+) terminal, usually red coloured, and a negative (-) terminal, usually black coloured.  The positive terminal of the ammeter is connected to the positive terminal of the cell or battery. Likewise, the negative terminal is connected to the negative terminal of the cell or battery. An ammeter is always connected in series in a circuit as shown in the figure below.

In this image we can see a few objects. We can see a few wires. We can see a few objects. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected with a wire. We can see a few objects are attached to a wire. We can see a few objects are connected

<!-- image -->

<!-- image -->

## WORK OUT

In the space provided above, draw the corresponding circuit diagram (using symbols) for the circuit with the ammeter connected in series.  Also, indicate the direction of the current flow .

<!-- image -->

## WHAT I HAVE LEARNT

1.   Current is defined as the rate of flow of charges.
2.   The SI unit of current is the ampère (A).
3.   Current is measured using an ammeter which is always connected in series.

<!-- image -->

## DID YOU KNOW…

André-Marie  Ampère  (1775-1836)  was  a  French  physicist  and mathematician who invented numerous applications, such as the electrical  telegraph. The  SI  unit  of  electric  current,  the ampère has been named after this scientist.

<!-- image -->

## Electromotive Force (e.m.f)

We are, now, going to refer back to the water flow analogy mentioned earlier and use it to explain electromotive force.

## Consider the figure below.

In this image, we can see a diagram.

<!-- image -->

Just  as  the  pump  pushes  (that  is,  provides  energy  to)  the  water  for  it  to  move  out  at  high pressure, similarly the battery pushes (provides energy to) the charges for them to move out of the positive terminal.

Unit

P5

## Definition of Electromotive Force

The electromotive force of a battery is defined as the work done by the battery in moving a charge of one coulomb round a complete circuit. The SI unit of e.m.f is the volt (V).

<!-- image -->

where E is the e.m.f measured in volts (V), Wd is work done measured in joules (J), and Q is flowing charge measured in coulombs (C).

Another unit for e.m.f. is the joule per coulomb (J/C).

One volt is equal to one joule per coulomb (J/C), that is, 1 V = 1 J/C.

Note : Electromotive force is NOT a force.

## Potential Difference

To get a better idea of what potential difference represents in a circuit, it may be useful to refer back to the analogy between water flow and electric current.

In this image, we can see a diagram.

<!-- image -->

In the above example, for water to be able to flow from point B to point A , the water at B must be at a high pressure while the water at A must be at a low pressure. This pressure difference provides the energy needed for water to flow between the two points.

Similarly, for current to flow between two points in a circuit (that is, for charges to move) there must be a potential difference between the two points in the circuit so that charges can move from one point to another (that is, for current to flow).

## Definition of Potential Difference

The potential difference between two points in a circuit is defined as the work done in moving a charge of one coulomb between the two points. The SI unit for potential difference is the volt (V).

| potential difference   | work done charge   |
|------------------------|--------------------|
| W d Q V =              | ; W d = QV         |

where  V is potential difference measured in volt (V), W d is work done measured in joule (J), and Q is flowing charge measured in coulomb (C).

Note : A potential difference of 5 V means that 5 J of work is done when one coulomb of charge is moved between two points in a circuit.

<!-- image -->

## DID YOU KNOW…

Italian physicist Alessandro Giuseppe Antonio Anastasio Volta (17451827) was a pioneer of electricity and power, who is credited as the inventor of the voltaic pile (now known as the dry cell). The SI unit of potential difference, the volt has been named after this scientist.

<!-- image -->

## Measurement of Potential Difference (or Voltage)

A voltmeter is used to measure the potential difference, or voltage, between two points in an electrical circuit.  In order to measure the potential difference across a device, the voltmeter is always connected in parallel to that device as shown in the figure below.

In this image we can see a box with some objects and wires.

<!-- image -->

In this image, we can see a square shape.

<!-- image -->

<!-- image -->

In the space provided above, draw the corresponding circuit diagram (using symbols) for the circuit with the voltmeter connected in parallel.

<!-- image -->

An e.m.f. of 3 V for the battery means that 3 J of energy is supplied by the battery to allow a charge of one coulomb to move across the external circuit. Thus, electromotive force represents energy supplied to every charge flowing through the battery.

A potential difference of 3 V for the lamp means that 3 J of work is done to allow a charge of one coulomb to move across the lamp. Thus, potential difference represents energy used by every charge moving across two points in the circuit.

## Worked example

Calculate the work done in moving a charge of 6 C through a potential difference of 30 V in an electrical circuit.

## Solution:

Work done = charge × potential difference = 6 C × 30 V = 180 J.

<!-- image -->

1. The potential difference  between the ends of a conductor is 12 V. How much electrical energy is converted to other forms of energy in the conductor when 100 C of charge flows through it?
2. What is the potential difference between two points in an electrical circuit if 2 C of charge needs 4 J of energy to move between them?
3. A 12 V car battery is connected to a lamp for 1 minute. A current of 2 A flows through the lamp. Calculate:
4. (i)   The charge flowing through the lamp

- (ii)  The energy used by the lamp
4. A battery of e.m.f. 12 V is connected to an electrical component through which a current of 4 A flows for 20 s.
- (i) What is meant by an e.m.f. of 12 V?
- (ii) What is the work done by the battery?

<!-- image -->

## WHAT I HAVE LEARNT

1.  The electromotive force of a battery is defined as the work done by the battery in moving a charge of one coulomb round a complete circuit.
2.  The potential difference between two points in a circuit is defined as the work done in moving a charge of one coulomb between the two points
3. The SI unit of e.m.f and potential difference is volt (V).
4.  A voltmeter is used to measure electromotive force and potential difference.
5.  A voltmeter is always connected in parallel.

<!-- image -->

## DID YOU KNOW…

Different sources of electrical energy have different values of electromotive force. Typical voltage of different sources of electrical energy are shown below.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Dry cell                                       | 1.5V                                                   |
|------------------------------------------------|--------------------------------------------------------|
| Car battery                                    | 12V                                                    |
| Mobile phone battery                           | 4.7V                                                   |
| Mains supply (from an electrical power socket) | 240V                                                   |
| Lightning                                      | Approximately 300 000V (300 kV); up to a million volts |

You may recall from Grade 7 that some materials conduct electricity better than other materials. But why are some materials good conductors of electricity and some are poor conductors?

In the next section, we will discuss about the reason for this in more details.

## Resistance

Materials are generally classified as conductors or insulators of electricity.

Relatively little electrical energy is needed for charges to move through conductors whereas even considerable amounts of electrical energy may not be sufficient to move charges through insulators.

The property of materials responsible for the difference in energy needed to drive an electric current through them is called ' electrical resistance ' .

Once  more,  the  analogy  between  electricity  and  water  flow  can  help  us  understand  this property in more detail.

In this image, we can see a diagram.

<!-- image -->

As illustrated in the above figure, the presence of dirt and other particles can oppose the flow of water in a water pipe. A greater number of such particles provides a greater opposition to the flow of water.

Similarly, the property called (electrical) resistance of a material opposes or resists the flow of an electric current (charges) through the material. Thus, a material of higher resistance has a greater opposition to the flow of an electric current.

<!-- image -->

## DID YOU KNOW…

Good conductors have a low resistance which permits easy flow of a current through them. On the other hand, poor conductors have a high/large resistance which strongly opposes the flow of current through them.

## Definition of Resistance

The resistance of a resistor is defined as the ratio of the potential difference across it to the current flowing through it. The SI unit of resistance is the ohm (Ω).

| Resistance   | potential difference current   |
|--------------|--------------------------------|
| R =          | ; V=IR V I                     |

where  R is resistance measured in ohm (Ω),

V is potential difference measured in volt (V), and I is current flowing measured in ampère (A).

The greater the resistance in a circuit, the lower the current.

## Worked example

A 10 V battery is connected in series with a resistor of resistance 20 Ω.  Calculate the current I that flows through the lamp.

## Solution:

e.m.f, V = 10 V resistance, R = 20 Ω

$$R = \frac { V } { I } _ { \dots }$$

20

=

10

I

$$\sum _ { \substack { I = \, \frac { 1 0 } { 2 0 } \, = \, \frac { 1 } { 2 } \, A = 0. 5 \, A } }$$

<!-- image -->

## DID YOU KNOW…

George Ohm (1789-1854), was a German physicist and mathematician. As a  school  teacher,  Ohm began his research with the new electrochemical cell,  invented by Italian scientist Alessandro Volta. He found that there is a direct proportionality relationship between the potential difference of a conductor and the current flowing through it. He named it Ohm's law. The SI unit of resistance, the ohm has been named after this scientist.

<!-- image -->

## Measurement of resistance

A resistor is a component which limits the flow of current. In this unit, you will learn about resistors connected in series and how to calculate their combined resistance.

2 resistors connected in series

<!-- image -->

## ACTIVITY 5.1 - Comparing resistances of two fixed resistors

<!-- image -->

## Materials needed:

- a battery
- a bulb
- a switch
- connecting wires
- two different fixed resistors

## Procedure:

1. Set up the circuit as shown on the right. Close the switch. Observe the brightness of the bulb.
2. Replace the fixed resistor R 1 with the second fixed resistor R 2 . Close the switch.

<!-- image -->

The bulb is now \_\_\_\_\_\_\_\_\_\_\_ (less bright / brighter) than step 1.

Therefore, the current is \_\_\_\_\_\_\_\_\_\_\_ (smaller / larger) than in step 1, and the resistance of R is \_\_\_\_\_\_\_\_\_\_\_\_\_ (smaller / larger) than in step 1.

2

## Conclusions:

1. When resistance increases, current decreases across the whole circuit. Therefore, the potential difference across the bulb decreases and the bulb is less bright.
2. When resistance decreases, current increases across the whole circuit. Therefore, the potential difference across the bulb increases and the bulb is brighter.

## Resistors in series

The total resistance (R total ) for the resistors in series is the sum of the individual resistances (R 1 + R 2 + R 3 ).

<!-- image -->

$$R _ { \text{total} } = R _ { 1 } + R _ { 2 } + R _ { 3 }$$

where R total is the total resistance in ohm (Ω), and

R

1 , R 2 , R 3 are the resistances of the resistors in series.

Hence, when resistors are connected in series, the individual resistances are added up and the total resistance increases.  This decreases the current.

## Worked example

Three resistors of resistance 1Ω, 2Ω and 6Ω are connected in series.  Calculate their total resistance.

## Solution:

$$R _ { \text{total} } & = R _ { 1 } + R _ { 2 } + R _ { 3 } \\ R _ { \text{total} } & = 1 + 2 + 6 = 9 \, \Omega$$

<!-- image -->

1. Find the total resistance of the following:

<!-- image -->

2.   Consider the circuit below and answer the questions that follow.
2. (a)  Draw a circuit diagram representing the above circuit.
3. (b) What physical quantity is the voltmeter measuring?

In this image we can see a few objects. We can also see a wire and a cable.

<!-- image -->

Unit

P5

- (c)  Write down the values shown by each meter.

Connected to scale 0 - 5 V

<!-- image -->

Connected to scale 0 - 1 A

<!-- image -->

Voltmeter reading:

Ammeter reading:

- (d) Calculate the resistance of the bulb.
- (e)  If the current flows for one minute, calculate:
- (i)   the amount of charge flowing through the bulb,
- (ii)  the energy transferred through the bulb.

<!-- image -->

DID YOU KNOW…

There are two types of resistors: fixed and variable .

Fixed resistors come in different ratings, shapes, sizes and colours as shown in the figure beside.

<!-- image -->

A rheostat is a variable resistor .  By changing the resistance you can control the current flowing through it.

<!-- image -->

Resistors  are  available  commercially  in  standard  values  of  resistance  only.  Often,  however, specific  values  of  resistance  are  required  for  certain  specific  applications  but  these  values of  resistance are not available. In such cases, resistors need to be combined to achieve the required value of resistance.

## Circuit diagrams: Series circuits

In a series circuit, all the components are connected one next to the other to form a single loop. Hence, a series circuit has only one path through which electric current can flow as shown in figure below.

<!-- image -->

Any gap in any part of a series circuit stops the flow of current in the whole circuit.  Similarly, if one lamp blows out, the series circuit breaks. Current stops flowing and the other lamp stops lighting.

In this image we can see a diagram.

<!-- image -->

Since there is only one path for the current to flow, therefore, the same current flows through all the lamps in the circuit.

The sum of the potential difference across each lamp in the circuit is equal to the e.m.f of the electrical source.

<!-- image -->

## ACTIVITY 5.2 - Investigating series circuits

<!-- image -->

## Materials needed:

- a battery
- a switch
- an ammeter
- a voltmeter
- two bulbs and two bulb holders
- connecting wires

## Procedure:

1. Connect the circuit as shown below by placing the ammeter at point A and close the switch.
2. Note down the ammeter reading at point A.

In this image, we can see a diagram. There are two wires, one is connected to a mobile and the other one is connected to a device.

<!-- image -->

Ammeter reading at point A = \_\_\_\_\_\_\_\_\_\_\_ A

3. Now connect the ammeter at point B as shown below and close the switch.
4. Note down the ammeter reading at point B.

In this image we can see a mobile phone and a wire connected to it.

<!-- image -->

Ammeter reading at point B = \_\_\_\_\_\_\_\_\_\_\_ A

5. Connect the ammeter at point C and close the switch.
6. Note down the ammeter reading.
3. Ammeter reading at point C = \_\_\_\_\_\_\_\_\_\_\_ A
7. Comment on the values of the currents measured at points A, B and C.
8. Connect the voltmeter across each bulb in turn and note down the potential difference across each one.
6. Potential difference across bulb L1 = \_\_\_\_\_\_\_\_\_\_\_ V

In this image we can see a diagram of a box with a switch and a wire.

<!-- image -->

In this image we can see a box with some wires and a socket.

<!-- image -->

In this image, we can see a box with a wire and a plug. We can also see a box with a wire and a plug.

<!-- image -->

Potential difference across bulb L2 = \_\_\_\_\_\_\_\_\_\_\_ V

9. Calculate the sum of the potential difference across bulbs L1 and L2.

Total potential difference across L1 and L2 = \_\_\_\_\_\_\_\_\_\_V

Unit

P5

10. Measure the potential difference across the whole circuit by connecting the voltmeter parallel to both bulbs and compare its value with the sum of the potential difference across bulbs L1 and L2.  What can you conclude?
11. Remove bulb L1 from its holder and close the switch. What happens to bulb L2?
12. Now, place bulb L1 to its holder and screw out bulb L2, and close the switch.  What happens to bulb L1?

## Conclusions:

1. The current flowing in a series circuit is the same at different points.
2. No current flows when any one component is removed as the circuit is broken.
3. The total potential difference of the circuit is equal to the sum of the potential difference across each bulb/resistor.

<!-- image -->

## WHAT I HAVE LEARNT

## Series circuits

<!-- image -->

-    Electric current through each component in a series circuit is the same .
- Potential difference across each component is different depending on the resistances of the components.
-     A series circuit has one path for current to flow.

The sum of the p.ds across each bulb is equal to the total p.d. of the circuit.

$$V = V _ { 1 } + V _ { 2 }$$

The p.d. across each bulb may be different but the current through each bulb is the same.

-     If one of the bulb is removed, the current flow to the remaining bulbs would be interrupted because the circuit is broken or becomes incomplete.

<!-- image -->

## ACTIVITY 5.3 - Investigating voltage across cells in series

<!-- image -->

## Materials needed :

- three 1.5 V dry cells
- a voltmeter
- connecting wires
- one bulb
- a switch

## Procedure:

1. Set up the circuit as shown below.

<!-- image -->

Close the circuit.

2.  Record the voltmeter reading for circuit P in the table below.

| circuit   |   number of cells | voltmeter reading /V   |
|-----------|-------------------|------------------------|
| P         |                 1 |                        |
| Q         |                 2 |                        |
| R         |                 3 |                        |

Observe the brightness of the bulb.

3.  Repeat step 2 with two cells in series.
4.  Now, repeat step 2 with three cells in series.

The image depicts a simple electrical circuit diagram. The diagram consists of two main components: Circuit Q and Circuit R.

### Circuit Q

#### Circuit Q
- **V1** (V1) is connected to the top left corner of the diagram.
- **V2** (V2) is connected to the top right corner of the diagram.
- **V3** (V3) is connected to the bottom left corner of the diagram.
- **V4** (V4) is connected to the bottom right corner of the diagram.
- **V5** (V5) is connected to the top left corner of the diagram.
- **V6** (V6) is connected to the bottom right corner of the diagram.

#### Circuit R
- **V7** (V7) is connected to the top left corner of the diagram.
- **V8** (V8) is connected to the top

<!-- image -->

More cells in series give a \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ (higher / lower) voltage.

What happens to the brightness of the bulb as the number of cells increases?

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## Conclusion:

As  the  number of  cells  increases,  the  voltage  increases.    Hence,  the  brightness  of  the  bulb increases.

The total e.m.f across all the cells connected in series (battery) is equal to the sum of the e.m.f of the individual cells.

## Combined resistance for resistors in series

<!-- image -->

## Resistors in series

<!-- image -->

The total resistance (combined or effective resistance) R is given by the equation: R = R 1 + R 2 + R 3

The e.m.f., V , is equal to the sum of the potential differences, V 1 , V 2 and V 3 across each resistor.

$$V = V _ { 1 } + V _ { 2 } + V _ { 3 }$$

If  all  the  three resistors have the same resistance, then, the p.d., across each resistor is equal.

$$V _ { _ { 1 } } = V _ { _ { 2 } } = V _ { _ { 3 } }$$

The same current flows through each resistor and throughout the circuit.

## Worked example

1. Three  resistors  of  resistance  2Ω,  3Ω  and 5Ω  respectively  are  connected  in  series with a battery, an ammeter and a switch as shown.

<!-- image -->

If the potential difference across the 3Ω resistor is 4.5 V , calculate:

- (i) the combined resistance of all the resistors,
- (ii) the current flowing through each resistor,
- (iii) the potential difference across each resistor,
- (iv) the total potential difference of the circuit.

## Solution:

(i) Since the resistors are connected in series, using the formula for series combination gives the total resistance R as:

R

$$R & = R _ { _ { 1 } } + R _ { _ { 2 } } + R _ { _ { 3 } } \\ & = 2 \Omega + 3 \Omega + 5 \Omega = 1 0 \Omega$$

(ii)

Using the formula V = IR the current I is

$$\Big | \quad I = \, \frac { \text{V} } { R } \, = \, \frac { 4. 5 } { 3 } = 1. 5 \, A$$

Since the resistors are connected in series, the current through each one is the same, that is 1.5 A

(iii)

Using the formula V = IR ,

P.d. across the 2Ω  resistor =  1.5 x 2  = 3.0 V

P.d. across the 3Ω resistor  =  4.5 V

P.d. across the 5Ω resistor  =  1.5 x 5 = 7.5 V

(iv)

Total p.d. = sum of p.d. across each resistor in series

= 3.0 V + 4.5V + 7.5V = 15V

<!-- image -->

Electric eels can produce strong electric shocks of around 500V!

They use this ability to hunt and to protect themselves too.

<!-- image -->

<!-- image -->

1. A cell has an emf of 1.5 V . It is connected in series with two resistors of resistance 4Ω and 6Ω connected each, as shown in the figure. 1.5 V
2. Calculate the:
3. (a)   combined resistance,
4. (b)   current flowing through the circuit,
5. (c)  potential difference across each resistor.
2.   A circuit is set up as shown in the diagram.
7. (a)  What is the value of the resistor R ?

<!-- image -->

<!-- image -->

- (b)   Calculate the p.d across each resistor.
3.   A battery consists of 3 cells, each of 1.5 V arranged in series. Two identical bulbs are connected in series together with the battery as shown in the diagram. The resistance of one lamp is 150 Ω.

## Calculate:

- (a)  the e.m.f. of the battery,
- (b)  the potential difference across each bulb,
- (c)  the current through the bulbs.
- (d)  Give one drawback of arranging bulbs in series.

<!-- image -->

DID YOU KNOW…

The  type  of  electricity  that  we  get  from  cells  and  batteries  are known as direct current (d.c.).

However,  electrical  energy  is  generated  and  distributed  in  a different  form  called  alternating  current  (a.c.).  For  example,  a television set or the washing machine at your home uses alternating current. The reason for using alternating current is mostly because its transmission across large distances and distribution at different voltages is more practical and efficient. In Grade 11, you will learn more about alternating current.

St Louis Power station

<!-- image -->

<!-- image -->

## Summary of unit

## In this unit, you have learnt about

- An electric current is defined as the rate of flow of charge.
- The unit of charge is the coulomb ( C ).
- The unit of electric current is the ampère ( A ).
- An ammeter is used to measure electric current and is always connected in series in a circuit.
- The formula used to calculate electric current is current = charge time
- As the number of bulbs in series increases in a circuit, the brightness of each bulb decreases.
- Potential difference is the amount of energy required to move a charge of 1 coulomb between two points in a circuit.
- The e.m.f. of a source is numerically equal to the work done per unit charge moved round a complete circuit.
- The units of potential difference and e.m.f. are volt ( V ) or joule per coulomb ( J/C ).
- Potential difference is measured with a voltmeter and is always connected in parallel in a circuit.
- Resistance of a resistor is defined as the ratio of the potential difference across it to the current flowing through it.
- Resistance can be calculated by using the formula V = IR .
- In series circuits, the electric current is the same throughout the circuit whereas the potential difference across each component may be different.
- The formula used to calculate the combined resistance of resistors in series: R = R 1 + R 2 + R 3 where R is the total resistance and R 1 , R 2 and R 3 are the respective resistances.

• Unit 5 • Electricity

Electricity circuit symbols

study of flows through

does not flow through represented by

charge Q

in the flow of

I

Current, flows in

circuits made up of

circuit components connected with

conductors

Insulators measured in

coulomb (C)

causes flow of potential difference, V

generates electromotive force,

e.m.f.

formula measured with

has unit calculated as

has unit measured with

Q

=

charge ammeter

ampere (A)

T

time resistor

W

Q

work done

=

charge flowing volt (V)

voltmeter connected in

connected in has

connected in parallel

series resistance, R

series total resistance

unit calculated as

3

R

+

2

R

+

1

R

=

R

ohm ( Ω)

V

=

potential difference

I

current

<!-- image -->

## Multiple choice questions

1. Which of the following particles is negatively charged?

- A Proton

- B Neutron

- C Electron

- D Nucleus

2. A charge of 120 C flows through a circuit in 1 minute. Calculate the amount of current flow- ing through the circuit?

- A 0.2 A

- B 2 A

- C 2.2 A

- D 120 A

3. The unit of electric current is the

- A Volt

- B Ohm

- C Ampere

- D Coulomb

4. Which instrument is used to measure the current flowing in a circuit?

- A Analogue Voltmeter

- B Digital Thermometer

- C Digital Ammeter

- D Digital Voltmeter

5. A wire has a current of 4 A passing through it. How much charge passes a point in the wire in 2 minutes?

- A 480 C

- B 8 C

- C 0.5 C

- D 240 C

6. Which quantity can be measured in joule/coulomb?

- A Charge

- B Potential difference

C

Resistance

- D Current

7.   Which of the following is the electrical symbol for a bulb?

A

B

C

D

A

<!-- image -->

Unit

Unit

P5

1

8. The figure below illustrates a battery, a switch, a bulb and a meter X connected as shown.

<!-- image -->

What does the instrument labeled meter X measure?

- A The amount of energy stored in the cell
- B The resistance of the battery
- C The current flowing through the bulb
- D The potential difference across the bulb
9. Which of the following describes the electromotive force of a cell?
- A The total energy used to drive unit charge round the complete circuit.
- B The energy used to drive charges in a circuit.
- C The energy used to drive unit charge between two points.
- D The rate of flow of charge
10. A battery drives 100 C of charge round a circuit. The energy transferred is 900 J. What is the electromotive force of the battery?
- A 90000 V

B 9 V

C 0.9 V

- D 9000 V
11. Which quantity has the same units as electromotive force?
- A Resistance
- B Current
- C Potential difference D Charge

Electricity

12. Which circuit can be used to find the resistance of the bulb?
13. When a potential difference of 2 V is applied across a resistor, 10 J of energy is dissipated as heat. How much charge flows through the resistor?

In this image, we can see a diagram.

<!-- image -->

A 0.2 C

B 5 C

C 20 C

- D 200 C
14. What is the current in a 5 Ω resistor when the potential difference between the ends of the resistor is 2.5 V?

A 2 A

B 12.5 A

C 0.5 A

D 125 A

15. What do you understand by a potential difference of 5 V ?
2. A 5 J of energy is needed to drive 1 C of charge round a complete circuit
3. B 5 J of energy is needed to drive 1 C of charge between 2 given points in circuit
4. C 1 J of energy is needed to drive 5 C of charge round a complete circuit
5. D 1 J of energy is needed to drive 5 C of charge between 2 given points in circuit

## STRUCTURED QUESTIONS

1. Two  dry  cells  are  connected  in  series  with  each  other  to  make a  battery  of  e.m.f.  3 V .  The  battery  is,  then,  connected  to  a  lamp as shown. When the circuit is switched on, 12 C of charge passes through the circuit in 10 seconds.
2. (a)   What do you understand by an e.m.f. of 3 V?
3. (b)   What amount of energy is transformed into electrical energy?
4. (c) Calculate the current in the circuit.
2. A battery maintains a current of 1.2 A in the circuit shown.
6. (a) Calculate the potential difference across
7. (i) AB

(ii)     CD       (iii) BC

<!-- image -->

- (b) What is the time taken for a charge of 30 C to flow through the 2 Ω resistor?
- (c) What is the electromotive force of the battery?

<!-- image -->

- (d) How would you connect an ammeter to measure the current  in  the  circuit  and  a voltmeter to measure the potential difference across AB? Draw a circuit diagram to show this.
3. A  6  Ω  resistor  and  a  resistor  of  unknown  resistance R are  connected  in  series  with  an ammeter and a 4 V battery. The ammeter reads 0.25 A .
- (a) What is the charge flowing through the ammeter in 1 minute?
- (b)   What is the potential difference across the 6 Ω resistor?
- (c) What is the potential difference across the resistor R ?
- (d)   What is the current through the resistor R ?
- (e) What is the value of the resistance of the resistor R ?

<!-- image -->

Unit

P5

<!-- image -->

## GROUP WORK (PROJECT WORK)

The photo on the right shows an outstandingly brilliant scientist called Nikola Tesla.  He  has  his  contribution  in  the  way  electricity  reaches  our homes and most of the communication devices that we use.

Prepare  a  short  PowerPoint  presentation  of  not  more  than  10  slides  to show some of his major inventions. You can work in groups of maximum 5 pupils.

## WEBLINK (Electric current)

https://www.youtube.com/watch?v=8gvJzrjwjds

## WEBLINK (Structure of atom)

https://www.youtube.com/watch?v=lP57gEWcisY

WEBLINK (e.m.f. and potential difference)

https://www.youtube.com/watch?v=v7XQs2sKsKU

<!-- image -->

In this image we can see a poster with some text and images.

<!-- image -->